using UnityEngine;
using UnityEngine.UI;
using System.IO;

public class BackgroundLoader : MonoBehaviour
{
    public string filePath = "C:/test/background.jpg";
    public RawImage backgroundImage;

    public void Awake()
    {
        // Auto-find the RawImage named "Background"
        backgroundImage = GameObject.Find("Background").GetComponent<RawImage>();
    }

    public void Start()
    {
        LoadBackgroundFromFile();
    }

    public void LoadBackgroundFromFile()
    {
        if (!File.Exists(filePath))
        {
            Debug.LogError("Background file not found: " + filePath);
            return;
        }

        byte[] bytes = File.ReadAllBytes(filePath);

        Texture2D tex = new Texture2D(2, 2);
        tex.LoadImage(bytes);

        backgroundImage.texture = tex;
    }
}