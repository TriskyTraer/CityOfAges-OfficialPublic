using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class ButtonRandomNumber : MonoBehaviour
{
    private Button btn;
    private TMP_Text label;

    void Awake()
    {
        btn = GetComponent<Button>();
        label = GetComponentInChildren<TMP_Text>();

        btn.onClick.AddListener(ChangeCaption);
    }

    void ChangeCaption()
    {
        int n = Random.Range(1, 10); // 1–9
        label.text = n.ToString();
    }
}

