VERSION 5.00
Begin VB.Form frmHelpAdminBuildArea 
   Appearance      =   0  'Flat
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   " ADMINISTRATION IMMORTAL SKILLS - AREAS and DOORS"
   ClientHeight    =   13680
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12285
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   11.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpAdminBuildArea.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   13680
   ScaleWidth      =   12285
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   11
      Left            =   120
      TabIndex        =   50
      Text            =   "JUMP"
      Top             =   12600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   26
      Left            =   1200
      TabIndex        =   49
      Text            =   "IMMO JUMP (0-255) more is harder. For pole vaulters: Gladiators/Warriors/Assassins/Gypsys"
      Top             =   12600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   25
      Left            =   1200
      TabIndex        =   48
      Text            =   "IMMO DLEV (doorid) will create a lever to the door. You can have many levers to unlock the door, fun stuff!"
      Top             =   12120
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   6
      Left            =   120
      TabIndex        =   47
      Text            =   "DLEV"
      Top             =   12120
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   24
      Left            =   120
      TabIndex        =   46
      Text            =   "TYPE"
      Top             =   9720
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   23
      Left            =   120
      TabIndex        =   45
      Text            =   "AE"
      Top             =   8760
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   22
      Left            =   120
      TabIndex        =   44
      Text            =   "DWIN"
      Top             =   11160
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   21
      Left            =   120
      TabIndex        =   43
      Text            =   "DC"
      Top             =   10680
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   20
      Left            =   120
      TabIndex        =   42
      Text            =   "FLEE"
      Top             =   6840
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   17
      Left            =   120
      TabIndex        =   41
      Text            =   "MAPT"
      Top             =   4440
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   15
      Left            =   120
      TabIndex        =   40
      Text            =   "WAPP"
      Top             =   1560
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   39
      Text            =   "RH"
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   5
      Left            =   120
      TabIndex        =   38
      Text            =   "RN"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   24
      Left            =   1200
      TabIndex        =   37
      Text            =   "Give the area elemental, fire in the area, radiation etc... IMMO AE (area elemental) "
      Top             =   8760
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   23
      Left            =   1200
      TabIndex        =   36
      Text            =   "IMMO QUES toggles if this area can be quested to."
      Top             =   10200
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   18
      Left            =   120
      TabIndex        =   35
      Text            =   "QUES"
      Top             =   10200
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   22
      Left            =   1200
      TabIndex        =   34
      Text            =   "IMMO TYPE modifies the zone toggle."
      Top             =   9720
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   21
      Left            =   1200
      TabIndex        =   33
      Text            =   "The following are commands you can use: SLIDe CLIMb MOVE PRESs PULL PUSH SEARch SHOVe"
      Top             =   5880
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   20
      Left            =   1200
      TabIndex        =   32
      Text            =   "Lost the key to the door, no problem, stand in the doorway and run this command."
      Top             =   9240
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   16
      Left            =   120
      TabIndex        =   31
      Text            =   "KEY"
      Top             =   9240
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   19
      Left            =   1200
      TabIndex        =   30
      Text            =   "When you are inside the doorway give it a window IMMO DWIN <value>"
      Top             =   11160
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   18
      Left            =   1200
      TabIndex        =   29
      Text            =   "IMMO MAPT toggles if the MAP command will show the area on the map, the Graphic Map ignores MAPT"
      Top             =   4440
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   28
      Text            =   "RDD/RDN"
      Top             =   3960
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   17
      Left            =   1200
      TabIndex        =   27
      Text            =   "IMMO RDD (text) will make a room day description//IMMO RDN (text) in turn makes the night description."
      Top             =   3960
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   3
      Left            =   120
      TabIndex        =   26
      Text            =   "HEIG"
      Top             =   8280
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   16
      Left            =   1200
      TabIndex        =   25
      Text            =   "IMMO HEIGHT <value> will set the height to the area, value 180 is about 6'1"", 0 toggles area height off."
      Top             =   8280
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   15
      Left            =   1200
      TabIndex        =   24
      Text            =   "TELE outside of an area into the black void, and run this command, then type HELP STA for IMMO STA #"
      Top             =   10680
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   23
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   22
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   1
      Left            =   120
      TabIndex        =   21
      Text            =   "RC"
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   20
      Text            =   "Use TELE X Y Z into the Void then IMMO RC (alone) will create a room where you stand. IMMO RD in turn."
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   19
      Text            =   "IMMO RN (name) will name your room See Also: IMMO MAGIC WORDS and IMMO SECRET SYSTEM WORDS"
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   3
      Left            =   1200
      TabIndex        =   18
      Text            =   "Finish your room with IMMO WAPP or for a new one IMMO WADD, this gives your Area a related theme."
      Top             =   1560
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   4
      Left            =   120
      TabIndex        =   17
      Text            =   "RB"
      Top             =   2040
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   16
      Text            =   "IMMO RB [DIR] [+/-] to open up a direction inside of a created area using the IMMO RC command."
      Top             =   2040
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   15
      Text            =   "IMMO RH [DIR] [+/-] will open a port area like RB does but HIDE it afterwards, so players can move though walls."
      Top             =   2520
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   14
      Text            =   "RH can be unclear to use sometimes, if you get confused use RB and RH to - (close) the direction and try again."
      Top             =   3000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   7
      Left            =   120
      TabIndex        =   13
      Text            =   "RALL"
      Top             =   3480
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   7
      Left            =   1200
      TabIndex        =   12
      Text            =   "IMMO RALL - gets all room information, it will show night and day and  more information for you."
      Top             =   3480
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   8
      Left            =   120
      TabIndex        =   11
      Text            =   "RXYZ"
      Top             =   4920
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   8
      Left            =   1200
      TabIndex        =   10
      Text            =   "IMMO RXYZ makes a room, so if you move into it, you arrive somewhere else. IMMO RTDT toggles this on/off."
      Top             =   4920
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   9
      Left            =   120
      TabIndex        =   9
      Text            =   "RBC"
      Top             =   5400
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   9
      Left            =   1200
      TabIndex        =   8
      Text            =   "IMMO RBC makes sliding walls, IMMO RBCD *DELETESPOT* removes it. See also: HINT player comand."
      Top             =   5400
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   10
      Left            =   120
      TabIndex        =   7
      Text            =   "DDES"
      Top             =   11640
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   10
      Left            =   1200
      TabIndex        =   6
      Text            =   "When in a door-frame you can descript a door by using IMMO DDES (text)"
      Top             =   11640
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   11
      Left            =   1200
      TabIndex        =   5
      Text            =   "SPREad SWINg SPIN SPEAk TOUCh TAP TUG TURN TWISt FIX only four letters are required."
      Top             =   6360
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   12
      Left            =   1200
      TabIndex        =   4
      Text            =   "IMMO FLEE toggles if the player's FLEE command allows them into this area."
      Top             =   6840
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   13
      Left            =   120
      TabIndex        =   3
      Text            =   "RR"
      Top             =   7320
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   13
      Left            =   1200
      TabIndex        =   2
      Text            =   "Areas can have special area roomrules IMMO RR"
      Top             =   7320
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   14
      Left            =   120
      TabIndex        =   1
      Text            =   "DONE"
      Top             =   7800
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   14
      Left            =   1200
      TabIndex        =   0
      Text            =   "IMMO DONE marks the room as finished, and no longer can be edited by lower level immortals."
      Top             =   7800
      Width           =   11000
   End
End
Attribute VB_Name = "frmHelpAdminBuildArea"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
