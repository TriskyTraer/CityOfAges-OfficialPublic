VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmRGBColorPallet 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "RGB Pallet - dblclick the middle of the form to pick a color"
   ClientHeight    =   2565
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   6720
   Icon            =   "frmRGBColorPallet.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2565
   ScaleWidth      =   6720
   Begin VB.CommandButton cmdDefaults 
      Caption         =   "&Defaults"
      Height          =   375
      Left            =   0
      TabIndex        =   20
      Top             =   1800
      Width           =   1215
   End
   Begin VB.CommandButton cmdSave 
      Caption         =   "&Save"
      Height          =   375
      Left            =   0
      TabIndex        =   19
      Top             =   2160
      Width           =   1215
   End
   Begin VB.PictureBox picShowColorBars 
      Align           =   4  'Align Right
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   2565
      Left            =   3705
      ScaleHeight     =   2535
      ScaleWidth      =   2985
      TabIndex        =   1
      Top             =   0
      Width           =   3015
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C0C000&
         Height          =   390
         Index           =   6
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   27
         Text            =   "lite blue"
         Top             =   2160
         Width           =   1095
      End
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00C000C0&
         Height          =   390
         Index           =   5
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   26
         Text            =   "purples"
         Top             =   1800
         Width           =   1095
      End
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00800000&
         Height          =   390
         Index           =   4
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   25
         Text            =   "blues"
         Top             =   1440
         Width           =   1095
      End
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008080&
         Height          =   390
         Index           =   3
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   24
         Text            =   "yellows"
         Top             =   1080
         Width           =   1095
      End
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00008000&
         Height          =   390
         Index           =   2
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   23
         Text            =   "greens"
         Top             =   720
         Width           =   1095
      End
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H008080FF&
         Height          =   390
         Index           =   1
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   22
         Text            =   "reds"
         Top             =   360
         Width           =   1095
      End
      Begin VB.TextBox txtRGBTitle 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00808080&
         Height          =   390
         Index           =   0
         Left            =   1920
         Locked          =   -1  'True
         TabIndex        =   21
         Text            =   "grays"
         Top             =   0
         Width           =   1095
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   6
         Left            =   960
         TabIndex        =   16
         Text            =   "bold"
         Top             =   2160
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   6
         Left            =   0
         TabIndex        =   15
         Text            =   "regular"
         Top             =   2160
         Width           =   975
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   5
         Left            =   960
         TabIndex        =   14
         Text            =   "bold"
         Top             =   1800
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   5
         Left            =   0
         TabIndex        =   13
         Text            =   "regular"
         Top             =   1800
         Width           =   975
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   4
         Left            =   960
         TabIndex        =   12
         Text            =   "bold"
         Top             =   1440
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   4
         Left            =   0
         TabIndex        =   11
         Text            =   "regular"
         Top             =   1440
         Width           =   975
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   3
         Left            =   960
         TabIndex        =   10
         Text            =   "bold"
         Top             =   1080
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   3
         Left            =   0
         TabIndex        =   9
         Text            =   "regular"
         Top             =   1080
         Width           =   975
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   2
         Left            =   960
         TabIndex        =   8
         Text            =   "bold"
         Top             =   720
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   2
         Left            =   0
         TabIndex        =   7
         Text            =   "regular"
         Top             =   720
         Width           =   975
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   1
         Left            =   960
         TabIndex        =   6
         Text            =   "bold"
         Top             =   360
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   1
         Left            =   0
         TabIndex        =   5
         Text            =   "regular"
         Top             =   360
         Width           =   975
      End
      Begin VB.TextBox txtRGBbold 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   0
         Left            =   960
         TabIndex        =   4
         Text            =   "bold"
         Top             =   0
         Width           =   975
      End
      Begin VB.TextBox txtRGBreg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Index           =   0
         Left            =   0
         TabIndex        =   0
         Text            =   "regular"
         Top             =   0
         Width           =   975
      End
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   480
      Top             =   0
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton cmdKeepColors 
      Appearance      =   0  'Flat
      Caption         =   "Push over Color >"
      Height          =   375
      Left            =   2160
      TabIndex        =   3
      Top             =   0
      Width           =   1575
   End
   Begin VB.Label lblProfileIndex 
      Alignment       =   2  'Center
      Caption         =   "#"
      Height          =   255
      Left            =   0
      TabIndex        =   18
      Top             =   0
      Visible         =   0   'False
      Width           =   615
   End
   Begin VB.Label lblIndexbold 
      Alignment       =   2  'Center
      Caption         =   "#"
      Height          =   255
      Left            =   1680
      TabIndex        =   17
      Top             =   0
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.Label lblIndexreg 
      Alignment       =   2  'Center
      Caption         =   "#"
      Height          =   255
      Left            =   1320
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   255
   End
End
Attribute VB_Name = "frmRGBColorPallet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gbllRGBColor As Long
Dim gbllRGBPick As Long
Private Sub basRGBPallet()
   CommonDialog1.CancelError = True ' Set Cancel to True.
On Error GoTo ErrHandler
   CommonDialog1.Flags = cdlCCRGBInit ' Set the Flags property.
   CommonDialog1.ShowColor ' Display the Color dialog box.
   Me.BackColor = CommonDialog1.Color ' Set the form's background color to the selected color.
   Exit Sub
ErrHandler:
   ' User pressed Cancel button.
   Unload frmRGBColorPallet
   Exit Sub
End Sub

Private Sub cmdDefaults_Click()
On Error Resume Next
    subDefaultTerminalColours
    
    txtRGBreg(0).BackColor = gbllreg(30)
    txtRGBreg(1).BackColor = gbllreg(31)
    txtRGBreg(2).BackColor = gbllreg(32)
    txtRGBreg(3).BackColor = gbllreg(33)
    txtRGBreg(4).BackColor = gbllreg(34)
    txtRGBreg(5).BackColor = gbllreg(35)
    txtRGBreg(6).BackColor = gbllreg(36)
    
    txtRGBbold(0).BackColor = gbllbold(30)
    txtRGBbold(1).BackColor = gbllbold(31)
    txtRGBbold(2).BackColor = gbllbold(32)
    txtRGBbold(3).BackColor = gbllbold(33)
    txtRGBbold(4).BackColor = gbllbold(34)
    txtRGBbold(5).BackColor = gbllbold(35)
    txtRGBbold(6).BackColor = gbllbold(36)
    
    MsgBox "You still have to use the Save button to make the default perminant.", vbOKOnly
End Sub

Private Sub cmdKeepColors_Click()
On Error Resume Next
    gbllRGBColor = frmRGBColorPallet.BackColor
    Select Case gbllRGBPick
        Case 1
            txtRGBreg(MyCLng(lblIndexreg.Caption)).BackColor = gbllRGBColor
        Case Else
            txtRGBbold(MyCLng(lblIndexbold.Caption)).BackColor = gbllRGBColor
    End Select
End Sub

Private Sub Form_Activate()
    subWindowsPosition Me, "S"
    lblProfileIndex.Caption = gbllRGBColorPallet
End Sub

Private Sub Form_DblClick()
    basRGBPallet
End Sub

Private Sub basLoad()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lProfileIndex As Long
    
    lblProfileIndex.Caption = gbllRGBColorPallet
    
    lProfileIndex = gbllRGBColorPallet 'this is the TRUE profile index but we translate to our database format below: + 1 to align to the database
    
    DoEvents
    
    Set rsSetUp = MyDB.OpenRecordset("SELECT RGB30fgreg, RGB30fgbold, RGB31fgreg, RGB31fgbold, RGB32fgreg, RGB32fgbold, RGB33fgreg, RGB33fgbold, RGB34fgreg, RGB34fgbold, RGB35fgreg, RGB35fgbold, RGB36fgreg, RGB36fgbold FROM tblProfile WHERE (CharacterNameID=" & (lProfileIndex + 1) & ");", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        gbllreg(30) = MyCStr(rsSetUp!RGB30fgreg)
        gbllreg(31) = MyCStr(rsSetUp!RGB31fgreg)
        gbllreg(32) = MyCStr(rsSetUp!RGB32fgreg)
        gbllreg(33) = MyCStr(rsSetUp!RGB33fgreg)
        gbllreg(34) = MyCStr(rsSetUp!RGB34fgreg)
        gbllreg(35) = MyCStr(rsSetUp!RGB35fgreg)
        gbllreg(36) = MyCStr(rsSetUp!RGB36fgreg)
        'gbllreg(37) = txtRGBreg(7).BackColor
        gbllbold(30) = MyCStr(rsSetUp!RGB30fgbold)
        gbllbold(31) = MyCStr(rsSetUp!RGB31fgbold)
        gbllbold(32) = MyCStr(rsSetUp!RGB32fgbold)
        gbllbold(33) = MyCStr(rsSetUp!RGB33fgbold)
        gbllbold(34) = MyCStr(rsSetUp!RGB34fgbold)
        gbllbold(35) = MyCStr(rsSetUp!RGB35fgbold)
        gbllbold(36) = MyCStr(rsSetUp!RGB36fgbold)
    
        txtRGBreg(0).BackColor = gbllreg(30)
        txtRGBbold(0).BackColor = gbllbold(30)
        txtRGBreg(1).BackColor = gbllreg(31)
        txtRGBbold(1).BackColor = gbllbold(31)
        txtRGBreg(2).BackColor = gbllreg(32)
        txtRGBbold(2).BackColor = gbllbold(32)
        txtRGBreg(3).BackColor = gbllreg(33)
        txtRGBbold(3).BackColor = gbllbold(33)
        txtRGBreg(4).BackColor = gbllreg(34)
        txtRGBbold(4).BackColor = gbllbold(34)
        txtRGBreg(5).BackColor = gbllreg(35)
        txtRGBbold(5).BackColor = gbllbold(35)
        txtRGBreg(6).BackColor = gbllreg(36)
        txtRGBbold(6).BackColor = gbllbold(36)
    End If
    Set rsSetUp = Nothing
    Exit Sub
Err_Check:
    MsgBox "basLoad, ERR#" & Err.Number & vbCrLf & Err.Description, vbOKOnly
End Sub
Private Sub Form_Load()
    subWindowsPosition Me, "L"
    basLoad
End Sub
Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
End Sub

Private Sub txtRGBreg_Click(Index As Integer)
On Error Resume Next
    gbllRGBPick = 1
    lblIndexreg.Caption = MyCStr(Index)
    cmdKeepColors.Top = txtRGBreg(Index).Top
End Sub

Private Sub txtRGBreg_DblClick(Index As Integer)
    basRGBPallet
End Sub

Private Sub txtRGBbold_Click(Index As Integer)
On Error Resume Next
    gbllRGBPick = 2
    lblIndexbold.Caption = MyCStr(Index)
    cmdKeepColors.Top = txtRGBbold(Index).Top
End Sub

Private Sub txtRGBbold_DblClick(Index As Integer)
    basRGBPallet
End Sub

Private Sub cmdSave_Click()
    basSave
End Sub

Private Sub basSave()
On Error GoTo Err_Check
    Dim lProfileIndex As Long
    DoEvents
    'Get the colors off the form
    gbllreg(30) = txtRGBreg(0).BackColor
    gbllreg(31) = txtRGBreg(1).BackColor
    gbllreg(32) = txtRGBreg(2).BackColor
    gbllreg(33) = txtRGBreg(3).BackColor
    gbllreg(34) = txtRGBreg(4).BackColor
    gbllreg(35) = txtRGBreg(5).BackColor
    gbllreg(36) = txtRGBreg(6).BackColor
    'gbllreg(37) = txtRGBreg(7).BackColor
    gbllbold(30) = txtRGBbold(0).BackColor
    gbllbold(31) = txtRGBbold(1).BackColor
    gbllbold(32) = txtRGBbold(2).BackColor
    gbllbold(33) = txtRGBbold(3).BackColor
    gbllbold(34) = txtRGBbold(4).BackColor
    gbllbold(35) = txtRGBbold(5).BackColor
    gbllbold(36) = txtRGBbold(6).BackColor
    'gbllbold(37) = txtRGBbold(7).BackColor
    
    'Save to profile the colors
    lProfileIndex = MyCLng(lblProfileIndex.Caption) 'this is the TRUE profile index but we translate to our database format below: + 1 to align to the database
    MyDB.Execute "UPDATE tblProfile SET RGB30fgreg='" & MyCStr(gbllreg(30)) & "', RGB30fgbold='" & MyCStr(gbllbold(30)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    MyDB.Execute "UPDATE tblProfile SET RGB31fgreg='" & MyCStr(gbllreg(31)) & "', RGB31fgbold='" & MyCStr(gbllbold(31)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    MyDB.Execute "UPDATE tblProfile SET RGB32fgreg='" & MyCStr(gbllreg(32)) & "', RGB32fgbold='" & MyCStr(gbllbold(32)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    MyDB.Execute "UPDATE tblProfile SET RGB33fgreg='" & MyCStr(gbllreg(33)) & "', RGB33fgbold='" & MyCStr(gbllbold(33)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    MyDB.Execute "UPDATE tblProfile SET RGB34fgreg='" & MyCStr(gbllreg(34)) & "', RGB34fgbold='" & MyCStr(gbllbold(34)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    MyDB.Execute "UPDATE tblProfile SET RGB35fgreg='" & MyCStr(gbllreg(35)) & "', RGB35fgbold='" & MyCStr(gbllbold(35)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    MyDB.Execute "UPDATE tblProfile SET RGB36fgreg='" & MyCStr(gbllreg(36)) & "', RGB36fgbold='" & MyCStr(gbllbold(36)) & "' WHERE CharacterNameID=" & (lProfileIndex + 1) & ";", dbFailOnError
    Exit Sub
Err_Check:
    MsgBox "basSave, ERR#" & Err.Number & vbCrLf & Err.Description, vbOKOnly
End Sub

Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
