VERSION 5.00
Begin VB.Form frmHelpAdminBuildObjects 
   Appearance      =   0  'Flat
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "ADMINISTRATION IMMORTAL SKILLS - OBJECTS"
   ClientHeight    =   13680
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12285
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   11.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpAdminBuildObjects.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   13680
   ScaleWidth      =   12285
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   59
      Left            =   1200
      TabIndex        =   71
      Text            =   "FORGE VL <value> forges a visible player level to the item, use FORGE LOCA 0 afterwards then drop the item."
      Top             =   11160
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   70
      Text            =   "VL"
      Top             =   11160
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   58
      Left            =   1200
      TabIndex        =   69
      Text            =   "121=bonus xp item"
      Top             =   9240
      Width           =   2535
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   57
      Left            =   10920
      TabIndex        =   68
      Text            =   "120=money"
      Top             =   8760
      Width           =   1275
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   56
      Left            =   9480
      TabIndex        =   67
      Text            =   "100=earlobes"
      Top             =   8760
      Width           =   1455
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   55
      Left            =   7800
      TabIndex        =   66
      Text            =   "90=boots"
      Top             =   8760
      Width           =   1695
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   54
      Left            =   6120
      TabIndex        =   65
      Text            =   "85=shoulders"
      Top             =   8760
      Width           =   1740
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   49
      Left            =   3720
      TabIndex        =   64
      Text            =   "84=over a shoulder"
      Top             =   8760
      Width           =   2415
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   47
      Left            =   1200
      TabIndex        =   63
      Text            =   "83=waist"
      Top             =   8760
      Width           =   2535
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   53
      Left            =   10920
      TabIndex        =   62
      Text            =   "82=hips"
      Top             =   8280
      Width           =   1275
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   52
      Left            =   9480
      TabIndex        =   61
      Text            =   "81=mid-back"
      Top             =   8280
      Width           =   1455
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   51
      Left            =   7800
      TabIndex        =   60
      Text            =   "80=middle back"
      Top             =   8280
      Width           =   1695
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   50
      Left            =   6480
      TabIndex        =   59
      Text            =   "73=cloaks"
      Top             =   8280
      Width           =   1380
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   48
      Left            =   3720
      TabIndex        =   58
      Text            =   "72=chest insignia"
      Top             =   8280
      Width           =   2770
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   46
      Left            =   1200
      TabIndex        =   57
      Text            =   "71=broach"
      Top             =   8280
      Width           =   2535
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   45
      Left            =   10920
      TabIndex        =   56
      Text            =   "70=torso"
      Top             =   7800
      Width           =   1275
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   44
      Left            =   9480
      TabIndex        =   55
      Text            =   "63=elbows"
      Top             =   7800
      Width           =   1455
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   43
      Left            =   7800
      TabIndex        =   54
      Text            =   "62=knees"
      Top             =   7800
      Width           =   1695
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   42
      Left            =   6480
      TabIndex        =   53
      Text            =   "61=ankles"
      Top             =   7800
      Width           =   1380
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   41
      Left            =   5160
      TabIndex        =   52
      Text            =   "60=legs"
      Top             =   7800
      Width           =   1330
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   40
      Left            =   3720
      TabIndex        =   51
      Text            =   "50=forearms"
      Top             =   7800
      Width           =   1500
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   39
      Left            =   2160
      TabIndex        =   50
      Text            =   "45=upper arms"
      Top             =   7800
      Width           =   1580
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   38
      Left            =   1200
      TabIndex        =   49
      Text            =   "41=cuff"
      Top             =   7800
      Width           =   980
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   37
      Left            =   10920
      TabIndex        =   48
      Text            =   "40=wrist"
      Top             =   7320
      Width           =   1280
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   36
      Left            =   9480
      TabIndex        =   47
      Text            =   "33=nose ring"
      Top             =   7320
      Width           =   1455
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   35
      Left            =   1200
      TabIndex        =   46
      Text            =   "23=poker cards, see also MERGE"
      Top             =   7320
      Width           =   3495
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   24
      Left            =   9480
      TabIndex        =   45
      Text            =   "22=gauntlets/mits"
      Top             =   6840
      Width           =   2720
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   20
      Left            =   8280
      TabIndex        =   44
      Text            =   "21=buckler"
      Top             =   6840
      Width           =   1215
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   10
      Left            =   1200
      TabIndex        =   43
      Text            =   "Sheilds also are hands items and just have armour class, some monks like to carry two shields for extra-armour."
      Top             =   10680
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   34
      Left            =   7800
      TabIndex        =   42
      Text            =   "32=tongue stud"
      Top             =   7320
      Width           =   1695
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   33
      Left            =   6480
      TabIndex        =   41
      Text            =   "31=thumbs"
      Top             =   7320
      Width           =   1335
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   32
      Left            =   4680
      TabIndex        =   40
      Text            =   "30=fingers, rings"
      Top             =   7320
      Width           =   1815
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   19
      Left            =   1200
      TabIndex        =   39
      Text            =   "All items can have HitRoll chance, DamageRoll chance, ArmourClass and HitPoints weapons have bonus dmg."
      Top             =   10200
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   15
      Left            =   1200
      TabIndex        =   38
      Text            =   "20=hands item, except for monks you want to also FORGE TYPE to these items to make it a valid weapon"
      Top             =   9720
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   31
      Left            =   6840
      TabIndex        =   37
      Text            =   "19=over eyes"
      Top             =   6840
      Width           =   1455
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   30
      Left            =   5760
      TabIndex        =   36
      Text            =   "18=mask"
      Top             =   6840
      Width           =   1095
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   29
      Left            =   3960
      TabIndex        =   35
      Text            =   "17=inside mouth"
      Top             =   6840
      Width           =   1815
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   28
      Left            =   2400
      TabIndex        =   34
      Text            =   "16=over mouth"
      Top             =   6840
      Width           =   1575
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   26
      Left            =   1200
      TabIndex        =   33
      Text            =   "15=amulet"
      Top             =   6840
      Width           =   1215
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   16
      Left            =   10800
      TabIndex        =   32
      Text            =   "14=pendant"
      Top             =   6360
      Width           =   1400
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   14
      Left            =   9480
      TabIndex        =   31
      Text            =   "13=talisman"
      Top             =   6360
      Width           =   1335
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   13
      Left            =   7920
      TabIndex        =   30
      Text            =   "12=necklaces"
      Top             =   6360
      Width           =   1575
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   12
      Left            =   6840
      TabIndex        =   29
      Text            =   "11=collar"
      Top             =   6360
      Width           =   1095
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   25
      Left            =   5160
      TabIndex        =   28
      Text            =   "10=hats/helmut"
      Top             =   6360
      Width           =   1695
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   27
      Left            =   3480
      TabIndex        =   27
      Text            =   "9=forehead item"
      Top             =   6360
      Width           =   1695
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   24
      Left            =   120
      TabIndex        =   26
      Text            =   "OD"
      Top             =   2040
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   23
      Left            =   120
      TabIndex        =   25
      Text            =   "EQUI"
      Top             =   12600
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   17
      Left            =   120
      TabIndex        =   24
      Text            =   "OLOC"
      Top             =   5880
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   15
      Left            =   120
      TabIndex        =   23
      Text            =   "CONT"
      Top             =   1560
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   22
      Text            =   "OTCF"
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   5
      Left            =   120
      TabIndex        =   21
      Text            =   "FORGE"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   23
      Left            =   1200
      TabIndex        =   20
      Text            =   "IMMO WEAP will show you the item types and numbers in the system, gives you an idea what to work on."
      Top             =   13080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   18
      Left            =   120
      TabIndex        =   19
      Text            =   "WEAP"
      Top             =   13080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   22
      Left            =   1200
      TabIndex        =   18
      Text            =   "IMMO EQUI gives you an idea what equipment exists in the realm, gives you an idea what to work on next."
      Top             =   12600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   21
      Left            =   1200
      TabIndex        =   17
      Text            =   "IMMO OLOC tongue stud, is piercing|32 -or- FORGE LOCA 32 will lock this item to location 32, the tongue"
      Top             =   5880
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   18
      Left            =   1200
      TabIndex        =   16
      Text            =   "SBLA for example are daggers, LBLA is a longsword, BLUD is a mace/bat, TALO a clawed item, POLE polearm"
      Top             =   4440
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   17
      Left            =   1200
      TabIndex        =   15
      Text            =   "PHAS, MGUN, BLUD, FLEX. ARRO, BOLT, STON, CLIP, BLAS are all the Weapon Types you can select from."
      Top             =   3960
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   14
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   13
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   1
      Left            =   120
      TabIndex        =   12
      Text            =   "OC"
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   11
      Text            =   "IMMO OC <objectname, objectshortdescription> this will create a object to your inventory."
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   10
      Text            =   "FORGE is a command for players and immortals. except an immortal can use this anywhere for free."
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   3
      Left            =   1200
      TabIndex        =   9
      Text            =   "If you make two objects, one will turn into a container and the other will become the container item to the area."
      Top             =   1560
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   8
      Text            =   "IMMO OD (full object name) to delete this object from an immortal's inventory."
      Top             =   2040
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   7
      Text            =   "IMMO OCTF will toggle an objects color."
      Top             =   2520
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   6
      Left            =   120
      TabIndex        =   6
      Text            =   "OTYP"
      Top             =   3000
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   5
      Text            =   "IMMO OTYP will set the objects Weapon type. MFORGE TYPE (SBLA,LBLA,NET...) works the same."
      Top             =   3000
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   7
      Left            =   1200
      TabIndex        =   4
      Text            =   "SBLA, LBLA, PUGI, TALO, POLE, NET, SAXE, GAXE, JAVI, SPEA, BOW, XBOW, SLIN, LANC"
      Top             =   3480
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   8
      Left            =   1200
      TabIndex        =   3
      Text            =   "PUGI are whips, chains, modified knuckle busters"
      Top             =   4920
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   9
      Left            =   120
      TabIndex        =   2
      Text            =   "OAVG"
      Top             =   5400
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   9
      Left            =   1200
      TabIndex        =   1
      Text            =   "IMMO OAVG will set the objects average damage, FORGE # DR works the same."
      Top             =   5400
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   11
      Left            =   1200
      TabIndex        =   0
      Text            =   "8=translation item"
      Top             =   6360
      Width           =   2295
   End
End
Attribute VB_Name = "frmHelpAdminBuildObjects"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
