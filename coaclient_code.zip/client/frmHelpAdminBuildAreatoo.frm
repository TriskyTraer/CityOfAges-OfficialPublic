VERSION 5.00
Begin VB.Form frmHelpAdminBuildAreaToo 
   Appearance      =   0  'Flat
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   " ADMINISTRATION IMMORTAL SKILLS - AREAS and DOORS - more"
   ClientHeight    =   13680
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12285
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   11.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpAdminBuildAreatoo.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   13680
   ScaleWidth      =   12285
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   11
      Text            =   "IMMO COLONIST will make an existing [IMMO RC] area a colonizable area using SS DROP command."
      Top             =   3000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   10
      Text            =   "COLONIST"
      Top             =   3000
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   9
      Text            =   "HOUSE"
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   5
      Left            =   120
      TabIndex        =   8
      Text            =   "TYPE"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   7
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   6
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   1
      Left            =   120
      TabIndex        =   5
      Text            =   "WHOIS"
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   4
      Text            =   "If you are an admin and need your Player ID type WHOIS alone. You can also WHOIS <playername>"
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   3
      Text            =   "How to Build a House for a player: IMMO TYPE 1 <PlayerID> will set an area for a house."
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   3
      Left            =   1200
      TabIndex        =   2
      Text            =   "Use IMMO RDD and IMMO RDN and IMMO WAPP to descript your house first because TYPE will lock down the"
      Top             =   1560
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   1
      Text            =   "area. You can also use IMMO TYPE by itself to clear and area and return it to a normal area."
      Top             =   2040
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   0
      Text            =   "This is the fast easy strait forward way to make a house. IMMO HOUSE <playername>"
      Top             =   2520
      Width           =   11000
   End
End
Attribute VB_Name = "frmHelpAdminBuildAreaToo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
