VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmMain 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "City of Ages - Terminal Emulator"
   ClientHeight    =   9195
   ClientLeft      =   45
   ClientTop       =   750
   ClientWidth     =   12780
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00404040&
   Icon            =   "frmMain.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   613
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   852
   Begin VB.PictureBox picGoldAnimation 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   3735
      Index           =   2
      Left            =   2640
      Picture         =   "frmMain.frx":0442
      ScaleHeight     =   3705
      ScaleWidth      =   5265
      TabIndex        =   7
      Top             =   120
      Visible         =   0   'False
      Width           =   5295
      Begin VB.Timer tmrGoldAnimation 
         Enabled         =   0   'False
         Index           =   2
         Interval        =   1500
         Left            =   120
         Top             =   840
      End
   End
   Begin VB.Timer tmrEventPause 
      Enabled         =   0   'False
      Interval        =   500
      Left            =   720
      Top             =   0
   End
   Begin MSWinsockLib.Winsock Winsock1 
      Left            =   0
      Top             =   0
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin VB.Timer timCursor 
      Interval        =   500
      Left            =   360
      Top             =   0
   End
   Begin VB.Frame frameConnection 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   330
      Left            =   75
      TabIndex        =   2
      Top             =   8880
      Width           =   12900
      Begin VB.TextBox txtSendClientData 
         Appearance      =   0  'Flat
         BackColor       =   &H00000000&
         CausesValidation=   0   'False
         BeginProperty Font 
            Name            =   "Verdana"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   360
         Left            =   120
         MaxLength       =   255
         TabIndex        =   0
         ToolTipText     =   "DblClick to enlarge // semi-colons to send multi-commands: say hello;wave;bow"
         Top             =   0
         Width           =   12525
      End
      Begin VB.Line drawCharacterFound 
         BorderColor     =   &H00008000&
         BorderWidth     =   5
         Visible         =   0   'False
         X1              =   25
         X2              =   25
         Y1              =   360
         Y2              =   0
      End
   End
   Begin VB.PictureBox picTerm 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BeginProperty Font 
         Name            =   "Verdana"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   8775
      Left            =   120
      ScaleHeight     =   583
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   839
      TabIndex        =   1
      Top             =   120
      Width           =   12615
      Begin VB.PictureBox picGoldAnimation 
         Appearance      =   0  'Flat
         BackColor       =   &H00000000&
         ForeColor       =   &H80000008&
         Height          =   3735
         Index           =   1
         Left            =   2640
         Picture         =   "frmMain.frx":541A8
         ScaleHeight     =   3705
         ScaleWidth      =   5145
         TabIndex        =   6
         Top             =   0
         Visible         =   0   'False
         Width           =   5175
         Begin VB.Timer tmrGoldAnimation 
            Enabled         =   0   'False
            Index           =   1
            Interval        =   1500
            Left            =   0
            Top             =   0
         End
      End
      Begin VB.PictureBox picGoldAnimation 
         Appearance      =   0  'Flat
         BackColor       =   &H00000000&
         ForeColor       =   &H80000008&
         Height          =   3735
         Index           =   0
         Left            =   2640
         Picture         =   "frmMain.frx":AC8E2
         ScaleHeight     =   3705
         ScaleWidth      =   5145
         TabIndex        =   5
         Top             =   0
         Visible         =   0   'False
         Width           =   5175
         Begin VB.Timer tmrGoldAnimation 
            Enabled         =   0   'False
            Index           =   0
            Interval        =   600
            Left            =   0
            Top             =   0
         End
      End
      Begin VB.Timer tmrTriggerPause 
         Enabled         =   0   'False
         Interval        =   500
         Left            =   240
         Top             =   960
      End
      Begin VB.Timer tmrSoundReset 
         Interval        =   32000
         Left            =   240
         Top             =   600
      End
      Begin VB.Timer tmrTurnOffVoiceOver 
         Interval        =   30000
         Left            =   240
         Top             =   240
      End
      Begin VB.PictureBox picEventTriggered 
         Appearance      =   0  'Flat
         BackColor       =   &H00404040&
         ForeColor       =   &H80000008&
         Height          =   3000
         Left            =   0
         ScaleHeight     =   2970
         ScaleWidth      =   4470
         TabIndex        =   3
         Top             =   0
         Visible         =   0   'False
         Width           =   4500
         Begin VB.Timer tmrWARPENGAGED 
            Enabled         =   0   'False
            Interval        =   2000
            Left            =   720
            Top             =   840
         End
         Begin VB.Timer tmrEventTriggered 
            Interval        =   20000
            Left            =   3240
            Top             =   0
         End
         Begin VB.Label lblEventTriggered 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H00808080&
            BackStyle       =   0  'Transparent
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   12
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H00C0FFFF&
            Height          =   615
            Left            =   0
            TabIndex        =   4
            ToolTipText     =   "The EventTriggered label and picbox are loaded from Events."
            Top             =   0
            Visible         =   0   'False
            Width           =   4095
         End
      End
   End
   Begin VB.Menu mnuMain 
      Caption         =   "Play"
      WindowList      =   -1  'True
      Begin VB.Menu mnuMainCD 
         Caption         =   "Connect"
      End
      Begin VB.Menu mnuRecordTextfileEventLine 
         Caption         =   "Record Textfile Event Line"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuAnimation 
         Caption         =   "Animation"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuSound 
         Caption         =   "Sound"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuSoundStoryLine 
         Caption         =   "Sound - Story Line"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuSoundBackground 
         Caption         =   "Sound - Background"
         Checked         =   -1  'True
      End
   End
   Begin VB.Menu mnuGame 
      Caption         =   "Game"
      Begin VB.Menu mnuNumlock 
         Caption         =   "Speed Numlock"
      End
      Begin VB.Menu mnuJoystickPackman 
         Caption         =   "Joystick Packmon"
      End
      Begin VB.Menu mnuForgeCommander 
         Caption         =   "Forge Commander"
      End
      Begin VB.Menu mnuFleetCommander 
         Caption         =   "Fleet Commander"
      End
      Begin VB.Menu mnuCharacterCommander 
         Caption         =   "Character Commander"
      End
   End
   Begin VB.Menu mnuCaptain 
      Caption         =   "Captain"
      Begin VB.Menu mnuMemos 
         Caption         =   "Notes and Memos"
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuCreatorMapperStatus 
         Caption         =   "Mapper Logging Active..."
      End
      Begin VB.Menu mnuNavigation 
         Caption         =   "Navigation"
         Begin VB.Menu mnuStarmap 
            Caption         =   "Starmap"
         End
         Begin VB.Menu mnuMapEventLocation 
            Caption         =   "Event Map"
         End
         Begin VB.Menu mnuMapper 
            Caption         =   "Mapper"
            Shortcut        =   ^M
         End
         Begin VB.Menu mnuMapperAutoFocus 
            Caption         =   "Mapper Auto Focus"
            Checked         =   -1  'True
            Visible         =   0   'False
         End
         Begin VB.Menu mnuMapperTimerActive 
            Caption         =   "Mapper Timer Active..."
            Checked         =   -1  'True
            Visible         =   0   'False
         End
      End
   End
   Begin VB.Menu mnuScreenUtilities 
      Caption         =   "Screen Utilities"
      Begin VB.Menu mnuAGViewer 
         Caption         =   "Graphic Viewers"
         Shortcut        =   ^{F9}
      End
      Begin VB.Menu mnuPMGraphicsEditor 
         Caption         =   "Graphics Editor"
      End
      Begin VB.Menu mnuShowFileNames 
         Caption         =   "Show File Names"
      End
      Begin VB.Menu mnuLargeMessageBox 
         Caption         =   "Large Message Box"
         Shortcut        =   ^A
      End
      Begin VB.Menu mnuChangeFont 
         Caption         =   "Change Font"
      End
      Begin VB.Menu mnuFontTweeker 
         Caption         =   "Font Tweeker"
         Visible         =   0   'False
      End
   End
   Begin VB.Menu mnuCreator 
      Caption         =   "Creator"
      Begin VB.Menu mnuCharacterProfiles 
         Caption         =   "Character Profiles"
         Shortcut        =   ^P
      End
      Begin VB.Menu mnuCharacterEvents 
         Caption         =   "Events and Background sound"
         Shortcut        =   ^E
      End
      Begin VB.Menu mnuEventsToggle 
         Caption         =   "Events Toggle"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuScaling 
         Caption         =   "Aliases and Macros"
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuCharacterTriggers 
         Caption         =   "Triggers and Speedwalk"
         Shortcut        =   ^T
      End
      Begin VB.Menu mnuButtons 
         Caption         =   "Buttons"
         Shortcut        =   ^B
      End
      Begin VB.Menu mnuEditVoiceLocationTriggers 
         Caption         =   "Edit Voice Location Triggers"
      End
   End
   Begin VB.Menu mnuTimers 
      Caption         =   "Timers"
      Begin VB.Menu mnuCreatorTickerA 
         Caption         =   "Ticker 2s sends"
         Shortcut        =   ^{F1}
      End
      Begin VB.Menu mnuCreatorTickerB 
         Caption         =   "Ticker 5s sends"
         Shortcut        =   ^{F2}
      End
      Begin VB.Menu mnuMDITickerC 
         Caption         =   "Ticker 7s sends"
         Shortcut        =   ^{F3}
      End
      Begin VB.Menu mnuMDITickerD 
         Caption         =   "Ticker 10s sends"
         Shortcut        =   ^{F4}
      End
      Begin VB.Menu mnuMDITickerE 
         Caption         =   "Ticker 14s sends"
         Shortcut        =   ^{F5}
      End
      Begin VB.Menu mnuMDITickerF 
         Caption         =   "Ticker 19s sends"
         Shortcut        =   ^{F6}
      End
   End
   Begin VB.Menu mnuTimerDynamic1 
      Caption         =   "Timer Dynamic1"
   End
   Begin VB.Menu mnuTimerDynamic2 
      Caption         =   "Timer Dynamic2"
   End
   Begin VB.Menu mnuTimerDynamic3 
      Caption         =   "Timer Dynamic3"
   End
   Begin VB.Menu mnuTools 
      Caption         =   "Tools"
      Begin VB.Menu mnuChangePortAddress 
         Caption         =   "Change Port Address"
      End
      Begin VB.Menu mnuRunInstance 
         Caption         =   "Run an Additional Instance of CoA Client"
      End
      Begin VB.Menu mnuScrollBack 
         Caption         =   "Scroll Back (ESC cancels, use arrow keys not numlock)"
         Shortcut        =   %{BKSP}
      End
      Begin VB.Menu mnuBlackSheet 
         Caption         =   "Black Sheet"
      End
   End
   Begin VB.Menu mnuInstructions 
      Caption         =   "Instructions"
      Begin VB.Menu mnuHowTo 
         Caption         =   "GAME - Tips when Playing"
      End
      Begin VB.Menu mnuHelpPlayerCommands 
         Caption         =   "Player Commands"
      End
      Begin VB.Menu mnuHelpPlayerCommandsToo 
         Caption         =   "Player Commands - more"
      End
      Begin VB.Menu mnuPlayerCommandsThree 
         Caption         =   "Player Commands - even more"
      End
      Begin VB.Menu mnuHelpAdminSkillsToo 
         Caption         =   "Admin Commands"
      End
      Begin VB.Menu mnuAdminBldCmds 
         Caption         =   "Give Yourself Admin Building Commands"
      End
      Begin VB.Menu mnuHelpAdminBuildAreas 
         Caption         =   "Admin Build Areas and Door Commands"
      End
      Begin VB.Menu mnuHelpAdminBuildAreasToo 
         Caption         =   "Admin Build Areas and Door Commands - more"
      End
      Begin VB.Menu mnuHelpAdminBuildMob 
         Caption         =   "Admin Mob Build Commands"
      End
      Begin VB.Menu mnuHelpAdminBuildObject 
         Caption         =   "Admin Object Build Commands"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "Help"
      Begin VB.Menu mnuHelpPortForward 
         Caption         =   "How to Port Forward"
      End
      Begin VB.Menu mnuTurnOnTelnet 
         Caption         =   "Turn Windows Telnet On"
      End
      Begin VB.Menu mnuHelpRedErrNos 
         Caption         =   "Server has Red Error numbers"
      End
      Begin VB.Menu mnuHelpServerStalls 
         Caption         =   "Server Stalls or Randomly Not Responding"
      End
      Begin VB.Menu mnuAbout 
         Caption         =   "About"
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'http://www.vbcorner.net/download_icons.htm   for vb6 icons
'Nice little Error trap routien
'On Error GoTo Err_Check
'    Exit Sub
'Err_Check:
'    MsgBox "subSaveTrigger," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
Public bTriedTriggers As Boolean
Public lStatusBarUsed As Long
Const cstStatusBarUsed = 75 'works with lStatusBarUsed, when datawinsock arrivals check with this constant value to shutoff config prompt with our clients status bar
Const cstbSoundLog = False 'Winsock1_DataArrival(ByVal bytesTotal As Long) and TermProcessInput are where the magic happens
Dim lListScan As Long
Public Sub subSetFrames()
On Error Resume Next
    Dim lPTW As Long
    Dim lPTH As Long
    Dim lPicTermHeight As Long
    Dim lFrmConnHeight As Long
    lPicTermHeight = frmMain.picTerm.height
    lFrmConnHeight = frmMain.frameConnection.height
    If (bgblLapTopMode) Then
        lPicTermHeight = (frmMain.picTerm.height / 2) + 21
        lFrmConnHeight = (frmMain.frameConnection.height / 2) + 6
    End If
    
    lPTW = (picTerm.width * Screen.TwipsPerPixelX)
    lPTH = (lPicTermHeight * Screen.TwipsPerPixelY)
    frmMain.frameConnection.Top = lPicTermHeight
    frmMain.frameConnection.width = lPTW
    frmMain.frameConnection.height = (frmMain.txtSendClientData.height / Screen.TwipsPerPixelY) + 6 'frmMain.txtSendClientData.height + 2
    frmMain.txtSendClientData.width = lPTW - 250
    frmMain.txtSendClientData.Top = lFrmConnHeight
    frmMain.width = lPTW + 50
    frmMain.height = (lPicTermHeight * Screen.TwipsPerPixelY) + (lFrmConnHeight * Screen.TwipsPerPixelY) + 500
End Sub
Private Sub subClearTerminal()
    Dim X As Integer
    Dim Y As Integer
    For Y = 0 To gbllMaxHeightChars 'we clear 0 to 79 and all 50 rows up and down
        For X = 0 To gblcstiTerminalWidthMAX
            With TerminalChar(Y, X)
                .BackColor = 0
                .Blink = 0
                .Bold = 0
                .ForeColor = 13
                .Invisible = False
                .Reverse = False
                .Text = 32
                .Underline = False
            End With
        Next
    Next
    'Terminal.Refresh
End Sub
Private Sub subMouseWheelUse(lRotation As Long)
    Dim lCount1 As Long
    Dim lCount2 As Long
    Dim zLine As String
    Dim DataLength As Long
    Dim lMAX As Long
    Dim iSaveCursorX As Integer
    Dim iSaveCursorY As Integer
    Dim lController As Long
    If (bgblLapTopMode) Then
        lController = 1
    Else
        lController = 4
    End If
    iSaveCursorX = Cursor.X
    Cursor.X = 0
    iSaveCursorY = Cursor.Y
    Cursor.Y = 0
    
    subClearTerminal
    
    If (lRotation < 0) Then
        gbllTerminalScrollBACKPointer = gbllTerminalScrollBACKPointer - lController
    Else
        gbllTerminalScrollBACKPointer = gbllTerminalScrollBACKPointer + lController
    End If

    If (bgblLapTopMode) Then
        If (gbllTerminalScrollBACKPointer + (MyCLng(cstlMaxHeightChars / 2)) > gbllTerminalScrollMAX) Then gbllTerminalScrollBACKPointer = gbllTerminalScrollMAX - (MyCLng(cstlMaxHeightChars / 2))
        If (gbllTerminalScrollBACKPointer < 1) Then gbllTerminalScrollBACKPointer = 1
    Else
        If (gbllTerminalScrollBACKPointer + cstlMaxHeightChars > gbllTerminalScrollMAX) Then gbllTerminalScrollBACKPointer = gbllTerminalScrollMAX - cstlMaxHeightChars
        If (gbllTerminalScrollBACKPointer < 1) Then gbllTerminalScrollBACKPointer = 1
    End If

    If (bgblLapTopMode) Then
        lMAX = gbllTerminalScrollBACKPointer + MyCLng(cstlMaxHeightChars / 2)
    Else
        lMAX = gbllTerminalScrollBACKPointer + cstlMaxHeightChars
    End If
    If (lMAX > gbllTerminalScrollMAX) Then lMAX = gbllTerminalScrollMAX
    lMAX = lMAX - 1 'the bottom maybe feeding back on us
    
    For lCount1 = gbllTerminalScrollBACKPointer To lMAX
        zLine = gblzTerminalScroll(lCount1) & vbCrLf
        DataLength = Len(zLine) 'this can be over 80 total chars with color codes
        For lCount2 = 1 To DataLength
            Call TermProcessInput(CByte(Asc(Mid(zLine, lCount2, 1))))
        Next
    Next lCount1
    
    Cursor.X = iSaveCursorX
    Cursor.Y = iSaveCursorY
End Sub
Public Sub MouseWheel(ByVal MouseKeys As Long, ByVal Rotation As Long, ByVal Xpos As Long, ByVal Ypos As Long)
'This procedure needs to exist even if it doesnt do anything
    subMouseWheelUse Rotation
End Sub

Public Sub Disconnect() 'Disconnect from remote host
    mnuMainCD.Caption = "Connect"
    mdiMain!picStatsBox.Visible = False
    gblbStatsBox = False
    frmMain.Winsock1.Close
    frmMain.timCursor.Enabled = False
    Call TermFreeMemory
End Sub

Public Sub subRewriteLastBitToWindow()
    Dim lCount1 As Long
    Dim lCount2 As Long
    Dim zLine As String
    Dim DataLength As Long
    Dim lMIN As Long
    Dim lMAX As Long
    Dim iSaveCursorX As Integer
    Dim iSaveCursorY As Integer

    iSaveCursorX = Cursor.X
    Cursor.X = 0
    iSaveCursorY = Cursor.Y
    Cursor.Y = 0

    subClearTerminal
    
    lMIN = gbllTerminalScrollMAX - cstlMaxHeightChars
    If (lMIN < 1) Then lMIN = 1
    lMAX = gbllTerminalScrollMAX
    
    For lCount1 = lMIN To lMAX
        zLine = gblzTerminalScroll(lCount1) & vbCrLf
        DataLength = Len(zLine)
        For lCount2 = 1 To DataLength
            Call TermProcessInput(CByte(Asc(Mid(zLine, lCount2, 1))))
        Next
    Next lCount1
    
    Cursor.X = iSaveCursorX
    Cursor.Y = iSaveCursorY
End Sub
Private Function bReturnGetKeyState(iKeyCode As Integer) As Boolean
    bReturnGetKeyState = (iKeyCode = -127 Or iKeyCode = -128) '(iKeyCode <> 0)
End Function
Private Sub mnuAnimation_Click()
    mnuAnimation.Checked = Not mnuAnimation.Checked
    gblbAnimation = Not gblbAnimation
End Sub
Private Sub mnuCharacterCommander_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmCharacterWindow
        frmCharacterWindow.Show
    End If
End Sub
Private Sub mnuMapEventLocation_Click()
    gblbMapEventLocationHumanRan = True
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmMapEventLocation
        frmMapEventLocation.Show
    End If
End Sub
Private Sub mnuFleetCommander_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmFleetWindow
        frmFleetWindow.Show
    End If
End Sub
Private Sub mnuFontTweeker_Click()
    frmFontTweeker.Show
End Sub
Private Sub mnuForgeCommander_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmForgeWindow
        frmForgeWindow.Show
    End If
End Sub

Private Sub mnuJoystickPackman_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmJoystickPackman
        frmJoystickPackman.Show
    End If
End Sub

Private Sub mnuNumlock_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmNumlock
        frmNumlock.Show
    End If
End Sub
Private Sub Form_Activate()
On Error Resume Next
    gblbCharacterNameIDOverride = True
    lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN)
    lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN)
    'Screen Mode: MsgBox lgblScreenWidth & " " & lgblScreenHeight
    
    gbllFormActivated = 12
    subWindowsPosition Me, "S"
    frmMain.txtSendClientData.SetFocus
    subProgramName
End Sub

Private Sub Form_Click()
On Error Resume Next
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub Form_Deactivate()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
On Error Resume Next
    subResetEventPicbox
    
    basFormLoad
    gblEventsToggle = True
    mdiMain.subLoadMDIButtons
End Sub
Private Sub mnuStarmap_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmMapStars
        frmMapStars.Show
    End If
End Sub
Private Sub picEventTriggered_DblClick()
    subClosedownEventPicbox
End Sub
Private Sub tmrEventTriggered_Timer() 'every 10 seconds we hide this window if it needs to or not
On Error Resume Next
    If (gbllEventTriggered > 0) Then
        gbllEventTriggered = gbllEventTriggered - 1
        Select Case gbllEventTriggered
            Case 1
                subClosedownEventPicbox
            Case Else
                If (frmMain!picEventTriggered.Left = 0) Then
                    frmMain!picEventTriggered.Left = frmMain!picEventTriggered.width + 15
                Else
                    frmMain!picEventTriggered.Left = 0
                End If
        End Select
    Else
        subResetEventPicbox
    End If
End Sub
Public Sub basFormLoad()
On Error Resume Next
    gblbSoundAllowed = True
    gblbSoundStoryLine = True
    gblbVoiceLorePlaying = False
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "L"
    mnuMapperAutoFocus.Checked = False
    gbllMapperAutoFocus = mnuMapperAutoFocus.Checked
    gbllMapperStatus = mnuCreatorMapperStatus.Checked
    gbllMapperTimerStatus = mnuMapperTimerActive.Checked
    gblbRecordTextfileEventLine = mnuRecordTextfileEventLine.Checked
    
    gblbTerminalScrolling = False
    frmMain.KeyPreview = True 'so the form's keyboard evens are checked before the form control keyboard events are checked
    'Call WheelHook(frmMain.hWnd)
    gbllEventOffTimer = 0
    
    gblbfrmMainAllowShutdown = True
    If (frmMain.Winsock1.State <> 7) Then '7 = connected
        frmMain.Caption = "City of Ages Terminal Emulator"
        frmMain.drawCharacterFound.Visible = False
        bPlayerNameRequired = True
    End If
    gblbEquipmentStart = False
    gblbInventoryStart = False
    gblbScorecardStart = False
    gblbSlistStart = False
    gblbTreesStart = False
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
    Close #iFileNo 'If (gblbRecordTextfileEventLine) Then
    If (FileLen(zFileNoName) < 4500) Then
        SetAttr zFileNoName, vbNormal
        Kill zFileNoName ' Then delete the file
    End If
    
    MyDB.Execute "UPDATE tblProfile SET MapperSizeType='" & MyCStr(UCase(gblzMapSizeType)) & "' WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbFailOnError

    'we test for track sounds left
    'If (cstbSoundLog) Then subSoundResultsLog

    subMCIStopPlayer
    subEnforceNumLock "OFF"
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
    MyDB.Execute "UPDATE tblWindows SET WindowMoved='A';", dbFailOnError
    
    DoEvents
    
    If (gblbfrmMainAllowShutdown) Then
        Call Disconnect
        DoEvents
        subCompactNRepair 'this closes the database link down as well
        End
    End If
    
    'Call WheelUnHook(frmMain.hWnd)
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    'Debug.Print "KeyCode=" & KeyCode 'KeyCode 38 is uparrow KeyCode 40 is dnarrow
    
    If (bReturnGetKeyState(GetKeyState(vbKeyUp))) Then
        If (gblbTerminalScrolling) Then 'Key UP behaves differently when the other terminal is showing
            subMouseWheelUse -1
        Else
            gblbFreeToText = True
            If (Not gblbBringBackFirstGo) Then gbllBringBack = gbllBringBack - 1
            If (gbllBringBack < 1) Then gbllBringBack = 1
            gblbBringBackFirstGo = False
            If (Len(MyCStr(gblzBringBackString(gbllBringBack))) <> 0) Then frmMain.txtSendClientData.Text = gblzBringBackString(gbllBringBack)
        End If
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyDown))) Then
        If (gblbTerminalScrolling) Then 'Key DOWN behaves differently when the other terminal is showing
            subMouseWheelUse 1
        Else
            gblbFreeToText = True
            If (gblzBringBackString(gbllBringBack + 1) <> "") Then
                If (Not gblbBringBackFirstGo) Then gbllBringBack = gbllBringBack + 1
                If (gbllBringBack > lcstBringBackString) Then
                    gbllBringBack = lcstBringBackString '# is the last thing on the text line
                End If
                frmMain.txtSendClientData.Text = gblzBringBackString(gbllBringBack)
                gblbBringBackFirstGo = False
            Else
                gblbBringBackFirstGo = True
                frmMain.txtSendClientData.Text = ""
                If (gbllBringBack > lcstBringBackString) Then
                    gbllBringBack = lcstBringBackString '7 is the last thing on the text line when there is nothing at 9
                End If
            End If
        End If
    End If

    If (bReturnGetKeyState(GetKeyState(vbKeyLeft))) Then
        gblbFreeToText = True
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF1))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF1 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF2))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF2 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF3))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF3 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF4))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF4 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF5))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF5 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF6))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF6 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF7))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF7 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF8))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF8 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF9))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF9 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF10))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF10 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF11))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF11 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyF12))) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyF12 & vbCrLf
    End If
End Sub

Private Sub Form_Paint()
On Error Resume Next
    Terminal.Refresh
End Sub

Private Sub mnuAbout_Click()
    frmSplashScreen.Show 0
End Sub

Private Sub mnuAdminBldCmds_Click()
    frmHelpAdminSkills.Show
End Sub

Private Sub mnuBlackSheet_Click()
    gblfrmBlackSheet = Not gblfrmBlackSheet
    If (gblfrmBlackSheet) Then
        frmBlackSheet.Show
    Else
        Unload frmBlackSheet
    End If
End Sub

Private Sub mnuEventsToggle_Click()
    mnuEventsToggle.Checked = Not mnuEventsToggle.Checked
    gblEventsToggle = mnuEventsToggle.Checked
End Sub

Private Sub mnuHelpAdminBuildAreasToo_Click()
    frmHelpAdminBuildAreaToo.Show
End Sub

Private Sub mnuHelpAdminSkillsToo_Click()
    frmHelpAdminSkillsToo.Show
End Sub

Private Sub mnuAGViewer_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmAreaViewerSaver
        Unload frmGraphicalRepresentation
        frmAreaViewerSaver.Show
        frmGraphicalRepresentation.Show
    End If
End Sub

Private Sub mnuButtons_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmButtons
        frmButtons.Show
    End If
End Sub

Private Sub mnuChangeFont_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmChangeFont
        frmChangeFont.Show
    End If
End Sub

Private Sub mnuChangePortAddress_Click()
    frmAddressPort.Show
End Sub

Private Sub mnuCharacterEvents_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        frmCharacterEvents.Show
    End If
End Sub
Private Sub mnuRecordTextfileEventLine_Click()
    mnuRecordTextfileEventLine.Checked = Not mnuRecordTextfileEventLine.Checked
    gblbRecordTextfileEventLine = Not gblbRecordTextfileEventLine
End Sub
Private Sub mnuCreatorMapperStatus_Click()
    mnuCreatorMapperStatus.Checked = Not mnuCreatorMapperStatus.Checked
    gbllMapperStatus = Not gbllMapperStatus
End Sub

Private Sub mnuCreatorTickerA_Click()
    frmTimer1.Show
End Sub

Private Sub mnuCreatorTickerB_Click()
    frmTimer2.Show
End Sub

Private Sub mnuEditVoiceLocationTriggers_Click()
    frmEditVoiceLocationTriggers.Show
End Sub

Private Sub mnuHelpAdminBuildAreas_Click()
    frmHelpAdminBuildArea.Show
End Sub

Private Sub mnuHelpAdminBuildMob_Click()
    frmHelpAdminBuildMob.Show
End Sub

Private Sub mnuHelpAdminBuildObject_Click()
    frmHelpAdminBuildObjects.Show
End Sub

Private Sub mnuHelpPlayerCommands_Click()
    frmHelpPlayerCommands.Show
End Sub

Private Sub mnuHelpPlayerCommandsToo_Click()
    frmHelpPlayerCommandsToo.Show
End Sub

Private Sub mnuHelpPortForward_Click()
    frmHelpPortForward.Show
End Sub

Private Sub mnuHelpRedErrNos_Click()
    frmHelpWontRun.Show
End Sub

Private Sub mnuHelpServerStalls_Click()
    frmHelpServerStalls.Show
End Sub

Private Sub mnuHowTo_Click()
    frmHowTo.Show
End Sub

Private Sub mnuMapperAutoFocus_Click()
    mnuMapperAutoFocus.Checked = Not mnuMapperAutoFocus.Checked
    gbllMapperAutoFocus = Not gbllMapperAutoFocus
End Sub

Private Sub mnuMapperTimerActive_Click()
    mnuMapperTimerActive.Checked = Not mnuMapperTimerActive.Checked
    gbllMapperTimerStatus = Not gbllMapperTimerStatus
End Sub

Private Sub mnuMapper_Click()
On Error Resume Next
    frmMapper.Show
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub mnuCharacterTriggers_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        frmCharacterTriggers.Show
    End If
End Sub

Private Sub mnuCharacterProfiles_Click()
    Unload frmCharacterProfiles
    frmCharacterProfiles.Show
End Sub

Private Sub mnuLargeMessageBox_Click()
    txtSendClientData_DblClick
End Sub
Public Sub basrunMainCD()
On Error Resume Next
    subCloseReliantWindows
    
    gbllCharacterNameID = 0
    gblzCharacterName = ""
    bPlayerNameRequired = True
    frmMain.drawCharacterFound.Visible = False
    frmMain.Caption = "City of Ages Terminal Emulator"
    If (mnuMainCD.Caption = "Connect") Then
        mnuMainCD.Caption = "Disconnect"
        Call TermInitialize
        frmMain.Winsock1.Close
        frmMain.Winsock1.Connect gblzAddress, gblzPort
        frmMain.timCursor.Enabled = True
        'Terminal0.SetFocus
    Else
        Call Disconnect
    End If
   frmMain.txtSendClientData.SetFocus
End Sub
Public Sub basrunMainCDNoInit()
On Error Resume Next
    subCloseReliantWindows
    
    'gbllCharacterNameID = 0
    'gblzCharacterName = ""
    'bPlayerNameRequired = True
    frmMain.drawCharacterFound.Visible = False
    frmMain.Caption = "City of Ages Terminal Emulator"
    If (mnuMainCD.Caption = "Connect") Then
        mnuMainCD.Caption = "Disconnect"
        Call TermInitialize
        frmMain.Winsock1.Close
        frmMain.Winsock1.Connect gblzAddress, gblzPort
        frmMain.timCursor.Enabled = True
        'Terminal0.SetFocus
    Else
        Call Disconnect
    End If
   frmMain.txtSendClientData.SetFocus
End Sub
Private Sub subMainCDSetState(iValueIndex As Integer)
On Error GoTo Err_Check
    If (iValueIndex = 1) Then mdiMain.subResetData
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    frmMain.txtSendClientData.Text = ""
    subCloseReliantWindows
    
    gbllCharacterNameID = 0
    gblzCharacterName = ""
    bPlayerNameRequired = True
    frmMain.drawCharacterFound.Visible = False
    frmMain.Caption = "City of Ages - Terminal Emulator"
    If (mnuMainCD.Caption = "Connect") Then
        mnuMainCD.Caption = "Disconnect"
        Unload frmMapper
        frmMapper.Show
        mdiMain.subQEButtonStatus False
        Call TermInitialize
        'frmMain.Winsock1.Close
        frmMain.Winsock1.Connect gblzAddress, gblzPort
        
        frmMain.timCursor.Enabled = True
        'Terminal0.SetFocus
    Else
        mdiMain.subQEButtonStatus False
        Call Disconnect
    End If
    
    frmMain.txtSendClientData.SetFocus
    If (frmMain.Winsock1.State = 6) Then '7 = connected MsgBox "I RUN FIRST ! HIHI !"
        Unload frmCharacterProfiles
        frmCharacterProfiles.Show
    End If
    
    subEnforceConnectionStatus
    Exit Sub
Err_Check:
    If (frmMain.Winsock1.State = 6) Then '7 = connected MsgBox "I RUN FIRST ! HIHI !"
        Unload frmCharacterProfiles
        frmCharacterProfiles.Show
    Else
        If (frmMain.Winsock1.State <> 9) Then
            MsgBox "subMainCDSetState," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
        Else
            subEnforceConnectionStatus
            Unload frmCharacterProfiles
            frmCharacterProfiles.Show
        End If
    End If
End Sub
Private Sub mnuMainCD_Click()
    subMainCDSetState 1
End Sub
Private Sub mnuMDITickerC_Click()
    frmTimer3.Show
End Sub
Private Sub mnuMDITickerD_Click()
    frmTimer4.Show
End Sub
Private Sub mnuMDITickerE_Click()
    frmTimer5.Show
End Sub
Private Sub mnuMDITickerF_Click()
    frmTimer6.Show
End Sub
Private Sub mnuMemos_Click()
    frmMemos.Show
End Sub
Private Sub mnuPlayerCommandsThree_Click()
    frmHelpPlayerCommandsThree.Show
End Sub
Private Sub mnuPMGraphicsEditor_Click()
On Error Resume Next
    Unload frmPerceptionMachineEditor
    frmPerceptionMachineEditor.Show
End Sub
Private Sub mnuRunInstance_Click()
    subCoAClientLoad
End Sub

Private Sub mnuScaling_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmCharacterMacroScaling
        frmCharacterMacroScaling.Show
    End If
End Sub

Private Sub mnuScrollBack_Click()
    gblbTerminalScrolling = Not gblbTerminalScrolling
End Sub

Private Sub mnuShowFileNames_Click()
    frmShowFileNames.Show
End Sub

Private Sub mnuSound_Click()
On Error Resume Next
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    Set Player = Nothing
    mnuSound.Checked = Not mnuSound.Checked
    gblbSoundAllowed = (mnuSound.Checked)
End Sub
Private Sub mnuSoundStoryLine_Click()
On Error Resume Next
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    Set Player = Nothing
    mnuSoundStoryLine.Checked = Not mnuSoundStoryLine.Checked
    gblbSoundStoryLine = (mnuSoundStoryLine.Checked)
End Sub
Private Sub mnuSoundBackground_Click()
    mnuSoundBackground.Checked = Not mnuSoundBackground.Checked
    gblbSoundBackground = (mnuSoundBackground.Checked)
    If (Not gblbSoundBackground) Then subMCIStopPlayer
End Sub


Private Sub mnuTimerDynamic1_Click()
    Unload frmTimerDynamic1
    frmTimerDynamic1.Show
End Sub
Private Sub mnuTimerDynamic2_Click()
    Unload frmTimerDynamicTwo
    frmTimerDynamicTwo.Show
End Sub
Private Sub mnuTimerDynamic3_Click()
    Unload frmTimerDynamic3
    frmTimerDynamic3.Show
End Sub
Private Sub mnuTurnOnTelnet_Click()
    frmHelp.Show
End Sub

Private Sub picTerm_Click()
On Error Resume Next
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub picTerm_DblClick()
    subOrganizeMainTerminalForm
End Sub

Private Sub timCursor_Timer()
    gbllScriptOutOfControl = 0
    If ReceivingData = False Then 'if not recieving data then flash the cursor
        gbllEventOffTimer = 0
        Call TermRefresh
    End If
End Sub

Private Sub subCheckTerminalScrollRange()
On Error Resume Next
    Dim lController As Long
    If (bgblLapTopMode) Then
        lController = 250
    Else
        lController = 500
    End If

    gbllTerminalScroll = gbllTerminalScroll + 1 'Terminal Scroll just keeps counting
    If (gbllTerminalScroll > cstlTerminalScrollMAX - lController) Then
        For gbllTerminalScroll = 1 To cstlTerminalScrollMAX 'this MAX is used to prevent overflowing the memory array
            gblzTerminalScroll(gbllTerminalScroll) = ""
        Next gbllTerminalScroll
        gbllTerminalScroll = 1 'needed its global
    End If
    gbllTerminalScrollMAX = gbllTerminalScroll 'This MAX is used to find out where in the Array is the bottom
    If (Not gblbTerminalScrolling) Then gbllTerminalScrollBACKPointer = gbllTerminalScrollMAX
End Sub

Private Sub tmrEventPause_Timer()
    tmrEventPause.Enabled = False
End Sub

Private Sub tmrGoldAnimation_Timer(Index As Integer)
    frmMain!picGoldAnimation(Index).Visible = False
    frmMain!tmrGoldAnimation(Index).Enabled = False
End Sub

Private Sub tmrSoundReset_Timer()
    If (lRandom(999999) < 666) Then frmPictureDungeonMasterCruely.Show
    If (lTrackSounds > 999000) Then subMCIStopPlayer 'we control the sound memory leak
End Sub

Private Sub tmrTriggerPause_Timer()
    tmrTriggerPause.Enabled = False
End Sub

Private Sub tmrTurnOffVoiceOver_Timer()
    If (gblbVoiceLorePlaying) Then
        gbllVoiceLorePlayer = gbllVoiceLorePlayer + 1 '30 seconds a click
        If (gbllVoiceLorePlayer >= 120) Then
            gbllVoiceLorePlayer = 0
            gblbVoiceLorePlaying = False
        End If
    Else
        If (gbllVoiceLorePlayer <> 0) Then gbllVoiceLorePlayer = 0
    End If
End Sub

Private Sub subCheckCoordsPlayerStoryLine(lCharacterNameID As Long, zInfoXYZ As String)
On Error GoTo Err_Code
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zFilename As String
    
    If (Not gblbVoiceLorePlaying) Then
        If (Len(zInfoXYZ) > 0) Then
            subExtractXYZFromInfoXYZ zInfoXYZ, lX, lY, lZ
            Set rsSetUp = MyDB.OpenRecordset("SELECT CharacterNameID, ReadToMeID, Played, ReadToMeHeader, ReadToMeFileName, X1, Y1, X2, Y2, Z  FROM tblReadToMe WHERE ((Played=0 or Played=2) AND (X1<=" & lX & " AND X2>=" & lX & " AND Y1<=" & lY & " AND Y2>=" & lY & " AND Z= " & lZ & "));", dbOpenSnapshot)
            If (Not rsSetUp.EOF) Then 'Map location in the db not there? create the location!
                zFilename = MyCStr(rsSetUp!ReadToMeFileName)
                If (Len(zFilename) <> 0) Then
                    If (bFileExists(zFilename)) Then
                        Set Player = Nothing
                        Set Player = New FilgraphManager 'This is the sound and music player
                            Player.RenderFile zFilename
                            Player.Run
                        gblbVoiceLorePlaying = True 'a timer of a few mintues shuts it down so regular sounds can play
                        MyDB.Execute "UPDATE tblReadToMe SET Played=1 WHERE Played=0 AND ReadToMeID=" & MyCLng(rsSetUp!ReadToMeID) & ";", dbFailOnError '0=Not Played Yet 1=Finished Playing 2=Repeat Playing
                    End If
                End If
            End If
            Set rsSetUp = Nothing
        End If
    End If
    Exit Sub
Err_Code:
    'Debug.Print "subCheckCoordsPlayerStoryLine:" & vbCrLf & Err.Number & " " & vbCrLf & Err.Description
End Sub

Private Sub Winsock1_Connect()
On Error Resume Next
    frmMapper.Show
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State <> 7 And KeyAscii = 13) Then '7 = connected
        'Winsock1.SendData Chr$(KeyAscii) 'would send each code
        Call mnuMainCD_Click
       frmMain.txtSendClientData.SetFocus
    End If
End Sub
Private Sub txtSendClientData_Click()
On Error Resume Next
    gblbFreeToText = True
End Sub
Private Sub txtSendClientData_DblClick()
On Error Resume Next
    frmMain.txtSendClientData.ToolTipText = "" 'user got the message obviously
    frmLargeMessageBox.Show
End Sub
Public Sub subRunSendClientData(KeyAscii As Integer)
On Error Resume Next
    gblbReturnSimulated = True
    txtSendClientData_KeyPress KeyAscii
    gblbReturnSimulated = False
End Sub
Private Sub txtSendClientData_KeyPress(KeyAscii As Integer)
    Dim lCopyScroll As Long
    Dim bSpecialKey As Boolean
    Dim zSendClientData As String

    bSpecialKey = False
    'Debug.Print "KeyAscii=" & KeyAscii
    
    gblbBringBackFirstGo = True
    
    If (KeyAscii = 27) Then
        gbllTerminalScrollBACKPointer = gbllTerminalScrollMAX
        frmMain.txtSendClientData.Text = ""
        'If (picTerm(1).Visible) Then
        '    picTerm.Visible = True
        '    picTerm(1).Visible = False
        'End If
        subRewriteLastBitToWindow
        gblbTerminalScrolling = False
    End If

    If (gbllProfileKeyAscii = 13 Or gblbReturnSimulated Or bReturnGetKeyState(GetKeyState(vbKeyReturn))) Then
        gbllProfileKeyAscii = 0
        
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then '7 = connected
            zSendClientData = MyCStr(txtSendClientData.Text)
            
            If (Len(zSendClientData) > 0) Then
                frmMain.txtSendClientData.Text = ""
                gbllBringBack = gbllBringBack + 1
                If (gbllBringBack > lcstBringBackString) Then
                    gbllBringBack = lcstBringBackString ' the send data textbox and the array of strings scrolls up - we stay at the bottom where the new info goes
                    For lCopyScroll = 1 To lcstBringBackString - 1
                        gblzBringBackString(lCopyScroll) = gblzBringBackString(lCopyScroll + 1)
                    Next lCopyScroll
                    gblzBringBackString(lcstBringBackString) = ""
                End If
                'If (gbllBringBack > 1) Then 'at the end of array we do not repeat previous commands of anything sent
                '    If (gblzBringBackString(gbllBringBack) <> zSendClientData) Then gblzBringBackString(gbllBringBack) = zSendClientData
                'Else
                    gblzBringBackString(gbllBringBack) = zSendClientData
                'End If
                gblbFreeToText = False
                
                If (UCase(zSendClientData) = "REDO") Then 'a player name was entered properly but there was a redo so start again
                    frmMain.Caption = "City of Ages - Telnet Client"
                    bPlayerNameRequired = True
                End If
                
                If (bPlayerNameRequired) Then 'BEGIN LOADING THE CHARACTER PROFILE Scripts and everything else, this is the first thing that happens when a user types in their players name
                    subLoadPlayerDefaults zSendClientData 'Load the Player Name and scripts and everything !
                    subSendClientData zSendClientData 'frmMain.Winsock1.SendData zSendClientData & vbCrLf
                Else 'consult the triggering system
                    bTriedTriggers = bTriggers(zSendClientData)
                    'bTriedEvents = bEvents(zSendClientData) 'this will run twice
                    If (bTriedTriggers) Then  'found a trigger?
                        bSpecialKey = True 'Yes
                    Else
                        subSendClientData zSendClientData
                    End If
                End If
            Else
                If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData vbCrLf
            End If
        End If
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyDecimal))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyDecimal & vbCrLf
    End If

    If (bReturnGetKeyState(GetKeyState(vbKeyDivide))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyDivide & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyMultiply))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyMultiply & vbCrLf
    End If

    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad0))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad0 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeySubtract))) Then
        bSpecialKey = True
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdUp.BackColor = &HFF00&
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeySubtract & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyAdd))) Then
        bSpecialKey = True
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdDown.BackColor = &HFF00&
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyAdd & vbCrLf
    End If
        
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad1))) Then
        If (gblbNumLockFormActive) Then frmNumlock.cmdSW.BackColor = &HFF00&
        subClearMobObjectListbox
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad1 & vbCrLf
        'before &H00C0C0C0&, after green &H0000FF00&
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdSW.BackColor = &HFF00&     'Fancy key animation when the window is open
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad2))) Then
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdS.BackColor = &HFF00&
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad2 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdS.BackColor = &HFF00& 'Fancy key animation when the window is open
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad3))) Then
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdSE.BackColor = &HFF00&
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad3 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdSE.BackColor = &HFF00&
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad4))) Then
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdW.BackColor = &HFF00&
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad4 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdW.BackColor = &HFF00&
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad5))) Then 'look
        subClearMobObjectListbox
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad5 & vbCrLf
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad6))) Then
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdE.BackColor = &HFF00&
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad6 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdE.BackColor = &HFF00& 'Fancy key animation when the window is open
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad7))) Then
        subClearMobObjectListbox
        If (gblbNumLockFormActive) Then frmNumlock.cmdNW.BackColor = &HFF00&
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad7 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdNW.BackColor = &HFF00& 'Fancy key animation when the window is open
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad8))) Then
    If (gblbNumLockFormActive) Then frmNumlock.cmdN.BackColor = &HFF00&
        subClearMobObjectListbox
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad8 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdN.BackColor = &HFF00& 'Fancy key animation when the window is open
    End If
    
    If (bReturnGetKeyState(GetKeyState(vbKeyNumpad9))) Then
        If (gblbNumLockFormActive) Then frmNumlock.cmdNE.BackColor = &HFF00&
        subClearMobObjectListbox
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad9 & vbCrLf
        If (gblbJoystickPackmanWindow) Then frmJoystickPackman.cmdNE.BackColor = &HFF00& 'Fancy key animation when the window is open
    End If
    
    If (bSpecialKey) Then KeyAscii = 0

    If (Not gblbFreeToText And Len(txtSendClientData.Text) <> 0 And frmMain.txtSendClientData.SelLength = 0) Then frmMain.txtSendClientData.SelStart = Len(txtSendClientData.Text) + 1
    'If (txtSendClientData.SelLength >= Len(txtSendClientData.Text)) Then gblbFreeToText = False
End Sub
Private Sub subStatusBar(zPassStatusBarEventLine As String)
    Dim lLen As Long
    Dim lLevel As Long
    Dim lCount As Long
    Dim zHold As String
    Dim bMax As Boolean
    Dim zValue As String
    Dim bDivisor As Boolean
    Dim bDivisorSpecial As Boolean
    Dim lDummy As Long
    'zCut(gblzStatusBarEventLine, "XYZ<", ">")
    
    gbllInfoHP = 1: gbllInfoHPMax = 1
    gbllInfoMana = 1: gbllInfoManaMax = 1
    gbllInfoEssence = 1: gbllInfoEssenceMax = 1
    gbllInfoSoul = 1: gbllInfoSoulMax = 1
    gbllInfoMove = 1: gbllInfoMoveMax = 1
    gbllInfoTNL = 1: gbllInfoTNLMax = 1
    
    lLen = Len(zPassStatusBarEventLine)
    lLevel = 0: bMax = False
    zValue = "": lCount = 0
    gblzInfoXYZ = "": gblzGold = ""
    'ie. zPassStatusBarEventLine = "'H666/1461 M1/1177 E0/1071 S2/1452 MV44% L53% XYZ<-1,0,0> $413"
    'Debug.Print zPassStatusBarEventLine
    Do
        lCount = lCount + 1
        zHold = Mid(zPassStatusBarEventLine, lCount, 1)
        bDivisor = False: bDivisorSpecial = False
        Select Case zHold
            Case " ", "/"
                bDivisor = True
            Case "%"
                bDivisor = True
                bDivisorSpecial = True
            Case "H"
                lLevel = 1
            Case "M"
                lLevel = 2
            Case "E"
                lLevel = 3
            Case "S"
                lLevel = 4
            Case "V"
                lLevel = 5
            Case "L"
                lLevel = 6
            Case "<"
                lLevel = 7
                zValue = ""
            Case "$"
                lLevel = 8
                zValue = ""
            Case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"
                zValue = zValue & zHold
        End Select
        If (lLevel = 7) Then
            If (zHold = ">") Then
                lLevel = 0
            Else
                If (zHold <> "<") Then 'And zHold <> ">") Then
                    gblzInfoXYZ = gblzInfoXYZ & zHold
                    subProcessXYZLine gblzInfoXYZ
                End If
            End If
        End If
        If (lLevel = 8) Then
            If (zHold = " ") Then
                lLevel = 0
            Else
                If (zHold <> "$") Then 'And zHold <> ">") Then
                    gblzGold = gblzGold & zHold
                End If
            End If
        End If
        If (bDivisor And zValue <> "") Then
            If (Not bDivisorSpecial) Then
                Select Case lLevel
                    Case 1
                        If (Not bMax) Then
                            gbllInfoHP = MyCLng(zValue)
                            bMax = True
                        Else
                            gbllInfoHPMax = MyCLng(zValue)
                            bMax = False
                        End If
                    Case 2
                        If (Not bMax) Then
                            gbllInfoMana = MyCLng(zValue)
                            bMax = True
                        Else
                            gbllInfoManaMax = MyCLng(zValue)
                            bMax = False
                        End If
                    Case 3
                        If (Not bMax) Then
                            gbllInfoEssence = MyCLng(zValue)
                            bMax = True
                        Else
                            gbllInfoEssenceMax = MyCLng(zValue)
                            bMax = False
                        End If
                    Case 4
                        If (Not bMax) Then
                            gbllInfoSoul = MyCLng(zValue)
                            bMax = True
                        Else
                            gbllInfoSoulMax = MyCLng(zValue)
                            bMax = False
                        End If
                    Case 5 'percents
                        gbllInfoMove = MyCLng(zValue)
                        gbllInfoMoveMax = 100 'MyCLng(zValue)
                        bMax = False
                    Case 6 'percents
                        gbllInfoTNL = MyCLng(zValue)
                        gbllInfoTNLMax = 100 'MyCLng(zValue)
                        bMax = False
                        lCount = lLen 'we exit
                End Select
            Else 'percentage
                Select Case lLevel
                    Case 1
                        gbllInfoHP = MyCLng(zValue)
                        gbllInfoHPMax = 100
                        bMax = False
                    Case 2
                        gbllInfoMana = MyCLng(zValue)
                        gbllInfoManaMax = 100
                        bMax = False
                    Case 3
                        gbllInfoEssence = MyCLng(zValue)
                        gbllInfoEssenceMax = 100
                        bMax = False
                    Case 4
                        gbllInfoSoul = MyCLng(zValue)
                        gbllInfoSoulMax = 100
                        bMax = False
                    Case 5 'percents
                        gbllInfoMove = MyCLng(zValue)
                        gbllInfoMoveMax = 100 'MyCLng(zValue)
                        bMax = False
                    Case 6 'percents
                        gbllInfoTNL = MyCLng(zValue)
                        gbllInfoTNLMax = 100 'MyCLng(zValue)
                        bMax = False
                End Select
            End If
            If (lLevel <> 0) Then zValue = ""
        End If
    Loop Until (lCount = lLen)
    If gbllInfoHPMax = 0 Then gbllInfoHPMax = 1
    If gbllInfoManaMax = 0 Then gbllInfoManaMax = 1
    If gbllInfoEssenceMax = 0 Then gbllInfoEssenceMax = 1
    If gbllInfoSoulMax = 0 Then gbllInfoSoulMax = 1
    If gbllInfoMoveMax = 0 Then gbllInfoMoveMax = 1
    If gbllInfoTNLMax = 0 Then gbllInfoTNLMax = 1
    If (gblbAnimation) Then
    If (MyCLng(gblzGold) <> 0) Then 'hardcoded loot animation
        lDummy = Abs(Abs(MyCLng(gblzGoldPrevious)) - Abs(MyCLng(gblzGold))) '
        If (MyCLng(gblzGoldPrevious) = 0) Then
            If (lDummy > 999) Then
                'animate gold falling picturebox
                'here is your chest of gold
                frmMain!picGoldAnimation(1).Visible = True
                frmMain!tmrGoldAnimation(1).Enabled = True
            Else
                If (lDummy > 99) Then
                    'animate gold falling picturebox
                    'here is your sprinkle of gold
                    frmMain!picGoldAnimation(0).Visible = True
                    frmMain!tmrGoldAnimation(0).Enabled = True
                End If
            End If
        Else
            If (lDummy > 3332) Then
                'animate gold falling picturebox
                'here is your chest of gold
                frmMain!picGoldAnimation(2).Visible = True
                frmMain!tmrGoldAnimation(2).Enabled = True
            End If
        End If
    End If
    End If
    gblzGoldPrevious = gblzGold
    'Debug.Print gblzGold
End Sub
Private Sub Winsock1_Close()
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    If (frmMain.Winsock1.State = 7) Then Call Disconnect
    subMainCDSetState 0
End Sub
Private Sub tmrWARPENGAGED_Timer()
On Error Resume Next
    tmrWARPENGAGED.Enabled = False 'turn this timer off again.
    Unload frmPictureENERGIZE
    Unload frmPictureBEAMDOWN
    Unload frmPictureWarpDriveENGAGE
    
    'Each time one of these is run there is a chance DM Cru-ley will show up
    If (gblbAnimation And lRandom(999) = 1) Or (lRandom(99999) = 1) Then frmPictureDungeonMasterCruely.Show
End Sub
Private Sub Winsock1_DataArrival(ByVal bytesTotal As Long)
On Error GoTo Err_Code
    Dim DataIn() As Byte
    Dim DataLength As Long
    Dim zLine As String
    Dim bDummy As Boolean
    Dim lDummy As Long
    Dim lMidEventLine27 As Long
    Dim lMidEventLineComma As Long
    Dim X As Integer
    Dim rsSetUp As Recordset
    Dim iESC As Integer
    Dim zChr As String
    Dim iLen As Integer
    Dim zEventLine As String
    Dim zOEventLine As String
    Dim bScriptHappened As Boolean
    Dim lCount As Long
    Dim bRanScriptTrigger As Boolean
    
    'Area Where Variables
    Dim lLenAreaWhere As Long
    Dim zAreaWhereChr As String
    Dim lAreaWhereScanner As Long
    Dim bAreaWhereScan As Boolean
    Dim lAreaWhereCounter As Long
    Dim zAreaWhereHoldLine As String
    
    'Dummy vars Use as it pleases
    Dim lInStr As Long
    Dim zFilename As String
    Dim lAdapter As Long
    Dim bAscii As Boolean
    Dim lDataInAsciiCount As Long
    Dim lChatA As Long
    Dim lChatB As Long
    Dim lChatC As Long 'Circlemud support
    
    ReceivingData = True
    DataLength = frmMain.Winsock1.BytesReceived
    frmMain.Winsock1.GetData DataIn, vbArray + vbByte
    iESC = 0: zLine = "": zEventLine = "": lAdapter = 0: lDataInAsciiCount = 0
    For X = 0 To DataLength - 1
        zChr = Chr(DataIn(X))
        'We keep the formatting at 80 cols
        If (DataIn(X) = 13) Then lAdapter = 0
        If (DataIn(X) = 27) Then
            bAscii = True
            lDataInAsciiCount = 0
        End If
        If (bAscii) Then lDataInAsciiCount = lDataInAsciiCount + 1
        If (DataIn(X) > 31 And Not bAscii) Then lAdapter = lAdapter + 1
        If (bAscii And DataIn(X) = 109) Then bAscii = False 'esc[0;0m encountered
        If (lAdapter > 80 And lDataInAsciiCount <= 8) Then
            lAdapter = 0
            Call TermProcessInput(13)
            Call TermProcessInput(10)
        End If
        If (lDataInAsciiCount > 8) Then 'Ascii was a fake
            bAscii = False
            lDataInAsciiCount = 0
        End If
        
        zEventLine = zEventLine & zChr 'we grab it all - to hide AID#MID#GID#OID# this is where it would be detected and removed.
        If (DataIn(X) = 27) Then iESC = iESC + 7
        iLen = (Len(zLine) - iESC)
        If (DataIn(X) <> 13 And DataIn(X) <> 10) Then
            zLine = zLine & zChr 'line is used for the Event matcher and for Scroll back buffer
            iLen = iLen + 1
        End If
        If (iLen = gblcstiTerminalWidthMAX + 1 Or DataIn(X) = 13 Or DataIn(X) = 10) Then
            If (iLen = gblcstiTerminalWidthMAX Or DataIn(X) = 13) Then
                subCheckTerminalScrollRange
                gblzTerminalScroll(gbllTerminalScroll) = zLine 'this is when they want to scroll backwards on something
                'Debug.Print "Len(zLine)=" & Len(zLine) & vbCrLf & zLine
                zLine = ""
            End If
        End If
        If (Not gblbTerminalScrolling) Then Call TermProcessInput(DataIn(X)) 'we just put it to memory until the scrolling is done
        'End If
    Next
    
    zOEventLine = zEventLine 'Keep the original
    zEventLine = zRemoveColorCodes(zEventLine) 'remove ascii color codes
    If (gblbRecordTextfileEventLine) Then Print #iFileNo, zOEventLine  'write some example text to the file we could use And gbllCharacterNameID <> 0 here
    
    If (zLine <> "") Then
        subCheckTerminalScrollRange
        gblzTerminalScroll(gbllTerminalScroll) = zLine 'this is when they want to scroll backwards on something
    End If
    
    ReceivingData = False
    
    If (gblbSoundStoryLine) Then subCheckCoordsPlayerStoryLine gbllCharacterNameID, gblzInfoXYZ
    
    gblzStatusBarEventLine = ""
    'Debug.Print zOEventLine
    If (InStr(zOEventLine, gblzGraphicalClientCode) <> 0) Then
        lDummy = InStr(zOEventLine, "'H")
        If (lDummy <> 0) Then  'command prompt commandprompt
            gblzStatusBarEventLine = zRemoveColorCodes(Mid(zOEventLine, lDummy))
        End If
    End If
    
    'Quick Exits
    If (InStr(zOEventLine, "Quicks:") <> 0) Then mdiMain.subQEReload zOEventLine
        
    'CAPTURE Mob Object and DOOR names
    subScannedNameLoad zOEventLine
   
    'Capture special locations of glory obj or mobs
    'If (InStr(zOEventLine, "[") < InStr(zOEventLine, "]") And InStr(zOEventLine, "@") <> 0) Then   'Special Picture values
    subCaptureREALMQUESTDesc zOEventLine
    subSpecialMapLocationXYZ zOEventLine
    'End If
    
    'CAPTURE: AID MID OID for the pictures to show up
    If (InStr(zEventLine, "#<") <> 0 And InStr(zEventLine, ">") <> 0) Then 'Special Picture values
        If (InStr(zEventLine, "AID#<") <> 0) Then
            gblzInfoAID = zCut(zEventLine, "AID#<", ">")
            gblzInfoAGID = zCut(zEventLine, "GID#<", ">")
        End If
        If (InStr(zEventLine, "MID#<") <> 0) Then
            gblzInfoMID = zCut(zEventLine, "MID#<", ">")
            gblzInfoMGID = zCut(zEventLine, "GID#<", ">")
        End If
        If (InStr(zEventLine, "OID#<") <> 0) Then
            gblzInfoOID = zCut(zEventLine, "OID#<", ">")
            gblzInfoOGID = zCut(zEventLine, "GID#<", ">")
        End If
    End If

    If (InStr(zEventLine, "|^|") <> 0 Or InStr(zEventLine, "|^^|") <> 0) Then
        If (Not gblbDetectedCommand) Then frmCommandDD.Show
        frmCommandDD.txtMsg.Text = zEventLine
    End If
    
    If (InStr(zEventLine, gblzMAPPEROFFCODE) <> 0 Or InStr(zEventLine, "<<@STARSHIP@>>") <> 0) Then  'when we beam aboard a starship we turn the mapper off
        mnuCreatorMapperStatus.Checked = False
        gbllMapperStatus = False
        subRemoveTheGraphicalMap gbllCharacterNameID, gblzInfoXYZ
    End If
    
    'If (InStr(zEventline, gblzMAPPERONCODE) <> 0) Then 'you can enable this code to work
    '    mnuCreatorMapperStatus.Checked = True
    '    gbllMapperStatus = True
    'End If
    
    'SCAN for Area Where BMP codes
    If (InStr(zEventLine, "<<") <> 0 And InStr(zEventLine, ">>") <> 0) Then
        gblzInfoAreaWhere = zCut(zEventLine, "<<", ">>")
    End If
    
    'SCAN for Inventory or Equipment text
    If (InStr(zEventLine, "<-") <> 0 And InStr(zEventLine, "->") <> 0) Then
        'INVENTORY START
        gblbInventoryStart = True
    End If
    If (gblbInventoryStart) Then
        gblzInventoryLine = gblzInventoryLine & zEventLine
    End If
    If (InStr(zEventLine, "<==") <> 0 And InStr(zEventLine, "==>") <> 0) Then
        'INVENTORY END
        gblbInventoryStart = False
        subProcessInventoryLine gblzInventoryLine
        gblzInventoryLine = ""
    End If
    If (InStr(zEventLine, "<+") <> 0 And InStr(zEventLine, "+>") <> 0) Then
        'Equipment START
        gblbEquipmentStart = True
    End If
    If (gblbEquipmentStart) Then
        gblzEquipmentLine = gblzEquipmentLine & zEventLine
    End If
    If (InStr(zEventLine, "<**") <> 0 And InStr(zEventLine, "**>") <> 0) Then
        'Equipment END
        gblbEquipmentStart = False
        subProcessEquipmentLine gblzEquipmentLine
        gblzEquipmentLine = ""
    End If
    If (InStr(zEventLine, "<## S") <> 0 And InStr(zEventLine, "D ##>") <> 0) Then
        'Scorecard START
        gblbScorecardStart = True
    End If
    If (gblbScorecardStart) Then
        gblzScorecardLine = gblzScorecardLine & zEventLine
    End If
    If (InStr(zEventLine, "<###") <> 0 And InStr(zEventLine, "###>") <> 0) Then
        'Scorecard END
        gblbScorecardStart = False
        subProcessScorecardLine gblzScorecardLine
        gblzScorecardLine = ""
    End If
    If (InStr(zEventLine, "<++=<S") <> 0 And InStr(zEventLine, "T>=++>") <> 0) Then '<++=<SKILL LIST>=++>
        'Slist Line START
        gblbSlistStart = True
    End If
    If (gblbSlistStart) Then
        gblzSlistLine = gblzSlistLine & zEventLine
    End If
    If (InStr(zEventLine, "<++==-") <> 0 And InStr(zEventLine, "-==++>") <> 0) Then
        'Slist Line END
        gblbSlistStart = False
        subProcessSlistLine gblzSlistLine
        gblzSlistLine = ""
    End If '<++==--*--==++>
    If (InStr(zEventLine, "<::=-") <> 0 And InStr(zEventLine, "-=::>") <> 0) Then 'LEARN PRAC COST DAMAGE trees
        ' TreesLine START
        gblbTreesStart = True
    End If
    If (gblbTreesStart) Then
        gblzTreesLine = gblzTreesLine & zEventLine
    End If
    If (InStr(zEventLine, "<::=+") <> 0 And InStr(zEventLine, "+=::>") <> 0) Then
        'TreesLine END
        gblbTreesStart = False
        subProcessTreesLine gblzTreesLine
        gblzTreesLine = ""
    End If '<::=++++:++++=::>

    lChatA = InStr(zEventLine, "<("): lChatB = InStr(zEventLine, ")>"): lChatC = InStr(zEventLine, "[OOC:")
    If (lChatA <> 0 And lChatB <> 0) Or (lChatC <> 0) Then
        'txtChatCapture END
        mdiMain.txtChatCapture.ToolTipText = "LastMsg@" & Format(time(), "hh:nnAMPM")
        If (lChatC = 0) Then
            mdiMain.txtChatCapture.Text = zRemoveClutter(zCut(zEventLine, "<(", ")>")) & vbCrLf & mdiMain.txtChatCapture.Text
        Else
            mdiMain.txtChatCapture.Text = zRemoveClutter(zCut(zEventLine, "[OOC:", "[Pl")) & vbCrLf & mdiMain.txtChatCapture.Text
        End If
    End If
    
    'CAPTURE: HP MANA ESS SOUL XYZ[zInfoXYZ] Gold doesnt matter  1335 is width max for the textbox
    If (Len(gblzStatusBarEventLine) <> 0) Then 'Status Bar values
        'gblzInfoXYZ = zCut(gblzStatusBarEventLine, "XYZ<", ">") 'CAPTURE: XYZ for Mapping
        lStatusBarUsed = 0
        subStatusBar gblzStatusBarEventLine
        mdiMain!txtStatsBar(0).width = (gbllInfoHP / gbllInfoHPMax) * 1335
        mdiMain!txtStatsBar(0).Text = gbllInfoHP & "/" & gbllInfoHPMax
        mdiMain!txtStatsBar(1).width = (gbllInfoMana / gbllInfoManaMax) * 1335
        mdiMain!txtStatsBar(1).Text = gbllInfoMana & "/" & gbllInfoManaMax
        mdiMain!txtStatsBar(2).width = (gbllInfoEssence / gbllInfoEssenceMax) * 1335
        mdiMain!txtStatsBar(2).Text = gbllInfoEssence & "/" & gbllInfoEssenceMax
        mdiMain!txtStatsBar(3).width = (gbllInfoSoul / gbllInfoSoulMax) * 1335
        mdiMain!txtStatsBar(3).Text = gbllInfoSoul & "/" & gbllInfoSoulMax
        mdiMain!txtStatsBar(4).width = (gbllInfoMove / gbllInfoMoveMax) * 1335
        mdiMain!txtStatsBar(4).Text = gbllInfoMove & "/" & gbllInfoMoveMax
        If (Not gblbStatsBox) Then
            mdiMain!picStatsBox.Visible = True
            gblbStatsBox = True
        End If
    Else
        lStatusBarUsed = lStatusBarUsed + 1
        If (lStatusBarUsed > cstStatusBarUsed) Then
            If (gblbStatsBox) Then
                mdiMain!picStatsBox.Visible = False
                gblbStatsBox = False
            End If
        End If
    End If
    
    If (gbllMapperStatus <> 0) Then subRecordTheGraphicalMap gbllCharacterNameID, gblzInfoXYZ
    
    If (gblbGraphicalRepresentation) Then frmGraphicalRepresentation.lblTranslate.Caption = zOEventLine

    If (gbllCharacterNameID <> 0) Then 'no profile matched so the person cannot use events
        If (gbllEventOffTimer = 0) Then
            'We now see if we can trip a Character Profile Event
            If (gblEventsToggle And Not gblbMASTERLock) Then
                bDummy = bEvents(zOEventLine)
            End If
        End If
    End If
    Exit Sub
Err_Code:
    Debug.Print "DataArrival:WINSOCK1:" & vbCrLf & Err.Number & " " & vbCrLf & Err.Description
End Sub
