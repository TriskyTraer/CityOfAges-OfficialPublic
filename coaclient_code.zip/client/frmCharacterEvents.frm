VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmCharacterEvents 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Profile - Events"
   ClientHeight    =   8100
   ClientLeft      =   150
   ClientTop       =   390
   ClientWidth     =   9375
   Icon            =   "frmCharacterEvents.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   8100
   ScaleWidth      =   9375
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Caption         =   "&Delete"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   8280
      Picture         =   "frmCharacterEvents.frx":08CA
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   7800
      Width           =   975
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5520
      TabIndex        =   9
      Top             =   7800
      Width           =   975
   End
   Begin VB.CommandButton cmdLoad 
      Appearance      =   0  'Flat
      Caption         =   "&Load"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   8
      Top             =   7800
      Width           =   975
   End
   Begin VB.CommandButton cmdNew 
      Appearance      =   0  'Flat
      Caption         =   "&New"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   7
      Top             =   7800
      Width           =   975
   End
   Begin VB.ListBox lstEvents 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3630
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   9135
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      ForeColor       =   &H80000008&
      Height          =   2535
      Left            =   120
      ScaleHeight     =   2505
      ScaleWidth      =   9105
      TabIndex        =   1
      Top             =   3840
      Width           =   9135
      Begin VB.ComboBox cbxAsciiColorInsert 
         Appearance      =   0  'Flat
         Height          =   315
         Left            =   6720
         TabIndex        =   3
         ToolTipText     =   "Copy and paste the funny code and numbers into the event textbox to use color codes, prevents chat tripping."
         Top             =   120
         Width           =   2295
      End
      Begin VB.CommandButton cmdImage 
         Appearance      =   0  'Flat
         Caption         =   "Img"
         Height          =   375
         Left            =   8640
         Style           =   1  'Graphical
         TabIndex        =   19
         ToolTipText     =   "Image file defaults to the sound file location with .BMP instead of .wav or .mp3, you can redirect with this location."
         Top             =   1560
         Width           =   375
      End
      Begin VB.TextBox txtImageFilename 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   222
         TabIndex        =   6
         ToolTipText     =   "You can double click to short cut strait to the pathing, the button will now frame your picture."
         Top             =   1560
         Width           =   8460
      End
      Begin VB.TextBox txtSearch 
         Appearance      =   0  'Flat
         Height          =   285
         Left            =   7440
         TabIndex        =   14
         Top             =   2040
         Width           =   1575
      End
      Begin VB.ComboBox cbxPlayerType 
         Appearance      =   0  'Flat
         Height          =   315
         Left            =   4800
         TabIndex        =   13
         ToolTipText     =   "MCI=Background WIN=Playforground and stop MCI player"
         Top             =   2040
         Width           =   1455
      End
      Begin VB.ComboBox cbxSoundType 
         Appearance      =   0  'Flat
         Height          =   315
         Left            =   1920
         TabIndex        =   12
         ToolTipText     =   "PLAY means this control will not stop previous playing sounds as STOP would."
         Top             =   2040
         Width           =   1455
      End
      Begin VB.CommandButton cmdPlayer 
         Appearance      =   0  'Flat
         Height          =   375
         Left            =   8640
         Picture         =   "frmCharacterEvents.frx":0E54
         Style           =   1  'Graphical
         TabIndex        =   11
         ToolTipText     =   $"frmCharacterEvents.frx":0FDE
         Top             =   1080
         Width           =   375
      End
      Begin VB.TextBox txtSoundFilename 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   222
         TabIndex        =   5
         ToolTipText     =   "You can double click to short cut strait to the pathing, the button will now play music."
         Top             =   1080
         Width           =   8460
      End
      Begin VB.TextBox txtEventProgrammedReply 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   255
         TabIndex        =   4
         ToolTipText     =   "Send to server this string"
         Top             =   600
         Width           =   8895
      End
      Begin VB.TextBox txtEventMatchingText 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   66
         TabIndex        =   2
         ToolTipText     =   "The server sends a string to match to this text box then trigger the next text box below."
         Top             =   120
         Width           =   6495
      End
      Begin VB.Label lblMsg 
         Appearance      =   0  'Flat
         BackColor       =   &H00404040&
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Player Type:"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   2
         Left            =   3480
         TabIndex        =   18
         Top             =   2040
         Width           =   1215
      End
      Begin VB.Label lblMsg 
         Appearance      =   0  'Flat
         BackColor       =   &H00404040&
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Sound Reaction:"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   1
         Left            =   120
         TabIndex        =   17
         Top             =   2040
         Width           =   1695
      End
      Begin VB.Label lblEventTextID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   15
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin MSComDlg.CommonDialog CDlg1 
      Left            =   0
      Top             =   0
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmCharacterEvents.frx":1081
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   1335
      Index           =   0
      Left            =   120
      TabIndex        =   16
      Top             =   6360
      Width           =   9135
   End
End
Attribute VB_Name = "frmCharacterEvents"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'See Also: bEvents(zEventLine As String) As Boolean

Private Sub subLoadAllEvents()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim zSearch As String
    Dim zSQL As String
    
    lstEvents.Clear
    zSearch = zRemoveSQLCrashChars(MyCStr(txtSearch.Text))
    
    If (Len(zSearch) > 0) Then 'TO filter or NOT to filter that is the
        zSQL = "SELECT EventTextID, CharacterNameID, EventMatchingText, EventProgrammedReply FROM tblEventText WHERE EventMatchingText LIKE '*" & zSearch & "*' AND CharacterNameID=" & gbllCharacterNameID & " ORDER BY EventMatchingText, EventTextID;"
    Else
        zSQL = "SELECT EventTextID, CharacterNameID, EventMatchingText, EventProgrammedReply FROM tblEventText WHERE CharacterNameID=" & gbllCharacterNameID & " ORDER BY EventMatchingText, EventTextID;"
    End If
    
    Set rsSetUp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        Do While (Not rsSetUp.EOF)
            lstEvents.AddItem rsSetUp!EventMatchingText
            lstEvents.ItemData(lstEvents.ListCount - 1) = rsSetUp!EventTextID
            rsSetUp.MoveNext
        Loop
    End If
    Set rsSetUp = Nothing
    
    cbxSoundType.Clear
    cbxSoundType.AddItem "PLAY"
    cbxSoundType.AddItem "STOP"
    cbxSoundType = "PLAY"
    
    cbxPlayerType.Clear
    cbxPlayerType.AddItem "MCI"
    cbxPlayerType.AddItem "WIN"
    cbxPlayerType = "MCI"
    Exit Sub
Err_Check:
    MsgBox "subLoadAllEvents," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub subSaveEvent()
'Does the same as:
'        MyDB.Execute "UPDATE tblEventText SET CharacterNameID=" & gbllCharacterNameID & ", EventMatchingText='" & zRemoveSQLCrashChars(txtEventMatchingText.Text) & "', EventProgrammedReply='" & zRemoveSQLCrashChars(txtEventProgrammedReply.Text) & "', SoundFilename='" & zRemoveSQLCrashChars(txtSoundFilename.Text) & "', SoundType='" & zRemoveSQLCrashChars(cbxSoundType.Text) & "', PlayerType='" & zRemoveSQLCrashChars(cbxPlayerType.Text) & "' WHERE EventTextID=" & lEventTextID & ";", dbFailOnError
'        MyDB.Execute "INSERT INTO tblEventText ( CharacterNameID, EventMatchingText, EventProgrammedReply, SoundFilename, SoundType, PlayerType ) SELECT " & gbllCharacterNameID & ", '" & zRemoveSQLCrashChars(txtEventMatchingText.Text) & "', '" & zRemoveSQLCrashChars(txtEventProgrammedReply.Text) & "', '" & zRemoveSQLCrashChars(txtSoundFilename.Text) & "', '" & zRemoveSQLCrashChars(cbxSoundType.Text) & "', '" & zRemoveSQLCrashChars(cbxPlayerType.Text) & "';", dbFailOnError
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lEventTextID As Long
    lEventTextID = MyCLng(lblEventTextID.Caption)
    Set rsData = MyDB.OpenRecordset("SELECT CharacterNameID, EventMatchingText, EventProgrammedReply, ImageFilename, SoundFilename, SoundType, PlayerType FROM tblEventText WHERE CharacterNameID=" & gbllCharacterNameID & " AND EventTextID=" & lEventTextID & ";", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!CharacterNameID = gbllCharacterNameID
        rsData!EventMatchingText = MyCStr(txtEventMatchingText.Text)
        rsData!EventProgrammedReply = MyCStr(txtEventProgrammedReply.Text)
        rsData!SoundFilename = MyCStr(txtSoundFilename.Text)
        rsData!ImageFilename = MyCStr(txtImageFilename.Text)
        rsData!SoundType = MyCStr(cbxSoundType.Text)
        rsData!PlayerType = MyCStr(cbxPlayerType.Text)
        rsData.Update
    Else
        rsData.AddNew
        rsData!CharacterNameID = gbllCharacterNameID
        rsData!EventMatchingText = MyCStr(txtEventMatchingText.Text)
        rsData!EventProgrammedReply = MyCStr(txtEventProgrammedReply.Text)
        rsData!SoundFilename = MyCStr(txtSoundFilename.Text)
        rsData!ImageFilename = MyCStr(txtImageFilename.Text)
        rsData!SoundType = MyCStr(cbxSoundType.Text)
        rsData!PlayerType = MyCStr(cbxPlayerType.Text)
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    MsgBox "subSaveEvent," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub cbxPlayerType_KeyPress(KeyAscii As Integer)
    cbxPlayerType = "MCI"
End Sub

Private Sub cbxPlayerType_LostFocus()
    Select Case (cbxPlayerType)
        Case "MCI", "WIN"
        Case Else
            cbxPlayerType = "MCI"
    End Select
End Sub

Private Sub cbxSoundType_KeyPress(KeyAscii As Integer)
    cbxSoundType = "PLAY"
End Sub
Private Sub cbxSoundType_LostFocus()
    Select Case (cbxSoundType)
        Case "STOP", "PLAY"
        Case Else
            cbxSoundType = "PLAY"
    End Select
End Sub


Private Sub cmdSave_Click()
    If (Len(MyCStr(txtEventMatchingText.Text)) = 0) Then
        txtEventMatchingText.Text = ""
        txtEventProgrammedReply.Text = ""
        txtSoundFilename.Text = ""
        txtImageFilename.Text = ""
        cbxSoundType = "PLAY"
        cbxPlayerType = "MCI"
    Else
        subSave
    End If
End Sub

Private Sub subSave()
    subSaveEvent
    subNew
    subLoadAllEvents
End Sub

Private Sub cmdDelete_Click()
On Error Resume Next
    MyDB.Execute "DELETE * FROM tblEventText WHERE EventTextID=" & MyCLng(lblEventTextID.Caption) & ";", dbFailOnError
    subNew
End Sub

Private Sub cmdLoad_Click()
    subLoadAllEvents
End Sub

Private Sub cmdNew_Click()
    subNew
End Sub
Private Sub subOpenSoundFileExplorer()
On Error GoTo Err_Check
    Dim lErr As Long
    With CDlg1
        .CancelError = True
        .DialogTitle = "Browse For MP3 Files"
        .Filter = "MP3 Files (*.mp3) |*.mp3; |Wave Files (*.wav) |*.wav; |Midi Files (*.mid) |*.mid"
        .InitDir = App.Path & "\"
        .ShowOpen
        If (Len(.filename) <> 0) Then txtSoundFilename.Text = .filename
    End With
    Exit Sub
Err_Check:
    lErr = Err.Number
    If (lErr <> 32755) Then MsgBox "subOpenSoundFileExplorer," & vbCrLf & lErr & vbCrLf & Err.Description, vbCritical
End Sub
Private Sub subOpenImageFileExplorer()
On Error GoTo Err_Check
    Dim lErr As Long
    With CDlg1
        .CancelError = True
        .DialogTitle = "Browse For MP3 Files"
        .Filter = "BMP Files (*.bmp) |*.bmp"
        .InitDir = App.Path & "\"
        .ShowOpen
        If (Len(.filename) <> 0) Then txtImageFilename.Text = .filename
    End With
    Exit Sub
Err_Check:
    lErr = Err.Number
    If (lErr <> 32755) Then MsgBox "subOpenImageFileExplorer," & vbCrLf & lErr & vbCrLf & Err.Description, vbCritical
End Sub
Private Sub cmdPlayer_Click()
On Error Resume Next
    If (Len(MyCStr(txtSoundFilename.Text)) > 0) Then
        Select Case cstPlayerType
            Case 1 'method 2 - works but cuts out the next play
                Set Player = Nothing
                Set Player = New FilgraphManager 'This is the sound and music player
                    Player.RenderFile MyCStr(txtSoundFilename.Text)
                    Player.Run
            Case 2 'wavs only and when you quit the application it keeps playing
                PlaySound txtSoundFilename.Text, ByVal 0&, SND_FILENAME Or SND_ASYNC 'wavs only but will play if the application shuts off
            Case 3 'Suppose to let you play two sounds at once - not sure what is wrong with it
                mciSendString "open " & txtSoundFilename.Text & " type mpegvideo alias FirstSound", "", 0, 0
                mciSendString "play FirstSound", "", 0, 0
                'mciSendString("open " & fileName & " type mpegvideo alias SecondSound", String.Empty, 0, 0)
                'mciSendString("play SecondSound", String.Empty, 0, 0)
                'mciSendString("close FirstSound", String.Empty, 0, 0) 'close in reverse order if possible
                'mciSendString("close SecondSound", String.Empty, 0, 0)
            Case 4 'not working
                Dim b As String
                b = StrConv(LoadResData(101, "custom"), vbUnicode)
                sndPlaySound txtSoundFilename.Text, Flags& 'Original says to use like this: sndPlaySound b, Flags&
        End Select
    Else
        subOpenSoundFileExplorer
    End If
End Sub

Private Sub cmdImage_Click()
On Error Resume Next
    If (Len(MyCStr(txtImageFilename.Text)) > 0) Then
        Select Case cstPlayerType
            Case 1 'method 2 - works but cuts out the next play
                Set Player = Nothing
                Set Player = New FilgraphManager 'This is the sound and music player
                    Player.RenderFile MyCStr(txtImageFilename.Text)
                    Player.Run
            Case 2 'wavs only and when you quit the application it keeps playing
                PlaySound txtImageFilename.Text, ByVal 0&, SND_FILENAME Or SND_ASYNC 'wavs only but will play if the application shuts off
            Case 3 'Suppose to let you play two sounds at once - not sure what is wrong with it
                mciSendString "open " & txtImageFilename.Text & " type mpegvideo alias FirstSound", "", 0, 0
                mciSendString "play FirstSound", "", 0, 0
                'mciSendString("open " & fileName & " type mpegvideo alias SecondSound", String.Empty, 0, 0)
                'mciSendString("play SecondSound", String.Empty, 0, 0)
                'mciSendString("close FirstSound", String.Empty, 0, 0) 'close in reverse order if possible
                'mciSendString("close SecondSound", String.Empty, 0, 0)
            Case 4 'not working
                Dim b As String
                b = StrConv(LoadResData(101, "custom"), vbUnicode)
                sndPlaySound txtImageFilename.Text, Flags& 'Original says to use like this: sndPlaySound b, Flags&
        End Select
    Else
        subOpenImageFileExplorer
    End If
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 5
    txtEventMatchingText.SetFocus
End Sub

Private Sub Form_Load()
    subLoadAllEvents
    subLoadAsciiCombobox
End Sub
Private Sub subLoadAsciiCombobox()
    cbxAsciiColorInsert.Clear
    cbxAsciiColorInsert.AddItem "nBlack" & gblzFNBLA
    cbxAsciiColorInsert.AddItem "nRed" & gblzFNRED
    cbxAsciiColorInsert.AddItem "nGreen" & gblzFNGRE
    cbxAsciiColorInsert.AddItem "nYellow" & gblzFNYEL
    cbxAsciiColorInsert.AddItem "nBlue" & gblzFNBLU
    cbxAsciiColorInsert.AddItem "nMagneta" & gblzFNMAG
    cbxAsciiColorInsert.AddItem "nCyan" & gblzFNCYA
    cbxAsciiColorInsert.AddItem "nWhite" & gblzFNWHI

    cbxAsciiColorInsert.AddItem "bBlack" & gblzFNBLA
    cbxAsciiColorInsert.AddItem "bRed" & gblzFBRED
    cbxAsciiColorInsert.AddItem "bGreen" & gblzFBGRE
    cbxAsciiColorInsert.AddItem "bYellow" & gblzFBYEL
    cbxAsciiColorInsert.AddItem "bBlue" & gblzFBBLU
    cbxAsciiColorInsert.AddItem "bMagneta" & gblzFBMAG
    cbxAsciiColorInsert.AddItem "bCyan" & gblzFBCYA
    cbxAsciiColorInsert.AddItem "bWhite" & gblzFBWHI
    
    cbxAsciiColorInsert.AddItem "*CmdlineCode" & gblzGraphicalClientCode
End Sub
Private Sub subNew()
    txtEventMatchingText.Text = ""
    txtEventProgrammedReply.Text = ""
    lblEventTextID.Caption = ""
    txtSoundFilename.Text = ""
    txtImageFilename.Text = ""
    cbxSoundType = "PLAY"
    cbxPlayerType = "MCI"
    DoEvents
    subLoadAllEvents
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Set Player = Nothing
End Sub

Private Sub lstEvents_Click()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Set rsSetUp = MyDB.OpenRecordset("SELECT PlayerType, SoundType, EventTextID, CharacterNameID, EventMatchingText, EventProgrammedReply, ImageFilename, SoundFilename FROM tblEventText WHERE CharacterNameID=" & gbllCharacterNameID & " AND EventTextID=" & MyCLng(lstEvents.ItemData(lstEvents.ListIndex)) & ";", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        lblEventTextID.Caption = MyCStr(rsSetUp!EventTextID)
        txtEventMatchingText.Text = MyCStr(rsSetUp!EventMatchingText)
        txtEventProgrammedReply.Text = MyCStr(rsSetUp!EventProgrammedReply)
        txtSoundFilename.Text = MyCStr(rsSetUp!SoundFilename)
        txtImageFilename.Text = MyCStr(rsSetUp!ImageFilename)
        cbxSoundType = MyCStr(rsSetUp!SoundType)
        cbxPlayerType = MyCStr(rsSetUp!PlayerType)
        rsSetUp.MoveNext
    Else
        subNew
    End If
    Set rsSetUp = Nothing
    Exit Sub
Err_Check:
    MsgBox "lstEvents_Click," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub txtImageFilename_DblClick()
    subOpenImageFileExplorer
End Sub
Private Sub txtSearch_KeyUp(KeyCode As Integer, Shift As Integer)
    If (KeyCode = 13) Then subLoadAllEvents
End Sub

Private Sub txtSoundFilename_DblClick()
    subOpenSoundFileExplorer
End Sub
