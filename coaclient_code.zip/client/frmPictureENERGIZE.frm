VERSION 5.00
Begin VB.Form frmPictureENERGIZE 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "E N E R G I Z E !!!"
   ClientHeight    =   10050
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   10035
   Icon            =   "frmPictureENERGIZE.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmPictureENERGIZE.frx":058A
   ScaleHeight     =   10050
   ScaleWidth      =   10035
End
Attribute VB_Name = "frmPictureENERGIZE"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
