VERSION 5.00
Begin VB.Form frmHelpPortForward 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "HELP - ROUTER PORT FORWARDING"
   ClientHeight    =   11760
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   15015
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpPortForward.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   Picture         =   "frmHelpPortForward.frx":058A
   ScaleHeight     =   11760
   ScaleWidth      =   15015
   Begin VB.Label lblAboutDefaultGateway 
      Alignment       =   1  'Right Justify
      BackColor       =   &H0080C0FF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Default Gateway is your Router, http://192.168.0.1 in this case."
      Height          =   495
      Left            =   3600
      TabIndex        =   0
      Top             =   6480
      Width           =   2535
   End
End
Attribute VB_Name = "frmHelpPortForward"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

