VERSION 5.00
Begin VB.Form frmChangeFont 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Terminal Emulator Font Editor"
   ClientHeight    =   8115
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   7530
   Icon            =   "frmChangeFont.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   8115
   ScaleWidth      =   7530
   Begin VB.ComboBox cbxFontMode 
      Appearance      =   0  'Flat
      Height          =   315
      Left            =   5640
      TabIndex        =   8
      TabStop         =   0   'False
      Text            =   "Main"
      ToolTipText     =   "Main telnet window or Notes [inv eq scorecard slist trees] windows"
      Top             =   6120
      Width           =   735
   End
   Begin VB.CommandButton cmdApply 
      Appearance      =   0  'Flat
      Caption         =   " &Apply"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   300
      Left            =   6480
      TabIndex        =   5
      Top             =   6100
      Width           =   975
   End
   Begin VB.ListBox lstFontSize 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   27.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5700
      Left            =   6480
      TabIndex        =   3
      Top             =   120
      Width           =   975
   End
   Begin VB.ListBox lstFontName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   9
         Charset         =   255
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   5970
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   6255
   End
   Begin VB.Label lblScreenSize 
      Height          =   255
      Left            =   120
      TabIndex        =   7
      Top             =   6120
      Width           =   2295
   End
   Begin VB.Label lblFontOriginal 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   3960
      TabIndex        =   6
      ToolTipText     =   "Original Font Used"
      Top             =   6480
      Width           =   3495
   End
   Begin VB.Label lblFontTest 
      Appearance      =   0  'Flat
      BackColor       =   &H000080FF&
      Caption         =   "TEST LABLE"
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   3240
      TabIndex        =   4
      Top             =   6120
      Visible         =   0   'False
      Width           =   975
   End
   Begin VB.Label lblFontName 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   120
      TabIndex        =   2
      ToolTipText     =   "Current Picked Font"
      Top             =   6480
      Width           =   3735
   End
   Begin VB.Label lblExample 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "EXAMPLE OF THE TEXT SELECTED IN THE ABOVE LISTBOX"
      ForeColor       =   &H80000008&
      Height          =   1095
      Left            =   120
      TabIndex        =   1
      ToolTipText     =   "Example of the Picked Font"
      Top             =   6960
      Width           =   7335
   End
End
Attribute VB_Name = "frmChangeFont"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdApply_Click()
On Error GoTo Err_Check
    Const zLine = "The quick brown fox jumps over the lazy dog." & vbCrLf & "This is a sentence that contains all 26 letters of the English alphabet." & vbCrLf & "It is also known as a pangram. It is commonly used as an exercise to" & vbCrLf & "learn where all the letters are on the keyboard or to test typewriters and printers." & vbCrLf & vbCrLf & "The phrase first appeared in 'The Boston Journal in 1885'."
    gblzFontName = UCase(MyCStr(lstFontName.Text))
    gbllFontSize = lMinFontSize(MyCLng(lstFontSize.Text))
    If (Len(gblzFontName) <> 0) Then
        Select Case cbxFontMode.Text
            Case "Main":
                lstFontSize_DblClick
            Case "Note"
                MyDB.Execute "UPDATE tblClientSetUp SET FontNoteName='" & gblzFontName & "', FontNoteSize=" & gbllFontSize & ";", dbFailOnError
                Unload frmInventory
                frmInventory.Show
                frmInventory.txtInventory.Text = "THIS IS A TEST" & vbCrLf & vbCrLf & zLine & vbCrLf & vbCrLf & "TEST OVER - CONDUIT CLOSED..."
                Unload frmEquipment
                frmEquipment.Show
                frmEquipment.txtEquipment.Text = "THIS IS A TEST" & vbCrLf & vbCrLf & zLine & vbCrLf & vbCrLf & "TEST OVER - CONDUIT CLOSED..."
                Unload frmScorecard
                frmScorecard.Show
                frmScorecard.txtScorecard.Text = "THIS IS A TEST" & vbCrLf & vbCrLf & zLine & vbCrLf & vbCrLf & "TEST OVER - CONDUIT CLOSED..."
                Unload frmSlistTrees
                frmSlistTrees.Show
                frmSlistTrees.txtSlistTrees.Text = "THIS IS A TEST" & vbCrLf & vbCrLf & zLine & vbCrLf & vbCrLf & "TEST OVER - CONDUIT CLOSED..."
            Case Else
                cbxFontMode.Text = "Main"
        End Select
    End If
    Exit Sub
Err_Check:
    MsgBox "cmdApply_Click," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 4
    subWindowsPosition Me, "S"
    
    lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN)
    lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN)
    bgblLapTopMode = (lgblScreenHeight < 1000)
    
    lblScreenSize.Caption = "Screen Mode: " & lgblScreenWidth & " x " & lgblScreenHeight
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
On Error Resume Next
    Dim zSizes As String
    Dim rsFonts As Recordset
    Dim i As Integer ' Declare variable.
    subWindowsPosition Me, "L"
    For i = 0 To Screen.FontCount - 1 ' Determine Numer of fonts.
        zSizes = UCase(MyCStr(Screen.Fonts(i)))
        Set rsFonts = MyDB.OpenRecordset("SELECT FontLookUpText, FontValueMin, FontValueMax, FontHeightAdjust FROM tblFontLookup WHERE (FontLookUpText='" & zSizes & "');", dbOpenDynaset)
        If (rsFonts.EOF) Then
            rsFonts.AddNew
            rsFonts!FontLookUpText = zSizes
            rsFonts!FontValueMin = 1
            rsFonts!FontValueMax = 1
            rsFonts!FontHeightAdjust = 3100
            rsFonts.Update
        End If
        Set rsFonts = Nothing
    
        lstFontName.AddItem Screen.Fonts(i)  ' Put each font into list box.
    Next i
    lblFontTest.FontName = gblzFontName
    lblFontTest.FontSize = lMinFontSize(gbllFontSize)
    lblFontName.Caption = gblzFontName
    lblFontOriginal.Caption = gblzFontName & "[" & lblFontTest.FontSize & "]"
    lblExample.FontName = gblzFontName
    lblExample.FontSize = lMinFontSize(gbllFontSize)
    
    cbxFontMode.AddItem "Main"
    cbxFontMode.AddItem "Note"
End Sub

Private Sub subLoadFontSizes()
    Dim zSaveName As String
    Dim zSaveSize As Single
    Dim aSizes As Variant
    Dim i As Long
    Dim rsFonts As Recordset
    
    'place holders for font name and font size
    zSaveName = lstFontSize.Font.Name
    zSaveSize = lMinFontSize(lstFontSize.Font.Size)

    aSizes = Array(5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 24)
    lstFontSize.Clear
    'this is the font the user has selected and is set to a label so we can use the label to find out what sizes it has in it
    lblFontTest.FontName = UCase(MyCStr(lstFontName.Text))
    DoEvents
    'whip through the array checking all possible font sizes
    For i = LBound(aSizes) To UBound(aSizes)
        lblFontTest.FontSize = lMinFontSize(MyCLng(aSizes(i)))
        DoEvents
        'font supports this size? then add to the list
        If Round(lMinFontSize(lblFontTest.FontSize) + 0.1) = MyCLng(aSizes(i)) Then 'doesnt round on .5 so we add .1 to force it to round correctly
            lstFontSize.AddItem aSizes(i)
        End If
    Next
End Sub
Private Function lMinFontSize(lValue As Long) As Long
    Dim lReturn As Long
    lReturn = lValue
    If (lReturn < 5) Then lReturn = 10
    lMinFontSize = lReturn
End Function

Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
    subWindowsPosition Me, "S"
    Unload frmInventory
    Unload frmEquipment
    Unload frmScorecard
    Unload frmSlistTrees
End Sub

Private Sub lstFontName_Click()
    Dim zFontNameClickedOn As String
    subLoadFontSizes
    zFontNameClickedOn = UCase(MyCStr(lstFontName.Text))
    lblFontName.Caption = zFontNameClickedOn
    lblExample.FontName = zFontNameClickedOn
    lblExample.FontSize = lMinFontSize(MyCLng(lstFontSize.Text))
End Sub

Private Sub lstFontName_DblClick()
    lstFontSize_DblClick
End Sub

Private Sub lstFontSize_Click()
    Dim zFontNameClickedOn As String
    zFontNameClickedOn = UCase(MyCStr(lstFontName.Text))
    lblFontName.Caption = zFontNameClickedOn
    lblExample.FontName = zFontNameClickedOn
    lblExample.FontSize = lMinFontSize(MyCLng(lstFontSize.Text))
End Sub

Private Sub lstFontSize_DblClick()
    gblzFontName = UCase(MyCStr(lstFontName.Text))
    gbllFontSize = lMinFontSize(MyCLng(lstFontSize.Text))
    MyDB.Execute "UPDATE tblClientSetUp SET FontName='" & gblzFontName & "', FontSize=" & gbllFontSize & ";", dbFailOnError
    'gblbfrmMainAllowShutdown = False
    'Unload frmMain
    'Load frmMain
    subSetUpTerminal
    subOrganizeMainTerminalForm
End Sub
