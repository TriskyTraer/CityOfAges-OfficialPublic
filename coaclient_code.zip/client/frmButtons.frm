VERSION 5.00
Begin VB.Form frmButtons 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BUTTONS"
   ClientHeight    =   7320
   ClientLeft      =   150
   ClientTop       =   495
   ClientWidth     =   5400
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00000000&
   Icon            =   "frmButtons.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   7320
   ScaleWidth      =   5400
   Begin VB.CommandButton cmdDone 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      Height          =   255
      Left            =   4320
      TabIndex        =   41
      Top             =   6960
      Width           =   975
   End
   Begin VB.TextBox txtNewValue 
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   360
      MaxLength       =   45
      TabIndex        =   39
      ToolTipText     =   "This value is sent to the server directly when you push the button."
      Top             =   6480
      Width           =   4935
   End
   Begin VB.TextBox txtNewLabel 
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   360
      MaxLength       =   10
      TabIndex        =   38
      ToolTipText     =   "Button Text Caption Label"
      Top             =   6120
      Width           =   4935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":058A
      DownPicture     =   "frmButtons.frx":09CC
      Height          =   495
      Index           =   19
      Left            =   2280
      Picture         =   "frmButtons.frx":180E
      Style           =   1  'Graphical
      TabIndex        =   42
      Top             =   5520
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   19
      Left            =   360
      Picture         =   "frmButtons.frx":1D98
      TabIndex        =   40
      Top             =   5520
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":33E2
      DownPicture     =   "frmButtons.frx":3824
      Height          =   495
      Index           =   18
      Left            =   4800
      Picture         =   "frmButtons.frx":4666
      Style           =   1  'Graphical
      TabIndex        =   37
      Top             =   5520
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   18
      Left            =   2880
      Picture         =   "frmButtons.frx":4BF0
      TabIndex        =   36
      Top             =   5520
      Width           =   1935
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   17
      Left            =   2880
      Picture         =   "frmButtons.frx":623A
      TabIndex        =   35
      Top             =   4920
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":7884
      DownPicture     =   "frmButtons.frx":7CC6
      Height          =   495
      Index           =   17
      Left            =   4800
      Picture         =   "frmButtons.frx":8B08
      Style           =   1  'Graphical
      TabIndex        =   34
      Top             =   4920
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   16
      Left            =   360
      Picture         =   "frmButtons.frx":9092
      TabIndex        =   33
      Top             =   4920
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":A6DC
      DownPicture     =   "frmButtons.frx":AB1E
      Height          =   495
      Index           =   16
      Left            =   2280
      Picture         =   "frmButtons.frx":B960
      Style           =   1  'Graphical
      TabIndex        =   32
      Top             =   4920
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   15
      Left            =   2880
      Picture         =   "frmButtons.frx":BEEA
      TabIndex        =   31
      Top             =   4320
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":D534
      DownPicture     =   "frmButtons.frx":D976
      Height          =   495
      Index           =   15
      Left            =   4800
      Picture         =   "frmButtons.frx":E7B8
      Style           =   1  'Graphical
      TabIndex        =   30
      Top             =   4320
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   14
      Left            =   360
      Picture         =   "frmButtons.frx":ED42
      TabIndex        =   29
      Top             =   4320
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":1038C
      DownPicture     =   "frmButtons.frx":107CE
      Height          =   495
      Index           =   14
      Left            =   2280
      Picture         =   "frmButtons.frx":11610
      Style           =   1  'Graphical
      TabIndex        =   28
      Top             =   4320
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   13
      Left            =   2880
      Picture         =   "frmButtons.frx":11B9A
      TabIndex        =   27
      Top             =   3720
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":131E4
      DownPicture     =   "frmButtons.frx":13626
      Height          =   495
      Index           =   13
      Left            =   4800
      Picture         =   "frmButtons.frx":14468
      Style           =   1  'Graphical
      TabIndex        =   26
      Top             =   3720
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   12
      Left            =   360
      Picture         =   "frmButtons.frx":149F2
      TabIndex        =   25
      Top             =   3720
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":1603C
      DownPicture     =   "frmButtons.frx":1647E
      Height          =   495
      Index           =   12
      Left            =   2280
      Picture         =   "frmButtons.frx":172C0
      Style           =   1  'Graphical
      TabIndex        =   24
      Top             =   3720
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   11
      Left            =   2880
      Picture         =   "frmButtons.frx":1784A
      TabIndex        =   23
      Top             =   3120
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":18E94
      DownPicture     =   "frmButtons.frx":192D6
      Height          =   495
      Index           =   11
      Left            =   4800
      Picture         =   "frmButtons.frx":1A118
      Style           =   1  'Graphical
      TabIndex        =   22
      Top             =   3120
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   10
      Left            =   360
      Picture         =   "frmButtons.frx":1A6A2
      TabIndex        =   21
      Top             =   3120
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":1BCEC
      DownPicture     =   "frmButtons.frx":1C12E
      Height          =   495
      Index           =   10
      Left            =   2280
      Picture         =   "frmButtons.frx":1CF70
      Style           =   1  'Graphical
      TabIndex        =   20
      Top             =   3120
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   9
      Left            =   2880
      Picture         =   "frmButtons.frx":1D4FA
      TabIndex        =   19
      Top             =   2520
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":1EB44
      DownPicture     =   "frmButtons.frx":1EF86
      Height          =   495
      Index           =   9
      Left            =   4800
      Picture         =   "frmButtons.frx":1FDC8
      Style           =   1  'Graphical
      TabIndex        =   18
      Top             =   2520
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   8
      Left            =   360
      Picture         =   "frmButtons.frx":20352
      TabIndex        =   17
      Top             =   2520
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":2199C
      DownPicture     =   "frmButtons.frx":21DDE
      Height          =   495
      Index           =   8
      Left            =   2280
      Picture         =   "frmButtons.frx":22C20
      Style           =   1  'Graphical
      TabIndex        =   16
      Top             =   2520
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   7
      Left            =   2880
      Picture         =   "frmButtons.frx":231AA
      TabIndex        =   15
      Top             =   1920
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":247F4
      DownPicture     =   "frmButtons.frx":24C36
      Height          =   495
      Index           =   7
      Left            =   4800
      Picture         =   "frmButtons.frx":25A78
      Style           =   1  'Graphical
      TabIndex        =   14
      Top             =   1920
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   6
      Left            =   360
      Picture         =   "frmButtons.frx":26002
      TabIndex        =   13
      Top             =   1920
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":2764C
      DownPicture     =   "frmButtons.frx":27A8E
      Height          =   495
      Index           =   6
      Left            =   2280
      Picture         =   "frmButtons.frx":288D0
      Style           =   1  'Graphical
      TabIndex        =   12
      Top             =   1920
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   5
      Left            =   2880
      Picture         =   "frmButtons.frx":28E5A
      TabIndex        =   11
      Top             =   1320
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":2A4A4
      DownPicture     =   "frmButtons.frx":2A8E6
      Height          =   495
      Index           =   5
      Left            =   4800
      Picture         =   "frmButtons.frx":2B728
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   1320
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   4
      Left            =   360
      Picture         =   "frmButtons.frx":2BCB2
      TabIndex        =   9
      Top             =   1320
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":2D2FC
      DownPicture     =   "frmButtons.frx":2D73E
      Height          =   495
      Index           =   4
      Left            =   2280
      Picture         =   "frmButtons.frx":2E580
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   1320
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   3
      Left            =   2880
      Picture         =   "frmButtons.frx":2EB0A
      TabIndex        =   7
      Top             =   720
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":30154
      DownPicture     =   "frmButtons.frx":30596
      Height          =   495
      Index           =   3
      Left            =   4800
      Picture         =   "frmButtons.frx":313D8
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   720
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   2
      Left            =   360
      Picture         =   "frmButtons.frx":31962
      TabIndex        =   5
      Top             =   720
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":32FAC
      DownPicture     =   "frmButtons.frx":333EE
      Height          =   495
      Index           =   2
      Left            =   2280
      Picture         =   "frmButtons.frx":34230
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   720
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   1
      Left            =   2880
      Picture         =   "frmButtons.frx":347BA
      TabIndex        =   3
      Top             =   120
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":35E04
      DownPicture     =   "frmButtons.frx":36246
      Height          =   495
      Index           =   1
      Left            =   4800
      Picture         =   "frmButtons.frx":37088
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   120
      Width           =   495
   End
   Begin VB.CommandButton cmdButton1 
      Appearance      =   0  'Flat
      Height          =   495
      Index           =   0
      Left            =   360
      Picture         =   "frmButtons.frx":37612
      TabIndex        =   1
      Top             =   120
      Width           =   1935
   End
   Begin VB.CommandButton cmdChange1 
      Appearance      =   0  'Flat
      DisabledPicture =   "frmButtons.frx":38C5C
      DownPicture     =   "frmButtons.frx":3909E
      Height          =   495
      Index           =   0
      Left            =   2280
      Picture         =   "frmButtons.frx":39EE0
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   120
      Width           =   495
   End
   Begin VB.Label lblRow1 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      Caption         =   "R2"
      ForeColor       =   &H80000008&
      Height          =   255
      Index           =   1
      Left            =   120
      TabIndex        =   44
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label lblRow1 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      Caption         =   "R1"
      ForeColor       =   &H80000008&
      Height          =   255
      Index           =   0
      Left            =   120
      TabIndex        =   43
      Top             =   120
      Width           =   255
   End
End
Attribute VB_Name = "frmButtons"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim zgblValue(0 To 19) As String
Dim lgblIndex  As Long

Private Sub cmdButton1_Click(Index As Integer)
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zgblValue(Index) & vbCrLf
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdButton1_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
    mdiMain.tmrButtonBnk.Enabled = True
    mdiMain.cmdButton1(Index).BackColor = cstlngButtonColorBnk
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 3
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_Load()
    subWindowsPosition Me, "L"
    lgblIndex = -1
    subLoadButtons
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub subSave()
    Dim rsData As Recordset
    Dim lCount As Long
    Dim zLabel As String
    
    DoEvents
    
    lCount = 0
    
    'If a record doesnt exit create it
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblButtons WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenSnapshot)
    If (rsData.EOF) Then
        MyDB.Execute "INSERT INTO tblButtons ( CharacterNameID ) SELECT " & gbllCharacterNameID & ";", dbFailOnError
    End If
    Set rsData = Nothing
    
    'Now save
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblButtons WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        For lCount = 1 To 20
            zLabel = MyCStr(cmdButton1(lCount - 1).Caption)
            Select Case lCount
                Case 1
                    rsData!ButtonLabel1 = zLabel
                Case 2
                    rsData!ButtonLabel2 = zLabel
                Case 3
                    rsData!ButtonLabel3 = zLabel
                Case 4
                    rsData!ButtonLabel4 = zLabel
                Case 5
                    rsData!ButtonLabel5 = zLabel
                Case 6
                    rsData!ButtonLabel6 = zLabel
                Case 7
                    rsData!ButtonLabel7 = zLabel
                Case 8
                    rsData!ButtonLabel8 = zLabel
                Case 9
                    rsData!ButtonLabel9 = zLabel
                Case 10
                    rsData!ButtonLabel10 = zLabel
                Case 11
                    rsData!ButtonLabel11 = zLabel
                Case 12
                    rsData!ButtonLabel12 = zLabel
                Case 13
                    rsData!ButtonLabel13 = zLabel
                Case 14
                    rsData!ButtonLabel14 = zLabel
                Case 15
                    rsData!ButtonLabel15 = zLabel
                Case 16
                    rsData!ButtonLabel16 = zLabel
                Case 17
                    rsData!ButtonLabel17 = zLabel
                Case 18
                    rsData!ButtonLabel18 = zLabel
                Case 19
                    rsData!ButtonLabel19 = zLabel
                Case 20
                    rsData!ButtonLabel20 = zLabel
            End Select
            
            zLabel = MyCStr(zgblValue(lCount - 1))
            Select Case lCount
                Case 1
                    rsData!Button1 = zLabel
                Case 2
                    rsData!Button2 = zLabel
                Case 3
                    rsData!Button3 = zLabel
                Case 4
                    rsData!Button4 = zLabel
                Case 5
                    rsData!Button5 = zLabel
                Case 6
                    rsData!Button6 = zLabel
                Case 7
                    rsData!Button7 = zLabel
                Case 8
                    rsData!Button8 = zLabel
                Case 9
                    rsData!Button9 = zLabel
                Case 10
                    rsData!Button10 = zLabel
                Case 11
                    rsData!Button11 = zLabel
                Case 12
                    rsData!Button12 = zLabel
                Case 13
                    rsData!Button13 = zLabel
                Case 14
                    rsData!Button14 = zLabel
                Case 15
                    rsData!Button15 = zLabel
                Case 16
                    rsData!Button16 = zLabel
                Case 17
                    rsData!Button17 = zLabel
                Case 18
                    rsData!Button18 = zLabel
                Case 19
                    rsData!Button19 = zLabel
                Case 20
                    rsData!Button20 = zLabel
            End Select
        Next lCount
        rsData.Update
    End If
    Set rsData = Nothing
End Sub

Private Sub subLoadButtons()
    Dim rsData As Recordset
    Dim lCount As Long
    Dim zLabel As String
    Dim zValue As String
    Dim bFound As Boolean
    lCount = 0
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblButtons WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenSnapshot)
    bFound = (Not rsData.EOF)
    For lCount = 1 To 20
        zLabel = ""
        zValue = ""
        If (bFound) Then
            Select Case lCount
                Case 1
                    zLabel = MyCStr(rsData!ButtonLabel1)
                    zValue = MyCStr(rsData!Button1)
                Case 2
                    zLabel = MyCStr(rsData!ButtonLabel2)
                    zValue = MyCStr(rsData!Button2)
                Case 3
                    zLabel = MyCStr(rsData!ButtonLabel3)
                    zValue = MyCStr(rsData!Button3)
                Case 4
                    zLabel = MyCStr(rsData!ButtonLabel4)
                    zValue = MyCStr(rsData!Button4)
                Case 5
                    zLabel = MyCStr(rsData!ButtonLabel5)
                    zValue = MyCStr(rsData!Button5)
                Case 6
                    zLabel = MyCStr(rsData!ButtonLabel6)
                    zValue = MyCStr(rsData!Button6)
                Case 7
                    zLabel = MyCStr(rsData!ButtonLabel7)
                    zValue = MyCStr(rsData!Button7)
                Case 8
                    zLabel = MyCStr(rsData!ButtonLabel8)
                    zValue = MyCStr(rsData!Button8)
                Case 9
                    zLabel = MyCStr(rsData!ButtonLabel9)
                    zValue = MyCStr(rsData!Button9)
                Case 10
                    zLabel = MyCStr(rsData!ButtonLabel10)
                    zValue = MyCStr(rsData!Button10)
                Case 11
                    zLabel = MyCStr(rsData!ButtonLabel11)
                    zValue = MyCStr(rsData!Button11)
                Case 12
                    zLabel = MyCStr(rsData!ButtonLabel12)
                    zValue = MyCStr(rsData!Button12)
                Case 13
                    zLabel = MyCStr(rsData!ButtonLabel13)
                    zValue = MyCStr(rsData!Button13)
                Case 14
                    zLabel = MyCStr(rsData!ButtonLabel14)
                    zValue = MyCStr(rsData!Button14)
                Case 15
                    zLabel = MyCStr(rsData!ButtonLabel15)
                    zValue = MyCStr(rsData!Button15)
                Case 16
                    zLabel = MyCStr(rsData!ButtonLabel16)
                    zValue = MyCStr(rsData!Button16)
                Case 17
                    zLabel = MyCStr(rsData!ButtonLabel17)
                    zValue = MyCStr(rsData!Button17)
                Case 18
                    zLabel = MyCStr(rsData!ButtonLabel18)
                    zValue = MyCStr(rsData!Button18)
                Case 19
                    zLabel = MyCStr(rsData!ButtonLabel19)
                    zValue = MyCStr(rsData!Button19)
                Case 20
                    zLabel = MyCStr(rsData!ButtonLabel20)
                    zValue = MyCStr(rsData!Button20)
            End Select
        End If
        If (Len(zLabel) = 0) Then
            zLabel = mdiMain.cmdButton1(lCount - 1).Caption
            zValue = zLabel
        End If
        zgblValue(lCount - 1) = zValue
        cmdButton1(lCount - 1).Caption = zLabel
    Next lCount
    Set rsData = Nothing
End Sub

Private Sub cmdChange1_Click(Index As Integer)
    lgblIndex = Index
    txtNewLabel.Text = MyCStr(cmdButton1(lgblIndex).Caption)
    txtNewValue.Text = MyCStr(zgblValue(lgblIndex))
End Sub

Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
    mdiMain.subLoadMDIButtons
End Sub

Private Sub txtNewLabel_KeyUp(KeyCode As Integer, Shift As Integer)
    If (lgblIndex <> -1) Then
        If (KeyCode = 13) Then
            cmdButton1(lgblIndex).Caption = txtNewLabel.Text
            subSave
        End If
    Else
        MsgBox "Please push the graphical red triangle button to load start your edit.", vbOKOnly
    End If
End Sub
Private Sub txtNewValue_KeyUp(KeyCode As Integer, Shift As Integer)
    If (lgblIndex <> -1) Then
        If (KeyCode = 13) Then
            zgblValue(lgblIndex) = txtNewValue.Text
            subSave
        End If
    Else
        MsgBox "Please push the graphical red triangle button to load start your edit.", vbOKOnly
    End If
End Sub

Private Sub cmdDone_Click()
    If (lgblIndex <> -1) Then
        cmdButton1(lgblIndex).Caption = txtNewLabel.Text
        zgblValue(lgblIndex) = txtNewValue.Text
        subSave
        mdiMain.subLoadMDIButtons
        txtNewLabel.Text = ""
        txtNewValue.Text = ""
        lgblIndex = -1
    Else
        MsgBox "Please push the graphical red triangle button to load start your edit.", vbOKOnly
    End If
End Sub

