VERSION 5.00
Begin VB.Form frmNumlock 
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "QUICKS MOVEMENT"
   ClientHeight    =   2640
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3960
   Icon            =   "frmNumlock.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2640
   ScaleWidth      =   3960
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   7
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   24
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   1200
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   6
      Left            =   2400
      Style           =   1  'Graphical
      TabIndex        =   23
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   1200
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   5
      Left            =   1080
      Style           =   1  'Graphical
      TabIndex        =   22
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   1200
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   4
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   21
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   720
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   3
      Left            =   1080
      Style           =   1  'Graphical
      TabIndex        =   20
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   720
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   2
      Left            =   3720
      Style           =   1  'Graphical
      TabIndex        =   19
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   240
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   1
      Left            =   2400
      Style           =   1  'Graphical
      TabIndex        =   18
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   240
      Width           =   255
   End
   Begin VB.CheckBox cbAMFilter 
      Height          =   255
      Index           =   0
      Left            =   1080
      Style           =   1  'Graphical
      TabIndex        =   17
      ToolTipText     =   "Click this to filter out of automovement."
      Top             =   240
      Width           =   255
   End
   Begin VB.CheckBox optAutoMove 
      Caption         =   "|"
      Height          =   495
      Left            =   1920
      Style           =   1  'Graphical
      TabIndex        =   16
      ToolTipText     =   "Turn on or off random movement each 5s"
      Top             =   480
      Width           =   135
   End
   Begin VB.Timer tmrAutomove 
      Interval        =   450
      Left            =   1800
      Top             =   720
   End
   Begin VB.CommandButton cmdDown 
      BackColor       =   &H00808080&
      Caption         =   "Down"
      Height          =   495
      Left            =   2040
      Style           =   1  'Graphical
      TabIndex        =   15
      Top             =   480
      Width           =   615
   End
   Begin VB.CommandButton cmdUp 
      BackColor       =   &H00808080&
      Caption         =   "Up"
      Height          =   495
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   14
      Top             =   480
      Width           =   615
   End
   Begin VB.CommandButton cmdClr 
      Appearance      =   0  'Flat
      Caption         =   "clr"
      Height          =   255
      Left            =   2760
      TabIndex        =   13
      Top             =   1800
      Width           =   495
   End
   Begin VB.TextBox txtBuildSpeedWalk 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H00C0C000&
      Height          =   285
      Left            =   120
      TabIndex        =   11
      Top             =   1800
      Width           =   2535
   End
   Begin VB.CheckBox chkBuildSpeedWalk 
      Alignment       =   1  'Right Justify
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      Caption         =   "Safely Build a Speedwalk?"
      ForeColor       =   &H80000008&
      Height          =   195
      Left            =   120
      TabIndex        =   10
      Top             =   1560
      Width           =   3735
   End
   Begin VB.CommandButton cmdLook 
      BackColor       =   &H00808080&
      Caption         =   "Look"
      Height          =   495
      Left            =   2040
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   2160
      Width           =   1935
   End
   Begin VB.CommandButton cmdExits 
      BackColor       =   &H00808080&
      Caption         =   "Exits"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   2160
      Width           =   1935
   End
   Begin VB.CommandButton cmdSE 
      BackColor       =   &H00808080&
      Caption         =   "SouthE"
      Height          =   495
      Left            =   2640
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdSW 
      BackColor       =   &H00808080&
      Caption         =   "SouthW"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdE 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      Caption         =   "East"
      Height          =   495
      Left            =   2640
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdW 
      BackColor       =   &H00808080&
      Caption         =   "West"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdNE 
      BackColor       =   &H00808080&
      Caption         =   "NorthE"
      Height          =   495
      Left            =   2640
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdNW 
      BackColor       =   &H00808080&
      Caption         =   "NorthW"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdS 
      BackColor       =   &H00808080&
      Caption         =   "South"
      Height          =   495
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdN 
      BackColor       =   &H00808080&
      Caption         =   "North"
      Height          =   495
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Width           =   1335
   End
   Begin VB.Label lblLastKey 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H00C0C000&
      Height          =   375
      Left            =   3360
      TabIndex        =   12
      Top             =   1800
      Width           =   615
   End
End
Attribute VB_Name = "frmNumlock"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gblbAutoMove As Boolean
Dim lAutomoveTimerCounter As Long
Private Sub subBuildSpeedWalk(zDir As String)
    lblLastKey.Caption = zDir
    If (chkBuildSpeedWalk.Value <> 0) Then
        txtBuildSpeedWalk.Text = txtBuildSpeedWalk.Text & zDir & ";"
    End If
End Sub

Private Sub cmdClr_Click()
    txtBuildSpeedWalk.Text = ""
End Sub

Private Sub cmdUp_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdUp.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "UP" & vbCrLf
        subBuildSpeedWalk "UP"
    End If
End Sub
Private Sub cmdDown_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdDown.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "DOWN" & vbCrLf
        subBuildSpeedWalk "DOWN"
    End If
End Sub
Private Sub cmdExits_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdExits.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "QUICK" & vbCrLf
    End If
End Sub

Private Sub cmdLook_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdLook.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "LOOK" & vbCrLf
    End If
End Sub
Private Sub cmdN_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdN.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "N" & vbCrLf
        subBuildSpeedWalk "N"
    End If
End Sub
Private Sub cmdS_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdS.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "S" & vbCrLf
        subBuildSpeedWalk "S"
    End If
End Sub
Private Sub cmdE_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdE.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "E" & vbCrLf
        subBuildSpeedWalk "E"
    End If
End Sub
Private Sub cmdW_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdW.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "W" & vbCrLf
        subBuildSpeedWalk "W"
    End If
End Sub
Private Sub cmdNE_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdNE.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "NE" & vbCrLf
        subBuildSpeedWalk "NE"
    End If
End Sub
Private Sub cmdNW_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdNW.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "NW" & vbCrLf
        subBuildSpeedWalk "NW"
    End If
End Sub
Private Sub cmdSE_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdSE.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "SE" & vbCrLf
        subBuildSpeedWalk "SE"
    End If
End Sub
Private Sub cmdSW_Click()
On Error Resume Next
    lAutomoveTimerCounter = 0
    cmdSW.BackColor = &HFF00&
    If (frmMain.Winsock1.State = 7) Then 'connected?
        subClearMobObjectListbox
        frmMain.Winsock1.SendData "SW" & vbCrLf
        subBuildSpeedWalk "SW"
    End If
End Sub

Private Sub Form_Load()
    gblbAutoMove = False
    optAutoMove.Value = gblbAutoMove
    subAMFilter True
End Sub

Private Sub subAMFilter(bStatus As Boolean)
    Dim lCount As Long
    Select Case bStatus
        Case 0
            For lCount = 0 To 7
                cbAMFilter(lCount).Visible = True
                cbAMFilter(lCount).Value = 0
            Next lCount
        Case Else
            For lCount = 0 To 7
                cbAMFilter(lCount).Visible = False
                cbAMFilter(lCount).Value = 1
            Next lCount
    End Select
End Sub

Private Sub optAutoMove_Click()
    gblbAutoMove = Not gblbAutoMove
    subAMFilter Not gblbAutoMove
End Sub

Private Sub tmrAutomove_Timer()
    lAutomoveTimerCounter = lAutomoveTimerCounter + 1
    Select Case lAutomoveTimerCounter
        Case 1
            cmdUp.BackColor = &H808080
            cmdDown.BackColor = &H808080
            cmdLook.BackColor = &H808080
            cmdExits.BackColor = &H808080
            cmdN.BackColor = &H808080
            cmdS.BackColor = &H808080
            cmdE.BackColor = &H808080
            cmdW.BackColor = &H808080
            cmdNW.BackColor = &H808080
            cmdNE.BackColor = &H808080
            cmdSW.BackColor = &H808080
            cmdSE.BackColor = &H808080
        Case 2, 3, 4, 5, 6, 7, 8
            If (gblbAutoMove And lAutomoveTimerCounter Mod 2 = 0) Then 'even value then proceed
                Select Case lRandom(8)
                    Case 1
                        If (cbAMFilter(1).Value = 0) Then cmdN_Click
                    Case 2
                        If (cbAMFilter(6).Value = 0) Then cmdS_Click
                    Case 3
                        If (cbAMFilter(3).Value = 0) Then cmdW_Click
                    Case 4
                        If (cbAMFilter(4).Value = 0) Then cmdE_Click
                    Case 5
                        If (cbAMFilter(2).Value = 0) Then cmdNE_Click
                    Case 6
                        If (cbAMFilter(0).Value = 0) Then cmdNW_Click
                    Case 7
                        If (cbAMFilter(5).Value = 0) Then cmdSW_Click
                    Case 8
                        If (cbAMFilter(7).Value = 0) Then cmdSE_Click
                End Select
            End If
        Case Else
            lAutomoveTimerCounter = 0
    End Select
End Sub
