VERSION 5.00
Begin VB.Form frmPictureWarpDriveENGAGE 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "E N G A G E !!!"
   ClientHeight    =   7590
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   11250
   Icon            =   "frmPictureWarpDriveENGAGE.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmPictureWarpDriveENGAGE.frx":058A
   ScaleHeight     =   7590
   ScaleWidth      =   11250
End
Attribute VB_Name = "frmPictureWarpDriveENGAGE"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
