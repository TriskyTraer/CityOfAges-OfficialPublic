VERSION 5.00
Begin VB.Form frmScorecard 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   Caption         =   "SCORE CARD"
   ClientHeight    =   6435
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   7545
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmScorecard.frx":0000
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   6435
   ScaleWidth      =   7545
   Begin VB.TextBox txtScorecard 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   12
         Charset         =   255
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00808080&
      Height          =   6375
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      ToolTipText     =   "Swipe this screen with your mouse to read this text better, double click to hold in bold mode."
      Top             =   0
      Width           =   7455
   End
End
Attribute VB_Name = "frmScorecard"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim bHighLightText As Boolean
Private Sub subResizeTextBox()
    txtScorecard.width = Me.width - 200
    txtScorecard.height = Me.height
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 16
    subWindowsPosition Me, "S"
    subResizeTextBox
End Sub

Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subWindowsPosition Me, "L"
    subResizeTextBox
    subLoadFontNoteInfo
    txtScorecard.FontName = gblzFontNoteName
    txtScorecard.FontSize = gbllFontNoteSize
End Sub
Private Sub Form_Resize()
    subResizeTextBox
End Sub
Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
    subResizeTextBox
End Sub
Private Sub txtScorecard_DblClick()
    bHighLightText = Not bHighLightText
    Select Case bHighLightText
        Case True
            txtScorecard.ForeColor = &H808080
            txtScorecard.BackColor = &H0&
        Case Else
            txtScorecard.ForeColor = &HC0C0C0
            txtScorecard.BackColor = &H400000
    End Select
    DoEvents
End Sub
