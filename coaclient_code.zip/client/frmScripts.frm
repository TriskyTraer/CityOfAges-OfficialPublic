VERSION 5.00
Begin VB.Form frmScripts 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Profile - Scripts"
   ClientHeight    =   9750
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   9375
   Icon            =   "frmScripts.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   9750
   ScaleWidth      =   9375
   Begin VB.ComboBox cbxWhereToLookInClient 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   330
      Left            =   2160
      TabIndex        =   17
      Text            =   "Status Bar"
      Top             =   6360
      Width           =   1815
   End
   Begin VB.TextBox txtTripWord5NS 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7560
      MaxLength       =   1
      TabIndex        =   13
      Top             =   6960
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord4NS 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5760
      MaxLength       =   1
      TabIndex        =   12
      Top             =   6960
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord3NS 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3960
      MaxLength       =   1
      TabIndex        =   11
      Top             =   6960
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord2NS 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      MaxLength       =   1
      TabIndex        =   10
      Top             =   6960
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord1NS 
      Enabled         =   0   'False
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      MaxLength       =   1
      TabIndex        =   9
      Top             =   6960
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord5Compare 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7560
      TabIndex        =   8
      ToolTipText     =   "This is the value after the IF..."
      Top             =   6360
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord4Compare 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5760
      TabIndex        =   7
      ToolTipText     =   "This is the value after the IF..."
      Top             =   6360
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord3Compare 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3960
      TabIndex        =   6
      ToolTipText     =   "This is the value after the IF..."
      Top             =   6360
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.TextBox txtTripWord2Compare 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2160
      TabIndex        =   5
      ToolTipText     =   "This is the value after the IF..."
      Top             =   6360
      Visible         =   0   'False
      Width           =   1575
   End
   Begin VB.ListBox lstScripts 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4590
      Left            =   120
      TabIndex        =   15
      Top             =   120
      Width           =   9135
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      ForeColor       =   &H80000008&
      Height          =   2775
      Left            =   120
      ScaleHeight     =   2745
      ScaleWidth      =   9105
      TabIndex        =   0
      Top             =   4800
      Width           =   9135
      Begin VB.TextBox txtTripWord1Compare 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   4
         ToolTipText     =   "Trigger Word: This is the value after the IF...and before the qualifiers like a less than sign <"
         Top             =   1560
         Width           =   1575
      End
      Begin VB.TextBox txtSoundFilename 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   3
         ToolTipText     =   "Sound file location"
         Top             =   1080
         Visible         =   0   'False
         Width           =   8895
      End
      Begin VB.TextBox txtScriptProgrammedReply 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   2
         ToolTipText     =   "Send to server"
         Top             =   600
         Visible         =   0   'False
         Width           =   8895
      End
      Begin VB.TextBox txtScriptMatchingText 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         TabIndex        =   1
         ToolTipText     =   "IF [optional] < 2000 THEN [TriggerName]"
         Top             =   120
         Width           =   8895
      End
      Begin VB.Label lblScriptTextID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   14
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmScripts.frx":0442
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   1695
      Left            =   120
      TabIndex        =   16
      Top             =   7680
      Width           =   9135
   End
End
Attribute VB_Name = "frmScripts"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub subLoadAllScripts()
    Dim rsSetUp As Recordset 'Only loads scripts directly to the lstScripts ListBox
    MyDB.Execute "DELETE * FROM tblScriptText WHERE Len(ScriptMatchingText)=0;", dbFailOnError 'we clean up stuff that was to be removed
    lstScripts.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT ScriptTextID, CharacterNameID, ScriptMatchingText, ScriptProgrammedReply, TripWord1Compare, TripWord2Compare, TripWord3Compare, TripWord4Compare, TripWord5Compare, TripWord1NS, TripWord2NS, TripWord3NS, TripWord4NS, TripWord5NS FROM tblScriptText WHERE CharacterNameID=" & gbllCharacterNameID & " ORDER BY ScriptProgrammedReply, ScriptMatchingText, ScriptTextID;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        Do While (Not rsSetUp.EOF)
            lstScripts.AddItem MyCStr(rsSetUp!ScriptMatchingText) 'This is the only one that is required - we load the rest upon click
            lstScripts.ItemData(lstScripts.ListCount - 1) = rsSetUp!ScriptTextID
            rsSetUp.MoveNext
        Loop
    End If
    Set rsSetUp = Nothing
End Sub

Private Sub subSaveScript()
    Dim zCharacterName As String
    Dim lScriptTextID As Long
    Dim rsSetUp As Recordset
    Dim zScriptLine As String
    Dim zTripWord1Compare As String
    Dim zTripWord2Compare As String
    Dim zTripWord3Compare As String
    Dim zTripWord4Compare As String
    Dim zTripWord5Compare As String
    Dim zTripWord1NS As String
    Dim zTripWord2NS As String
    Dim zTripWord3NS As String
    Dim zTripWord4NS As String
    Dim zTripWord5NS As String
    Dim zWhereToLookInClient As String
    
    lScriptTextID = MyCLng(lblScriptTextID.Caption)
    
    zScriptLine = UCase(zRemoveSQLCrashChars(txtScriptMatchingText.Text))
    If (InStr(zScriptLine, "ERROR") = 0 And InStr(zScriptLine, "MISSING") = 0) Then
        If (InStr(zScriptLine, "IF") = 0) Then zScriptLine = "IF " & zScriptLine
        If (InStr(zScriptLine, "THEN") = 0) Then zScriptLine = zScriptLine & " THEN"
        If (InStr(zScriptLine, "IF") > InStr(zScriptLine, "THEN")) Then zScriptLine = zScriptLine & " (ERROR IF TriggerWord <=> STRING/NUMBER THEN)"
        If (InStr(zScriptLine, "<") = 0 And InStr(zScriptLine, ">") = 0 And InStr(zScriptLine, "=") = 0) Then zScriptLine = zScriptLine & " MISSING<>="
    End If
    txtScriptMatchingText.Text = zScriptLine 'After we massage the value we show them what we exactly did with it
    
    zTripWord1Compare = UCase(zRemoveSQLCrashChars(txtTripWord1Compare.Text))
    zTripWord2Compare = UCase(zRemoveSQLCrashChars(txtTripWord2Compare.Text))
    zTripWord3Compare = UCase(zRemoveSQLCrashChars(txtTripWord3Compare.Text))
    zTripWord4Compare = UCase(zRemoveSQLCrashChars(txtTripWord4Compare.Text))
    zTripWord5Compare = UCase(zRemoveSQLCrashChars(txtTripWord5Compare.Text))
    zTripWord1NS = MyCStr(txtTripWord1NS.Text) 'Auto detected by the computer
    zTripWord2NS = MyCStr(txtTripWord2NS.Text)
    zTripWord3NS = MyCStr(txtTripWord3NS.Text)
    zTripWord4NS = MyCStr(txtTripWord4NS.Text)
    zTripWord5NS = MyCStr(txtTripWord5NS.Text)
    zWhereToLookInClient = UCase(zRemoveSQLCrashChars(cbxWhereToLookInClient.Text))
    If (Len(zWhereToLookInClient) <> 0) Then
        zWhereToLookInClient = Mid(zWhereToLookInClient, 1, 1)
    Else
        zWhereToLookInClient = "S"
    End If
    If (zWhereToLookInClient <> "S" And zWhereToLookInClient <> "E") Then zWhereToLookInClient = "S"
    If (zWhereToLookInClient = "S") Then
        zWhereToLookInClient = "Status Bar"
    Else
        zWhereToLookInClient = "Elsewhere"
    End If
    DoEvents
    
    If (lScriptTextID <> 0) Then
        MyDB.Execute "UPDATE tblScriptText SET CharacterNameID=" & gbllCharacterNameID & ", ScriptMatchingText='" & zScriptLine & "', TripWord1Compare='" & zTripWord1Compare & "', TripWord2Compare='" & zTripWord2Compare & "', TripWord3Compare='" & zTripWord3Compare & "', TripWord4Compare='" & zTripWord4Compare & "', TripWord5Compare='" & zTripWord5Compare & "', TripWord1NS='" & zTripWord1NS & "', TripWord2NS='" & zTripWord2NS & "', TripWord3NS='" & zTripWord3NS & "', TripWord4NS='" & zTripWord4NS & "', TripWord5NS='" & zTripWord5NS & "', WhereToLookInClient='" & zWhereToLookInClient & "', ScriptProgrammedReply='', SoundFilename='' WHERE ScriptTextID=" & lScriptTextID & ";", dbFailOnError
    Else
        MyDB.Execute "INSERT INTO tblScriptText ( CharacterNameID, ScriptMatchingText, ScriptProgrammedReply, SoundFilename ) SELECT " & gbllCharacterNameID & ", '" & zScriptLine & "', '', '';", dbFailOnError
    End If
    Set rsSetUp = Nothing
End Sub

Private Sub Form_Activate()
    txtScriptMatchingText.SetFocus
End Sub

Private Sub Form_Load()
    mnuNew_Click
    subLoadAllScripts
End Sub

Private Sub Form_Unload(Cancel As Integer)
    MyDB.Execute "DELETE * FROM tblScriptText WHERE Len(ScriptMatchingText)=0;", dbFailOnError 'we clean up stuff that was to be removed
    subLoadScriptsToMemory
End Sub

Private Sub subDelete()
    MyDB.Execute "DELETE * FROM tblScriptText WHERE ScriptTextID=" & MyCLng(lblScriptTextID.Caption) & ";", dbFailOnError
    mnuNew_Click
End Sub


Private Sub subNew()
'On Error Resume Next
    cbxWhereToLookInClient.Clear
    cbxWhereToLookInClient.AddItem "Status Bar"
    cbxWhereToLookInClient.AddItem "Elsewhere"
    cbxWhereToLookInClient.Text = "Status Bar"
    txtScriptMatchingText.Text = ""
    txtScriptProgrammedReply.Text = ""
    lblScriptTextID.Caption = ""
    txtSoundFilename.Text = ""
    txtTripWord1Compare.Text = ""
    txtTripWord2Compare.Text = ""
    txtTripWord3Compare.Text = ""
    txtTripWord4Compare.Text = ""
    txtTripWord5Compare.Text = ""
    txtTripWord1NS.Text = ""
    txtTripWord2NS.Text = ""
    txtTripWord3NS.Text = ""
    txtTripWord4NS.Text = ""
    txtTripWord5NS.Text = ""
    
    DoEvents
End Sub

Private Sub subSave()
    subSaveScript
    mnuNew_Click
    mnuLoad_Click
End Sub

Private Sub lstScripts_Click()
    Dim rsSetUp As Recordset
    Set rsSetUp = MyDB.OpenRecordset("SELECT ScriptTextID, CharacterNameID, ScriptMatchingText, ScriptProgrammedReply, SoundFilename, TripWord1Compare, TripWord2Compare, TripWord3Compare, TripWord4Compare, TripWord5Compare, TripWord1NS, TripWord2NS, TripWord3NS, TripWord4NS, TripWord5NS, WhereToLookInClient FROM tblScriptText WHERE CharacterNameID=" & gbllCharacterNameID & " AND ScriptTextID=" & MyCLng(lstScripts.ItemData(lstScripts.ListIndex)) & ";", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        lblScriptTextID.Caption = MyCStr(rsSetUp!ScriptTextID)
        txtScriptMatchingText.Text = MyCStr(rsSetUp!ScriptMatchingText)
        txtTripWord1Compare.Text = UCase(MyCStr(rsSetUp!TripWord1Compare))
        txtTripWord2Compare.Text = UCase(MyCStr(rsSetUp!TripWord2Compare))
        txtTripWord3Compare.Text = UCase(MyCStr(rsSetUp!TripWord3Compare))
        txtTripWord4Compare.Text = UCase(MyCStr(rsSetUp!TripWord4Compare))
        txtTripWord5Compare.Text = UCase(MyCStr(rsSetUp!TripWord5Compare))
        txtTripWord1NS.Text = UCase(MyCStr(rsSetUp!TripWord1NS))
        txtTripWord2NS.Text = UCase(MyCStr(rsSetUp!TripWord2NS))
        txtTripWord3NS.Text = UCase(MyCStr(rsSetUp!TripWord3NS))
        txtTripWord4NS.Text = UCase(MyCStr(rsSetUp!TripWord4NS))
        txtTripWord5NS.Text = UCase(MyCStr(rsSetUp!TripWord5NS))
        txtScriptProgrammedReply.Text = MyCStr(rsSetUp!ScriptProgrammedReply)
        txtSoundFilename.Text = MyCStr(rsSetUp!SoundFilename)
        cbxWhereToLookInClient.Text = MyCStr(rsSetUp!WhereToLookInClient)
        rsSetUp.MoveNext
        txtScriptMatchingText.SetFocus
    Else
        mnuNew_Click
    End If
    Set rsSetUp = Nothing
End Sub

Private Sub txtTripWord1Compare_KeyUp(KeyCode As Integer, Shift As Integer)
    Dim zValue As String
    zValue = MyCStr(txtTripWord1Compare.Text)
    If IsNumeric(zValue) Then
        txtTripWord1NS.Text = "N"
    Else
        txtTripWord1NS.Text = "S"
    End If
End Sub

Private Sub txtTripWord2Compare_KeyUp(KeyCode As Integer, Shift As Integer)
    Dim zValue As String
    zValue = MyCStr(txtTripWord2Compare.Text)
    If IsNumeric(zValue) Then
        txtTripWord2NS.Text = "N"
    Else
        txtTripWord2NS.Text = "S"
    End If
End Sub

Private Sub txtTripWord3Compare_KeyUp(KeyCode As Integer, Shift As Integer)
    Dim zValue As String
    zValue = MyCStr(txtTripWord3Compare.Text)
    If IsNumeric(zValue) Then
        txtTripWord3NS.Text = "N"
    Else
        txtTripWord3NS.Text = "S"
    End If
End Sub

Private Sub txtTripWord4Compare_KeyUp(KeyCode As Integer, Shift As Integer)
    Dim zValue As String
    zValue = MyCStr(txtTripWord4Compare.Text)
    If IsNumeric(zValue) Then
        txtTripWord4NS.Text = "N"
    Else
        txtTripWord4NS.Text = "S"
    End If
End Sub

Private Sub txtTripWord5Compare_KeyUp(KeyCode As Integer, Shift As Integer)
    Dim zValue As String
    zValue = MyCStr(txtTripWord5Compare.Text)
    If IsNumeric(zValue) Then
        txtTripWord5NS.Text = "N"
    Else
        txtTripWord5NS.Text = "S"
    End If
End Sub
