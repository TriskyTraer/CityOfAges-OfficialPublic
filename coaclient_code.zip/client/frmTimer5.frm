VERSION 5.00
Begin VB.Form frmTimer5 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "TIMER 14 second sends"
   ClientHeight    =   1260
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   5625
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmTimer5.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   1260
   ScaleWidth      =   5625
   Begin VB.CheckBox chkOnOff 
      BackColor       =   &H00C0C0FF&
      Caption         =   "off"
      Height          =   330
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   840
      Width           =   5415
   End
   Begin VB.TextBox txtSendToServer 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   660
      Left            =   120
      TabIndex        =   0
      ToolTipText     =   "Use button name below to run a script, semi-colons will seperate more commands."
      Top             =   120
      Width           =   5415
   End
   Begin VB.Timer tmrSendToWinsock 
      Enabled         =   0   'False
      Interval        =   14000
      Left            =   120
      Top             =   120
   End
End
Attribute VB_Name = "frmTimer5"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Activate()
    gbllFormActivated = 23
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subWindowsPosition Me, "L"
    subWindowsFieldLoader Me, "L"
End Sub

Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
    subWindowsFieldLoader Me, "S"
End Sub

Private Sub chkOnOff_Click()
On Error Resume Next
    Select Case (chkOnOff.Value = 0)
        Case True
            chkOnOff.BackColor = &HC0C0FF
            tmrSendToWinsock.Enabled = False
            chkOnOff.Caption = "off"
        Case False
            chkOnOff.BackColor = &H80FF80
            tmrSendToWinsock.Enabled = True
            chkOnOff.Caption = "on"
    End Select
    frmMain!txtSendClientData.SetFocus
End Sub

Private Sub tmrSendToWinsock_Timer()
    Dim lLen As String
    Dim zSendClientData As String
    If (frmMain.Winsock1.State = 7) Then
        zSendClientData = MyCStr(txtSendToServer.Text)
        lLen = Len(zSendClientData)
        If (lLen > 0) Then
            If (Not bTriggers(zSendClientData)) Then
                subSendClientData zSendClientData
            End If
        End If
    End If
End Sub
Private Sub txtSendToServer_KeyPress(KeyAscii As Integer)
On Error Resume Next
    If (KeyAscii = 13) Then
        KeyAscii = 0
        frmMain!txtSendClientData.SetFocus
    End If
End Sub

