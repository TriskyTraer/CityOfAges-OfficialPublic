VERSION 5.00
Begin VB.Form frmJoystickPackman 
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "JOYSTICK MOVEMENT"
   ClientHeight    =   2640
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3960
   Icon            =   "frmJoystickPackman.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2640
   ScaleWidth      =   3960
   Begin VB.Timer tmrAnimation 
      Interval        =   700
      Left            =   1560
      Top             =   600
   End
   Begin VB.CommandButton cmdLook 
      BackColor       =   &H00C0C0C0&
      Caption         =   "GO GAME"
      Height          =   495
      Left            =   2040
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   2160
      Width           =   1935
   End
   Begin VB.CommandButton cmdExits 
      BackColor       =   &H00C0C0C0&
      Caption         =   "STOP GAME"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   2160
      Width           =   1935
   End
   Begin VB.CommandButton cmdSE 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "SouthE"
      Height          =   495
      Left            =   2640
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdSW 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "SouthW"
      Height          =   495
      Left            =   0
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdE 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "East"
      Height          =   495
      Left            =   2640
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdW 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "West"
      Height          =   495
      Left            =   0
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdNE 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "NorthE"
      Height          =   495
      Left            =   2640
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdNW 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "NorthW"
      Height          =   495
      Left            =   0
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdS 
      BackColor       =   &H00C0C0C0&
      Caption         =   "South"
      Height          =   495
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdN 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "North"
      Height          =   495
      Left            =   1320
      MaskColor       =   &H00808080&
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Width           =   1335
   End
   Begin VB.Label lblMsg 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      Caption         =   "The NUMLOCK has been temporary modified to play PACKMON."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0080FFFF&
      Height          =   615
      Left            =   240
      TabIndex        =   11
      ToolTipText     =   "While the Window is open, your NUMLOCK will behave as a joystick."
      Top             =   1560
      Width           =   3615
   End
   Begin VB.Label lblLastKey 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H00C0C000&
      Height          =   375
      Left            =   3360
      TabIndex        =   10
      Top             =   1800
      Width           =   615
   End
End
Attribute VB_Name = "frmJoystickPackman"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim zHoldKeyNumpad1 As String
Dim zHoldKeyNumpad2 As String
Dim zHoldKeyNumpad3 As String
Dim zHoldKeyNumpad4 As String
Dim zHoldKeyNumpad6 As String
Dim zHoldKeyNumpad7 As String
Dim zHoldKeyNumpad8 As String
Dim zHoldKeyNumpad9 As String
Private Sub cmdLook_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK GO" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdN_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK N" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdS_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK S" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdE_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK E" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdW_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK W" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdNE_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK NE" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdNW_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK NW" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdSE_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK SE" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdSW_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK SW" & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub Form_Activate()
    If (Not gblbMainSendClientDataFocused) Then
        gblbMainSendClientDataFocused = True
        gblbJoystickPackmanWindow = True
        frmMain.txtSendClientData.SetFocus
    End If
End Sub
Private Sub cmdExits_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK STOP" & vbCrLf
        Unload frmJoystickPackman
    End If
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
    gblbJoystickPackmanWindow = False
    gblzKeyNumpad1 = zHoldKeyNumpad1
    gblzKeyNumpad2 = zHoldKeyNumpad2
    gblzKeyNumpad3 = zHoldKeyNumpad3
    gblzKeyNumpad4 = zHoldKeyNumpad4
    gblzKeyNumpad6 = zHoldKeyNumpad6
    gblzKeyNumpad7 = zHoldKeyNumpad7
    gblzKeyNumpad8 = zHoldKeyNumpad8
    gblzKeyNumpad9 = zHoldKeyNumpad9
    
    gblbMainSendClientDataFocused = False
End Sub
Private Sub Form_Load()
On Error Resume Next
    gblbJoystickPackmanWindow = True
    frmMain.txtSendClientData.SetFocus
    zHoldKeyNumpad1 = gblzKeyNumpad1
    zHoldKeyNumpad2 = gblzKeyNumpad2
    zHoldKeyNumpad3 = gblzKeyNumpad3
    zHoldKeyNumpad4 = gblzKeyNumpad4
    zHoldKeyNumpad6 = gblzKeyNumpad6
    zHoldKeyNumpad7 = gblzKeyNumpad7
    zHoldKeyNumpad8 = gblzKeyNumpad8
    zHoldKeyNumpad9 = gblzKeyNumpad9
    gblzKeyNumpad1 = "JOYS SW"
    gblzKeyNumpad2 = "JOYS S"
    gblzKeyNumpad3 = "JOYS SE"
    gblzKeyNumpad4 = "JOYS W"
    gblzKeyNumpad6 = "JOYS E"
    gblzKeyNumpad7 = "JOYS NW"
    gblzKeyNumpad8 = "JOYS N"
    gblzKeyNumpad9 = "JOYS NE"
End Sub

Private Sub tmrAnimation_Timer()
On Error Resume Next
    frmJoystickPackman.cmdSW.BackColor = &HC0C0C0       'Fancy key animation when the window is open
    frmJoystickPackman.cmdS.BackColor = &HC0C0C0
    frmJoystickPackman.cmdSE.BackColor = &HC0C0C0
    frmJoystickPackman.cmdW.BackColor = &HC0C0C0
    frmJoystickPackman.cmdE.BackColor = &HC0C0C0
    frmJoystickPackman.cmdNW.BackColor = &HC0C0C0
    frmJoystickPackman.cmdN.BackColor = &HC0C0C0
    frmJoystickPackman.cmdNE.BackColor = &HC0C0C0
End Sub
