VERSION 5.00
Begin VB.Form frmJoystickPackman 
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "JOYSTICK MOVEMENT"
   ClientHeight    =   2640
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3960
   Icon            =   "frmJoystickPackman.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2640
   ScaleWidth      =   3960
   Begin VB.CommandButton cmdLook 
      BackColor       =   &H00C0C0C0&
      Caption         =   "GO GAME"
      Height          =   495
      Left            =   2040
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   2160
      Width           =   1935
   End
   Begin VB.CommandButton cmdExits 
      BackColor       =   &H00C0C0C0&
      Caption         =   "STOP GAME"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   2160
      Width           =   1935
   End
   Begin VB.CommandButton cmdSE 
      BackColor       =   &H00C0C0C0&
      Caption         =   "SouthE"
      Height          =   495
      Left            =   2640
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdSW 
      BackColor       =   &H00C0C0C0&
      Caption         =   "SouthW"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdE 
      BackColor       =   &H00C0C0C0&
      Caption         =   "East"
      Height          =   495
      Left            =   2640
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdW 
      BackColor       =   &H00C0C0C0&
      Caption         =   "West"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   480
      Width           =   1335
   End
   Begin VB.CommandButton cmdNE 
      BackColor       =   &H00C0C0C0&
      Caption         =   "NorthE"
      Height          =   495
      Left            =   2640
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdNW 
      BackColor       =   &H00C0C0C0&
      Caption         =   "NorthW"
      Height          =   495
      Left            =   0
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdS 
      BackColor       =   &H00C0C0C0&
      Caption         =   "South"
      Height          =   495
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   960
      Width           =   1335
   End
   Begin VB.CommandButton cmdN 
      BackColor       =   &H00C0C0C0&
      Caption         =   "North"
      Height          =   495
      Left            =   1320
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Width           =   1335
   End
   Begin VB.Label lblMsg 
      BackColor       =   &H00000000&
      Caption         =   "RED PLANET PACKMON GAME: Once the game begins do not move out of the room to keep playing."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   735
      Left            =   120
      TabIndex        =   11
      Top             =   1440
      Width           =   3735
   End
   Begin VB.Label lblLastKey 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H00C0C000&
      Height          =   375
      Left            =   3360
      TabIndex        =   10
      Top             =   1800
      Width           =   615
   End
End
Attribute VB_Name = "frmJoystickPackman"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdExits_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK STOP" & vbCrLf
    End If
End Sub

Private Sub cmdLook_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK GO" & vbCrLf
    End If
End Sub
Private Sub cmdN_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK N" & vbCrLf
    End If
End Sub
Private Sub cmdS_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK S" & vbCrLf
    End If
End Sub
Private Sub cmdE_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK E" & vbCrLf
    End If
End Sub
Private Sub cmdW_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK W" & vbCrLf
    End If
End Sub
Private Sub cmdNE_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK NE" & vbCrLf
    End If
End Sub
Private Sub cmdNW_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK NW" & vbCrLf
    End If
End Sub
Private Sub cmdSE_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK SE" & vbCrLf
    End If
End Sub
Private Sub cmdSW_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData "JOYSTICK SW" & vbCrLf
    End If
End Sub

