VERSION 5.00
Begin VB.Form frmMapEventLocation 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Mapper - Event Location "
   ClientHeight    =   4485
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7020
   FillStyle       =   0  'Solid
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMapEventLocation.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   4485
   ScaleWidth      =   7020
   Begin VB.PictureBox picGridMaster 
      Appearance      =   0  'Flat
      BackColor       =   &H00FF80FF&
      ForeColor       =   &H80000008&
      Height          =   1600
      Left            =   2280
      ScaleHeight     =   1575
      ScaleWidth      =   4665
      TabIndex        =   7
      Top             =   360
      Visible         =   0   'False
      Width           =   4695
      Begin VB.ListBox lstGridMaster 
         Appearance      =   0  'Flat
         Height          =   1500
         Left            =   0
         TabIndex        =   9
         Top             =   0
         Width           =   3615
      End
      Begin VB.CommandButton cmdDeleteGridMasterSelection 
         Appearance      =   0  'Flat
         BackColor       =   &H008080FF&
         Caption         =   "&Del"
         Height          =   1500
         Left            =   3600
         Style           =   1  'Graphical
         TabIndex        =   8
         ToolTipText     =   "Select from the left list box and use this delete button to remove it."
         Top             =   0
         Width           =   615
      End
   End
   Begin VB.CommandButton cmdBringDownGridMasterPicbox 
      Appearance      =   0  'Flat
      BackColor       =   &H00FF80FF&
      Caption         =   "v"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6480
      Style           =   1  'Graphical
      TabIndex        =   6
      ToolTipText     =   "Bring up the maintenance listbox."
      Top             =   0
      Width           =   495
   End
   Begin VB.CommandButton cmdEngage 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      Caption         =   "Set Course ENGAGE"
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3600
      Style           =   1  'Graphical
      TabIndex        =   5
      ToolTipText     =   "Use the coordnates and beam to your ship, and plot a course!"
      Top             =   0
      Width           =   1455
   End
   Begin VB.CommandButton cmdPageLost 
      Appearance      =   0  'Flat
      Caption         =   "View Glory Quests"
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5040
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   0
      Width           =   1455
   End
   Begin VB.CommandButton cmdOpenRight 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   0
      Picture         =   "frmMapEventLocation.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Visible         =   0   'False
      Width           =   280
   End
   Begin VB.Timer tmrMapperRefresh 
      Interval        =   555
      Left            =   0
      Top             =   120
   End
   Begin VB.TextBox txtX 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   1215
   End
   Begin VB.TextBox txtY 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1200
      TabIndex        =   2
      Top             =   0
      Width           =   1215
   End
   Begin VB.TextBox txtZ 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2400
      TabIndex        =   3
      Top             =   0
      Width           =   1215
   End
End
Attribute VB_Name = "frmMapEventLocation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstzMapSizeType = "SMALL"
Const cstRangeX = 26
Const cstRangeY = 18
Const cstSize = 5 'Cannot be less than 5 and must be an odd number
Const cstT2P = 15 '15 twips to 1 pixel
Const cstPixel = 3
Dim gbllX As Long
Dim gbllY As Long
Dim gbllSW As Long
Dim gbllSH As Long
Dim gbllOMeLeft As Long
Dim gbllOMeTop As Long
Dim btmrReloadMap As Boolean
Private Sub cmdBringDownGridMasterPicbox_Click()
    picGridMaster.Visible = Not picGridMaster.Visible
End Sub
Private Sub subtmrReloadMap()
    picGridMaster.Visible = False
    gbllSpecialX = MyCLng(txtX.Text)
    gbllSpecialY = MyCLng(txtY.Text)
    gbllSpecialZ = MyCLng(txtZ.Text)
    DoEvents
    subFormLoad False
End Sub

Private Sub Form_Activate()
    gblbCharacterNameIDOverride = True
    gbllFormActivated = 1301
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subFormLoad True
    btmrReloadMap = False
End Sub
Private Sub Form_Deactivate()
    gblbHumanRan = False
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub subFormLoad(bRecord As Boolean)
    If (Len(gblzClipTitle) <> 0) Then frmMapEventLocation.Caption = gblzClipTitle
    txtX.Text = gbllSpecialX
    txtY.Text = gbllSpecialY
    txtZ.Text = gbllSpecialZ
    DoEvents
    
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "L"
    
    subMapperSize cstzMapSizeType
    subUpdateMapper
    
    If (bRecord) Then subSaveGridMaster
    subPopulateGridMaster
End Sub
Private Sub subSaveGridMaster()
On Error GoTo Err_Check
    Dim zAreaWhere As String
    Dim zPlayerDesc As String
    Dim zDate As String
    Dim zTime As String
    
    If (Not gblbHumanRan) Then
        zAreaWhere = gblzClipTitle
        If (Len(zAreaWhere) <> 0) Then
            zPlayerDesc = gblzCharacterName
            zDate = Format(Date, "MMM DD, YYYY")
            zTime = Format(time(), "HH:NN:SS")
            MyDB.Execute "INSERT INTO tblGridMaster ( GridMasterX, GridMasterY, GridMasterZ, GridMasterWhere, GridMasterDesc, GridCreatedTime, GridCreatedDate ) SELECT " & gbllSpecialX & ", " & gbllSpecialY & ", " & gbllSpecialZ & ", '" & zAreaWhere & "', '" & zPlayerDesc & "', '" & zDate & "', '" & zTime & "';", dbFailOnError
        End If
    End If
    DoEvents
    Exit Sub
Err_Check:
    MsgBox "subPopulateGridMaster," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub subPopulateGridMaster()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zWhere As String
    Dim zDesc As String
    Dim zTime As String
    Dim zDate As String
    lstGridMaster.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT GridMasterID, GridMasterX, GridMasterY, GridMasterZ, GridMasterWhere, GridMasterDesc, GridCreatedTime, GridCreatedDate FROM tblGridMaster ORDER BY GridMasterID DESC;", dbOpenSnapshot) 'we do not use CharacterID here
    Do While (Not rsSetUp.EOF)
        lX = rsSetUp!GridMasterX
        lY = rsSetUp!GridMasterY
        lZ = rsSetUp!GridMasterZ
        zDesc = rsSetUp!GridMasterDesc
        zWhere = rsSetUp!GridMasterWhere
        zTime = rsSetUp!GridCreatedTime
        zDate = rsSetUp!GridCreatedDate
        lstGridMaster.AddItem lX & " " & lY & " " & lZ & " " & zWhere
        lstGridMaster.ItemData(lstGridMaster.NewIndex) = rsSetUp!GridMasterID
        rsSetUp.MoveNext
    Loop
    Set rsSetUp = Nothing
    DoEvents
    Exit Sub
Err_Check:
    MsgBox "subPopulateGridMaster," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub cmdDeleteGridMasterSelection_Click()
    'MsgBox "work in progress" & vbCrLf & lstGridMaster.List(lstGridMaster.ListIndex) & vbCrLf & lstGridMaster.ItemData(lstGridMaster.ListIndex)
    If (lstGridMaster.ListIndex <> -1) Then
        If (MsgBox("Delete this selection?", vbYesNo) = vbYes) Then
            If (lstGridMaster.ListIndex <> -1) Then
                MyDB.Execute "DELETE GridMasterID FROM tblGridMaster WHERE (GridMasterID=" & lstGridMaster.ItemData(lstGridMaster.ListIndex) & ");", dbFailOnError
                subPopulateGridMaster
            Else
                Beep
            End If
        Else
            Beep
        End If
    Else
        Beep
    End If
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub lstGridMaster_DblClick()
    subLoadSelectedGridMaster
    picGridMaster.Visible = False
End Sub
Private Sub subLoadSelectedGridMaster()
On Error GoTo Err_Check
    Dim bOkay As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zWhere As String
    Dim zDesc As String
    Dim rsSetUp As Recordset
    
    bOkay = False
    If (lstGridMaster.ListIndex <> -1) Then
        Set rsSetUp = MyDB.OpenRecordset("SELECT GridMasterID, GridMasterX, GridMasterY, GridMasterZ, GridMasterWhere, GridMasterDesc FROM tblGridMaster WHERE (GridMasterID=" & lstGridMaster.ItemData(lstGridMaster.ListIndex) & ");", dbOpenSnapshot) 'we do not use CharacterID here
        If (Not rsSetUp.EOF) Then
            lX = rsSetUp!GridMasterX
            lY = rsSetUp!GridMasterY
            lZ = rsSetUp!GridMasterZ
            zDesc = rsSetUp!GridMasterDesc
            zWhere = rsSetUp!GridMasterWhere
            
            gbllSpecialX = lX
            gbllSpecialY = lY
            gbllSpecialZ = lZ
            gblzClipTitle = zWhere
            bOkay = True
        End If
        Set rsSetUp = Nothing
        If (bOkay) Then subFormLoad False
    Else
        Beep
    End If
    DoEvents
    Exit Sub
Err_Check:
    MsgBox "subLoadSelectedGridMaster," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub tmrMapperRefresh_Timer()
    If (btmrReloadMap) Then
        subtmrReloadMap
        btmrReloadMap = False
    End If
    If (gbllMapperTimerStatus) Then subUpdateMapper
End Sub
Private Sub subUpdateMapper()
    frmMapEventLocation.Cls
    subMakeTheGraphicalMap gbllCharacterNameID, gblzInfoXYZ, cstzMapSizeType
End Sub
Private Function lMid(zType As String) As Long
    Dim lReturn As Long
    Select Case zType
        Case "W", "X"
            lReturn = MyCLng((gbllSW / cstT2P) / 2)
        Case "H", "Y"
            lReturn = MyCLng((gbllSH / cstT2P) / 2) - 29
    End Select
    lMid = lReturn
End Function
Private Sub subMapperSize(zType As String)
    Select Case zType
        Case "SMALL"
            frmMapEventLocation.width = 16000
            frmMapEventLocation.height = 11000
            gbllSW = (frmMapEventLocation.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapEventLocation.height / 2) '(Screen.Height / 2)
        Case "LARGE"
            frmMapEventLocation.width = frmMain.width * 2
            frmMapEventLocation.height = frmMain.height * 2
            gbllSW = (frmMapEventLocation.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapEventLocation.height / 2) '(Screen.Height / 2)
    End Select
    
    frmMapEventLocation.Cls
    frmMapEventLocation.ScaleMode = cstPixel
    frmMapEventLocation.AutoRedraw = True
    frmMapEventLocation.width = gbllSW
    frmMapEventLocation.height = gbllSH
    frmMapEventLocation.FillStyle = vbSolid
    frmMapEventLocation.FillColor = &H80C0FF
    frmMapEventLocation.DrawWidth = 1
End Sub
Public Sub subMakeTheGraphicalMap(lCharacterNameID As Long, zInfoXYZ As String, zType As String)
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCX As Long 'True location of the player
    Dim lCY As Long
    Dim lCZ As Long
    
    lX = gbllSpecialX
    lY = gbllSpecialY
    lZ = gbllSpecialZ
    'Create Layered Map
    lCX = lX: lCY = lY: lCZ = lZ
    'Read the Map Location
    lZ = 0
    Select Case zType
        Case "SMALL"
            Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX) & " AND X<=" & lCX + (cstRangeX) & " AND Y>=" & lCY - cstRangeY & " AND Y<=" & lCY + cstRangeY & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
            Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                lX = rsSetUp!X
                lY = rsSetUp!Y
                lZ = rsSetUp!Z
                Select Case lCZ
                    Case lZ
                        frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                    Case Else
                        If (lZ - lCZ < 0) Then
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                        Else
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                        End If
                End Select
                rsSetUp.MoveNext
            Loop
            Set rsSetUp = Nothing
            frmMapEventLocation.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
        Case "LARGE"
            Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX + 5) & " AND X<=" & lCX + (cstRangeX + 5) & " AND Y>=" & lCY - ((cstRangeY * 2) + 2) & " AND Y<=" & lCY + ((cstRangeY * 2) + 2) & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
            Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                lX = rsSetUp!X
                lY = rsSetUp!Y
                lZ = rsSetUp!Z
                Select Case lCZ
                    Case lZ
                        frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                    Case Else
                        If (lZ - lCZ < 0) Then
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                        Else
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                        End If
                End Select
                rsSetUp.MoveNext
            Loop
            Set rsSetUp = Nothing
            frmMapEventLocation.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
    End Select
    Exit Sub
Err_Check:
    'MsgBox "MAPEVENTLOCATION:subMakeTheGraphicalMap," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub cmdPageLost_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "PAGE LOST" & vbCrLf & "PAGE CHESTS" & vbCrLf & "PAGE QUEST" & vbCrLf
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdEngage_Click()
On Error Resume Next
    If (gbllSpecialX + gbllSpecialY + gbllSpecialZ <> 0) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "SS BOARD" & vbCrLf & "SS NAVI " & MyCStr(gbllSpecialX) & " " & MyCStr(gbllSpecialY) & " " & MyCStr(gbllSpecialZ - lRandom(20)) & vbCrLf
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub txtX_Change()
    btmrReloadMap = True
End Sub
Private Sub txtX_LostFocus()
    txtX.Text = MyCLng(txtX.Text)
End Sub
Private Sub txtY_Change()
    btmrReloadMap = True
End Sub
Private Sub txtY_LostFocus()
    txtY.Text = MyCLng(txtY.Text)
End Sub
Private Sub txtZ_Change()
    btmrReloadMap = True
End Sub
Private Sub txtZ_LostFocus()
    txtZ.Text = MyCLng(txtZ.Text)
End Sub
