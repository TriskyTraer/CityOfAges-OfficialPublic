VERSION 5.00
Begin VB.Form frmMapEventLocation 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Mapper - Event Location "
   ClientHeight    =   4485
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7020
   FillStyle       =   0  'Solid
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMapEventLocation.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   4485
   ScaleWidth      =   7020
   Begin VB.CommandButton cmdOpenRight 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   0
      Picture         =   "frmMapEventLocation.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Visible         =   0   'False
      Width           =   280
   End
   Begin VB.Timer tmrMapperRefresh 
      Interval        =   555
      Left            =   0
      Top             =   120
   End
   Begin VB.TextBox txtX 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   1215
   End
   Begin VB.TextBox txtY 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1200
      TabIndex        =   2
      Top             =   0
      Width           =   1215
   End
   Begin VB.TextBox txtZ 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2400
      TabIndex        =   3
      Top             =   0
      Width           =   1215
   End
End
Attribute VB_Name = "frmMapEventLocation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstzMapSizeType = "SMALL"
Const cstRangeX = 26
Const cstRangeY = 18
Const cstSize = 5 'Cannot be less than 5 and must be an odd number
Const cstT2P = 15 '15 twips to 1 pixel
Const cstPixel = 3
Dim bSendClientData As Boolean
Dim gbllX As Long
Dim gbllY As Long
Dim gbllSW As Long
Dim gbllSH As Long
Dim gbllOMeLeft As Long
Dim gbllOMeTop As Long
Private Sub Form_Activate()
    gblbCharacterNameIDOverride = True
    gbllFormActivated = 1301
    subWindowsPosition Me, "S"
    If (bSendClientData) Then frmMain.txtSendClientData.SetFocus
    bSendClientData = False
End Sub
Private Sub Form_Deactivate()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    DoEvents
    txtX.Text = gbllSpecialX
    txtY.Text = gbllSpecialY
    txtZ.Text = gbllSpecialZ
    DoEvents
    
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "L"
    bSendClientData = True 'frmMain.txtSendClientData.SetFocus
    
    subMapperSize cstzMapSizeType
    subUpdateMapper
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_DblClick()
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub tmrMapperRefresh_Timer()
    If (gbllMapperTimerStatus) Then subUpdateMapper
End Sub

Private Sub Form_Click()
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub subUpdateMapper()
    frmMapEventLocation.Cls
    subMakeTheGraphicalMap gbllCharacterNameID, gblzInfoXYZ, cstzMapSizeType
    If (gbllMapperTimerStatus And gbllMapperAutoFocus) Then frmMain.txtSendClientData.SetFocus
End Sub

Private Function lMid(zType As String) As Long
    Dim lReturn As Long
    Select Case zType
        Case "W", "X"
            lReturn = MyCLng((gbllSW / cstT2P) / 2)
        Case "H", "Y"
            lReturn = MyCLng((gbllSH / cstT2P) / 2) - 29
    End Select
    lMid = lReturn
End Function

Private Sub subMapperSize(zType As String)
    Select Case zType
        Case "SMALL"
            frmMapEventLocation.width = 16000
            frmMapEventLocation.height = 11000
            gbllSW = (frmMapEventLocation.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapEventLocation.height / 2) '(Screen.Height / 2)
        Case "LARGE"
            frmMapEventLocation.width = frmMain.width * 2
            frmMapEventLocation.height = frmMain.height * 2
            gbllSW = (frmMapEventLocation.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapEventLocation.height / 2) '(Screen.Height / 2)
    End Select
    
    frmMapEventLocation.Cls
    frmMapEventLocation.ScaleMode = cstPixel
    frmMapEventLocation.AutoRedraw = True
    frmMapEventLocation.width = gbllSW
    frmMapEventLocation.height = gbllSH
    frmMapEventLocation.FillStyle = vbSolid
    frmMapEventLocation.FillColor = &H80C0FF
    frmMapEventLocation.DrawWidth = 1
End Sub

Public Sub subMakeTheGraphicalMap(lCharacterNameID As Long, zInfoXYZ As String, zType As String)
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCX As Long 'True location of the player
    Dim lCY As Long
    Dim lCZ As Long
    
    lX = gbllSpecialX
    lY = gbllSpecialY
    lZ = gbllSpecialZ
    'Create Layered Map
    lCX = lX: lCY = lY: lCZ = lZ
    'Read the Map Location
    lZ = 0
    Select Case zType
        Case "SMALL"
            Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX) & " AND X<=" & lCX + (cstRangeX) & " AND Y>=" & lCY - cstRangeY & " AND Y<=" & lCY + cstRangeY & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
            Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                lX = rsSetUp!X
                lY = rsSetUp!Y
                lZ = rsSetUp!Z
                Select Case lCZ
                    Case lZ
                        frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                    Case Else
                        If (lZ - lCZ < 0) Then
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                        Else
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                        End If
                End Select
                rsSetUp.MoveNext
            Loop
            Set rsSetUp = Nothing
            frmMapEventLocation.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
        Case "LARGE"
            Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX + 5) & " AND X<=" & lCX + (cstRangeX + 5) & " AND Y>=" & lCY - ((cstRangeY * 2) + 2) & " AND Y<=" & lCY + ((cstRangeY * 2) + 2) & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
            Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                lX = rsSetUp!X
                lY = rsSetUp!Y
                lZ = rsSetUp!Z
                Select Case lCZ
                    Case lZ
                        frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                    Case Else
                        If (lZ - lCZ < 0) Then
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                        Else
                            frmMapEventLocation.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                        End If
                End Select
                rsSetUp.MoveNext
            Loop
            Set rsSetUp = Nothing
            frmMapEventLocation.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
    End Select
    Exit Sub
Err_Check:
    MsgBox "subMakeTheGraphicalMap," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub



