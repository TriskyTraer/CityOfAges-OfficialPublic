Attribute VB_Name = "modVT100ANSI"
Option Explicit
Public Declare Function BitBlt Lib "gdi32.dll" (ByVal hdcDest As Long, ByVal nXDest As Long, ByVal nYDest As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hdcSrc As Long, ByVal nXSrc As Long, ByVal nYSrc As Long, ByVal dwRop As Long) As Long
Private Declare Function CreateSolidBrush Lib "gdi32.dll" (ByVal crColor As Long) As Long
Private Declare Function DeleteObject Lib "gdi32.dll" (ByVal hObject As Long) As Long
Private Declare Function SelectObject Lib "gdi32.dll" (ByVal hdc As Long, ByVal hObject As Long) As Long
Declare Function PatBlt Lib "gdi32" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal dwRop As Long) As Long
Public Const PATCOPY = &HF00021
Private Declare Function SetTextColor Lib "gdi32" (ByVal hdc As Long, ByVal crColor As Long) As Long

Private Declare Function TextOut Lib "gdi32" Alias "TextOutA" (ByVal hdc As Long, ByVal X As Long, ByVal Y As Long, ByVal lpString As String, ByVal nCount As Long) As Long
Private Declare Function Beep Lib "kernel32.dll" (ByVal dwFreq As Long, ByVal dwDuration As Long) As Long

Public Const DSTINVERT = &H550009
Public Const SRCCOPY = &HCC0020

Public Const cstlMaxHeightChars = 50
Public gbllMaxHeightChars As Long 'cannot be more than cstlMaxHeightChars - 2
Public Const gblcstiTerminalWidthMAX = 79 '0 to 79 for X

'Store Default colors
Public gbllreg(30 To 37) As Long
Public gbllbold(30 To 37) As Long

Type Cur
    X As Integer
    Y As Integer
    Visible As Boolean
    Reverse As Boolean
End Type
Type Char
    width As Integer
    height As Integer
End Type
Type TermAttr
    XOFF As Boolean
    LNM As Boolean 'True = Set, False = Reset
    Wordwrap As Boolean 'True = Set, False = Reset
    Blink As Boolean
    Bold As Boolean
    Invisible As Boolean
    Reverse As Boolean
    Underline As Boolean
    ForeColor As Long
    BackColor As Long
End Type
Type CharAttr
    Text As Byte
    Bold As Boolean
    Blink As Boolean
    Underline As Boolean
    Reverse As Boolean
    Invisible As Boolean
    ForeColor As Long
    BackColor As Long
End Type
Type Brush
    Black As Long
    Red As Long
    Green As Long
    Yellow As Long
    Blue As Long
    Magenta As Long
    Cyan As Long
    White As Long
    Gray As Long
End Type

Public Terminal As PictureBox 'Terminal.Picture = LoadPicture("C:\Users\Traer\Desktop\CityofAgesSE\CoA\coaclient\pictures\M1.bmp")
Public Character As Char
Public Cursor As Cur, CursorSave As Cur
Public TerminalAttribute As TermAttr
Public InEscape As Boolean, ReceivingData As Boolean
Public EscString As String
Public Tabs(19) As Integer, BlinkSentry As Integer
Public TabNum As Integer
Public TerminalChar(cstlMaxHeightChars, gblcstiTerminalWidthMAX) As CharAttr
Public Color As Brush
'=============================================================================================================================
'=============================================================================================================================
Public Sub subfrmMainSetUp(bShow As Boolean) 'see also: subOrganizeMainTerminalForm subSetUpTerminal
    lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN)
    lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN)
    bgblLapTopMode = (lgblScreenHeight < 1000)
    frmMain.height = ((gbllMaxHeightChars * gbllFontSize) * 21) + lgblValSpread + 99 'This controls the MAIN FORM SIZE of frmMain
    frmMain.width = (frmMain.picTerm.width * Screen.TwipsPerPixelX)  'This controls the MAIN FORM SIZE of frmMain
    frmMain.frameConnection.Top = (frmMain.height / Screen.TwipsPerPixelX) - 60
    frmMain.txtSendClientData.width = (frmMain.picTerm.width * Screen.TwipsPerPixelX) - 250
    frmMain.frameConnection.width = frmMain.txtSendClientData.width + 50
    mdiMain.Show
    frmMain.subSetFrames
    If (bShow) Then MsgBox "H = " & lgblScreenHeight & " W = " & lgblScreenWidth
End Sub
Public Sub subSetUpTerminal()
    Dim rsSetUp As Recordset
    gblzFontName = "TERMINAL"
    gbllFontSize = 14
    gbllMaxHeightChars = cstlMaxHeightChars - 5
    gbldLengthTerminalMultiplier = 2
    gblbFlashCursor = False
    gblzAddress = "127.0.0.1"
    gblzPort = "23"
    gblzKeyDivide = "EQUIPMENT"
    gblzKeyMultiply = "INVENTORY"
    gblzKeySubtract = "UP"
    gblzKeyAdd = "DOWN"
    gblzKeyDecimal = "LIST"
    gblzKeyNumpad0 = "MAP"
    gblzKeyNumpad1 = "SW"
    gblzKeyNumpad2 = "SOUTH"
    gblzKeyNumpad3 = "SE"
    gblzKeyNumpad4 = "WEST"
    gblzKeyNumpad5 = "LOOK"
    gblzKeyNumpad6 = "EAST"
    gblzKeyNumpad7 = "NW"
    gblzKeyNumpad8 = "NORTH"
    gblzKeyNumpad9 = "NE"
    gblzKeyF1 = "X" 'character sheet
    gblbSoundAllowed = True
    
    basStoreMDBLocationToMemory True ' Load MDB location to memory plus show error messages.
    
    lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN)
    lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN)
    bgblLapTopMode = (lgblScreenHeight < 1000)

    Set rsSetUp = MyDB.OpenRecordset("SELECT FontName, FontSize, MaxHeightChars, LengthTerminalMultiplier, FlashCursor FROM tblClientSetUp;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        gblzFontName = rsSetUp!FontName
        gbllFontSize = rsSetUp!FontSize
        gbllMaxHeightChars = rsSetUp!MaxHeightChars - 3 'if the line in the terminal is too long in vertical lines subtract one or two more here
        gbldLengthTerminalMultiplier = rsSetUp!LengthTerminalMultiplier
        gblbFlashCursor = rsSetUp!FlashCursor
    Else
        MyDB.Execute "INSERT INTO tblClientSetUp ( FontName, FontSize, MaxHeightChars, LengthTerminalMultiplier, FlashCursor ) SELECT '" & gblzFontName & "', " & gbllFontSize & ", " & gbllMaxHeightChars & ", " & gbldLengthTerminalMultiplier & ", " & gblbFlashCursor & ";", dbFailOnError
    End If
    Set rsSetUp = Nothing
    
    Set rsSetUp = MyDB.OpenRecordset("SELECT Address, Port FROM tblSystemSetUp WHERE Selected=True;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        gblzAddress = rsSetUp!Address
        gblzPort = rsSetUp!Port
    Else
        MyDB.Execute "INSERT INTO tblSystemSetUp ( Address, Port, Selected ) SELECT '" & gblzAddress & "', '" & gblzPort & "', True;", dbFailOnError
    End If
    Set rsSetUp = Nothing
    
    Call TermInitialize
End Sub
Public Sub subOrganizeMainTerminalForm()
    Const bcstDebugger = False
    Dim rsFonts As Recordset 'see also: subfrmMainSetUp subSetUpTerminal
    Dim bOkay As Boolean
    Dim zFontLookUpText As String
    Dim lFontValueMin As Long
    Dim lFontValueMax As Long
    Dim lFontHeightAdjust As Long
    frmMain!txtSendClientData.Text = ""
    lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN)
    lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN)
    bgblLapTopMode = (lgblScreenHeight < 1000)
    If (bgblLapTopMode) Then gbllMaxHeightChars = (cstlMaxHeightChars / 2)
    If (gbllFontSize < 5) Then gbllFontSize = 8 'this must be <5 and set to default 8 here prevents a bug
    If (gbllFontSize > 24) Then gbllFontSize = 24
    
    'WE MAKE FONTS HERE::
    'OVERRIDE #1
    Select Case gbllFontSize
        Case 5
            lgblValSpread = gbllFontSize * 350
        Case 6
            lgblValSpread = gbllFontSize * 240
        Case 7
            lgblValSpread = gbllFontSize * 230
        Case 8
            lgblValSpread = gbllFontSize * 280
        Case 9
            lgblValSpread = gbllFontSize * 210
        Case 10
            lgblValSpread = gbllFontSize * 200
        Case 11
            lgblValSpread = gbllFontSize * 190
        Case 12
            lgblValSpread = gbllFontSize * 180
        Case 13
            lgblValSpread = gbllFontSize * 170
        Case 14
            lgblValSpread = gbllFontSize * 180
        Case 15
            lgblValSpread = gbllFontSize * 150
        Case 16
            lgblValSpread = gbllFontSize * 140
        Case 17
            lgblValSpread = gbllFontSize * 130
        Case 18
            lgblValSpread = gbllFontSize * 120
        Case 19
            lgblValSpread = gbllFontSize * 135
        Case 20
            lgblValSpread = gbllFontSize * 150
        Case 21
            lgblValSpread = gbllFontSize * 150
        Case 22
            lgblValSpread = gbllFontSize * 110
        Case 23
            lgblValSpread = gbllFontSize * 125
        Case 24
            lgblValSpread = gbllFontSize * 140
        Case 25 To 99
            lgblValSpread = gbllFontSize * 110
        Case Else
            lgblValSpread = gbllFontSize * 500 'default
    End Select
    
    'OVERRIDE #2
    'Defaults by part matching name INSTR
    'If (InStr(gblzFontName, "ARIAL") <> 0) Then
    '    lgblValSpread = gbllFontSize * 400 'default
    'End If
    
    If bcstDebugger Then Debug.Print "1// vs[" & lgblValSpread & "] fs[" & gbllFontSize & "]"
    
    'OVERRIDE #3
    Select Case gblzFontName 'Defaults by exact name CASE STATEMENT
        Case "ARIAL"
            Select Case gbllFontSize
                Case 5
                    lgblValSpread = gbllFontSize * 200
                Case 6
                    lgblValSpread = gbllFontSize * 340
                Case 7
                    lgblValSpread = gbllFontSize * 350
                Case 8
                    lgblValSpread = gbllFontSize * 220
                Case 9
                    lgblValSpread = gbllFontSize * 290
                Case 10
                    lgblValSpread = gbllFontSize * 230
                Case 11
                    lgblValSpread = gbllFontSize * 190
                Case 12
                    lgblValSpread = gbllFontSize * 150
                Case 14
                    lgblValSpread = gbllFontSize * 170
                Case 16
                    lgblValSpread = gbllFontSize * 120
                Case 18
                    lgblValSpread = gbllFontSize * 120
                Case 20
                    lgblValSpread = gbllFontSize * 185
                Case 22
                    lgblValSpread = gbllFontSize * 115
                Case 24
                    lgblValSpread = gbllFontSize * 105
                Case 25 To 99
                    lgblValSpread = gbllFontSize * 105
                Case Else
                    lgblValSpread = gbllFontSize * 500 'default
            End Select
        Case "ARIAL BLACK"
            Select Case gbllFontSize
                Case 5
                    lgblValSpread = gbllFontSize * 600
                Case 6
                    lgblValSpread = gbllFontSize * 460
                Case 7
                    lgblValSpread = gbllFontSize * 440
                Case 8
                    lgblValSpread = gbllFontSize * 460
                Case 9
                    lgblValSpread = gbllFontSize * 440
                Case 10
                    lgblValSpread = gbllFontSize * 370
                Case 11
                    lgblValSpread = gbllFontSize * 500
                Case 12
                    lgblValSpread = gbllFontSize * 440
                Case 14
                    lgblValSpread = gbllFontSize * 440
                Case 16
                    lgblValSpread = gbllFontSize * 390
                Case 18
                    lgblValSpread = gbllFontSize * 350
                Case 20
                    lgblValSpread = gbllFontSize * 390
                Case 22
                    lgblValSpread = gbllFontSize * 360
                Case 24
                    lgblValSpread = gbllFontSize * 370
                Case 25 To 99
                    lgblValSpread = gbllFontSize * 280
                Case Else
                    lgblValSpread = gbllFontSize * 500 'default
            End Select
        Case "MS SANS SERIF"
            Select Case gbllFontSize
                Case 5
                    lgblValSpread = gbllFontSize * 350
                Case 6
                    lgblValSpread = gbllFontSize * 240
                Case 7
                    lgblValSpread = gbllFontSize * 230
                Case 8
                    lgblValSpread = gbllFontSize * 280
                Case 9
                    lgblValSpread = gbllFontSize * 210
                Case 10
                    lgblValSpread = gbllFontSize * 200
                Case 11
                    lgblValSpread = gbllFontSize * 190
                Case 12
                    lgblValSpread = gbllFontSize * 180
                Case 13
                    lgblValSpread = gbllFontSize * 170
                Case 14
                    lgblValSpread = gbllFontSize * 180
                Case 15
                    lgblValSpread = gbllFontSize * 150
                Case 16
                    lgblValSpread = gbllFontSize * 140
                Case 17
                    lgblValSpread = gbllFontSize * 130
                Case 18
                    lgblValSpread = gbllFontSize * 120
                Case 19
                    lgblValSpread = gbllFontSize * 135
                Case 20
                    lgblValSpread = gbllFontSize * 150
                Case 21
                    lgblValSpread = gbllFontSize * 150
                Case 22
                    lgblValSpread = gbllFontSize * 110
                Case 23
                    lgblValSpread = gbllFontSize * 125
                Case 24
                    lgblValSpread = gbllFontSize * 140
                Case 25 To 99
                    lgblValSpread = gbllFontSize * 110
                Case Else
                    lgblValSpread = gbllFontSize * 500 'default
            End Select
        Case "MODERN"
            Select Case gbllFontSize
                Case 5
                    lgblValSpread = gbllFontSize * 350
                Case 6
                    lgblValSpread = gbllFontSize * 240
                Case 7
                    lgblValSpread = gbllFontSize * 230
                Case 8
                    lgblValSpread = gbllFontSize * 280
                Case 9
                    lgblValSpread = gbllFontSize * 210
                Case 10
                    lgblValSpread = gbllFontSize * 200
                Case 11
                    lgblValSpread = gbllFontSize * 190
                Case 12
                    lgblValSpread = gbllFontSize * 180
                Case 13
                    lgblValSpread = gbllFontSize * 170
                Case 14
                    lgblValSpread = gbllFontSize * 180
                Case 15
                    lgblValSpread = gbllFontSize * 150
                Case 16
                    lgblValSpread = gbllFontSize * 140
                Case 17
                    lgblValSpread = gbllFontSize * 130
                Case 18
                    lgblValSpread = gbllFontSize * 120
                Case 19
                    lgblValSpread = gbllFontSize * 135
                Case 20
                    lgblValSpread = gbllFontSize * 150
                Case 21
                    lgblValSpread = gbllFontSize * 150
                Case 22
                    lgblValSpread = gbllFontSize * 110
                Case 23
                    lgblValSpread = gbllFontSize * 125
                Case 24
                    lgblValSpread = gbllFontSize * 140
                Case 25 To 99
                    lgblValSpread = gbllFontSize * 110
                Case Else
                    lgblValSpread = gbllFontSize * 500 'default
            End Select
        Case "ROMAN"
            Select Case gbllFontSize
                Case 5
                    lgblValSpread = gbllFontSize * 320
                Case 6
                    lgblValSpread = gbllFontSize * 240
                Case 7
                    lgblValSpread = gbllFontSize * 190
                Case 8
                    lgblValSpread = gbllFontSize * 280
                Case 9
                    lgblValSpread = gbllFontSize * 210
                Case 10
                    lgblValSpread = gbllFontSize * 160
                Case 11
                    lgblValSpread = gbllFontSize * 180
                Case 12
                    lgblValSpread = gbllFontSize * 140
                Case 14
                    lgblValSpread = gbllFontSize * 180
                Case 16
                    lgblValSpread = gbllFontSize * 130
                Case 18
                    lgblValSpread = gbllFontSize * 120
                Case 20
                    lgblValSpread = gbllFontSize * 150
                Case 22
                    lgblValSpread = gbllFontSize * 110
                Case 24
                    lgblValSpread = gbllFontSize * 135
                Case 25 To 99
                    lgblValSpread = gbllFontSize * 160
                Case Else
                    lgblValSpread = gbllFontSize * 500 'default
            End Select
        Case "MS SANS SERIF"
            lgblValSpread = gbllFontSize * 400 'put back the default
            lgblValSpread = lgblValSpread * 2
            lgblValSpread = lgblValSpread + 1600
        Case "DEJAVU SANS"
            lgblValSpread = gbllFontSize * 400 'put back the default
            lgblValSpread = lgblValSpread * 2
            lgblValSpread = lgblValSpread + 400
        Case "CAMBRIA"
            lgblValSpread = gbllFontSize * 400 'put back the default
            lgblValSpread = lgblValSpread * 3
        Case "COURIER NEW"
            lgblValSpread = gbllFontSize * 350 'default
            If (gbllFontSize >= 5) Then lgblValSpread = gbllFontSize * 350
            If (gbllFontSize > 8) Then lgblValSpread = gbllFontSize * 260
            If (gbllFontSize > 9) Then lgblValSpread = gbllFontSize * 220
            If (gbllFontSize > 11) Then lgblValSpread = gbllFontSize * 200
            If (gbllFontSize > 16) Then lgblValSpread = gbllFontSize * 190
            If (gbllFontSize > 18) Then lgblValSpread = gbllFontSize * 175
            If (gbllFontSize > 20) Then lgblValSpread = gbllFontSize * 160
            If (gbllFontSize > 22) Then lgblValSpread = gbllFontSize * 100
        Case "EBRIMA"
            lgblValSpread = gbllFontSize * 400 'put back the default
            lgblValSpread = lgblValSpread * 6
        Case "TAHOMA"
            lgblValSpread = gbllFontSize * 200 'put back the default
            lgblValSpread = lgblValSpread + 450
    End Select
    
    'OVERRIDE #4
    'The User can also make their own override value
    bOkay = False
    Set rsFonts = MyDB.OpenRecordset("SELECT FontLookUpText, FontValueMin, FontValueMax, FontHeightAdjust FROM tblFontLookup ORDER BY FontLookUpText;", dbOpenSnapshot)
    Do While (Not rsFonts.EOF And Not bOkay)
        zFontLookUpText = UCase(MyCStr(rsFonts!FontLookUpText))
        lFontValueMin = MyCLng(rsFonts!FontValueMin)
        lFontValueMax = MyCLng(rsFonts!FontValueMax)
        
        If (InStr(gblzFontName, zFontLookUpText) > 0) Then
            If (lFontValueMin <= gbllFontSize And lFontValueMax >= gbllFontSize) Then
                bOkay = True
                'lgblValSpread = gbllFontSize * 400 'put back the default
                lgblValSpread = MyCLng(rsFonts!FontHeightAdjust) 'Override
                If bcstDebugger Then Debug.Print "FONT MATCH = " & gblzFontName & " " & gbllFontSize & " vs[" & lgblValSpread & "] fs[" & gbllFontSize & "]"
            End If
        End If
        'If (Screen.Height / Screen.TwipsPerPixelY > 790) Then lgblValSpread = lgblValSpread + 200
        rsFonts.MoveNext
    Loop
    Set rsFonts = Nothing

    subfrmMainSetUp False
    If bcstDebugger Then Debug.Print "2// vs[" & lgblValSpread & "] fs[" & gbllFontSize & "]"
End Sub

Public Sub subEventTextProcessing(zLine As String)
    Dim rsEventText As Recordset
    Set rsEventText = MyDB.OpenRecordset("SELECT EventMatchingText, EventProgrammedReply FROM tblEventText;", dbOpenSnapshot)
    If (Not rsEventText.EOF) Then
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData MyCStr(rsEventText!EventProgrammedReply) & vbCrLf
    End If
    Set rsEventText = Nothing
End Sub

Public Sub TermInitialize()
On Error Resume Next
    Dim X As Integer
    Dim Y As Integer
    Set Terminal = frmMain.picTerm
    frmMain.ScaleMode = 3 'Pixel is 3
    Terminal.ScaleMode = 3 'Pixel is 3
    If (Len(gblzFontName) = 0) Then 'error detected
        gblzFontName = "ARIAL"
        gbllFontSize = 10
    End If
    Terminal.FontName = gblzFontName
    Terminal.FontSize = gbllFontSize
    Character.height = Terminal.TextHeight("O")
    Character.width = Terminal.TextWidth("O")
    
    BlinkSentry = 0
    Terminal.Cls
    Terminal.Refresh
    With Cursor
        .X = 0
        .Y = 0
        .Visible = gblbFlashCursor
        .Reverse = False
    End With
    With CursorSave
        .X = 0
        .Y = 0
        .Visible = gblbFlashCursor
        .Reverse = False
    End With
    InEscape = False
    ReceivingData = False
    With Terminal
        .Top = 0
        .Left = 0
        .width = (80 * Character.width) + 8
        .height = (((25 * Character.height)) * gbldLengthTerminalMultiplier) - 8
        .ForeColor = QBColor(8)
        .BackColor = QBColor(0)
    End With
    With TerminalAttribute
        .XOFF = False
        .LNM = False
        .Wordwrap = False
        .Blink = False
        .Bold = False
        .Invisible = False
        .Reverse = False
        .Underline = False
        .ForeColor = Terminal.ForeColor
        .BackColor = Terminal.BackColor
    End With
    For Y = 0 To gbllMaxHeightChars - 1
        For X = 0 To gblcstiTerminalWidthMAX
            With TerminalChar(Y, X)
                .Blink = False
                .Bold = False
                .Invisible = False
                .Reverse = False
                .Text = 32
                .Underline = False
                .ForeColor = Terminal.ForeColor
                .BackColor = Terminal.BackColor
            End With
        Next
    Next
    For X = 0 To 19
        Tabs(X) = X * 4
    Next
    TabNum = 0
    With Color
        .Black = CreateSolidBrush(vbBlack)
        .Blue = CreateSolidBrush(vbBlue)
        .Cyan = CreateSolidBrush(vbCyan)
        .Gray = CreateSolidBrush(QBColor(8))
        .Green = CreateSolidBrush(vbGreen)
        .Magenta = CreateSolidBrush(vbMagenta)
        .Red = CreateSolidBrush(vbRed)
        .White = CreateSolidBrush(vbWhite)
        .Yellow = CreateSolidBrush(vbYellow)
    End With
    
    subDefaultTerminalColours False
End Sub

Public Sub subDefaultTerminalColours(bLoadMessage As Boolean)
    'terminal colors defaulted
    gbllreg(30) = 8421504
    gbllbold(30) = 8421504
    gbllreg(31) = 217
    gbllbold(31) = 255
    gbllreg(32) = 34615
    gbllbold(32) = 47415
    gbllreg(33) = 30840
    gbllbold(33) = 38550
    gbllreg(34) = 16736586
    gbllbold(34) = 16728100
    gbllreg(35) = 12862095
    gbllbold(35) = 13325980
    gbllreg(36) = 13153606
    gbllbold(36) = 13550165
    gbllreg(37) = 6250335
    gbllbold(37) = 10197915
    If (bLoadMessage) Then MsgBox "You still have to save.", vbOKOnly
End Sub
Public Sub TermProcessInput(ByteIn As Byte)
    If TerminalAttribute.XOFF = False Then
        Cursor.Visible = False
        If (InEscape) Then
            Call TermProcessEscapeSequence(ByteIn)
        Else
            EscString = ""
            Select Case ByteIn
                Case 0 'NUL - Ignored on input
                Case 4 'EOT - End of Transmission
                    Call frmMain.Disconnect
                Case 5 'ENQ - Transmit answerback message
                    'Debug.Print "ENQ - Transmit answerback message"
                Case 7 'BEL - Sound bell tone
                    Call Beep(700, 250)
                Case 8 'BS - Move cursor left one character position
                    Cursor.X = Cursor.X - 1
                    Call TermCheckCursor
                Case 9 'HT - Move to next tab stop, or to right margin if no more tab stops
                    If TabNum = 19 Then
                        Cursor.X = gblcstiTerminalWidthMAX
                    Else
                        TabNum = TabNum + 1
                        Cursor.X = Tabs(TabNum)
                    End If
                Case 10, 11, 12 'LF, VT, FF, - line feed or new line operation when in new line mode
                    If Cursor.Y >= gbllMaxHeightChars Then
                        Call TermScrollUp
                        Cursor.Y = gbllMaxHeightChars
                        If TerminalAttribute.LNM = True Then 'If new line mode
                            Cursor.X = 0
                        End If
                    Else
                        Cursor.Y = Cursor.Y + 1
                        If TerminalAttribute.LNM = True Then 'If new line mode
                            Cursor.X = 0
                        End If
                    End If
                    Call TermCheckCursor
                Case 13 'CR - Move the cursor to the left margin on the current line
                    Cursor.X = 0
                Case 14 'SO - Invoke G1 character set, as designated by SCS escape sequence
                    'Debug.Print "SO - Invoke G1 character set, as designated by SCS escape sequence"
                Case 15 'SI - Select G0 character set, as selected by escape sequence
                    'Debug.Print "SI - Select G0 character set, as selected by escape sequence"
                Case 17 'XON - OK to Resume transmission
                    TerminalAttribute.XOFF = False
                Case 19 'XOFF - Stop transmission except for XOFF and XON escape sequences
                    TerminalAttribute.XOFF = True
                Case 24 'CAN - Immediately terminate control sequence, and display error character
                    'Debug.Print "CAN - Immediately terminate control sequence, and display error character"
                Case 26 'SUB - Interpreted as CAN
                    'Debug.Print "SUB - Interpreted as CAN"
                Case 27 'ESC - Invoke an escape sequence
                    InEscape = True
                Case Else 'Bytes to display on Terminal screen
                    Call TermCheckCursor
                    With TerminalChar(Cursor.Y, Cursor.X)
                        .BackColor = TerminalAttribute.BackColor
                        .Blink = TerminalAttribute.Blink
                        .Bold = TerminalAttribute.Bold
                        .ForeColor = TerminalAttribute.ForeColor
                        .Invisible = TerminalAttribute.Invisible
                        .Reverse = TerminalAttribute.Reverse
                        .Text = ByteIn 'WE PRINT EACH INDIVIDUAL CHARACTER HERE
                        .Underline = TerminalAttribute.Underline
                    End With
                    Cursor.X = Cursor.X + 1
                    Call TermCheckCursor
            End Select
        End If
        Cursor.Visible = gblbFlashCursor 'do not flash cursor
    Else
        If ByteIn = 17 Then 'XON - OK to Resume transmission
            TerminalAttribute.XOFF = False
        End If
    End If
End Sub

Private Sub TermProcessEscapeSequence(ByteIn As Byte)
    Dim X As Integer, Y As Integer, Z As Integer
    If EscString = "" Then 'If no Control Sequence Introducer exists...
        Select Case Chr$(ByteIn)
            Case "[", "(", ")", "#"
                EscString = EscString & Chr$(ByteIn)
            Case "Z" 'DECID - Identify Terminal
                Call TermSendData(Chr(27) & "[?1;0c")
                InEscape = False
            Case "=" 'DECKPAM - Keypad Application Mode
                InEscape = False
            Case ">" 'DECKPNM - Keypad Numeric Mode
                InEscape = False
            Case "8" 'DECRC - Restore Cursor
                With Cursor
                    .X = CursorSave.X
                    .Y = CursorSave.Y
                    .Reverse = CursorSave.Reverse
                    .Visible = CursorSave.Visible
                End With
                Call TermCheckCursor
                InEscape = False
            Case "7" 'DECSC - Save Cursor
                With CursorSave
                    .X = Cursor.X
                    .Y = Cursor.Y
                    .Reverse = Cursor.Reverse
                    .Visible = Cursor.Visible
                End With
                InEscape = False
            Case "H" 'HTS - Horizontal Tabulation Set
                If TabNum >= 19 Then
                    Tabs(19) = Cursor.X
                    TabNum = 19
                Else
                    Tabs(TabNum) = Cursor.X
                    TabNum = TabNum + 1
                End If
                InEscape = False
            Case "D" 'IND - Index
                If Cursor.Y >= gbllMaxHeightChars Then
                    Call TermScrollUp
                    Cursor.Y = gbllMaxHeightChars
                Else
                    Cursor.Y = Cursor.Y + 1
                End If
                Call TermCheckCursor
                InEscape = False
            Case "E" 'NEL - Next Line
                If Cursor.Y >= gbllMaxHeightChars Then
                    Call TermScrollUp
                    Cursor.Y = gbllMaxHeightChars
                Else
                    Cursor.Y = Cursor.Y + 1
                End If
                Cursor.X = 0
                Call TermCheckCursor
                InEscape = False
            Case "M" 'RI - Reverse Index
                If Cursor.Y <= 0 Then
                    'Call TermScrollDown
                    Cursor.Y = 0
                Else
                    Cursor.Y = Cursor.Y - 1
                End If
                Call TermCheckCursor
                InEscape = False
            Case "c" 'RIS - Reset to Initial State
                Call TermInitialize
                InEscape = False
            Case Else
                InEscape = False
        End Select
    Else 'If a Control Sequence Introducer exists...
        EscString = EscString & Chr$(ByteIn)
        Select Case Left(EscString, 1)
            Case "["
                Select Case Right(EscString, 1)
                    Case "D" 'CUB - Cursor Backward
                        If Len(EscString) = 2 Then 'if no parameter value
                            Cursor.X = Cursor.X - 1
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            If X = 0 Or X = 1 Then
                                Cursor.X = Cursor.X - 1
                            Else
                                Cursor.X = Cursor.X - X
                            End If
                        End If
                        Call TermCheckCursor
                        InEscape = False
                    Case "B" 'CUD - Cursor Down
                        If Len(EscString) = 2 Then 'if no parameter value
                            Cursor.Y = Cursor.Y + 1
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            If X = 0 Or X = 1 Then
                                Cursor.Y = Cursor.Y + 1
                            Else
                                Cursor.Y = Cursor.Y + X
                            End If
                        End If
                        Call TermCheckCursor
                        InEscape = False
                    Case "C" 'CUF - Cursor Forward
                        If Len(EscString) = 2 Then 'if no parameter value
                            Cursor.X = Cursor.X + 1
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            If X = 0 Or X = 1 Then
                                Cursor.X = Cursor.X + 1
                            Else
                                Cursor.X = Cursor.X + X
                            End If
                        End If
                        Call TermCheckCursor
                        InEscape = False
                    Case "H" 'CUP - Cursor Position
                        If Len(EscString) = 2 Then 'if no parameter values
                            Cursor.X = 0
                            Cursor.Y = 0
                        ElseIf Len(EscString) = 3 Then 'if no parameter values
                            If InStr(1, EscString, ";", vbTextCompare) <> 0 Then
                                Cursor.X = 0
                                Cursor.Y = 0
                            End If
                        Else
                            EscString = Mid(EscString, 2, Len(EscString) - 2)
                            Cursor.Y = CInt(TermSeparateParameters(EscString)) - 1
                            Cursor.X = CInt(EscString) - 1
                        End If
                        Call TermCheckCursor
                        InEscape = False
                    Case "A" 'CUU - Cursor Up
                        If Len(EscString) = 2 Then 'if no parameter value
                            Cursor.Y = Cursor.Y - 1
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            If X = 0 Or X = 1 Then
                                Cursor.Y = Cursor.Y - 1
                            Else
                                Cursor.Y = Cursor.Y - X
                            End If
                        End If
                        Call TermCheckCursor
                        InEscape = False
                    Case "c" 'DA - Device Attributes
                        If Len(EscString) = 2 Then 'if no parameter value
                            Call TermSendData(Chr(27) & "[?1;0c")
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            If X = 0 Then
                                Call TermSendData(Chr(27) & "[?1;0c")
                            End If
                        End If
                        InEscape = False
                    Case "n" 'DSR - Device Status Report
                        X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                        Select Case X
                            Case 5 'Please report status
                                Call TermSendData(Chr(27) & "[0n")
                            Case 6 'Please report active position (CPR)
                                Call TermSendData(Chr(27) & "[" & Cursor.Y + 1 & ";" & Cursor.X + 1 & "R")
                        End Select
                        InEscape = False
                    Case "J" 'ED - Erase In Display
                        If Len(EscString) = 2 Then 'if no parameter value
                            For Z = Cursor.X To gblcstiTerminalWidthMAX
                                TerminalChar(Cursor.Y, Z).Text = 32
                            Next
                            For Y = (Cursor.Y + 1) To gbllMaxHeightChars
                                For Z = 0 To gblcstiTerminalWidthMAX
                                    TerminalChar(Y, Z).Text = 32
                                Next
                            Next
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            Select Case X
                                Case 0 'Erase from active position to end of screen, inclusive
                                    For Z = Cursor.X To gblcstiTerminalWidthMAX
                                        TerminalChar(Cursor.Y, Z).Text = 32
                                    Next
                                    For Y = (Cursor.Y + 1) To gbllMaxHeightChars
                                        For Z = 0 To gblcstiTerminalWidthMAX
                                            TerminalChar(Y, Z).Text = 32
                                        Next
                                    Next
                                Case 1 'Erase from start of screen to active position, inclusive
                                    For Z = 0 To Cursor.X
                                        TerminalChar(Cursor.Y, Z).Text = 32
                                    Next
                                    For Y = 0 To (Cursor.Y - 1)
                                        For Z = 0 To gblcstiTerminalWidthMAX
                                            TerminalChar(Y, Z).Text = 32
                                        Next
                                    Next
                                Case 2 'Erase entire display, cursor does not move
                                    For Y = 0 To gbllMaxHeightChars
                                        For Z = 0 To gblcstiTerminalWidthMAX
                                            TerminalChar(Y, Z).Text = 32
                                        Next
                                    Next
                            End Select
                            Terminal.Refresh
                        End If
                        InEscape = False
                    Case "K" 'EL - Erase In Line
                        If Len(EscString) = 2 Then 'if no parameter value
                            For Z = Cursor.X To gblcstiTerminalWidthMAX
                                TerminalChar(Cursor.Y, Z).Text = 32
                            Next
                        Else
                            X = CInt(Mid(EscString, 2, Len(EscString) - 2))
                            Select Case X
                                Case 0 'Erase from active position to end of line, inclusive
                                    For Z = Cursor.X To gblcstiTerminalWidthMAX
                                        TerminalChar(Cursor.Y, Z).Text = 32
                                    Next
                                Case 1 'Erase from start of line to active position, inclusive
                                    For Z = 0 To Cursor.X
                                        TerminalChar(Cursor.Y, Z).Text = 32
                                    Next
                                Case 2 'Erase entire line
                                    For Z = 0 To gblcstiTerminalWidthMAX
                                        TerminalChar(Cursor.Y, Z).Text = 32
                                    Next
                            End Select
                            Terminal.Refresh
                        End If
                        InEscape = False
                    Case "f" 'HVP - Horizontal and Vertical Position
                        If Len(EscString) = 2 Then 'if no parameter values
                            Cursor.X = 0
                            Cursor.Y = 0
                        ElseIf Len(EscString) = 3 Then 'if no parameter values
                            If InStr(1, EscString, ";", vbTextCompare) <> 0 Then
                                Cursor.X = 0
                                Cursor.Y = 0
                            End If
                        Else
                            EscString = Mid(EscString, 2, Len(EscString) - 2)
                            Cursor.Y = CInt(TermSeparateParameters(EscString)) - 1
                            Cursor.X = CInt(EscString) - 1
                        End If
                        Call TermCheckCursor
                        InEscape = False
                    Case "l" 'RM - Reset Mode
                        EscString = Mid(EscString, 2, Len(EscString) - 2)
                        Do
                            Select Case TermSeparateParameters(EscString)
                                Case "20" 'LNM = Reset
                                    TerminalAttribute.LNM = False
                                Case "7", "=7" 'Wordwrap = Reset
                                    TerminalAttribute.Wordwrap = False
                            End Select
                        Loop Until EscString = ""
                        InEscape = False
                    Case "m" 'SGR - Select Graphic Rendition
                        EscString = Mid(EscString, 2, Len(EscString) - 2)
                        Do
                            Select Case TermSeparateParameters(EscString)
                                Case "0" 'Normal Display
                                    With TerminalAttribute
                                        .Blink = False
                                        .Bold = False
                                        .Invisible = False
                                        .Reverse = False
                                        .Underline = False
                                    End With
                                    
                                Case "1" 'Bold
                                    TerminalAttribute.Bold = True
                                Case "4" 'Underscore
                                    TerminalAttribute.Underline = True
                                Case "5" 'Blink
                                    TerminalAttribute.Blink = True
                                Case "7" 'Reverse Video
                                    TerminalAttribute.Reverse = True
                                Case "8" 'Invisible
                                    TerminalAttribute.Invisible = True
                                Case "30" 'Black Foreground
                                    TerminalAttribute.ForeColor = gbllreg(30) 'QBColor(8)
                                Case "31" 'Red Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(31)
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(31) 'RGB(135, 0, 0)
                                    End If
                                Case "32" 'Green Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(32) 'RGB(55, 185, 0)
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(32) 'RGB(55, 135, 0)
                                    End If
                                Case "33" 'Yellow Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(33) 'RGB(150, 150, 0)
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(33) 'RGB(120, 120, 0)
                                    End If
                                Case "34" 'Blue Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(34) 'RGB(0, 0, 140)
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(34) 'RGB(0, 0, 88)
                                    End If
                                Case "35" 'Magenta Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(35) 'vbMagenta
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(35) 'RGB(135, 0, 95)
                                    End If
                                Case "36" 'Cyan Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(36) 'RGB(0, 155, 155)
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(36) 'RGB(0, 75, 75)
                                    End If
                                Case "37" 'White Foreground
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.ForeColor = gbllbold(37)
                                    Else
                                        TerminalAttribute.ForeColor = gbllreg(37) 'RGB(95, 95, 95)
                                    End If
                                Case "40" 'Black Background
                                    TerminalAttribute.BackColor = QBColor(8)
                                Case "41" 'Red Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = vbRed
                                    Else
                                        TerminalAttribute.BackColor = RGB(135, 0, 0)
                                    End If
                                Case "42" 'Green Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = vbGreen
                                    Else
                                        TerminalAttribute.BackColor = RGB(55, 135, 0)
                                    End If
                                Case "43" 'Yellow Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = RGB(150, 150, 0)
                                    Else
                                        TerminalAttribute.BackColor = RGB(120, 120, 0)
                                    End If
                                Case "44" 'Blue Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = RGB(0, 0, 140)
                                    Else
                                        TerminalAttribute.BackColor = RGB(0, 0, 88)
                                    End If
                                Case "45" 'Magenta Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = vbMagenta
                                    Else
                                        TerminalAttribute.BackColor = RGB(135, 0, 95)
                                    End If
                                Case "46" 'Cyan Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = RGB(0, 155, 155)
                                    Else
                                        TerminalAttribute.BackColor = RGB(0, 75, 75)
                                    End If
                                Case "47" 'White Background
                                    If (TerminalAttribute.Bold) Then
                                        TerminalAttribute.BackColor = RGB(155, 155, 155)
                                    Else
                                        TerminalAttribute.BackColor = RGB(95, 95, 95)
                                    End If
                            End Select
                        Loop Until EscString = ""
                        InEscape = False
                        
                    Case "h" 'SM - Set Mode
                        EscString = Mid(EscString, 2, Len(EscString) - 2)
                        Do
                            Select Case TermSeparateParameters(EscString)
                                Case "20" 'LNM =Set
                                    TerminalAttribute.LNM = True
                                Case "7", "=7" 'Wordwrap = Set
                                    TerminalAttribute.Wordwrap = True
                            End Select
                        Loop Until EscString = ""
                        InEscape = False
                    Case "g" 'TBC - Tabulation Clear
                        If Len(EscString) = 2 Then 'if no parameter value
                            For X = 0 To 19
                                If Tabs(X) = Cursor.X Then
                                    Tabs(X) = ""
                                End If
                            Next
                        Else
                            EscString = Mid(EscString, 2, Len(EscString) - 2)
                            Select Case EscString
                                Case 0 'Clear horizontal tab stop at the active position
                                    For X = 0 To 19
                                        If Tabs(X) = Cursor.X Then
                                            Tabs(X) = ""
                                        End If
                                    Next
                                Case 3 'Clear all horizontal tab stops
                                    For X = 0 To 19
                                        Tabs(X) = ""
                                    Next
                                    TabNum = 0
                            End Select
                        End If
                        InEscape = False
                    Case "s" 'ANSI - Save Cursor Position
                        With CursorSave
                            .X = Cursor.X
                            .Y = Cursor.Y
                            .Reverse = Cursor.Reverse
                            .Visible = Cursor.Visible
                        End With
                        InEscape = False
                    Case "u" 'ANSI - Restore Cursor Position
                        With Cursor
                            .X = CursorSave.X
                            .Y = CursorSave.Y
                            .Reverse = CursorSave.Reverse
                            .Visible = CursorSave.Visible
                        End With
                        Call TermCheckCursor
                        InEscape = False
                End Select
            Case "(", ")" 'SCS - Select Character Set
                InEscape = False
            Case "#"
                Select Case Right(EscString, 1)
                    Case "8" 'DECALN - Screen Alignment Display
                        Cursor.X = 0
                        Cursor.Y = 0
                        For Y = 0 To gbllMaxHeightChars
                            'Cursor.Y = Y
                            For X = 0 To 79
                                TerminalChar(Y, X).Text = Asc("E")
                            Next
                        Next
                        Cursor.X = 0
                        Cursor.Y = 0
                        Terminal.Refresh
                        InEscape = False
                    Case Else
                        InEscape = False
                End Select
        End Select
    End If
End Sub

Private Sub TermCheckCursor()
    If Cursor.X < 0 Then
        Cursor.X = 0
    ElseIf Cursor.X > gblcstiTerminalWidthMAX Then
        If TerminalAttribute.Wordwrap = False Then
            Cursor.X = gblcstiTerminalWidthMAX
        Else
            Cursor.X = 0
            Cursor.Y = Cursor.Y + 1
            Call TermCheckCursor
        End If
    End If
    If Cursor.Y < 0 Then
        Cursor.Y = 0
    ElseIf Cursor.Y > gbllMaxHeightChars Then
        Cursor.Y = gbllMaxHeightChars
    End If
End Sub

Public Sub TermSendData(Data As String)
    Dim X As Integer
    Dim bData() As Byte
    
    For X = 1 To Len(Data)
        If frmMain.Winsock1.State = 7 Then '7 = connected
            frmMain.Winsock1.SendData CByte(Asc(Mid(Data, X, 1)))
        End If
    Next
End Sub

Private Function TermSeparateParameters(EscStringIn As String) As String
    Dim X As Integer

    X = InStr(EscStringIn, ";")
    If X = 0 Then
        TermSeparateParameters = EscStringIn
        EscString = ""
    Else
        TermSeparateParameters = Left$(EscStringIn, X - 1)
        EscString = Mid$(EscStringIn, X + 1)
    End If
End Function

Private Sub TermScrollUp()
    Dim X As Integer, Y As Integer
    If (Not gblbTerminalScrolling) Then 'we do not scroll up when the user is manually scrolling up and down
        For Y = 0 To gbllMaxHeightChars - 1 'move everything up one level
            For X = 0 To gblcstiTerminalWidthMAX
                With TerminalChar(Y, X)
                    .BackColor = TerminalChar(Y + 1, X).BackColor
                    .Blink = TerminalChar(Y + 1, X).Blink
                    .Bold = TerminalChar(Y + 1, X).Bold
                    .ForeColor = TerminalChar(Y + 1, X).ForeColor
                    .Invisible = TerminalChar(Y + 1, X).Invisible
                    .Reverse = TerminalChar(Y + 1, X).Reverse
                    .Text = TerminalChar(Y + 1, X).Text
                    .Underline = TerminalChar(Y + 1, X).Underline
                End With
            Next
        Next
        
        For X = 0 To gblcstiTerminalWidthMAX
            With TerminalChar(gbllMaxHeightChars, X)
                .BackColor = TerminalAttribute.BackColor
                .Blink = TerminalAttribute.Blink
                .Bold = TerminalAttribute.Bold
                .ForeColor = TerminalAttribute.ForeColor
                .Invisible = TerminalAttribute.Invisible
                .Reverse = TerminalAttribute.Reverse
                .Text = 32 'We clear the bottom line with all space characters
                .Underline = TerminalAttribute.Underline
            End With
        Next
    End If
End Sub

Public Sub TermFreeMemory()
    Call DeleteObject(Color.Black)
    Call DeleteObject(Color.Blue)
    Call DeleteObject(Color.Cyan)
    Call DeleteObject(Color.Gray)
    Call DeleteObject(Color.Green)
    Call DeleteObject(Color.Magenta)
    Call DeleteObject(Color.Red)
    Call DeleteObject(Color.White)
    Call DeleteObject(Color.Yellow)
End Sub

Public Sub TermRefresh()
    Dim Y As Integer, X As Integer
    Dim tempBrush As Long
    
    Terminal.Cls
    
    If Cursor.Visible = True Then
        BlinkSentry = BlinkSentry - 1
        If BlinkSentry <= 0 Then
            BlinkSentry = 1
            If Cursor.Reverse = True Then
                Cursor.Reverse = False
            Else
                Cursor.Reverse = True
                Call BitBlt(Terminal.hdc, Cursor.X * Character.width, Cursor.Y * Character.height, Character.width, Character.height, Terminal.hdc, Cursor.X * Character.width, Cursor.Y * Character.height, DSTINVERT)
            End If
        End If
    End If
    
    For Y = 0 To gbllMaxHeightChars
        For X = 0 To gblcstiTerminalWidthMAX
            Call SetTextColor(Terminal.hdc, TerminalChar(Y, X).ForeColor)
            
            If TerminalChar(Y, X).Blink = True Then
                If Cursor.Reverse = False Then
                    Call TextOut(Terminal.hdc, X * Character.width, Y * Character.height, Chr$(32), 1)
                Else
                    Call TextOut(Terminal.hdc, X * Character.width, Y * Character.height, Chr$(TerminalChar(Y, X).Text), 1)
                End If
            Else
                Call TextOut(Terminal.hdc, X * Character.width, Y * Character.height, Chr$(TerminalChar(Y, X).Text), 1)
            End If
        Next
    Next
    
    Terminal.Refresh
End Sub
