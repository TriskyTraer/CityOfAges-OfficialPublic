VERSION 5.00
Begin VB.Form frmMapStars 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "STARMAP"
   ClientHeight    =   4485
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7020
   FillStyle       =   0  'Solid
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMapStars.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   4485
   ScaleWidth      =   7020
   Begin VB.CommandButton cmdBringDownGridMasterPicbox 
      Appearance      =   0  'Flat
      BackColor       =   &H0080C0FF&
      Caption         =   "..."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   6480
      MaskColor       =   &H0080FF80&
      Style           =   1  'Graphical
      TabIndex        =   0
      ToolTipText     =   "Brings up the grid master maintenance and report listbox."
      Top             =   0
      Width           =   255
   End
   Begin VB.PictureBox picGridMaster 
      Appearance      =   0  'Flat
      BackColor       =   &H0080C0FF&
      ForeColor       =   &H80000008&
      Height          =   1600
      Left            =   120
      ScaleHeight     =   1575
      ScaleWidth      =   6585
      TabIndex        =   8
      Top             =   360
      Visible         =   0   'False
      Width           =   6615
      Begin VB.CommandButton cmdDeleteGridMasterSelection 
         Appearance      =   0  'Flat
         BackColor       =   &H008080FF&
         Caption         =   "&Del"
         Height          =   300
         Left            =   6240
         Style           =   1  'Graphical
         TabIndex        =   9
         ToolTipText     =   "Select from the left listbox and use this delete button to remove that unused item in this report."
         Top             =   1320
         Width           =   375
      End
      Begin VB.ListBox lstGridMaster 
         Appearance      =   0  'Flat
         Height          =   1500
         Left            =   10
         TabIndex        =   10
         ToolTipText     =   "Double click a selection to load the starmap!"
         Top             =   0
         Width           =   6480
      End
   End
   Begin VB.CommandButton cmdAllStop 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0FF&
      Caption         =   "All Stop"
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   7
      TabStop         =   0   'False
      ToolTipText     =   "Use the coordnates and beam to your ship, and plot a course!"
      Top             =   0
      Width           =   735
   End
   Begin VB.CommandButton cmdEngage 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      Caption         =   "Set Course ENGAGE"
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3600
      Style           =   1  'Graphical
      TabIndex        =   5
      TabStop         =   0   'False
      ToolTipText     =   "Use the coordnates and beam to your ship, and plot a course!"
      Top             =   0
      Width           =   1095
   End
   Begin VB.CommandButton cmdPageLost 
      Appearance      =   0  'Flat
      Caption         =   "View Glory Quests"
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   6
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4680
      Style           =   1  'Graphical
      TabIndex        =   6
      TabStop         =   0   'False
      Top             =   0
      Width           =   1095
   End
   Begin VB.CommandButton cmdOpenRight 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   0
      Picture         =   "frmMapStars.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   0
      Visible         =   0   'False
      Width           =   280
   End
   Begin VB.Timer tmrMapperRefresh 
      Interval        =   555
      Left            =   0
      Top             =   120
   End
   Begin VB.TextBox txtX 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   0
      TabIndex        =   2
      Top             =   0
      Width           =   1215
   End
   Begin VB.TextBox txtY 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1200
      TabIndex        =   3
      Top             =   0
      Width           =   1215
   End
   Begin VB.TextBox txtZ 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2400
      TabIndex        =   4
      Top             =   0
      Width           =   1215
   End
End
Attribute VB_Name = "frmMapStars"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstzMapSizeType = "SMALL"
Const cstRangeX = 26
Const cstRangeY = 18
Const cstSize = 5 'Cannot be less than 5 and must be an odd number
Const cstT2P = 15 '15 twips to 1 pixel
Const cstPixel = 3
Dim bToggleHUD As Boolean
Dim gbllX As Long
Dim gbllY As Long
Dim gbllSW As Long
Dim gbllSH As Long
Dim gbllOMeLeft As Long
Dim gbllOMeTop As Long
Private Sub cmdAllStop_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "SS STOP" & vbCrLf
End Sub

Private Sub cmdBringDownGridMasterPicbox_Click()
    picGridMaster.Visible = Not picGridMaster.Visible
End Sub

Private Sub cmdDeleteGridMasterSelection_Click()
On Error GoTo Err_Check
    'MsgBox "work in progress" & vbCrLf & lstGridMaster.List(lstGridMaster.ListIndex) & vbCrLf & lstGridMaster.ItemData(lstGridMaster.ListIndex)
    If (lstGridMaster.ListIndex <> -1) Then
        If (MsgBox("Delete this selection?", vbYesNo) = vbYes) Then
            If (lstGridMaster.ListIndex <> -1) Then
                MyDB.Execute "DELETE GridStarmapID FROM tblGridStarmap WHERE (GridStarmapID=" & lstGridMaster.ItemData(lstGridMaster.ListIndex) & ");", dbFailOnError
                subPopulateGridMaster
            Else
                Beep
            End If
        Else
            Beep
        End If
    Else
        Beep
    End If
    Exit Sub
Err_Check:
    MsgBox "frmMapStars::cmdDeleteGridMasterSelection_Click," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub

Private Sub Form_Activate()
    gblbCharacterNameIDOverride = True
    gbllFormActivated = 1301
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_DblClick()
    bToggleHUD = (Not bToggleHUD)
    subMapperSize cstzMapSizeType
    subUpdateMapper
End Sub
Private Sub Form_Deactivate()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subFormLoad
End Sub
Private Sub subFormLoad()
On Error GoTo Err_Check
    bToggleHUD = False
    DoEvents
    If (gblbGridStarmapCalled) Then
        gbllStarmapX = gbllGridStarmapX
        gbllStarmapY = gbllGridStarmapY
        gbllStarmapZ = gbllGridStarmapZ
        gblbGridStarmapCalled = False
        
        txtX.Text = gbllStarmapX
        txtY.Text = gbllStarmapY
        txtZ.Text = gbllStarmapZ
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "SS LOCK " & MyCStr(gbllStarmapX) & " " & MyCStr(gbllStarmapY) & " " & MyCStr(gbllStarmapZ) & vbCrLf
        frmMain.txtSendClientData.SetFocus
    Else
        subUpdateXYZ False
    End If
   
    DoEvents
    
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "L"
    
    subMapperSize cstzMapSizeType
    subUpdateMapper
    
    subPopulateGridMaster
    Exit Sub
Err_Check:
    MsgBox "frmMapStars::Load_Form," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub subUpdateXYZ(bFull As Boolean)
On Error Resume Next
    Dim lInfoX As Long
    Dim lInfoY As Long
    Dim lInfoZ As Long

    subExtractXYZFromInfoXYZ gblzInfoXYZ, lInfoX, lInfoY, lInfoZ
    If (bFull) Or (gblltxtMSNX + gblltxtMSNY + gblltxtSNZ = 0) Then
        gblltxtMSNX = lInfoX
        gblltxtMSNY = lInfoY
        gblltxtMSNZ = lInfoZ
    End If
    
    gbllStarmapX = gblltxtMSNX
    gbllStarmapY = gblltxtMSNY
    gbllStarmapZ = gblltxtMSNZ
    
    txtX.Text = gblltxtMSNX
    txtY.Text = gblltxtMSNY
    txtZ.Text = gblltxtMSNZ
End Sub
Private Sub subPopulateGridMaster()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zWhere As String
    Dim zDesc As String
    Dim zTime As String
    Dim zDate As String
    lstGridMaster.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT GridStarmapID, GridStarmapX, GridStarmapY, GridStarmapZ, GridStarmapWhere, GridStarmapDesc, GridStarmapCreatedTime, GridStarmapCreatedDate FROM tblGridStarmap ORDER BY GridStarmapID DESC;", dbOpenSnapshot) 'we do not use CharacterID here
    Do While (Not rsSetUp.EOF)
        lX = rsSetUp!GridStarmapX
        lY = rsSetUp!GridStarmapY
        lZ = rsSetUp!GridStarmapZ
        zDesc = rsSetUp!GridStarmapDesc
        zWhere = rsSetUp!GridStarmapWhere
        zTime = rsSetUp!GridStarmapCreatedTime
        zDate = rsSetUp!GridStarmapCreatedDate
        lstGridMaster.AddItem lX & " " & lY & " " & lZ & " " & zWhere
        lstGridMaster.ItemData(lstGridMaster.NewIndex) = rsSetUp!GridStarmapID
        rsSetUp.MoveNext
    Loop
    Set rsSetUp = Nothing
    DoEvents
    Exit Sub
Err_Check:
    MsgBox "subPopulateGridMaster," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub

Private Sub lstGridMaster_DblClick()
    subLoadSelectedGridMaster True
    
    gblltxtMSNX = gbllStarmapX
    gblltxtMSNY = gbllStarmapY
    gblltxtMSNZ = gbllStarmapZ
       
    txtX.Text = gblltxtMSNX
    txtY.Text = gblltxtMSNY
    txtZ.Text = gblltxtMSNZ
    
    DoEvents
    gblbGridStarmapCalled = False
    picGridMaster.Visible = False
End Sub
Private Sub subLoadSelectedGridMaster(bSkipPart As Boolean)
On Error GoTo Err_Check
    Dim bOkay As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zWhere As String
    Dim zDesc As String
    Dim rsSetUp As Recordset
    
    bOkay = False
    If (lstGridMaster.ListIndex <> -1) Then
        Set rsSetUp = MyDB.OpenRecordset("SELECT GridStarmapID, GridStarmapX, GridStarmapY, GridStarmapZ, GridStarmapWhere, GridStarmapDesc FROM tblGridStarmap WHERE (GridStarmapID=" & lstGridMaster.ItemData(lstGridMaster.ListIndex) & ");", dbOpenSnapshot) 'we do not use CharacterID here
        If (Not rsSetUp.EOF) Then
            lX = rsSetUp!GridStarmapX
            lY = rsSetUp!GridStarmapY
            lZ = rsSetUp!GridStarmapZ
            zDesc = rsSetUp!GridStarmapDesc
            zWhere = rsSetUp!GridStarmapWhere
            
            gbllStarmapX = lX
            gbllStarmapY = lY
            gbllStarmapZ = lZ

            'gblzClipTitle = zWhere
            bOkay = True
        End If
        Set rsSetUp = Nothing
        If (bOkay And Not bSkipPart) Then subFormLoad
    Else
        Beep
    End If
    DoEvents
    Exit Sub
Err_Check:
    MsgBox "subLoadSelectedGridMaster," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub tmrMapperRefresh_Timer()
    If (gbllMapperTimerStatus) Then subUpdateMapper
End Sub
Private Sub subUpdateMapper()
    frmMapStars.Cls
    subMakeTheGraphicalMap gbllCharacterNameID, gblzInfoXYZ, cstzMapSizeType
    If (gbllMapperTimerStatus And gbllMapperAutoFocus) Then frmMain.txtSendClientData.SetFocus
End Sub

Private Function lMid(zType As String) As Long
    Dim lReturn As Long
    Select Case zType
        Case "W", "X"
            lReturn = MyCLng((gbllSW / cstT2P) / 2)
        Case "H", "Y"
            lReturn = MyCLng((gbllSH / cstT2P) / 2) - 29
    End Select
    lMid = lReturn
End Function

Private Sub subMapperSize(zType As String)
    Select Case zType
        Case "SMALL"
            frmMapStars.width = 16000
            frmMapStars.height = 11000
            gbllSW = (frmMapStars.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapStars.height / 2) '(Screen.Height / 2)
        Case "LARGE"
            frmMapStars.width = frmMain.width * 2
            frmMapStars.height = frmMain.height * 2
            gbllSW = (frmMapStars.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapStars.height / 2) '(Screen.Height / 2)
    End Select
    
    frmMapStars.Cls
    frmMapStars.ScaleMode = cstPixel
    frmMapStars.AutoRedraw = True
    frmMapStars.width = gbllSW
    frmMapStars.height = gbllSH
    frmMapStars.FillStyle = vbSolid
    frmMapStars.FillColor = &H80C0FF
    frmMapStars.DrawWidth = 1
End Sub

Public Sub subMakeTheGraphicalMap(lCharacterNameID As Long, zInfoXYZ As String, zType As String)
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCX As Long 'True location of the player
    Dim lCY As Long
    Dim lCZ As Long
    
    lX = gbllStarmapX
    lY = gbllStarmapY
    lZ = gbllStarmapZ
    'Create Layered Map
    lCX = lX: lCY = lY: lCZ = lZ
    'Read the Map Location
    lZ = 0
    Select Case zType
        Case "SMALL"
            Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX) & " AND X<=" & lCX + (cstRangeX) & " AND Y>=" & lCY - cstRangeY & " AND Y<=" & lCY + cstRangeY & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
            Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                lX = rsSetUp!X
                lY = rsSetUp!Y
                lZ = rsSetUp!Z
                Select Case lCZ
                    Case lZ
                        frmMapStars.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                    Case Else
                        If (lZ - lCZ < 0) Then
                            frmMapStars.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                        Else
                            frmMapStars.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                        End If
                End Select
                rsSetUp.MoveNext
            Loop
            Set rsSetUp = Nothing
            If (bToggleHUD) Then frmMapStars.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
        Case "LARGE"
            Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX + 5) & " AND X<=" & lCX + (cstRangeX + 5) & " AND Y>=" & lCY - ((cstRangeY * 2) + 2) & " AND Y<=" & lCY + ((cstRangeY * 2) + 2) & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
            Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                lX = rsSetUp!X
                lY = rsSetUp!Y
                lZ = rsSetUp!Z
                Select Case lCZ
                    Case lZ
                        frmMapStars.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                    Case Else
                        If (lZ - lCZ < 0) Then
                            frmMapStars.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                        Else
                            frmMapStars.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                        End If
                End Select
                rsSetUp.MoveNext
            Loop
            Set rsSetUp = Nothing
            If (bToggleHUD) Then frmMapStars.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
    End Select
    Exit Sub
Err_Check:
    'MsgBox "MAPEVENTLOCATION:subMakeTheGraphicalMap," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub
Private Sub cmdPageLost_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "PAGE LOST" & vbCrLf & "PAGE CHESTS" & vbCrLf & "PAGE QUEST" & vbCrLf
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdEngage_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "SS BOARD" & vbCrLf & "SS NAVI " & MyCStr(gbllStarmapX) & " " & MyCStr(gbllStarmapY) & " " & MyCStr(gbllStarmapZ) & vbCrLf
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub txtX_KeyPress(KeyAscii As Integer)
    If (KeyAscii = 13) Then subLoadStarMap
End Sub
Private Sub txtX_LostFocus()
    subLoadStarMap
End Sub
Private Sub txtY_KeyPress(KeyAscii As Integer)
    If (KeyAscii = 13) Then subLoadStarMap
End Sub
Private Sub txtY_LostFocus()
    subLoadStarMap
End Sub
Private Sub txtZ_KeyPress(KeyAscii As Integer)
    If (KeyAscii = 13) Then subLoadStarMap
End Sub
Private Sub txtZ_LostFocus()
    subLoadStarMap
End Sub
Private Sub subLoadStarMap()
On Error Resume Next
    gbllStarmapX = MyCLng(txtX.Text)
    gbllStarmapY = MyCLng(txtY.Text)
    gbllStarmapZ = MyCLng(txtZ.Text)
End Sub
