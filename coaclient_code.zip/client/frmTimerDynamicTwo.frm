VERSION 5.00
Begin VB.Form frmTimerDynamicTwo 
   Appearance      =   0  'Flat
   BackColor       =   &H0080C0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "TIMER Dynamic 2"
   ClientHeight    =   1800
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   5625
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmTimerDynamicTwo.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1800
   ScaleWidth      =   5625
   Begin VB.TextBox txtTimerDynamic 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      MaxLength       =   3
      TabIndex        =   0
      Text            =   "300"
      Top             =   120
      Width           =   735
   End
   Begin VB.CheckBox chkOnOff 
      BackColor       =   &H00C0C0FF&
      Caption         =   "off"
      Height          =   330
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   1320
      Width           =   5415
   End
   Begin VB.TextBox txtSendToServer 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   660
      Left            =   120
      TabIndex        =   1
      ToolTipText     =   "Use trigger events or button name below to run a script, semi-colons will seperate more commands."
      Top             =   600
      Width           =   5415
   End
   Begin VB.Timer tmrSendToWinsock 
      Enabled         =   0   'False
      Interval        =   1000
      Left            =   120
      Top             =   120
   End
   Begin VB.Label lblTimerMinutes 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   1920
      TabIndex        =   4
      Top             =   120
      Width           =   3615
   End
   Begin VB.Label lblTimerDynamic 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   960
      TabIndex        =   3
      Top             =   120
      Width           =   855
   End
End
Attribute VB_Name = "frmTimerDynamicTwo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gbllTimerDynamic As Long
Dim gbllTimerDynamicMAX As Long
Private Sub Form_Activate()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    gbllFormActivated = 25
    'subWindowsPosition Me, "S"
    Set rsSetUp = MyDB.OpenRecordset("SELECT TimerDynamic2 FROM tblProfile WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        gbllTimerDynamicMAX = MyCLng(rsSetUp!TimerDynamic2)
        txtTimerDynamic.Text = gbllTimerDynamicMAX
    End If
    Set rsSetUp = Nothing
    If (gbllCharacterNameID <> 0) Then
        Me.Caption = "2[" & gblzCharacterName & "]"
    End If
    Exit Sub
Err_Check:
    MsgBox "Form_Activate," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    'subWindowsPosition Me, "L"
    'subWindowsFieldLoader Me, "L"
End Sub

Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
    subWindowsFieldLoader Me, "S"
End Sub

Private Sub chkOnOff_Click()
On Error Resume Next
    Select Case (chkOnOff.Value = 0)
        Case True
            chkOnOff.BackColor = &HC0C0FF
            tmrSendToWinsock.Enabled = False
            chkOnOff.Caption = "off"
        Case False
            chkOnOff.BackColor = &H80FF80
            tmrSendToWinsock.Enabled = True
            chkOnOff.Caption = "on"
            gbllTimerDynamic = 0
            lblTimerDynamic.Caption = gbllTimerDynamicMAX
            lblTimerMinutes.Caption = MyCLng(gbllTimerDynamicMAX / 60) & " minutes"
    End Select
    frmMain!txtSendClientData.SetFocus
End Sub

Private Sub tmrSendToWinsock_Timer()
    Dim zSendClientData As String
    Dim lLen As String
    gbllTimerDynamic = gbllTimerDynamic + 1
    lblTimerDynamic.Caption = MyCStr(gbllTimerDynamicMAX - gbllTimerDynamic)
    If (gbllTimerDynamic < gbllTimerDynamicMAX - 59) Then
        lblTimerMinutes.Caption = MyCLng((gbllTimerDynamicMAX - gbllTimerDynamic) / 60) & " minutes"
    Else
        lblTimerMinutes.Caption = "seconds left till send"
    End If
    If (gbllTimerDynamic >= gbllTimerDynamicMAX) Then
        gbllTimerDynamic = 0
        If (frmMain.Winsock1.State = 7) Then
            zSendClientData = MyCStr(txtSendToServer.Text)
            lLen = Len(zSendClientData)
            If (lLen > 0) Then
                If (Not bTriggers(zSendClientData)) Then
                    subSendClientData zSendClientData
                End If
            End If
        End If
    End If
End Sub
Private Sub txtSendToServer_KeyPress(KeyAscii As Integer)
On Error Resume Next
    If (KeyAscii = 13) Then
        KeyAscii = 0
        frmMain!txtSendClientData.SetFocus
    End If
End Sub
Private Sub txtTimerDynamic_LostFocus()
'on error resume next
    MyDB.Execute "UPDATE tblProfile SET TimerDynamic2=" & MyCLng(txtTimerDynamic.Text) & " WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbFailOnError
    gbllTimerDynamicMAX = MyCLng(txtTimerDynamic.Text)
End Sub
