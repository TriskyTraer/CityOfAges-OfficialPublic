VERSION 5.00
Begin VB.Form frmShowFileNames 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   Caption         =   "Show File Names"
   ClientHeight    =   3984
   ClientLeft      =   228
   ClientTop       =   576
   ClientWidth     =   10044
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.4
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmShowFileNames.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   3984
   ScaleWidth      =   10044
   Begin VB.CommandButton cmdResize 
      Appearance      =   0  'Flat
      Caption         =   "="
      Height          =   210
      Left            =   0
      TabIndex        =   9
      Top             =   0
      Width           =   135
   End
   Begin VB.CommandButton cmdRunPaintShopPro 
      Appearance      =   0  'Flat
      Caption         =   "Run Paint Shop"
      Height          =   375
      Left            =   8520
      TabIndex        =   6
      ToolTipText     =   "You can use Paint Shop in your main directory for file names listed above."
      Top             =   3000
      Width           =   1455
   End
   Begin VB.TextBox txtOGID 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   5
      ToolTipText     =   "OGID"
      Top             =   2520
      Width           =   9855
   End
   Begin VB.TextBox txtMGID 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   4
      ToolTipText     =   "MGID"
      Top             =   2040
      Width           =   9855
   End
   Begin VB.TextBox txtAGID 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   3
      ToolTipText     =   "AGID"
      Top             =   1560
      Width           =   9855
   End
   Begin VB.TextBox txtAppPath 
      Height          =   435
      Left            =   120
      TabIndex        =   7
      ToolTipText     =   "Application path for your BMP files to customize your own graphics."
      Top             =   3480
      Width           =   9855
   End
   Begin VB.TextBox txtOID 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   2
      ToolTipText     =   "OID"
      Top             =   1080
      Width           =   9855
   End
   Begin VB.TextBox txtMID 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   1
      ToolTipText     =   "MID"
      Top             =   600
      Width           =   9855
   End
   Begin VB.TextBox txtAID 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.6
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   120
      TabIndex        =   0
      ToolTipText     =   "AID"
      Top             =   120
      Width           =   9855
   End
   Begin VB.Label lblMsg 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      Caption         =   "Double click one of the above text boxes to load into paintshop for editing then save them in the below file pathing."
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   120
      TabIndex        =   8
      Top             =   3000
      Width           =   8295
   End
End
Attribute VB_Name = "frmShowFileNames"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim res As Integer
Private Sub subResize()
On Error Resume Next
    frmShowFileNames.Top = 105
    frmShowFileNames.Left = 105
    frmShowFileNames.Width = 10290
    frmShowFileNames.Height = 4575
    lblMsg.Visible = True
    cmdRunPaintShopPro.Left = 8520
End Sub
Private Sub cmdResize_Click()
    subResize
End Sub

Private Sub cmdRunPaintShopPro_Click()
    subMSPaintLoad ""
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 17
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_DblClick()
    subResize
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subWindowsPosition Me, "L"
    txtAppPath.Text = gblzAppPathPictures
    If (Len(gblzInfoAID) > 0) Then txtAID.Text = gblzInfoAID & ".bmp"
    If (Len(gblzInfoMID) > 0) Then txtMID.Text = gblzInfoMID & ".bmp"
    If (Len(gblzInfoOID) > 0) Then txtOID.Text = gblzInfoOID & ".bmp"
    If (Len(gblzInfoAGID) > 0) Then txtAGID.Text = gblzInfoAGID
    If (Len(gblzInfoOGID) > 0) Then txtOGID.Text = gblzInfoOGID
    If (Len(gblzInfoMGID) > 0) Then txtMGID.Text = gblzInfoMGID
End Sub

Private Sub Form_Resize()
On Error Resume Next
    txtAID.Width = frmShowFileNames.Width - 435
    txtMID.Width = frmShowFileNames.Width - 435
    txtOID.Width = frmShowFileNames.Width - 435
    txtAGID.Width = frmShowFileNames.Width - 435
    txtMGID.Width = frmShowFileNames.Width - 435
    txtOGID.Width = frmShowFileNames.Width - 435
    txtAppPath.Width = frmShowFileNames.Width - 435
    lblMsg.Visible = False
    cmdRunPaintShopPro.Left = 120
    frmShowFileNames.Height = 4575
End Sub

Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
End Sub
Private Sub mnuSnippetTool_Click()
    subRunMSSnippetTool
End Sub

Private Sub subMSPaintLoad(zFilename As String)
    Const cstFileName = "C:\WINDOWS\system32\mspaint.exe"
    Dim zPathAndFileName As String
    Dim res As Integer
    If (bFileExists(cstFileName)) Then
        zPathAndFileName = cstFileName & " " & zFilename
        res = Shell(zPathAndFileName, vbNormalFocus)
    End If
End Sub

Private Sub subRunMSPaintShop()
    Const cstFileName = "C:\WINDOWS\system32\mspaint.exe"
    Dim res As Integer
    If (bFileExists(cstFileName)) Then
        res = Shell(cstFileName, vbNormalFocus)
    End If
End Sub

Private Sub subRunMSSnippetTool()
    Const cstFileName = "C:\WINDOWS\system32\SnippingTool.exe"
    Dim res As Integer
    If (bFileExists(cstFileName)) Then
        res = Shell(cstFileName, vbNormalFocus)
    End If
End Sub

Private Sub txtAID_DblClick()
    subMSPaintLoad txtAID.Text
End Sub
Private Sub txtMID_DblClick()
    subMSPaintLoad txtMID.Text
End Sub
Private Sub txtOID_DblClick()
    subMSPaintLoad txtOID.Text
End Sub
Private Sub txtAGID_DblClick()
    subMSPaintLoad txtAGID.Text
End Sub
Private Sub txtMGID_DblClick()
    subMSPaintLoad txtMGID.Text
End Sub
Private Sub txtOGID_DblClick()
    subMSPaintLoad txtOGID.Text
End Sub


