VERSION 5.00
Begin VB.Form frmFleetWindow 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Fleet Commands"
   ClientHeight    =   4635
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4815
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   4635
   ScaleWidth      =   4815
   Begin VB.PictureBox picBackground 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   4455
      Left            =   120
      ScaleHeight     =   4425
      ScaleWidth      =   4545
      TabIndex        =   0
      Top             =   120
      Width           =   4575
      Begin VB.PictureBox picOther 
         Appearance      =   0  'Flat
         BackColor       =   &H00C0C000&
         ForeColor       =   &H80000008&
         Height          =   1095
         Left            =   120
         ScaleHeight     =   1065
         ScaleWidth      =   2145
         TabIndex        =   17
         Top             =   3240
         Width           =   2175
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "City of Ages Centre"
            Height          =   375
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   19
            ToolTipText     =   "Set Course to Ancient Red Planet Starbase...ENGAGE!"
            Top             =   600
            Width           =   1695
         End
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "Ancient Red Planet"
            Height          =   375
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   18
            ToolTipText     =   "Set Course to Ancient Red Planet Starbase...ENGAGE!"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picStarship 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2775
         Left            =   120
         ScaleHeight     =   2745
         ScaleWidth      =   2145
         TabIndex        =   12
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "ENERGIZE/Board"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   16
            ToolTipText     =   "Once you purchase a starship you can board her!"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Repair"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   14
            ToolTipText     =   "Repair your starship!"
            Top             =   2280
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "BUY a starship"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   13
            ToolTipText     =   "$40000, one time purchase"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picStarport 
         Appearance      =   0  'Flat
         BackColor       =   &H000040C0&
         ForeColor       =   &H80000008&
         Height          =   3855
         Left            =   2280
         ScaleHeight     =   3825
         ScaleWidth      =   2145
         TabIndex        =   1
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Engines"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   11
            ToolTipText     =   "$25250"
            Top             =   120
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Scanners"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   10
            ToolTipText     =   "$4615"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Cloaking Modiule"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   9
            ToolTipText     =   "$17600"
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Repulsor Modiule"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   8
            ToolTipText     =   "$15500"
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Power Levels"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   7
            ToolTipText     =   "$485"
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Battery Levels"
            Height          =   255
            Index           =   6
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   6
            ToolTipText     =   "$875"
            Top             =   1920
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Phasers"
            Height          =   255
            Index           =   7
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   5
            ToolTipText     =   "$6800"
            Top             =   2280
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Mines"
            Height          =   255
            Index           =   8
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   4
            ToolTipText     =   "$9100"
            Top             =   2640
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Shield"
            Height          =   255
            Index           =   9
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   3
            ToolTipText     =   "$12625"
            Top             =   3000
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "Up Hull"
            Height          =   255
            Index           =   10
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   2
            ToolTipText     =   "$9250"
            Top             =   3360
            Width           =   1695
         End
      End
      Begin VB.Label lblStarport 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "S T A R P O R T  A C T I V I T I E S"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Left            =   0
         TabIndex        =   15
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
End
Attribute VB_Name = "frmFleetWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdOtheroffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0 'Ancient Red Planet
                frmMain.Winsock1.SendData "SS NAVI 0 0 -" & MyCStr(712 + lRandom(30)) & vbCrLf
            Case 1 'City of Ages Planatary Centre
                frmMain.Winsock1.SendData "SS NAVI 0 0 -" & MyCStr(20 + lRandom(50)) & vbCrLf
        End Select
    End If
   frmMain.tmrENGAGED.Enabled = True
   frmPictureWarpDriveENGAGE.Show 'modal is best
   Unload frmFleetWindow
   
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdSendoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 1
                frmMain.Winsock1.SendData "SS UGE 1" & vbCrLf
            Case 2
                frmMain.Winsock1.SendData "SS UGC 1" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "SS UGK 1" & vbCrLf
            Case 4
                frmMain.Winsock1.SendData "SS UGR 1" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "SS UGO 1" & vbCrLf
            Case 6
                frmMain.Winsock1.SendData "SS UGB 1" & vbCrLf
            Case 7
                frmMain.Winsock1.SendData "SS UGP 1" & vbCrLf
            Case 8
                frmMain.Winsock1.SendData "SS UGM 1" & vbCrLf
            Case 9
                frmMain.Winsock1.SendData "SS UGS 1" & vbCrLf
            Case 10
                frmMain.Winsock1.SendData "SS UGH 1" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdShipoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "SS BUY" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf
                MsgBox "~E N E R G I Z E ~", vbOKOnly
            Case 2
                frmMain.Winsock1.SendData "SS REPAIR" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
   Unload frmFleetWindow
End Sub

Private Sub Form_Load()
    gblbFleetWindow = True
End Sub

'                   ~STARPORT UPGRADE COMMANDS~
'SS BUY
'SS UGE         - upgrade your starship engines, $25250 gold.
'SS UGC         - upgrade your starship scanners, $4615 gold.
'
'SS UGK         - upgrade your starship cloaking device, $17600 gold.
'SS UGR         - upgrade your starship repulsor device, $15500 gold.
'SS UGO         - upgrade your power levels, $485 gold.
'SS UGB         - upgrade your battery, $875 gold.
'
'SS UGP         - upgrade your starship phasers, $6800 gold.
'SS UGM         - upgrade your starship proximity mines, $9100 gold.
'SS UGS         - upgrade your starship shield generator, $12625 gold.
'SS UGH         - upgrade your starship hull armour, $9250 gold.
'SS REPAIR      - this will repair your starship at a starport
'
'SS BOARD       - beams you aboard your starship from anywhere
'SS BEAM        - beams you down, SS BEAM SCAN (scans for mobs)
'SS LOCATION    - the onboard starship computer will tell you your location
'SS FUEL        - this will load your spacecraft with any fuel in your inventory
'SS LOAD        - beams cryogenic chambers aboard
'SS NAVIGATION  - SYNTAX: NAVI [-/+]X [-/+]Y [-/+]Z
'SS PURSUIT     - This will chase the phaser locked target
'SS FREEFIRE    - Instant battery recharge costing [-1lps]
'SS HEAL        - Load a nanite repair component
'
'SS VIEWER      - Activates the viewer
'SS WARP - SYNTAX: WARP Number
'SS STOP        - all stop, see also: SS NAVIGATION
'SS STATUS      - shows the ship status
'SS PARSECS     - measures the distance
'SS PING        - starship scan
'SS SCAN        - scans the area for mineral deposits
'SS CLOAKING    - toggles your cloaking device on or off
'SS LOCK x y z  - locks phasers to target at x y z
'SS MINE        - drops a proximity mine at your location
'SS FIRE        - fires phasers
'SS VALUE       - free starship appraisal
'SS REPULSOR    - activates your starship repulsor beam
'
'[1;37mColonists/Troop Commands
'[1;30mSS DROP        - SS DROP [VALUE/MAX], starship -> colony planet
'SS COLONISTS   - SS COLO [VALUE/MAX], colony planet -> starship
'SS DEFEND      - SS DEFE [VALUE/MAX], starship -> homeworld
'SS TRANSFER    - SS TRAN [VALUE/MAX], homeworld -> starship
'SS CONTROL     - shows you all your controlled worlds
Private Sub Form_Unload(Cancel As Integer)
    gblbFleetWindow = False
End Sub
