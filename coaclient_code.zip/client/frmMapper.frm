VERSION 5.00
Begin VB.Form frmMapper 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Mapper"
   ClientHeight    =   4485
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   7020
   FillStyle       =   0  'Solid
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00000000&
   Icon            =   "frmMapper.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   4485
   ScaleWidth      =   7020
   Begin VB.CommandButton cmdStarmap 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "&Starmap"
      Height          =   255
      Left            =   1920
      MaskColor       =   &H00000000&
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdViewerEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      Caption         =   "Event Mapper"
      Height          =   255
      Left            =   600
      MaskColor       =   &H00000000&
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   0
      Width           =   1335
   End
   Begin VB.CommandButton cmdOpenRight 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   280
      Picture         =   "frmMapper.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   0
      Width           =   280
   End
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   0
      Picture         =   "frmMapper.frx":0B14
      Style           =   1  'Graphical
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   0
      Width           =   280
   End
   Begin VB.Timer tmrMapperRefresh 
      Interval        =   555
      Left            =   0
      Top             =   120
   End
End
Attribute VB_Name = "frmMapper"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstRangeX = 26
Const cstRangeY = 18
Const cstSize = 5 'Cannot be less than 5 and must be an odd number
Const cstT2P = 15 '15 twips to 1 pixel
Const cstPixel = 3
Dim bSendClientData As Boolean
Dim gbllX As Long
Dim gbllY As Long
Dim gbllSW As Long
Dim gbllSH As Long
Dim gbllOMeLeft As Long
Dim gbllOMeTop As Long

Private Sub cmdDelete_Click()
On Error Resume Next
    Unload frmMapperDeleteSpot
    frmMapperDeleteSpot.Show
End Sub

Private Sub cmdDelete_KeyDown(KeyCode As Integer, Shift As Integer)
    frmMain.txtSendClientData.SetFocus
    KeyCode = 0
End Sub

Private Sub cmdOpenRight_Click()
    If (gblzMapSizeType = "SMALL") Then
        gblzMapSizeType = "LARGE"
    Else
        gblzMapSizeType = "SMALL"
    End If
    subMapperSize gblzMapSizeType
End Sub
Private Sub cmdStarmap_Click()
    gblbGridStarmapCalled = False
    Unload frmMapStars
    frmMapStars.Show
End Sub
Private Sub cmdViewerEvents_Click()
    Unload frmMapEventLocation
    frmMapEventLocation.Show
End Sub
Private Sub Form_Activate()
    gblbCharacterNameIDOverride = True
    gbllFormActivated = 13
    subWindowsPosition Me, "S"
    If (bSendClientData) Then frmMain.txtSendClientData.SetFocus
    bSendClientData = False
End Sub
Private Sub Form_Deactivate()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub subLoadMapperTypeSize()
    Static lHoldCharacterNameID As Long
    Dim rsSetUp As Recordset
    
    If (lHoldCharacterNameID <> gbllCharacterNameID) Then
        Set rsSetUp = MyDB.OpenRecordset("SELECT MapperSizeType FROM tblProfile WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenSnapshot)
        If (Not rsSetUp.EOF) Then
            gblzMapSizeType = MyCStr(rsSetUp!MapperSizeType)
            If (Len(gblzMapSizeType) <> 5) Then gblzMapSizeType = "LARGE"
        End If
        Set rsSetUp = Nothing
        subMapperSize gblzMapSizeType
        
        lHoldCharacterNameID = gbllCharacterNameID
    End If
End Sub
Private Sub Form_Load()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "L"
    gblzMapSizeType = "SMALL"
    subLoadMapperTypeSize
    bSendClientData = True 'frmMain.txtSendClientData.SetFocus
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_DblClick()
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub tmrMapperRefresh_Timer()
    If (gbllMapperTimerStatus) Then subUpdateMapper
    subLoadMapperTypeSize
End Sub

Private Sub Form_Click()
On Error Resume Next
    subLoadMapperTypeSize
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub subUpdateMapper()
    frmMapper.Cls
    subMakeTheGraphicalMap gbllCharacterNameID, gblzInfoXYZ, gblzMapSizeType
    If (gbllMapperTimerStatus And gbllMapperAutoFocus) Then frmMain.txtSendClientData.SetFocus
End Sub

Private Function lMid(zType As String) As Long
    Dim lReturn As Long
    Select Case zType
        Case "W", "X"
            lReturn = MyCLng((gbllSW / cstT2P) / 2)
        Case "H", "Y"
            lReturn = MyCLng((gbllSH / cstT2P) / 2) - 29
    End Select
    lMid = lReturn
End Function

Private Sub subMapperSize(zType As String)
    Select Case zType
        Case "SMALL"
            frmMapper.width = 16000
            frmMapper.height = 11000
            gbllSW = (frmMapper.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapper.height / 2) '(Screen.Height / 2)
        Case "LARGE"
            frmMapper.width = frmMain.width * 2
            frmMapper.height = frmMain.height * 2
            gbllSW = (frmMapper.width / 2) '(Screen.Width / 2)
            gbllSH = (frmMapper.height / 2) '(Screen.Height / 2)
    End Select
    
    frmMapper.Cls
    frmMapper.ScaleMode = cstPixel
    frmMapper.AutoRedraw = True
    frmMapper.width = gbllSW
    frmMapper.height = gbllSH
    frmMapper.FillStyle = vbSolid
    frmMapper.FillColor = &H80C0FF
    frmMapper.DrawWidth = 1
End Sub

Public Sub subMakeTheGraphicalMap(lCharacterNameID As Long, zInfoXYZ As String, zType As String)
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCX As Long 'True location of the player
    Dim lCY As Long
    Dim lCZ As Long
    
    If (Len(zInfoXYZ) > 0) Then
        subExtractXYZFromInfoXYZ zInfoXYZ, lX, lY, lZ
        'Create Layered Map
        lCX = lX: lCY = lY: lCZ = lZ
        'Read the Map Location
        lZ = 0
        
        Select Case zType
            Case "SMALL"
                Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX) & " AND X<=" & lCX + (cstRangeX) & " AND Y>=" & lCY - cstRangeY & " AND Y<=" & lCY + cstRangeY & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
                Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                    lX = rsSetUp!X
                    lY = rsSetUp!Y
                    lZ = rsSetUp!Z
                    Select Case lCZ
                        Case lZ
                            frmMapper.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                        Case Else
                            If (lZ - lCZ < 0) Then
                                frmMapper.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                            Else
                                frmMapper.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                            End If
                    End Select
                    rsSetUp.MoveNext
                Loop
                Set rsSetUp = Nothing
                frmMapper.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
            Case "LARGE"
                Set rsSetUp = MyDB.OpenRecordset("SELECT X, Y, Z, Codes FROM tblMapper WHERE (X>=" & lCX - (cstRangeX + 5) & " AND X<=" & lCX + (cstRangeX + 5) & " AND Y>=" & lCY - ((cstRangeY * 2) + 2) & " AND Y<=" & lCY + ((cstRangeY * 2) + 2) & " AND Z>=" & lCZ - 5 & " AND Z<=" & lCZ + 5 & ");", dbOpenSnapshot)
                Do While (Not rsSetUp.EOF) 'Codes are used to identify the area you are in
                    lX = rsSetUp!X
                    lY = rsSetUp!Y
                    lZ = rsSetUp!Z
                    Select Case lCZ
                        Case lZ
                            frmMapper.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 1, vbRed
                        Case Else
                            If (lZ - lCZ < 0) Then
                                frmMapper.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbWhite 'above
                            Else
                                frmMapper.Circle (lMid("X") + ((lX - lCX) * (cstSize * 2)), lMid("Y") + ((lY - lCY) * (cstSize * 2))), cstSize - 4, vbYellow 'below player
                            End If
                    End Select
                    rsSetUp.MoveNext
                Loop
                Set rsSetUp = Nothing
                frmMapper.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbGreen
        End Select
    End If
    Exit Sub
Err_Check:
    'MsgBox "MAPPER:subMakeTheGraphicalMap," & vbCrLf & "#" & Err.Number & " " & Err.Description, vbOKOnly, "CoA Client"
End Sub

Public Sub subRemoveSpotOnMap(lCharacterNameID As Long, zInfoXYZ As String)
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCX As Long 'True location of the player
    Dim lCY As Long
    Dim lCZ As Long
    
    If (Len(zInfoXYZ) > 0) Then
        subExtractXYZFromInfoXYZ zInfoXYZ, lX, lY, lZ
        'Delete the Map Location
        MyDB.Execute "DELETE MapperID FROM tblMapper WHERE (CharacterNameID=" & lCharacterNameID & " AND X=" & lCX & " AND Y=" & lCY & " AND Z=" & lCZ & ");", dbFailOnError
        frmMapper.Circle (lMid("X"), lMid("Y")), cstSize - 1, vbBlack
    End If
End Sub

