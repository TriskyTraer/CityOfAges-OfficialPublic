VERSION 5.00
Begin VB.Form frmHelpAdminSkills 
   Appearance      =   0  'Flat
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "ADMINISTRATION IMMORTAL SKILLS"
   ClientHeight    =   13680
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12285
   Icon            =   "frmHelpAdminSkillsToo.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   13680
   ScaleWidth      =   12285
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00004040&
      Height          =   315
      Index           =   1
      Left            =   6840
      MultiLine       =   -1  'True
      TabIndex        =   48
      Text            =   "frmHelpAdminSkillsToo.frx":058A
      Top             =   2760
      Width           =   5295
   End
   Begin VB.PictureBox picBecomeImmy 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0C0C0&
      ForeColor       =   &H80000008&
      Height          =   1455
      Left            =   1200
      Picture         =   "frmHelpAdminSkillsToo.frx":05B1
      ScaleHeight     =   1425
      ScaleWidth      =   5505
      TabIndex        =   47
      Top             =   1560
      Width           =   5535
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   23
      Left            =   120
      TabIndex        =   46
      Text            =   "HELP"
      Top             =   12720
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   25
      Left            =   1200
      TabIndex        =   45
      Text            =   "IMMO HELP - allows the immortal to add/edit coaserver.mdb help system. Suggestions are: Add your URL/About"
      Top             =   12720
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   22
      Left            =   120
      TabIndex        =   44
      Text            =   "IGNO"
      Top             =   11280
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   21
      Left            =   120
      TabIndex        =   43
      Text            =   "BOUN"
      Top             =   10320
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   20
      Left            =   120
      TabIndex        =   42
      Text            =   "HELP"
      Top             =   9840
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   19
      Left            =   120
      TabIndex        =   41
      Text            =   "EMAIL"
      Top             =   7920
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   17
      Left            =   120
      TabIndex        =   40
      Text            =   "VOTE"
      Top             =   6960
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   15
      Left            =   120
      TabIndex        =   39
      Text            =   "HEAL"
      Top             =   5520
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   38
      Text            =   "PVP"
      Top             =   12240
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00004040&
      Height          =   2475
      Index           =   5
      Left            =   120
      MultiLine       =   -1  'True
      TabIndex        =   37
      Text            =   "frmHelpAdminSkillsToo.frx":1C983
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   24
      Left            =   1200
      TabIndex        =   36
      Text            =   "IMMO IGNO will force all players in the realm to ignore a player. IMMO MUTE stops a player from chatting."
      Top             =   11280
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   23
      Left            =   1200
      TabIndex        =   35
      Text            =   "Even the immortals rely on the help system. HELP MOBILE / HELP BUILD / HELP IMMORTAL are good reads."
      Top             =   13200
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   22
      Left            =   1200
      TabIndex        =   34
      Text            =   "IMMO PVP will turn PvP on to all areas of the realm. Controlled PvP happens NW of 0,0,0"
      Top             =   12240
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   21
      Left            =   1200
      TabIndex        =   33
      Text            =   "IMMO VOTE little vote system you can IMMO VOTE CLEAR and IMMO VOTE STOP one too."
      Top             =   6960
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   20
      Left            =   1200
      TabIndex        =   32
      Text            =   "IMMO ECLI will cause the realm to fall into an eclipse, making the realm more buff vs players."
      Top             =   11760
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   16
      Left            =   120
      TabIndex        =   31
      Text            =   "ECLI"
      Top             =   11760
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   19
      Left            =   1200
      TabIndex        =   30
      Text            =   "IMMO BOUNTY will clear a long list of bounties."
      Top             =   10320
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   18
      Left            =   1200
      TabIndex        =   29
      Text            =   "IMMO HEAL sets everything in the realm to max hitpoints and fixes starships."
      Top             =   5520
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   28
      Text            =   "SAC"
      Top             =   5040
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   17
      Left            =   1200
      TabIndex        =   27
      Text            =   "IMMO SAC, this is an extreme measure to clean an area of junk items, even containers will be deleted."
      Top             =   5040
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   3
      Left            =   120
      TabIndex        =   26
      Text            =   "CR"
      Top             =   9360
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   16
      Left            =   1200
      TabIndex        =   25
      Text            =   "IMMO CR will rename a clan for you. IMMO INDUCT and INDUCT commands to place players in a clan."
      Top             =   9360
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   15
      Left            =   1200
      TabIndex        =   24
      Text            =   "IMMO HELP <help id> is an editor for the help system, it is written to be search easy."
      Top             =   9840
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   23
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   22
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   21
      Text            =   "In the CoA client you can DECLINE being an immortal rolling yourself back to mortal status once again."
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   20
      Text            =   "To become an administrator/immortal bring up the Server [white taskbar cloud] and Utilities>Make Administrator"
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   4
      Left            =   120
      TabIndex        =   19
      Text            =   "IMMO"
      Top             =   3120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   18
      Text            =   "Key immortal command before all others: IMMO TABLES // IMMO FIELDS // IMMO SQL"
      Top             =   3120
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   17
      Text            =   "Using SQL allows you to do ANYTHING at all with the mud, read some wiki's on the web on how to use SQL."
      Top             =   3600
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   6
      Left            =   120
      TabIndex        =   16
      Text            =   "SCM"
      Top             =   4080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   15
      Text            =   "IMMO SCM Speak Control Max, allows you to set the amount of channel chat that goes on."
      Top             =   4080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   7
      Left            =   120
      TabIndex        =   14
      Text            =   "TELE"
      Top             =   4560
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   7
      Left            =   1200
      TabIndex        =   13
      Text            =   "TELE X Y Z  so you can move around and into the Void, IMMO TRANSPORT <name> <name/location> too"
      Top             =   4560
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   8
      Left            =   120
      TabIndex        =   12
      Text            =   "WORM"
      Top             =   6000
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   8
      Left            =   1200
      TabIndex        =   11
      Text            =   "IMMO WORM <x y z> will make a one way starship wormhole from your position to the plotted one."
      Top             =   6000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   9
      Left            =   120
      TabIndex        =   10
      Top             =   6480
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   9
      Left            =   1200
      TabIndex        =   9
      Top             =   6480
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   10
      Left            =   120
      TabIndex        =   8
      Text            =   "BOLT"
      Top             =   10800
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   10
      Left            =   1200
      TabIndex        =   7
      Text            =   "IMMO FIRE, BOLT, HEAVEN, HELL will stun a player for a few minutes, HEAVEN/HELL send them there."
      Top             =   10800
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   11
      Left            =   120
      TabIndex        =   6
      Text            =   "GUES"
      Top             =   7440
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   11
      Left            =   1200
      TabIndex        =   5
      Text            =   "IMMO GUES <word> you can trigger the system to give you a guess word to figure out, a little fun game."
      Top             =   7440
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   12
      Left            =   1200
      TabIndex        =   4
      Text            =   "IMMO EMAIL (email)//IMMO [IMM1..IMM4] (imms)//IMMO MUD (name)//IMMO URL (homeurl)//IMMO TELNET (url)"
      Top             =   7920
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   13
      Left            =   120
      TabIndex        =   3
      Text            =   "XP"
      Top             =   8400
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   13
      Left            =   1200
      TabIndex        =   2
      Text            =   "IMMO XP Cheats a players XP amount so they can level faster, they still need to kill something to level up."
      Top             =   8400
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   14
      Left            =   120
      TabIndex        =   1
      Text            =   "GOLD"
      Top             =   8880
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   14
      Left            =   1200
      TabIndex        =   0
      Text            =   "IMMO GOLD, cheat a player into wealth, IMMO GGLO is to give them GLORY which players use to FORGE with."
      Top             =   8880
      Width           =   11000
   End
End
Attribute VB_Name = "frmHelpAdminSkills"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
