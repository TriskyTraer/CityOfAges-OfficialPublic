VERSION 5.00
Begin VB.Form frmHelpPlayerCommandsToo 
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "HELP - Basic Player Commands"
   ClientHeight    =   13545
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12270
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpPlayerCommandsToo.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   13545
   ScaleWidth      =   12270
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   27
      Left            =   120
      TabIndex        =   55
      Text            =   "STARGATE"
      Top             =   13080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   27
      Left            =   1200
      TabIndex        =   54
      Text            =   "The stargates in the realm are fully functional and connect to eachother. STARGATE <7 LENGTH CODE>"
      Top             =   13080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   26
      Left            =   120
      TabIndex        =   53
      Text            =   "MAJIC"
      Top             =   12600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   26
      Left            =   1200
      TabIndex        =   52
      Text            =   "Majically unseal a door, classes are: Mage, Cleric, Bard, Gypsy, Knight, Monk See Also: Bash and Use."
      Top             =   12600
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   25
      Left            =   120
      TabIndex        =   51
      Text            =   "BASH"
      Top             =   12120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   25
      Left            =   1200
      TabIndex        =   50
      Text            =   "Bash in a door, all classes can attempt this. See also: Majic and Use"
      Top             =   12120
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   24
      Left            =   120
      TabIndex        =   49
      Text            =   "ACTIVATE"
      Top             =   11640
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   24
      Left            =   1200
      TabIndex        =   48
      Text            =   "Activate a non-passive skill. Use AFFECT to see which ones you have learnt and can Activate."
      Top             =   11640
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   23
      Left            =   120
      TabIndex        =   47
      Text            =   "RELOAD"
      Top             =   11160
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   23
      Left            =   1200
      TabIndex        =   46
      Text            =   "Probably one of the most important commands you can run now and then other than ATTACK and LOOK."
      Top             =   11160
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   22
      Left            =   120
      TabIndex        =   45
      Text            =   "ABSORB"
      Top             =   10680
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   22
      Left            =   1200
      TabIndex        =   44
      Text            =   "The most rarest rare of all the realm and can appear on any item you get. HELP ANKH to read more."
      Top             =   10680
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   21
      Left            =   120
      TabIndex        =   43
      Text            =   "MERGE"
      Top             =   10200
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   21
      Left            =   1200
      TabIndex        =   42
      Text            =   "You will find playing cards around the realm, this is the best item to forge your glory too when completed."
      Top             =   10200
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   41
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   20
      Left            =   1200
      TabIndex        =   40
      Text            =   "TRAIN (one word from the mob in the room), you can TRAIN (one mob word) DISBAND as well."
      Top             =   9720
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   20
      Left            =   120
      TabIndex        =   39
      Text            =   "TRAIN"
      Top             =   9720
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   19
      Left            =   1200
      TabIndex        =   38
      Text            =   "Raid the dead around you, this is so you can bring back dead mobiles faster."
      Top             =   9240
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   19
      Left            =   120
      TabIndex        =   37
      Text            =   "RD"
      Top             =   9240
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   18
      Left            =   1200
      TabIndex        =   36
      Text            =   "Heal your pets, some classes are limited or do not have this function."
      Top             =   8760
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   18
      Left            =   120
      TabIndex        =   35
      Text            =   "HP"
      Top             =   8760
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   17
      Left            =   1200
      TabIndex        =   34
      Text            =   "MARK and RECALL work to help you with getting back to your spot. See Also: HELP MAGIC WORDS"
      Top             =   8280
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   17
      Left            =   120
      TabIndex        =   33
      Text            =   "MARK"
      Top             =   8280
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   16
      Left            =   1200
      TabIndex        =   32
      Text            =   "There will be hints around a bridge area, bridge hands will be around. Shadow Castle west of 0, 0, 0 has one."
      Top             =   7800
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   16
      Left            =   120
      TabIndex        =   31
      Text            =   "BRIDGE"
      Top             =   7800
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   15
      Left            =   1200
      TabIndex        =   30
      Text            =   "You can Auction an item, this is similar to the Starship EXCHANGE but one item at a time, BID for the item too."
      Top             =   7320
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   15
      Left            =   120
      TabIndex        =   29
      Text            =   "AUCTION"
      Top             =   7320
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   14
      Left            =   1200
      TabIndex        =   28
      Text            =   "DIG allows you to try to dig up any items another player might of burried here. See Also: BURY"
      Top             =   6840
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   14
      Left            =   120
      TabIndex        =   27
      Text            =   "DIG"
      Top             =   6840
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   13
      Left            =   1200
      TabIndex        =   26
      Text            =   "Allows you to emote anything, similar to SAY but it comes from your character. HELP EMOTE for more."
      Top             =   6360
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   13
      Left            =   120
      TabIndex        =   25
      Text            =   "EMOTE"
      Top             =   6360
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   12
      Left            =   1200
      TabIndex        =   24
      Text            =   "RAMBLE, RUMOR, QUEST, MUSIC, QUOTE, IRC, IC, OOC, are some global channels. HELP CHANNELS"
      Top             =   5880
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   23
      Text            =   "RAMBLE"
      Top             =   5880
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   11
      Left            =   1200
      TabIndex        =   22
      Text            =   "You can YELL to people in your <<WHERE>> areas. SAY only talks in the current area, can be useful."
      Top             =   5400
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   11
      Left            =   120
      TabIndex        =   21
      Text            =   "YELL"
      Top             =   5400
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   10
      Left            =   1200
      TabIndex        =   20
      Text            =   "Get more information about the player when online or offline."
      Top             =   4920
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   10
      Left            =   120
      TabIndex        =   19
      Text            =   "WHOIS"
      Top             =   4920
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   9
      Left            =   1200
      TabIndex        =   18
      Text            =   "Displays who is online, PAGE LAST shows you who has been online over the last 24 hours."
      Top             =   4440
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   9
      Left            =   120
      TabIndex        =   17
      Text            =   "WHO"
      Top             =   4440
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   8
      Left            =   1200
      TabIndex        =   16
      Text            =   "Our EQ list grows becomming hard to see know what you are missing, use this command. See Also: RELOAD"
      Top             =   3960
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   8
      Left            =   120
      TabIndex        =   15
      Text            =   "NEED"
      Top             =   3960
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   7
      Left            =   1200
      TabIndex        =   14
      Text            =   "AUTOLOOT - toggle if you want to use the GET ALL CORPSE command instead of the server filling your INV."
      Top             =   3480
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   7
      Left            =   120
      TabIndex        =   13
      Text            =   "AUTO"
      Top             =   3480
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   12
      Text            =   "The room too full of junk? SACRIFICE all the items to the Void where the Immortals hangout!"
      Top             =   3000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   6
      Left            =   120
      TabIndex        =   11
      Text            =   "SAC"
      Top             =   3000
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   10
      Text            =   "Inventory too full? Donate the items, donation hall is ne and down of 0, 0, 0"
      Top             =   2520
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   5
      Left            =   120
      TabIndex        =   9
      Text            =   "DONATE"
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   8
      Text            =   "When a player turns into a bird or frog or falls under other possible Witchcraft, you can STEP on them."
      Top             =   2040
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   4
      Left            =   120
      TabIndex        =   7
      Text            =   "STEP"
      Top             =   2040
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   3
      Left            =   1200
      TabIndex        =   6
      Text            =   "When a player sleeps they cannot hear you - why not WAKE them up to get their attention."
      Top             =   1560
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   3
      Left            =   120
      TabIndex        =   5
      Text            =   "WAKE"
      Top             =   1560
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   4
      Text            =   "Helps a player when stunned."
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   3
      Text            =   "AID"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   2
      Text            =   "USE [LEVER/KNOB/KEY/COMBINATION/PICK] toggles locks on doors and safes. See Also: Bash and Majic"
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   1
      Left            =   120
      TabIndex        =   1
      Text            =   "USE"
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   0
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
End
Attribute VB_Name = "frmHelpPlayerCommandsToo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
