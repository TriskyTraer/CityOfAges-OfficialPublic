VERSION 5.00
Begin VB.Form frmUpdateBackGroundPicture 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   ClientHeight    =   15
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   1800
   Icon            =   "frmUpdateBackGroundPicture.frx":0000
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   15
   ScaleWidth      =   1800
   ShowInTaskbar   =   0   'False
End
Attribute VB_Name = "frmUpdateBackGroundPicture"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
