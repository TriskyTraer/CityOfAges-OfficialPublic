Attribute VB_Name = "modDatabaseTools"
Option Explicit
'Nice little Error trap routien, See Also: subWriteErrorFile
'On Error GoTo Err_Check
'    Exit Sub
'Err_Check:
'    MsgBox "subSaveTrigger," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
Public Function lRandom(lngRandomNumber As Long) As Long
'Randomizes from 1 to lngRandomNumber
'Random allows negative numbers to work as well and 0 (zero) is skipped
On Error GoTo Err_Trap
    Dim lReturn As Long
    Dim lCheck As Long 'in case the computer's randomizer timer fails

    If (lngRandomNumber <> 0) Then
        Randomize ' Initialize random-number generator.
        lCheck = 0
        Do While (lReturn = 0 And lCheck < 19)
            lCheck = lCheck + 1
            lReturn = (lngRandomNumber * Rnd) ' Compute random value
        Loop
        If (lCheck > 18) Then lReturn = 1
    Else
        lReturn = 0
    End If
    
    lRandom = lReturn
    Exit Function
Err_Trap:
    lRandom = 1
End Function
Public Function zRemoveClutter(zLine As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim zChar As String
    Dim lCount As Long
    Dim lLen As Long
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (Not bAmong(zChar, Chr(13), Chr(10), Chr(27))) Then zReturn = zReturn & zChar
    Next lCount
    zRemoveClutter = zRemoveColorCodes(zReturn)
End Function
Public Function zRemoveNumbers(zLine As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim zChar As String
    Dim lCount As Long
    Dim lLen As Long
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (Not bAmong(zChar, "0", "1", "2", "3", "4", "5", "6", "7", "8", "9")) Then zReturn = zReturn & zChar
    Next lCount
    zRemoveNumbers = MyCStr(zReturn)
End Function
Public Function zKeepNumbersOnly(zLine As String, Optional zExtra As String) As String
'Syntax: zKeepNumbersOnly("HE110 TH3R3") returns:  11033
'        zKeepNumbersOnly("HE110 TH3R3", " ") returns:  110 33 *useful to keep coordinates*
On Error Resume Next
    Dim zReturn As String
    Dim zChar As String
    Dim lCount As Long
    Dim lLen As Long
    lLen = Len(zLine)
    zReturn = ""
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (zChar = zExtra Or bAmong(zChar, "-", "+", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9")) Then zReturn = zReturn & zChar
    Next lCount
    zKeepNumbersOnly = MyCStr(zReturn)
End Function
Public Function zKeepLettersOnly(zLine As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim zChar As String
    Dim lCount As Long
    Dim lLen As Long
    lLen = Len(zLine)
    zReturn = ""
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (bAmong(UCase(zChar), "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z")) Then zReturn = zReturn & zChar
    Next lCount
    zKeepLettersOnly = MyCStr(zReturn)
End Function
Public Function zReplaceCharWithChar(zLine As String, zRChar As String, zWChar As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim zChar As String
    Dim lCount As Long
    Dim lLen As Long
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (zChar = zRChar) Then
            zReturn = zReturn & zWChar
        Else
            zReturn = zReturn & zChar
        End If
    Next lCount
    zReplaceCharWithChar = MyCStr(zReturn)
End Function
Public Function zRemoveSQLCrashChars(zLine As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim zChar As String
    Dim lCount As Long
    Dim lLen As Long
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (Not bAmong(zChar, ";", "'", """")) Then zReturn = zReturn & zChar
    Next lCount
    zRemoveSQLCrashChars = MyCStr(zReturn)
End Function
Public Sub subWriteErrorFile(zLine As Variant, Optional iType As Integer)
On Error GoTo Err_Check
    Dim rsSysErr As Recordset
    Select Case MyCLng(iType)
        Case 2 'all immortals will hear it
            'subSystemMessageToImmortals gblzFBRED & "(immortal eye) ERROR!" & vbCrLf & gblzFNGRE & "subWriteErrorFile reports:" & vbCrLf & zLine, 1
        Case 3 'write it to the screen
            basPrintMessage64 "subWriteErrorFile reports:" & vbCrLf & zLine
        Case Else 'write the message as an error
            Set rsSysErr = MyDB.OpenRecordset("tblSystemErrors", dbOpenTable)
            rsSysErr.AddNew
            rsSysErr!SystemErrorDesc = zLine
            rsSysErr!SystemErrorDateTime = Format(Now(), "mmm dd, yyyy hh:ss:nn")
            rsSysErr.Update
            Set rsSysErr = Nothing
            'subSystemMessageToImmortals gblzFBRED & "(immortal eye) ERROR!" & vbCrLf & gblzFNGRE & zLine, 1
    End Select
    Exit Sub
Err_Check:
    'subSystemMessageToImmortals gblzFBRED & "(immortal eye) " & gblzFBRED & "!!!ERROR WRITING AN ERROR LOG!!!" & vbCrLf & gblzFBWHI & "subWriteErrorFile," & vbCrLf & gblzFNWHI & "ERROR#" & Err.Numer & vbCrLf & gblzFNBLA & Err.Description, 1
End Sub
Public Function ynNetworkPath(strPath As String) As Boolean
On Error Resume Next
    ynNetworkPath = (InStr(strPath, "[\\"))
End Function
Public Function basCompletePath(varPath As Variant) As String
'Pass: basCompletePath("C:\WINDOWS\TEMP")
'Returns: "C:\WINDOWS\TEMP\"
On Error Resume Next
    Dim strPath As String

    strPath = MyCStr(varPath)
    If (Len(strPath) > 0) Then
        strPath = UCase(strPath)
        If (Mid(strPath, Len(strPath), 1) <> "\") Then
            strPath = UCase(strPath & "\")
        End If
    End If
    
    basCompletePath = strPath
End Function

Public Function strReturnNetworkPath(strUNC As String, strPath As String) As String
'ynNetworkPath should be called first to verify that a network path can be returned.
On Error Resume Next
    Dim strReturn As String
    
    strReturn = MyCStr(strReturn)
    
    'Get the UNC path.
    strReturn = basCompletePath(Mid(strUNC, InStr(strUNC, "[\\")))
    
    strReturn = Mid(strReturn, 2, Len(strReturn) - 3) 'remove the "[\\COMPUTER\C\FOLDER]" square brackets.
    
    'Attach the folders after the UNC.
    strReturn = strReturn & basCompletePath(Mid(strPath, InStr(strPath, ":") + 1))
    
    strReturnNetworkPath = strReturn
End Function
Public Sub basRetrieveFilenameAndPath(strFileBoth As String, strFilename As String, strFilePath As String)
On Error GoTo Err_basRetrieveFilenameAndPath
' Send through: strFileBoth as "C:\TEMP1\TEMP2\FILENAME.EXE
' Returns: strFileName as FILENAME.EXE
' Returns: strFilePath as C:\TEMP1\TEMP2
    Dim intNotFound As Integer
    Dim lngEnd As Long
    
    strFileBoth = strFileBoth
    lngEnd = Len(strFileBoth)
    intNotFound = True
    
    'Find the first '\' looking backwards. This is to separate the file and path.
    Do While (lngEnd > 0 And intNotFound)
        If (Mid(strFileBoth, lngEnd, 1) = "\") Then
            intNotFound = False
        Else
            lngEnd = lngEnd - 1
        End If
    Loop
    
    strFilename = ""
    strFilePath = ""
    
    If (Len(strFileBoth) And lngEnd > 0) Then
        strFilename = UCase(Mid(strFileBoth, lngEnd + 1, Len(strFileBoth)))
        strFilePath = UCase(Mid(strFileBoth, 1, lngEnd - 1))
    End If
    Exit Sub
Err_basRetrieveFilenameAndPath:
End Sub
Public Function MyCLng(varValue As Variant) As Long
' CLng by itself is not reliable when dealing with NULL values. So here is my version.
'This routien will handle any leading or ending spaces! We do not need to remove any weird spaces, cool!
On Error GoTo Err_MyCLng
    Dim zValue As String
    Dim lngValue As Long

    'MsgBox "IsNumeric = " & IsNumeric(varValue) & " Length = " & Len(varValue) & " Value = " & varValue

    lngValue = 0
    
    If (IsNumeric(varValue) And (Len(varValue) > 0)) Then ' Numers only! IsNumeric Covers Nulls and all String Text (mixed with #'s too). Len(varValue) < 11 prevents a Numer overflow
        zValue = MyCStr(varValue)
        'If InStr(zValue, ".") Then zValue = Mid(zValue, 1, InStr(zValue, ".") - 1)
        Select Case UCase(zValue)
            Case "FALSE"
                zValue = 0
            Case "TRUE"
                zValue = -1
        End Select
        'If (Len(zValue) < 10 Or InStr(zValue, "-")) Then lngValue = CLng(zValue)
        lngValue = CLng(zValue)
    End If
    MyCLng = lngValue
Exit_Err_MyCLng:
    Exit Function
Err_MyCLng:
    MyCLng = 0
    Resume Exit_Err_MyCLng
End Function
Public Function MyCStr(varValue As Variant) As String
' CStr by itself is not reliable when dealing with NULL values. So here is my version.
On Error GoTo Err_MyCStr
    Dim strValue As String

    strValue = ""
    If (Not (IsNull(varValue))) Then 'If you get a no record error then you need on error in this function
        If (Len(varValue) > 0) Then
            strValue = CStr(Trim(varValue))
        End If
    End If
    MyCStr = strValue
Exit_Err_MyCStr:
    Exit Function
Err_MyCStr:
    Resume Exit_Err_MyCStr
End Function
Public Sub basHourglass(intState As Integer)
On Error Resume Next
'intState can be True (on) or False (off).
    If (intState) Then
        Screen.MousePointer = 11 ' Hourglass
    Else
        Screen.MousePointer = 0 ' Normal
    End If
    DoEvents
End Sub
Public Sub basPrintMessage64(strMsg As String)
On Error Resume Next
    basHourglass False
    MsgBox strMsg, 64, "APPLICATION PAUSED"
End Sub
Public Sub basHelpMessage64(strMsg As String)
On Error Resume Next
    basHourglass False
    MsgBox strMsg, 64, "Quick Help"
End Sub
Public Function basMessage36(strMsg As String) As Integer
On Error Resume Next
    basHourglass False
    basMessage36 = (MsgBox(strMsg, 36, "Advanced Dungeon Solutions") = 6)
End Function
Public Function bAmong(varTarget As Variant, ParamArray varList() As Variant) As Boolean
' If bAmong(ch, "a", "f", "g") then...
' "ParamArray varList() As Variant" can be anything at all, it needs to be variant in this case to make this function more flexible, the "bAmong() As Integer" is returns a boolean value though Integer.
On Error Resume Next
    Dim bReturn As Integer
    Dim vEachChar As Variant
    
    bReturn = False
    
    For Each vEachChar In varList()
        If (vEachChar = varTarget) Then
            bReturn = True
            Exit For
        End If
    Next
    
    bAmong = bReturn
End Function
Public Function basDoesFileExist(strPathAndFile As String) As Integer
On Error Resume Next
    Dim lngError As Long
    Dim intReturn As Integer
    
    intReturn = False ' File does not exist
    
    intReturn = (GetAttr(strPathAndFile) > 0) ' This will be skipped if GetAttr errors out at level 76 'path not found'

    basDoesFileExist = intReturn
End Function
Public Function basStoreMDBLocationToMemory(intLoad As Integer) As String
    basStoreMDBLocationToMemory = App.Path & "\coaclient.mdb"
End Function
Public Function MyDB() As Database  'Resource DAO 2.5+ is a required DLL plug in.
On Error GoTo Err_MyDB
'Original concept: Mark Southron
'Modified for full flexibility: Darren N. Lory
'See also, basCloseMyDB(), basResetMyDB()
'This code removes the need for these each time in every module.:
'               Dim MyDB As Database
'               Set MyDB = Workspaces(0).OpenDatabase(basStoreMDBLocationToMemory(True))
'Syntax examples:   MyDB.Execute "DELETE * from tblEMPLOYEE;"
'                   Set MyRS = MyDB.(etc...)
' Static gblDB As Database is defined at the top of this module.
'     At the top it is defined at PUBLIC not static because static can only exist within a procedure/function.
    If (gblDB Is Nothing) Then
        Set gblDB = Workspaces(0).OpenDatabase(basStoreMDBLocationToMemory(True)) ' Set gblDB = Workspaces(0).OpenDatabase(basStoreMDBLocationToMemory(True), True) 'True means its exclusive - remove True and the comma for shared.
        'Did the object get loaded properly?
        If (gblDB Is Nothing) Then
            'No...
            basPrintMessage64 "MyDB (field gblDB) Error #001," & vbCrLf & vbCr & "Could not set the MyDB Object. The database object could not be registered to memory." & vbCrLf & vbCr & "Is the given path set to a valid MDB? (" & basStoreMDBLocationToMemory(True) & ")" & vbCrLf & vbCr & "The System is about to Shutdown, please click okay to continue."
            End
        End If
    End If
    
    Set MyDB = gblDB
    If (MyDB Is Nothing) Then
        basPrintMessage64 "MyDB (field MyDB) Error #002," & vbCrLf & vbCr & "Could not set the MyDB Object. The database object could not be registered to memory." & vbCrLf & vbCr & "Is the given path set to a valid MDB? (" & basStoreMDBLocationToMemory(True) & ")" & vbCrLf & vbCr & "The System is about to Shutdown, please click okay to continue."
        End
    End If
    
    Exit Function
Err_MyDB:
    basPrintMessage64 "MyDB ERROR," & vbCrLf & "Error #, " & Err.Numer & vbCrLf & Err.Description
    End
End Function
Public Sub basCloseMyDB()
On Error GoTo Err_basCloseMyDB
'See Also, MyDB() As Database
'Event Location Use: Form_Unload(Cancel As Integer)
    If Not (MyDB Is Nothing) Then
        Set gblDB = Nothing
        'Never use MyDB.Close, if you do you may not be able to access data properly until the application is shutdown.
    End If
    Exit Sub
Err_basCloseMyDB:
    basPrintMessage64 Err.Description
End Sub
Public Sub subLoadPlayerDefaults(zCharacterName As String)
On Error GoTo Err_subLoadPlayerDefaults
    Dim rsCharacter As Recordset
    Set rsCharacter = MyDB.OpenRecordset("SELECT IPCommonConnect, CharacterNameID, CharacterName, KeyDivide, KeyMultiply, KeySubtract, KeyAdd, KeyDecimal, KeyNumpad0, KeyNumpad1, KeyNumpad2, KeyNumpad3, KeyNumpad4, KeyNumpad5, KeyNumpad6, KeyNumpad7, KeyNumpad8, KeyNumpad9, KeyF1, KeyF2, KeyF3, KeyF4, KeyF5, KeyF6, KeyF7, KeyF8, KeyF9, KeyF10, KeyF11, KeyF12 FROM tblProfile WHERE (CharacterName='" & UCase(zCharacterName) & "');", dbOpenSnapshot)
    If (Not rsCharacter.EOF) Then
        bPlayerNameRequired = False
        gbllCharacterNameID = rsCharacter!CharacterNameID
        gblzCharacterName = MyCStr(rsCharacter!CharacterName)
        gblzKeyDivide = MyCStr(rsCharacter!KeyDivide)
        gblzKeyMultiply = MyCStr(rsCharacter!KeyMultiply)
        gblzKeySubtract = MyCStr(rsCharacter!KeySubtract)
        gblzKeyAdd = MyCStr(rsCharacter!KeyAdd)
        gblzKeyDecimal = MyCStr(rsCharacter!KeyDecimal)
        gblzKeyNumpad0 = MyCStr(rsCharacter!KeyNumpad0)
        gblzKeyNumpad1 = MyCStr(rsCharacter!KeyNumpad1)
        gblzKeyNumpad2 = MyCStr(rsCharacter!KeyNumpad2)
        gblzKeyNumpad3 = MyCStr(rsCharacter!KeyNumpad3)
        gblzKeyNumpad4 = MyCStr(rsCharacter!KeyNumpad4)
        gblzKeyNumpad5 = MyCStr(rsCharacter!KeyNumpad5)
        gblzKeyNumpad6 = MyCStr(rsCharacter!KeyNumpad6)
        gblzKeyNumpad7 = MyCStr(rsCharacter!KeyNumpad7)
        gblzKeyNumpad8 = MyCStr(rsCharacter!KeyNumpad8)
        gblzKeyNumpad9 = MyCStr(rsCharacter!KeyNumpad9)
        gblzKeyF1 = MyCStr(rsCharacter!KeyF1)
        gblzKeyF2 = MyCStr(rsCharacter!KeyF2)
        gblzKeyF3 = MyCStr(rsCharacter!KeyF3)
        gblzKeyF4 = MyCStr(rsCharacter!KeyF4)
        gblzKeyF5 = MyCStr(rsCharacter!KeyF5)
        gblzKeyF6 = MyCStr(rsCharacter!KeyF6)
        gblzKeyF7 = MyCStr(rsCharacter!KeyF7)
        gblzKeyF8 = MyCStr(rsCharacter!KeyF8)
        gblzKeyF9 = MyCStr(rsCharacter!KeyF9)
        gblzKeyF10 = MyCStr(rsCharacter!KeyF10)
        gblzKeyF11 = MyCStr(rsCharacter!KeyF11)
        gblzKeyF12 = MyCStr(rsCharacter!KeyF12)
        
        frmMain.drawCharacterFound.Visible = True
        If (Len(gblzCharacterName) <> 0) Then
            frmMain.Caption = "City of Ages Terminal Emulator - " & gblzCharacterName
        Else
            bPlayerNameRequired = True
            frmMain.Caption = "City of Ages Terminal Emulator"
        End If
    End If
    Set rsCharacter = Nothing
    mdiMain.subLoadMDIButtons
    subLoadScriptsToMemory
    Exit Sub
Err_subLoadPlayerDefaults:
    basPrintMessage64 Err.Description
End Sub
Public Sub subLoadScriptsToMemory()
On Error GoTo Err_subLoadScriptsToMemory
    'Uses gbllCharacterNameID
    Dim rsCharacter As Recordset
    Dim lCount As Long
    
    For lCount = 1 To cstlScriptMAX
        gblzScripts(lCount) = ""
    Next lCount
    
    lCount = 0
    Set rsCharacter = MyDB.OpenRecordset("SELECT ScriptMatchingText, TripWord1Compare, TripWord2Compare, TripWord3Compare, TripWord4Compare, TripWord5Compare, TripWord1NS, TripWord2NS, TripWord3NS, TripWord4NS, TripWord5NS, WhereToLookInClient FROM tblScriptText WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenSnapshot)
    Do While (Not rsCharacter.EOF And lCount < cstlScriptMAX)
        lCount = lCount + 1
        gblzScripts(lCount) = UCase(MyCStr(rsCharacter!ScriptMatchingText))
        gblzTripWord1Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord1Compare))
        gblzTripWord2Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord2Compare))
        gblzTripWord3Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord3Compare))
        gblzTripWord4Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord4Compare))
        gblzTripWord5Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord5Compare))
        gblzTripWord1NS(lCount) = UCase(MyCStr(rsCharacter!TripWord1NS))
        gblzTripWord2NS(lCount) = UCase(MyCStr(rsCharacter!TripWord2NS))
        gblzTripWord3NS(lCount) = UCase(MyCStr(rsCharacter!TripWord3NS))
        gblzTripWord4NS(lCount) = UCase(MyCStr(rsCharacter!TripWord4NS))
        gblzTripWord5NS(lCount) = UCase(MyCStr(rsCharacter!TripWord5NS))
        gblzWhereToLookInClient(lCount) = UCase(MyCStr(rsCharacter!WhereToLookInClient))
        rsCharacter.MoveNext
    Loop
    Set rsCharacter = Nothing
    Exit Sub
Err_subLoadScriptsToMemory:
    basPrintMessage64 Err.Description
End Sub
Public Function zRemoveWord(zLine As String, zWord As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim lLoc As Long
    lLoc = InStr(zLine, Trim(zWord) & " ")
    If (lLoc > 0) Then
        zReturn = Trim(Trim(Mid(zLine, 1, lLoc - 1)) & " " & Trim(Mid(zLine, lLoc + 1 + Len(zWord))))
    Else
        zReturn = zLine
    End If
    zRemoveWord = zReturn
End Function
Public Function zScriptFormat(zEventLine As String) As String
    Const bDebug = False
    Dim zReturn As String
    Dim zHoldEventLine As String
    Dim lCountWEMAX As Long
    Dim zProcessLine As String
    Dim lCountWE As Long
    Dim zProcessLineChar As String
    Dim zProcessLineFinished As String
    Dim bNumeric As Boolean
    Dim bNumericNextChar As Boolean

    'PROCESS AND FORMAT: zEventLine
    zHoldEventLine = MyCStr(zEventLine)
    lCountWEMAX = Len(zHoldEventLine)
    zProcessLine = ""
    For lCountWE = 1 To lCountWEMAX 'Strip all spaces so we can put the spaces in correctly by our format
        zProcessLineChar = Mid(zHoldEventLine, lCountWE, 1)
        If (zProcessLineChar <> " ") Then 'remove all spaces
            zProcessLine = zProcessLine & zProcessLineChar
        End If
    Next lCountWE
    zProcessLineFinished = ""
    If (bDebug) Then Debug.Print "  BE|" & zProcessLine
    lCountWEMAX = Len(zProcessLine)
    For lCountWE = 1 To lCountWEMAX 'Format spaces to our format
        zProcessLineChar = Mid(zProcessLine, lCountWE, 1)
        bNumeric = IsNumeric(zProcessLineChar) <> 0 Or zProcessLineChar = "%"
        bNumericNextChar = IsNumeric(Mid(zProcessLine, lCountWE + 1, 1)) Or Mid(zProcessLine, lCountWE + 1, 1) = "%"
        If (bNumeric) Then
            If (Not bNumericNextChar) Then
                zProcessLineFinished = zProcessLineFinished & zProcessLineChar & " " 'We add spaces before % < > ! and #s
            Else
                zProcessLineFinished = zProcessLineFinished & zProcessLineChar  'Just add the Char
            End If
        Else
            If (bNumericNextChar) Then
                zProcessLineFinished = zProcessLineFinished & zProcessLineChar & " " 'We add spaces before % < > ! and #s
            Else
                zProcessLineFinished = zProcessLineFinished & zProcessLineChar  'Just add the Char
            End If
        End If
    Next lCountWE
    zProcessLineChar = zProcessLineFinished & " "
    zHoldEventLine = zProcessLineChar 'spaces are now put in properly
    lCountWEMAX = Len(zHoldEventLine)
    If (bDebug) Then Debug.Print "  AE|" & zHoldEventLine
    zReturn = zHoldEventLine
    zScriptFormat = zReturn
End Function

Public Function bScriptTrigger(zScriptLine As String) As Boolean
    Dim lCount As Long
    Dim zChar As String
    Dim zHoldLine As String
    Dim zTrigger As String
    Dim bReturn As Boolean
    
    zHoldLine = Trim(zScriptLine)
    lCount = Len(zHoldLine)
    zTrigger = ""
    If (lCount > 1) Then
        zChar = Mid(zScriptLine, lCount, 1)
        Do While (lCount > 1 And zChar <> " ") 'cut out last word which is the trigger to look for
            lCount = lCount - 1
            zChar = Mid(zScriptLine, lCount, 1)
        Loop
        zTrigger = Mid(zScriptLine, lCount + 1)
    End If
    
    bReturn = (bTriggers(zTrigger)) 'found a trigger?
    bScriptTrigger = bReturn
End Function

Public Sub subRemoveTheGraphicalMap(lCharacterNameID As Long, zInfoXYZ As String)
On Error GoTo Err_Check
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim rsSetUp As Recordset
    
    If (Len(zInfoXYZ) > 0) Then
        subExtractXYZFromInfoXYZ zInfoXYZ, lX, lY, lZ
        
        'Allow the User to turn Mapping on or Off
        Set rsSetUp = MyDB.OpenRecordset("SELECT CharacterNameID, X, Y, Z, Codes FROM tblMapper WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
        If (Not rsSetUp.EOF) Then 'Map location in the db not there? create the location!
            MyDB.Execute "DELETE CharacterNameID FROM tblMapper WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
        End If
        Set rsSetUp = Nothing
    End If
    Exit Sub
Err_Check:
    MsgBox "subRemoveTheGraphicalMap," & vbCrLf & "Err#" & Err.Number & vbCrLf & Err.Description
End Sub


Public Sub subRecordTheGraphicalMap(lCharacterNameID As Long, zInfoXYZ As String)
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lLenXYZ As Long
    Dim zHoldInfoXYZ As String
    Dim zNum As String
    Dim lStatus As Long
    Dim lCount As Long
    
    If (Len(zInfoXYZ) > 0) Then
        'Allow the User to turn Mapping on or Off
        subExtractXYZFromInfoXYZ zInfoXYZ, lX, lY, lZ
        'Save The Map Location
        Set rsSetUp = MyDB.OpenRecordset("SELECT CharacterNameID, X, Y, Z, Codes FROM tblMapper WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
        If (rsSetUp.EOF) Then 'Map location in the db not there? create the location!
            MyDB.Execute "INSERT INTO tblMapper ( CharacterNameID, X, Y, Z, Codes ) SELECT " & gbllCharacterNameID & ", '" & lX & "', '" & lY & "', '" & lZ & "','O';", dbFailOnError
        End If
        Set rsSetUp = Nothing
    End If
End Sub

Public Sub subExtractXYZFromInfoXYZ(zInfoXYZ As String, ByRef lX As Long, ByRef lY As Long, ByRef lZ As Long)
    Dim lCount As Long
    Dim lType As Long
    Dim lLen As Long
    Dim zChr As String
    Dim zX As String
    Dim zY As String
    Dim zZ As String
    Dim bFlag As Boolean
    
    lType = 0: bFlag = True
    zX = "": zY = "": zZ = ""
    lLen = Len(zInfoXYZ)
    
    For lCount = 1 To lLen
        zChr = Mid(zInfoXYZ, lCount, 1)
        If (IsNumeric(zChr) Or zChr = "-" Or zChr = "+") Then
            If (bFlag) Then lType = lType + 1
            bFlag = False
            Select Case lType
                Case 1
                    zX = zX & zChr
                Case 2
                    zY = zY & zChr
                Case 3
                    zZ = zZ & zChr
            End Select
        Else
            bFlag = True
        End If
    Next lCount
    lX = MyCLng(MyCStr(zX))
    lY = MyCLng(MyCStr(zY))
    lZ = MyCLng(MyCStr(zZ))
End Sub

Public Function bProcessScriptStatusBar(lScriptLoc As Long) As Boolean
On Error Resume Next
    'TRISKER FINISH Status Bar and Elsewhere selections by user's Script type combobox S or E
    Dim zScriptLine As String
    Dim lStatusBarValue As Long
    Dim lLessETo As Long
    Dim lMoreETo As Long
    Dim lEqualTo As Long
    Dim lLoc As Long
    Dim lLastNumber As Long
    Dim zQualifer As String
    Dim bReturn As Boolean
    Dim lCount As Long
    
    bReturn = False
    If (gbllScriptOutOfControl < 5) Then
        zScriptLine = gblzScripts(lScriptLoc)
        
        'zScripts(lCount) = UCase(MyCStr(rsCharacter!ScriptMatchingText))
        'zTripWord1Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord1Compare))
        'zTripWord2Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord2Compare))
        'zTripWord3Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord3Compare))
        'zTripWord4Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord4Compare))
        'zTripWord5Compare(lCount) = UCase(MyCStr(rsCharacter!TripWord5Compare))
        'zTripWord1NS(lCount) = UCase(MyCStr(rsCharacter!TripWord1NS))
        'zTripWord2NS(lCount) = UCase(MyCStr(rsCharacter!TripWord2NS))
        'zTripWord3NS(lCount) = UCase(MyCStr(rsCharacter!TripWord3NS))
        'zTripWord4NS(lCount) = UCase(MyCStr(rsCharacter!TripWord4NS))
        'zTripWord5NS(lCount) = UCase(MyCStr(rsCharacter!TripWord5NS))
        
        lLessETo = 0
        lMoreETo = 0
        lEqualTo = 0
        lLoc = 0
        lLastNumber = 0
        
        zQualifer = ""
        Select Case gblzTripWord1NS(lScriptLoc)
            Case "S" 'Comparison by Qualifier - S for String comparison
                Select Case UCase(Mid(gblzTripWord1Compare(lScriptLoc), 1, 1))
                    Case "H"
                        lStatusBarValue = gbllInfoHP
                    Case "E"
                        lStatusBarValue = gbllInfoEssence
                    Case "M"
                        lStatusBarValue = gbllInfoMana
                    Case "S"
                        lStatusBarValue = gbllInfoSoul
                End Select
                
                If (lStatusBarValue <> 0) Then
                    If (lLessETo = 0) Then
                        lLessETo = InStr(zScriptLine, "< ")
                        If (lLessETo <> 0) Then zQualifer = "< "
                    End If
                    If (lLessETo = 0) Then
                        lLessETo = InStr(zScriptLine, "<= ")
                        If (lLessETo <> 0) Then zQualifer = "<= "
                    End If
                    If (lMoreETo = 0) Then
                        lMoreETo = InStr(zScriptLine, "> ")
                        If (lMoreETo <> 0) Then zQualifer = "> "
                    End If
                    If (lMoreETo = 0) Then
                        lMoreETo = InStr(zScriptLine, ">= ")
                        If (lMoreETo <> 0) Then zQualifer = ">= "
                    End If
                    If (lEqualTo = 0) Then
                        lEqualTo = InStr(zScriptLine, " = ")
                        If (lEqualTo <> 0) Then zQualifer = " = "
                    End If
                    If (lEqualTo = 0) Then
                        lEqualTo = InStr(zScriptLine, ":= ")
                        If (lEqualTo <> 0) Then zQualifer = ":= "
                    End If
                    
                    lLoc = 0
                    If (lLoc = 0) Then lLoc = lLessETo
                    If (lLoc = 0) Then lLoc = lMoreETo
                    If (lLoc = 0) Then lLoc = lEqualTo
                    If (lLoc <> 0) Then
                        lLastNumber = MyCLng(zKeepNumbersOnly(zCut(zScriptLine, zQualifer, "THEN")))
                        If (lLessETo <> 0) Then bReturn = (lStatusBarValue < lLastNumber) 'DO NOT DO EQUAL TOO
                        If (lMoreETo <> 0) Then bReturn = (lStatusBarValue > lLastNumber)
                        If (lEqualTo <> 0) Then bReturn = (lStatusBarValue = lLastNumber)
                    End If
                End If
            Case "S" 'STRING
                'TRISKER FINSIH THIS
                'If (zWhereToLookInClient(lScriptLoc) = "S") Then 'Status Bar only
                'End If
        End Select
        If (bReturn) Then
            gbllScriptOutOfControl = gbllScriptOutOfControl + 1
        End If
    End If
    bProcessScriptStatusBar = bReturn
End Function
Public Function bEvents(zEventLine As String) As Boolean
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim rsSetUp As Recordset
    Dim lSemiColon As Long
    Dim zHandleSemiColon As String
    Dim lLocSemiColon As String
    Dim zButtonLabel As String
    Dim lCount As Long
    Dim zHoldEventLine As String
    Dim zHoldEventMatchingText As String
    Dim zSoundFilename As String
    Dim zImageFilename As String
'    Dim rsSetUp As Recordset
'    lEventTextID = MyCLng(lblEventTextID.text)
'    If (lEventTextID <> 0) Then
'        MyDB.Execute "UPDATE tblEventText SET CharacterNameID=" & gbllCharacterNameID & ", EventMatchingText='" & zRemoveSQLCrashChars(txtEventMatchingText.Text) & "', EventProgrammedReply='" & zRemoveSQLCrashChars(txtEventProgrammedReply.Text) & "', SoundFilename='" & zRemoveSQLCrashChars(txtSoundFilename.Text) & "', SoundType='" & zRemoveSQLCrashChars(cbxSoundType.Text) & "', PlayerType='" & zRemoveSQLCrashChars(cbxPlayerType.Text) & "' WHERE EventTextID=" & lEventTextID & ";", dbFailOnError
'    Else
'        MyDB.Execute "INSERT INTO tblEventText ( CharacterNameID, EventMatchingText, EventProgrammedReply, SoundFilename, SoundType, PlayerType ) SELECT " & gbllCharacterNameID & ", '" & zRemoveSQLCrashChars(txtEventMatchingText.Text) & "', '" & zRemoveSQLCrashChars(txtEventProgrammedReply.Text) & "', '" & zRemoveSQLCrashChars(txtSoundFilename.Text) & "', '" & zRemoveSQLCrashChars(cbxSoundType.Text) & "', '" & zRemoveSQLCrashChars(cbxPlayerType.Text) & "';", dbFailOnError
'    End If
'    Set rsSetUp = Nothing
'    If (bEvents(zSendClientData)) Then 'found a Event?
'                        bSpecialKey = True 'Yes
'                    Else
'                        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zSendClientData & vbCrLf
'                    End If
    
    
    'Events and Events - when you type a word it will be checked against here:
    bReturn = False
    'Debug.Print ">>" & zEventLine
    zHoldEventLine = UCase(zEventLine)
    Set rsSetUp = MyDB.OpenRecordset("SELECT EventTextID, CharacterNameID, EventMatchingText, EventProgrammedReply, ImageFilename, SoundFilename FROM tblEventText WHERE CharacterNameID=" & gbllCharacterNameID & ";", dbOpenSnapshot)
    Do While (Not rsSetUp.EOF)
        'Debug.Print UCase(zEventLine) & " // " & UCase(rsSetUp!EventMatchingText)
        'UCase(zEventLine) = UCase(rsSetUp!EventMatchingText)) Then
        zHoldEventMatchingText = UCase(rsSetUp!EventMatchingText)
        'Debug.Print zHoldEventLine
        'Debug.Print zHoldEventMatchingText
        If (InStr(zHoldEventLine, zHoldEventMatchingText) > 0) Then
            bReturn = True
            zHandleSemiColon = MyCStr(rsSetUp!EventProgrammedReply)
            'cmdPlayer_Click() 'SoundFilename
            zSoundFilename = MyCStr(rsSetUp!SoundFilename)
            zImageFilename = ""
            If (gblEventsToggle And Not gblbMASTERLock) Then 'an image could come from two places, this soundffilename but not a .wav or .mp3 but a .bmp or from the database as imagefilename
                zImageFilename = MyCStr(rsSetUp!ImageFilename)
                If (Len(zImageFilename) = 0) Then 'Nothing in the database?
                    If (Len(zSoundFilename) > 4) Then zImageFilename = Mid(zSoundFilename, 1, InStr(zSoundFilename, ".") - 1) & ".BMP"                   'this image will be found in the sound directory
                End If
            End If
            
            If (bFileExists(zImageFilename)) Then
                'Debug.Print zImageFilename
                subResetEventPicbox
                subShowEventPicbox zImageFilename 'frmMain!picEventTriggered.Picture = LoadPicture(zImageFilename)
            End If
            
            If (gblbSoundAllowed) Then
                If (Len(zSoundFilename) > 0) Then
                    Select Case cstPlayerType
                        Case 1 'method 2 - works but cuts out the next play
                            Set Player = Nothing
                            Set Player = New FilgraphManager 'This is the sound and music player
                                Player.RenderFile zSoundFilename 'testcode is something like "C:\noname.mp3"
                                Player.Run
                        Case 2 'wavs only and when you quit the application it keeps playing
                            PlaySound zSoundFilename, ByVal 0&, SND_FILENAME Or SND_ASYNC 'wavs only but will play if the application shuts off
                        Case 3 'Suppose to let you play two sounds at once - not sure what is wrong with it
                            mciSendString "open " & zSoundFilename & " type mpegvideo alias FirstSound", "", 0, 0
                            mciSendString "play FirstSound", "", 0, 0
                            'mciSendString("open " & fileName & " type mpegvideo alias SecondSound", String.Empty, 0, 0)
                            'mciSendString("play SecondSound", String.Empty, 0, 0)
                            'mciSendString("close FirstSound", String.Empty, 0, 0) 'close in reverse order if possible
                            'mciSendString("close SecondSound", String.Empty, 0, 0)
                        Case 4 'not working
                            Dim b As String
                            b = StrConv(LoadResData(101, "custom"), vbUnicode)
                            sndPlaySound zSoundFilename, Flags&
                    End Select
                End If
            End If
            lLocSemiColon = InStr(zHandleSemiColon, ";")
            If (lLocSemiColon <> 0) Then 'repeat this line until all commands separated by a semi-colon is processed
                zHandleSemiColon = MyCStr(rsSetUp!EventProgrammedReply) & ";" 'SO WE CAN END OUT
                Do While (lLocSemiColon <> 0)
                    'Debug.Print "H>" & Mid(zHandleSemiColon, 1, lLocSemiColon - 1)
                    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData Mid(zHandleSemiColon, 1, lLocSemiColon - 1) & vbCrLf
                    zHandleSemiColon = Mid(zHandleSemiColon, lLocSemiColon + 1)
                    lLocSemiColon = InStr(zHandleSemiColon, ";")
                    If (lLocSemiColon <> 0) Then
                        frmMain!tmrEventPause.Enabled = True
                        Do While (frmMain!tmrEventPause.Enabled)  'when the timer hits 500 this shuts off by event
                            DoEvents
                        Loop
                    End If
                Loop
            Else
                'Debug.Print "S>" & Mid(zHandleSemiColon, 1, lLocSemiColon - 1)
                If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zHandleSemiColon & vbCrLf
            End If
        End If
        rsSetUp.MoveNext
    Loop
    Set rsSetUp = Nothing
    Exit Function
Err_Check:
    Select Case Err.Number
        Case -2147220970
            MsgBox "bEvents," & vbCrLf & "File not found linked to an event playback." & vbCrLf & zHoldEventMatchingText, vbCritical
        Case Else
            MsgBox "bEvents," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
    End Select
End Function

Public Function bTriggers(zTriggerLine As String) As Boolean
    Dim bReturn As Boolean
    Dim rsSetUp As Recordset
    Dim lSemiColon As Long
    Dim zHandleSemiColon As String
    Dim lLocSemiColon As String
    Dim zButtonLabel As String
    Dim lCount As Long
    
    'Triggers and Events - when you type a word it will be checked against here:
    bReturn = False
    Set rsSetUp = MyDB.OpenRecordset("SELECT TriggerTextID, CharacterNameID, TriggerMatchingText, TriggerProgrammedReply, SoundFilename FROM tblTriggerText WHERE CharacterNameID=" & gbllCharacterNameID & ";", dbOpenSnapshot)
    Do While (Not rsSetUp.EOF)
        If (UCase(zTriggerLine) = UCase(rsSetUp!TriggerMatchingText)) Then
            bReturn = True
            zHandleSemiColon = MyCStr(rsSetUp!TriggerProgrammedReply)
            lLocSemiColon = InStr(zHandleSemiColon, ";")
            If (lLocSemiColon <> 0) Then 'repeat this line until all commands separated by a semi-colon is processed
                zHandleSemiColon = MyCStr(rsSetUp!TriggerProgrammedReply) & ";" 'SO WE CAN END OUT
                Do While (lLocSemiColon <> 0)
                    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData Mid(zHandleSemiColon, 1, lLocSemiColon - 1) & vbCrLf
                    zHandleSemiColon = Mid(zHandleSemiColon, lLocSemiColon + 1)
                    lLocSemiColon = InStr(zHandleSemiColon, ";")
                    If (lLocSemiColon <> 0) Then
                        frmMain!tmrTriggerPause.Enabled = True
                        Do While (frmMain!tmrTriggerPause.Enabled)  'when the timer hits 500 this shuts off by event
                            DoEvents
                        Loop
                    End If
                Loop
            Else
                If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zHandleSemiColon & vbCrLf
            End If
        End If
        rsSetUp.MoveNext
    Loop
    Set rsSetUp = Nothing
    
    'Buttons can act like triggers too
    Set rsSetUp = MyDB.OpenRecordset("SELECT * FROM tblButtons WHERE CharacterNameID=" & gbllCharacterNameID & ";", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        For lCount = 1 To 20 'only 20 in the tblButtons
            Select Case lCount
                Case 1
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel1)
                Case 2
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel2)
                Case 3
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel3)
                Case 4
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel4)
                Case 5
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel5)
                Case 6
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel6)
                Case 7
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel7)
                Case 8
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel8)
                Case 9
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel9)
                Case 10
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel10)
                Case 11
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel11)
                Case 12
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel12)
                Case 13
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel13)
                Case 14
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel14)
                Case 15
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel15)
                Case 16
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel16)
                Case 17
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel17)
                Case 18
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel18)
                Case 19
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel19)
                Case 20
                    zButtonLabel = MyCStr(rsSetUp!ButtonLabel20)
            End Select
            
            If (UCase(zTriggerLine) = UCase(zButtonLabel)) Then
                bReturn = True
                Select Case lCount
                    Case 1
                        zButtonLabel = MyCStr(rsSetUp!Button1)
                    Case 2
                        zButtonLabel = MyCStr(rsSetUp!Button2)
                    Case 3
                        zButtonLabel = MyCStr(rsSetUp!Button3)
                    Case 4
                        zButtonLabel = MyCStr(rsSetUp!Button4)
                    Case 5
                        zButtonLabel = MyCStr(rsSetUp!Button5)
                    Case 6
                        zButtonLabel = MyCStr(rsSetUp!Button6)
                    Case 7
                        zButtonLabel = MyCStr(rsSetUp!Button7)
                    Case 8
                        zButtonLabel = MyCStr(rsSetUp!Button8)
                    Case 9
                        zButtonLabel = MyCStr(rsSetUp!Button9)
                    Case 10
                        zButtonLabel = MyCStr(rsSetUp!Button10)
                    Case 11
                        zButtonLabel = MyCStr(rsSetUp!Button11)
                    Case 12
                        zButtonLabel = MyCStr(rsSetUp!Button12)
                    Case 13
                        zButtonLabel = MyCStr(rsSetUp!Button13)
                    Case 14
                        zButtonLabel = MyCStr(rsSetUp!Button14)
                    Case 15
                        zButtonLabel = MyCStr(rsSetUp!Button15)
                    Case 16
                        zButtonLabel = MyCStr(rsSetUp!Button16)
                    Case 17
                        zButtonLabel = MyCStr(rsSetUp!Button17)
                    Case 18
                        zButtonLabel = MyCStr(rsSetUp!Button18)
                    Case 19
                        zButtonLabel = MyCStr(rsSetUp!Button19)
                    Case 20
                        zButtonLabel = MyCStr(rsSetUp!Button20)
                End Select
                If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zButtonLabel & vbCrLf
            End If
        Next lCount
    End If
    Set rsSetUp = Nothing
    bTriggers = bReturn
End Function

Public Function bFileExists(zFilename As String) As Boolean
On Error Resume Next
    Dim tmpRv As Long
    Dim bReturn As Boolean
    bReturn = False
    If (Len(zFilename) <> 0) Then
        tmpRv = GetAttr(zFilename)
        bReturn = (Not Err And tmpRv <> 0)
    End If
    bFileExists = bReturn
End Function
Public Function bFileExist(zFilename As String) As Boolean
On Error Resume Next
    Dim tmpRv As Long
    tmpRv = GetAttr(zFilename)
    bFileExist = Not Err And tmpRv <> 0
End Function
Public Sub subCoAClientLoad()
On Error Resume Next
    Const cstFileName = "coaclient.exe"
    Dim zPathAndFileName As String
    Dim res As Integer
    If (bFileExist(cstFileName)) Then
        zPathAndFileName = cstFileName
        res = Shell(zPathAndFileName, vbNormalFocus)
    End If
End Sub
Public Sub subLoadFontNoteInfo()
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Set rsPlayer = MyDB.OpenRecordset("SELECT FontNoteName, FontNoteSize FROM tblClientSetUp;", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        gblzFontNoteName = MyCStr(rsPlayer!FontNoteName)
        gbllFontNoteSize = MyCLng(rsPlayer!FontNoteSize)
    End If
    Set rsPlayer = Nothing
    'Debug.Print "FONT: " & gblzFontNoteName & " " & gbllFontNoteSize
    Exit Sub
Err_Check:
    MsgBox "subLoadFontNoteInfo," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub 'gblzFontNoteName gbllFontNoteSize
Public Sub subProgramName()
    Dim zChar As String
    Dim zNewName As String
    
    zChar = Chr(65 + (lRandom(25) - 1))
    
    Select Case lRandom(12)
        Case 1
            zNewName = "Got that Feeling of, Bash N Crash Day!!"
        Case 2
            zNewName = "COMMAND ON DEMAND GAMES: Play GUESSWORD, SHOWTIME, ROULETTE, HORSES, today!!"
        Case 3
            zNewName = "Wuv is in the RELOAD."
        Case 4
            zNewName = "AURAS like SANCTUARY halves your hating damage."
        Case 5
            zNewName = "Hit em' hard, hit 'em harder, there is no get-hit!"
        Case 6, 7, 8
            zNewName = "Harness your Tricks! Triggers make text games so much more fun, we have them, go ahead and try them."
        Case Else
            zNewName = "Each Class has a Power Skill. HP, HITALL, BOLT etc..."
    End Select
    If (Len(zNewName) > 0) Then
        mdiMain.Caption = "MAIN - City of Ages Telnet Client [" & Chr(65 + lRandom(25)) & Chr(65 + lRandom(25)) & "] - " & zNewName
    End If
End Sub
Public Sub subScannedNameLoad(zHoldOEventLine As String)
On Error GoTo Err_Check
    Dim lScan As Long
    Dim lComma As Long
    Dim zMid As String
    Dim lLenEL As Long
    Dim lListScan As Long
    Dim zHoldScannedName As String
    Dim lQoLock1 As Long
    Dim lQmLock1 As Long
    Dim lQmLock2 As Long
    Dim lQoLock2 As Long
    Dim lQLock3 As Long
    Dim bQ1m As Boolean
    Dim bQ1o As Boolean
    Dim bQ1 As Boolean
    Dim bQ2 As Boolean
    Dim bQ3 As Boolean
    Dim bListboxLoad As Boolean
    
    bQ1 = False
    bListboxLoad = False
    lLenEL = Len(zHoldOEventLine)
        
    'If InStr(zHoldOEventLine, "sentinel") Then
    '    If InStr(zHoldOEventLine, ",") Then
    '        Debug.Print zHoldOEventLine
    '    End If
    'End If
    'zHoldOEventLine = Chr(27) & "[1;35m" & Chr(27) & "[0;35ma sentinel, stands here solemnly watching the gate " & Chr(27) & "[1;31m[99%]"
    
    For lScan = 1 To lLenEL
        If (Mid(zHoldOEventLine, lScan, 1) = Chr(27)) Then '27 is a filter check
            zHoldScannedName = ""
            lQmLock1 = lScan
            lQoLock1 = lScan
            lQmLock2 = 0
            lQoLock2 = 0
            lQLock3 = 0
            bQ1 = True
            bQ1m = False
            bQ1o = False
            bQ2 = False
            bQ3 = False
            lComma = 0
        End If
        If (bQ1) Then
            If (Mid(zHoldOEventLine, lScan + 1, 1) = "m") Then
                Select Case Mid(zHoldOEventLine, lScan, 1)
                    Case "5"
                        'Debug.Print "MOB DETECTED"
                        lQmLock2 = lScan + 2
                        bQ1m = True 'mob
                    Case "0", "7" 'gray and white
                        'Debug.Print "OBJECT DETECTED"
                        If (InStr(zHoldOEventLine, ":") = 0) Then
                            lQoLock2 = lScan + 2
                            bQ1o = True 'object
                        End If
                End Select
                bQ2 = (bQ1m Or bQ1o)
            End If
        End If
        
        If (bQ1 And bQ2 And Mid(zHoldOEventLine, lScan, 1) = ",") Then
            lComma = lScan
            lQLock3 = lScan
            bQ3 = True
        End If
        
        If (bQ3) Then 'qualifier 3 done!
            If (bQ1m) Then gbllListScannedNameMCounter = gbllListScannedNameMCounter + 1
            If (bQ1o) Then gbllListScannedNameOCounter = gbllListScannedNameOCounter + 1

            If (bQ1m) Then zHoldScannedName = UCase(Mid(zHoldOEventLine, lQmLock2, Abs((lQLock3) - (lQmLock2))))
            If (bQ1o) Then zHoldScannedName = UCase(Mid(zHoldOEventLine, lQoLock2, Abs((lQLock3) - (lQoLock2))))
            If (Mid(zHoldScannedName, 1, 2) = "A ") Then zHoldScannedName = Mid(zHoldScannedName, 3)
            If (Mid(zHoldScannedName, 1, 3) = "AN ") Then zHoldScannedName = Mid(zHoldScannedName, 4)
            If (Mid(zHoldScannedName, 1, 4) = "THE ") Then zHoldScannedName = Mid(zHoldScannedName, 5)
            
            If (Len(zHoldScannedName) > 0) Then
                bListboxLoad = True
                If ((bQ1m) And (gbllListScannedNameMCounter >= 1 And gbllListScannedNameMCounter <= cstlScannedNameMAX)) Then gblzListScannedMName(gbllListScannedNameMCounter) = zHoldScannedName
                If ((bQ1o) And (gbllListScannedNameOCounter >= 1 And gbllListScannedNameOCounter <= cstlScannedNameMAX)) Then gblzListScannedOName(gbllListScannedNameOCounter) = zHoldScannedName
                zHoldScannedName = ""
            End If
            
            If (lComma <> 0) Then
                lScan = lScan + lComma
                If (lScan > lLenEL) Then lScan = lLenEL
            End If
            
            bQ3 = False
        End If
    Next lScan
    
    If (bListboxLoad) Then
        If (gbllListScannedNameMCounter >= cstlScannedNameMAX) Then
            mdiMain!lstMobName.Clear
            gbllListScannedNameMCounter = 0
            For lListScan = 1 To cstlScannedNameMAX
                gblzListScannedMName(lListScan) = ""
            Next lListScan
        End If
                
        If (gbllListScannedNameOCounter >= cstlScannedNameMAX) Then
            mdiMain!lstObjectName.Clear
            gbllListScannedNameOCounter = 0
            For lListScan = 1 To cstlScannedNameMAX
                gblzListScannedOName(lListScan) = ""
            Next lListScan
        End If
        
        For lScan = cstlScannedNameMAX To 1 Step -1
            zHoldScannedName = ""
            If (bQ1m) Then zHoldScannedName = gblzListScannedMName(lScan)
            If (bQ1o) Then zHoldScannedName = gblzListScannedOName(lScan)
            
            If (Len(zHoldScannedName) > 0) Then
                If (bQ1m) Then mdiMain!lstMobName.AddItem zHoldScannedName 'our mob list box
                If (bQ1o) Then mdiMain!lstObjectName.AddItem zHoldScannedName 'our object list box
                DoEvents
            End If
        Next lScan
    End If
    Exit Sub
Err_Check:
    MsgBox "subScannedNameLoad," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub
