VERSION 5.00
Begin VB.Form frmHelpAdminBuildMob 
   Appearance      =   0  'Flat
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "ADMINISTRATION IMMORTAL SKILLS - MOBS"
   ClientHeight    =   13680
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12285
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   11.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpAdminBuildMob.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   13680
   ScaleWidth      =   12285
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   23
      Left            =   120
      TabIndex        =   48
      Top             =   11160
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   22
      Left            =   120
      TabIndex        =   47
      Top             =   10200
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   21
      Left            =   120
      TabIndex        =   46
      Text            =   "MAPA"
      Top             =   9240
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   19
      Left            =   120
      TabIndex        =   45
      Text            =   "MEP"
      Top             =   6840
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   17
      Left            =   120
      TabIndex        =   44
      Text            =   "MSE"
      Top             =   5880
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   4
      Left            =   120
      TabIndex        =   43
      Text            =   "DESC"
      Top             =   4440
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   15
      Left            =   120
      TabIndex        =   42
      Text            =   "MID"
      Top             =   1560
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   41
      Text            =   "MGIV"
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   5
      Left            =   120
      TabIndex        =   40
      Text            =   "MEDIT"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   24
      Left            =   1200
      TabIndex        =   38
      Top             =   10200
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   23
      Left            =   1200
      TabIndex        =   37
      Top             =   11640
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   18
      Left            =   120
      TabIndex        =   36
      Top             =   11640
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   22
      Left            =   1200
      TabIndex        =   35
      Top             =   11160
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   21
      Left            =   1200
      TabIndex        =   34
      Text            =   "Mobile speak editor, when you move into a room the mob will speak and emote, this is the editor to do this."
      Top             =   5880
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   20
      Left            =   1200
      TabIndex        =   33
      Top             =   10680
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   16
      Left            =   120
      TabIndex        =   32
      Top             =   10680
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   19
      Left            =   1200
      TabIndex        =   31
      Text            =   "IMMO MAPA <mobileid> will allow the mob to move around on a path.MDPA <mobid> deletes, MLPA views paths."
      Top             =   9240
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   18
      Left            =   1200
      TabIndex        =   30
      Text            =   "MFORGE DESC <long desc> Is so you can descript your mobile once it is done."
      Top             =   4440
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   29
      Text            =   "MD"
      Top             =   3960
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   17
      Left            =   1200
      TabIndex        =   28
      Text            =   "To delete a mobile look at it then type IMMO MD (mobile ID)  Mobile ID is also MID#"
      Top             =   3960
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   16
      Left            =   1200
      TabIndex        =   27
      Text            =   "First you create the Mob Quest Herd which is one data record, then you tag all the mobiles that are involved"
      Top             =   8280
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   15
      Left            =   1200
      TabIndex        =   26
      Text            =   "with the given HerdMobID. Once given this ID do not forget it till you are done tagging the mobiles involved."
      Top             =   8760
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   24
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   23
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   1
      Left            =   120
      TabIndex        =   22
      Text            =   "MC"
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   21
      Text            =   "IMMO MC <mobname, mobshortdescription> this will create a mob, the comma is required for consistency."
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   20
      Text            =   "Now MEDIT <mobid> to skill  up the mobile, return to this mob anytime with the GOTO command."
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   3
      Left            =   1200
      TabIndex        =   19
      Text            =   "After you lock onto your mobile (also shown in SCORE) use the MID command to see what you can skill."
      Top             =   1560
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   18
      Text            =   "Use the capitol letters you see on each line to Mobile Forge skills to the mobile."
      Top             =   2040
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   17
      Text            =   "IMMO MGIV (objectid) (mobid) will mount the item to the mobile, look at the mobile afterwards."
      Top             =   2520
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   6
      Left            =   120
      TabIndex        =   16
      Text            =   "DROP"
      Top             =   3000
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   15
      Text            =   "IMMO DROP (partial object name) (mobile ID) this will undo IMMO MGIV forcing the item to the ground."
      Top             =   3000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   7
      Left            =   120
      TabIndex        =   14
      Text            =   "MQUE"
      Top             =   3480
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   7
      Left            =   1200
      TabIndex        =   13
      Text            =   "IMMO MQUE (full mobile name)|(give quest object description)|(object name that the player receives)"
      Top             =   3480
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   8
      Left            =   120
      TabIndex        =   12
      Text            =   "MCOPY"
      Top             =   4920
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   8
      Left            =   1200
      TabIndex        =   11
      Text            =   "After you are completely done editing a mob and the mob's skills you can make a few with IMMO MCOPY "
      Top             =   4920
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   9
      Left            =   120
      TabIndex        =   10
      Text            =   "MERC"
      Top             =   5400
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   9
      Left            =   1200
      TabIndex        =   9
      Text            =   "IMMO MERC <mob id> <item word> <price> places and item on the mob for sale making them a merchant."
      Top             =   5400
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   10
      Left            =   120
      TabIndex        =   8
      Text            =   "CREATE"
      Top             =   9720
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   10
      Left            =   1200
      TabIndex        =   7
      Text            =   "IMMO CREATE <moblevel> <1 to 3 words short desc>   ie. IMMO CREATE 50 shakey skeletons  [makes 5]"
      Top             =   9720
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   11
      Left            =   120
      TabIndex        =   6
      Text            =   "MQE"
      Top             =   6360
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   11
      Left            =   1200
      TabIndex        =   5
      Text            =   "Mob Quest Editor"
      Top             =   6360
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   12
      Left            =   1200
      TabIndex        =   4
      Text            =   "Mobs can emote at players"
      Top             =   6840
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   13
      Left            =   120
      TabIndex        =   3
      Text            =   "MPE"
      Top             =   7320
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   13
      Left            =   1200
      TabIndex        =   2
      Text            =   "Mob Phrase Editor, the player command TALK uses this editor abilities."
      Top             =   7320
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   14
      Left            =   120
      TabIndex        =   1
      Text            =   "MQHE"
      Top             =   7800
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      Height          =   450
      Index           =   14
      Left            =   1200
      TabIndex        =   0
      Text            =   "Mob Quest Herd Editor, this quest is about a group of mobiles, when you attack one you also have the others."
      Top             =   7800
      Width           =   11000
   End
   Begin VB.Label Label1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   735
      Left            =   1200
      TabIndex        =   39
      Top             =   12840
      Width           =   10995
   End
   Begin VB.Label lblLastWordsFromTheAuthor 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   735
      Left            =   1200
      TabIndex        =   25
      Top             =   12120
      Width           =   10995
   End
End
Attribute VB_Name = "frmHelpAdminBuildMob"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
