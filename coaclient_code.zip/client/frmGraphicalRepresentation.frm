VERSION 5.00
Begin VB.Form frmGraphicalRepresentation 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00404040&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "PERCEPTION MACHINE ( intices you to read )"
   ClientHeight    =   8250
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   6630
   Icon            =   "frmGraphicalRepresentation.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   8250
   ScaleWidth      =   6630
   Begin VB.Timer tmrResetSpam 
      Interval        =   2500
      Left            =   0
      Top             =   0
   End
   Begin VB.PictureBox picTime 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   1815
      Left            =   120
      ScaleHeight     =   1815
      ScaleWidth      =   6375
      TabIndex        =   4
      Top             =   240
      Width           =   6375
   End
   Begin VB.Timer tmrGR 
      Interval        =   1000
      Left            =   -1200
      Top             =   120
   End
   Begin VB.PictureBox picWeather 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   6015
      Left            =   4680
      ScaleHeight     =   6015
      ScaleWidth      =   1815
      TabIndex        =   3
      Top             =   2040
      Width           =   1815
   End
   Begin VB.PictureBox picFrame2 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   3000
      Left            =   120
      ScaleHeight     =   3000
      ScaleWidth      =   4575
      TabIndex        =   0
      Top             =   5040
      Width           =   4575
   End
   Begin VB.PictureBox picFrame1 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   3000
      Left            =   120
      ScaleHeight     =   3000
      ScaleWidth      =   4575
      TabIndex        =   1
      Top             =   2040
      Width           =   4575
   End
   Begin VB.Label lblTranslate 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H0000FF00&
      Height          =   375
      Left            =   -1320
      TabIndex        =   2
      Top             =   120
      Visible         =   0   'False
      Width           =   375
   End
End
Attribute VB_Name = "frmGraphicalRepresentation"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstbUseDebugger = False
Const lMAXFrames = 2
Dim lFrame As Long
Dim lFPS As Long
Dim lTimer As Long
Dim lFileNameLoaded As Long
Private Sub lblTranslate_Change()
    Dim zTranslate As Variant
    Dim lBegin As Long
    Dim lEnd As Long
    Dim zWordMatch As String
    lFPS = lFPS + 1 'fails per sec then flush
    If (lFPS > 99) Then
        lFPS = 0
        subClrscr
    End If
    zTranslate = MyCStr(UCase(lblTranslate.Caption))
    If (InStr(zTranslate, "^") = 0) Then 'we disable text sends with caret symbol, so people cannot trigger eachother with channels
        'If (cstbUseDebugger) Then Debug.Print "Original = " & zTranslate
        If (InStr(zTranslate, "SUNRISE") <> 0 Or InStr(zTranslate, "SUN RISE") <> 0 Or InStr(zTranslate, "DAWN") <> 0 Or InStr(zTranslate, "MORNING") <> 0 Or InStr(zTranslate, "SUN SET") <> 0 Or InStr(zTranslate, "SUNSET") <> 0 Or InStr(zTranslate, "DUSK") <> 0 Or InStr(zTranslate, "EVENING") <> 0) Then frmGraphicalRepresentation.BackColor = &H404040   'reset to gray scale
        If (InStr(zTranslate, "ECLIPSE") <> 0) Then frmGraphicalRepresentation.BackColor = &H400040
        If (InStr(zTranslate, "SKULL") <> 0 And InStr(zTranslate, "MOON") <> 0) Then frmGraphicalRepresentation.BackColor = &H80&
        If (InStr(zTranslate, "ARMAGEDDON") <> 0) Then frmGraphicalRepresentation.BackColor = &H8080FF
        lBegin = InStr(zTranslate, "<<")
        lEnd = InStr(zTranslate, ">>") + 2
        If (lBegin <> 0 And lEnd <> 0 And lBegin < lEnd) Then
            'set autodetected Form Title
            zWordMatch = Mid(zTranslate, lBegin, lEnd - lBegin)
            frmGraphicalRepresentation.Caption = zRemoveColorCodes(zWordMatch)
        End If
    
        subTranslateScanDatabase zTranslate
    End If
End Sub
Private Sub subTranslateScanDatabase(zPassTranslation As Variant)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zFilename As String
    Dim zIgnoreWhenMatchingInWords As String
    Dim zMustHaveWhenMatchingInWords As String
    Dim zWordMatch As String
    Dim zTranslation As String
    Dim lType As Long
    Dim lCount As Long
    Dim lGate1 As Long
    Dim lGate2a As Long
    Dim lGate2b As Long
    Dim lLenIgnore As Long
    Dim lLenMustHave As Long
    Dim bGate1 As Boolean
    Dim bGate2 As Boolean
    Dim zCellHold As String
    Dim zCellIgnore As String
    Dim zCellMustHave As String
    Dim lBackgroundColor As Long
    Dim zTranslationUCase As String
    Dim lTranslationUCaseLen As Long
    Dim lTranslationUCaseCnt As Long
    Dim lESCMarkStart As Long
    Dim lESCMarkEnd As Long

    zTranslationUCase = UCase(zPassTranslation)
    lTranslationUCaseLen = Len(zTranslationUCase)
    lESCMarkStart = 0: lESCMarkEnd = 0
    For lTranslationUCaseCnt = 1 To lTranslationUCaseLen 'we cut each line out
        If (lESCMarkStart <> 0 And Mid(zTranslationUCase, lTranslationUCaseCnt, 1) = Chr(13)) Then lESCMarkEnd = lTranslationUCaseCnt
        If (lESCMarkStart = 0 And Mid(zTranslationUCase, lTranslationUCaseCnt, 1) = Chr(27)) Then lESCMarkStart = lTranslationUCaseCnt
        
        If (lESCMarkEnd - lESCMarkStart > 0) Then 'try a cut out sentence
            zTranslation = zRemoveColorCodes(Mid(zTranslationUCase, lESCMarkStart, lESCMarkEnd - lESCMarkStart))
            lESCMarkStart = 0: lESCMarkEnd = 0
            lGate1 = 0: lGate2a = 0: lGate2b = 0
            'If (Len(zTranslation) > 3) Then
            If (cstbUseDebugger) Then Debug.Print zTranslation  'say A GOLDFISH, IS SWIMMING HAPPILY {1}
            
            Set rsPlayer = MyDB.OpenRecordset("SELECT BackgroundColor, PerceptionMachineID, WordMatch, PMFilename, Type, IgnoreWhenMatchingInWords, MusthaveWhenMatchingInWords FROM tblPerceptionMachine WHERE (CharacterNameID=" & gbllCharacterNameID & " OR CharacterNameID=0) AND (PMFilename <> '" & gblzFileNameLoaded(0) & "' and PMFilename <> '" & gblzFileNameLoaded(1) & "' and PMFilename <> '" & gblzFileNameLoaded(2) & "' and PMFilename <> '" & gblzFileNameLoaded(3) & "');", dbOpenSnapshot)
            Do While (Not rsPlayer.EOF)
                lFPS = 0
                zFilename = UCase(MyCStr(rsPlayer!PMFilename))
                zWordMatch = UCase(MyCStr(rsPlayer!WordMatch))
                'Debug.Print zWordMatch & ", Scanning...{" & InStr(zTranslation, zWordMatch) & "} [[" & zTranslation & "]]"
                If (InStr(" " & zTranslation, " " & zWordMatch) <> 0) Then  'do we find the word somewhere in the translation also, instr Protects from accidental SQL injection
                    If (cstbUseDebugger) Then Debug.Print "FOUND>>>>>>>{" & zWordMatch & "}"
                    If (cstbUseDebugger) Then Debug.Print "zFileNameLoaded0123: " & gblzFileNameLoaded(0) & " " & gblzFileNameLoaded(1) & " " & gblzFileNameLoaded(2) & " " & gblzFileNameLoaded(3)
                    If (cstbUseDebugger) Then Debug.Print "zTranslation2 = " & zTranslation
                    'Debug.Print "zWordMatch2 = " & zWordMatch
                    zIgnoreWhenMatchingInWords = MyCStr(rsPlayer!IgnoreWhenMatchingInWords) & " "
                    lLenIgnore = Len(zIgnoreWhenMatchingInWords)
                    lGate1 = 0: zCellHold = "": zCellIgnore = ""
                    If (lLenIgnore > 1) Then 'the space counts in
                        lCount = 0
                        Do
                            lCount = lCount + 1
                            zCellHold = Mid(zIgnoreWhenMatchingInWords, lCount, 1)
                            If (zCellHold <> " ") Then
                                zCellIgnore = zCellIgnore & zCellHold
                            Else
                                zCellIgnore = Trim(zCellIgnore)
                                If (cstbUseDebugger) Then Debug.Print "zCellIgnore = " & zCellIgnore
                                If (InStr(zTranslation, zCellIgnore) <> 0) Then lGate1 = lGate1 + 1
                                zCellIgnore = ""
                            End If
                        Loop Until (lCount >= lLenIgnore)
                    End If
                    
                    zMustHaveWhenMatchingInWords = MyCStr(rsPlayer!MustHaveWhenMatchingInWords) & " "
                    lLenMustHave = Len(zMustHaveWhenMatchingInWords)
                    lGate2a = 0: lGate2b = 0: zCellHold = "": zCellMustHave = ""
                    If (lLenMustHave > 1) Then 'the space counts in
                        zCellMustHave = ""
                        lCount = 0
                        Do
                            lCount = lCount + 1
                            zCellHold = Mid(zMustHaveWhenMatchingInWords, lCount, 1)
                            If (zCellHold <> " ") Then
                                zCellMustHave = zCellMustHave & zCellHold
                            Else
                                zCellMustHave = Trim(zCellMustHave)
                                If (cstbUseDebugger) Then Debug.Print "zCellMustHave = " & zCellMustHave
                                If (Not (InStr(zTranslation, zCellMustHave) <> 0)) Then
                                    lGate2a = lGate2a + 1 'this word did not match, doesnt quite yet mean a full fail
                                Else
                                    lGate2b = lGate2b + 1 'at least one must have matched, its all we need
                                End If
                                zCellMustHave = ""
                            End If
                        Loop Until (lCount >= lLenMustHave)
                    End If
                    
                    If (cstbUseDebugger) Then Debug.Print "G1[" & lGate1 & "] G2a[" & lGate2a & "] G2b[" & lGate2b & "]"
                    
                    If (lGate1 = 0 And (lGate2a = 0 Or lGate2b <> 0)) Then
                        lFileNameLoaded = lFileNameLoaded + 1
                        If (lFileNameLoaded > cstFileNameLoadedMAX) Then lFileNameLoaded = 0
                        gblzFileNameLoaded(lFileNameLoaded) = zFilename
                        lType = MyCLng(rsPlayer!Type) '0=Moon Phase 1=Time Window 2=Weather Window 3=Frame1 4=Frame2 etc...
                        If (lType > -1) Then
                        If (cstbUseDebugger) Then Debug.Print lType & " " & zFilename
                        Select Case lType
                            Case 0
                                frmGraphicalRepresentation.Caption = zWordMatch
                                subLoadNextFrameWithPicture zFilename
                            Case 1
                                subLoadTimePicture zFilename
                            Case 2
                                subLoadWeatherPicture zFilename
                            Case Else
                                subLoadNextFrameWithPicture zFilename
                        End Select
                        
                        lBackgroundColor = MyCLng(rsPlayer!BackgroundColor)
                        Select Case lBackgroundColor
                            Case 0 'gray
                                frmGraphicalRepresentation.BackColor = &H404040
                            Case 1 'green
                                frmGraphicalRepresentation.BackColor = &H80FF80
                            Case 2 'red
                                frmGraphicalRepresentation.BackColor = &H8080FF
                            Case 3 'purpy
                                frmGraphicalRepresentation.BackColor = &HFF80FF
                            Case 4 'cyan
                                frmGraphicalRepresentation.BackColor = &HFFFF80
                            Case 5 'orange
                                frmGraphicalRepresentation.BackColor = &H80FF&
                            Case 6 'yellow
                                frmGraphicalRepresentation.BackColor = &H80FFFF
                            Case 7 'blue
                                frmGraphicalRepresentation.BackColor = &HC00000
                            Case Else
                                frmGraphicalRepresentation.BackColor = &O0
                        End Select
                        End If
                    End If
                End If
                rsPlayer.MoveNext
            Loop
            Set rsPlayer = Nothing
            'End If
        End If
    Next lTranslationUCaseCnt
    Exit Sub
Err_Check:
    MsgBox "subTranslateScanDatabase," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
    'Debug.Print "subTranslateScanDatabase:" & vbCrLf & Err.Number & " " & vbCrLf & Err.Description
End Sub
Private Sub Form_DblClick()
    subClrscr
End Sub
Public Function strRemoveCharacterFromLine(strLine As String, strRemoveThisChar As String) As String
On Error Resume Next
    Dim intScan As Integer
    Dim strReturn As String
    Dim strChar As String
    
    strReturn = ""
    For intScan = 1 To Len(strLine)
        strChar = (Mid(strLine, intScan, 1))
        
        If (strChar <> strRemoveThisChar) Then
            strReturn = strReturn & strChar
        End If
    Next intScan
    
    strRemoveCharacterFromLine = strReturn
End Function
Private Sub subLoadNextFrameWithPicture(zFilename As String)
On Error GoTo Err_Check
    Dim zFilePathAndFileName As String
    If (Len(zFilename) > 0) Then
        zFilePathAndFileName = gblzAppPathPictures & "\" & zFilename
        If (bFileExists(zFilePathAndFileName)) Then
            lFrame = lFrame + 1
            If (lFrame > lMAXFrames) Then lFrame = 1
            Select Case lFrame
                Case 1
                    picFrame1.Picture = Nothing
                    picFrame1.Picture = LoadPicture(zFilePathAndFileName)
                Case 2
                    picFrame2.Picture = Nothing
                    picFrame2.Picture = LoadPicture(zFilePathAndFileName)
            End Select
        End If
    End If
    Exit Sub
Err_Check:
    'If (cstbUseDebugger) Then basPrintMessage64 "subLoadNextFrameWithPicture ERR#" & Err.Number & vbCrLf & Err.Description
    Debug.Print "subLoadNextFrameWithPicture:" & vbCrLf & Err.Number & " " & vbCrLf & Err.Description
End Sub
Private Sub subLoadWeatherPicture(zFilename As String)
    Dim zFilePathAndFileName As String
    zFilePathAndFileName = gblzAppPathPictures & "\" & zFilename
    If (bFileExists(zFilePathAndFileName)) Then
        picWeather.Picture = Nothing
        picWeather.Picture = LoadPicture(zFilePathAndFileName)
    End If
End Sub
Private Sub subLoadTimePicture(zFilename As String)
    Dim zFilePathAndFileName As String
    zFilePathAndFileName = gblzAppPathPictures & "\" & zFilename
    If (bFileExists(zFilePathAndFileName)) Then
        picTime.Picture = Nothing
        picTime.Picture = LoadPicture(zFilePathAndFileName)
    End If
End Sub
Private Sub subLoadmdiMainBackground(zFilename As String) 'need hDC to win32 to redraw so doesnt work with mdi forms
    Dim zFilePathAndFileName As String
    zFilePathAndFileName = gblzAppPathPictures & "\" & zFilename
    If (bFileExists(zFilePathAndFileName)) Then
        'mdiMain.Picture = LoadPicture(gblzAppPathPictures & "\" & "clrscrbg.bmp")
        mdiMain.Picture = Nothing
        mdiMain.Picture = LoadPicture(zFilePathAndFileName)
    End If
End Sub
Private Sub subClrscr()
On Error Resume Next
    lFPS = 0
    lTimer = 0
    frmGraphicalRepresentation.BackColor = &H404040
    picFrame1.Picture = Nothing
    picFrame2.Picture = Nothing
    picWeather.Picture = Nothing
    picTime.Picture = Nothing
    frmGraphicalRepresentation.Caption = "~ P E R C E P T I O N  M A C H I N E ~"
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub tmrGR_Timer()
    lTimer = lTimer + 1
    If (lTimer > 89) Then
        lTimer = 0
        subClrscr
    End If
End Sub
Private Sub tmrResetSpam_Timer()
On Error Resume Next
    For lFileNameLoaded = 0 To cstFileNameLoadedMAX
        gblzFileNameLoaded(lFileNameLoaded) = ""
    Next lFileNameLoaded
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 3911
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
On Error Resume Next
    lFileNameLoaded = 0
    tmrGR.Enabled = True
    tmrGR.Interval = 1000
    lFrame = 0
    lFPS = 0
    tmrResetSpam_Timer
    gblbGraphicalRepresentation = True
    subWindowsPosition Me, "L"
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
    gblbGraphicalRepresentation = False
    subWindowsPosition Me, "S"
End Sub
