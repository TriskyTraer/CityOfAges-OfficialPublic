VERSION 5.00
Begin VB.Form frmSendData 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   Caption         =   "PROMPT"
   ClientHeight    =   708
   ClientLeft      =   108
   ClientTop       =   432
   ClientWidth     =   7620
   LinkTopic       =   "Form1"
   ScaleHeight     =   708
   ScaleWidth      =   7620
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      Height          =   372
      Left            =   120
      TabIndex        =   0
      Text            =   "Text1"
      Top             =   120
      Width           =   5892
   End
End
Attribute VB_Name = "frmSendData"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
