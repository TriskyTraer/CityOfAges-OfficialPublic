VERSION 5.00
Begin VB.Form frmCharacterMacroScaling 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Profile - Aliases and Macros"
   ClientHeight    =   8055
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   4815
   Icon            =   "frmCharacterMacroScaling.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   8055
   ScaleWidth      =   4815
   Begin VB.Timer tmrScaling 
      Enabled         =   0   'False
      Interval        =   2000
      Left            =   0
      Top             =   0
   End
   Begin VB.CommandButton cmdNew 
      Appearance      =   0  'Flat
      Caption         =   "&New"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   4
      Top             =   7680
      Width           =   975
   End
   Begin VB.CommandButton cmdLoad 
      Appearance      =   0  'Flat
      Caption         =   "&Load"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   5
      Top             =   7680
      Width           =   975
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2520
      TabIndex        =   6
      Top             =   7680
      Width           =   975
   End
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Caption         =   "&Delete"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3720
      Picture         =   "frmCharacterMacroScaling.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   7680
      Width           =   975
   End
   Begin VB.ListBox lstScaling 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3630
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4575
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      ForeColor       =   &H80000008&
      Height          =   2535
      Left            =   120
      ScaleHeight     =   2505
      ScaleWidth      =   4545
      TabIndex        =   8
      TabStop         =   0   'False
      Top             =   3840
      Width           =   4575
      Begin VB.CheckBox chkTimer 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         DownPicture     =   "frmCharacterMacroScaling.frx":0B14
         ForeColor       =   &H80000008&
         Height          =   375
         Left            =   3120
         Picture         =   "frmCharacterMacroScaling.frx":109E
         Style           =   1  'Graphical
         TabIndex        =   2
         ToolTipText     =   "Check green to start the timer to run your command lines."
         Top             =   120
         Width           =   375
      End
      Begin VB.TextBox txtScalingHeader 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   50
         MultiLine       =   -1  'True
         TabIndex        =   1
         Top             =   120
         Width           =   2895
      End
      Begin VB.TextBox txtScalingMemo 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1815
         Left            =   120
         MaxLength       =   255
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   3
         Top             =   600
         Width           =   4335
      End
      Begin VB.Label lblLineCount 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   375
         Left            =   3600
         TabIndex        =   11
         Top             =   120
         Width           =   855
      End
      Begin VB.Label lblScalingTextID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   9
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmCharacterMacroScaling.frx":17D4
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   1095
      Left            =   120
      TabIndex        =   10
      Top             =   6480
      Width           =   4575
   End
End
Attribute VB_Name = "frmCharacterMacroScaling"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gbllNextLine As Long
Private Sub subLoadAllScalings()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset 'Only loads Scalings directly to the lstScaling ListBox
    MyDB.Execute "DELETE * FROM tblScalingText WHERE Len(ScalingMemo)=0;", dbFailOnError 'we clean up stuff that was to be removed
    lstScaling.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT ScalingTextID, CharacterNameID, ScalingHeader, ScalingMemo FROM tblScalingText WHERE CharacterNameID=" & gbllCharacterNameID & " ORDER BY ScalingMemo;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        Do While (Not rsSetUp.EOF)
            lstScaling.AddItem MyCStr(rsSetUp!ScalingHeader) 'This is the only one that is required - we load the rest upon click
            lstScaling.ItemData(lstScaling.ListCount - 1) = rsSetUp!ScalingTextID
            rsSetUp.MoveNext
        Loop
    End If
    Set rsSetUp = Nothing
    Exit Sub
Err_Check:
    MsgBox "subLoadAllScalings," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub subSaveScaling()
On Error GoTo Err_Check
    Dim lScalingTextID As Long
    Dim zScalingMatchingText As String
    Dim zScalingProgrammedReply As String
    Dim zSoundFilename As String
    Dim rsData As Recordset
    
    lScalingTextID = MyCLng(lblScalingTextID.Caption)
    zScalingMatchingText = txtScalingHeader.Text
    zScalingProgrammedReply = txtScalingMemo.Text
    Set rsData = MyDB.OpenRecordset("SELECT ScalingTextID, CharacterNameID, ScalingHeader, ScalingMemo FROM tblScalingText WHERE CharacterNameID=" & gbllCharacterNameID & " AND ScalingTextID=" & lScalingTextID & ";", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!ScalingHeader = zScalingMatchingText
        rsData!ScalingMemo = zScalingProgrammedReply
        rsData.Update
    Else
        rsData.AddNew
        rsData!CharacterNameID = gbllCharacterNameID
        rsData!ScalingHeader = zScalingMatchingText
        rsData!ScalingMemo = zScalingProgrammedReply
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    MsgBox "subSaveScaling," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub cmdDelete_Click()
    subDelete
End Sub

Private Sub cmdLoad_Click()
    subNew
    subLoadAllScalings
End Sub

Private Sub cmdNew_Click()
    subNew
End Sub

Private Sub cmdSave_Click()
    subSave
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 15
    txtScalingHeader.SetFocus
End Sub

Private Sub Form_Load()
    subNew
    subLoadAllScalings
End Sub

Private Sub Form_Resize()
    If (Me.WindowState = vbNormal) Then
        chkTimer.Value = False
    End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
    MyDB.Execute "DELETE * FROM tblScalingText WHERE Len(ScalingMemo)=0;", dbFailOnError 'we clean up stuff that was to be removed
End Sub

Private Sub subDelete()
On Error Resume Next
    MyDB.Execute "DELETE * FROM tblScalingText WHERE ScalingTextID=" & MyCLng(lblScalingTextID.Caption) & ";", dbFailOnError
    subNew
    subLoadAllScalings
End Sub

Private Sub subNew()
On Error Resume Next
    txtScalingHeader.Text = ""
    txtScalingMemo.Text = ""
    lblScalingTextID.Caption = ""
    lblLineCount.Caption = ""
    chkTimer.Value = False
    chkTimer.ToolTipText = "Check green to start the timer to run your command lines."
    DoEvents
End Sub

Private Sub subSave()
    subSaveScaling
    subNew
    subLoadAllScalings
End Sub

Private Sub subPrintLineCount()
    lblLineCount.Caption = 255 - Len(MyCStr(txtScalingMemo.Text))
End Sub

Private Sub chkTimer_Click()
    If (MyCLng(lblScalingTextID.Caption) = 0) Then
        chkTimer.Value = False
    Else
        tmrScaling.Enabled = (chkTimer.Value)
        chkTimer.ToolTipText = ""
        Select Case chkTimer.Value
            Case 1
                frmCharacterMacroScaling.WindowState = vbMinimized
        End Select
    End If
End Sub

Private Sub lstScaling_Click()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    chkTimer.Value = False
    
    Set rsSetUp = MyDB.OpenRecordset("SELECT ScalingTextID, CharacterNameID, ScalingHeader, ScalingMemo FROM tblScalingText WHERE CharacterNameID=" & gbllCharacterNameID & " AND ScalingTextID=" & MyCLng(lstScaling.ItemData(lstScaling.ListIndex)) & ";", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        lblScalingTextID.Caption = MyCStr(rsSetUp!ScalingTextID)
        txtScalingHeader.Text = MyCStr(rsSetUp!ScalingHeader)
        txtScalingMemo.Text = MyCStr(rsSetUp!ScalingMemo)
        subPrintLineCount
        rsSetUp.MoveNext
        txtScalingMemo.SetFocus
    Else
        subNew
    End If
    Set rsSetUp = Nothing
    Exit Sub
Err_Check:
    MsgBox "lstScaling_Click," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub tmrScaling_Timer()
    Dim lScalingTextID As Long
    Dim lCount As Long
    Dim lLen As Long
    Dim lNextLine As Long
    Dim zScalingLine As String
    Dim zSendLine As String
    Dim zChr As String
    
    If (Not gblbMASTERLock) Then
        tmrScaling.Enabled = False
        
        lScalingTextID = MyCLng(lblScalingTextID.Caption)
        
        If (lScalingTextID <> 0) Then
            zScalingLine = UCase(zRemoveSQLCrashChars(txtScalingMemo.Text))
            
            txtScalingMemo.Text = zScalingLine 'After we massage the value we show them what we exactly did with it
            lLen = Len(zScalingLine)
            
            zSendLine = ""
            lNextLine = 0
            For lCount = 1 To lLen
                zChr = Mid(zScalingLine, lCount, 1)
                If (zChr <> vbCr) Then zSendLine = zSendLine & zChr
                If (zChr = vbCr) Then
                    lNextLine = lNextLine + 1
                    If (lNextLine = gbllNextLine) Then
                        'If InStr(Trim(UCase(zSendLine)), "STOP") > 0 Then
                        '    chkTimer.Value = 0
                        '    tmrScaling.Enabled = (chkTimer.Value)
                        'End If
                        'If tmrScaling.Enabled Then
                        If (frmMain.Winsock1.State = 7) Then
                           frmMain.Winsock1.SendData zSendLine & vbCrLf
                        End If
                        'End If
                    Else
                        zSendLine = ""
                    End If
                End If
            Next lCount
            
            gbllNextLine = gbllNextLine + 1
            If (gbllNextLine > lNextLine) Then gbllNextLine = 1
        End If
        
        tmrScaling.Enabled = True
    End If
End Sub

Private Sub txtScalingMemo_KeyPress(KeyAscii As Integer)
    subPrintLineCount
End Sub

Private Sub txtScalingMemo_LostFocus()
    Dim zLine As String
    Dim bDetectedVBCRLF As Boolean
    Dim lLen As Long
    zLine = MyCStr(txtScalingMemo.Text)
    lLen = Len(zLine)
    If (Len(zLine) > 1) Then
        If Not (Mid(zLine, lLen, 1) = vbCr Or Mid(zLine, lLen, 1) = vbLf) Then
            txtScalingMemo.Text = txtScalingMemo.Text & vbCrLf 'end result we just want one
        End If
    End If
End Sub
