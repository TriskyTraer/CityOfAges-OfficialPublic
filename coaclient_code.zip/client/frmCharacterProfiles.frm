VERSION 5.00
Begin VB.Form frmCharacterProfiles 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "CHARACTER PROFILES"
   ClientHeight    =   11205
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   18000
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmCharacterProfiles.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   11205
   ScaleWidth      =   18000
   Begin VB.CommandButton cmdOpenRight 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   5400
      Picture         =   "frmCharacterProfiles.frx":08CA
      Style           =   1  'Graphical
      TabIndex        =   306
      Top             =   360
      Width           =   375
   End
   Begin VB.CommandButton cmdOpenDown 
      Appearance      =   0  'Flat
      Height          =   255
      Left            =   5040
      Picture         =   "frmCharacterProfiles.frx":0E54
      Style           =   1  'Graphical
      TabIndex        =   305
      Top             =   360
      Width           =   375
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   9
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   304
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   10200
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   8
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   303
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   9120
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   7
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   302
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   8040
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   6
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   301
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   6960
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   5
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   300
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   5880
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   4
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   299
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   4800
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   3
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   298
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   3720
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   2
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   297
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   2640
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   1
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   296
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   1560
      Width           =   255
   End
   Begin VB.CommandButton cmdSendNameToMain 
      BackColor       =   &H00C0FFC0&
      Caption         =   "s e n d"
      Height          =   855
      Index           =   0
      Left            =   5760
      Style           =   1  'Graphical
      TabIndex        =   295
      ToolTipText     =   "Send over this player name and use their map and event/sounds and color scheme."
      Top             =   480
      Width           =   255
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   9
      Left            =   0
      TabIndex        =   294
      Text            =   "X"
      Top             =   10200
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   8
      Left            =   0
      TabIndex        =   293
      Text            =   "X"
      Top             =   9120
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   7
      Left            =   0
      TabIndex        =   292
      Text            =   "X"
      Top             =   8040
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   6
      Left            =   0
      TabIndex        =   291
      Text            =   "X"
      Top             =   6960
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   5
      Left            =   0
      TabIndex        =   290
      Text            =   "X"
      Top             =   5880
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   4
      Left            =   0
      TabIndex        =   289
      Text            =   "X"
      Top             =   4800
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   3
      Left            =   0
      TabIndex        =   288
      Text            =   "X"
      Top             =   3720
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   2
      Left            =   0
      TabIndex        =   287
      Text            =   "X"
      Top             =   2640
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   1
      Left            =   0
      TabIndex        =   286
      Text            =   "X"
      Top             =   1560
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.TextBox txtCharacterNameID 
      BackColor       =   &H000080FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   0
      Left            =   0
      TabIndex        =   285
      Text            =   "X"
      Top             =   480
      Visible         =   0   'False
      Width           =   150
   End
   Begin VB.CommandButton cmdLoad 
      Appearance      =   0  'Flat
      Caption         =   "&Load"
      Height          =   255
      Left            =   120
      TabIndex        =   284
      Top             =   240
      Width           =   975
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      Height          =   255
      Left            =   1080
      TabIndex        =   283
      Top             =   240
      Width           =   975
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   282
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   281
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   280
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   279
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   278
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   277
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   276
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   275
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   274
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   273
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   272
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   271
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   270
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   269
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   268
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   267
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   266
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   265
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   264
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   263
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   262
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   261
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   260
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   259
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   258
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   257
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   256
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   255
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   254
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   253
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   252
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   251
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   250
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   249
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   248
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   247
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   246
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   245
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   244
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   243
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   242
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   241
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   240
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   239
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   238
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   237
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   236
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   235
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   234
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   233
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   232
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   231
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   230
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   229
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   228
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   227
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   226
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   225
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   224
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   223
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   222
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   221
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   220
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   219
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   218
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   217
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   216
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   215
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   214
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   213
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   212
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   211
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   210
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   209
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   208
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   207
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   206
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   205
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   204
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   203
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   202
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   201
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   200
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   199
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   198
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   197
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   196
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   195
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   194
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   193
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   192
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   191
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   190
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   189
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   188
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   187
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   186
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   185
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   184
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   183
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   182
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   181
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   180
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   179
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   178
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   177
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   176
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   175
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF12 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   174
      TabStop         =   0   'False
      ToolTipText     =   "F12"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF11 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   173
      TabStop         =   0   'False
      ToolTipText     =   "F11"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF10 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   172
      TabStop         =   0   'False
      ToolTipText     =   "F10"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   171
      TabStop         =   0   'False
      ToolTipText     =   "F9"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   170
      TabStop         =   0   'False
      ToolTipText     =   "F8"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   169
      TabStop         =   0   'False
      ToolTipText     =   "F7"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   168
      TabStop         =   0   'False
      ToolTipText     =   "F6"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   167
      TabStop         =   0   'False
      ToolTipText     =   "F5"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   16680
      MaxLength       =   25
      TabIndex        =   166
      TabStop         =   0   'False
      ToolTipText     =   "F4"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   15360
      MaxLength       =   25
      TabIndex        =   165
      TabStop         =   0   'False
      ToolTipText     =   "F3"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   14040
      MaxLength       =   25
      TabIndex        =   164
      TabStop         =   0   'False
      ToolTipText     =   "F2"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyF1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   12720
      MaxLength       =   25
      TabIndex        =   0
      TabStop         =   0   'False
      ToolTipText     =   "F1"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   162
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   10490
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   161
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   10490
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   160
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   9410
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   159
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   9410
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   158
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   8330
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   157
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   8330
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   156
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   7250
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   155
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   7250
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   154
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   6170
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   153
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   6170
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   152
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   5090
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   151
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   5090
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   150
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   4010
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   149
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   4010
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   148
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   2930
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   147
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   2930
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   146
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   145
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   1850
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDecimal 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   144
      TabStop         =   0   'False
      ToolTipText     =   "Key.Decimal Delete"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad0 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   143
      TabStop         =   0   'False
      ToolTipText     =   "Key0Insert"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   142
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   141
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   140
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   139
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   138
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   137
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   136
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   10200
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   135
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   134
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   133
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   10485
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   132
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   131
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   9
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   130
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   10770
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   129
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   128
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   127
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   126
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   125
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   124
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   123
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   9120
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   122
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   121
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   120
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   9405
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   119
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   118
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   8
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   117
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   9690
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   116
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   115
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   114
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   113
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   112
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   111
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   110
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   8040
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   109
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   108
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   107
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   8325
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   106
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   105
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   7
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   104
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   8610
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   103
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   102
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   101
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   100
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   99
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   98
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   97
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   6960
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   96
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   95
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   94
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   7245
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   93
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   92
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   6
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   91
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   7530
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   90
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   89
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   88
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   87
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   86
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   85
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   84
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   5880
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   83
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   82
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   81
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   6165
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   80
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   79
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   5
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   78
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   6450
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   77
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   76
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   75
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   74
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   73
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   72
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   71
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   70
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   69
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   68
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   5085
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   67
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   66
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   4
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   65
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   5370
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   64
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   63
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   62
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   61
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   60
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   59
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   58
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   3720
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   57
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   56
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   55
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   4005
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   54
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   53
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   3
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   52
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   4290
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   51
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   50
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   49
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   48
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   47
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   46
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   45
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   2640
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   44
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   43
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   42
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   2925
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   41
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   40
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   2
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   39
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   3210
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   38
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   37
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   36
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   35
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   34
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   33
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   32
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   1560
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   31
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   30
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   29
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   1845
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   28
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   27
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   1
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   26
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   2130
      Width           =   1215
   End
   Begin VB.TextBox txtKeyAdd 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   25
      TabStop         =   0   'False
      ToolTipText     =   "Add+Key"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeySubtract 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   11280
      MaxLength       =   25
      TabIndex        =   24
      TabStop         =   0   'False
      ToolTipText     =   "Subtract-Key"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad3 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   21
      TabStop         =   0   'False
      ToolTipText     =   "3"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad2 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   20
      TabStop         =   0   'False
      ToolTipText     =   "2"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad1 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   19
      TabStop         =   0   'False
      ToolTipText     =   "1"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad6 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   18
      TabStop         =   0   'False
      ToolTipText     =   "6"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad5 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   17
      TabStop         =   0   'False
      ToolTipText     =   "5"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad4 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   16
      TabStop         =   0   'False
      ToolTipText     =   "4"
      Top             =   765
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad9 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   9960
      MaxLength       =   25
      TabIndex        =   15
      TabStop         =   0   'False
      ToolTipText     =   "9"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad8 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   8640
      MaxLength       =   25
      TabIndex        =   14
      TabStop         =   0   'False
      ToolTipText     =   "8"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyNumpad7 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   7320
      MaxLength       =   25
      TabIndex        =   13
      TabStop         =   0   'False
      ToolTipText     =   "7"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtKeyMultiply 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   12
      TabStop         =   0   'False
      ToolTipText     =   "Multiply*Key"
      Top             =   1050
      Width           =   1215
   End
   Begin VB.TextBox txtKeyDivide 
      Appearance      =   0  'Flat
      Height          =   315
      Index           =   0
      Left            =   6000
      MaxLength       =   25
      TabIndex        =   11
      TabStop         =   0   'False
      ToolTipText     =   "Divide/Key"
      Top             =   480
      Width           =   1215
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   0
      Left            =   120
      MaxLength       =   15
      TabIndex        =   1
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   480
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   1
      Left            =   120
      MaxLength       =   15
      TabIndex        =   2
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   1560
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   2
      Left            =   120
      MaxLength       =   15
      TabIndex        =   3
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   2640
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   3
      Left            =   120
      MaxLength       =   15
      TabIndex        =   4
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   3720
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   4
      Left            =   120
      MaxLength       =   15
      TabIndex        =   5
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   4800
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   5
      Left            =   120
      MaxLength       =   15
      TabIndex        =   6
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   5880
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   6
      Left            =   120
      MaxLength       =   15
      TabIndex        =   7
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   6960
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   7
      Left            =   120
      MaxLength       =   15
      TabIndex        =   8
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   8040
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   8
      Left            =   120
      MaxLength       =   15
      TabIndex        =   9
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   9120
      Width           =   5655
   End
   Begin VB.TextBox txtCharacterName 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Index           =   9
      Left            =   120
      MaxLength       =   15
      TabIndex        =   10
      ToolTipText     =   "Double Click to change color mapping."
      Top             =   10200
      Width           =   5655
   End
   Begin VB.Label lblFunctionKeyTitle 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Function Keys"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   12720
      TabIndex        =   163
      Top             =   120
      Width           =   5175
   End
   Begin VB.Label lblCharacterNameTitle 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "PROFILE CHARACTER NAMES"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   120
      TabIndex        =   23
      Top             =   120
      Width           =   5655
   End
   Begin VB.Label lblNumpadTitle 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "/    0   *     NUMLOCK PAD SETTINGS   -    .   +"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   6000
      TabIndex        =   22
      Top             =   120
      Width           =   6495
   End
End
Attribute VB_Name = "frmCharacterProfiles"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub cmdOpenDown_Click()
    subOpenDownFormActive
End Sub
Private Sub subOpenDownFormActiveSmall()
On Error Resume Next
    frmCharacterProfiles.height = 5130
    'cmdLoad.Top = 245: cmdLoad.Left = 120
    'cmdSave.Top = 245: cmdSave.Left = 1200
    'cmdOpenDown.Top = 245: cmdOpenDown.Left = 5040
    'cmdOpenRight.Top = 245: cmdOpenRight.Left = 5520
End Sub
Private Sub subOpenDownFormActiveFULL()
On Error Resume Next
    frmCharacterProfiles.height = 12690
    'cmdLoad.Top = 11880: cmdLoad.Left = 120
    'cmdSave.Top = 11880: cmdSave.Left = 1200
    'cmdOpenDown.Top = 11880: cmdOpenDown.Left = 5040
    'cmdOpenRight.Top = 11880: cmdOpenRight.Left = 5520
End Sub
Private Sub subOpenDownFormActive()
On Error Resume Next
    Select Case (frmCharacterProfiles.height = 12690)
        Case True
            subOpenDownFormActiveSmall
        Case Else
            subOpenDownFormActiveFULL
    End Select
End Sub
Private Sub Form_Activate()
    gblbCharacterNameIDOverride = True
    gbllFormActivated = 6
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Deactivate()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    gblbCharacterNameIDOverride = True
    subWindowsPosition Me, "L"
    subWindowsFieldLoader Me, "L"
    
    subOpenDownFormActiveSmall

    If (gbllCharacterNameID <> 0) Then
        frmCharacterProfiles.Caption = "Character Profiled - " & gblzCharacterName
    End If
    subLoadAllCharacterProfiles
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbCharacterNameIDOverride = True
    If (gbllCharacterNameID <> 0) Then
        subLoadPlayerDefaults gblzCharacterName
    End If
    subWindowsPosition Me, "S"
    subWindowsFieldLoader Me, "S"
End Sub
Private Sub subLoadAllCharacterProfiles()
On Error GoTo Err_subLoadAllCharacterProfiles
    Dim i As Integer
    Dim rsSetUp As Recordset
    'gblzKeyDivide = "EQUIPMENT"
    'gblzKeyMultiply = "INVENTORY"
    'gblzKeySubtract = "UP"
    'gblzKeyAdd = "DOWN"
    'gblzKeyDecimal = "LIST"
    'gblzKeyNumpad0 = "MAP"
    'gblzKeyNumpad1 = "SW"
    'gblzKeyNumpad2 = "SOUTH"
    'gblzKeyNumpad3 = "SE"
    'gblzKeyNumpad4 = "WEST"
    'gblzKeyNumpad5 = "LOOK"
    'gblzKeyNumpad6 = "EAST"
    'gblzKeyNumpad7 = "NW"
    'gblzKeyNumpad8 = "NORTH"
    'gblzKeyNumpad9 = "NE"
    'gblzKeyF1 = "X" 'character sheet
    Set rsSetUp = MyDB.OpenRecordset("SELECT CharacterNameID, CharacterName, KeyDivide, KeyMultiply, KeySubtract, KeyAdd, KeyDecimal, KeyNumpad0, KeyNumpad1, KeyNumpad2, KeyNumpad3, KeyNumpad4, KeyNumpad5, KeyNumpad6, KeyNumpad7, KeyNumpad8, KeyNumpad9, KeyF1, KeyF2, KeyF3, KeyF4, KeyF5, KeyF6, KeyF7, KeyF8, KeyF9, KeyF10, KeyF11, KeyF12 FROM tblProfile ORDER BY CharacterNameID;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        i = 0
        Do While (Not rsSetUp.EOF And i < 10)
            txtCharacterNameID(i).Text = MyCStr(rsSetUp!CharacterNameID)
            txtCharacterName(i).Text = MyCStr(rsSetUp!CharacterName)
            txtKeyDivide(i).Text = MyCStr(rsSetUp!KeyDivide)
            txtKeyMultiply(i).Text = MyCStr(rsSetUp!KeyMultiply)
            txtKeySubtract(i).Text = MyCStr(rsSetUp!KeySubtract)
            txtKeyAdd(i).Text = MyCStr(rsSetUp!KeyAdd)
            txtKeyDecimal(i).Text = MyCStr(rsSetUp!KeyDecimal)
            txtKeyNumpad0(i).Text = MyCStr(rsSetUp!KeyNumpad0)
            txtKeyNumpad1(i).Text = MyCStr(rsSetUp!KeyNumpad1)
            txtKeyNumpad2(i).Text = MyCStr(rsSetUp!KeyNumpad2)
            txtKeyNumpad3(i).Text = MyCStr(rsSetUp!KeyNumpad3)
            txtKeyNumpad4(i).Text = MyCStr(rsSetUp!KeyNumpad4)
            txtKeyNumpad5(i).Text = MyCStr(rsSetUp!KeyNumpad5)
            txtKeyNumpad6(i).Text = MyCStr(rsSetUp!KeyNumpad6)
            txtKeyNumpad7(i).Text = MyCStr(rsSetUp!KeyNumpad7)
            txtKeyNumpad8(i).Text = MyCStr(rsSetUp!KeyNumpad8)
            txtKeyNumpad9(i).Text = MyCStr(rsSetUp!KeyNumpad9)
            txtKeyF1(i).Text = MyCStr(rsSetUp!KeyF1)
            txtKeyF2(i).Text = MyCStr(rsSetUp!KeyF2)
            txtKeyF3(i).Text = MyCStr(rsSetUp!KeyF3)
            txtKeyF4(i).Text = MyCStr(rsSetUp!KeyF4)
            txtKeyF5(i).Text = MyCStr(rsSetUp!KeyF5)
            txtKeyF6(i).Text = MyCStr(rsSetUp!KeyF6)
            txtKeyF7(i).Text = MyCStr(rsSetUp!KeyF7)
            txtKeyF8(i).Text = MyCStr(rsSetUp!KeyF8)
            txtKeyF9(i).Text = MyCStr(rsSetUp!KeyF9)
            txtKeyF10(i).Text = MyCStr(rsSetUp!KeyF10)
            txtKeyF11(i).Text = MyCStr(rsSetUp!KeyF11)
            txtKeyF12(i).Text = MyCStr(rsSetUp!KeyF12)
            rsSetUp.MoveNext
            i = i + 1
        Loop
    End If
    Set rsSetUp = Nothing
    Exit Sub
Err_subLoadAllCharacterProfiles:
    basPrintMessage64 "subLoadAllCharacterProfiles," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subSaveAllCharacterProfiles()
On Error GoTo Err_subSaveAllCharacterProfiles
    Dim zCharacterName As String
    Dim zKeyDivide As String
    Dim zKeyMultiply As String
    Dim zKeySubtract As String
    Dim zKeyAdd As String
    Dim zKeyDecimal As String
    Dim zKeyNumpad0 As String
    Dim zKeyNumpad1 As String
    Dim zKeyNumpad2 As String
    Dim zKeyNumpad3 As String
    Dim zKeyNumpad4 As String
    Dim zKeyNumpad5 As String
    Dim zKeyNumpad6 As String
    Dim zKeyNumpad7 As String
    Dim zKeyNumpad8 As String
    Dim zKeyNumpad9 As String
    Dim zKeyF1 As String
    Dim zKeyF2 As String
    Dim zKeyF3 As String
    Dim zKeyF4 As String
    Dim zKeyF5 As String
    Dim zKeyF6 As String
    Dim zKeyF7 As String
    Dim zKeyF8 As String
    Dim zKeyF9 As String
    Dim zKeyF10 As String
    Dim zKeyF11 As String
    Dim zKeyF12 As String
    
    Dim i As Integer
    Dim rsSetUp As Recordset

    For i = 0 To 9
        zCharacterName = UCase(zRemoveSQLCrashChars(MyCStr(txtCharacterName(i).Text)))
        zKeyDivide = zRemoveSQLCrashChars(MyCStr(txtKeyDivide(i).Text))
        zKeyMultiply = zRemoveSQLCrashChars(MyCStr(txtKeyMultiply(i).Text))
        zKeySubtract = zRemoveSQLCrashChars(MyCStr(txtKeySubtract(i).Text))
        zKeyAdd = zRemoveSQLCrashChars(MyCStr(txtKeyAdd(i).Text))
        zKeyDecimal = zRemoveSQLCrashChars(MyCStr(txtKeyDecimal(i).Text))
        zKeyNumpad0 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad0(i).Text))
        zKeyNumpad1 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad1(i).Text))
        zKeyNumpad2 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad2(i).Text))
        zKeyNumpad3 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad3(i).Text))
        zKeyNumpad4 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad4(i).Text))
        zKeyNumpad5 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad5(i).Text))
        zKeyNumpad6 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad6(i).Text))
        zKeyNumpad7 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad7(i).Text))
        zKeyNumpad8 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad8(i).Text))
        zKeyNumpad9 = zRemoveSQLCrashChars(MyCStr(txtKeyNumpad9(i).Text))
        zKeyF1 = zRemoveSQLCrashChars(MyCStr(txtKeyF1(i).Text))
        zKeyF2 = zRemoveSQLCrashChars(MyCStr(txtKeyF2(i).Text))
        zKeyF3 = zRemoveSQLCrashChars(MyCStr(txtKeyF3(i).Text))
        zKeyF4 = zRemoveSQLCrashChars(MyCStr(txtKeyF4(i).Text))
        zKeyF5 = zRemoveSQLCrashChars(MyCStr(txtKeyF5(i).Text))
        zKeyF6 = zRemoveSQLCrashChars(MyCStr(txtKeyF6(i).Text))
        zKeyF7 = zRemoveSQLCrashChars(MyCStr(txtKeyF7(i).Text))
        zKeyF8 = zRemoveSQLCrashChars(MyCStr(txtKeyF8(i).Text))
        zKeyF9 = zRemoveSQLCrashChars(MyCStr(txtKeyF9(i).Text))
        zKeyF10 = zRemoveSQLCrashChars(MyCStr(txtKeyF10(i).Text))
        zKeyF11 = zRemoveSQLCrashChars(MyCStr(txtKeyF11(i).Text))
        zKeyF12 = zRemoveSQLCrashChars(MyCStr(txtKeyF12(i).Text))
        Set rsSetUp = MyDB.OpenRecordset("SELECT CharacterName, KeyDivide, KeyMultiply, KeySubtract, KeyAdd, KeyDecimal, KeyNumpad0, KeyNumpad1, KeyNumpad2, KeyNumpad3, KeyNumpad4, KeyNumpad5, KeyNumpad6, KeyNumpad7, KeyNumpad8, KeyNumpad9, KeyF1, KeyF2, KeyF3, KeyF4, KeyF5, KeyF6, KeyF7, KeyF8, KeyF9, KeyF10, KeyF11, KeyF12 FROM tblProfile WHERE CharacterNameID=" & (i + 1) & ";", dbOpenSnapshot)
        If (rsSetUp.EOF) Then 'no record? then create a record:
            MyDB.Execute "INSERT INTO tblProfile (CharacterNameID) SELECT " & (i + 1) & ";", dbFailOnError
           'MyDB.Execute "INSERT INTO tblEventText ( CharacterNameID, EventMatchingText, EventProgrammedReply, SoundFilename ) SELECT " & gbllCharacterNameID & ", '" & zRemoveSQLCrashChars(txtEventMatchingText.Text) & "', '" & zRemoveSQLCrashChars(txtEventProgrammedReply.Text) & "', '" & zRemoveSQLCrashChars(txtSoundFilename.Text) & "';", dbFailOnError
        End If
        MyDB.Execute "UPDATE tblProfile SET CharacterName='" & zKeepLettersOnly(zCharacterName) & "', KeyDivide='" & zKeyDivide & "', KeyMultiply='" & zKeyMultiply & "', KeySubtract='" & zKeySubtract & "', KeyAdd='" & zKeyAdd & "', KeyDecimal='" & zKeyDecimal & "', KeyNumpad0='" & zKeyNumpad0 & "', KeyNumpad1='" & zKeyNumpad1 & "', KeyNumpad2='" & zKeyNumpad2 & "', KeyNumpad3='" & zKeyNumpad3 & "', KeyNumpad4='" & zKeyNumpad4 & "', KeyNumpad5='" & zKeyNumpad5 & "', KeyNumpad6='" & zKeyNumpad6 & "', KeyNumpad7='" & zKeyNumpad7 & "', KeyNumpad8='" & zKeyNumpad8 & "', KeyNumpad9='" & zKeyNumpad9 & "', KeyF1='" & zKeyF1 & "', KeyF2='" & zKeyF2 & "', KeyF3='" & zKeyF3 & "', KeyF4='" & zKeyF4 & "', KeyF5='" & zKeyF5 & "', KeyF6='" & zKeyF6 & "', KeyF7='" & zKeyF7 & "', KeyF8='" & zKeyF8 & "', KeyF9='" & zKeyF9 & "', KeyF10='" & zKeyF10 & "', KeyF11='" & zKeyF11 & "', KeyF12='" & zKeyF12 & "' WHERE CharacterNameID=" & (i + 1) & ";", dbFailOnError
    Next i
    Set rsSetUp = Nothing
    subLoadAllCharacterProfiles
    Exit Sub
Err_subSaveAllCharacterProfiles:
    basPrintMessage64 "subSaveAllCharacterProfiles," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub cmdLoad_Click()
    subLoadAllCharacterProfiles
End Sub

Private Sub cmdSave_Click()
    subSaveAllCharacterProfiles
End Sub
Private Sub cmdOpenRight_Click()
On Error Resume Next
    Select Case (frmCharacterProfiles.width = 18090)
        Case True
            frmCharacterProfiles.width = 6045
        Case Else
            frmCharacterProfiles.width = 18090
    End Select
End Sub

Private Sub mnuRGBColorPallet_Click()
    MsgBox "Double click on the profile name you would like to change the pallet for.", vbOKOnly
End Sub

Private Sub txtCharacterName_DblClick(Index As Integer)
On Error Resume Next
    Unload frmRGBColorPallet
    frmRGBColorPallet.Show
    frmRGBColorPallet.lblProfileIndex = MyCStr(Index)
End Sub

Private Sub cmdSendNameToMain_Click(Index As Integer)
On Error GoTo Err_Check
    Dim rsProfile As Recordset
    Dim lRGB As Long
    txtCharacterName(Index).Text = MyCStr(txtCharacterName(Index).Text)
    If (Len(txtCharacterName(Index).Text) > 0) Then
        subSaveAllCharacterProfiles
        MyDB.Execute "UPDATE tblProfile SET IPCommonConnect='" & gblzAddress & "' WHERE ([CharacterName]='" & MyCStr(txtCharacterName(Index).Text) & "');", dbFailOnError
        If (frmMain.Winsock1.State <> 7) Then '7 = connected
            frmMain.basFormLoad
            If (gbllCharacterNameID <> 0) Then
                frmMain.basrunMainCDNoInit
            Else
                frmMain.basrunMainCD
            End If
            'If frmMain.Winsock1.State = 6 Then <<winsock_connecting...msghere>>
        End If
        frmMain.txtSendClientData.Text = txtCharacterName(Index).Text
        gbllProfileKeyAscii = 13
        frmMain.subRunSendClientData 13
        'frmMain.Winsock1.SendData txtCharacterName(Index).Text & vbCrLf
    End If
    
    If (bFileExists("clear.bmp")) Then
        mdiMain.Picture = LoadPicture("clear.bmp")
    End If

    'terminal colors defaults
    gbllreg(30) = 8421504
    gbllbold(30) = 8421504
    gbllreg(31) = 135
    gbllbold(31) = 255
    gbllreg(32) = 34615
    gbllbold(32) = 47415
    gbllreg(33) = 30840
    gbllbold(33) = 38550
    gbllreg(34) = 5767168
    gbllbold(34) = 9175040
    gbllreg(35) = 6226055
    gbllbold(35) = 16711935
    gbllreg(36) = 4934400
    gbllbold(36) = 10197760
    gbllreg(37) = 6250335
    gbllbold(37) = 10197915
    
    Set rsProfile = MyDB.OpenRecordset("SELECT RGB30fgreg, RGB31fgreg, RGB32fgreg, RGB33fgreg, RGB34fgreg, RGB35fgreg, RGB36fgreg, RGB37fgreg, RGB30fgbold, RGB31fgbold, RGB32fgbold, RGB33fgbold, RGB34fgbold, RGB35fgbold, RGB36fgbold, RGB37fgbold FROM tblProfile WHERE CharacterNameID=" & (Index + 1) & ";", dbOpenSnapshot)
    If (Not rsProfile.EOF) Then
        'terminal colors user picked and set
        lRGB = MyCLng(rsProfile!RGB30fgreg): If (lRGB <> 0) Then gbllreg(30) = lRGB
        lRGB = MyCLng(rsProfile!RGB30fgbold): If (lRGB <> 0) Then gbllbold(30) = lRGB
        lRGB = MyCLng(rsProfile!RGB31fgreg): If (lRGB <> 0) Then gbllreg(31) = lRGB
        lRGB = MyCLng(rsProfile!RGB31fgbold): If (lRGB <> 0) Then gbllbold(31) = lRGB
        lRGB = MyCLng(rsProfile!RGB32fgreg): If (lRGB <> 0) Then gbllreg(32) = lRGB
        lRGB = MyCLng(rsProfile!RGB32fgbold): If (lRGB <> 0) Then gbllbold(32) = lRGB
        lRGB = MyCLng(rsProfile!RGB33fgreg): If (lRGB <> 0) Then gbllreg(33) = lRGB
        lRGB = MyCLng(rsProfile!RGB33fgbold): If (lRGB <> 0) Then gbllbold(33) = lRGB
        lRGB = MyCLng(rsProfile!RGB34fgreg): If (lRGB <> 0) Then gbllreg(34) = lRGB
        lRGB = MyCLng(rsProfile!RGB34fgbold): If (lRGB <> 0) Then gbllbold(34) = lRGB
        lRGB = MyCLng(rsProfile!RGB35fgreg): If (lRGB <> 0) Then gbllreg(35) = lRGB
        lRGB = MyCLng(rsProfile!RGB35fgbold): If (lRGB <> 0) Then gbllbold(35) = lRGB
        lRGB = MyCLng(rsProfile!RGB36fgreg): If (lRGB <> 0) Then gbllreg(36) = lRGB
        lRGB = MyCLng(rsProfile!RGB36fgbold): If (lRGB <> 0) Then gbllbold(36) = lRGB
        lRGB = MyCLng(rsProfile!RGB37fgreg): If (lRGB <> 0) Then gbllreg(37) = lRGB
        lRGB = MyCLng(rsProfile!RGB37fgbold): If (lRGB <> 0) Then gbllbold(37) = lRGB
    End If
    Set rsProfile = Nothing
    
    frmMapper.Show
    frmMain.txtSendClientData.SetFocus
    Unload frmCharacterProfiles
    Exit Sub
Err_Check:
    basPrintMessage64 Err.Description
End Sub

Private Sub txtCharacterName_LostFocus(Index As Integer)
    txtCharacterName(Index) = zKeepLettersOnly(txtCharacterName(Index))
End Sub
