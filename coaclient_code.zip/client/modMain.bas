Attribute VB_Name = "modMain"
Option Explicit
'drag and drop
Public gblbMainSendClientDataFocused As Boolean
Public Declare Function GetSystemMetrics Lib "user32" (ByVal nIndex As Long) As Long
'Private Declare Function GetSystemMetrics Lib "user32" (ByVal nIndex As Long) As Long 'And then when you need the screen width and height, define these constants:
Public Const SM_CXSCREEN = 0
Public Const SM_CYSCREEN = 1
Public gbllAttMode As Long
Public gblbStatsBox As Boolean
Public gbllEventTriggered As Long
Public cstlngButtonColorIndex As Long
Public Const cstlngButtonColorOri = &HFFC0C0
Public Const cstlngButtonColorBnk = &H80FF80
Public Const cstFileNameLoadedMAX = 3
Public Const cstPlayerType = 1
Public gblbFleetWindow As Boolean
Public gblbForgeWindow As Boolean
Public gblbJoystickPackmanWindow As Boolean
Public gblzFileNameLoaded(0 To cstFileNameLoadedMAX) As String
Public gblbGraphicalRepresentation As Boolean
Public lgblScreenWidth As Long  'lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN) 'Then you can use GetSystemMetrics wherever you need it. If it makes more sense to add the declaration and constants to a Module (.BAS), then just make the declaration and constants public.
Public lgblScreenHeight As Long 'lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN) 'Then you can use GetSystemMetrics wherever you need it. If it makes more sense to add the declaration and constants to a Module (.BAS), then just make the declaration and constants public.
Public bgblLapTopMode As Boolean
Public lgblValSpread As Long
Public gblfrmBlackSheet As Boolean
Public gblbMASTERLock As Boolean
Public zgblDragDrop As String
Public gblbDetectedCommand As Boolean
Public gblbAnimation As Boolean
Public gblzFontNoteName As String
Public gbllFontNoteSize As Long
Public gblbRecordTextfileEventLine As Boolean 'this var works with iFileNo
Public iFileNo As Integer
Public zFileNoName As String
Type POINTAPI
    X As Long
    Y As Long
End Type
Type Msg
    hWnd As Long
    message As Long
    wParam As Long
    lParam As Long
    time As Long
    pt As POINTAPI
End Type
Declare Sub DragAcceptFiles Lib "shell32.dll" (ByVal hWnd As Long, ByVal fAccept As Long)
Declare Sub DragFinish Lib "shell32.dll" (ByVal hDrop As Long)
Declare Function DragQueryFile Lib "shell32.dll" Alias "DragQueryFileA" (ByVal hDrop As Long, ByVal UINT As Long, ByVal lpStr As String, ByVal ch As Long) As Long
Declare Function PeekMessage Lib "user32" Alias "PeekMessageA" (lpMsg As Msg, ByVal hWnd As Long, ByVal wMsgFilterMin As Long, ByVal wMsgFilterMax As Long, ByVal wRemoveMsg As Long) As Long
Const PM_NOREMOVE = &H0
Const PM_NOYIELD = &H2
Const PM_REMOVE = &H1
Const WM_DROPFILES = &H233

'code
Public gblEventsToggle As Boolean
Public Const gblzMAPPEROFFCODE = "<@[MAPPEROFF]@>"
Public Const gblzMAPPERONCODE = "<@[MAPPERON]@>"
Public gbllVoiceLorePlayer As Boolean
Public gblbVoiceLorePlaying As Boolean
Public gblbSoundBackground As Boolean

Public gbllProfileKeyAscii As Long
'Background sounds, play sounds at the same time
 Public Declare Function mciSendString Lib "winmm.dll" Alias "mciSendStringA" (ByVal lpstrCommand As String, ByVal lpstrReturnString As String, ByVal uReturnLength As Integer, ByVal hwndCallback As Integer) As Integer
    'mciSendString("open " & fileName & " type mpegvideo alias FirstSound", String.Empty, 0, 0)
    'mciSendString("play FirstSound", String.Empty, 0, 0)
    'mciSendString("open " & fileName & " type mpegvideo alias SecondSound", String.Empty, 0, 0)
    'mciSendString("play SecondSound", String.Empty, 0, 0)
    'mciSendString("close FirstSound", String.Empty, 0, 0) 'close in reverse order if possible
    'mciSendString("close SecondSound", String.Empty, 0, 0)

' GetSystemMetrics constants
Private Const SM_CXVSCROLL = 2
Private Const SM_CYHSCROLL = 3

' SetWindowPos Flags
Public Const SWP_NOSIZE = &H1
Public Const SWP_NOMOVE = &H2
Public Const SWP_NOZORDER = &H4
Public Const SWP_NOREDRAW = &H8
Public Const SWP_NOACTIVATE = &H10
Public Const SWP_FRAMECHANGED = &H20        '  The frame changed: send WM_NCCALCSIZE
Public Const SWP_SHOWWINDOW = &H40
Public Const SWP_HIDEWINDOW = &H80
Public Const SWP_NOCOPYBITS = &H100
Public Const SWP_NOOWNERZORDER = &H200      '  Don't do owner Z ordering
Public Const swpFlags As Long = SWP_FRAMECHANGED Or SWP_NOMOVE Or SWP_NOZORDER Or SWP_NOSIZE
Public Declare Function SetWindowPos Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Public Declare Function GetSysColor Lib "user32" (ByVal nIndex As Long) As Long
Public Declare Function IsWindow Lib "user32" (ByVal hWnd As Long) As Long

Public Const RDW_UPDATENOW As Long = &H100
Public Declare Function RedrawWindow Lib "user32" (ByVal hWnd As Long, ByRef lprcUpdate As Any, ByVal hrgnUpdate As Long, ByVal fuRedraw As Long) As Long
Public Declare Function UpdateWindow Lib "user32" (ByVal hWnd As Long) As Boolean

Public Const cstlTerminalScrollMAX = 59999
Public gblzMapSizeType As String
Public gbllRotation As Long
Public gbllTerminalScroll As Long
Public gbllTerminalScrollAt As Long
Public gbllTerminalScrollMAX As Long 'the max at which we are at
Public gblzTerminalScroll(1 To cstlTerminalScrollMAX + 200) As String '200 for extra buffer just in case
Public gbllTerminalScrollBACKPointer As Long
Public gblbReturnSimulated As Boolean
Public gblbBringBackFirstGo As Boolean
Public gbllBringBack As Long
Public Const lcstBringBackString = 9
Public gblzBringBackString(1 To lcstBringBackString + 1) As String
Public gbllEventOffTimer As Long
Public gblbFreeToText As Boolean
Public bPlayerNameRequired As Boolean 'so the next few entries the player makes becomes the character file

Public gblzAppPathPictures As String
Public gblzAppPathPicturesO As String
Public gblzAppPathPicturesM As String
Public gblzAppPathPicturesA As String
Public gblzAppPathSounds As String
Public gblzAppPathSoundsO As String
Public gblzAppPathSoundsM As String
Public gblzAppPathSoundsA As String

Public gblzGraphicalClientCode As String
Public gblzInfoAID As String
Public gblzInfoAGID As String
Public gblzInfoMID As String
Public gblzInfoMGID As String
Public gblzInfoOID As String
Public gblzInfoOGID As String
Public gblzInfoXYZ As String
Public gblzGold As String
Public gblzGoldPrevious As String
Public gblzInfoAreaWhere As String

Public gbllInfoHP As String
Public gbllInfoMana As String
Public gbllInfoEssence As String
Public gbllInfoSoul As String
Public gbllInfoMove As String
Public gbllInfoTNL As String
Public gbllInfoHPMax As String
Public gbllInfoManaMax As String
Public gbllInfoEssenceMax As String
Public gbllInfoSoulMax As String
Public gbllInfoMoveMax As String
Public gbllInfoTNLMax As String

Public gblzFNBLA As String ' Chr(27) & "[1;30m"
Public gblzFNRED As String ' Chr(27) & "[0;31m"
Public gblzFNGRE As String ' Chr(27) & "[0;32m"
Public gblzFNYEL As String ' Chr(27) & "[0;33m"
Public gblzFNBLU As String ' Chr(27) & "[0;34m"
Public gblzFNMAG As String ' Chr(27) & "[0;35m"
Public gblzFNCYA As String ' Chr(27) & "[0;36m"
Public gblzFNWHI As String ' Chr(27) & "[0;37m"

Public gblzFBRED As String ' Chr(27) & "[1;31m"
Public gblzFBGRE As String ' Chr(27) & "[1;32m"
Public gblzFBYEL As String ' Chr(27) & "[1;33m"
Public gblzFBBLU As String ' Chr(27) & "[1;34m"
Public gblzFBMAG As String ' Chr(27) & "[1;35m"
Public gblzFBCYA As String ' Chr(27) & "[1;36m"
Public gblzFBWHI As String ' Chr(27) & "[1;37m"

Public Const cstlScriptMAX = 200
Public Const cstlMobMAX = 12
Public gblzStatusBarEventLine As String
Public gbllListMobNameCounter As Long
Public gblzListMobName(1 To cstlMobMAX) As String
Public gblzScripts(1 To cstlScriptMAX) As String
Public gbllScriptOutOfControl As Long
Public gblzTripWord1Compare(1 To cstlScriptMAX) As String
Public gblzTripWord2Compare(1 To cstlScriptMAX) As String
Public gblzTripWord3Compare(1 To cstlScriptMAX) As String
Public gblzTripWord4Compare(1 To cstlScriptMAX) As String
Public gblzTripWord5Compare(1 To cstlScriptMAX) As String
Public gblzTripWord1NS(1 To cstlScriptMAX) As String
Public gblzTripWord2NS(1 To cstlScriptMAX) As String
Public gblzTripWord3NS(1 To cstlScriptMAX) As String
Public gblzTripWord4NS(1 To cstlScriptMAX) As String
Public gblzTripWord5NS(1 To cstlScriptMAX) As String
Public gblbInventoryStart As Boolean
Public gblzInventoryLine As String
Public gblbEquipmentStart As Boolean
Public gblzEquipmentLine As String
Public gblbScorecardStart As Boolean
Public gblzScorecardLine As String
Public gblbSlistStart As Boolean
Public gblzSlistLine As String
Public gblbTreesStart As Boolean
Public gblzTreesLine As String
Public gblzWhereToLookInClient(1 To cstlScriptMAX) As String
Public gbllMapperStatus As Long
Public gbllMapperTimerStatus As Long
Public gbllMapperAutoFocus As Long
Public gblbTerminalScrolling As Boolean
Public gblbSoundStoryLine As Boolean
Public gblbSoundAllowed As Boolean
Public Player As FilgraphManager
Public gblDB As Database
Public gblzAddress As String
Public gblzPort As String
Public gblbfrmMainAllowShutdown As Boolean
Public gblbFlashCursor As Boolean
Public gbldLengthTerminalMultiplier As Double
Public gblzFontName As String
Public gbllFontSize As Long
Public gbllCharacterNameID As Long
Public gblbCharacterNameIDOverride As Boolean
Public gblzCharacterName As String
Public gblzKeyDivide As String
Public gblzKeyMultiply As String
Public gblzKeySubtract As String
Public gblzKeyAdd As String
Public gblzKeyDecimal As String
Public gblzKeyNumpad0 As String
Public gblzKeyNumpad1 As String
Public gblzKeyNumpad2 As String
Public gblzKeyNumpad3 As String
Public gblzKeyNumpad4 As String
Public gblzKeyNumpad5 As String
Public gblzKeyNumpad6 As String
Public gblzKeyNumpad7 As String
Public gblzKeyNumpad8 As String
Public gblzKeyNumpad9 As String
Public gblzKeyF1 As String
Public gblzKeyF2 As String
Public gblzKeyF3 As String
Public gblzKeyF4 As String
Public gblzKeyF5 As String
Public gblzKeyF6 As String
Public gblzKeyF7 As String
Public gblzKeyF8 As String
Public gblzKeyF9 As String
Public gblzKeyF10 As String
Public gblzKeyF11 As String
Public gblzKeyF12 As String
Public Sub subCloseReliantWindows()
On Error Resume Next
    Unload frmCharacterWindow
    Unload frmFleetWindow
    Unload frmForgeWindow
    Unload frmAddressPort
    Unload frmAreaViewerSaver
    Unload frmPerceptionMachineEditor
    Unload frmGraphicalRepresentation
    Unload frmButtons
    Unload frmChangeFont
    Unload frmCharacterEvents
    Unload frmCharacterMacroScaling
    Unload frmCharacterProfiles
    Unload frmCharacterTriggers
    Unload frmHelp
    Unload frmLargeMessageBox
    Unload frmMapper
    Unload frmShowFileNames
    Unload frmSplashScreen
    Unload frmTimer1
    Unload frmTimer2
    Unload frmTimer3
    Unload frmTimer4
    Unload frmTimer5
    Unload frmTimer6
    Unload frmTimerDynamic1
    Unload frmTimerDynamicTwo
    Unload frmTimerDynamic3
    Unload frmInventory
    Unload frmEquipment
    Unload frmScorecard
    Unload frmSlistTrees
    Unload frmJoystickPackman
    Unload frmNumlock
    
    mdiMain.subRefreshButtons
End Sub
Public Sub subSendClientData(zPassSendClientData As String) 'frmMain.Winsock1.SendData zSendClientData & vbCrLf
On Error GoTo Err_Check
    Dim zHold As String
    If (frmMain.Winsock1.State = 7) Then 'we finally send the players command
        zHold = zPassSendClientData
        If (InStr(zHold, ";") <> 0) Then
            'the semicolon allows multisend
            Do
                DoEvents
                If (InStr(zHold, ";") <> 0) Then
                     If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData Mid(zHold, 1, InStr(zHold, ";") - 1) & vbCrLf
                    zHold = Mid(zHold, InStr(zHold, ";") + 1)
                Else
                     If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zHold & vbCrLf
                    zHold = ""
                End If
            Loop Until (zHold = "")
        Else
            frmMain.Winsock1.SendData zPassSendClientData & vbCrLf
        End If
    End If
    Exit Sub
Err_Check:
    'basPrintMessage64 "COASERVER: subCompactNRepair," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCompactNRepair() 'See Also: Public Function MyDB() As Database
On Error GoTo Err_Check
    MyDB.Close
    If (basDoesFileExist(App.Path & "\coaclientc.mdb")) Then Kill App.Path & "\coaclientc.mdb"
    If (basDoesFileExist(App.Path & "\coaclient.mdb")) Then
        Call DBEngine.CompactDatabase(App.Path & "\coaclient.mdb", App.Path & "\coaclientc.mdb")
        Kill App.Path & "\coaclient.mdb"
        Name App.Path & "\coaclientc.mdb" As App.Path & "\coaclient.mdb"
    End If
    DoEvents
    Exit Sub
Err_Check:
    'basPrintMessage64 "COASERVER: subCompactNRepair," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subWindowsPosition(frmHoldForm As Form, zType As String)
    Dim rsSetUp As Recordset
    Dim bFound As Boolean
   
    If (gblbCharacterNameIDOverride Or gbllCharacterNameID > 0) Then
        gblbCharacterNameIDOverride = False
        bFound = False
        DoEvents
        Set rsSetUp = MyDB.OpenRecordset("SELECT WindowsID, CharacterNameID, WindowMoved, WindowType, WindowTop, WindowLeft, WindowHeight, WindowWidth FROM tblWindows WHERE (CharacterNameID=" & gbllCharacterNameID & " AND WindowType='" & frmHoldForm.Name & "');", dbOpenDynaset)
        If (Not rsSetUp.EOF) Then  'Codes are used to identify the area you are in
            bFound = True
            rsSetUp.Edit
            Select Case zType
                Case "L", "l", "LOAD", "A", "a", "ACTIVATE"
                    frmHoldForm.Top = MyCLng(rsSetUp!WindowTop) '7515
                    frmHoldForm.Left = MyCLng(rsSetUp!WindowLeft) '1400
                    frmHoldForm.height = MyCLng(rsSetUp!WindowHeight) '5500
                    frmHoldForm.width = MyCLng(rsSetUp!WindowWidth) '8000
                    rsSetUp!WindowMoved = "U"
                Case Else 'The rest just save
                    rsSetUp!WindowTop = frmHoldForm.Top
                    rsSetUp!WindowLeft = frmHoldForm.Left
                    rsSetUp!WindowHeight = frmHoldForm.height
                    rsSetUp!WindowWidth = frmHoldForm.width
                    rsSetUp!WindowMoved = "A"
            End Select
            rsSetUp.Update
        End If
        Set rsSetUp = Nothing
        DoEvents
        If (Not bFound) Then
            MyDB.Execute "INSERT INTO tblWindows ( CharacterNameID, WindowType, WindowTop, WindowLeft, WindowHeight, WindowWidth, WindowMoved ) SELECT " & gbllCharacterNameID & ", '" & frmHoldForm.Name & "', " & frmHoldForm.Top & ", " & frmHoldForm.Left & ", " & frmHoldForm.height & ", " & frmHoldForm.width & ", 'N';", dbFailOnError 'New type
        End If
        DoEvents
    End If
End Sub
Public Sub subProcessInventoryLine(zInvLine As String)
    Dim zNewInvLine As String
    Dim zHoldInvLine As String
    Dim lLen As Long
    Dim lScanner As Long
    Dim lCounter As Long
    Dim lEndLoc As Long
    Dim bScan As Boolean
    Dim zChr As String
    
    zHoldInvLine = zInvLine
    lEndLoc = InStr(zHoldInvLine, "<===========>")
    If (lEndLoc > 2) Then
        zHoldInvLine = Mid(zHoldInvLine, 1, lEndLoc - 1)
        'Clean colors out of the line for display
        zNewInvLine = ""
        bScan = False
        lLen = Len(zHoldInvLine)
        For lCounter = 1 To lLen
            zChr = Mid(zHoldInvLine, lCounter, 1)
            If (zChr = Chr(27)) Then
                lScanner = 0
                bScan = True
            End If
            If (bScan) Then lScanner = lScanner + 1
            If (lScanner = 8) Then
                bScan = False
            End If
            If (Not bScan) Then zNewInvLine = zNewInvLine & zChr
        Next lCounter
        
        frmInventory.Show
        frmInventory.txtInventory = zNewInvLine
        frmMain.txtSendClientData.SetFocus
    End If
End Sub
Public Sub subProcessEquipmentLine(zInvLine As String)
    Dim zNewInvLine As String
    Dim zHoldInvLine As String
    Dim lLen As Long
    Dim lScanner As Long
    Dim lCounter As Long
    Dim lEndLoc As Long
    Dim bScan As Boolean
    Dim zChr As String
    
    zHoldInvLine = zInvLine
    lEndLoc = InStr(zHoldInvLine, "<***********>")
    If (lEndLoc > 2) Then
        zHoldInvLine = Mid(zHoldInvLine, 1, lEndLoc - 1)
        'Clean colors out of the line for display
        zNewInvLine = ""
        bScan = False
        lLen = Len(zHoldInvLine)
        For lCounter = 1 To lLen
            zChr = Mid(zHoldInvLine, lCounter, 1)
            If (zChr = Chr(27)) Then
                lScanner = 0
                bScan = True
            End If
            If (bScan) Then lScanner = lScanner + 1
            If (lScanner = 8) Then
                bScan = False
            End If
            If (Not bScan) Then zNewInvLine = zNewInvLine & zChr
        Next lCounter
        
        frmEquipment.Show
        frmEquipment.txtEquipment = zNewInvLine
        frmMain.txtSendClientData.SetFocus
    End If
End Sub
Public Sub subProcessXYZLine(zInvLine As String)
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    
    subExtractXYZFromInfoXYZ zInvLine, lX, lY, lZ
    
    If (Not gblbFleetWindow) Then
        If (lX = -3 And lY = 3 And lZ = -704) Then
            frmFleetWindow.Show
            frmMain.txtSendClientData.SetFocus
        End If
    End If
    
    If (Not gblbForgeWindow) Then
        If ((lX = -48 And lY = -11 And lZ = 0) Or (lX = -2 And lY = 1 And lZ = -700)) Then
            frmForgeWindow.Show
            frmMain.txtSendClientData.SetFocus
        End If
    End If
    
    If (Not gblbJoystickPackmanWindow) Then
        If (lX = -4 And lY = 4 And lZ = -700) Then
            frmJoystickPackman.Show
            frmMain.txtSendClientData.SetFocus
        End If
    End If
End Sub
Public Sub subProcessScorecardLine(zInvLine As String)
    Dim zNewInvLine As String
    Dim zHoldInvLine As String
    Dim lLen As Long
    Dim lScanner As Long
    Dim lCounter As Long
    Dim lEndLoc As Long
    Dim bScan As Boolean
    Dim zChr As String
    
    zHoldInvLine = zInvLine
    lEndLoc = InStr(zHoldInvLine, "<################>")
    If (lEndLoc > 2) Then
        zHoldInvLine = Mid(zHoldInvLine, 1, lEndLoc - 1)
        'Clean colors out of the line for display
        zNewInvLine = ""
        bScan = False
        lLen = Len(zHoldInvLine)
        For lCounter = 1 To lLen
            zChr = Mid(zHoldInvLine, lCounter, 1)
            If (zChr = Chr(27)) Then
                lScanner = 0
                bScan = True
            End If
            If (bScan) Then lScanner = lScanner + 1
            If (lScanner = 8) Then
                bScan = False
            End If
            If (Not bScan) Then zNewInvLine = zNewInvLine & zChr
        Next lCounter
        
        frmScorecard.Show
        frmScorecard.txtScorecard = zNewInvLine
        frmMain.txtSendClientData.SetFocus
    End If
End Sub
Public Sub subProcessSlistLine(zInvLine As String)
    Dim zNewInvLine As String
    Dim zHoldInvLine As String
    Dim lLen As Long
    Dim lScanner As Long
    Dim lCounter As Long
    Dim lEndLoc As Long
    Dim bScan As Boolean
    Dim zChr As String
    
    zHoldInvLine = zInvLine '<++=<SKILL LIST>=++>
    lEndLoc = InStr(zHoldInvLine, "<++==--*--==++>")
    If (lEndLoc > 2) Then
        zHoldInvLine = Mid(zHoldInvLine, 1, lEndLoc - 1)
        'Clean colors out of the line for display
        zNewInvLine = ""
        bScan = False
        lLen = Len(zHoldInvLine)
        For lCounter = 1 To lLen
            zChr = Mid(zHoldInvLine, lCounter, 1)
            If (zChr = Chr(27)) Then
                lScanner = 0
                bScan = True
            End If
            If (bScan) Then lScanner = lScanner + 1
            If (lScanner = 8) Then
                bScan = False
            End If
            If (Not bScan) Then zNewInvLine = zNewInvLine & zChr
        Next lCounter
        
        frmSlistTrees.Show
        frmSlistTrees.txtSlistTrees = zNewInvLine
        frmMain.txtSendClientData.SetFocus
    End If
End Sub 'unload frmSlistTrees
Public Sub subProcessTreesLine(zInvLine As String)
    Dim zNewInvLine As String
    Dim zHoldInvLine As String
    Dim lLen As Long
    Dim lScanner As Long
    Dim lCounter As Long
    Dim lEndLoc As Long
    Dim bScan As Boolean
    Dim zChr As String
    
    zHoldInvLine = zInvLine
    lEndLoc = InStr(zHoldInvLine, "<::=++++:++++=::>")
    If (lEndLoc > 2) Then
        zHoldInvLine = Mid(zHoldInvLine, 1, lEndLoc - 1)
        'Clean colors out of the line for display
        zNewInvLine = ""
        bScan = False
        lLen = Len(zHoldInvLine)
        For lCounter = 1 To lLen
            zChr = Mid(zHoldInvLine, lCounter, 1)
            If (zChr = Chr(27)) Then
                lScanner = 0
                bScan = True
            End If
            If (bScan) Then lScanner = lScanner + 1
            If (lScanner = 8) Then
                bScan = False
            End If
            If (Not bScan) Then zNewInvLine = zNewInvLine & zChr
        Next lCounter
        
        frmSlistTrees.Show
        frmSlistTrees.txtSlistTrees = zNewInvLine
        frmMain.txtSendClientData.SetFocus
    End If
End Sub 'unload frmSlistTrees
Public Function zRemoveColorCodes(zLine As String) As String
    Dim zHoldLine As String
    Dim lLenLine As Long
    Dim lCounter As Long
    Dim lScanner As Long
    Dim zChr As String '[0;0m
    Dim bScan As Boolean
    Dim bSpirit As Boolean
    
    zHoldLine = ""
    bScan = False
    
    lLenLine = Len(zLine)
    If (InStr(zLine, Chr(27)) <> 0) Then
        lCounter = 0
        Do
            lCounter = lCounter + 1
            zChr = Mid(zLine, lCounter, 1)
            If (zChr = Chr(27)) Then
                lScanner = 0
                bScan = True
            End If
            If (bScan) Then
                lScanner = lScanner + 1
                bSpirit = ((zChr = "0" Or zChr = "1" Or zChr = "2" Or zChr = "3" Or zChr = "4" Or zChr = "5" Or zChr = "6" Or zChr = "7" Or zChr = "8" Or zChr = "9") And Mid(zLine, lCounter + 1, 1) = "m")
                If (lScanner = 8 Or bSpirit) Then
                    bScan = False
                    If (bSpirit) Then
                        lCounter = lCounter + 1
                    Else
                        zHoldLine = zHoldLine & zChr
                    End If
                End If
            Else
                zHoldLine = zHoldLine & zChr
            End If
        Loop Until (lCounter >= lLenLine)
    Else
        zHoldLine = zLine
    End If
    'Debug.Print zHoldLine
    zRemoveColorCodes = zHoldLine
End Function
Public Function zForceSize(strInfo As Variant, intLen As Integer, strChar As String, strType As String) As String
'Pass:  strInfo for the string to be parsed
'       intLen for length
'       strChar for the character to add to the string if it is less than length.
'       strChar can be of any length or pattern of characters!
'       No trim is used if strChar is a SPACE, in case spaces are required.
'       strType add the character 'B'efore the string or 'A'fter the string.
'See also: basPreceedSize basPreceedSize
On Error Resume Next
    Dim strReturn As String
    
    If (InStr(strChar, " ") > 0) Then
        strReturn = Mid(MyCStr(strInfo), 1, intLen) ' cut from the first position to the forced length position
    Else
        strReturn = Mid(MyCStr(strInfo), 1, intLen) ' trim then cut from the first position to the forced length position
    End If
    
    'If the forced length position is greater than the length of the line then add strChar 'B' or 'A'.
    Do While (Len(strReturn) < intLen)
        Select Case strType
            Case "B" 'Add before the string
                strReturn = strChar & strReturn
            Case Else 'Add after the string
                strReturn = strReturn & strChar
        End Select
    Loop
    
    zForceSize = strReturn
End Function
Public Sub subInitializeAnsiGraphics()
On Error Resume Next
    gblzFNBLA = Chr(27) & "[1;30m" 'this is a grey without the zero part of [0;30m
    gblzFNRED = Chr(27) & "[0;31m"
    gblzFNGRE = Chr(27) & "[0;32m"
    gblzFNYEL = Chr(27) & "[0;33m"
    gblzFNBLU = Chr(27) & "[0;34m"
    gblzFNMAG = Chr(27) & "[0;35m"
    gblzFNCYA = Chr(27) & "[0;36m"
    gblzFNWHI = Chr(27) & "[0;37m"
    
    gblzFBRED = Chr(27) & "[1;31m"
    gblzFBGRE = Chr(27) & "[1;32m"
    gblzFBYEL = Chr(27) & "[1;33m"
    gblzFBBLU = Chr(27) & "[1;34m"
    gblzFBMAG = Chr(27) & "[1;35m"
    gblzFBCYA = Chr(27) & "[1;36m"
    gblzFBWHI = Chr(27) & "[1;37m"
    'Public gblzGraphicalClientCode As String
    gblzGraphicalClientCode = gblzFNBLA & gblzFNGRE & gblzFBCYA 'The Graphical Client watches for this code and when it is see it uses the data separated by MOREBAR | to display graphics - the mud will never allow a single quote to be accepted so we can use it
End Sub

Public Function zRemoveLine(zLine As String, zFrom As String, zTo As String) As String
On Error Resume Next
    Dim lFrom As Long
    Dim lCount As Long
    Dim lTo As Long
    Dim lStart As Long
    Dim zReturn As String
        
    lFrom = InStr(zLine, zFrom)
    lTo = InStr(zLine, zTo)
    zReturn = ""
    
    If (lFrom < lTo And lFrom + lTo > 0) Then
        zReturn = Mid(zLine, 1, lFrom - 1) & Mid(zLine, lTo + 1, (lTo - lFrom))
    End If
    
    zRemoveLine = zReturn
End Function
Public Function zCut(zLine As String, zFrom As String, zTo As String) As String
On Error Resume Next
    Dim zHoldLine As String
    Dim zTreatedLine As String
    Dim zChar As String
    Dim lLen As Long
    Dim lFrom As Long
    Dim lCount As Long
    Dim lTo As Long
    Dim bDone As Boolean
    Dim lSwitch As Long
    Dim lStart As Long
    Dim lEndCount As Long
    Dim zReturn As String
    
    'Remove crazy escape codes and ...
    zTreatedLine = ""
    zHoldLine = zLine
    lLen = Len(zHoldLine)
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (zChar <> Chr(27) And zChar <> vbCr And zChar <> vbLf) Then 'remove esc vbcr vblf
            zTreatedLine = zTreatedLine & zChar
        End If
    Next lCount
    zHoldLine = zTreatedLine
    lLen = Len(zHoldLine)
    'Debug.Print zTreatedLine
    
    'cont...with the sub
    zReturn = ""
    
    lFrom = InStr(zHoldLine, zFrom)
    If (lFrom <> 0) Then
        bDone = False
        If (zTo = "") Then zTo = " "
        lTo = Len(zTo)
        lCount = lFrom - 1
        Do While (Not bDone And lCount <= lLen)
            lCount = lCount + 1
            If (Mid(zHoldLine, lCount, lTo) = zTo) Then
                bDone = True
            End If
        Loop
        lStart = lFrom + Len(zFrom)
        lEndCount = lCount - lStart
        zReturn = MyCStr(Mid(zHoldLine, lStart, lEndCount))
    End If
    
    zCut = zReturn
End Function
Public Sub subWindowsFieldLoader(frmName As Form, zType As String)
'This works well with forms with textboxes to have defaults
'On Error GoTo Err_Check
    Dim rsLoader As Recordset
    Dim cCont As Control
    Dim zWindowFormName As String
    Dim zWindowTypeName As String
    Dim zValue As String
    
    zWindowFormName = MyCStr(frmName.Name)
    For Each cCont In frmName.Controls
        If (UCase(TypeName(cCont)) = "TEXTBOX") Then
            zWindowTypeName = MyCStr(cCont.Name) & "-" & UCase(TypeName(cCont))
            Set rsLoader = MyDB.OpenRecordset("SELECT WindowFormName, WindowTypeName, WindowFieldIndicatorLoader, WindowNameFieldID, WindowNameID, CharacterNameID, WindowFieldValue, WindowFieldControl, WindowFieldStatus, WindowFieldType FROM tblWindowNameField WHERE (WindowFormName='" & zWindowFormName & "' AND WindowTypeName='" & zWindowTypeName & "' AND CharacterNameID=" & gbllCharacterNameID & ");", dbOpenDynaset)
            If (rsLoader.EOF) Then
                rsLoader.AddNew
                rsLoader!WindowFormName = zWindowFormName
                rsLoader!WindowTypeName = zWindowTypeName
                rsLoader!WindowFieldValue = MyCStr(cCont.Text)
                rsLoader!CharacterNameID = gbllCharacterNameID
                rsLoader.Update
            Else
                Select Case zType
                    Case "SAVE", "S" 'Form_Unload uses this
                        rsLoader.Edit
                        rsLoader!WindowFieldValue = MyCStr(cCont.Text)
                        rsLoader!CharacterNameID = gbllCharacterNameID
                        rsLoader.Update
                    Case "UPDATE", "LOAD", "RELOAD", "R", "L" 'load the control
                        cCont.Text = MyCStr(rsLoader!WindowFieldValue)
                End Select
            End If
            Set rsLoader = Nothing
        End If
    Next cCont
    Exit Sub
Err_Check:
End Sub
Public Sub WatchForFiles()
' This subroutine watchs for all of your WM_DROPFILES messages
    Dim ret As Integer
    Dim FileDropMessage As Msg ' Msg Type
    Dim fileDropped As Boolean ' True if Files where dropped
    Dim hDrop As Long ' Pointer to the dropped file structure
    Dim filename As String * 128 ' the dropped filename
    Dim numOfDroppedFiles As Long ' the amount of dropped files
    Dim curFile As Long ' the current file number
    
    ' loop to keep checking for files
    ' NOTE : Do any code you want to execute before this setDo
    
    ' check for Dropped file messages
    fileDropped = PeekMessage(FileDropMessage, 0, WM_DROPFILES, WM_DROPFILES, PM_REMOVE Or PM_NOYIELD)
    
    If (fileDropped) Then
        ' Get the pointer to the dropped file structure
        hDrop = FileDropMessage.wParam
        
        ' Get the toal number of files
        numOfDroppedFiles = DragQueryFile(hDrop, True, filename, 127)
        
        For curFile = 1 To numOfDroppedFiles
            ' Get the file name
            ret = DragQueryFile(hDrop, curFile - 1, filename, 127)
            ' at this pointer you can do what you want with the
            ' filename the filename will be a full qalified path
            zgblDragDrop = filename
        Next curFile
        
        ' We are now done with the structure, tell windows
        ' to discard it
        Call DragFinish(hDrop)
        DoEvents
    End If
End Sub
Public Sub subShowEventPicbox(zPathPicture As String)
On Error Resume Next
    If (bFileExists(zPathPicture)) Then
        frmMain!picEventTriggered.Picture = LoadPicture(zPathPicture)
        'frmMain!lblEventTriggered.caption =  ""
    End If
    If (gbllEventTriggered > 0) Then
        'frmMain!tmrEventTriggered.Enabled = True
        'frmMain!tmrEventTriggered.Interval = 10000
        frmMain!lblEventTriggered.Visible = True
        frmMain!picEventTriggered.Visible = True
    End If
End Sub
Public Sub subResetEventPicbox() 'to use this: load an image into picEventTrigger and turn on the timer with subResetEventPicbox then use subShowEventPicbox
On Error Resume Next
    gbllEventTriggered = 5
    frmMain!tmrEventTriggered.Enabled = True
    frmMain!tmrEventTriggered.Interval = 10000
    frmMain!lblEventTriggered.Visible = False
    frmMain!picEventTriggered.Visible = False
End Sub
Public Sub subClosedownEventPicbox() 'to use this: use as is to shut everything down
On Error Resume Next
    gbllEventTriggered = 0
    frmMain!picEventTriggered.Left = 0
    frmMain!tmrEventTriggered.Enabled = False
    frmMain!tmrEventTriggered.Interval = 10000
    frmMain!lblEventTriggered.Visible = False
    frmMain!picEventTriggered.Visible = False
    Set frmMain!picEventTriggered.Picture = Nothing
End Sub
Sub Main()
    subInitializeAnsiGraphics
    gbllCharacterNameID = 0
    gblbfrmMainAllowShutdown = True
    subSetUpTerminal
    subOrganizeMainTerminalForm
    'Call WatchForFiles 'activate drag n drop - doesnt work yet
End Sub

