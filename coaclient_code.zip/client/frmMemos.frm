VERSION 5.00
Begin VB.Form frmMemos 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character - Notes and Memos"
   ClientHeight    =   9225
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   9315
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMemos.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   9225
   ScaleWidth      =   9315
   Begin VB.CommandButton cmdDelete 
      Caption         =   "delete"
      Height          =   300
      Left            =   8280
      Picture         =   "frmMemos.frx":038A
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   8880
      Width           =   1000
   End
   Begin VB.CommandButton cmdNew 
      Caption         =   "new"
      Height          =   300
      Left            =   120
      TabIndex        =   3
      Top             =   8880
      Width           =   1000
   End
   Begin VB.CommandButton cmdLoad 
      Caption         =   "load"
      Height          =   300
      Left            =   2520
      TabIndex        =   4
      Top             =   8880
      Width           =   1000
   End
   Begin VB.CommandButton cmdSave 
      Caption         =   "save"
      Height          =   300
      Left            =   5760
      TabIndex        =   5
      Top             =   8880
      Width           =   1000
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   2655
      Left            =   120
      ScaleHeight     =   2625
      ScaleWidth      =   9105
      TabIndex        =   0
      Top             =   6120
      Width           =   9135
      Begin VB.TextBox txtMemoValue 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   1815
         Left            =   120
         MaxLength       =   255
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   2
         ToolTipText     =   "Double click this window to insert your last loaded coordinates."
         Top             =   600
         Width           =   8895
      End
      Begin VB.TextBox txtMemoHeader 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   70
         TabIndex        =   1
         ToolTipText     =   "Header Text"
         Top             =   120
         Width           =   7935
      End
      Begin VB.Label lblMemoLen 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   375
         Left            =   8160
         TabIndex        =   9
         ToolTipText     =   "Amount of bytes left for this log."
         Top             =   120
         Width           =   855
      End
      Begin VB.Label lblMemoTextID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   8
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin VB.ListBox lstMemos 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   5790
      Left            =   120
      TabIndex        =   7
      Top             =   120
      Width           =   9135
   End
End
Attribute VB_Name = "frmMemos"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstMaxMemoLength = 255
Private Sub cmdDelete_Click()
On Error Resume Next
    MyDB.Execute "DELETE MemoID FROM tblMemo WHERE MemoID=" & MyCLng(lblMemoTextID.Caption) & ";", dbFailOnError
    cmdNew_Click
End Sub
Private Sub cmdLoad_Click()
    subLoadAllMemos
    cmdNew_Click
End Sub
Private Sub cmdNew_Click()
    lblMemoTextID.Caption = 0
    txtMemoHeader.Text = ""
    txtMemoValue.Text = ""
    subLoadAllMemos
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 14
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    Me.Caption = "Captain " & gblzCharacterName & "'s Log, stardate: " & UCase(Format(Now(), "mmm dd, yyyy hh:nn:ss"))
    subWindowsPosition Me, "L"
    subLoadAllMemos
End Sub

Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub subLoadAllMemos()
On Error Resume Next
    Dim rsSetUp As Recordset 'Only loads Memos directly to the lstMemos ListBox
    lblMemoLen.Caption = ""
    lblMemoLen.BackColor = &H8000000F
    
    MyDB.Execute "DELETE * FROM tblMemo WHERE Len(MemoHeader)=0;", dbFailOnError 'we clean up stuff that was to be removed
    
    lstMemos.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT MemoID, CharacterNameID, MemoHeader, MemoValue FROM tblMemo WHERE CharacterNameID=" & gbllCharacterNameID & " ORDER BY MemoHeader;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        Do While (Not rsSetUp.EOF)
            lstMemos.AddItem MyCStr(rsSetUp!MemoHeader)
            lstMemos.ItemData(lstMemos.ListCount - 1) = MyCLng(rsSetUp!MemoID)
            rsSetUp.MoveNext
        Loop
    End If
    Set rsSetUp = Nothing
End Sub

Private Sub cmdSave_Click() 'CharacterNameID MemoHeader MemoValue
    Dim rsSetUp As Recordset 'Only loads Memos directly to the lstMemos ListBox
    If Len(MyCStr(txtMemoValue.Text)) > 65000 Then MsgBox "WARNING: " & vbCrLf & "Your note is " & Len(MyCStr(txtMemoValue.Text)) & " bytes and the Maximum is cstMaxMemoLength bytes, some of your note will be lost.", "CoA Client", vbOKOnly
    Set rsSetUp = MyDB.OpenRecordset("SELECT MemoID, CharacterNameID, MemoHeader, MemoValue FROM tblMemo WHERE MemoID=" & MyCLng(lblMemoTextID) & ";", dbOpenDynaset)
    If (Not rsSetUp.EOF) Then
        rsSetUp.Edit
        rsSetUp!CharacterNameID = gbllCharacterNameID
        rsSetUp!MemoHeader = MyCStr(txtMemoHeader.Text)
        rsSetUp!MemoValue = Mid(MyCStr(txtMemoValue.Text), 1, cstMaxMemoLength)
        rsSetUp.Update
    Else
        rsSetUp.AddNew
        rsSetUp!CharacterNameID = gbllCharacterNameID
        rsSetUp!MemoHeader = MyCStr(txtMemoHeader.Text)
        rsSetUp!MemoValue = Mid(MyCStr(txtMemoValue.Text), 1, cstMaxMemoLength) 'Access 97 has a max of cstMaxMemoLength
        rsSetUp.Update
    End If
    Set rsSetUp = Nothing
    
    cmdNew_Click
End Sub

Private Sub lstMemos_Click()
    Dim rsSetUp As Recordset 'Only loads Memos directly to the lstMemos ListBox
    
    Set rsSetUp = MyDB.OpenRecordset("SELECT MemoID, CharacterNameID, MemoHeader, MemoValue FROM tblMemo WHERE MemoID=" & MyCLng(lstMemos.ItemData(lstMemos.ListIndex)) & " ORDER BY MemoHeader;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        lblMemoTextID.Caption = MyCLng(rsSetUp!MemoID)
        txtMemoHeader.Text = MyCStr(rsSetUp!MemoHeader)
        txtMemoValue.Text = MyCStr(rsSetUp!MemoValue)
        subMemoValueColor MyCStr(rsSetUp!MemoValue)
    End If
    Set rsSetUp = Nothing
End Sub
Private Sub subMemoValueColor(strMVC As Variant)
On Error Resume Next
    Dim lLen As Long
    lLen = (cstMaxMemoLength - Len(MyCStr(strMVC)))
    lblMemoLen.Caption = lLen
    If (lLen < 0) Then
        lblMemoLen.BackColor = RGB(255, 0, 0)
    Else
        lblMemoLen.BackColor = &H8000000F
    End If
End Sub
Private Sub txtMemoHeader_LostFocus()
    subMemoValueColor txtMemoValue.Text
End Sub
Private Sub txtMemoValue_KeyUp(KeyCode As Integer, Shift As Integer)
    subMemoValueColor txtMemoValue.Text
End Sub
Private Sub txtMemoValue_DblClick()
On Error Resume Next
        txtMemoValue.Text = txtMemoValue.Text & vbCrLf & "Captain's Log, stardate: " & vbCrLf & Format(Now(), "mmm dd, yyyy hh:nn:ss") & vbCrLf & "Our Destination is event: x" & MyCStr(gbllSpecialX) & " y" & MyCStr(gbllSpecialY) & " z" & MyCStr(gbllSpecialZ) & vbCrLf & "The sector seems to be near starmap: x" & MyCStr(gbllStarmapX) & " y" & MyCStr(gbllStarmapY) & " z" & MyCStr(gbllStarmapZ)
End Sub
Private Sub txtMemoValue_LostFocus()
    subMemoValueColor txtMemoValue.Text
End Sub
