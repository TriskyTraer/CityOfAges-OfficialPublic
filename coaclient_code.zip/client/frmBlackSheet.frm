VERSION 5.00
Begin VB.Form frmBlackSheet 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   Caption         =   "The - Does Nothing - that Does What you Need"
   ClientHeight    =   3030
   ClientLeft      =   120
   ClientTop       =   450
   ClientWidth     =   4560
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   3030
   ScaleWidth      =   4560
End
Attribute VB_Name = "frmBlackSheet"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_DblClick()
On Error Resume Next
    frmMapper.SetFocus
    frmMain.SetFocus
End Sub

Private Sub Form_Load()
    gblfrmBlackSheet = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblfrmBlackSheet = False
End Sub
