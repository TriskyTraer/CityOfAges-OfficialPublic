VERSION 5.00
Begin VB.Form frmTeachers 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "LEARN"
   ClientHeight    =   1140
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   1650
   Icon            =   "frmTeachers.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   1140
   ScaleWidth      =   1650
   Begin VB.Timer tmrLearn 
      Interval        =   15000
      Left            =   480
      Top             =   240
   End
   Begin VB.CommandButton cmdTeacher 
      Appearance      =   0  'Flat
      BackColor       =   &H0080C0FF&
      Caption         =   "List Teacher Learnings"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   0
      ToolTipText     =   "Click to send the TEACHER command."
      Top             =   120
      Width           =   1335
   End
End
Attribute VB_Name = "frmTeachers"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'see also: subProcessXYZLine
Private Sub cmdTeacher_Click()
    frmMain.Winsock1.SendData "TEACHERS" & vbCrLf
    frmMain.txtSendClientData.Text = "LEARN <spell name?>"
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub Form_Load()
    gblbTeachersWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbTeachersWindow = False
End Sub
Private Sub tmrLearn_Timer() 'slows down the fluttering evect
    gblbTeachersWindow = False
    tmrLearn.Enabled = False
End Sub
