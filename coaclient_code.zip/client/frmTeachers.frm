VERSION 5.00
Begin VB.Form frmTeachers 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Learn from the Teachers"
   ClientHeight    =   2145
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3330
   Icon            =   "frmTeachers.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2145
   ScaleWidth      =   3330
   Begin VB.CommandButton cmdTeacher 
      Appearance      =   0  'Flat
      BackColor       =   &H0080C0FF&
      Caption         =   "View Teacher Learnings"
      Height          =   375
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   240
      Width           =   2895
   End
   Begin VB.Label lblMsg2 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      Caption         =   "Alt-Backpace to scroll back text then ESC to release to continue."
      ForeColor       =   &H80000008&
      Height          =   615
      Left            =   240
      TabIndex        =   2
      Top             =   1560
      Width           =   2895
   End
   Begin VB.Label lblMsg1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      Caption         =   "After you click the button, use commands: LEARN and PRACTICE and COST and DAMAGE to view your spells."
      ForeColor       =   &H80000008&
      Height          =   735
      Left            =   240
      TabIndex        =   1
      Top             =   720
      Width           =   2895
   End
End
Attribute VB_Name = "frmTeachers"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'see also: subProcessXYZLine
Private Sub cmdTeacher_Click()
    frmMain.Winsock1.SendData "TEACHERS" & vbCrLf
    frmMain.txtSendClientData.Text = "LEARN <spell name?>"
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub Form_Load()
    gblbTeachersWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbTeachersWindow = False
End Sub
