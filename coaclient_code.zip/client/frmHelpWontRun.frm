VERSION 5.00
Begin VB.Form frmHelpWontRun 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "HELP - First Run - Errors on the Server"
   ClientHeight    =   12900
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   9660
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpWontRun.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   Picture         =   "frmHelpWontRun.frx":058A
   ScaleHeight     =   12900
   ScaleWidth      =   9660
End
Attribute VB_Name = "frmHelpWontRun"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
