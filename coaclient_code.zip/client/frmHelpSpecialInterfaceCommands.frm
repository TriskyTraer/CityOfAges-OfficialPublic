VERSION 5.00
Begin VB.Form frmHelpSpecialInterfaceCommands 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Help - Special Interface Commands"
   ClientHeight    =   5355
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   8190
   Icon            =   "frmHelpSpecialInterfaceCommands.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5355
   ScaleWidth      =   8190
   Begin VB.TextBox txtHelpInterfaceData 
      Height          =   5055
      Left            =   120
      MultiLine       =   -1  'True
      TabIndex        =   0
      Text            =   "frmHelpSpecialInterfaceCommands.frx":058A
      Top             =   120
      Width           =   7935
   End
End
Attribute VB_Name = "frmHelpSpecialInterfaceCommands"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub Form_Load()
    Dim zInfo As String
    zInfo = zInfo & "DD shows the day description, night is shown too if not the same." & vbCrLf
  zInfo = zInfo & "MAP" & vbCrLf
  zInfo = zInfo & "XXX" & vbCrLf
  zInfo = zInfo & "AC" & vbCrLf
  zInfo = zInfo & "FACTION Data" & vbCrLf
  zInfo = zInfo & "OBJECTS" & vbCrLf
  zInfo = zInfo & "MOBS" & vbCrLf
  zInfo = zInfo & "PLYR rx ry rz facing-graphicsid this is controlled by your client, run alone for the complete necessary room report on players" & vbCrLf
  zInfo = zInfo & "SCAN" & vbCrLf
  zInfo = zInfo & "LOCATION" & vbCrLf
  zInfo = zInfo & "ATMOZ" & vbCrLf
  zInfo = zInfo & "PETS" & vbCrLf
  zInfo = zInfo & "AREA"
  txtHelpInterfaceData.Text = zInfo
End Sub
