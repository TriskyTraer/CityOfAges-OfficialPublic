VERSION 5.00
Begin VB.Form frmMapperDeleteSpot 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Mapper - Delete Spot"
   ClientHeight    =   705
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   5160
   Icon            =   "frmMapperDeleteSpot.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   705
   ScaleWidth      =   5160
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Height          =   495
      Left            =   4800
      Picture         =   "frmMapperDeleteSpot.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   120
      Width           =   255
   End
   Begin VB.TextBox txtDelZ 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   480
      Left            =   3240
      TabIndex        =   2
      Top             =   120
      Width           =   1455
   End
   Begin VB.TextBox txtDelY 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   480
      Left            =   1680
      TabIndex        =   1
      Top             =   120
      Width           =   1455
   End
   Begin VB.TextBox txtDelX 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   480
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1455
   End
End
Attribute VB_Name = "frmMapperDeleteSpot"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Activate()
    gbllFormActivated = 25
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_Load()
    subWindowsPosition Me, "L"
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub txtDelX_LostFocus()
    txtDelX.Text = MyCStr(txtDelX.Text)
End Sub

Private Sub txtDelY_LostFocus()
    txtDelY.Text = MyCStr(txtDelY.Text)
End Sub

Private Sub txtDelZ_LostFocus()
    txtDelZ.Text = MyCStr(txtDelZ.Text)
End Sub

Private Sub cmdDelete_Click()
'On Error Resume Next
    Dim zDelX As String
    Dim zDelY As String
    Dim zDelZ As String
    zDelX = MyCStr(txtDelX.Text)
    zDelY = MyCStr(txtDelY.Text)
    zDelZ = MyCStr(txtDelZ.Text)
    MyDB.Execute "DELETE MapperID FROM tblMapper WHERE (X=" & MyCLng(zDelX) & " AND Y=" & MyCLng(zDelY) & " AND Z=" & MyCLng(zDelZ) & ");", dbFailOnError
End Sub
