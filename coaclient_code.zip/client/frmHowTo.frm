VERSION 5.00
Begin VB.Form frmHowTo 
   Appearance      =   0  'Flat
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "HELP - PLAY TIPS"
   ClientHeight    =   12045
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   8385
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHowTo.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   12045
   ScaleWidth      =   8385
   Begin VB.TextBox txtHelpUnity 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      Height          =   1455
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   15
      Text            =   "frmHowTo.frx":058A
      Top             =   10560
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   7
      Left            =   120
      TabIndex        =   14
      Text            =   "UNITY SPECIAL COMMANDS"
      Top             =   10200
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   6
      Left            =   120
      TabIndex        =   12
      Text            =   "OTHER THAN COMMAND SKILLS THERE IS: RELOADING WEAR SKILLS / ACTIVATE SKILLS / PASSIVE SKILLS"
      Top             =   8640
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   5
      Left            =   120
      TabIndex        =   10
      Text            =   "KEY CUSTOMIZATION and what is with the red Damaged/Raided areas"
      Top             =   7320
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   4
      Left            =   120
      TabIndex        =   8
      Text            =   "MOVING and ATTACKING"
      Top             =   5760
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   3
      Left            =   120
      TabIndex        =   6
      Text            =   "QUESTS of the Realm/PAGE command"
      Top             =   4200
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   2
      Left            =   120
      TabIndex        =   4
      Text            =   "PAGE and DONATE and AUCTION commands"
      Top             =   2880
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   1
      Left            =   120
      TabIndex        =   2
      Text            =   "TALKING TO MOBILES of the REALM (TALK command/MERCH command)"
      Top             =   1560
      Width           =   8175
   End
   Begin VB.TextBox txtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0080FFFF&
      Height          =   375
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Text            =   "FIXED OBJECTS IN THE REALM (cannot be picked up - but you can USE LEVER command or TWIST them!)"
      Top             =   360
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Move around by typing: NORTH SOUTH EAST WEST NE NW SE SW UP DOWN or use the NUMLOCK pad."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   375
      Index           =   7
      Left            =   120
      TabIndex        =   16
      Top             =   0
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":0831
      ForeColor       =   &H80000008&
      Height          =   1215
      Index           =   6
      Left            =   120
      TabIndex        =   13
      Top             =   9000
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":0A6C
      ForeColor       =   &H80000008&
      Height          =   975
      Index           =   5
      Left            =   120
      TabIndex        =   11
      Top             =   7680
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":0BFA
      ForeColor       =   &H80000008&
      Height          =   1215
      Index           =   4
      Left            =   120
      TabIndex        =   9
      Top             =   6120
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":0E0C
      ForeColor       =   &H80000008&
      Height          =   1215
      Index           =   3
      Left            =   120
      TabIndex        =   7
      Top             =   4560
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":101F
      ForeColor       =   &H80000008&
      Height          =   975
      Index           =   2
      Left            =   120
      TabIndex        =   5
      Top             =   3240
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":11CD
      ForeColor       =   &H80000008&
      Height          =   975
      Index           =   1
      Left            =   120
      TabIndex        =   3
      Top             =   1920
      Width           =   8175
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFFF&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmHowTo.frx":132B
      ForeColor       =   &H80000008&
      Height          =   855
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   720
      Width           =   8175
   End
End
Attribute VB_Name = "frmHowTo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

