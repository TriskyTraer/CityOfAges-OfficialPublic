VERSION 5.00
Begin VB.Form frmForgeWindow 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Forge Commands"
   ClientHeight    =   6360
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4815
   Icon            =   "frmForgeWindow.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6360
   ScaleWidth      =   4815
   Begin VB.PictureBox picHammerFilm 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   6375
      Index           =   5
      Left            =   0
      LinkItem        =   " "
      Picture         =   "frmForgeWindow.frx":058A
      ScaleHeight     =   6345
      ScaleWidth      =   4785
      TabIndex        =   34
      Top             =   0
      Visible         =   0   'False
      Width           =   4815
      Begin VB.Timer tmrAnimateForge 
         Enabled         =   0   'False
         Interval        =   675
         Left            =   4080
         Top             =   120
      End
      Begin VB.Label lblEndMessage 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   30
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   2055
         Left            =   0
         TabIndex        =   35
         ToolTipText     =   "End Forge Message"
         Top             =   4320
         Visible         =   0   'False
         Width           =   4815
      End
   End
   Begin VB.PictureBox picHammerFilm 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   6375
      Index           =   4
      Left            =   0
      LinkItem        =   " "
      Picture         =   "frmForgeWindow.frx":5D7F4
      ScaleHeight     =   6345
      ScaleWidth      =   4785
      TabIndex        =   33
      Top             =   0
      Visible         =   0   'False
      Width           =   4815
   End
   Begin VB.PictureBox picHammerFilm 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   6375
      Index           =   3
      Left            =   0
      LinkItem        =   " "
      Picture         =   "frmForgeWindow.frx":C9A9A
      ScaleHeight     =   6345
      ScaleWidth      =   4785
      TabIndex        =   32
      Top             =   0
      Visible         =   0   'False
      Width           =   4815
   End
   Begin VB.PictureBox picHammerFilm 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   6375
      Index           =   2
      Left            =   0
      LinkItem        =   " "
      Picture         =   "frmForgeWindow.frx":11DF3C
      ScaleHeight     =   6345
      ScaleWidth      =   4785
      TabIndex        =   31
      Top             =   0
      Visible         =   0   'False
      Width           =   4815
   End
   Begin VB.PictureBox picHammerFilm 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   6375
      Index           =   1
      Left            =   0
      LinkItem        =   " "
      Picture         =   "frmForgeWindow.frx":199FDA
      ScaleHeight     =   6345
      ScaleWidth      =   4785
      TabIndex        =   30
      Top             =   0
      Visible         =   0   'False
      Width           =   4815
   End
   Begin VB.PictureBox picHammerFilm 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      ForeColor       =   &H80000008&
      Height          =   6375
      Index           =   0
      Left            =   0
      LinkItem        =   " "
      Picture         =   "frmForgeWindow.frx":20649C
      ScaleHeight     =   6345
      ScaleWidth      =   4785
      TabIndex        =   29
      Top             =   0
      Visible         =   0   'False
      Width           =   4815
   End
   Begin VB.PictureBox picCharAbilities 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   2535
      Index           =   1
      Left            =   120
      ScaleHeight     =   2505
      ScaleMode       =   0  'User
      ScaleWidth      =   4545
      TabIndex        =   19
      ToolTipText     =   "Character Abilities"
      Top             =   3720
      Width           =   4575
      Begin VB.PictureBox picCharacterSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         ForeColor       =   &H80000008&
         Height          =   1695
         Index           =   2
         Left            =   2280
         ScaleHeight     =   1665
         ScaleWidth      =   2145
         TabIndex        =   26
         ToolTipText     =   "This are travelling item commands."
         Top             =   720
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "KEEP"
            Height          =   255
            Index           =   19
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   28
            ToolTipText     =   "For free KEEP your worn Equipment items SAFE."
            Top             =   120
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "UNKEEP"
            Height          =   255
            Index           =   20
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   27
            ToolTipText     =   "For free UNKEEP your removed Inventory items to SELL/TRADE/DROP andor SACRIFICE"
            Top             =   480
            Width           =   1695
         End
      End
      Begin VB.PictureBox picCharacterSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   1695
         Index           =   1
         Left            =   120
         ScaleHeight     =   1665
         ScaleWidth      =   2145
         TabIndex        =   20
         ToolTipText     =   "Must be at the forge to use these commands."
         Top             =   720
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "CHIZZLE [Alignment]"
            Height          =   255
            Index           =   18
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   25
            ToolTipText     =   "50 CROWNS OF GLORY, removes any Alignment requirement of the item."
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "TEMPER [Level Help]"
            Height          =   255
            Index           =   17
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   24
            ToolTipText     =   "33 CROWNS OF GLORY, attempts to lower the level requirement of the item."
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "UNSTAMP"
            Height          =   255
            Index           =   16
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   23
            ToolTipText     =   "9 CROWNS OF GLORY, removes any STAMP"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "STAMP"
            Height          =   255
            Index           =   15
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   22
            ToolTipText     =   "5 CROWNS OF GLORY, this item is now yours forever, never to be stolen again!"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Label lblCharAbilities 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "S P E C I A L"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   2
         Left            =   0
         TabIndex        =   21
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
   Begin VB.PictureBox picCharAbilities 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   0
      Left            =   120
      ScaleHeight     =   3585
      ScaleMode       =   0  'User
      ScaleWidth      =   4545
      TabIndex        =   0
      ToolTipText     =   "Character Abilities"
      Top             =   120
      Width           =   4575
      Begin VB.PictureBox Picture1 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   3015
         Index           =   0
         Left            =   2280
         ScaleHeight     =   2985
         ScaleWidth      =   2145
         TabIndex        =   10
         ToolTipText     =   "Must be at the forge to use these commands."
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "SOUL"
            Height          =   255
            Index           =   14
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   18
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   2640
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "HR"
            Height          =   255
            Index           =   7
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   17
            ToolTipText     =   "1 CROWN FOR 3"
            Top             =   120
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "DR"
            Height          =   255
            Index           =   8
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   16
            ToolTipText     =   "1 CROWN FOR 2"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "AC"
            Height          =   255
            Index           =   9
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   15
            ToolTipText     =   "1 CROWN FOR 2"
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "HP"
            Height          =   255
            Index           =   10
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   14
            ToolTipText     =   "1 CROWN FOR 4"
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "MANA"
            Height          =   255
            Index           =   11
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   13
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "ESSENCE"
            Height          =   255
            Index           =   12
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   12
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   1920
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "MOVE"
            Height          =   255
            Index           =   13
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   11
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   2280
            Width           =   1695
         End
      End
      Begin VB.PictureBox picCharacterSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2655
         Index           =   0
         Left            =   120
         ScaleHeight     =   2625
         ScaleWidth      =   2145
         TabIndex        =   2
         ToolTipText     =   "Must be at the forge to use these commands."
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "LUCK"
            Height          =   255
            Index           =   6
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   9
            ToolTipText     =   "12 CROWNS OF GLORY [helps magicfind]"
            Top             =   2280
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "CHARASMA"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   8
            ToolTipText     =   "7 CROWNS OF GLORY"
            Top             =   1920
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "CONSTITUTION"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   7
            ToolTipText     =   "11 CROWNS OF GLORY"
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "DEXTERITY"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   6
            ToolTipText     =   "9 CROWNS OF GLORY"
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "WISDOM"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   5
            ToolTipText     =   "8 CROWNS OF GLORY"
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "INTELLIGENCE"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   4
            ToolTipText     =   "8 CROWNS OF GLORY"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "STRENGTH"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   3
            ToolTipText     =   "13 CROWNS OF GLORY"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Label lblCharAbilities 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "F O R G E  A B I L I T I E S"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   0
         Left            =   0
         TabIndex        =   1
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
End
Attribute VB_Name = "frmForgeWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
 Option Explicit
 Dim lAnimateforge As Long
'                   ~FORGE UPGRADE COMMANDS~
'  STR INT WIS DEX CON CHA LUC
'  HR DR AC HP MANA ESSE MOVE SOUL
'  STAMP UNSTAMP TEMPER CHIZZLE RENA DESC
'  ITEM SETS STAMPS: BACKSTAB MISSLERANGE
'STR        -  13 crowns forges 1 strength to an object
'INT        -  8 crowns forges 1 intelligence to an object
'WIS        -  8 crowns forges 1 wisdom to an object
'DEX        -  9 crowns forges 1 dexterity to an object
'CON        -  11 crowns forges 1 constitution to an object
'CHA        -  7 crowns forges 1 charisma to an object
'LUC        -  12 crowns forges 1 luck to an object
'                NOTE: Stats are used throughout the system,
'                one ability point can be very powerful!
'
'HR         -  1 crown forges 3 hitroll to an object
'DR         -  1 crown forges 2 average damage roll to an object
'AC         -  1 crown forges 2 armour class to your item
'HP         -  1 crown forges 4 hit points to an object
'MANA       -  1 crown forges 10 offensive mana to an object
'ESSE       -  1 crown forges 10 essence
'MOVE       -  1 crown forges 10 move
'SOUL       -  1 crown forges 10 soul
'
'STAMP      -  5 crowns stamps this object as yours forever
'UNSTAMP    -  9 crowns unstamps this object
'TEMPER     -  33 crowns, randoms level requirement
'CHIZZLE    -  50 crowns, alignment sets to neutral
'RENA       -  1 crown cost per change, renames/restrings an object
'DESC       -  1 crown cost per change, modifies the object's description
'                object description is revealed when you look at the item,
'                this command will overwrite the previous item description so
'                if you want to keep the previous description you will have
'                to append it with your new description.
Private Sub cmdSendoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "FORGE 1 STR" & vbCrLf
                lblEndMessage.Caption = "FORGED STRENGTH!"
            Case 1
                frmMain.Winsock1.SendData "FORGE 1 INT" & vbCrLf
                lblEndMessage.Caption = "FORGED INTELLIGENCE!"
            Case 2
                frmMain.Winsock1.SendData "FORGE 1 WIS" & vbCrLf
                lblEndMessage.Caption = "FORGED WISDOM!"
            Case 3
                frmMain.Winsock1.SendData "FORGE 1 DEX" & vbCrLf
                lblEndMessage.Caption = "FORGED DEXTERITY!"
            Case 4
                frmMain.Winsock1.SendData "FORGE 1 CON" & vbCrLf
                lblEndMessage.Caption = "FORGED CONSTITUTION!"
            Case 5
                frmMain.Winsock1.SendData "FORGE 1 CHA" & vbCrLf
                lblEndMessage.Caption = "FORGED CHARISMA!"
            Case 6
                frmMain.Winsock1.SendData "FORGE 1 LUC" & vbCrLf
                lblEndMessage.Caption = "FORGED LUCK!"
            Case 7
                frmMain.Winsock1.SendData "FORGE 1 HR" & vbCrLf
                lblEndMessage.Caption = "FORGED HIT ROLL CHANCE!"
            Case 8
                frmMain.Winsock1.SendData "FORGE 1 DR" & vbCrLf
                lblEndMessage.Caption = "FORGED DAMAGE ROLL CHANCE!"
            Case 9
                frmMain.Winsock1.SendData "FORGE 1 AC" & vbCrLf
                lblEndMessage.Caption = "FORGED ARMOR CLASS!"
            Case 10
                frmMain.Winsock1.SendData "FORGE 1 HP" & vbCrLf
                lblEndMessage.Caption = "FORGED LIFE HIT POINTS!"
            Case 11
                frmMain.Winsock1.SendData "FORGE 1 MANA" & vbCrLf
                lblEndMessage.Caption = "FORGED MANA!"
            Case 12
                frmMain.Winsock1.SendData "FORGE 1 ESSE" & vbCrLf
                lblEndMessage.Caption = "FORGED ESSENCE!"
            Case 13
                frmMain.Winsock1.SendData "FORGE 1 SOUL" & vbCrLf
                lblEndMessage.Caption = "FORGED SOUL!"
            Case 14
                frmMain.Winsock1.SendData "FORGE 1 MOVE" & vbCrLf
                lblEndMessage.Caption = "FORGED MOVE!"
            Case 15
                frmMain.Winsock1.SendData "FORGE STAMP" & vbCrLf
                lblEndMessage.Caption = "FORGED STAMPED YOURS!"
            Case 16
                frmMain.Winsock1.SendData "FORGE UNSTAMP" & vbCrLf
                lblEndMessage.Caption = "FORGED UNSTAMPED!"
            Case 17
                frmMain.Winsock1.SendData "FORGE TEMPER" & vbCrLf
                lblEndMessage.Caption = "FORGED TEMPER!"
            Case 18
                frmMain.Winsock1.SendData "FORGE CHIZZLE" & vbCrLf
                lblEndMessage.Caption = "FORGED A CHIZZLING!"
            Case 19
                frmMain.Winsock1.SendData "KEEP" & vbCrLf
                lblEndMessage.Caption = "KEEP ALL EQUIPMENT!"
            Case 20
                frmMain.Winsock1.SendData "UNKEEP" & vbCrLf
                lblEndMessage.Caption = "UNKEEP ALL INVENTORY!"
        End Select
        If (gblbAnimation) Then tmrAnimateForge.Enabled = True
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub Form_Load()
    lblEndMessage.Caption = ""
    lblEndMessage.Visible = False
    gblbForgeWindow = True
    lAnimateforge = -1
    tmrAnimateForge.Enabled = False
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblbForgeWindow = False
End Sub

Private Sub tmrAnimateForge_Timer()
    picHammerFilm(0).Visible = False
    picHammerFilm(1).Visible = False
    picHammerFilm(2).Visible = False
    picHammerFilm(3).Visible = False
    picHammerFilm(4).Visible = False
    lAnimateforge = lAnimateforge + 1
    Select Case lAnimateforge
        Case 0, 1, 2, 3, 4, 5
            tmrAnimateForge.Interval = 375
            picHammerFilm(lAnimateforge).Visible = True
            If (lAnimateforge > 4) Then
                tmrAnimateForge.Interval = 1150
                If (lblEndMessage.Caption <> "") Then lblEndMessage.Visible = True
            End If
        Case 7
            lblEndMessage.Caption = ""
            picHammerFilm(5).Visible = False
            lblEndMessage.Visible = False
            tmrAnimateForge.Interval = 675
            tmrAnimateForge.Enabled = False
            lAnimateforge = -1
            lblEndMessage.Visible = True
    End Select
End Sub
