VERSION 5.00
Begin VB.Form frmForgeWindow 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Forge Commands"
   ClientHeight    =   6975
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4830
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6975
   ScaleWidth      =   4830
   Begin VB.PictureBox picCharAbilities 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   3375
      Index           =   1
      Left            =   120
      ScaleHeight     =   3345
      ScaleMode       =   0  'User
      ScaleWidth      =   4545
      TabIndex        =   19
      ToolTipText     =   "Character Abilities"
      Top             =   3480
      Width           =   4575
      Begin VB.PictureBox picCharacterSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2655
         Index           =   2
         Left            =   2280
         ScaleHeight     =   2625
         ScaleWidth      =   2145
         TabIndex        =   26
         ToolTipText     =   "This are travelling item commands."
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "KEEP"
            Height          =   255
            Index           =   19
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   28
            ToolTipText     =   "For free KEEP your worn Equipment items SAFE."
            Top             =   120
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "UNKEEP"
            Height          =   255
            Index           =   20
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   27
            ToolTipText     =   "For free UNKEEP your removed Inventory items to SELL/TRADE/DROP andor SACRIFICE"
            Top             =   480
            Width           =   1695
         End
      End
      Begin VB.PictureBox picCharacterSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2655
         Index           =   1
         Left            =   120
         ScaleHeight     =   2625
         ScaleWidth      =   2145
         TabIndex        =   20
         ToolTipText     =   "Must be at the forge to use these commands."
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "CHIZZLE [Alignment]"
            Height          =   255
            Index           =   18
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   25
            ToolTipText     =   "50 CROWNS OF GLORY, removes any Alignment requirement of the item."
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "TEMPER [Level Help]"
            Height          =   255
            Index           =   17
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   24
            ToolTipText     =   "33 CROWNS OF GLORY, attempts to lower the level requirement of the item."
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "UNSTAMP"
            Height          =   255
            Index           =   16
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   23
            ToolTipText     =   "9 CROWNS OF GLORY, removes any STAMP"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "STAMP"
            Height          =   255
            Index           =   15
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   22
            ToolTipText     =   "5 CROWNS OF GLORY, this item is now yours forever, never to be stolen again!"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Label lblCharAbilities 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "S P E C I A L"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   2
         Left            =   0
         TabIndex        =   21
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
   Begin VB.PictureBox picCharAbilities 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   3375
      Index           =   0
      Left            =   120
      ScaleHeight     =   3345
      ScaleMode       =   0  'User
      ScaleWidth      =   4545
      TabIndex        =   0
      ToolTipText     =   "Character Abilities"
      Top             =   120
      Width           =   4575
      Begin VB.PictureBox Picture1 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2655
         Index           =   0
         Left            =   2280
         ScaleHeight     =   2625
         ScaleWidth      =   2145
         TabIndex        =   10
         ToolTipText     =   "Must be at the forge to use these commands."
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "SOUL"
            Height          =   255
            Index           =   14
            Left            =   1080
            Style           =   1  'Graphical
            TabIndex        =   18
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   2280
            Width           =   855
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "HR"
            Height          =   255
            Index           =   7
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   17
            ToolTipText     =   "1 CROWN FOR 3"
            Top             =   120
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "DR"
            Height          =   255
            Index           =   8
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   16
            ToolTipText     =   "1 CROWN FOR 2"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "AC"
            Height          =   255
            Index           =   9
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   15
            ToolTipText     =   "1 CROWN FOR 2"
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "HP"
            Height          =   255
            Index           =   10
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   14
            ToolTipText     =   "1 CROWN FOR 4"
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "MANA"
            Height          =   255
            Index           =   11
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   13
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "ESSENCE"
            Height          =   255
            Index           =   12
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   12
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   1920
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "MOVE"
            Height          =   255
            Index           =   13
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   11
            ToolTipText     =   "1 CROWN FOR 10"
            Top             =   2280
            Width           =   855
         End
      End
      Begin VB.PictureBox picCharacterSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2655
         Index           =   0
         Left            =   120
         ScaleHeight     =   2625
         ScaleWidth      =   2145
         TabIndex        =   2
         ToolTipText     =   "Must be at the forge to use these commands."
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "LUCK"
            Height          =   255
            Index           =   6
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   9
            ToolTipText     =   "12 CROWNS OF GLORY [helps magicfind]"
            Top             =   2280
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "CHARASMA"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   8
            ToolTipText     =   "7 CROWNS OF GLORY"
            Top             =   1920
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "CONSTITUTION"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   7
            ToolTipText     =   "11 CROWNS OF GLORY"
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "DEXTERITY"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   6
            ToolTipText     =   "9 CROWNS OF GLORY"
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "WISDOM"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   5
            ToolTipText     =   "8 CROWNS OF GLORY"
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "INTELLIGENCE"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   4
            ToolTipText     =   "8 CROWNS OF GLORY"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "STRENGTH"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   3
            ToolTipText     =   "13 CROWNS OF GLORY"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Label lblCharAbilities 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "F O R G E  A B I L I T I E S"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Index           =   0
         Left            =   0
         TabIndex        =   1
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
End
Attribute VB_Name = "frmForgeWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
 Option Explicit
'                   ~FORGE UPGRADE COMMANDS~
'  STR INT WIS DEX CON CHA LUC
'  HR DR AC HP MANA ESSE MOVE SOUL
'  STAMP UNSTAMP TEMPER CHIZZLE RENA DESC
'  ITEM SETS STAMPS: BACKSTAB MISSLERANGE
'STR        -  13 crowns forges 1 strength to an object
'INT        -  8 crowns forges 1 intelligence to an object
'WIS        -  8 crowns forges 1 wisdom to an object
'DEX        -  9 crowns forges 1 dexterity to an object
'CON        -  11 crowns forges 1 constitution to an object
'CHA        -  7 crowns forges 1 charisma to an object
'LUC        -  12 crowns forges 1 luck to an object
'                NOTE: Stats are used throughout the system,
'                one ability point can be very powerful!
'
'HR         -  1 crown forges 3 hitroll to an object
'DR         -  1 crown forges 2 average damage roll to an object
'AC         -  1 crown forges 2 armour class to your item
'HP         -  1 crown forges 4 hit points to an object
'MANA       -  1 crown forges 10 offensive mana to an object
'ESSE       -  1 crown forges 10 essence
'MOVE       -  1 crown forges 10 move
'SOUL       -  1 crown forges 10 soul
'
'STAMP      -  5 crowns stamps this object as yours forever
'UNSTAMP    -  9 crowns unstamps this object
'TEMPER     -  33 crowns, randoms level requirement
'CHIZZLE    -  50 crowns, alignment sets to neutral
'RENA       -  1 crown cost per change, renames/restrings an object
'DESC       -  1 crown cost per change, modifies the object's description
'                object description is revealed when you look at the item,
'                this command will overwrite the previous item description so
'                if you want to keep the previous description you will have
'                to append it with your new description.
Private Sub cmdSendoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "FORGE 1 STR" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "FORGE 1 INT" & vbCrLf
            Case 2
                frmMain.Winsock1.SendData "FORGE 1 WIS" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "FORGE 1 DEX" & vbCrLf
            Case 4
                frmMain.Winsock1.SendData "FORGE 1 CON" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "FORGE 1 CHA" & vbCrLf
            Case 6
                frmMain.Winsock1.SendData "FORGE 1 LUC" & vbCrLf
            Case 7
                frmMain.Winsock1.SendData "FORGE 1 HR" & vbCrLf
            Case 8
                frmMain.Winsock1.SendData "FORGE 1 DR" & vbCrLf
            Case 9
                frmMain.Winsock1.SendData "FORGE 1 AC" & vbCrLf
            Case 10
                frmMain.Winsock1.SendData "FORGE 1 HP" & vbCrLf
            Case 11
                frmMain.Winsock1.SendData "FORGE 1 MANA" & vbCrLf
            Case 12
                frmMain.Winsock1.SendData "FORGE 1 ESSE" & vbCrLf
            Case 13
                frmMain.Winsock1.SendData "FORGE 1 SOUL" & vbCrLf
            Case 14
                frmMain.Winsock1.SendData "FORGE 1 MOVE" & vbCrLf
            Case 15
                frmMain.Winsock1.SendData "FORGE STAMP" & vbCrLf
            Case 16
                frmMain.Winsock1.SendData "FORGE UNSTAMP" & vbCrLf
            Case 17
                frmMain.Winsock1.SendData "FORGE TEMPER" & vbCrLf
            Case 18
                frmMain.Winsock1.SendData "FORGE CHIZZLE" & vbCrLf
            Case 19
                frmMain.Winsock1.SendData "KEEP" & vbCrLf
            Case 20
                frmMain.Winsock1.SendData "UNKEEP" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub Form_Load()
gblbForgeWindow = True
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblbForgeWindow = False
End Sub
