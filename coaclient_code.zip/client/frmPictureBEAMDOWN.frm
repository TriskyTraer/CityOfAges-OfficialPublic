VERSION 5.00
Begin VB.Form frmPictureBEAMDOWN 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "BEAM DOWN!!!"
   ClientHeight    =   10050
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   10080
   Icon            =   "frmPictureBEAMDOWN.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmPictureBEAMDOWN.frx":058A
   ScaleHeight     =   10050
   ScaleWidth      =   10080
End
Attribute VB_Name = "frmPictureBEAMDOWN"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
