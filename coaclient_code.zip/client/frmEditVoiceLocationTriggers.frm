VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmEditVoiceLocationTriggers 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Profile - Read Me by Locations"
   ClientHeight    =   9015
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   9375
   Icon            =   "frmEditVoiceLocationTriggers.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   9015
   ScaleWidth      =   9375
   Begin VB.CommandButton cmdNoVoiceOver 
      Appearance      =   0  'Flat
      Caption         =   "Turn off Voice Overs"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3720
      TabIndex        =   20
      Top             =   7080
      Width           =   1695
   End
   Begin VB.CommandButton cmdCancelSound 
      Appearance      =   0  'Flat
      Caption         =   "Stop the Sound"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   19
      Top             =   7080
      Width           =   1695
   End
   Begin VB.TextBox txtZ 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   4560
      MaxLength       =   255
      ScrollBars      =   2  'Vertical
      TabIndex        =   14
      ToolTipText     =   "Z"
      Top             =   6000
      Width           =   855
   End
   Begin VB.TextBox txtY2 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   3360
      MaxLength       =   255
      ScrollBars      =   2  'Vertical
      TabIndex        =   13
      ToolTipText     =   "Y2"
      Top             =   6000
      Width           =   855
   End
   Begin VB.TextBox txtY1 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   2400
      MaxLength       =   255
      ScrollBars      =   2  'Vertical
      TabIndex        =   12
      ToolTipText     =   "Y1"
      Top             =   6000
      Width           =   855
   End
   Begin VB.TextBox txtX2 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   1200
      MaxLength       =   255
      ScrollBars      =   2  'Vertical
      TabIndex        =   11
      ToolTipText     =   "X2"
      Top             =   6000
      Width           =   855
   End
   Begin VB.TextBox txtX1 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      MaxLength       =   255
      ScrollBars      =   2  'Vertical
      TabIndex        =   10
      ToolTipText     =   "X1"
      Top             =   6000
      Width           =   855
   End
   Begin VB.CommandButton cmdNew 
      Appearance      =   0  'Flat
      Caption         =   "&New"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   3
      Top             =   8640
      Width           =   975
   End
   Begin VB.CommandButton cmdLoad 
      Appearance      =   0  'Flat
      Caption         =   "&Load"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   4
      Top             =   8640
      Width           =   975
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5520
      TabIndex        =   5
      Top             =   8640
      Width           =   975
   End
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Caption         =   "&Delete"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   8280
      Picture         =   "frmEditVoiceLocationTriggers.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   8640
      Width           =   975
   End
   Begin VB.ListBox lstEVLT 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   4350
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   9135
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      ForeColor       =   &H80000008&
      Height          =   2775
      Left            =   120
      ScaleHeight     =   2745
      ScaleWidth      =   9105
      TabIndex        =   7
      TabStop         =   0   'False
      Top             =   4800
      Width           =   9135
      Begin VB.CommandButton cmdRepeatStoryLine 
         Appearance      =   0  'Flat
         Caption         =   "Repeat Storyline"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   7320
         TabIndex        =   18
         Top             =   2280
         Width           =   1695
      End
      Begin VB.CommandButton cmdShhhMode 
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   8640
         Picture         =   "frmEditVoiceLocationTriggers.frx":0B14
         Style           =   1  'Graphical
         TabIndex        =   17
         ToolTipText     =   "Shhhh the recording"
         Top             =   840
         Width           =   375
      End
      Begin VB.CommandButton cmdPlayer 
         Appearance      =   0  'Flat
         Height          =   375
         Left            =   8640
         Picture         =   "frmEditVoiceLocationTriggers.frx":109E
         Style           =   1  'Graphical
         TabIndex        =   16
         Top             =   480
         Width           =   375
      End
      Begin VB.ComboBox cbxPlayed 
         Appearance      =   0  'Flat
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   390
         Left            =   5520
         TabIndex        =   15
         Top             =   1200
         Width           =   3495
      End
      Begin VB.TextBox txtReadToMeHeader 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   50
         MultiLine       =   -1  'True
         TabIndex        =   1
         ToolTipText     =   "Header"
         Top             =   120
         Width           =   8895
      End
      Begin VB.TextBox txtReadToMeFileName 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Left            =   120
         MaxLength       =   255
         ScrollBars      =   2  'Vertical
         TabIndex        =   2
         ToolTipText     =   "Play file name"
         Top             =   600
         Width           =   8415
      End
      Begin VB.Label lblReadToMeID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   8
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin MSComDlg.CommonDialog CDlg1 
      Left            =   0
      Top             =   0
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmEditVoiceLocationTriggers.frx":1228
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   855
      Left            =   120
      TabIndex        =   9
      Top             =   7680
      Width           =   9135
   End
End
Attribute VB_Name = "frmEditVoiceLocationTriggers"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim gbllNextLine As Long
Private Sub subLoadAllReadMes()
    Dim rsData As Recordset 'Only loads ReadMess directly to the lstEVLT ListBox
    MyDB.Execute "DELETE * FROM tblReadToMe WHERE Len(ReadToMeHeader)=0;", dbFailOnError 'we clean up stuff that was to be removed
    lstEVLT.Clear
    Set rsData = MyDB.OpenRecordset("SELECT ReadToMeID, ReadToMeHeader FROM tblReadToMe ORDER BY ReadToMeHeader;", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        Do While (Not rsData.EOF)
            lstEVLT.AddItem MyCStr(rsData!ReadToMeHeader) 'This is the only one that is required - we load the rest upon click
            lstEVLT.ItemData(lstEVLT.ListCount - 1) = rsData!ReadToMeID
            rsData.MoveNext
        Loop
    End If
    Set rsData = Nothing
End Sub

Private Sub subSaveReadMes()
    Dim rsData As Recordset
    Dim zCharacterName As String
    Dim lReadToMeID As Long
    Dim zReadToMeHeader As String
    Dim zReadToMeFileName As String
    Dim lX1 As Long
    Dim lX2 As Long
    Dim lY1 As Long
    Dim lY2 As Long
    Dim lZ As Long
    Dim lPlayed As Long
    Dim zSendCommandForPlayer As String
    
    lReadToMeID = MyCLng(lblReadToMeID.Caption)
    lX1 = MyCLng(txtX1.Text)
    lX2 = MyCLng(txtX2.Text)
    lY1 = MyCLng(txtY1.Text)
    lY2 = MyCLng(txtY2.Text)
    lZ = MyCLng(txtZ.Text)
    lPlayed = MyCLng(Mid(cbxPlayed.Text, 1, 1))
    zSendCommandForPlayer = ""
    zReadToMeHeader = zRemoveSQLCrashChars(txtReadToMeHeader.Text)
    txtReadToMeHeader.Text = zReadToMeHeader 'After we massage the value we show them what we exactly did with it
    zReadToMeFileName = zRemoveSQLCrashChars(txtReadToMeFileName.Text)
    txtReadToMeFileName.Text = zReadToMeFileName 'After we massage the value we show them what we exactly did with it
    
    DoEvents
    
    Set rsData = MyDB.OpenRecordset("SELECT X1, X2, Y1, Y2, Z, ReadToMeHeader, ReadToMeFileName, SendCommandForPlayer, Played, CharacterNameID FROM tblReadToMe WHERE ReadToMeID=" & lReadToMeID & ";", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!Played = lPlayed
        rsData!ReadToMeHeader = zReadToMeHeader
        rsData!ReadToMeFileName = zReadToMeFileName
        rsData!SendCommandForPlayer = zSendCommandForPlayer
        rsData!X1 = lX1
        rsData!X2 = lX2
        rsData!Y1 = lY1
        rsData!Y2 = lY2
        rsData!Z = lZ
        rsData.Update
    Else
        rsData.AddNew
        rsData!Played = lPlayed
        rsData!ReadToMeHeader = zReadToMeHeader
        rsData!ReadToMeFileName = zReadToMeFileName
        rsData!SendCommandForPlayer = zSendCommandForPlayer
        rsData!X1 = lX1
        rsData!X2 = lX2
        rsData!Y1 = lY1
        rsData!Y2 = lY2
        rsData!Z = lZ
        rsData.Update
    End If
    Set rsData = Nothing
    
    cmdLoad_Click
End Sub

Private Sub cbxPlayed_KeyUp(KeyCode As Integer, Shift As Integer)
    cbxPlayed.Text = "0: play again"
End Sub

Private Sub cmdCancelSound_Click()
    cmdShhhMode_Click 'mute sound
End Sub

Private Sub cmdDelete_Click()
    subDelete
End Sub

Private Sub cmdLoad_Click()
    subNew
    subLoadAllReadMes
End Sub

Private Sub cmdNew_Click()
    subNew
End Sub

Private Sub cmdNoVoiceOver_Click()
On Error Resume Next
    MyDB.Execute "UPDATE tblReadToMe SET Played=1 WHERE Played=0;", dbFailOnError 'Not Played means they will hear it again
    cmdLoad_Click
    MsgBox "Done!" & vbCrLf & "Voice Over Turned off!" & vbCrLf & "That bad huh? *winks*", vbOKOnly
End Sub

Private Sub cmdPlayer_Click()
On Error Resume Next
    If (Len(MyCStr(txtReadToMeFileName.Text)) > 0) Then
        Select Case 2
            Case 1 'method 1 (said to play two sounds at once) - not sure what is wrong with it
                mciSendString "open " & txtReadToMeFileName.Text & " type mpegvideo alias FirstSound", "", 0, 0
                mciSendString "play FirstSound", "", 0, 0
                'mciSendString("open " & fileName & " type mpegvideo alias SecondSound", String.Empty, 0, 0)
                'mciSendString("play SecondSound", String.Empty, 0, 0)
                'mciSendString("close FirstSound", String.Empty, 0, 0) 'close in reverse order if possible
                'mciSendString("close SecondSound", String.Empty, 0, 0)
            Case 2 'method 2
                Set Player = Nothing
                Set Player = New FilgraphManager 'This is the sound and music player
                    Player.RenderFile MyCStr(txtReadToMeFileName.Text)
                    Player.Run
        End Select
    Else
        With CDlg1
            .CancelError = True
            .DialogTitle = "Browse For MP3 Files"
            .Filter = "MP3 Files (*.mp3) |*.mp3; |Wave Files (*.wav) |*.wav; |Midi Files (*.mid) |*.mid"
            .ShowOpen
            If (Len(.filename) <> 0) Then txtReadToMeFileName.Text = .filename
        End With
    End If
End Sub

Private Sub cmdRepeatStoryLine_Click()
On Error Resume Next
    MyDB.Execute "UPDATE tblReadToMe SET Played=0 WHERE Played=1;", dbFailOnError 'Not Played means they will hear it again
    cmdLoad_Click
    MsgBox "Done!" & vbCrLf & "When you enter certain areas you will hear the Storyline Lore play once again, Enjoy!", vbOKOnly
End Sub

Private Sub cmdSave_Click()
    subSave
End Sub

Private Sub cmdShhhMode_Click()
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    Set Player = Nothing
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 8
    txtReadToMeHeader.SetFocus
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subNew
    subLoadAllReadMes
    subWindowsPosition Me, "L"
End Sub

Private Sub Form_Unload(Cancel As Integer)
On Error Resume Next
    subWindowsPosition Me, "S"
    MyDB.Execute "DELETE * FROM tblReadToMe WHERE Len(ReadToMeHeader)=0;", dbFailOnError 'we clean up stuff that was to be removed
    Set Player = Nothing
End Sub

Private Sub subDelete()
    MyDB.Execute "DELETE * FROM tblReadToMe WHERE ReadToMeID=" & MyCLng(lblReadToMeID.Caption) & ";", dbFailOnError
    subNew
    subLoadAllReadMes
End Sub

Private Sub subNew()
'On Error Resume Next
    cbxPlayed.Clear
    cbxPlayed.AddItem "0: not played yet"
    cbxPlayed.AddItem "1: played, will not play again"
    cbxPlayed.AddItem "2: repeat play loop"
    txtReadToMeHeader.Text = ""
    txtReadToMeFileName.Text = ""
    lblReadToMeID.Caption = ""
    txtX1.Text = ""
    txtX2.Text = ""
    txtY1.Text = ""
    txtY2.Text = ""
    txtZ.Text = ""
    cbxPlayed.Text = "0: play again"
    DoEvents
End Sub

Private Sub subSave()
    subSaveReadMes
    subNew
    subLoadAllReadMes
End Sub

Private Sub lstEVLT_Click()
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("SELECT ReadToMeID, CharacterNameID, Played, ReadToMeHeader, ReadToMeFileName, X1, X2, Y1, Y2, Z, SendCommandForPlayer FROM tblReadToMe WHERE ReadToMeID=" & MyCLng(lstEVLT.ItemData(lstEVLT.ListIndex)) & ";", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        lblReadToMeID.Caption = MyCLng(rsData!ReadToMeID)
        'cbxPlayed.Text = MyCLng(rsData!Played)
        Select Case MyCLng(rsData!Played)
            Case 0
                cbxPlayed.Text = "0: not played yet"
            Case 1
                cbxPlayed.Text = "1: played, will not play again"
            Case 2
                cbxPlayed.Text = "2: repeat play loop"
        End Select
        txtReadToMeHeader = MyCStr(rsData!ReadToMeHeader)
        txtReadToMeFileName = MyCStr(rsData!ReadToMeFileName)
        'txtSendCommandForPlayer = MyCStr(rsData!SendCommandForPlayer)
        txtX1 = MyCLng(rsData!X1)
        txtX2 = MyCLng(rsData!X2)
        txtY1 = MyCLng(rsData!Y1)
        txtY2 = MyCLng(rsData!Y2)
        txtZ = MyCLng(rsData!Z)

        rsData.MoveNext
        txtReadToMeHeader.SetFocus
    Else
        subNew
    End If
    Set rsData = Nothing
End Sub

Private Sub txtX1_LostFocus()
    Dim lC1 As Long
    Dim lC2 As Long
    lC1 = MyCLng(txtX1.Text)
    lC2 = MyCLng(txtX2.Text)
    If (lC1 > lC2) Then
        lC2 = lC1
    End If
    txtX1.Text = lC1
    txtX2.Text = lC2
End Sub

Private Sub txtX2_LostFocus()
    Dim lC1 As Long
    Dim lC2 As Long
    lC1 = MyCLng(txtX1.Text)
    lC2 = MyCLng(txtX2.Text)
    If (lC2 < lC1) Then
        lC2 = lC1
    End If
    txtX1.Text = lC1
    txtX2.Text = lC2
End Sub

Private Sub txtY1_LostFocus()
    Dim lC1 As Long
    Dim lC2 As Long
    lC1 = MyCLng(txtY1.Text)
    lC2 = MyCLng(txtY2.Text)
    If (lC1 > lC2) Then
        lC2 = lC1
    End If
    txtY1.Text = lC1
    txtY2.Text = lC2
End Sub

Private Sub txtY2_LostFocus()
    Dim lC1 As Long
    Dim lC2 As Long
    lC1 = MyCLng(txtY1.Text)
    lC2 = MyCLng(txtY2.Text)
    If (lC2 < lC1) Then
        lC1 = lC2
    End If
    txtY1.Text = lC1
    txtY2.Text = lC2
End Sub
