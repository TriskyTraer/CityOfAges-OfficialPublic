VERSION 5.00
Begin VB.Form frmEquipment 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   Caption         =   "EQUIPMENT"
   ClientHeight    =   6435
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   7545
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmEquipment.frx":0000
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   6435
   ScaleWidth      =   7545
   Begin VB.TextBox txtEquipment 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   12
         Charset         =   255
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00404040&
      Height          =   6375
      Left            =   0
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      Top             =   0
      Width           =   7455
   End
End
Attribute VB_Name = "frmEquipment"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub subResizeTextBox()
    txtEquipment.width = Me.width - 200
    txtEquipment.height = Me.height
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 9
    subWindowsPosition Me, "S"
    subResizeTextBox
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
    subWindowsPosition Me, "L"
    subResizeTextBox
    subLoadFontNoteInfo
    txtEquipment.FontName = gblzFontNoteName
    txtEquipment.FontSize = gbllFontNoteSize
End Sub
Private Sub Form_Resize()
    subResizeTextBox
End Sub
Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
    subResizeTextBox
End Sub

