VERSION 5.00
Begin VB.Form frmSplashScreen 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "City of Ages - About and History"
   ClientHeight    =   3720
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   15180
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmSplashScreen.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   Picture         =   "frmSplashScreen.frx":058A
   ScaleHeight     =   3720
   ScaleWidth      =   15180
   Begin VB.PictureBox Picture1 
      Height          =   3975
      Left            =   0
      Picture         =   "frmSplashScreen.frx":EA83
      ScaleHeight     =   3915
      ScaleMode       =   0  'User
      ScaleWidth      =   4485
      TabIndex        =   6
      Top             =   -600
      Visible         =   0   'False
      Width           =   4575
   End
   Begin VB.CommandButton cmdHelpGUIDesign 
      Caption         =   "GUI Designers"
      Height          =   375
      Left            =   12240
      TabIndex        =   5
      Top             =   2880
      Width           =   2895
   End
   Begin VB.CommandButton cmdFixCutOffWindows 
      Caption         =   "Safely Reset Forms"
      Height          =   375
      Left            =   10440
      TabIndex        =   4
      ToolTipText     =   "This will fix form-windows so they are no longer cut off. This is safe to do and will not hurt anything."
      Top             =   2880
      Width           =   1695
   End
   Begin VB.Timer Timer1 
      Interval        =   500
      Left            =   600
      Top             =   0
   End
   Begin VB.CommandButton cmdRepeatStoryLine 
      Caption         =   "Repeat Storyline"
      Height          =   375
      Left            =   8520
      TabIndex        =   2
      Top             =   2880
      Width           =   1695
   End
   Begin VB.TextBox txtAppPath 
      Height          =   315
      Left            =   0
      TabIndex        =   0
      ToolTipText     =   "Application path for your BMP files to customize your own graphics."
      Top             =   3360
      Width           =   15135
   End
   Begin VB.Label lblMsg2 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      Caption         =   "Happy Hunting!"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000080FF&
      Height          =   255
      Left            =   8520
      TabIndex        =   3
      Top             =   2640
      Width           =   3615
   End
   Begin VB.Label lblMsg1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      Caption         =   $"frmSplashScreen.frx":4E981
      ForeColor       =   &H000080FF&
      Height          =   2415
      Left            =   8640
      TabIndex        =   1
      Top             =   120
      Width           =   3375
   End
End
Attribute VB_Name = "frmSplashScreen"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gbllOMeLeft As Long
Dim gbllOMeTop As Long
Dim lgblShowPic As Long
Private Sub cmdFixCutOffWindows_Click()
On Error Resume Next
    MyDB.Execute "DELETE WindowsID FROM tblWindows;", dbFailOnError
End Sub

Private Sub cmdHelpGUIDesign_Click()
    frmHelpSpecialInterfaceCommands.Show
End Sub

Private Sub cmdRepeatStoryLine_Click()
On Error Resume Next
    MyDB.Execute "UPDATE tblReadToMe SET Played=0 WHERE Played=1;", dbFailOnError 'Not Played means they will hear it again
    MsgBox "Done!" & vbCrLf & "When you enter certain areas you will hear the Storyline Lore play once again, Enjoy!", vbOKOnly
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 18
    lgblShowPic = 0
    lgblScreenWidth = GetSystemMetrics(SM_CXSCREEN)
    lgblScreenHeight = GetSystemMetrics(SM_CYSCREEN)
End Sub

Private Sub Form_Load()
On Error Resume Next
    txtAppPath.Text = App.Path
End Sub

Private Sub Timer1_Timer()
    lgblShowPic = lgblShowPic + 1
    If lgblShowPic = 14 Then Picture1.Visible = True
    If lgblShowPic = 10 Then frmGarfieldeyes.Show
    If (gbllFormActivated = 18) Then 'A Protection so the other forms arnt running this code on event execute of other Timers on other forms
        If (Me.Left <> gbllOMeLeft And Me.Top <> gbllOMeTop) Then 'Keeps from over running this timer event
            gbllOMeLeft = Me.Left: gbllOMeTop = Me.Top
            subStickyAlignWindows Me.Name, mdiMain.Name
        End If
    End If
End Sub

