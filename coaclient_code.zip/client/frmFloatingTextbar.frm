VERSION 5.00
Begin VB.Form frmFloatingTextbar 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Floating Textbar"
   ClientHeight    =   720
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   10650
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   720
   ScaleWidth      =   10650
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox txtSendClientData 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   10455
   End
End
Attribute VB_Name = "frmFloatingTextbar"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub Form_KeyPress(KeyAscii As Integer)
    If (frmMain.Winsock1.State <> 7 And KeyAscii = 13) Then '7 = connected
        'Winsock1.SendData Chr$(KeyAscii) 'would send each code
        Call frmMain.mnuMainCD_Click
        frmFloatingTextbar.txtSendClientData.SetFocus
    End If
End Sub
Private Sub txtSendClientData_Click()
    gblbFreeToText = True
End Sub

Private Sub txtSendClientData_DblClick()
    frmFloatingTextbar!txtSendClientData.ToolTipText = "" 'user got the message obviously
    frmLargeMessageBox.Show
End Sub
Private Sub txtSendClientData_KeyPress(KeyAscii As Integer)
    Dim lCopyScroll As Long
    Dim bSpecialKey As Boolean
    Dim zSendClientData As String
    bSpecialKey = False
    'Debug.Print "KeyAscii=" & KeyAscii '50 is south 56 north
    
    gblbBringBackFirstGo = True
    If (KeyAscii = 27) Then
        gbllTerminalScrollBACKPointer = gbllTerminalScrollMAX
        frmFloatingTextbar.txtSendClientData.Text = ""
        frmMain.subRewriteLastBitToWindow
        gblbTerminalScrolling = False
    End If

    If (KeyAscii = 50 Or KeyAscii = 56) Then 'scroll dn and up
        If KeyAscii = 50 Then gbllBringBack = gbllBringBack + 1
        If KeyAscii = 56 Then gbllBringBack = gbllBringBack - 1
        If (gbllBringBack > lcstBringBackString) Then gbllBringBack = 1
        If (gbllBringBack < 1) Then gbllBringBack = lcstBringBackString
        zSendClientData = gblzBringBackString(gbllBringBack)
        frmFloatingTextbar.txtSendClientData.Text = zSendClientData
    End If
    
    If (gbllProfileKeyAscii = 13 Or gblbReturnSimulated Or frmMain.bReturnGetKeyState(GetKeyState(vbKeyReturn))) Then
        gbllProfileKeyAscii = 0
        
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then
            zSendClientData = MyCStr(txtSendClientData.Text)
            
            If (Len(zSendClientData) > 0) Then
                frmFloatingTextbar.txtSendClientData.Text = ""
                gbllBringBack = gbllBringBack + 1
                If (gbllBringBack > lcstBringBackString) Then
                    gbllBringBack = lcstBringBackString ' the send data textbox and the array of strings scrolls up - we stay at the bottom where the new info goes
                    For lCopyScroll = 1 To lcstBringBackString - 1
                        gblzBringBackString(lCopyScroll) = gblzBringBackString(lCopyScroll + 1)
                    Next lCopyScroll
                    gblzBringBackString(lcstBringBackString) = ""
                End If
                'If (gbllBringBack > 1) Then 'at the end of array we do not repeat previous commands of anything sent
                '    If (gblzBringBackString(gbllBringBack) <> zSendClientData) Then gblzBringBackString(gbllBringBack) = zSendClientData
                'Else
                gblzBringBackString(gbllBringBack) = zSendClientData
                gbllBringBack = gbllBringBack + 1
                If (gbllBringBack > lcstBringBackString) Then gbllBringBack = 1
                'End If
                gblbFreeToText = False
                
                If (UCase(zSendClientData) = "REDO") Then 'a player name was entered properly but there was a redo so start again
                    frmMain.Caption = "City of Ages Client"
                    bPlayerNameRequired = True
                End If
                
                If (bPlayerNameRequired) Then 'BEGIN LOADING THE CHARACTER PROFILE Scripts and everything else, this is the first thing that happens when a user types in their players name
                    subLoadPlayerDefaults zSendClientData 'Load the Player Name and scripts and everything !
                    frmMain.Winsock1.SendData zSendClientData & vbCrLf
                Else 'consult the triggering system
                    frmMain.bTriedTriggers = bTriggers(zSendClientData)
                    frmMain.bTriedEvents = bEvents(zSendClientData)
                    If (frmMain.bTriedTriggers Or frmMain.bTriedEvents) Then 'found a trigger?
                        bSpecialKey = True 'Yes
                    Else
                        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zSendClientData & vbCrLf
                    End If
                End If
            End If
        End If
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyDecimal))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyDecimal & vbCrLf
    End If

    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyDivide))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyDivide & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyMultiply))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyMultiply & vbCrLf
    End If

    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad0))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad0 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeySubtract))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeySubtract & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyAdd))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyAdd & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad1))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad1 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad2))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad2 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad3))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad3 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad4))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad4 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad5))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad5 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad6))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad6 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad7))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad7 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad8))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad8 & vbCrLf
    End If
    
    If (frmMain.bReturnGetKeyState(GetKeyState(vbKeyNumpad9))) Then
        bSpecialKey = True
        If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData gblzKeyNumpad9 & vbCrLf
    End If
    
    If (bSpecialKey) Then KeyAscii = 0

    If (Not gblbFreeToText And Len(txtSendClientData.Text) <> 0 And frmFloatingTextbar.txtSendClientData.SelLength = 0) Then frmFloatingTextbar.txtSendClientData.SelStart = Len(txtSendClientData.Text) + 1
    'If (txtSendClientData.SelLength >= Len(txtSendClientData.Text)) Then gblbFreeToText = False
End Sub

