STORY LINE
===========================================================================================
A MUD set in a dungeon environment, with a twist. A world
of an ancient race disappeared leaving behind technology
that existed over a millennia ago. All their mystical
technologies were forgotten or lost across a hundred
worlds. Species across the universe come to seek new
technologies on these worlds and clues to the disappearance
of the ancients. Venture forth and meet many travelers
between your quests and rediscover the ancients and gain
their mystical powers embedded in their technologies.

SPECIAL FEATURES
===========================================================================================
Immersive commands: Map - Scan - Look - Peek at everything plus 100s of other commands
Fishing! Golf! Secret locations! Stargates! Starships! Secret planets to visit!
Forge items to train and build your character with Crowns of Glory
If you die, you do not corpse your equipment!
Magic Words and MARK and RECALL to explore the realm
Ten quest engines: Quest Masters, Guide Masters, 
Group Quests - Mob Raids, Armagaddon, Bounty Hunts, Starship phaser quests!
Detailed skills when battling creatures of the realm
Built in MAP command that follows you around - no mapping required!
IAS, Blocking, Martial arts, and more!
We added SLAY so low levels with high SLAY items can kill higher level mobs
Tonns of unique and updated skills on items, to learn from a teacher, and hidden ones to find!
Magic Find to get items from creatures of the realm
Full Item randomization! Stats, Rares, Uniques, Treasures!
Great spells on items!
Pilot your own Warp Drive starship! Use your starship as your house as well!
Admins can build players Player Houses for even more room!
Find Gold, and gamble it: Horse Racing! Slots Gambling! A perfect Roulette board! A very real Stock market!
Risk in Space with colonizations.
Factions so players can take over areas together, another sort of Risk type game.
Glory to forge your favorite items! The Game has 20 different ways to find glory, or be rewarded glory for just playing!
This MUD also has a Report system called PAGES, and you can see top players and so on.
Chests to open!
Admins can build mobs, mobs with skills and spells, traps, water areas, more rooms to explore!

PORTS
===========================================================================================
CoA uses port 23 the default telnet port but it also has one dynamic port you can change!
This dynamic port was originally created for those in the military that have telnet access
but on a different and secured port, also if you have a server with a company they might assign you
a port and it won't be their main port 23 which they probably use for internal reasons.
If you change this default port keep in mind to relaunch CoA.

CODERS
===========================================================================================
You want to start in subProcessUserLine procedure, this is where commands sent by the
players is matched up.

Having issues installing VB6 sr 6 to Windows 10? There is help!!
 http://blog.danbrust.net/2015/09/14/installing-visual-basic-studio-6-on-windows-10/#.WZYX4FH5hpg
 https://www.youtube.com/watch?v=LXvd8IRw_ZI
 this proves you didn't make the wrong choice many still love and use VB6 its a great language!!

SOURCE CODE DISCLAIMER
===========================================================================================
After the year 2035 You can use this code as opensource for your own personal or commercial
requirements. Hopefully I got my $6000 in hardware that burnt out coding and running this MUD,
before you make yours. :)

For now you may distribute the coaclient.exe and installation EXE so your players can play,
keep the source code to yourself, however. You may sell items and housing in the game as you wish,
to generate some money for yourself, meanwhile.

Enjoy my work! Try not to remove my name and pictures of me from anything.

You can get ahold of me directly at formsmatter@gmail.com I do not mind helping individials so
do not be worried about contacting me even to, say 'hi', I am all about the player base.


