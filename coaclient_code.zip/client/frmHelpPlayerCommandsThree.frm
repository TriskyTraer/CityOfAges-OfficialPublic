VERSION 5.00
Begin VB.Form frmHelpPlayerCommandsThree 
   BackColor       =   &H00C0E0FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "HELP - Basic Player Commands"
   ClientHeight    =   13545
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   12270
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmHelpPlayerCommandsThree.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   13545
   ScaleWidth      =   12270
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   18
      Left            =   1200
      TabIndex        =   37
      Text            =   "List spells and skills at a teacher."
      Top             =   7440
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   16
      Left            =   120
      TabIndex        =   36
      Text            =   "TEACHER"
      Top             =   7440
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   15
      Left            =   120
      TabIndex        =   35
      Text            =   "HOUSE"
      Top             =   3960
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   17
      Left            =   1200
      TabIndex        =   34
      Text            =   "After an immortal runs IMMO RC, and IMMO HOUSE <playername> the player has a teleport to house command."
      Top             =   3960
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   14
      Left            =   120
      TabIndex        =   33
      Text            =   "MERCH"
      Top             =   4440
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   16
      Left            =   1200
      TabIndex        =   32
      Text            =   "MERCH or LIST to show items at a merchant, BUY and SELL to complete a transation."
      Top             =   4440
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   13
      Left            =   120
      TabIndex        =   31
      Text            =   "HORSES"
      Top             =   9600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   15
      Left            =   1200
      TabIndex        =   30
      Text            =   "Bet on the HORSES !"
      Top             =   9600
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   12
      Left            =   120
      TabIndex        =   29
      Text            =   "ROULETTE"
      Top             =   9120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   14
      Left            =   1200
      TabIndex        =   28
      Text            =   "Players all have a true to life roulette board that follows them around."
      Top             =   9120
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   330
      Index           =   13
      Left            =   1200
      TabIndex        =   27
      Text            =   "GAMBLING COMMANDS"
      Top             =   8760
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   12
      Left            =   1200
      TabIndex        =   26
      Text            =   "IMMO HINT creates a textfile that is a 'report' of where all magic words and stargate chevron runes are used."
      Top             =   6960
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   11
      Left            =   120
      TabIndex        =   25
      Text            =   $"frmHelpPlayerCommandsThree.frx":058A
      Top             =   6960
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   10
      Left            =   120
      TabIndex        =   24
      Text            =   "ARMA"
      Top             =   6480
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   11
      Left            =   1200
      TabIndex        =   23
      Text            =   "ARMAGEDDON command will give you details about this quest including how much time players have left."
      Top             =   6480
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   10
      Left            =   1200
      TabIndex        =   22
      Text            =   "QUEST is a channel as well and if you type QUEST GO at the Oracle ne of 0,0,0 you recieve a personal quest."
      Top             =   6000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   7
      Left            =   120
      TabIndex        =   21
      Text            =   "QUEST"
      Top             =   6000
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   330
      Index           =   7
      Left            =   1200
      TabIndex        =   20
      Text            =   "QUEST COMMANDS"
      Top             =   5160
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   9
      Left            =   1200
      TabIndex        =   19
      Text            =   "Spends all your move points and finds the location of the mob you seek, mages is more potent as a spell."
      Top             =   5520
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   9
      Left            =   120
      TabIndex        =   18
      Text            =   "LOCATION"
      Top             =   5520
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   8
      Left            =   1200
      TabIndex        =   17
      Text            =   "INDUCT <playername> [1 to 18] will induct a player into your clan. An immortal using this command can set any."
      Top             =   3480
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   8
      Left            =   120
      TabIndex        =   16
      Text            =   "INDUCT"
      Top             =   3480
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   6
      Left            =   1200
      TabIndex        =   15
      Text            =   "FOLLOW <playername> then the other player GROUP <playername> and DISBAND GROUP eventually."
      Top             =   3000
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   6
      Left            =   120
      TabIndex        =   14
      Text            =   "FOLLOW"
      Top             =   3000
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   5
      Left            =   120
      TabIndex        =   13
      Text            =   "STANCE"
      Top             =   2520
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   5
      Left            =   1200
      TabIndex        =   12
      Text            =   "STANCE [A/D[N] Aggressive or Defensive or Normal stance, aggressive reduces AC considerably."
      Top             =   2520
      Width           =   11000
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   4
      Left            =   1200
      TabIndex        =   11
      Text            =   "MISSILE allows the player to lock onto a target and fire their weapons. Goil in Shadow Castle sells them."
      Top             =   2040
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   4
      Left            =   120
      TabIndex        =   10
      Text            =   "MISSILE"
      Top             =   2040
      Width           =   975
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   3
      Left            =   120
      TabIndex        =   9
      Text            =   "ABSORB"
      Top             =   1560
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   3
      Left            =   1200
      TabIndex        =   8
      Text            =   "Ankh's are utterly rare, they are like MERGE cards but can rare on any item anytime--it will be spent once used."
      Top             =   1560
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   2
      Left            =   120
      TabIndex        =   7
      Text            =   "MERGE"
      Top             =   1080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   2
      Left            =   1200
      TabIndex        =   6
      Text            =   "There are cards hidden around the realm, you can MERGE THREE TWO for example."
      Top             =   1080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      Height          =   435
      Index           =   27
      Left            =   120
      TabIndex        =   5
      Text            =   "SAY (word)"
      Top             =   13080
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   27
      Left            =   1200
      TabIndex        =   4
      Text            =   "SAY <magicword> uses the SAY channel to activate a magical word to a new area."
      Top             =   13080
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   0
      Left            =   120
      TabIndex        =   3
      Text            =   "CMDS"
      Top             =   120
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   1
      Left            =   1200
      TabIndex        =   2
      Text            =   "At the time you find yourself battling something you predict you cannot win use this command to run away."
      Top             =   600
      Width           =   11000
   End
   Begin VB.TextBox txtCommand 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   435
      Index           =   1
      Left            =   120
      TabIndex        =   1
      Text            =   "FLEE"
      Top             =   600
      Width           =   975
   End
   Begin VB.TextBox txtCommandDesc 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   11.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   450
      Index           =   0
      Left            =   1200
      TabIndex        =   0
      Text            =   "EXAMPLES, Directions refer to  [N,S,E,W,NE,NW,SE,SW,U,D]"
      Top             =   120
      Width           =   11000
   End
End
Attribute VB_Name = "frmHelpPlayerCommandsThree"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
