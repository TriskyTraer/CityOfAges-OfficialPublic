VERSION 5.00
Begin VB.Form frmPerceptionMachineEditor 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "~ PERCEPTION MACHINE EDITOR ~"
   ClientHeight    =   9450
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   13815
   Icon            =   "frmPerceptionMachineEditor.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   9450
   ScaleWidth      =   13815
   Begin VB.PictureBox picDisplay 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   9255
      Left            =   9240
      ScaleHeight     =   9225
      ScaleWidth      =   4425
      TabIndex        =   14
      Top             =   120
      Width           =   4455
   End
   Begin VB.CommandButton cmdNew 
      Appearance      =   0  'Flat
      Caption         =   "&New"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   9120
      Width           =   975
   End
   Begin VB.CommandButton cmdLoad 
      Appearance      =   0  'Flat
      Caption         =   "&Load"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   7
      Top             =   9120
      Width           =   975
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5520
      TabIndex        =   8
      Top             =   9120
      Width           =   975
   End
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Caption         =   "&Delete"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   8280
      Picture         =   "frmPerceptionMachineEditor.frx":038A
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   9120
      Width           =   975
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      ForeColor       =   &H80000008&
      Height          =   1575
      Left            =   120
      ScaleHeight     =   1545
      ScaleWidth      =   9105
      TabIndex        =   11
      Top             =   6960
      Width           =   9135
      Begin VB.TextBox txtBackgroundColor 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   2
         TabIndex        =   0
         ToolTipText     =   "0=gray normal 1=grn 2=red 3=purpy 4=cyan 5=oj 6=yello 7=blue"
         Top             =   120
         Width           =   465
      End
      Begin VB.TextBox txtType 
         Alignment       =   2  'Center
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   12
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   8520
         MaxLength       =   2
         TabIndex        =   3
         ToolTipText     =   "-1=off 0=title form 1=time top 2=weather right 3++=frames"
         Top             =   120
         Width           =   465
      End
      Begin VB.TextBox txtMustHaveWhenMatchingInWords 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   125
         TabIndex        =   5
         ToolTipText     =   "Must Have at least one of these words matching in the sentence."
         Top             =   1080
         Width           =   8895
      End
      Begin VB.TextBox txtWordMatch 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   600
         MaxLength       =   50
         TabIndex        =   1
         ToolTipText     =   "This is the single search-line more than 3 characters long to search and compare server text against."
         Top             =   120
         Width           =   5295
      End
      Begin VB.TextBox txtIgnoreWhenMatchingInWords 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   255
         TabIndex        =   4
         ToolTipText     =   "All words listed here cannot be in the same sentence as the search word."
         Top             =   600
         Width           =   8895
      End
      Begin VB.TextBox txtPMFilename 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   5880
         MaxLength       =   222
         TabIndex        =   2
         ToolTipText     =   "filename with extension only ie. garroc.bmp"
         Top             =   120
         Width           =   2625
      End
      Begin VB.Label lblPerceptionMachineID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   12
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin VB.ListBox lstTriggers 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   9
         Charset         =   255
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6690
      Left            =   120
      TabIndex        =   10
      Top             =   120
      Width           =   9135
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "This allows a player to associate pictures with text scans."
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   375
      Left            =   120
      TabIndex        =   13
      Top             =   8640
      Width           =   9135
   End
End
Attribute VB_Name = "frmPerceptionMachineEditor"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub Form_Activate()
On Error Resume Next
    gbllFormActivated = 97
    txtWordMatch.SetFocus
End Sub
Private Sub Form_Click()
    txtWordMatch.SetFocus
End Sub
Private Sub Form_Load()
    subLoadAllTriggers
End Sub
Private Sub subLoadAllTriggers()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    lstTriggers.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT PerceptionMachineID, CharacterNameID, WordMatch, IgnoreWhenMatchingInWords, MustHaveWhenMatchingInWords FROM tblPerceptionMachine ORDER BY WordMatch;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        Do While (Not rsSetUp.EOF)
            lstTriggers.AddItem zForceSize(MyCStr(rsSetUp!WordMatch), 33, " ", "A") & "|" & MyCStr(rsSetUp!MustHaveWhenMatchingInWords)
            lstTriggers.ItemData(lstTriggers.ListCount - 1) = rsSetUp!PerceptionMachineID
            rsSetUp.MoveNext
        Loop
    End If
    Set rsSetUp = Nothing
    Exit Sub
Err_Check:
    basPrintMessage64 "subLoadAllTriggers," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subSaveTrigger()
On Error GoTo Err_Check
    Dim zCharacterName As String
    Dim lPerceptionMachineID As Long
    Dim lBackgroundColor As Long
    Dim zWordMatch As String
    Dim zIgnoreWhenMatchingInWords As String
    Dim zPMFilename As String
    Dim zMustHaveWhenMatchingInWords As String
    Dim rsData As Recordset
    Dim lType As Long
    
    lBackgroundColor = MyCLng(txtBackgroundColor.Text)
    lPerceptionMachineID = MyCLng(lblPerceptionMachineID.Caption)
    zWordMatch = MyCStr(txtWordMatch.Text)
    zIgnoreWhenMatchingInWords = MyCStr(txtIgnoreWhenMatchingInWords.Text)
    zPMFilename = MyCStr(txtPMFilename.Text)
    zMustHaveWhenMatchingInWords = MyCStr(txtMustHaveWhenMatchingInWords.Text)
    lType = MyCLng(MyCStr(txtType.Text))
    Set rsData = MyDB.OpenRecordset("SELECT BackgroundColor, PerceptionMachineID, CharacterNameID, Type, WordMatch, MustHaveWhenMatchingInWords, IgnoreWhenMatchingInWords, PMFilename FROM tblPerceptionMachine WHERE (PerceptionMachineID=" & lPerceptionMachineID & ");", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!BackgroundColor = lBackgroundColor
        rsData!Type = lType
        rsData!WordMatch = zWordMatch
        rsData!MustHaveWhenMatchingInWords = zMustHaveWhenMatchingInWords
        rsData!IgnoreWhenMatchingInWords = zIgnoreWhenMatchingInWords
        rsData!PMFilename = zPMFilename
        rsData.Update
    Else
        rsData.AddNew
        rsData!CharacterNameID = 0 'gbllCharacterNameID
        rsData!BackgroundColor = lBackgroundColor
        rsData!Type = lType
        rsData!WordMatch = zWordMatch
        rsData!MustHaveWhenMatchingInWords = zMustHaveWhenMatchingInWords
        rsData!IgnoreWhenMatchingInWords = zIgnoreWhenMatchingInWords
        rsData!PMFilename = zPMFilename
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    basPrintMessage64 "subSaveTrigger," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub cmdDelete_Click()
'tblPerceptionMachine   PerceptionMachineID PlayerID CharacterNameID WordMatch PMFilename Type IgnoreWhenMatchingInWords MustHaveWhenMatchingInWords
    MyDB.Execute "DELETE * FROM tblPerceptionMachine WHERE PerceptionMachineID=" & MyCLng(lblPerceptionMachineID.Caption) & ";", dbFailOnError
    subNew
End Sub
Private Sub cmdLoad_Click()
    subLoadAllTriggers
End Sub
Private Sub cmdNew_Click()
    subNew
End Sub
Private Sub cmdSave_Click()
    subSaveTrigger
    subNew
End Sub
Private Sub subNew()
On Error GoTo Err_Check
    picDisplay.Picture = Nothing
    txtBackgroundColor.Text = ""
    txtWordMatch.Text = ""
    txtIgnoreWhenMatchingInWords.Text = ""
    lblPerceptionMachineID.Caption = ""
    txtPMFilename.Text = ""
    txtMustHaveWhenMatchingInWords.Text = ""
    txtType.Text = ""
    subLoadAllTriggers
    Exit Sub
Err_Check:
    Debug.Print "subNew:" & vbCrLf & Err.Number & " " & vbCrLf & Err.Description
End Sub
Private Sub lstTriggers_Click()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim zFilename As String
    Set rsSetUp = MyDB.OpenRecordset("SELECT BackgroundColor, PerceptionMachineID, PlayerID, CharacterNameID, WordMatch, PMFilename, Type, IgnoreWhenMatchingInWords, MustHaveWhenMatchingInWords FROM tblPerceptionMachine WHERE PerceptionMachineID=" & MyCLng(lstTriggers.ItemData(lstTriggers.ListIndex)) & ";", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        txtBackgroundColor.Text = MyCLng(rsSetUp!BackgroundColor)
        lblPerceptionMachineID.Caption = MyCLng(rsSetUp!PerceptionMachineID)
        txtWordMatch.Text = MyCStr(rsSetUp!WordMatch)
        txtIgnoreWhenMatchingInWords.Text = UCase(MyCStr(rsSetUp!IgnoreWhenMatchingInWords))
        txtPMFilename.Text = MyCStr(rsSetUp!PMFilename)
        txtMustHaveWhenMatchingInWords.Text = UCase(MyCStr(rsSetUp!MustHaveWhenMatchingInWords))
        txtType.Text = MyCStr(rsSetUp!Type)
        picDisplay.Picture = Nothing
        zFilename = App.Path & "\pictures\" & txtPMFilename.Text
        If (bFileExists(zFilename)) Then
            picDisplay.Picture = LoadPicture(zFilename)
        End If
    Else
        subNew
    End If
    Set rsSetUp = Nothing
    txtWordMatch.SetFocus
    Exit Sub
Err_Check:
    Debug.Print "lstTriggers_Click:" & vbCrLf & Err.Number & " " & vbCrLf & Err.Description
End Sub

Private Sub picEvents_Click()
    txtBackgroundColor.SetFocus
End Sub
Private Sub txtBackgroundColor_LostFocus()
    txtBackgroundColor.Text = MyCLng(Trim(txtBackgroundColor.Text))
End Sub
Private Sub txtIgnoreWhenMatchingInWords_LostFocus()
    txtIgnoreWhenMatchingInWords.Text = UCase(MyCStr(txtIgnoreWhenMatchingInWords.Text))
End Sub

Private Sub txtMustHaveWhenMatchingInWords_LostFocus()
    txtMustHaveWhenMatchingInWords.Text = UCase(MyCStr(txtMustHaveWhenMatchingInWords.Text))
End Sub
Private Sub txtPMFilename_LostFocus()
    txtPMFilename.Text = MyCStr(txtPMFilename.Text)
    If (Len(txtPMFilename.Text) > 0) Then
        If (InStr(txtPMFilename.Text, ".") = 0) Then
            txtPMFilename.Text = txtPMFilename.Text & ".bmp"
        End If
    End If
End Sub
Private Sub txtType_LostFocus()
    txtType.Text = MyCStr(txtType.Text)
    If (Len(txtType.Text) = 0) Then
        If (Len(txtPMFilename.Text) > 0) Then
            txtType.Text = "3"
        End If
    End If
End Sub
Private Sub txtWordMatch_LostFocus()
On Error Resume Next
    txtWordMatch.Text = UCase(MyCStr(txtWordMatch.Text))
End Sub
