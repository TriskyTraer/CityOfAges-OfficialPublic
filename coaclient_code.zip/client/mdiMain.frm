VERSION 5.00
Begin VB.MDIForm mdiMain 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   Caption         =   "MAIN - City of Ages Telnet Client"
   ClientHeight    =   10755
   ClientLeft      =   120
   ClientTop       =   135
   ClientWidth     =   17985
   Icon            =   "mdiMain.frx":0000
   LinkTopic       =   "MDIForm1"
   Picture         =   "mdiMain.frx":058A
   WindowState     =   2  'Maximized
   Begin VB.Timer tmrButtonBnk 
      Enabled         =   0   'False
      Interval        =   333
      Left            =   480
      Top             =   1320
   End
   Begin VB.PictureBox picMain 
      Align           =   2  'Align Bottom
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   1035
      Left            =   0
      ScaleHeight     =   1035
      ScaleWidth      =   17985
      TabIndex        =   1
      Top             =   9720
      Width           =   17985
      Begin VB.PictureBox picTools 
         Appearance      =   0  'Flat
         BackColor       =   &H00000000&
         ForeColor       =   &H80000008&
         Height          =   975
         Left            =   11760
         ScaleHeight     =   945
         ScaleWidth      =   5985
         TabIndex        =   27
         ToolTipText     =   "CONFIG PROMPT +/-"
         Top             =   0
         Width           =   6015
         Begin VB.TextBox txtChatCapture 
            Appearance      =   0  'Flat
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   600
            MultiLine       =   -1  'True
            ScrollBars      =   2  'Vertical
            TabIndex        =   29
            Top             =   120
            Width           =   5295
         End
         Begin VB.CommandButton cmdChatCaptureClear 
            Appearance      =   0  'Flat
            BackColor       =   &H0080C0FF&
            Caption         =   "Clr"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   735
            Left            =   120
            MaskColor       =   &H0080C0FF&
            Style           =   1  'Graphical
            TabIndex        =   28
            ToolTipText     =   "Game messages get caught and displayed to the right."
            Top             =   120
            Width           =   375
         End
      End
      Begin VB.PictureBox picStatsBox 
         Appearance      =   0  'Flat
         BackColor       =   &H00000000&
         ForeColor       =   &H80000008&
         Height          =   975
         Left            =   9720
         ScaleHeight     =   945
         ScaleWidth      =   1305
         TabIndex        =   21
         ToolTipText     =   "CONFIG PROMPT +/-"
         Top             =   0
         Visible         =   0   'False
         Width           =   1335
         Begin VB.TextBox txtStatsBar 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H00000080&
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Serif"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H0000C0C0&
            Height          =   165
            Index           =   3
            Left            =   0
            Locked          =   -1  'True
            TabIndex        =   25
            Text            =   "soul"
            Top             =   580
            Width           =   1335
         End
         Begin VB.TextBox txtStatsBar 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H00800080&
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Serif"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H0000FFFF&
            Height          =   165
            Index           =   1
            Left            =   0
            Locked          =   -1  'True
            TabIndex        =   23
            Text            =   "mana"
            Top             =   200
            Width           =   1335
         End
         Begin VB.TextBox txtStatsBar 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H00008000&
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Serif"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H0000C0C0&
            Height          =   165
            Index           =   4
            Left            =   0
            Locked          =   -1  'True
            TabIndex        =   26
            Text            =   "move"
            Top             =   780
            Width           =   1335
         End
         Begin VB.TextBox txtStatsBar 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H000080FF&
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Serif"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H0080FFFF&
            Height          =   165
            Index           =   0
            Left            =   0
            Locked          =   -1  'True
            TabIndex        =   24
            Text            =   "hitpoints"
            Top             =   0
            Width           =   1335
         End
         Begin VB.TextBox txtStatsBar 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C000&
            BorderStyle     =   0  'None
            BeginProperty Font 
               Name            =   "MS Serif"
               Size            =   6.75
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            ForeColor       =   &H0080FFFF&
            Height          =   165
            Index           =   2
            Left            =   0
            Locked          =   -1  'True
            TabIndex        =   22
            Text            =   "ess"
            Top             =   390
            Width           =   1335
         End
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   19
         Left            =   7800
         Style           =   1  'Graphical
         TabIndex        =   19
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   18
         Left            =   8760
         Style           =   1  'Graphical
         TabIndex        =   20
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   17
         Left            =   6840
         Style           =   1  'Graphical
         TabIndex        =   18
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   16
         Left            =   5880
         Style           =   1  'Graphical
         TabIndex        =   17
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   15
         Left            =   4920
         Style           =   1  'Graphical
         TabIndex        =   16
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   14
         Left            =   3960
         Style           =   1  'Graphical
         TabIndex        =   15
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   13
         Left            =   3000
         Style           =   1  'Graphical
         TabIndex        =   14
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   12
         Left            =   2040
         Style           =   1  'Graphical
         TabIndex        =   13
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   11
         Left            =   1080
         Style           =   1  'Graphical
         TabIndex        =   12
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   10
         Left            =   120
         Style           =   1  'Graphical
         TabIndex        =   11
         Top             =   480
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   9
         Left            =   8760
         Style           =   1  'Graphical
         TabIndex        =   10
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   8
         Left            =   7800
         Style           =   1  'Graphical
         TabIndex        =   9
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   7
         Left            =   6840
         Style           =   1  'Graphical
         TabIndex        =   8
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   6
         Left            =   5880
         Style           =   1  'Graphical
         TabIndex        =   7
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   5
         Left            =   4920
         Style           =   1  'Graphical
         TabIndex        =   6
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   4
         Left            =   3960
         Style           =   1  'Graphical
         TabIndex        =   5
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   3
         Left            =   3000
         Style           =   1  'Graphical
         TabIndex        =   4
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   2
         Left            =   2040
         Style           =   1  'Graphical
         TabIndex        =   3
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   1
         Left            =   1080
         Style           =   1  'Graphical
         TabIndex        =   2
         Top             =   0
         Width           =   855
      End
      Begin VB.CommandButton cmdButton1 
         Appearance      =   0  'Flat
         BackColor       =   &H00FFC0C0&
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   495
         Index           =   0
         Left            =   120
         Style           =   1  'Graphical
         TabIndex        =   0
         Top             =   0
         Width           =   855
      End
      Begin VB.PictureBox picSettings 
         Height          =   975
         Left            =   11160
         ScaleHeight     =   915
         ScaleWidth      =   435
         TabIndex        =   30
         Top             =   0
         Width           =   495
         Begin VB.CheckBox chkLineFeed3 
            Appearance      =   0  'Flat
            BackColor       =   &H00FFFF00&
            Caption         =   "lf"
            ForeColor       =   &H80000008&
            Height          =   255
            Left            =   0
            TabIndex        =   32
            TabStop         =   0   'False
            ToolTipText     =   "Line Feed more return codes before your end of line Character Prompt"
            Top             =   360
            Width           =   495
         End
         Begin VB.CommandButton cmdReturnCode 
            Appearance      =   0  'Flat
            Caption         =   "&ret"
            Height          =   375
            Left            =   0
            TabIndex        =   33
            ToolTipText     =   "Send and enter return key code to continue reading on..."
            Top             =   0
            Width           =   495
         End
         Begin VB.CommandButton cmdMASTERLock 
            Appearance      =   0  'Flat
            BackColor       =   &H00008000&
            Caption         =   "MCE"
            BeginProperty Font 
               Name            =   "Arial"
               Size            =   8.25
               Charset         =   0
               Weight          =   400
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Left            =   0
            MaskColor       =   &H0080C0FF&
            Style           =   1  'Graphical
            TabIndex        =   31
            ToolTipText     =   "QUICK MASTER OVERRIDE for Menu->Creator->Events toggle switch"
            Top             =   600
            Width           =   495
         End
      End
   End
   Begin VB.Timer tmrAreaWhere 
      Interval        =   1000
      Left            =   1080
      Top             =   1320
   End
   Begin VB.Menu mnuMDIPlay 
      Caption         =   "Play"
      Begin VB.Menu mnuMDIConnect 
         Caption         =   "Connect"
      End
      Begin VB.Menu mnuAnimation 
         Caption         =   "Animation"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuMDISound 
         Caption         =   "Sound"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuMDISoundStoryLine 
         Caption         =   "Sound - Story Line"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuMDISoundBackground 
         Caption         =   "Sound - Background"
         Checked         =   -1  'True
      End
   End
   Begin VB.Menu mnuMDIScreenUtilities 
      Caption         =   "Screen Utilities"
      Begin VB.Menu mnuMDIAreaGraphicsViewer 
         Caption         =   "Graphic Viewers"
      End
      Begin VB.Menu mnuPMGraphicsEditor 
         Caption         =   "Graphics Editor"
      End
      Begin VB.Menu mnuShowFileNames 
         Caption         =   "Show File Names"
      End
      Begin VB.Menu mnuMDIScrollBack 
         Caption         =   "Scroll Back (ESC cancels, use arrow keys not numlock)"
         Shortcut        =   %{BKSP}
      End
      Begin VB.Menu mnuMDILargeMessageBox 
         Caption         =   "Large Message Box"
         Shortcut        =   ^L
      End
      Begin VB.Menu mnuMemos 
         Caption         =   "Notes and Memos"
         Shortcut        =   ^N
      End
      Begin VB.Menu mnuMDIMapper 
         Caption         =   "Mapper"
         Shortcut        =   ^M
      End
      Begin VB.Menu mnuMDIMapperAutoFocus 
         Caption         =   "Mapper Auto Focus"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuMDIMapperLoggingActive 
         Caption         =   "Mapper Logging Active..."
      End
      Begin VB.Menu mnuMDIMapperTimerActive 
         Caption         =   "Mapper Timer Active"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuMDIChangeFont 
         Caption         =   "Change Font"
      End
      Begin VB.Menu mnuFontTweeker 
         Caption         =   "Font Tweeker (aka daFonzie)"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuRecordTextfileEventLine 
         Caption         =   "Record Textfile Event Lines"
         Checked         =   -1  'True
      End
   End
   Begin VB.Menu mnuMDICreator 
      Caption         =   "Creator"
      Begin VB.Menu mnuMDICharacterProfiles 
         Caption         =   "Character Profiles"
         Shortcut        =   ^P
      End
      Begin VB.Menu mnuMDIEvents 
         Caption         =   "Events and Background sound"
         Shortcut        =   ^E
      End
      Begin VB.Menu mnuEventsToggle 
         Caption         =   "Events Toggle"
         Checked         =   -1  'True
      End
      Begin VB.Menu mnuScaling 
         Caption         =   "Aliases and Macros"
         Shortcut        =   ^S
      End
      Begin VB.Menu mnuMDITriggers 
         Caption         =   "Triggers and Speedwalk"
         Shortcut        =   ^T
      End
      Begin VB.Menu mnuMDIButtons 
         Caption         =   "Buttons"
         Shortcut        =   ^B
      End
      Begin VB.Menu mnuEditVoiceLocationTriggers 
         Caption         =   "Edit Voice Location Triggers"
      End
   End
   Begin VB.Menu mnuTimers 
      Caption         =   "Timers"
      Begin VB.Menu mnuMDITickerA 
         Caption         =   "Ticker 2s sends"
         Shortcut        =   ^{F1}
      End
      Begin VB.Menu mnuMDITickerB 
         Caption         =   "Ticker 5s sends"
         Shortcut        =   ^{F2}
      End
      Begin VB.Menu mnuMDITickerC 
         Caption         =   "Ticker 7s sends"
         Shortcut        =   ^{F3}
      End
      Begin VB.Menu mnuMDITickerD 
         Caption         =   "Ticker 10s sends"
         Shortcut        =   ^{F4}
      End
      Begin VB.Menu mnuMDITickerE 
         Caption         =   "Ticker 14s sends"
         Shortcut        =   ^{F5}
      End
      Begin VB.Menu mnuMDITickerF 
         Caption         =   "Ticker 19s sends"
         Shortcut        =   ^{F6}
      End
   End
   Begin VB.Menu mnuTimerDynamic1 
      Caption         =   "Timer Dynamic1"
   End
   Begin VB.Menu mnuTimerDynamic2 
      Caption         =   "Timer Dynamic2"
   End
   Begin VB.Menu mnuTimerDynamic3 
      Caption         =   "Timer Dynamic3"
   End
   Begin VB.Menu mnuMDITools 
      Caption         =   "Tools"
      Begin VB.Menu mnuNumlock 
         Caption         =   "Speed Numlock"
      End
      Begin VB.Menu mnuJoystickPackman 
         Caption         =   "Joystick Packmon"
      End
      Begin VB.Menu mnuMDIChangePortAddress 
         Caption         =   "Charnge Port Address"
      End
      Begin VB.Menu mnuBlackSheet 
         Caption         =   "Black Sheet"
      End
      Begin VB.Menu mnuRunInstance 
         Caption         =   "Run an Additional Instance of CoA Client"
      End
   End
   Begin VB.Menu mnuInstructions 
      Caption         =   "Instructions"
      Begin VB.Menu mnuHowTo 
         Caption         =   "GAME - Tips when Playing"
      End
      Begin VB.Menu mnuMDIPlayerCommands 
         Caption         =   "Player Commands"
      End
      Begin VB.Menu mnuHelpPlayerCommandsToo 
         Caption         =   "Player Commands - more"
      End
      Begin VB.Menu mnuPlayerCommandsThree 
         Caption         =   "Player Commands - even more"
      End
      Begin VB.Menu mnuMDIHelpAdminSkillsToo 
         Caption         =   "Admin Skill Commands"
      End
      Begin VB.Menu mnuMDIAdminBldCmds 
         Caption         =   "Give Yourself Admin Building Commands"
      End
      Begin VB.Menu mnuHelpAdminBuildAreas 
         Caption         =   "Admin Build Areas and Door Commands"
      End
      Begin VB.Menu mnuHelpAdminBuildAreasToo 
         Caption         =   "Admin Build Areas and Door Commands - more"
      End
      Begin VB.Menu mnuHelpAdminBuildMob 
         Caption         =   "Admin Mob Build Commands"
      End
      Begin VB.Menu mnuHelpAdminBuildObject 
         Caption         =   "Admin Object Build Commands"
      End
   End
   Begin VB.Menu mnuMDIHelp 
      Caption         =   "Help"
      Begin VB.Menu mnuHelpPortForward 
         Caption         =   "How To Port Forward"
      End
      Begin VB.Menu mnuMDIInstallWindowsTelnetForWindowsOS 
         Caption         =   "Install Windows Telnet for Windows OS"
      End
      Begin VB.Menu mnuMDIFixServerHasRedErrorNumbers 
         Caption         =   "Fix Server Has Red Error Numbers"
      End
      Begin VB.Menu mnuHelpServerStalls 
         Caption         =   "Server Stalls or Randomly Not Responding"
      End
      Begin VB.Menu mnuMDIAbout 
         Caption         =   "About"
      End
   End
End
Attribute VB_Name = "mdiMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'Nice little Error trap routien
'On Error GoTo Err_Check
'    Exit Sub
'Err_Check:
'    MsgBox "subSaveTrigger," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical

Dim zInfoAreaWhere As String
Dim zgblValue(0 To 19) As String
Private Sub chkLineFeed3_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case (chkLineFeed3.Value <> 0)
            Case True
                frmMain.Winsock1.SendData "LON" & vbCrLf
            Case Else
                frmMain.Winsock1.SendData "LOFF" & vbCrLf
        End Select
    Else
        chkLineFeed3.Value = 0
    End If
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdReturnCode_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        frmMain.Winsock1.SendData vbCrLf
    End If

   frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdMASTERLock_Click()
On Error Resume Next
    gblbMASTERLock = (Not gblbMASTERLock)
    Select Case gblbMASTERLock
        Case True
            cmdMASTERLock.BackColor = &H40&
        Case Else 'Unlocked Green
            cmdMASTERLock.BackColor = &H8000&
    End Select
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub cmdButton1_MouseUp(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
On Error Resume Next
    If (Button = 2) Then
        Unload frmButtons
        frmButtons.Show
    End If
End Sub
Private Sub MDIForm_Activate()
On Error Resume Next
    subEnforceNumLock "ON"
    subProgramName
    subLoadFontNoteInfo
End Sub

Private Sub mnuAnimation_Click()
    mnuAnimation.Checked = Not mnuAnimation.Checked
    gblbAnimation = Not gblbAnimation
End Sub

Private Sub mnuBlackSheet_Click()
    gblfrmBlackSheet = Not gblfrmBlackSheet
    If (gblfrmBlackSheet) Then
        frmBlackSheet.Show
    Else
        Unload frmBlackSheet
    End If
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub MDIForm_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 2 Then
        frmMapper.Show
    End If
End Sub

Private Sub MDIForm_Unload(Cancel As Integer)
    Close #iFileNo 'If (gblbRecordTextfileEventLine) Then
    If (FileLen(zFileNoName) < 4500) Then
        SetAttr zFileNoName, vbNormal
        Kill zFileNoName ' Then delete the file
    End If
    End
End Sub

Private Sub mnuEditVoiceLocationTriggers_Click()
    frmEditVoiceLocationTriggers.Show
End Sub

Private Sub mnuAdminBldCmds_Click()
    frmHelpAdminSkills.Show
End Sub

Private Sub mnuEventsToggle_Click()
    mnuEventsToggle.Checked = Not mnuEventsToggle.Checked
    gblEventsToggle = mnuEventsToggle.Checked
End Sub

Private Sub mnuFontTweeker_Click()
    frmFontTweeker.Show
End Sub

Private Sub mnuHelpAdminBuildAreasToo_Click()
    frmHelpAdminBuildAreaToo.Show
End Sub

Private Sub mnuHelpPlayerCommandsToo_Click()
    frmHelpPlayerCommandsToo.Show
End Sub

Private Sub mnuHelpPortForward_Click()
    frmHelpPortForward.Show
End Sub

Private Sub mnuJoystickPackman_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmJoystickPackman
        frmJoystickPackman.Show
    End If
End Sub

Private Sub mnuMDIAdminBldCmds_Click()
    frmHelpAdminSkills.Show
End Sub

Private Sub mnuMDIHelpAdminSkillsToo_Click()
    frmHelpAdminSkillsToo.Show
End Sub

Private Sub mnuHelpAdminBuildAreas_Click()
    frmHelpAdminBuildArea.Show
End Sub

Private Sub mnuHelpAdminBuildMob_Click()
    frmHelpAdminBuildMob.Show
End Sub

Private Sub mnuHelpAdminBuildObject_Click()
    frmHelpAdminBuildObjects.Show
End Sub

Private Sub mnuHowTo_Click()
    frmHowTo.Show
End Sub

Private Sub mnuMDIMapperLoggingActive_Click()
    mdiMain!mnuCreatorMapperStatus.Checked = Not mdiMain!mnuCreatorMapperStatus.Checked
    gbllMapperStatus = Not gbllMapperStatus
End Sub

Private Sub mnuMDITickerC_Click()
    frmTimer3.Show
End Sub

Private Sub mnuMDITickerD_Click()
    frmTimer4.Show
End Sub

Private Sub mnuMDITickerE_Click()
    frmTimer5.Show
End Sub

Private Sub mnuMDITickerF_Click()
    frmTimer6.Show
End Sub

Private Sub mnuNumlock_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmNumlock
        frmNumlock.Show
    End If
End Sub

Private Sub mnuPlayerCommandsThree_Click()
    frmHelpPlayerCommandsThree.Show
End Sub

Private Sub mnuPMGraphicsEditor_Click()
On Error Resume Next
    Unload frmPerceptionMachineEditor
    frmPerceptionMachineEditor.Show
End Sub

Private Sub mnuRecordTextfileEventLine_Click()
    mnuRecordTextfileEventLine.Checked = Not mnuRecordTextfileEventLine.Checked
    gblbRecordTextfileEventLine = Not gblbRecordTextfileEventLine
End Sub

Private Sub mnuShowFileNames_Click()
    frmShowFileNames.Show
End Sub

Private Sub mnuTimerDynamic1_Click()
    Unload frmTimerDynamic1
    frmTimerDynamic1.Show
End Sub

Private Sub mnuTimerDynamic2_Click()
    Unload frmTimerDynamicTwo
    frmTimerDynamicTwo.Show
End Sub

Private Sub mnuTimerDynamic3_Click()
    Unload frmTimerDynamic3
    frmTimerDynamic3.Show
End Sub

 
Private Sub Picture1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button = 2 Then
        frmButtons.Show
    End If
End Sub

Public Sub subRefreshButtons()
    Dim lCount As Long
    For lCount = 0 To 19
        zgblValue(lCount) = ""
        cmdButton1(lCount).Caption = ""
    Next lCount
End Sub

Public Sub subLoadMDIButtons()
'See also: subLoadMDIButtons subLoadMDIButtonsHelper
    Dim rsData As Recordset
    Dim lCount As Long
    Dim zLabel As String
    Dim zValue As String
    lCount = 0
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblButtons WHERE (CharacterNameID=" & gbllCharacterNameID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        For lCount = 1 To 20
            zLabel = ""
            zValue = ""
            Select Case lCount
                Case 1
                    zLabel = MyCStr(rsData!ButtonLabel1)
                    zValue = MyCStr(rsData!Button1)
                Case 2
                    zLabel = MyCStr(rsData!ButtonLabel2)
                    zValue = MyCStr(rsData!Button2)
                Case 3
                    zLabel = MyCStr(rsData!ButtonLabel3)
                    zValue = MyCStr(rsData!Button3)
                Case 4
                    zLabel = MyCStr(rsData!ButtonLabel4)
                    zValue = MyCStr(rsData!Button4)
                Case 5
                    zLabel = MyCStr(rsData!ButtonLabel5)
                    zValue = MyCStr(rsData!Button5)
                Case 6
                    zLabel = MyCStr(rsData!ButtonLabel6)
                    zValue = MyCStr(rsData!Button6)
                Case 7
                    zLabel = MyCStr(rsData!ButtonLabel7)
                    zValue = MyCStr(rsData!Button7)
                Case 8
                    zLabel = MyCStr(rsData!ButtonLabel8)
                    zValue = MyCStr(rsData!Button8)
                Case 9
                    zLabel = MyCStr(rsData!ButtonLabel9)
                    zValue = MyCStr(rsData!Button9)
                Case 10
                    zLabel = MyCStr(rsData!ButtonLabel10)
                    zValue = MyCStr(rsData!Button10)
                Case 11
                    zLabel = MyCStr(rsData!ButtonLabel11)
                    zValue = MyCStr(rsData!Button11)
                Case 12
                    zLabel = MyCStr(rsData!ButtonLabel12)
                    zValue = MyCStr(rsData!Button12)
                Case 13
                    zLabel = MyCStr(rsData!ButtonLabel13)
                    zValue = MyCStr(rsData!Button13)
                Case 14
                    zLabel = MyCStr(rsData!ButtonLabel14)
                    zValue = MyCStr(rsData!Button14)
                Case 15
                    zLabel = MyCStr(rsData!ButtonLabel15)
                    zValue = MyCStr(rsData!Button15)
                Case 16
                    zLabel = MyCStr(rsData!ButtonLabel16)
                    zValue = MyCStr(rsData!Button16)
                Case 17
                    zLabel = MyCStr(rsData!ButtonLabel17)
                    zValue = MyCStr(rsData!Button17)
                Case 18
                    zLabel = MyCStr(rsData!ButtonLabel18)
                    zValue = MyCStr(rsData!Button18)
                Case 19
                    zLabel = MyCStr(rsData!ButtonLabel19)
                    zValue = MyCStr(rsData!Button19)
                Case 20
                    zLabel = MyCStr(rsData!ButtonLabel20)
                    zValue = MyCStr(rsData!Button20)
            End Select
            zgblValue(lCount - 1) = zValue
            cmdButton1(lCount - 1).Caption = zLabel
        Next lCount
    Else
        subLoadMDIButtonsHelper
    End If
    Set rsData = Nothing
End Sub

Public Sub subLoadMDIButtonsHelper()
'See also: subLoadMDIButtonsHelper
    Dim lCount As Long
    Dim zLabel As String
    Dim zValue As String
    lCount = 0
    For lCount = 1 To 20 'We use defaults where there is no label (where applicable)
        zLabel = MyCStr(cmdButton1(lCount - 1).Caption)
        Select Case lCount
            Case 1
                If (zLabel = "") Then
                    zLabel = "INV"
                    zValue = "INV"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 2
                If (zLabel = "") Then
                    zLabel = "EQ"
                    zValue = "EQ"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 3
                If (zLabel = "") Then
                    zLabel = "SCORE"
                    zValue = "SCORE"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 4
                If (zLabel = "") Then
                    zLabel = "SLIST"
                    zValue = "SLIST"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 5
                If (zLabel = "") Then
                    zLabel = "LEARN"
                    zValue = "LEARN TREE"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 6
                If (zLabel = "") Then
                    zLabel = "PRACTICE"
                    zValue = "PRAC"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 7
                If (zLabel = "") Then
                    zLabel = "CLEAN"
                    zValue = "CLEAN"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 8
                If (zLabel = "") Then
                    zLabel = "SAC"
                    zValue = "SAC"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 11
                If (zLabel = "") Then
                    zLabel = "LOOK"
                    zValue = "LOOK"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 12
                If (zLabel = "") Then
                    zLabel = "MAP"
                    zValue = "MAP"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 14
                If (zLabel = "") Then
                    zLabel = "AFFECT"
                    zValue = "AFFECT"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 15
                If (zLabel = "") Then
                    zLabel = "COST"
                    zValue = "COST"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 16
                If (zLabel = "") Then
                    zLabel = "DAMAGE"
                    zValue = "DAMAGE"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 17
                If (zLabel = "") Then
                    zLabel = "ORACLE"
                    zValue = "QUEST GO"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
            Case 18
                If (zLabel = "") Then
                    zLabel = "DRINK"
                    zValue = "DRINK FOUNTAIN"
                    zgblValue(lCount - 1) = zValue
                    cmdButton1(lCount - 1).Caption = zLabel
                End If
        End Select
    Next lCount
End Sub

Private Sub cmdButton1_Click(Index As Integer)
On Error Resume Next
    'If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData zgblValue(Index) & vbCrLf
    'frmMain.txtSendClientData.SetFocus
    
    Dim lLen As String
    Dim zSendClientData As String
    
    If (frmMain.Winsock1.State = 7) Then
        zSendClientData = MyCStr(zgblValue(Index))
        lLen = Len(zSendClientData)
        If (lLen > 0) Then
            If (Not bTriggers(zSendClientData)) Then 'bEvents(zEventLine)
                subSendClientData zSendClientData
            End If
        End If
    End If
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdChatCaptureClear_Click()
On Error Resume Next
    mdiMain.txtChatCapture.Text = ""
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub MDIForm_Load()
On Error Resume Next
    gblbCharacterNameIDOverride = True
    gblbMASTERLock = False 'Unlocked/Green
    subEnforceNumLock "ON"
    lTrackSounds = 1
    gblbSoundBackground = True
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    frmMain.Show
    gblbStatsBox = False
    zInfoAreaWhere = ""
    subAppPathSetup
    gblbRecordTextfileEventLine = True
    gblbAnimation = (mnuAnimation.Checked)
    'If (gblbRecordTextfileEventLine) Then
        iFileNo = FreeFile
        zFileNoName = App.Path & "\" & Format(Now(), "yyyymmddhhnnss") & ".TXT"
        'open the file for writing
        Open zFileNoName For Output As #iFileNo 'please note, if this file already exists it will be overwritten!
        Print #iFileNo, "FILE CREATED: " & Format(Now(), "mmm dd, yyyy hh:nn") 'close the file (if you dont do this, you wont be able to open it again!)
    'End If
End Sub

Private Sub subAppPathSetup()
On Error Resume Next
    gblzAppPathPictures = App.Path & "\pictures" 'for pictures
    MkDir gblzAppPathPictures
    gblzAppPathPicturesO = App.Path & "\pictures\o"
    MkDir gblzAppPathPicturesO
    gblzAppPathPicturesM = App.Path & "\pictures\m"
    MkDir gblzAppPathPicturesM
    gblzAppPathPicturesA = App.Path & "\pictures\a"
    MkDir gblzAppPathPicturesA
    
    gblzAppPathSounds = App.Path & "\sounds" 'for sounds
    MkDir gblzAppPathSounds
    gblzAppPathSoundsO = App.Path & "\sounds\o"
    MkDir gblzAppPathSoundsO
    gblzAppPathSoundsM = App.Path & "\sounds\m"
    MkDir gblzAppPathSoundsM
    gblzAppPathSoundsA = App.Path & "\sounds\a"
    MkDir gblzAppPathSoundsA
End Sub

Private Sub mnuScaling_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        frmCharacterMacroScaling.Show
    End If
End Sub

Private Sub MDIForm_Resize()
On Error Resume Next
    'Dim lPTW As Long
    'Dim lPTH As Long
    If (mdiMain.Top < 1) Then mdiMain.Top = 1
    If (mdiMain.Left < 1) Then mdiMain.Left = 1
    picTools.width = (mdiMain.width - picTools.Left) - 120
    txtChatCapture.width = (picTools.width - txtChatCapture.Left) - 120
End Sub

Private Sub mnuHelpServerStalls_Click()
    frmHelpServerStalls.Show
End Sub

Private Sub mnuMDIAbout_Click()
    frmSplashScreen.Show 0
End Sub

Private Sub mnuMDIAreaGraphicsViewer_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmAreaViewerSaver
        Unload frmGraphicalRepresentation
        frmAreaViewerSaver.Show
        frmGraphicalRepresentation.Show
    End If
End Sub

Private Sub mnuMDIButtons_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmButtons
        frmButtons.Show
    End If
End Sub

Private Sub mnuMDIChangeFont_Click()
On Error Resume Next
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        Unload frmChangeFont
        frmChangeFont.Show
    End If
End Sub

Private Sub mnuMDIChangePortAddress_Click()
    frmAddressPort.Show
End Sub

Private Sub mnuMDICharacterProfiles_Click()
    Unload frmCharacterProfiles
    frmCharacterProfiles.Show
End Sub

Private Sub mnuMDIConnect_Click()
On Error Resume Next
    frmMain.txtSendClientData.Text = ""
    subCloseReliantWindows
    
    gbllCharacterNameID = 0
    gblzCharacterName = ""
    bPlayerNameRequired = True
    frmMain.drawCharacterFound.Visible = False
    frmMain.Caption = "City of Ages Terminal Emulator"
    If (mnuMDIConnect.Caption = "Connect") Then
        If (frmMain.Winsock1.State <> 7) Then '7 = connected MsgBox "HIHI2 - never runs"
            Unload frmCharacterProfiles
            frmCharacterProfiles.Show
        End If

        mnuMDIConnect.Caption = "Disconnect"
        mdiMain!picStatsBox.Visible = False
        Call TermInitialize
        frmMain.Winsock1.Close
        frmMain.Winsock1.Connect gblzAddress, gblzPort
        frmMain.timCursor.Enabled = True
        'Terminal0.SetFocus
    Else
        Call frmMain.Disconnect
    End If
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub mnuMDIEvents_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        frmCharacterEvents.Show
    End If
End Sub

Private Sub mnuMDIFixServerHasRedErrorNumbers_Click()
    frmHelpWontRun.Show
End Sub

Private Sub mnuMDIInstallWindowsTelnetForWindowsOS_Click()
    frmHelp.Show
End Sub

Private Sub mnuMDILargeMessageBox_Click()
    frmMain.txtSendClientData.ToolTipText = "" 'user got the message obviously
    frmLargeMessageBox.Show
End Sub

Private Sub mnuMDIMapperAutoFocus_Click()
    mnuMDIMapperAutoFocus.Checked = Not mnuMDIMapperAutoFocus.Checked
    gbllMapperAutoFocus = Not gbllMapperAutoFocus
End Sub

Private Sub mnuMDIPlayerCommands_Click()
    frmHelpPlayerCommands.Show
End Sub

Private Sub mnuMDIScrollBack_Click()
    gblbTerminalScrolling = Not gblbTerminalScrolling
End Sub

Private Sub mnuMDISound_Click()
On Error Resume Next
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    Set Player = Nothing
    mnuMDISound.Checked = Not mnuMDISound.Checked
    gblbSoundAllowed = (mnuMDISound.Checked)
End Sub
Private Sub mnuMDISoundStoryLine_Click()
On Error Resume Next
    gbllVoiceLorePlayer = 0
    gblbVoiceLorePlaying = False
    Set Player = Nothing
    mnuMDISoundStoryLine.Checked = Not mnuMDISoundStoryLine.Checked
    gblbSoundStoryLine = (mnuMDISoundStoryLine.Checked)
End Sub
Private Sub mnuMDISoundBackground_Click()
On Error Resume Next
    mnuMDISoundBackground.Checked = Not mnuMDISoundBackground.Checked
    gblbSoundBackground = (mnuMDISoundBackground.Checked)
    If (Not gblbSoundBackground) Then subMCIStopPlayer
End Sub
Private Sub mnuMDITickerA_Click()
    frmTimer1.Show
End Sub

Private Sub mnuMDITickerB_Click()
    frmTimer2.Show
End Sub

Private Sub mnuMDITriggers_Click()
    If (gbllCharacterNameID = 0) Then
        basPrintMessage64 "Please Log into the Game first." & vbCrLf & "You may need to Create a Profile before logging in however."
        frmCharacterProfiles.Show
    Else
        frmCharacterTriggers.Show
    End If
End Sub

Private Sub mnuMemos_Click()
    frmMemos.Show
End Sub
Private Sub tmrAreaWhere_Timer()
    Dim zFilename As String
    Dim zFilePathAndFileName As String
    'Load Area Where
    If (zInfoAreaWhere <> gblzInfoAreaWhere) Then 'we already displayed this spot
        If (Len(gblzInfoAreaWhere) = 0) Then
            mdiMain.Caption = "MAIN - City of Ages Telnet Client"
        Else
            zFilename = gblzInfoAreaWhere & ".bmp" 'zRemoveColorCodes is used in frmMain
            mdiMain.Caption = "MAIN - [" & zFilename & "]"
            zFilePathAndFileName = gblzAppPathPictures & "\" & zFilename
            If (bFileExists(zFilePathAndFileName)) Then
                mdiMain.Picture = LoadPicture(zFilePathAndFileName)
                'Update the picture on the mdiMain form - easy ways to do this
                'Select Case 3 'Ways to refresh the mdi form picture
                '    Case 1 'gives you a bit of a headache
                '        'windowstate=0 (normal)  windowstate=1 (minimized)  windowstate=2 (maximized)
                '        Select Case Me.WindowState
                '            Case 0
                '                Me.WindowState = 1
                '                Me.WindowState = 0
                '            Case Else
                '                Me.WindowState = 1
                '                Me.WindowState = 2
                '        End Select
                '    Case 2 'bit of a flash but is not bad
                '        frmUpdateBackGroundPicture.Height = mdiMain.Height
                '        frmUpdateBackGroundPicture.Width = mdiMain.Width
                '        frmUpdateBackGroundPicture.Show
                '        Unload frmUpdateBackGroundPicture
                '    Case 3 'cleanest version no blinking
                        Call SetWindowPos(Me.hWnd, 0, 0, 0, 0, 0, swpFlags)
                        'call RedrawWindow Me.hWnd, ByVal 0&, 0, RDW_UPDATENOW
                        'call UpdateWindow Me.hWnd
                'End Select
            End If
        End If
    End If
    zInfoAreaWhere = gblzInfoAreaWhere 'keep the loading from over doing the reloading as it was a found file
End Sub

Private Sub tmrButtonBnk_Timer()
    Dim lCount As Long
    tmrButtonBnk.Enabled = False
    For lCount = 0 To 19
        mdiMain.cmdButton1(lCount).BackColor = cstlngButtonColorOri
    Next lCount
End Sub

