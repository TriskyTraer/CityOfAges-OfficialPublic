Attribute VB_Name = "modSystemHooks"
Option Explicit
'Nice little Error trap routien, See Also: subWriteErrorFile
'On Error GoTo Err_Check
'    Exit Sub
'Err_Check:
'    MsgBox "subSaveTrigger," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical

' EXAMPLE USAGE: Simple logic to detect mouse wheel up or down: "MouseWheel " & IIf(Rotation < 0, "Down", "Up")
' Store WndProcs
Private Declare Function GetProp Lib "user32.dll" Alias "GetPropA" ( _
                ByVal hWnd As Long, _
                ByVal lpString As String) As Long

Private Declare Function SetProp Lib "user32.dll" Alias "SetPropA" ( _
                ByVal hWnd As Long, _
                ByVal lpString As String, _
                ByVal hData As Long) As Long

Private Declare Function RemoveProp Lib "user32.dll" Alias "RemovePropA" ( _
                ByVal hWnd As Long, _
                ByVal lpString As String) As Long

' Hooking
Private Declare Function CallWindowProc Lib "user32.dll" Alias "CallWindowProcA" ( _
                ByVal lpPrevWndFunc As Long, _
                ByVal hWnd As Long, _
                ByVal Msg As Long, _
                ByVal wParam As Long, _
                ByVal lParam As Long) As Long

Private Declare Function SetWindowLong Lib "user32.dll" Alias "SetWindowLongA" ( _
                ByVal hWnd As Long, _
                ByVal nIndex As Long, _
                ByVal dwNewLong As Long) As Long

Private Declare Function SendMessage Lib "user32.dll" Alias "SendMessageA" ( _
                ByVal hWnd As Long, _
                ByVal Msg As Long, _
                wParam As Any, _
                lParam As Any) As Long

' Position Checking
Private Declare Function GetWindowRect Lib "user32" ( _
                ByVal hWnd As Long, _
                lpRect As RECT) As Long
                
Private Declare Function GetParent Lib "user32" ( _
                ByVal hWnd As Long) As Long

Private Const GWL_WNDPROC = -4
Private Const WM_MOUSEWHEEL = &H20A
Private Const CB_GETDROPPEDSTATE = &H157

Public Const SND_APPLICATION = &H80         ' look for application specific association
Public Const SND_ALIAS = &H10000     ' name is a WIN.INI [sounds] entry
Public Const SND_ALIAS_ID = &H110000    ' name is a WIN.INI [sounds] entry identifier
Public Const SND_ASYNC = &H1         ' play asynchronously
Public Const SND_FILENAME = &H20000     ' name is a file name
Public Const SND_LOOP = &H8         ' loop the sound until next sndPlaySound
Public Const SND_MEMORY = &H4         ' lpszSoundName points to a memory file
Public Const SND_NODEFAULT = &H2         ' silence not default, if sound not found
Public Const SND_NOSTOP = &H10        ' don't stop any currently playing sound
Public Const SND_NOWAIT = &H2000      ' don't wait if the driver is busy
Public Const SND_PURGE = &H40               ' purge non-static events for task
Public Const SND_RESOURCE = &H40004     ' name is a resource name or atom
Public Const SND_SYNC = &H0         ' play synchronously (default)
'eg. PlaySound "C:\WINDOWS\MEDIA\TADA.WAV", ByVal 0&, SND_FILENAME Or SND_ASYNC
Public Declare Function PlaySound Lib "winmm.dll" Alias "PlaySoundA" (ByVal lpszName As String, ByVal hModule As Long, ByVal dwFlags As Long) As Long

'mciSendString can play many sounds at one time 'Error msg? look here: https://msdn.microsoft.com/en-us/library/aa228215(v=vs.60).aspx
Private Declare Function mciSendString Lib "winmm.dll" Alias "mciSendStringA" (ByVal lpstrCommand As String, ByVal lpstrReturnString As String, ByVal uReturnLength As Integer, ByVal hwndCallback As Integer) As Integer
Private Declare Function mciGetErrorString Lib "winmm.dll" Alias "mciGetErrorStringA" (ByVal dwError As Integer, ByVal lpstrBuffer As String, ByVal uLength As Integer) As Integer

Public Const Flags& = SND_ASYNC Or SND_NODEFAULT Or SND_MEMORY
Public Declare Function sndPlaySound Lib "winmm.dll" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long
Public Const KEYEVENTF_KEYUP = &H2
'Public Const KEY_DOWN As Integer = &H8000
Public Declare Function GetKeyState Lib "user32.dll" (ByVal nVirtKey As KeyCodeConstants) As Integer 'Const KEY_DOWN As Integer = &H8000 'If GetKeyState(vbKeyA) And KEY_DOWN Then    'End If
'Public Declare Function GetKeyState Lib "user32" (ByVal nVirtKey As Long) As Integer
Public Declare Sub keybd_event Lib "user32" (ByVal bVk As Byte, ByVal bScan As Byte, ByVal dwFlags As Long, ByVal dwExtraInfo As Long)

Private Type RECT
  Left As Long
  Top As Long
  Right As Long
  Bottom As Long
End Type

Public zTrackSounds(1 To 999999) As String
Public lTrackSounds As Long
Public gbllFormActivated As Long 'Each form from top to bottom will have a value from 1 to #ofForms in your list - Set this variable in 'Private Sub Form_Load()' as it is called before Form.Activated - this value goes into some module (ie. modMain) for the entire .vbp

' Check Messages
' ================================================
Private Function WindowProc(ByVal Lwnd As Long, ByVal Lmsg As Long, ByVal wParam As Long, ByVal lParam As Long) As Long
  Dim Rotation As Long
  Dim MouseKeys As Long
  Dim Xpos As Long
  Dim Ypos As Long
  Dim fFrm As Form

  Select Case Lmsg
  
    Case WM_MOUSEWHEEL
    
      MouseKeys = wParam And 65535
      Rotation = wParam / 65536
      Xpos = lParam And 65535
      Ypos = lParam / 65536
      
      Set fFrm = GetForm(Lwnd)
      If fFrm Is Nothing Then
        ' it's not a form
        If Not IsOver(Lwnd, Xpos, Ypos) And IsOver(GetParent(Lwnd), Xpos, Ypos) Then
          ' it's not over the control and is over the form,
          ' so fire mousewheel on form (if it's not a dropped down combo)
          If SendMessage(Lwnd, CB_GETDROPPEDSTATE, 0&, 0&) <> 1 Then
            GetForm(GetParent(Lwnd)).MouseWheel MouseKeys, Rotation, Xpos, Ypos
            Exit Function ' Discard scroll message to control
          End If
        End If
      Else
        ' it's a form so fire mousewheel
        If IsOver(fFrm.hWnd, Xpos, Ypos) Then fFrm.MouseWheel MouseKeys, Rotation, Xpos, Ypos
      End If
  End Select
  
  WindowProc = CallWindowProc(GetProp(Lwnd, "PrevWndProc"), Lwnd, Lmsg, wParam, lParam)
End Function

' Hook / UnHook
' ================================================
Public Sub WheelHook(ByVal hWnd As Long)
  On Error Resume Next
  SetProp hWnd, "PrevWndProc", SetWindowLong(hWnd, GWL_WNDPROC, AddressOf WindowProc)
End Sub

Public Sub WheelUnHook(ByVal hWnd As Long)
  On Error Resume Next
  SetWindowLong hWnd, GWL_WNDPROC, GetProp(hWnd, "PrevWndProc")
  RemoveProp hWnd, "PrevWndProc"
End Sub

' Window Checks
' ================================================
Public Function IsOver(ByVal hWnd As Long, ByVal lX As Long, ByVal lY As Long) As Boolean
  Dim rectCtl As RECT
  GetWindowRect hWnd, rectCtl
  With rectCtl
    IsOver = (lX >= .Left And lX <= .Right And lY >= .Top And lY <= .Bottom)
  End With
End Function

Private Function GetForm(ByVal hWnd As Long) As Form
  For Each GetForm In Forms
    If GetForm.hWnd = hWnd Then Exit Function
  Next GetForm
  Set GetForm = Nothing
End Function

Public Sub subEnforceNumLock(zType As String)
    Select Case UCase(zType)
        Case "ON"
            If (GetKeyState(vbKeyNumlock) = 0) Then
                keybd_event vbKeyNumlock, 0, 0, 0       'simulates key press
                keybd_event vbKeyNumlock, 0, vbKeyUp, 0 'simulates key release (WM_KEYUP);
            End If
        Case "OFF"
            If (GetKeyState(vbKeyNumlock) = 1) Then
                keybd_event vbKeyNumlock, 0, 0, 0       'simulates key press
                keybd_event vbKeyNumlock, 0, vbKeyUp, 0 'simulates key release (WM_KEYUP);
            End If
    End Select
End Sub

Public Sub subStickyAlignWindows(zName As String, Optional zMainMDI As String)
'This is not a true sticky window but it helps to align them on the border of eachother
'Useage:
    '(goes into a main Module for the entire .vbp Project)
    'Public gbllFormActivated As Long 'Each form from top to bottom will have a value from 1 to #ofForms in your list - Set this variable in 'Private Sub Form_Load()' as it is called before Form.Activated - this value goes into some module (ie. modMain) for the entire .vbp
    '(form declarations and PROCs)
    'Option Explicit ' (goes into a private form)
    'Dim gbllOMeLeft As Long
    'Dim gbllOMeTop As Long
    '
    'Private Sub Form_Activate()
    '    gbllFormActivated = <value>
    'End Sub
    'Private Sub Form_Load()
    'On Error Resume Next
    '    gbllFormActivated = <value>
    '    txtAppPath.Text = app.path
    'End Sub
    '
    'Private Sub Timer1_Timer() 'somewhere below Private Sub Form_Load() - dont forget to drag-n-drop to make a ToolBar's Timer
    '    If (gbllFormActivated = <value>) Then 'A Protection so the other forms arnt running this code on event execute of other Timers on other forms
    '        If (Me.Left <> gbllOMeLeft And Me.Top <> gbllOMeTop) Then
    '            gbllOMeLeft = Me.Left: gbllOMeTop = Me.Top
    '            subStickyWindows Me.Name, mdiMain.Name
    '        End If
    '    End If
    'End Sub
    Const cstSnapSize = 500 'this is in Twips which is 15 x size of 1 pixel
    Dim frmRect As Form
    Dim lOX1 As Long
    Dim lOX2 As Long
    Dim lOY1 As Long
    Dim lOY2 As Long
    Dim lDX1 As Long
    Dim lDX2 As Long
    Dim lDY1 As Long
    Dim lDY2 As Long
    
    '1) GET Original X1&2 and Y1&2 TOP LEFT TOP+HEIGHT LEFT+WIDTH
    For Each frmRect In Forms
        If (frmRect.Name = zName) Then
            lOX1 = frmRect.Left
            lOX2 = frmRect.Left + frmRect.Width
            lOY1 = frmRect.Top
            lOY2 = frmRect.Top + frmRect.Height
        End If
    Next frmRect
    
    '2) Compare Original X1 with 2 and Y1 with 2 for each TOP LEFT TOP+HEIGHT LEFT+WIDTH
    For Each frmRect In Forms
        lDX1 = frmRect.Left
        lDX2 = frmRect.Left + frmRect.Width
        lDY1 = frmRect.Top
        lDY2 = frmRect.Top + frmRect.Height
        If (frmRect.Name <> zMainMDI And frmRect.Name <> zName) Then
            If (lOX2 > lDX1 - cstSnapSize And lOX2 < lDX1 + cstSnapSize) Then   'Test snap to target rect's left side
                lOX1 = (lDX1 - (lOX2 - lOX1)) + 10
            Else
                If (lOX1 > lDX2 - cstSnapSize And lOX1 < lDX2 + cstSnapSize) Then   'Test snap to target rect's right side
                    lOX1 = lDX2 - 60
                End If
            End If
        End If
    Next frmRect
    
    '3) SET the above values back to the Original X1&2 and Y1&2 for TOP LEFT TOP+HEIGHT LEFT+WIDTH
    For Each frmRect In Forms
        If (frmRect.Name = zName) Then 'Snap the original X into place
            frmRect.Left = lOX1
        End If
    Next frmRect
End Sub

Public Sub subMCIStopPlayer()
On Error Resume Next
    Dim iResult As Integer 'Error msg? look here: https://msdn.microsoft.com/en-us/library/aa228215(v=vs.60).aspx
    Dim zMsg As String
    Dim lCount As Long
    For lCount = 1 To lTrackSounds
        iResult = mciSendString("close " & zTrackSounds(lCount), zMsg, 0, 0)       '2263=notplaying 20=play was stopped successfully
        zTrackSounds(lCount) = ""
    Next lCount
    lTrackSounds = 1
End Sub

Public Sub subMCIPlayer(zFilename As String)
    Dim iResult As Integer 'Error msg? look here: https://msdn.microsoft.com/en-us/library/aa228215(v=vs.60).aspx
    Dim zMsg As String
    Dim zFilePathname As String

    zFilePathname = zFilename
    If (InStr(zFilename, "\") = 0) Then zFilePathname = gblzAppPathSounds & "\" & zFilename 'No pathing was given so default to the player's client directory [.Wav files only!]
    
    lTrackSounds = lTrackSounds + 1
    zTrackSounds(lTrackSounds) = "P" & lTrackSounds & "Track"
    
    'We find an available player
    iResult = mciSendString("open " & zFilePathname & " type mpegvideo alias " & zTrackSounds(lTrackSounds), 0, 0, 0)  'iResult=289 (already playing on FirstSound) 0=successful, playing now
    iResult = mciSendString("play " & zTrackSounds(lTrackSounds), zMsg, 0, 0)
End Sub

