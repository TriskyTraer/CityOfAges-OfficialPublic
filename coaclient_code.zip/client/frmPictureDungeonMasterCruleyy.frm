VERSION 5.00
Begin VB.Form frmPictureDungeonMasterCruely 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "D U N G E O N  M A S T E R  CRUELY  L U R K S !!!"
   ClientHeight    =   8340
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   8385
   Icon            =   "frmPictureDungeonMasterCruleyy.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   Picture         =   "frmPictureDungeonMasterCruleyy.frx":058A
   ScaleHeight     =   8340
   ScaleWidth      =   8385
   Begin VB.Timer tmrCruley 
      Interval        =   12000
      Left            =   0
      Top             =   0
   End
   Begin VB.Label lblCruelyMessage 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   15.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H000000FF&
      Height          =   975
      Left            =   0
      TabIndex        =   0
      ToolTipText     =   "A Message from Dungeon Master Cruley, he watches for patterned words which can activate him!"
      Top             =   0
      Visible         =   0   'False
      Width           =   8415
   End
End
Attribute VB_Name = "frmPictureDungeonMasterCruely"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub subCruelyDc()
    lblCruelyMessage.Caption = "I have powerzzz for realz! I disconnect you !! HAR HAR! (game over, insert 25 cents to continue)"
    If (frmMain.Winsock1.State = 7) Then
        frmMain.mnuMainCD.Caption = "Connect"
        mdiMain.mnuMDIConnect.Caption = "Connect"
        Call frmMain.Disconnect
    End If
    tmrCruley.Enabled = False
End Sub
Private Sub tmrCruley_Timer()
    tmrCruley.Enabled = False
    lblCruelyMessage.Visible = False
    Unload frmPictureDungeonMasterCruely
End Sub
Private Sub Form_Load()
    Dim bFound As Boolean
    bFound = True
    Select Case lRandom(12)
        Case 1
            lblCruelyMessage.Caption = "I know, I know, shut up Cru-ley, I am just popping in to say 'HI Captain'"
        Case 2
            lblCruelyMessage.Caption = "I know, I know, get off my bridge Cru-ley! wow ..."
        Case 3
            lblCruelyMessage.Caption = "What'cha doing? Am I bothering you? hehehe!"
        Case 3
            lblCruelyMessage.Caption = "Just popping in Captai'Neato"
        Case 4
            lblCruelyMessage.Caption = "One life has a passage, the other does not, Captai'Neato!"
        Case 5
            lblCruelyMessage.Caption = "Some take the red gummy, some instead, eat the blue gummy, Captai'Neato!"
        Case 6
            lblCruelyMessage.Caption = "There is no bending anything, Captai'Neato, it is in fact the Vodka that bends everybody! har har!"
        Case 7
            lblCruelyMessage.Caption = "Hello," & vbCrLf & "Captai'Neato, someone said you sound like an Owl ! ? !"
        Case 8
            lblCruelyMessage.Caption = "Incomming mob ships, this time its not something you can handle, C'Neato!"
        Case 9
            lblCruelyMessage.Caption = "Incomming attacker!"
        Case 10
            lblCruelyMessage.Caption = "I know, turn back if you are afraid, C'Neato!"
        Case 11
            lblCruelyMessage.Caption = "Everyone to their stations...Red Alert! Oh my appologies, this is your ship after all!"
        Case Else
            bFound = False
            If (lRandom(9999) = 1) Then
                subCruelyDc
            End If
    End Select
    If (bFound) Then lblCruelyMessage.Visible = True
End Sub

