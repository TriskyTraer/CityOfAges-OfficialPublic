VERSION 5.00
Begin VB.Form frmMerchant 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "MERCHANT"
   ClientHeight    =   975
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   3360
   Icon            =   "frmMerchant.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   975
   ScaleWidth      =   3360
   ShowInTaskbar   =   0   'False
   Begin VB.CommandButton cmdMerchant 
      Appearance      =   0  'Flat
      BackColor       =   &H0080C0FF&
      Caption         =   "View Merchant Warez"
      Height          =   375
      Left            =   240
      Style           =   1  'Graphical
      TabIndex        =   0
      ToolTipText     =   "Click to send the LIST command."
      Top             =   240
      Width           =   2895
   End
End
Attribute VB_Name = "frmMerchant"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'see also: subProcessXYZLine
Private Sub cmdMerchant_Click()
    frmMain.Winsock1.SendData "LIST" & vbCrLf
    frmMain.txtSendClientData.Text = "BUY ? SELL ?"
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub Form_Load()
    gblbMerchantWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbMerchantWindow = False
End Sub

