VERSION 5.00
Begin VB.Form frmMerchant 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "WAREZ"
   ClientHeight    =   1140
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   1650
   Icon            =   "frmMerchant.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   1140
   ScaleWidth      =   1650
   ShowInTaskbar   =   0   'False
   Begin VB.Timer tmrWarez 
      Interval        =   15000
      Left            =   240
      Top             =   240
   End
   Begin VB.CommandButton cmdMerchant 
      Appearance      =   0  'Flat
      BackColor       =   &H0080C0FF&
      Caption         =   "List Merchant Warez"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   855
      Left            =   120
      Style           =   1  'Graphical
      TabIndex        =   0
      ToolTipText     =   "Click to send the LIST command."
      Top             =   120
      Width           =   1335
   End
End
Attribute VB_Name = "frmMerchant"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'see also: subProcessXYZLine
Private Sub cmdMerchant_Click()
    frmMain.Winsock1.SendData "LIST" & vbCrLf
    frmMain.txtSendClientData.Text = "BUY ? SELL ?"
    frmMain.txtSendClientData.SetFocus
End Sub
Private Sub Form_Load()
    gblbMerchantWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbMerchantWindow = False
End Sub
Private Sub tmrWarez_Timer() 'slows down the unwanted fluttering effect
    gblbMerchantWindow = False
    tmrWarez.Enabled = False
End Sub
