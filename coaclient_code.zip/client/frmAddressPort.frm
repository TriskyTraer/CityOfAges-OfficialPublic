VERSION 5.00
Begin VB.Form frmAddressPort 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Change Internet Protocol Address and Port"
   ClientHeight    =   9240
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   9675
   Icon            =   "frmAddressPort.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   9240
   ScaleWidth      =   9675
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   9
      Left            =   9120
      Picture         =   "frmAddressPort.frx":058A
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   39
      Top             =   7680
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   8
      Left            =   9120
      Picture         =   "frmAddressPort.frx":09CC
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   38
      Top             =   6840
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   7
      Left            =   9120
      Picture         =   "frmAddressPort.frx":0E0E
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   37
      Top             =   6000
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   6
      Left            =   9120
      Picture         =   "frmAddressPort.frx":1250
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   36
      Top             =   5160
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   5
      Left            =   9120
      Picture         =   "frmAddressPort.frx":1692
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   35
      Top             =   4320
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   4
      Left            =   9120
      Picture         =   "frmAddressPort.frx":1AD4
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   34
      Top             =   3480
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   3
      Left            =   9120
      Picture         =   "frmAddressPort.frx":1F16
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   33
      Top             =   2640
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   2
      Left            =   9120
      Picture         =   "frmAddressPort.frx":2358
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   32
      Top             =   1800
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   1
      Left            =   9120
      Picture         =   "frmAddressPort.frx":279A
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   31
      Top             =   960
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.PictureBox picSelected 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   0  'None
      FontTransparent =   0   'False
      ForeColor       =   &H80000008&
      Height          =   480
      Index           =   0
      Left            =   9120
      Picture         =   "frmAddressPort.frx":2BDC
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   30
      Top             =   120
      Visible         =   0   'False
      Width           =   480
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   9
      Left            =   960
      MaxLength       =   50
      TabIndex        =   18
      Top             =   7680
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   9
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   19
      Top             =   7680
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   9
      Left            =   120
      Picture         =   "frmAddressPort.frx":301E
      Style           =   1  'Graphical
      TabIndex        =   29
      TabStop         =   0   'False
      Top             =   7680
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   8
      Left            =   960
      MaxLength       =   50
      TabIndex        =   16
      Top             =   6840
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   8
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   17
      Top             =   6840
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   8
      Left            =   120
      Picture         =   "frmAddressPort.frx":3460
      Style           =   1  'Graphical
      TabIndex        =   28
      TabStop         =   0   'False
      Top             =   6840
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   7
      Left            =   960
      MaxLength       =   50
      TabIndex        =   14
      Top             =   6000
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   7
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   15
      Top             =   6000
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   7
      Left            =   120
      Picture         =   "frmAddressPort.frx":38A2
      Style           =   1  'Graphical
      TabIndex        =   27
      TabStop         =   0   'False
      Top             =   6000
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   6
      Left            =   960
      MaxLength       =   50
      TabIndex        =   12
      Top             =   5160
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   6
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   13
      Top             =   5160
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   6
      Left            =   120
      Picture         =   "frmAddressPort.frx":3CE4
      Style           =   1  'Graphical
      TabIndex        =   26
      TabStop         =   0   'False
      Top             =   5160
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   5
      Left            =   960
      MaxLength       =   50
      TabIndex        =   10
      Top             =   4320
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   5
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   11
      Top             =   4320
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   5
      Left            =   120
      Picture         =   "frmAddressPort.frx":4126
      Style           =   1  'Graphical
      TabIndex        =   25
      TabStop         =   0   'False
      Top             =   4320
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   4
      Left            =   960
      MaxLength       =   50
      TabIndex        =   8
      Top             =   3480
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   4
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   9
      Top             =   3480
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   4
      Left            =   120
      Picture         =   "frmAddressPort.frx":4568
      Style           =   1  'Graphical
      TabIndex        =   24
      TabStop         =   0   'False
      Top             =   3480
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   3
      Left            =   960
      MaxLength       =   50
      TabIndex        =   6
      Top             =   2640
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   3
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   7
      Top             =   2640
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   3
      Left            =   120
      Picture         =   "frmAddressPort.frx":49AA
      Style           =   1  'Graphical
      TabIndex        =   23
      TabStop         =   0   'False
      Top             =   2640
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   2
      Left            =   960
      MaxLength       =   50
      TabIndex        =   4
      Top             =   1800
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   2
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   5
      Top             =   1800
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   2
      Left            =   120
      Picture         =   "frmAddressPort.frx":4DEC
      Style           =   1  'Graphical
      TabIndex        =   22
      TabStop         =   0   'False
      Top             =   1800
      Width           =   735
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   1
      Left            =   960
      MaxLength       =   50
      TabIndex        =   2
      Top             =   960
      Width           =   5895
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   1
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   3
      Top             =   960
      Width           =   2055
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   1
      Left            =   120
      Picture         =   "frmAddressPort.frx":522E
      Style           =   1  'Graphical
      TabIndex        =   21
      TabStop         =   0   'False
      Top             =   960
      Width           =   735
   End
   Begin VB.CommandButton cmdSelect 
      Appearance      =   0  'Flat
      Caption         =   "save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   0
      Left            =   120
      Picture         =   "frmAddressPort.frx":5670
      Style           =   1  'Graphical
      TabIndex        =   20
      TabStop         =   0   'False
      Top             =   120
      Width           =   735
   End
   Begin VB.TextBox txtPort 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   0
      Left            =   6960
      MaxLength       =   9
      TabIndex        =   1
      Top             =   120
      Width           =   2055
   End
   Begin VB.TextBox txtAddress 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   26.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   735
      Index           =   0
      Left            =   960
      MaxLength       =   50
      TabIndex        =   0
      Top             =   120
      Width           =   5895
   End
   Begin VB.Label lblHelp 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFC0C0&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   615
      Left            =   120
      TabIndex        =   40
      Top             =   8520
      Width           =   9495
   End
End
Attribute VB_Name = "frmAddressPort"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdSelect_Click(Index As Integer)
    Dim i As Integer
    subSaveAllPortAddress
    For i = 0 To 9
        picSelected(i).Visible = False
    Next i
    picSelected(Index).Visible = True
    gblzAddress = txtAddress(Index).Text
    gblzPort = MyCLng(txtPort(Index).Text)
    MyDB.Execute "UPDATE tblSystemSetUp SET Selected=FALSE;", dbFailOnError
    MyDB.Execute "UPDATE tblSystemSetUp SET Selected=TRUE WHERE Address='" & zRemoveSQLCrashChars(MyCStr(txtAddress(Index).Text)) & "' AND Port='" & zRemoveSQLCrashChars(MyCStr(txtPort(Index).Text)) & "';", dbFailOnError
    MyDB.Execute "UPDATE tblSystemSetUp SET Selected=FALSE WHERE Address='' or Port='';", dbFailOnError
    subSaveAllPortAddress
End Sub

Private Sub subListAllPortAddress()
    Dim i As Integer
    Dim rsSetUp As Recordset
    Set rsSetUp = MyDB.OpenRecordset("SELECT Address, Port, Selected FROM tblSystemSetUp ORDER BY SystemSetUpID;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        i = 0
        Do While (Not rsSetUp.EOF And i < 10)
            txtAddress(i).Text = MyCStr(rsSetUp!Address)
            txtPort(i).Text = MyCStr(rsSetUp!Port)
            Select Case rsSetUp!Selected
                Case 0, False
                    picSelected(i).Visible = False
                Case Else
                picSelected(i).Visible = True
            End Select
            rsSetUp.MoveNext
            i = i + 1
        Loop
    Else
        MyDB.Execute "INSERT INTO tblSystemSetUp ( Address, Port, Selected ) SELECT '" & gblzAddress & "', '" & gblzPort & "', True;", dbFailOnError
        txtAddress(0).Text = "127.0.0.1"
        txtPort(0).Text = "23"
    End If
    Set rsSetUp = Nothing
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub subSaveAllPortAddress()
    Dim i As Integer
    Dim zAddy As String
    Dim zPort As String
    Dim bShow As Boolean
    
    MyDB.Execute "DELETE * FROM tblSystemSetUp;", dbFailOnError
    For i = 0 To 9
        zAddy = zRemoveSQLCrashChars(MyCStr(txtAddress(i).Text))
        txtAddress(i).Text = zAddy
        zPort = zRemoveSQLCrashChars(MyCStr(txtPort(i).Text))
        txtPort(i).Text = zPort
        bShow = picSelected(i).Visible
        MyDB.Execute "INSERT INTO tblSystemSetUp ( Address, Port, Selected ) SELECT '" & zAddy & "', '" & zPort & "', " & bShow & ";", dbFailOnError
    Next i
End Sub

Private Sub Form_Activate()
    gbllFormActivated = 1
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_Load()
    subWindowsPosition Me, "L"
    subListAllPortAddress
    lblHelp.Caption = "To connect locally and directly to your own computer with City of Ages server use:" & vbCrLf & "ip address 127.0.0.1 [port 23/port 4000/port 4001]"
End Sub

Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
End Sub

Private Sub txtPort_LostFocus(Index As Integer)
On Error Resume Next
    txtPort(Index).Text = MyCLng(txtPort(Index).Text)
    If (txtPort(Index).Text = "0") Then txtPort(Index).Text = ""
End Sub
