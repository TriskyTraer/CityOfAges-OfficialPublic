VERSION 5.00
Begin VB.Form frmLargeMessageBox 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Large Message Box"
   ClientHeight    =   5340
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   11490
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmLargeMessageBox.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5340
   ScaleWidth      =   11490
   Begin VB.CommandButton cmdSend 
      Appearance      =   0  'Flat
      Caption         =   "&Send"
      Height          =   255
      Left            =   9840
      TabIndex        =   1
      Top             =   5040
      Width           =   1455
   End
   Begin VB.TextBox txtParagraph 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   4815
      Left            =   120
      MaxLength       =   2222
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   0
      Top             =   120
      Width           =   11415
   End
End
Attribute VB_Name = "frmLargeMessageBox"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub cmdSend_Click()
On Error Resume Next
    txtParagraph_KeyUp 13, 0
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 11
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_Load()
On Error Resume Next
    subWindowsPosition Me, "L"
    txtParagraph.Text = frmMain.txtSendClientData.Text
    frmMain.txtSendClientData.Text = ""
End Sub
Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Resize()
    txtParagraph.width = frmLargeMessageBox.width - 350
    frmLargeMessageBox.height = 5925
End Sub
Private Sub Form_Unload(Cancel As Integer)
    subWindowsPosition Me, "S"
End Sub
Private Sub txtParagraph_KeyUp(KeyCode As Integer, Shift As Integer)
On Error Resume Next
    If (KeyCode = 27) Then
        Unload Me
        frmMain.txtSendClientData.SetFocus
    End If

    If (KeyCode = 13) Then
        If (frmMain.Winsock1.State = 7) Then
            txtParagraph.Text = MyCStr(txtParagraph.Text) 'zRemoveCrazyChars(MyCStr(txtParagraph.Text))
            DoEvents
            If (Len(txtParagraph.Text) > 0) Then
                frmMain.Winsock1.SendData txtParagraph.Text & vbCrLf
            End If
        End If
        Unload frmLargeMessageBox
        frmMain.txtSendClientData.SetFocus
    End If
End Sub
