VERSION 5.00
Begin VB.Form frmAreaViewerSaver 
   Appearance      =   0  'Flat
   BackColor       =   &H00404040&
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   5385
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   5520
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmAreaViewerSaver.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   OLEDropMode     =   1  'Manual
   ScaleHeight     =   5385
   ScaleWidth      =   5520
   Begin VB.PictureBox pbOID 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   2055
      Left            =   2760
      ScaleHeight     =   2055
      ScaleWidth      =   2655
      TabIndex        =   2
      TabStop         =   0   'False
      Top             =   3240
      Width           =   2655
   End
   Begin VB.PictureBox pbMID 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   2055
      Left            =   120
      ScaleHeight     =   2055
      ScaleWidth      =   2655
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   3240
      Width           =   2655
   End
   Begin VB.Timer tmrDisplay 
      Left            =   120
      Top             =   120
   End
   Begin VB.PictureBox pbAreaAID 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   3135
      Left            =   120
      ScaleHeight     =   3135
      ScaleWidth      =   5295
      TabIndex        =   0
      TabStop         =   0   'False
      Top             =   120
      Width           =   5295
   End
End
Attribute VB_Name = "frmAreaViewerSaver"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'WebBrowser1.Navigate ("C:\Users\User\Desktop\3D_view.gif") to play animated gifs

'Private Sub Command1_Click()
    'MsgBox zgblDragDrop
'End Sub


'Load a picture: Picture1.Picture = LoadPicture("c:\123.bmp")
'Save a picture: SavePicture Picture1.Picture, "c:\321.bmp"
Dim zInfoAID As String
Dim zInfoMID As String
Dim zInfoOID As String
Dim zInfoAGID As String
Dim zInfoMGID As String
Dim zInfoOGID As String
Dim zInfoGOID As String
Dim zInfoXYZ As String

Private Sub Form_Activate()
    gbllFormActivated = 2
    subWindowsPosition Me, "S"
End Sub

Private Sub Form_DblClick()
    subReset
    frmShowFileNames.Show
End Sub

Private Sub Form_Deactivate()
    subWindowsPosition Me, "S"
End Sub
Private Sub Form_Load()
On Error Resume Next
    subResetGraphics
    subWindowsPosition Me, "L"
    subWindowsFieldLoader Me, "L"
    tmrDisplay.Interval = 250
    tmrDisplay.Enabled = True
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "GMON" & vbCrLf
End Sub
Private Sub Form_Unload(Cancel As Integer)
    tmrDisplay.Enabled = False
    subWindowsPosition Me, "S"
    subWindowsFieldLoader Me, "S"
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "GMOFF" & vbCrLf
End Sub
Private Sub subResetGraphics()
    Set pbAreaAID.Picture = Nothing
    Set pbMID.Picture = Nothing
    Set pbOID.Picture = Nothing
End Sub
Private Sub subReset()
On Error Resume Next
    zInfoXYZ = ""
    zInfoAID = ""
    zInfoMID = ""
    zInfoOID = ""
    zInfoAGID = ""
    zInfoMGID = ""
    zInfoOGID = ""
    gblzInfoXYZ = ""
    gblzInfoAID = ""
    gblzInfoAGID = ""
    gblzInfoMID = ""
    gblzInfoMGID = ""
    gblzInfoOID = ""
    gblzInfoOGID = ""
    gblzInfoAreaWhere = ""
    frmMain.txtSendClientData.SetFocus
    subResetGraphics
End Sub

Private Sub tmrDisplay_Timer()
On Error GoTo Err_Check
    Dim zFilePathAndFileName As String
    Dim zFilename As String
    
    'Load Area
    If (zInfoAID <> gblzInfoAID) Then 'we already displayed this spot
        If (Len(gblzInfoAID) <> 0) Then
            zFilename = (gblzInfoAID) & ".bmp"
            frmAreaViewerSaver.Caption = "Area (" & zFilename & ")"
            pbAreaAID.ToolTipText = zFilename
            zFilePathAndFileName = gblzAppPathPicturesA & "\" & zFilename
            If (bFileExists(zFilePathAndFileName)) Then
                pbAreaAID.Picture = LoadPicture(zFilePathAndFileName)
            Else
                If (Len(gblzInfoAGID) <> 0) Then
                    zFilename = (gblzInfoAGID)
                    frmAreaViewerSaver.Caption = (frmAreaViewerSaver.Caption & " GID(" & zFilename & ")")
                    pbAreaAID.ToolTipText = pbAreaAID.ToolTipText & "GID(" & zFilename & ")"
                    zFilePathAndFileName = gblzAppPathPicturesA & "\" & zFilename
                    If (bFileExists(zFilePathAndFileName)) Then
                        pbAreaAID.Picture = Nothing
                        pbAreaAID.Picture = LoadPicture(zFilePathAndFileName)
                    End If
                End If
            End If
        End If
    End If
    zInfoAID = gblzInfoAID
    
    'Load Mob
    If (zInfoMID <> gblzInfoMID) Then 'we already displayed this spot
        If (Len(gblzInfoMID) <> 0) Then
            zFilename = (gblzInfoMID) & ".bmp"
            pbMID.ToolTipText = "Mob Filename (" & zFilename & ")"
            zFilePathAndFileName = gblzAppPathPicturesM & "\" & zFilename
            If (bFileExists(zFilePathAndFileName)) Then
                pbMID.Picture = LoadPicture(zFilePathAndFileName)
            Else
                If (Len(gblzInfoMGID) <> 0) Then
                    zFilename = (gblzInfoMGID)
                    pbMID.ToolTipText = pbMID.ToolTipText & " GID(" & zFilename & ")"
                    zFilePathAndFileName = gblzAppPathPicturesM & "\" & zFilename
                    If (bFileExists(zFilePathAndFileName)) Then
                        pbMID.Picture = Nothing
                        pbMID.Picture = LoadPicture(zFilePathAndFileName)
                    End If
                End If
            End If
        End If
    End If
    zInfoMID = gblzInfoMID
    
    'Load Object
    If (zInfoOID <> gblzInfoOID) Then 'we already displayed this spot
        If (Len(gblzInfoOID) <> 0) Then
            zFilename = (gblzInfoOID) & ".bmp"
            pbOID.ToolTipText = "Object Filename (" & zFilename & ")"
            zFilePathAndFileName = gblzAppPathPicturesO & "\" & zFilename
            If (bFileExists(zFilePathAndFileName)) Then
                pbOID.Picture = LoadPicture(zFilePathAndFileName)
            Else
                If (Len(gblzInfoOGID) <> 0) Then
                    zFilename = (gblzInfoOGID)
                    pbOID.ToolTipText = pbOID.ToolTipText & " GID(" & zFilename & ")"
                    zFilePathAndFileName = gblzAppPathPicturesO & "\" & zFilename
                    If (bFileExists(zFilePathAndFileName)) Then
                        pbOID.Picture = Nothing
                        pbOID.Picture = LoadPicture(zFilePathAndFileName)
                    End If
                End If
            End If
        End If
    End If
    zInfoOID = gblzInfoOID
    Exit Sub
Err_Check:
    MsgBox "tmrDisplay_Timer," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

