VERSION 5.00
Begin VB.Form frmFontTweeker 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Font Tweeker"
   ClientHeight    =   5055
   ClientLeft      =   30
   ClientTop       =   360
   ClientWidth     =   7485
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   7.5
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5055
   ScaleWidth      =   7485
   Begin VB.CommandButton cmdAboutFontLookUpGeneralEditor 
      Caption         =   "?"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   312
      Left            =   5880
      TabIndex        =   7
      Top             =   4680
      Width           =   255
   End
   Begin VB.CommandButton cmdDELETEALL 
      Caption         =   "Command1"
      Height          =   252
      Left            =   0
      TabIndex        =   6
      Top             =   720
      Width           =   132
   End
   Begin VB.TextBox txtFontValueMax 
      Appearance      =   0  'Flat
      Height          =   288
      Left            =   1560
      TabIndex        =   2
      ToolTipText     =   "MAX Font Size range: Set to 1 to disable me"
      Top             =   4680
      Width           =   1092
   End
   Begin VB.TextBox txtFontValueMin 
      Appearance      =   0  'Flat
      Height          =   288
      Left            =   240
      TabIndex        =   1
      ToolTipText     =   "Min Font Size range: Set to 1 to disable me"
      Top             =   4680
      Width           =   1092
   End
   Begin VB.CommandButton cmdFontListSave 
      Caption         =   "&Save"
      Height          =   312
      Left            =   6120
      TabIndex        =   4
      Top             =   4680
      Width           =   1092
   End
   Begin VB.TextBox txtFontHeightAdjust 
      Appearance      =   0  'Flat
      Height          =   288
      Left            =   2880
      MaxLength       =   4
      TabIndex        =   3
      ToolTipText     =   "This is a PERMINANT OVERRIDE - but who cares, you can push the command prompt down as far as you like with this form."
      Top             =   4680
      Width           =   1212
   End
   Begin VB.ListBox lstFontLookUp 
      Appearance      =   0  'Flat
      Height          =   4320
      Left            =   240
      TabIndex        =   0
      Top             =   120
      Width           =   6972
   End
   Begin VB.Label lblFontTextID 
      BackColor       =   &H000000FF&
      Caption         =   "X"
      Height          =   132
      Left            =   0
      TabIndex        =   5
      Top             =   240
      Visible         =   0   'False
      Width           =   132
   End
End
Attribute VB_Name = "frmFontTweeker"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub cmdAboutFontLookUpGeneralEditor_Click()
    MsgBox "Font Tweeker brings up the entire list of your system Fonts." & vbCrLf & vbCrLf & "Set both min and max to one and SAVE to disable this ranging, which is the default." & vbCrLf & vbCrLf & "Our autodetect system will try to set your command prompt but here you can now set that value to OVERRIDE, which is what you should ALWAYS do for all your fonts, dont use the systems, my math is bad.", vbInformation
End Sub

Private Sub cmdDELETEALL_Click()
    MyDB.Execute "delete * from tblFontLookup;"
End Sub

Private Sub Form_Load()
    subFontLookUpPopulateListbox
End Sub

Private Sub subFontLookUpPopulateListbox()
On Error GoTo Err_Check
    Dim rsFonts As Recordset
    Set rsFonts = MyDB.OpenRecordset("SELECT FontLookUpID, FontLookUpText, FontValueMin, FontValueMax, FontHeightAdjust FROM tblFontLookup ORDER BY FontLookUpText;", dbOpenSnapshot)
    Do While (Not rsFonts.EOF)
        lstFontLookUp.AddItem UCase(MyCStr(rsFonts!FontLookUpText))
        lstFontLookUp.ItemData(lstFontLookUp.ListCount - 1) = rsFonts!FontLookUpID
        rsFonts.MoveNext
    Loop
    Set rsFonts = Nothing
    Exit Sub
Err_Check:
    MsgBox "subFontLookUpPopulateListbox," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub cmdFontListSave_Click()
On Error GoTo Err_Check
    Dim rsFonts As Recordset
    Dim lFontTextID As Long
    
    lFontTextID = MyCLng(lblFontTextID.Caption)
    If (lFontTextID <> 0) Then
        Set rsFonts = MyDB.OpenRecordset("SELECT FontLookUpText, FontValueMin, FontValueMax, FontHeightAdjust FROM tblFontLookup WHERE FontLookUpID=" & lFontTextID & " ORDER BY FontLookUpText;", dbOpenDynaset)
        If (Not rsFonts.EOF) Then
            rsFonts.Edit 'AddNew comes from the Fonts List maker in frmChangefont
            rsFonts!FontValueMin = MyCLng(txtFontValueMin.Text)
            rsFonts!FontValueMax = MyCLng(txtFontValueMax.Text)
            rsFonts!FontHeightAdjust = MyCLng(txtFontHeightAdjust.Text)
            rsFonts.Update
        End If
        Set rsFonts = Nothing
    End If
    subOrganizeMainTerminalForm
    Exit Sub
Err_Check:
    MsgBox "subFontLookUpPopulateListbox," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub lstFontLookUp_Click()
On Error GoTo Err_Check
    Dim rsSetUp As Recordset
    Dim lFontTextID As Long
    
    lFontTextID = MyCLng(lstFontLookUp.ItemData(lstFontLookUp.ListIndex))
    If (lFontTextID <> 0) Then
        Set rsSetUp = MyDB.OpenRecordset("SELECT FontLookUpID, FontLookUpText, FontValueMin, FontValueMax, FontHeightAdjust FROM tblFontLookup WHERE FontLookUpID=" & lFontTextID & " ORDER BY FontLookUpText;", dbOpenSnapshot)
        If (Not rsSetUp.EOF) Then
            subNew
            lblFontTextID.Caption = MyCStr(rsSetUp!FontLookUpID)
            txtFontValueMin.Text = MyCLng(rsSetUp!FontValueMin)
            txtFontValueMax.Text = MyCLng(rsSetUp!FontValueMax)
            txtFontHeightAdjust.Text = MyCLng(rsSetUp!FontHeightAdjust)
        End If
        Set rsSetUp = Nothing
    Else
        
    End If
    Exit Sub
Err_Check:
    MsgBox "lstFontLookUp_Click," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub
Private Sub subNew()
On Error Resume Next
    lblFontTextID.Caption = "0"
    txtFontValueMin.Text = ""
    txtFontValueMax.Text = ""
    txtFontHeightAdjust.Text = ""
End Sub
