VERSION 5.00
Begin VB.Form frmCharacterWindow 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Commands"
   ClientHeight    =   6645
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4680
   Icon            =   "frmCharacterWindow.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   6645
   ScaleWidth      =   4680
   Begin VB.PictureBox picBackground 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   6495
      Left            =   120
      ScaleHeight     =   6465
      ScaleWidth      =   4425
      TabIndex        =   0
      Top             =   120
      Width           =   4455
      Begin VB.PictureBox Picture1 
         Appearance      =   0  'Flat
         BackColor       =   &H00808080&
         ForeColor       =   &H80000008&
         Height          =   1575
         Left            =   120
         ScaleHeight     =   1545
         ScaleWidth      =   4185
         TabIndex        =   28
         Top             =   4560
         Width           =   4215
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "TEACHER"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   12
            Left            =   3120
            Style           =   1  'Graphical
            TabIndex        =   58
            ToolTipText     =   "Lists something at the merchant, then you want to BUY ITEMNAME."
            Top             =   600
            Width           =   975
         End
         Begin VB.CommandButton cmdDream 
            Appearance      =   0  'Flat
            Caption         =   "Dream"
            Height          =   255
            Left            =   120
            TabIndex        =   44
            ToolTipText     =   "Activate a Stargate in the area, type the code at the send command line."
            Top             =   840
            Width           =   615
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "SCAN OBJs"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   11
            Left            =   1440
            Style           =   1  'Graphical
            TabIndex        =   42
            ToolTipText     =   "SLEEP [regenerate faster]"
            Top             =   1080
            Width           =   615
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "SCAN MOBs"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   10
            Left            =   720
            Style           =   1  'Graphical
            TabIndex        =   41
            ToolTipText     =   "SLEEP [regenerate faster]"
            Top             =   1080
            Width           =   735
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "SCAN"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   9
            Left            =   120
            Style           =   1  'Graphical
            TabIndex        =   40
            ToolTipText     =   "SLEEP [regenerate faster]"
            Top             =   1080
            Width           =   615
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "WAKE"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Index           =   8
            Left            =   1440
            Style           =   1  'Graphical
            TabIndex        =   38
            ToolTipText     =   "WAKE UP [stop regenerating faster["
            Top             =   600
            Width           =   615
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "STAND"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   495
            Index           =   7
            Left            =   720
            Style           =   1  'Graphical
            TabIndex        =   37
            ToolTipText     =   "STAND, ready to move and fight!"
            Top             =   600
            Width           =   735
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "SLEEP"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   255
            Index           =   6
            Left            =   120
            Style           =   1  'Graphical
            TabIndex        =   36
            ToolTipText     =   "SLEEP [regenerate faster]"
            Top             =   600
            Width           =   615
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "MAGIC SCRY"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   5
            Left            =   2160
            Style           =   1  'Graphical
            TabIndex        =   35
            Top             =   1080
            Width           =   1935
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "MERCHANT"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   4
            Left            =   2160
            Style           =   1  'Graphical
            TabIndex        =   33
            ToolTipText     =   "Lists something at the merchant, then you want to BUY ITEMNAME."
            Top             =   600
            Width           =   975
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "MAP"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   3
            Left            =   2160
            Style           =   1  'Graphical
            TabIndex        =   32
            Top             =   120
            Width           =   1935
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   " D"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   2
            Left            =   1440
            Style           =   1  'Graphical
            TabIndex        =   31
            ToolTipText     =   "STANCE DEFENSIVE [more ac less hr]"
            Top             =   120
            Width           =   615
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "N"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   1
            Left            =   720
            Style           =   1  'Graphical
            TabIndex        =   30
            ToolTipText     =   "STANCE NORMAL"
            Top             =   120
            Width           =   735
         End
         Begin VB.CommandButton cmdCharCombat 
            Appearance      =   0  'Flat
            Caption         =   "A"
            BeginProperty Font 
               Name            =   "Terminal"
               Size            =   6
               Charset         =   255
               Weight          =   700
               Underline       =   0   'False
               Italic          =   0   'False
               Strikethrough   =   0   'False
            EndProperty
            Height          =   375
            Index           =   0
            Left            =   120
            Style           =   1  'Graphical
            TabIndex        =   29
            ToolTipText     =   "STANCE AGGRESSIVE [more hr less ac]"
            Top             =   120
            Width           =   615
         End
      End
      Begin VB.PictureBox picCharSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         ForeColor       =   &H80000008&
         Height          =   3375
         Left            =   2280
         ScaleHeight     =   3345
         ScaleWidth      =   2025
         TabIndex        =   14
         Top             =   1080
         Width           =   2055
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00FF80FF&
            Caption         =   "FLEE"
            Height          =   315
            Index           =   9
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   24
            Top             =   2640
            Width           =   1695
         End
         Begin VB.CommandButton cmdPageLost 
            Appearance      =   0  'Flat
            Caption         =   "GLORY QUESTS"
            Height          =   375
            Left            =   240
            TabIndex        =   57
            Top             =   1800
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "UNKEEP"
            Height          =   255
            Index           =   3
            Left            =   1080
            Style           =   1  'Graphical
            TabIndex        =   26
            ToolTipText     =   "For free UNKEEP your removed Inventory items to SELL/TRADE/DROP andor SACRIFICE"
            Top             =   3000
            Width           =   855
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "KEEP"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   25
            ToolTipText     =   "For free KEEP your worn Equipment items SAFE."
            Top             =   3000
            Width           =   855
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SAC/CLEAN ROOM"
            Height          =   375
            Index           =   8
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   23
            Top             =   2160
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "LEARN TREE"
            Height          =   255
            Index           =   7
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   22
            Top             =   720
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SPELL STRENGTH"
            Height          =   255
            Index           =   6
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   21
            ToolTipText     =   "Both your heal and damage spells will list their potency. Wisdom and Intelligence adds to them in their own way."
            Top             =   1440
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SPELL CAST COST"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   20
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "PRACTICED SPELLS"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   19
            ToolTipText     =   "This is your book of spells."
            Top             =   960
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SCORE"
            Height          =   255
            Index           =   3
            Left            =   1080
            Style           =   1  'Graphical
            TabIndex        =   18
            Top             =   480
            Width           =   855
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SLIST"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   17
            Top             =   480
            Width           =   855
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "EQ"
            Height          =   255
            Index           =   1
            Left            =   1080
            Style           =   1  'Graphical
            TabIndex        =   16
            ToolTipText     =   "This will bring reveal your worn items."
            Top             =   120
            Width           =   855
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "INV"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   15
            ToolTipText     =   "This will bring up your inventory."
            Top             =   120
            Width           =   855
         End
      End
      Begin VB.Timer tmrPhaserAnimation 
         Enabled         =   0   'False
         Interval        =   300
         Left            =   120
         Top             =   0
      End
      Begin VB.PictureBox picStarport 
         Appearance      =   0  'Flat
         BackColor       =   &H000040C0&
         ForeColor       =   &H80000008&
         Height          =   975
         Left            =   2280
         ScaleHeight     =   945
         ScaleWidth      =   2145
         TabIndex        =   9
         Top             =   120
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C0C0&
            Caption         =   "FAST-FREE-FIRE"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   11
            ToolTipText     =   "Resets your battery so you can fire phasers again!"
            Top             =   600
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C0C0&
            Caption         =   "FIRE PHASERS"
            Height          =   375
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   10
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picOther 
         Appearance      =   0  'Flat
         BackColor       =   &H00C0C000&
         ForeColor       =   &H80000008&
         Height          =   2655
         Left            =   120
         ScaleHeight     =   2625
         ScaleWidth      =   2145
         TabIndex        =   5
         Top             =   1800
         Width           =   2175
         Begin VB.CommandButton cmdMapStars 
            Appearance      =   0  'Flat
            Caption         =   "Navigator"
            Height          =   255
            Left            =   1080
            TabIndex        =   59
            ToolTipText     =   "Activate a Stargate in the area, type the code at the send command line."
            Top             =   1200
            Width           =   855
         End
         Begin VB.PictureBox picThusters 
            Appearance      =   0  'Flat
            BackColor       =   &H00FFFFC0&
            ForeColor       =   &H80000008&
            Height          =   735
            Left            =   120
            ScaleHeight     =   705
            ScaleWidth      =   1905
            TabIndex        =   45
            Top             =   1800
            Width           =   1935
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   " NW"
               Height          =   255
               Index           =   7
               Left            =   120
               Style           =   1  'Graphical
               TabIndex        =   55
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   0
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   " N"
               Height          =   255
               Index           =   8
               Left            =   720
               Style           =   1  'Graphical
               TabIndex        =   54
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   0
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   " NE"
               Height          =   255
               Index           =   9
               Left            =   1320
               Style           =   1  'Graphical
               TabIndex        =   53
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   0
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   " W"
               Height          =   255
               Index           =   10
               Left            =   120
               Style           =   1  'Graphical
               TabIndex        =   52
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   240
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   "u"
               Height          =   255
               Index           =   11
               Left            =   720
               Style           =   1  'Graphical
               TabIndex        =   51
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   240
               Width           =   255
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   "d"
               Height          =   255
               Index           =   12
               Left            =   960
               Style           =   1  'Graphical
               TabIndex        =   50
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   240
               Width           =   255
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   "E"
               Height          =   255
               Index           =   13
               Left            =   1320
               Style           =   1  'Graphical
               TabIndex        =   49
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   240
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   "SW"
               Height          =   255
               Index           =   14
               Left            =   120
               Style           =   1  'Graphical
               TabIndex        =   48
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   480
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   "S"
               Height          =   255
               Index           =   15
               Left            =   720
               Style           =   1  'Graphical
               TabIndex        =   47
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   480
               Width           =   495
            End
            Begin VB.CommandButton cmdShipoffs 
               Appearance      =   0  'Flat
               BackColor       =   &H00FFC0C0&
               Caption         =   "SE"
               Height          =   255
               Index           =   16
               Left            =   1320
               Style           =   1  'Graphical
               TabIndex        =   46
               ToolTipText     =   "Starship Thrusters, moves one area."
               Top             =   480
               Width           =   495
            End
         End
         Begin VB.CommandButton cmdEngage 
            Appearance      =   0  'Flat
            Caption         =   "Engage"
            Height          =   255
            Left            =   1080
            TabIndex        =   43
            ToolTipText     =   "The starship will be commanded to 'All Stop' and will drop out of warp and stop moving."
            Top             =   840
            Width           =   855
         End
         Begin VB.CommandButton cmdStargate 
            Appearance      =   0  'Flat
            Caption         =   "Stargate"
            Height          =   255
            Left            =   240
            TabIndex        =   39
            ToolTipText     =   "Activate a Stargate in the area, type the code at the send command line."
            Top             =   1200
            Width           =   855
         End
         Begin VB.CommandButton cmdSTOP 
            Appearance      =   0  'Flat
            Caption         =   "All Stop"
            Height          =   255
            Left            =   240
            TabIndex        =   27
            ToolTipText     =   "The starship will be commanded to 'All Stop' and will drop out of warp and stop moving."
            Top             =   840
            Width           =   855
         End
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "City of Ages Centre"
            Height          =   375
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   7
            ToolTipText     =   "Plot a Course, destination: City of Ages...ENGAGE!"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "Ancient Red Planet"
            Height          =   375
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   6
            ToolTipText     =   "Plot a Course, destination: Ancient Red Planet...ENGAGE!"
            Top             =   120
            Width           =   1695
         End
         Begin VB.Label lblThusters 
            Alignment       =   2  'Center
            Appearance      =   0  'Flat
            BackColor       =   &H00FFFFC0&
            BorderStyle     =   1  'Fixed Single
            Caption         =   "T H R U S T E R S"
            ForeColor       =   &H00000000&
            Height          =   255
            Left            =   120
            TabIndex        =   56
            Top             =   1560
            Width           =   1935
         End
      End
      Begin VB.PictureBox picStarship 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   1695
         Left            =   120
         ScaleHeight     =   1665
         ScaleWidth      =   2145
         TabIndex        =   1
         Top             =   120
         Width           =   2175
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Reload Skills"
            Height          =   255
            Index           =   6
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   34
            ToolTipText     =   "Recall back to your Marked spot."
            Top             =   1320
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Recall"
            Height          =   255
            Index           =   5
            Left            =   1080
            Style           =   1  'Graphical
            TabIndex        =   13
            ToolTipText     =   "Recall back to your Marked spot."
            Top             =   960
            Width           =   855
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Mark"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   12
            ToolTipText     =   "Mark your spot then Recall later back."
            Top             =   960
            Width           =   855
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Beam Dn"
            Height          =   255
            Index           =   3
            Left            =   1080
            Style           =   1  'Graphical
            TabIndex        =   8
            ToolTipText     =   "BEAM DOWN!"
            Top             =   720
            Width           =   855
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Beam Up"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   4
            ToolTipText     =   "Once you purchase a starship you can board her!"
            Top             =   720
            Width           =   855
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Repair the Starship"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   3
            ToolTipText     =   "Repair your starship!"
            Top             =   360
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "BUY a STARSHIP"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   2
            ToolTipText     =   "$40000, one time purchase"
            Top             =   120
            Width           =   1695
         End
      End
   End
End
Attribute VB_Name = "frmCharacterWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim lTimerPA As Long
Dim lFlash As Long
Dim lTimerPAMax As Long

Private Sub cmdCharCombat_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "STAN A" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "STAN N" & vbCrLf
            Case 2
                frmMain.Winsock1.SendData "STAN D" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "MAP" & vbCrLf
            Case 4
                frmMain.Winsock1.SendData "MERC" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "SCRY" & vbCrLf
            Case 6
                frmMain.Winsock1.SendData "SLEEP" & vbCrLf
            Case 7
                frmMain.Winsock1.SendData "STAND" & vbCrLf
            Case 8
                frmMain.Winsock1.SendData "WAKE" & vbCrLf
            Case 9
                frmMain.Winsock1.SendData "SCAN" & vbCrLf
            Case 10
                frmMain.Winsock1.SendData "SCAN MOBILES" & vbCrLf
            Case 11
                frmMain.Winsock1.SendData "SCAN OBJECTS" & vbCrLf
            Case 12
                frmMain.Winsock1.SendData "TEACHER" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdCharoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "INVE" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "EQUI" & vbCrLf
            Case 2
                frmMain.Winsock1.SendData "SLIST" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "SCORE" & vbCrLf
            Case 4
                frmMain.Winsock1.SendData "PRAC" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "COST" & vbCrLf
            Case 6
                frmMain.Winsock1.SendData "DAMA" & vbCrLf
            Case 7
                frmMain.Winsock1.SendData "LEARN TREE" & vbCrLf
            Case 8
                frmMain.Winsock1.SendData "SAC" & vbCrLf & "CLEAN" & vbCrLf
            Case 9
                frmMain.Winsock1.SendData "FLEE" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdDream_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "DREAM" & vbCrLf
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdEngage_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "SS ENGAGE" & vbCrLf
End Sub

Private Sub cmdMapStars_Click()
    frmMapStars.Show
End Sub

Private Sub cmdOtheroffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0 'Ancient Red Planet
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf & "SS NAVI 0 0 -" & MyCStr(712 + lRandom(30)) & vbCrLf
            Case 1 'City of Ages Planatary Centre
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf & "SS NAVI 0 0 -" & MyCStr(20 + lRandom(50)) & vbCrLf
        End Select
    End If
   If (gblbAnimation) Then frmMain.tmrWARPENGAGED.Enabled = True
   If (gblbAnimation) Then frmPictureWarpDriveENGAGE.Show 'Do not do modal because non modal forms cant show
   Unload frmFleetWindow
   
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdSendoffs_Click(Index As Integer)
On Error Resume Next
    cmdSendoffs(0).BackColor = &HC0C0C0
    cmdSendoffs(1).BackColor = &HC0C0C0
    cmdSendoffs(2).BackColor = &HC0C0C0
    cmdSendoffs(3).BackColor = &HC0C0C0

    If (frmMain.Winsock1.State = 7) Then 'connected?
        lFlash = Index
        Select Case lFlash
            Case 0
                cmdSendoffs(lFlash).BackColor = &HFF&
                frmMain.Winsock1.SendData "SS FIRE" & vbCrLf
                frmCharacterWindow.tmrPhaserAnimation.Enabled = True
            Case 1
                cmdSendoffs(lFlash).BackColor = &HFF00FF
                frmMain.Winsock1.SendData "SS FREE" & vbCrLf
                frmCharacterWindow.tmrPhaserAnimation.Enabled = True
            Case 2
                frmMain.Winsock1.SendData "KEEP" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "UNKEEP" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdShipoffs_Click(Index As Integer)
On Error Resume Next
    Dim rsSetUp As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
        
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "SS BUY" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf
                'MsgBox "~E N E R G I Z E ~", vbOKOnly
                frmMain.tmrWARPENGAGED.Enabled = True
                If (gblbAnimation) Then frmPictureENERGIZE.Show 'Do not do modal because non modal forms cant show
                Unload frmFleetWindow
            Case 2
                frmMain.Winsock1.SendData "SS REPAIR" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "SS BEAM" & vbCrLf
                'MsgBox "~E N E R G I Z E ~", vbOKOnly
                frmMain.tmrWARPENGAGED.Enabled = True
                If (gblbAnimation) Then frmPictureBEAMDOWN.Show 'Do not do modal because non modal forms cant show
                Unload frmFleetWindow
            Case 4
                frmMain.Winsock1.SendData "MARK" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "RECA" & vbCrLf
            Case 6
                frmMain.Winsock1.SendData "RELOAD" & vbCrLf
            Case 7 To 16 'starship thrusting
                If (Len(gblzInfoXYZ) > 0) Then
                    subExtractXYZFromInfoXYZ gblzInfoXYZ, lX, lY, lZ
                    Select Case Index
                        Case 7 'nw
                            lX = lX - 1
                            lY = lY - 1
                        Case 8 'n
                            lY = lY - 1
                        Case 9 'ne
                            lX = lX + 1
                            lY = lY - 1
                        Case 10 'w
                            lX = lX - 1
                        Case 11 'u
                            lZ = lZ - 1
                        Case 12 'd
                            lZ = lZ + 1
                        Case 13 'e
                            lX = lX + 1
                        Case 14 'sw
                            lX = lX - 1
                            lY = lY + 1
                        Case 15 's
                            lY = lY + 1
                        Case 16 'se
                            lX = lX + 1
                            lY = lY + 1
                    End Select
                    frmMain.Winsock1.SendData "SS NAVI " & MyCStr(lX) & " " & MyCStr(lY) & " " & MyCStr(lZ) & vbCrLf
                Else
                    Beep
                End If
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
   Unload frmFleetWindow
End Sub

Private Sub cmdStargate_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "STAR " & MyCStr(frmMain.txtSendClientData.Text) & vbCrLf
    frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdSTOP_Click()
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "SS STOP" & vbCrLf
End Sub

Private Sub Form_Load()
On Error Resume Next
    lTimerPA = 0
    lFlash = -1
    lTimerPAMax = 8
    tmrPhaserAnimation.Enabled = False
    cmdSendoffs(0).BackColor = &HC0C0C0
    cmdSendoffs(1).BackColor = &HC0C0C0
    cmdSendoffs(2).BackColor = &HC0C0C0
    cmdSendoffs(3).BackColor = &HC0C0C0
    gblbFleetWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbFleetWindow = False
End Sub
Private Sub tmrPhaserAnimation_Timer()
On Error Resume Next
    If (lFlash > -1) Then
        lTimerPA = lTimerPA + 1
        If ((lTimerPA Mod 2 = 0)) Then 'check if Even then proceed
            cmdSendoffs(lFlash).BackColor = &HC0C0C0
        Else 'Odd
            Select Case lFlash
                Case 0
                    cmdSendoffs(lFlash).BackColor = &HFF&
                    lTimerPAMax = 8
                Case 1
                    cmdSendoffs(lFlash).BackColor = &HFF00FF
                    lTimerPAMax = 4
            End Select
        End If
        
        If (lTimerPA > lTimerPAMax + 1) Then 'the +1 is to color is gray again first, up top there of this PROC
            lTimerPA = 0
            lFlash = -1
            tmrPhaserAnimation.Enabled = False
            'cmdSendoffs(lFlash).BackColor = &HC0C0C0
            frmMain.txtSendClientData.SetFocus
        End If
    Else
        tmrPhaserAnimation.Enabled = False
    End If
End Sub
Private Sub cmdPageLost_Click()
    If (frmMain.Winsock1.State = 7) Then frmMain.Winsock1.SendData "PAGE LOST" & vbCrLf & "PAGE CHESTS" & vbCrLf & "PAGE QUEST" & vbCrLf
End Sub

