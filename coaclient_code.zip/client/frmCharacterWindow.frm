VERSION 5.00
Begin VB.Form frmCharacterWindow 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Commands"
   ClientHeight    =   4560
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4815
   Icon            =   "frmCharacterWindow.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   4560
   ScaleWidth      =   4815
   Begin VB.PictureBox picBackground 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   4335
      Left            =   120
      ScaleHeight     =   4305
      ScaleWidth      =   4545
      TabIndex        =   0
      Top             =   120
      Width           =   4575
      Begin VB.Timer tmrPhaserAnimation 
         Enabled         =   0   'False
         Interval        =   300
         Left            =   0
         Top             =   600
      End
      Begin VB.PictureBox picStarport 
         Appearance      =   0  'Flat
         BackColor       =   &H000040C0&
         ForeColor       =   &H80000008&
         Height          =   3735
         Left            =   2280
         ScaleHeight     =   3705
         ScaleWidth      =   2145
         TabIndex        =   10
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C0C0&
            Caption         =   "FAST FREEFIRE"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   12
            ToolTipText     =   "$4615"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C0C0&
            Caption         =   "FIRE PHASERS"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   11
            ToolTipText     =   "$25250"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picOther 
         Appearance      =   0  'Flat
         BackColor       =   &H00C0C000&
         ForeColor       =   &H80000008&
         Height          =   975
         Left            =   120
         ScaleHeight     =   945
         ScaleWidth      =   2145
         TabIndex        =   6
         Top             =   3240
         Width           =   2175
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "City of Ages Centre"
            Height          =   375
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   8
            ToolTipText     =   "Set Course to Ancient Red Planet Starbase...ENGAGE!"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "Ancient Red Planet"
            Height          =   375
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   7
            ToolTipText     =   "Set Course to Ancient Red Planet Starbase...ENGAGE!"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picStarship 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2775
         Left            =   120
         ScaleHeight     =   2745
         ScaleWidth      =   2145
         TabIndex        =   1
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Recall"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   14
            ToolTipText     =   "Recall back to your Marked spot."
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Mark"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   13
            ToolTipText     =   "Mark your spot then Recall later back."
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "BEAM to Disembark"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   9
            ToolTipText     =   "Once you purchase a starship you can board her!"
            Top             =   840
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "ENERGIZE && Board"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   5
            ToolTipText     =   "Once you purchase a starship you can board her!"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Repair"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   3
            ToolTipText     =   "Repair your starship!"
            Top             =   2280
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "BUY a starship"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   2
            ToolTipText     =   "$40000, one time purchase"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Label lblStarport 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "C H A R A C T E R  COMMANDS"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Left            =   0
         TabIndex        =   4
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
End
Attribute VB_Name = "frmCharacterWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim lTimerPA As Long
Dim lFlash As Long

Private Sub cmdOtheroffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0 'Ancient Red Planet
                frmMain.Winsock1.SendData "SS NAVI 0 0 -" & MyCStr(712 + lRandom(30)) & vbCrLf
            Case 1 'City of Ages Planatary Centre
                frmMain.Winsock1.SendData "SS NAVI 0 0 -" & MyCStr(20 + lRandom(50)) & vbCrLf
        End Select
    End If
   frmMain.tmrWARPENGAGED.Enabled = True
   frmPictureWarpDriveENGAGE.Show 1 'modal is best
   Unload frmFleetWindow
   
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdSendoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        lFlash = Index
        Select Case lFlash
            Case 0
                cmdSendoffs(2).BackColor = &HFF&
                frmMain.Winsock1.SendData "SS FIRE" & vbCrLf
                frmCharacterWindow.tmrPhaserAnimation.Enabled = True
            Case 1
                cmdSendoffs(2).BackColor = &HFF00FF
                frmMain.Winsock1.SendData "SS FREEFIRE" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdShipoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "SS BUY" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf
                'MsgBox "~E N E R G I Z E ~", vbOKOnly
                frmMain.tmrWARPENGAGED.Enabled = True
                frmPictureENERGIZE.Show 1 'modal is best
                Unload frmFleetWindow
            Case 2
                frmMain.Winsock1.SendData "SS REPAIR" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "SS BEAM" & vbCrLf
                'MsgBox "~E N E R G I Z E ~", vbOKOnly
                frmMain.tmrWARPENGAGED.Enabled = True
                frmPictureBEAMDOWN.Show 1 'modal is best
                Unload frmFleetWindow
            Case 4
                frmMain.Winsock1.SendData "MARK" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "RECA" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
   Unload frmFleetWindow
End Sub

Private Sub Form_Load()
    lTimerPA = -1
    lFlash = -1
    tmrPhaserAnimation.Enabled = False
    cmdSendoffs(0).BackColor = &HC0C0C0
    cmdSendoffs(1).BackColor = &HC0C0C0

    gblbFleetWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbFleetWindow = False
End Sub
Private Sub tmrPhaserAnimation_Timer()
    lTimerPA = lTimerPA + 1
    If ((lTimerPA Mod 2 = 0)) Then 'Even ??
        cmdSendoffs(0).BackColor = &HC0C0C0
        cmdSendoffs(1).BackColor = &HC0C0C0
    Else 'Odd
        If lFlash = 0 Then cmdSendoffs(0).BackColor = &HFF&
        If lFlash = 1 Then cmdSendoffs(1).BackColor = &HFF00FF
    End If
    
    If (lTimerPA > 12) Then
        lTimerPA = -1
        lFlash = -1
        tmrPhaserAnimation.Enabled = False
        cmdSendoffs(0).BackColor = &HC0C0C0
        cmdSendoffs(1).BackColor = &HC0C0C0
        frmMain.txtSendClientData.SetFocus
    End If
End Sub
