VERSION 5.00
Begin VB.Form frmCharacterWindow 
   Appearance      =   0  'Flat
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Commands"
   ClientHeight    =   5100
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4815
   Icon            =   "frmCharacterWindow.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   5100
   ScaleWidth      =   4815
   Begin VB.PictureBox picBackground 
      Appearance      =   0  'Flat
      BackColor       =   &H00400040&
      ForeColor       =   &H80000008&
      Height          =   4935
      Left            =   120
      ScaleHeight     =   4905
      ScaleWidth      =   4545
      TabIndex        =   0
      Top             =   120
      Width           =   4575
      Begin VB.PictureBox picCharSheet 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         ForeColor       =   &H80000008&
         Height          =   3375
         Left            =   2280
         ScaleHeight     =   3345
         ScaleWidth      =   2145
         TabIndex        =   15
         Top             =   1440
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "UNKEEP"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   26
            ToolTipText     =   "For free UNKEEP your removed Inventory items to SELL/TRADE/DROP andor SACRIFICE"
            Top             =   3000
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            Caption         =   "KEEP"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   25
            ToolTipText     =   "For free KEEP your worn Equipment items SAFE."
            Top             =   2760
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SAC/CLEAN ROOM"
            Height          =   255
            Index           =   8
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   24
            Top             =   2400
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "LEARNT TREE"
            Height          =   255
            Index           =   7
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   23
            Top             =   960
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SPELL STRENGTH"
            Height          =   255
            Index           =   6
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   22
            ToolTipText     =   "Both your heal and damage spells will list their potency. Wisdom and Intelligence adds to them in their own way."
            Top             =   2040
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SPELL CAST COST"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   21
            Top             =   1800
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "PRACTICED SPELLS"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   20
            ToolTipText     =   "This is your book of spells."
            Top             =   1560
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SCORE"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   19
            Top             =   1200
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "SLIST"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   18
            Top             =   720
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "EQUIPMENT"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   17
            ToolTipText     =   "This will bring reveal your worn items."
            Top             =   360
            Width           =   1695
         End
         Begin VB.CommandButton cmdCharoffs 
            Appearance      =   0  'Flat
            Caption         =   "INVENTORY"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   16
            ToolTipText     =   "This will bring up your inventory."
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Timer tmrPhaserAnimation 
         Enabled         =   0   'False
         Interval        =   300
         Left            =   120
         Top             =   0
      End
      Begin VB.PictureBox picStarport 
         Appearance      =   0  'Flat
         BackColor       =   &H000040C0&
         ForeColor       =   &H80000008&
         Height          =   975
         Left            =   2280
         ScaleHeight     =   945
         ScaleWidth      =   2145
         TabIndex        =   10
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C0C0&
            Caption         =   "FAST-FREE-FIRE"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   12
            ToolTipText     =   "Resets your battery so you can fire phasers again!"
            Top             =   600
            Width           =   1695
         End
         Begin VB.CommandButton cmdSendoffs 
            Appearance      =   0  'Flat
            BackColor       =   &H00C0C0C0&
            Caption         =   "FIRE PHASERS"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   11
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picOther 
         Appearance      =   0  'Flat
         BackColor       =   &H00C0C000&
         ForeColor       =   &H80000008&
         Height          =   1575
         Left            =   120
         ScaleHeight     =   1545
         ScaleWidth      =   2145
         TabIndex        =   6
         Top             =   3240
         Width           =   2175
         Begin VB.CommandButton cmdSTOP 
            Appearance      =   0  'Flat
            Caption         =   "Drop out of Warp"
            Height          =   255
            Left            =   240
            TabIndex        =   27
            ToolTipText     =   "The starship will be commanded to 'All Stop' and will drop out of warp and stop moving."
            Top             =   960
            Width           =   1695
         End
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "City of Ages Centre"
            Height          =   375
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   8
            ToolTipText     =   "Set Course to City of Ages...ENGAGE!"
            Top             =   480
            Width           =   1695
         End
         Begin VB.CommandButton cmdOtheroffs 
            Appearance      =   0  'Flat
            Caption         =   "Ancient Red Planet"
            Height          =   375
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   7
            ToolTipText     =   "Set Course to the City of Ages Centre...ENGAGE!"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.PictureBox picStarship 
         Appearance      =   0  'Flat
         BackColor       =   &H0000C0C0&
         ForeColor       =   &H80000008&
         Height          =   2775
         Left            =   120
         ScaleHeight     =   2745
         ScaleWidth      =   2145
         TabIndex        =   1
         Top             =   480
         Width           =   2175
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Recall"
            Height          =   255
            Index           =   5
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   14
            ToolTipText     =   "Recall back to your Marked spot."
            Top             =   1680
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Mark"
            Height          =   255
            Index           =   4
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   13
            ToolTipText     =   "Mark your spot then Recall later back."
            Top             =   1440
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Beam Down"
            Height          =   255
            Index           =   3
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   9
            ToolTipText     =   "BEAM DOWN!"
            Top             =   960
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Board Starship"
            Height          =   255
            Index           =   1
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   5
            ToolTipText     =   "Once you purchase a starship you can board her!"
            Top             =   720
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "Repair the Starship"
            Height          =   255
            Index           =   2
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   3
            ToolTipText     =   "Repair your starship!"
            Top             =   360
            Width           =   1695
         End
         Begin VB.CommandButton cmdShipoffs 
            Appearance      =   0  'Flat
            Caption         =   "BUY a STARSHIP"
            Height          =   255
            Index           =   0
            Left            =   240
            Style           =   1  'Graphical
            TabIndex        =   2
            ToolTipText     =   "$40000, one time purchase"
            Top             =   120
            Width           =   1695
         End
      End
      Begin VB.Label lblStarport 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BackStyle       =   0  'Transparent
         Caption         =   "C H A R A C T E R  COMMANDS"
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   14.25
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   375
         Left            =   0
         TabIndex        =   4
         ToolTipText     =   "All prices in GOLD!"
         Top             =   0
         Width           =   4575
      End
   End
End
Attribute VB_Name = "frmCharacterWindow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim lTimerPA As Long
Dim lFlash As Long
Dim lTimerPAMax As Long

Private Sub cmdCharoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "INVE" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "EQUI" & vbCrLf
            Case 2
                frmMain.Winsock1.SendData "SLIST" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "SCORE" & vbCrLf
            Case 4
                frmMain.Winsock1.SendData "PRAC" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "COST" & vbCrLf
            Case 6
                frmMain.Winsock1.SendData "DAMA" & vbCrLf
            Case 7
                frmMain.Winsock1.SendData "LEARN TREE" & vbCrLf
            Case 8
                frmMain.Winsock1.SendData "SAC" & vbCrLf & "CLEAN" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdOtheroffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0 'Ancient Red Planet
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf & "SS NAVI 0 0 -" & MyCStr(712 + lRandom(30)) & vbCrLf
            Case 1 'City of Ages Planatary Centre
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf & "SS NAVI 0 0 -" & MyCStr(20 + lRandom(50)) & vbCrLf
        End Select
    End If
   frmMain.tmrWARPENGAGED.Enabled = True
   frmPictureWarpDriveENGAGE.Show 'Do not do modal because non modal forms cant show
   Unload frmFleetWindow
   
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdSendoffs_Click(Index As Integer)
On Error Resume Next
    cmdSendoffs(0).BackColor = &HC0C0C0
    cmdSendoffs(1).BackColor = &HC0C0C0
    cmdSendoffs(2).BackColor = &HC0C0C0
    cmdSendoffs(3).BackColor = &HC0C0C0

    If (frmMain.Winsock1.State = 7) Then 'connected?
        lFlash = Index
        Select Case lFlash
            Case 0
                cmdSendoffs(lFlash).BackColor = &HFF&
                frmMain.Winsock1.SendData "SS FIRE" & vbCrLf
                frmCharacterWindow.tmrPhaserAnimation.Enabled = True
            Case 1
                cmdSendoffs(lFlash).BackColor = &HFF00FF
                frmMain.Winsock1.SendData "SS FREE" & vbCrLf
                frmCharacterWindow.tmrPhaserAnimation.Enabled = True
            Case 2
                frmMain.Winsock1.SendData "KEEP" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "UNKEEP" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
End Sub

Private Sub cmdShipoffs_Click(Index As Integer)
On Error Resume Next
    If (frmMain.Winsock1.State = 7) Then 'connected?
        Select Case Index
            Case 0
                frmMain.Winsock1.SendData "SS BUY" & vbCrLf
            Case 1
                frmMain.Winsock1.SendData "SS BOARD" & vbCrLf
                'MsgBox "~E N E R G I Z E ~", vbOKOnly
                frmMain.tmrWARPENGAGED.Enabled = True
                frmPictureENERGIZE.Show 'Do not do modal because non modal forms cant show
                Unload frmFleetWindow
            Case 2
                frmMain.Winsock1.SendData "SS REPAIR" & vbCrLf
            Case 3
                frmMain.Winsock1.SendData "SS BEAM" & vbCrLf
                'MsgBox "~E N E R G I Z E ~", vbOKOnly
                frmMain.tmrWARPENGAGED.Enabled = True
                frmPictureBEAMDOWN.Show 'Do not do modal because non modal forms cant show
                Unload frmFleetWindow
            Case 4
                frmMain.Winsock1.SendData "MARK" & vbCrLf
            Case 5
                frmMain.Winsock1.SendData "RECA" & vbCrLf
        End Select
    End If
   frmMain.txtSendClientData.SetFocus
   Unload frmFleetWindow
End Sub

Private Sub cmdSTOP_Click()
On Error Resume Next
    frmMain.Winsock1.SendData "SS STOP" & vbCrLf
End Sub

Private Sub Form_Load()
On Error Resume Next
    lTimerPA = 0
    lFlash = -1
    lTimerPAMax = 8
    tmrPhaserAnimation.Enabled = False
    cmdSendoffs(0).BackColor = &HC0C0C0
    cmdSendoffs(1).BackColor = &HC0C0C0
    cmdSendoffs(2).BackColor = &HC0C0C0
    cmdSendoffs(3).BackColor = &HC0C0C0
    gblbFleetWindow = True
End Sub
Private Sub Form_Unload(Cancel As Integer)
    gblbFleetWindow = False
End Sub
Private Sub tmrPhaserAnimation_Timer()
On Error Resume Next
    If (lFlash > -1) Then
        lTimerPA = lTimerPA + 1
        If ((lTimerPA Mod 2 = 0)) Then 'check if Even then proceed
            cmdSendoffs(lFlash).BackColor = &HC0C0C0
        Else 'Odd
            Select Case lFlash
                Case 0
                    cmdSendoffs(lFlash).BackColor = &HFF&
                    lTimerPAMax = 8
                Case 1
                    cmdSendoffs(lFlash).BackColor = &HFF00FF
                    lTimerPAMax = 4
            End Select
        End If
        
        If (lTimerPA > lTimerPAMax + 1) Then 'the +1 is to color is gray again first, up top there of this PROC
            lTimerPA = 0
            lFlash = -1
            tmrPhaserAnimation.Enabled = False
            'cmdSendoffs(lFlash).BackColor = &HC0C0C0
            frmMain.txtSendClientData.SetFocus
        End If
    Else
        tmrPhaserAnimation.Enabled = False
    End If
End Sub
