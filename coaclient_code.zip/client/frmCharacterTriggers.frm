VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmCharacterTriggers 
   Appearance      =   0  'Flat
   BackColor       =   &H00FFC0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Character Profile - Triggers"
   ClientHeight    =   8010
   ClientLeft      =   150
   ClientTop       =   195
   ClientWidth     =   9375
   Icon            =   "frmCharacterTriggers.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   ScaleHeight     =   8010
   ScaleWidth      =   9375
   Begin VB.CommandButton cmdClearSoundPath 
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   8640
      Picture         =   "frmCharacterTriggers.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   4920
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.CommandButton cmdNew 
      Appearance      =   0  'Flat
      Caption         =   "&New"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   5
      Top             =   7680
      Width           =   975
   End
   Begin VB.CommandButton cmdLoad 
      Appearance      =   0  'Flat
      Caption         =   "&Load"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   6
      Top             =   7680
      Width           =   975
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5520
      TabIndex        =   7
      Top             =   7680
      Width           =   975
   End
   Begin VB.CommandButton cmdDelete 
      Appearance      =   0  'Flat
      Caption         =   "&Delete"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   8280
      Picture         =   "frmCharacterTriggers.frx":0B14
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   7680
      Width           =   975
   End
   Begin VB.PictureBox picEvents 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0E0FF&
      ForeColor       =   &H80000008&
      Height          =   1575
      Left            =   120
      ScaleHeight     =   1545
      ScaleWidth      =   9105
      TabIndex        =   11
      Top             =   3840
      Width           =   9135
      Begin VB.TextBox txtTriggerDesc 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   2400
         MaxLength       =   125
         TabIndex        =   2
         ToolTipText     =   "Your description to name"
         Top             =   120
         Width           =   6615
      End
      Begin VB.TextBox txtTriggerMatchingText 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   12
         TabIndex        =   1
         ToolTipText     =   "Your command trigger to name"
         Top             =   120
         Width           =   2175
      End
      Begin VB.TextBox txtTriggerProgrammedReply 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   255
         TabIndex        =   3
         ToolTipText     =   "Send to server string"
         Top             =   600
         Width           =   8895
      End
      Begin VB.TextBox txtSoundFilename 
         BeginProperty Font 
            Name            =   "Arial"
            Size            =   9.75
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   375
         Left            =   120
         MaxLength       =   222
         TabIndex        =   4
         ToolTipText     =   "When blank button will bring up the music browser or else it will play the sound file."
         Top             =   1080
         Visible         =   0   'False
         Width           =   8385
      End
      Begin VB.CommandButton cmdPlayer 
         Appearance      =   0  'Flat
         Height          =   375
         Left            =   8760
         Picture         =   "frmCharacterTriggers.frx":109E
         Style           =   1  'Graphical
         TabIndex        =   10
         Top             =   1080
         Visible         =   0   'False
         Width           =   255
      End
      Begin VB.Label lblTriggerTextID 
         Appearance      =   0  'Flat
         BackColor       =   &H000080FF&
         Caption         =   "X"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   12
         Top             =   120
         Visible         =   0   'False
         Width           =   135
      End
   End
   Begin VB.ListBox lstTriggers 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   9
         Charset         =   255
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3630
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   9135
   End
   Begin MSComDlg.CommonDialog CDlg1 
      Left            =   0
      Top             =   0
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label lblMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H00404040&
      BorderStyle     =   1  'Fixed Single
      Caption         =   $"frmCharacterTriggers.frx":1228
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   2055
      Left            =   120
      TabIndex        =   13
      Top             =   5520
      Width           =   9135
   End
End
Attribute VB_Name = "frmCharacterTriggers"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub subLoadAllTriggers()
    Dim rsSetUp As Recordset
    lstTriggers.Clear
    Set rsSetUp = MyDB.OpenRecordset("SELECT TriggerTextID, CharacterNameID, TriggerMatchingText, TriggerProgrammedReply, TriggerDesc FROM tblTriggerText WHERE CharacterNameID=" & gbllCharacterNameID & " ORDER BY TriggerMatchingText, TriggerProgrammedReply, TriggerTextID;", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        Do While (Not rsSetUp.EOF)
            lstTriggers.AddItem zForceSize(MyCStr(rsSetUp!TriggerMatchingText), 13, " ", "A") & MyCStr(rsSetUp!TriggerDesc)
            lstTriggers.ItemData(lstTriggers.ListCount - 1) = rsSetUp!TriggerTextID
            rsSetUp.MoveNext
        Loop
    End If
    Set rsSetUp = Nothing
End Sub

Private Sub subSaveTrigger()
On Error GoTo Err_Check
    Dim zCharacterName As String
    Dim lTriggerTextID As Long
    Dim zTriggerMatchingText As String
    Dim zTriggerProgrammedReply As String
    Dim zSoundFilename As String
    Dim zTriggerDesc As String
    Dim rsData As Recordset
    
    lTriggerTextID = MyCLng(lblTriggerTextID.Caption)
    zTriggerMatchingText = txtTriggerMatchingText.Text
    zTriggerProgrammedReply = txtTriggerProgrammedReply.Text
    zSoundFilename = MyCStr(txtSoundFilename.Text)
    zTriggerDesc = MyCStr(txtTriggerDesc.Text)
    Set rsData = MyDB.OpenRecordset("SELECT TriggerTextID, CharacterNameID, TriggerMatchingText, TriggerDesc, TriggerProgrammedReply, SoundFilename FROM tblTriggerText WHERE CharacterNameID=" & gbllCharacterNameID & " AND TriggerTextID=" & lTriggerTextID & ";", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!TriggerMatchingText = zTriggerMatchingText
        rsData!TriggerDesc = zTriggerDesc
        rsData!TriggerProgrammedReply = zTriggerProgrammedReply
        rsData!SoundFilename = zSoundFilename
        rsData.Update
    Else
        rsData.AddNew
        rsData!CharacterNameID = gbllCharacterNameID
        rsData!TriggerMatchingText = zTriggerMatchingText
        rsData!TriggerDesc = zTriggerDesc
        rsData!TriggerProgrammedReply = zTriggerProgrammedReply
        rsData!SoundFilename = zSoundFilename
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    MsgBox "subSaveTrigger," & vbCrLf & Err.Number & vbCrLf & Err.Description, vbCritical
End Sub

Private Sub cmdClearSoundPath_Click()
    txtSoundFilename.Text = ""
End Sub

Private Sub cmdDelete_Click()
    MyDB.Execute "DELETE * FROM tblTriggerText WHERE TriggerTextID=" & MyCLng(lblTriggerTextID.Caption) & ";", dbFailOnError
    subNew
End Sub

Private Sub cmdLoad_Click()
    subLoadAllTriggers
End Sub

Private Sub cmdNew_Click()
    subNew
End Sub


Private Sub cmdPlayer_Click()
On Error Resume Next
    If (Len(MyCStr(txtSoundFilename.Text)) > 0) Then
        Select Case 2
            Case 1 'method 1 (you can play two sounds at once) - not sure what is wrong with it
                mciSendString "open " & txtSoundFilename.Text & " type mpegvideo alias FirstSound", "", 0, 0
                mciSendString "play FirstSound", "", 0, 0
                'mciSendString("open " & fileName & " type mpegvideo alias SecondSound", String.Empty, 0, 0)
                'mciSendString("play SecondSound", String.Empty, 0, 0)
                'mciSendString("close FirstSound", String.Empty, 0, 0) 'close in reverse order if possible
                'mciSendString("close SecondSound", String.Empty, 0, 0)
            Case 2 'method 2
                Set Player = Nothing
                Set Player = New FilgraphManager 'This is the sound and music player
                    Player.RenderFile MyCStr(txtSoundFilename.Text)
                    Player.Run
        End Select
    Else
        With CDlg1
            .CancelError = True
            .DialogTitle = "Browse For MP3 Files"
            .Filter = "MP3 Files (*.mp3) |*.mp3; |Wave Files (*.wav) |*.wav; |Midi Files (*.mid) |*.mid"
            .ShowOpen
            If (Len(.filename) <> 0) Then txtSoundFilename.Text = .filename
        End With
    End If
End Sub

Private Sub cmdSave_Click()
    subSaveTrigger
    subNew
End Sub
Private Sub Form_Activate()
    gbllFormActivated = 7
    txtTriggerMatchingText.SetFocus
End Sub

Private Sub Form_Load()
    subLoadAllTriggers
End Sub

Private Sub subNew()
    txtTriggerMatchingText.Text = ""
    txtTriggerProgrammedReply.Text = ""
    lblTriggerTextID.Caption = ""
    txtSoundFilename.Text = ""
    txtTriggerDesc.Text = ""
    subLoadAllTriggers
End Sub

Private Sub lstTriggers_Click()
    Dim rsSetUp As Recordset
    Set rsSetUp = MyDB.OpenRecordset("SELECT TriggerTextID, CharacterNameID, TriggerMatchingText, TriggerDesc, TriggerProgrammedReply, SoundFilename FROM tblTriggerText WHERE CharacterNameID=" & gbllCharacterNameID & " AND TriggerTextID=" & MyCLng(lstTriggers.ItemData(lstTriggers.ListIndex)) & ";", dbOpenSnapshot)
    If (Not rsSetUp.EOF) Then
        lblTriggerTextID.Caption = MyCLng(rsSetUp!TriggerTextID)
        txtTriggerMatchingText.Text = MyCStr(rsSetUp!TriggerMatchingText)
        txtTriggerProgrammedReply.Text = MyCStr(rsSetUp!TriggerProgrammedReply)
        txtSoundFilename.Text = MyCStr(rsSetUp!SoundFilename)
        txtTriggerDesc.Text = MyCStr(rsSetUp!TriggerDesc)
        rsSetUp.MoveNext
    Else
        subNew
    End If
    Set rsSetUp = Nothing
End Sub
