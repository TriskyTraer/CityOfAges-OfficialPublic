VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmPort2046 
   BackColor       =   &H00FFFFFF&
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   1095
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   1560
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "Port2046.frx":0000
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   1095
   ScaleWidth      =   1560
   Begin VB.CommandButton cmdRemoveAdmin 
      Caption         =   "-"
      Height          =   255
      Left            =   1200
      TabIndex        =   6
      ToolTipText     =   "Retracts Admin abilities, only."
      Top             =   840
      Width           =   375
   End
   Begin VB.CommandButton cmdMakeAdmin 
      Caption         =   "Make Admin"
      Height          =   330
      Left            =   0
      TabIndex        =   5
      TabStop         =   0   'False
      ToolTipText     =   "This will give you immortal command abilities: HELP IMMORTAL"
      Top             =   840
      Width           =   1222
   End
   Begin VB.ListBox lstUserInput 
      Appearance      =   0  'Flat
      BackColor       =   &H0000C000&
      Height          =   240
      ItemData        =   "Port2046.frx":0ABA
      Left            =   720
      List            =   "Port2046.frx":0ABC
      TabIndex        =   3
      Top             =   0
      Visible         =   0   'False
      Width           =   135
   End
   Begin VB.ListBox lstPortMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H0000C0C0&
      Height          =   240
      ItemData        =   "Port2046.frx":0ABE
      Left            =   720
      List            =   "Port2046.frx":0AC0
      TabIndex        =   1
      Top             =   240
      Visible         =   0   'False
      Width           =   135
   End
   Begin VB.Timer ctlTimerPort 
      Left            =   1080
      Top             =   0
   End
   Begin MSWinsockLib.Winsock ctlServer 
      Left            =   240
      Top             =   0
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      LocalPort       =   2011
   End
   Begin VB.Label lblPlayerName 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H00800080&
      Height          =   255
      Left            =   -120
      TabIndex        =   4
      Top             =   480
      Width           =   1815
   End
   Begin VB.Label lblRemoteHost 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      ForeColor       =   &H00800080&
      Height          =   255
      Left            =   0
      TabIndex        =   2
      Top             =   240
      Width           =   1575
   End
   Begin VB.Label lblMsg 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   12
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   1575
   End
End
Attribute VB_Name = "frmPort2046"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit 'ports 2011 to 2057 are player static ports
'TRISKER WORK HERE on these ports with lstUserInput you can group same sent messages very well
Public zMeNamePortID As String
Public lMeNamePortID As Long
Public bUnload As Boolean
Public gbllTimeOuts As Long
Public gblzOUserInput As String
Public gbliOUserInput As Integer
Public gblzMode As String
Private Sub cmdMakeAdmin_Click()
    If (MsgBox("Would you like to set the person on this port to Full Systems Administrator?" & vbCrLf & vbCrLf & "NOTE: Use HELP IMMORTAL in the MUD for your commands.", 4) = 6) Then
        subImmortalSetImmLvPortID zMeNamePortID, 100
        MsgBox "Player Updated."
    Else
        MsgBox "Cancelled."
    End If
End Sub
Private Sub cmdRemoveAdmin_Click()
    If (MsgBox("Remove Systems Administrator permissions?" & vbCrLf & vbCrLf & "NOTE: Your character will not be harmed in any way.", 4) = 6) Then
        subImmortalSetImmLvPortID zMeNamePortID, 0
        MsgBox "Player Updated."
    Else
        MsgBox "Cancelled."
    End If
End Sub
Private Sub ctlTimerPort_Timer()
On Error GoTo Err_Check
    If (bUnload) Then
        Me.ctlTimerPort.Interval = 0 'we turn off timers that are suppose to be in sleep mode
    Else
        subPortEngineTimer Me, gbllTimeOuts 'process a listbox
    End If
    Exit Sub
Err_Check:
    'subWriteErrorFile "ctlTimerPort_Timer p" & zMeNamePortID & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub
Private Sub ctlServer_DataArrival(ByVal lBytesTotal As Long)
On Error GoTo Err_Check
    'User sending some information
    gbllTimeOuts = 0
    subPortDataArrival Me 'process inbox - listbox
    Exit Sub
Err_Check:
    'subWriteErrorFile "ctlServer_DataArrival p" & zMeNamePortID & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub
Private Sub Form_Load()
On Error GoTo Err_Check
    Me.lstUserInput.Clear 'sometimes some data gets trapped in the EXE or listbox control some wierd data showing: Command Prompt of the player that disconnected and usually some weather report right after - strange I am hoping this clears it up
    Me.lstPortMsg.Clear

    zMeNamePortID = MyCLng(Mid(Me.Name, 8, 4)) 'This is the actual name of the form 'frmPortXXXX'
    Me.lblMsg.Caption = zMeNamePortID
    lMeNamePortID = MyCLng(zMeNamePortID)
    
    gblbSystemAwake = False 'We try to sleep the system each time we close the port. If someone is still online they will awaken the system as long as they are playing.
    bUnload = False
    
    Me.ctlTimerPort.Interval = 0 'we keep the timer off till a connection request - port 23 will activate this form's timer interval when the connection request is passed
    Me.gblzOUserInput = ""
    Me.gbliOUserInput = 0
    Me.gbllTimeOuts = 0

    'gblzVoteCasted(MyCInt(zMeNamePortID)) = ""
    subChannelStatusAll zMeNamePortID, True: subPortInitVars lMeNamePortID
    Me.gblzMode = ""

    Me.Caption = "p" & zMeNamePortID 'Load
    Me.ctlServer.LocalPort = zMeNamePortID 'set telnet port
    Me.ctlServer.Listen 'Listen for the user that was passed over from port 23
    Exit Sub
Err_Check:
    'subWriteErrorFile "Form_Load p" & zMeNamePortID & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error GoTo Err_Check
    bUnload = True
    gblbLineFeed(MyCLng(zMeNamePortID)) = False
    Me.gblzMode = ""
    Me.ctlTimerPort.Interval = 0
    Me.lblPlayerName.Caption = ""
    Me.ctlServer.Close
    Me.lstUserInput.Clear
    Me.lstPortMsg.Clear
    subClearLoginPort zMeNamePortID
    Exit Sub
Err_Check:
    'subWriteErrorFile "Form_Unload p" & zMeNamePortID & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub

