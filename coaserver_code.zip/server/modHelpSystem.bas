Attribute VB_Name = "modHelpSystem"
Option Explicit
Public Sub subHelpSystem(zPortID As String, zPassFocusWord As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim rsHelpSystem As Recordset
    Dim lCount As Long
    Dim lRecordCount As Long
    Dim lEmoteCount As Long
    Dim zEmoteList As String
    Dim zEmote As String
    Dim bHelpSystemOkay As Boolean
    Dim lPlayerID As Long
    Dim lImmortalLevel As Long
    Dim zPlayerClass As String
    Dim lClanMemberLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lTotalEmoteCount As Long
    Dim zFocusWord As String
    
    zFocusWord = zPassFocusWord
    zFocusWord = strTrimEOLMatching(zFocusWord, "S", "", True)
    zFocusWord = strTrimEOLMatching(zFocusWord, "ED", "", True)
    zFocusWord = strTrimEOLMatching(zFocusWord, "ING", "", True)
    zFocusWord = strTrimEOLMatching(zFocusWord, "ES", "", True)
    
    'subHelpSystem zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5)), lImmortalLevel, zClass, lClanMemberLevel, lPlayerID
    ', lImmortalLevel As Long, zPlayerClass As String, lClanMemberLevel As Long, lPlayerID As Long
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, ImmortalLevel, Class, ClanMemberLevel, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
        zPlayerClass = MyCStr(rsPlayer!Class)
    End If
    Set rsPlayer = Nothing
    
    If (lTotalAssignedAreas(lPlayerID) > 0) Then
        lImmortalLevel = 4
    End If
    
    bHelpSystemOkay = False
    
    Select Case MyCStr(Mid(zFocusWord, 1, 4))
        Case "HINT"
            subSendMsg vbCrLf & "&gType HINTS alone to manage tricky to use ground objects.", zPortID
        Case "LEVE", "LIST", "LESS", "LICL", "LOWE"
            If (lImmortalLevel > 0) Then subLessarImmortalCommands zPortID
        Case "SUPE" 'Supervisor
            If (lImmortalLevel > 4) Then
                bHelpSystemOkay = True
                subSendMsg vbCrLf & "&gGame Commands - Immortal Supervisors:" & vbCrLf & _
                    gblzFNGRE & "Supervisor command examples:" & vbCrLf & _
                    "SUPE 10 - will show you the last ten commands used by the immortals" & vbCrLf & _
                    "SUPE Trisker 10 - will show you the last 10 commands used by this immortal" & vbCrLf & _
                    "" _
                , zPortID
            End If
        Case "IMM", "IMMO", "GOD", "BUIL", "TOOL", "HIGH"
            bHelpSystemOkay = True
            If (lImmortalLevel > 0) Then
                If (lImmortalLevel > 4) Then
                    subHigherImmortalCommands zPortID
                End If
                If (lImmortalLevel < 5) Then
                    subSendMsg "&GHELP &g[LESSER IMMORTAL COMMANDS, MC, RC, OC, DOOR, MOB, ROOM, OBJECT, AREA, FORGE]", zPortID
                Else
                    subSendMsg "&GHELP &g[LESSER IMMORTAL COMMANDS, SUPERVISOR, MC, RC, OC, DOOR, MOB, ROOM, OBJECT, AREA, FORGE, WORM]", zPortID
                End If
                subLessarImmortalCommands zPortID
            End If
        Case "QUIV"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~QUIVERS~&g" & vbCrLf & _
                "Quivers are arrows for bows." & vbCrLf & _
                "Note: Bows are a two handed item." _
            , zPortID
        Case "FACT"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~FACTIONS~&g" & vbCrLf & _
                "When you pick a faction you become innoculated because those are you PEOPLE, to an extent. There are 9 factions to choose from." & vbCrLf & _
                "Each time you cross though a faction that does not match with yours, you can catch the flu and cough up blood and toxins. Thieves hate cataching the flu and should FACTION COMMAND their favorite stealing locations." _
            , zPortID
            subSendMsg "&AFACTIONS DECLARE A WINNER at 100 Million total population", zPortID
        Case "QUAR"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~QUARRELS~&g" & vbCrLf & _
                "Quarrels are bolts for crossbows." & vbCrLf & _
                "Note: Crossbows are a two handed item." _
            , zPortID
        Case "GOLD", "SOD", "GRAS", "XP", "EXPE", "DISA"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~WHY DID MY ITEM DISAPPEAR~&g" & vbCrLf & _
                "Gold items and Grass Sod items can be removed and worn," & vbCrLf & _
                "however when you drop a gold item or a sod item it becomes a tangible asset" & vbCrLf & _
                "on the ground." & vbCrLf & _
                "You can turn special items into actual gold or experience by dropping" & vbCrLf & _
                "it onto the ground and then picking it up. This can be useful or a hindrance." _
            , zPortID
            
            subSendMsg vbCrLf & "&G~GIVING GOLD~&g" & vbCrLf & _
                "To give gold to a player, type GIVE for the syntax." _
            , zPortID
        Case "GUES"
            bHelpSystemOkay = True
            subSendMsg "&GGUESS WORD GAME" & vbCrLf & "&gThe guess word game is a method to earn crowns of glory." & vbCrLf & "This is useful to forge - HELP FORGE.", zPortID
            If (lImmortalLevel > 79) Then
                subSendMsg "&GIL80+: IMMORTAL GUESS WORD GAME COMMANDS&g", zPortID
                subSendMsg "IMMO GUESS             - will cancel the current guess word that is running.", zPortID
                subSendMsg "IMMO GUESS RAND RAND   - will force the system to select a word to use from the dictionary.", zPortID
                subSendMsg "IMMO GUESS WORD DELETE - will delete the word from the dictionary.", zPortID
                subSendMsg "IMMO GUESS WORD LIST   - will list a matching word to the pattern word.", zPortID
                subSendMsg "                       - You can use a wild card * after a few letters.", zPortID
                subSendMsg "                       - for example: IMMO GUESS WOR* LIST", zPortID
                subSendMsg "&wNOTE: When a player correctly guesses a word it will be added to the dictionary.", zPortID
            End If
        Case "GOLF"
            bHelpSystemOkay = True
            subSendMsg "&GSYNTAX: &gGolf BallName NameOfHole", zPortID
            subSendMsg "&gSTRENGTH       - Str helps to strike the ball which gives it the distance it should travel." & vbCrLf & "DEXTERITY      - Dex helps the accuracy so that you can land the ball closer to the green.", zPortID
            subSendMsg "&gPAR            - A par in this mud is 15 from hole to hole." & vbCrLf & "AIMING         - If your ball gets stuck try to aim at one of the" & vbCrLf & "                 other hole names, and shoot your way to freedom." & vbCrLf & "SWINGS         - Putting into a cup will reset your swings as will" & vbCrLf & "                 logging out of the realm.", zPortID
            subSendMsg "&g                 Note: You cannot golf from colonist areas;", zPortID
            subSendMsg "&g                       clan areas; water areas more than a few inches deep.", zPortID
            subSendMsg "&g                       From Even message areas; nor non-flee zones; and" & vbCrLf & "                       also the areas must accept quests.", zPortID
            If (lImmortalLevel > 1) Then
                subSendMsg "&gTo allow golfing in the area the following must be correct in tblArea:", zPortID
                subSendMsg "&g    (Underwater<9 AND DXYZActive=0 AND NoFleeZone=False AND NoQuestZone=0 AND", zPortID
                subSendMsg "&g    ClanID=0 AND PlayerType=0 AND X=# AND Y=# AND Z=#)", zPortID
                subSendMsg "&g    Where # is the location of the player-golfer.", zPortID
            End If
        Case "TITL"
            bHelpSystemOkay = True
            subSendMsg "&GSyntax: &gTITLE YOUR-TITLE-HERE" & vbCrLf & "This will set your title in WHO." & vbCrLf & "&GSee Also: HELP &g[COLOR/WHOIS/DESC]", zPortID
        Case "DESC"
            bHelpSystemOkay = True
            subSendMsg "&GSyntax: &gDESC YOUR-PARAGRAPH-HERE" & vbCrLf & "This will set your title in WHO." & vbCrLf & "&GSee Also: HELP &g[COLOR/WHOIS/TITLE]", zPortID
        Case "AUTO"
            bHelpSystemOkay = True
            subSendMsg "&gThis will toggle your Autoloot On or Off." & vbCrLf & "Autoloot gets the item from a corpse automatically." & vbCrLf & "If you do not use autoloot then you would" & vbCrLf & "need to use the GET command.", zPortID
        Case "PART", "TEAM", "PARTY", "GROU", "FOLL" 'party or group help
            subSendMsg "&G~GROUPING~" & vbCrLf & "SYNTAX: &gGROUP PLAYERNAME" & vbCrLf & "        GROUP PLAYER DISBAND" & vbCrLf & "        FOLLOW SELF" & vbCrLf & "Also: GROUP ALL and GROUP PLAYERNAME" & vbCrLf & "When you attack everyone in the group will attack if they are grouped.", zPortID
        Case "LESS" 'lessar gods
            'bHelpSystemOkay = False we want to check the help system too
            Select Case lImmortalLevel
                Case 1
                    subSendMsg "&GLevel 1 - LESSAR GOD COMMANDS" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "&gFIRE BOLT AUCTION GS RS CLOG(creates admin a msg) RALL(spell checking)" & vbCrLf & "You cannot edit or change the system in anyway using these commands.", zPortID
                    subSendMsg "&GHELP &g[IMMORTAL/FORGE]", zPortID
                Case 2 To 999
                    subSendMsg "&GLevel 2 - LESSAR GOD COMMANDS" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "&gFIRE BOLT AUCTION GS RS CLOG(creates admin a msg) RALL(spell checking)" & vbCrLf & "HEAVEN HELL PORT ARENA IP LIVE ACTIVE REBOOT CLOSE" & vbCrLf & "You cannot edit or change the system in anyway using these commands.", zPortID
                    subSendMsg "&GHELP &g[IMMORTAL/FORGE]", zPortID
                Case Else
                    subSendMsg "&gYou are not enlightened enough to read these commands.", zPortID
            End Select
        Case "STEA" 'steal
            'bHelpSystemOkay = False 'we want to let immortals add their own DONATION search to tblSystemHelp
            subSendMsg "&GSTEALING" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "&gFORGE STAMP   - will protect your best items from theft." & vbCrLf & "SCARED        - if some one steals from you and fails" & vbCrLf & "              they become very easy to kill - even the high levels.", zPortID
            subSendMsg "&GHELP &g[FORGE/RULES]", zPortID
        Case "FAVO", "VOTE"
            bHelpSystemOkay = True
            subSendMsg "&gSYNTAX: FAVOUR IMMORTALENTITYNAME" & vbCrLf & "        This command toggles the vote on or off as well." & vbCrLf & "        This command alone to see your vote.", zPortID
            subSendMsg "&gSYNTAX: VOTE [Y/N/Abstain]", zPortID
        Case "CLEA", "RAID"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~RAIDS or DAMAGED AREAS~&g" & vbCrLf & _
                "Use the CLEAN command, which takes from your MOVE points." & vbCrLf & _
                "Note: Raids and Player areas which makes the most corpses cause areas to be littered and damaged." _
            , zPortID
        Case "EMAI"
            bHelpSystemOkay = True
            subSendMsg "&WSend your area descriptions and/or the descriptions of your house to:" & vbCrLf & "Email: " & zSystemConfig(2) & vbCrLf & "&GPLEASE READ THIS! IMPORTANT! Before you send your descriptions," & vbCrLf & "please read HELP BUILD and HELP DONATIONS!", zPortID
            subSendMsg "&GHELP &g[DONATIONS/BUILD/IMMORTAL/RULES]", zPortID
        Case "EMOT", "SOCI"
            bHelpSystemOkay = True
            lEmoteCount = 0: lTotalEmoteCount = 0: zEmoteList = ""
            Set rsHelpSystem = MyDB.OpenRecordset("SELECT ChartEmoteID, KeywordCommand FROM tblChartEmote ORDER BY KeywordCommand;", dbOpenSnapshot)
            Do While (Not rsHelpSystem.EOF)
                zEmote = MyCStr(rsHelpSystem!KeywordCommand)
                lTotalEmoteCount = lTotalEmoteCount + 1
                lEmoteCount = lEmoteCount + 1
                Select Case lEmoteCount
                    Case 2, 4, 6
                        zEmoteList = zEmoteList & "&c"
                    Case Else
                        zEmoteList = zEmoteList & "&C"
                End Select
                
                zEmoteList = zEmoteList & strForceSize(zEmote, 9, " ", "A") & " "
                
                If (lEmoteCount > 6) Then
                    subSendMsg zEmoteList, zPortID
                    lEmoteCount = 0
                    zEmoteList = ""
                End If
                rsHelpSystem.MoveNext
            Loop
            Set rsHelpSystem = Nothing
            If (lEmoteCount <> 0) Then subSendMsg zEmoteList, zPortID
            subSendMsg "&CROULETTE  &cDECK      &CHORSE     &cDICE      ANGER    &c(special emotes)", zPortID
            If (lTotalEmoteCount <> 0) Then subSendMsg "&w" & lTotalEmoteCount & " total emotes.", zPortID
            subSendMsg "&GSee Also: HELP &g[PETS/PEMOTE/BASIC/ADVANCED/SLIST/LEARN TREE/AREA/MOB]" & vbCrLf & "&aNote: You can use * with the command EMOTE to move your name." & vbCrLf & "emote smiles sheepishly.    emote With a wide grin * gazes sheepishly." & vbCrLf & "You can also use PEMOTE.", zPortID
        Case "PLAY", "PROL"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~PROLOGUE~&g" & vbCrLf & _
                "Okay, could you tell me a little about it?" & vbCrLf & _
                "Its a heavy quest mud and you can learn skills." & vbCrLf & _
                "Our objects and items in the game are very good with" & vbCrLf & _
                "lots of stats raising items, spells, and skills come from them." & vbCrLf & _
                "You can also build your own stats using the forge command." & vbCrLf & _
                "We have magic find and in high levels this helps you to level." & vbCrLf & _
                "Mobs are a challenging fight similar to players with increased skills and magic." & vbCrLf & _
                "Type SCORE for your starting magic find." & vbCrLf & _
                "When you get high level magic find help you get experience with bonus xp chunks." & vbCrLf & _
                "In here you level with fighting and later ob powerful magic find items for the bonus xp." & vbCrLf & _
                "Many of your your skills are automatic, some ar not," & vbCrLf & _
                "read about this in help basic and help advanced." & vbCrLf & _
                "We have treasure items which are rarer than our uniques and godly items." & vbCrLf & _
                "" _
            , zPortID
            
            subSendMsg vbCrLf & "&GGame Commands - Prologue:&g" & vbCrLf & _
                "Mobs have lots of different spells." & vbCrLf & _
                "The mud is 100% customized in visual basic." & vbCrLf & _
                "Map moves with you so you dont become too lost and confused." & vbCrLf & _
                "MARK and RECALL move you around and there are magic words to move you around" & vbCrLf & _
                "faster around the realm, its faster and easier too" & vbCrLf & _
                "There are quests everwhere and are all well done." & vbCrLf & _
                "Remember to look at everything and get anything from corpses." & vbCrLf & _
                "Quests are given to win crowns of glory from the immortals." & vbCrLf & _
                "Quests from quest masters helps to raise your hit points, essence, mana, or soul." & vbCrLf & _
                "Type X or SCORE - how much glory do you have now?" & vbCrLf & _
                "Type help forge with crowns of glory you can forge your own weapons in here at the blacksmith." & vbCrLf & _
                "You can compound forge to one item so most find a really good item and keep adding to it - help forge." & vbCrLf & _
                "You can rename one of your items to what you like with oren too, most do this first." & vbCrLf & _
                "Mobs can throw you in jail if you are really evil with your alignment." & vbCrLf & _
                "New angle to mudding with new quests added daily." & vbCrLf & _
                "" _
            , zPortID
            'int wis for mana and essence, soul is con str, move is dex etc...I will make a help on this now
        Case "AC"
            bHelpSystemOkay = False
            subSendMsg vbCrLf & "&W~Armour Class~&w" & vbCrLf & _
                "Armour Class is generally your body worn protection." & vbCrLf & _
                "&aWhen Hitroll is finally able to cut into your armour the damage inflicted" & vbCrLf & _
                "can be absorbed. Certain classes have the natural ability to" & vbCrLf & _
                "effectively allow their armour to absorb damage more often." & vbCrLf & _
                "Some items such as shields carry a naturally high absorption capability." _
            , zPortID
        Case "PET", "TRAI", "PETS", "PEMO", "ANIM", "MOUN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Train:&g" & vbCrLf & _
                "TRAIN (MOBname)  - add a trainable pet to your side." & vbCrLf & _
                "        If your level is high enough you can add the mob to your" & vbCrLf & _
                "        group of fighters." & vbCrLf & _
                "        You may not add the same mob more than once to your group." & vbCrLf & _
                "        There are many trainable mobiles in the realm as well." & vbCrLf & _
                "        Once the pet is assigned to you, you cant look at the pet." & vbCrLf & _
                "TRAIN DISBAND (PETname)  - to remove the pet from your side." & vbCrLf & _
                "PEMOTE (PETname) (emote) (target name)  - will make your pets pet-emote." & vbCrLf & _
                "MOUNT (PETname)  - mount a pet for its minor skills and low movement cost." _
            , zPortID
            subSendMsg "&GImportant: Your CHArisma helps pets hit and gain extra experience points!", zPortID
            subSendMsg "&GImportant for Knights: There is a chance when your pet dies it ::FORCE ASCENDS:: instead.", zPortID
            subSendMsg "&GSee Also: HELP &g[EMOTE/LEARN/MOB/BASIC COMMANDS/TELNET/ADVANCED COMMANDS/TITLE]", zPortID
        Case "RULA", "NEWB", "FAQ", "RULE", "BOTT", "BOT", "NOOB", "NEW", "LOGI", "LOGO", "REAL"
            bHelpSystemOkay = True
            subRealmRules zPortID, 1, 1
            subSendMsg "&GThank you for reading the first quarter of the rules.&g (HELP RULB)" & vbCrLf & "&gHELP [RULB/RULC/RULD]", zPortID
        Case "RULB"
            bHelpSystemOkay = True
            subRealmRules zPortID, 2, 1
            subSendMsg "&GThank you for reading the second quarter of the rules.&g (HELP RULC)" & vbCrLf & "&gHELP [RULA/RULC/RULD]", zPortID
        Case "RULC"
            bHelpSystemOkay = True
            subRealmRules zPortID, 3, 1
            subSendMsg "&GThank you for reading the third quarter of the rules.&g (HELP RULD)" & vbCrLf & "&gHELP [RULA/RULB/RULD]", zPortID
        Case "RULD"
            bHelpSystemOkay = True
            subRealmRules zPortID, 4, 1
            subSendMsg "&GThank you for reading the last quarter of the rules.&g (HELP RULA or HELP RULE)" & vbCrLf & "&gHELP [RULA/RULB/RULC]", zPortID
        Case "LANG"
            bHelpSystemOkay = True
            subSendMsg "&GGame System - Language List:" & vbCrLf & "&g" & _
                "Languages are used to understand what creatures of the realm are trying" & vbCrLf & _
                "to communicate to you. You gain languages by looking for the" & vbCrLf & _
                "orbs, translators, and other high technology magical equipment." & vbCrLf & _
                "&GSee Also: HELP &g[MOBS/AREA]" _
            , zPortID
            For lCount = 1 To 14
                subSendMsg "&G&C" & strForceSize(lCount & " ", 20, " ", "A") & zTranslateLanguage(lCount), zPortID
            Next lCount
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&G~FORGE LANGUAGE~&g" & vbCrLf & _
                    "SYNTAX: Type FORGE ABOVENUMBER LANGUAGE" _
                , zPortID
            End If
        Case "ADVA", "COMM", "ACTI", "SCRO", "RECI", "IDEN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GPlayer Game Commands - Advanced Commands:" & vbCrLf & "&g" & _
                "QUAFF          - to drink an equipped potion in your hands" & vbCrLf & _
                "DRINK          - Drink fountain" & vbCrLf & _
                "RECITE         - recite scroll targetobject" & vbCrLf & _
                "MARK and RECALL- help you explore the world faster." & vbCrLf & _
                "X or SCORE     - shows your your character's abilities" _
            , zPortID
            subSendMsg vbCrLf & "&GPlayer Game Commands - Advanced Commands:" & vbCrLf & "&g" & _
                "CONSIDER       - consider a target before you attack" & vbCrLf & _
                "DIG/BURY       - hides an object in the area" & vbCrLf & _
                "CAST           - cast a spell" & vbCrLf & _
                "MAP            - map command, see also: LIGHT TORCH (or) CAST LIGHTSPELL" & vbCrLf & _
                "SCAN           - SCAN # [PLAY/MOBS] See also: help scan" & vbCrLf & _
                "FLEE           - run to disengage combat" _
            , zPortID
            
            subSendMsg gblzFNGRE & _
                "AID            - use your soul to try and revive a stunned player." & vbCrLf & _
                "STUN           - stun your opponent" & vbCrLf & _
                "BS             - backstab stuns and causes light dmg vs your opponent" & vbCrLf & _
                "STEP           - step on the magically short" & vbCrLf & _
                "DISARM         - attempts to disarm your opponent" & vbCrLf & _
                "MISSILE        - to use missile weapons" & vbCrLf & _
                "LEARN          - to learn in the realm" & vbCrLf & _
                "LOOK           - look around your area" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "PATH           - look for paths left behind in the area" & vbCrLf & _
                "STEAL          - steal from a player - thieves are the best at this" & vbCrLf & _
                "COST           - to list your skill cast costs" & vbCrLf & _
                "ACTIVATE       - Activates skills marked activate. ie. AC BASIC GRIP" & vbCrLf & _
                "TRAIN          - train a creature of the realm: HELP PETS" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "POT            - uses the casino poker table calculator" & vbCrLf & _
                "VET            - to heal your pets at a Veterinarian" & vbCrLf & _
                "LOAD           - load your ammo back up at most rangers" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "ABSORBING      - Some items have the godly <>Ankh of Absorption<>." & vbCrLf & _
                "                 Place only the Ankh and the other item into your inventory" & vbCrLf & _
                "                 and then type ABSORB. You will be prompted if necessary." & vbCrLf & _
                "                 The Ankh item has the ability to absorb another similar item." & vbCrLf & _
                "                 The Ankh item will grow its strength from other items." & vbCrLf & _
                "                 The Ankh absorbing them is the Ankh that rules them all!" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "MERGING        - This will place together one card with another card." & vbCrLf & _
                "                 Both cards must be in your inventory to do this." _
            , zPortID
            subSendMsg gblzFNGRE & _
                "CRAFTING       - To craft something place the items alone in your inventory then" & vbCrLf & _
                "                 use this command. You must be standing at a transmuting device." & vbCrLf & _
                "                 Note: Explore the realm! Find the crafting transmute spots." _
            , zPortID
            
            subSendMsg "&gHigh Ranks Only:" & vbCrLf & _
                "VOTE           - Vote message will start a poll by a leader!" _
            , zPortID
            
            subSendMsg "&GSee Also: HELP &g[SLIST/LEARN TREE/TELNET/BASIC COMMANDS/SOCIALS/AREA/FORGE WEAPONS/USE PICKLOCK/USE KEYS]", zPortID
        Case "BASI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GBasic Game Commands - Game Commands:&g" & vbCrLf & _
                "LEARN          - typing this at a teacher will show you all the skills they teach" & vbCrLf & _
                "WEAR           - wear (object)    will wear items you have in your inventory" & vbCrLf & _
                "REMOVE         - remove (object)" & vbCrLf & _
                "GET/TAKE       - get (object)     places an object in the area into your inventory" & vbCrLf & _
                "GIVE           - give (object) (playername)  or  give (value) gold (playername)" & vbCrLf & _
                "DROP           - drop (object)    removes an object from your inventory and onto the ground" & vbCrLf & _
                "LIGHT          - LIGHT an object" & vbCrLf & "                    ie. LIGHT TORCH this is so you can use your MAP command" & vbCrLf & _
                "PEEK           - peek into other rooms without moving from your area" & vbCrLf & _
                "AFFECT         - see what skills and spells are on you" & vbCrLf & _
                "MERGE          - will merge poker cards together" & vbCrLf & _
                "SAC            - to sacrifice junk items in the room" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "U (up), D (down) and N,S,E,W and NE,NW,SE,SW" & vbCrLf & _
                "               - game movement for your player" & vbCrLf & _
                "WHERE          - shows you everyone in your general area" & vbCrLf & _
                "AREAS          - lists the most popular areas of the system." & vbCrLf & _
                "AREAS PLACE    - will help direct you toward an area." & vbCrLf & _
                "SCAN           - looks around the area for mobs or players" & vbCrLf & _
                "MAP            - shows you where you are in the realm" & vbCrLf & _
                "                 without having to map. You are the green spot at the centre." _
            , zPortID
            subSendMsg gblzFNGRE & _
                "EMOTE          - EMOTE embraces you! (or try) EMOTE A mudball hits * in the face!" & vbCrLf & _
                "PEMOTE         - make your pets emote for roleplay" & vbCrLf & _
                "WHOIS          - Will read someones title and desc, you can use the LOOK ocmmand as well" & vbCrLf & _
                "TITLE          - this will set your title in WHO" & vbCrLf & _
                "DESC           - this will descript your character when you look at yourself" & vbCrLf & _
                "GUESS          - you can play guess the word game, immortals can set up the game" _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[USE/AREA/SLIST/LEARN TREE/SOCIALS/TELNET/ADVANCED COMMANDS/AREA/FORGE WEAPONS/USE PICKLOCK/USE KEYS]", zPortID
        Case "WHOI", "WHO", "FING"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~WhoIs~&g" & vbCrLf & _
                "WHO            - This will list everyone online" & vbCrLf & _
                "WHOIS          - Will read someones title and desc," & vbCrLf & "                  you can use the LOOK command as well." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[ADVANCED COMMANDS/BASIC COMMANDS/TITLE/DESC]", zPortID
        Case "BOUN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~BOUNTY QUESTING~" & vbCrLf & "&g" & _
                "BOUNTY         - Type this to list TOP 20 easy bounties and 10 hardest ones." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE/MORE]", zPortID
        Case "MERG", "POKE", "CARD"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MERGE CARDS and POKER CARDS~" & vbCrLf & _
                gblzFNGRE & "MERGE (keepcard) (mergingcard)" & vbCrLf & "NOTE: You will keep the name of the keep card" & vbCrLf & "ALSO: POT      - in poker rooms to calculate your bets." & vbCrLf & "      DECK     - Draws your own card/poker games.", zPortID
            subSendMsg "&GSee Also: HELP &g[ABSORBS/TRANSMUTING/ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE]", zPortID
        Case "CRAF", "TRAN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~CRAFTING SYSTEM~" & vbCrLf & "&g" & _
                "CRAFTING       - To craft something place the items alone in your inventory then" & vbCrLf & _
                "                 use this command. You must be standing at a transmuting device." & vbCrLf & _
                "                 Note: Crafting is difficult to do unless you have explored the realm." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[ABSORBS/MERGE CARDS/ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE]", zPortID
        Case "ABSO"
            bHelpSystemOkay = True
            subSendMsg gblzFNGRE & _
                "ABSORBING      - Some items have the godly <>Ankh of Absorption<>." & vbCrLf & _
                "                 Note: To use this command have only the two items you want to" & vbCrLf & _
                "                       put together in your inventory." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[MERGE CARDS/TRANSMUTING/ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE]", zPortID
        Case "EVOL", "MUD", "STOR", "MORE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~GAME EVOLUTION~" & vbCrLf & "&g" & _
                "spells -> skills -> swords -> guns + grenades -> energy weapons -> warp drive" & vbCrLf & _
                "Basically this MUD shows you an evolution of technology and where the" & vbCrLf & _
                "human race will be sometime into the future." & vbCrLf & _
                "The game is about 80% swords and spells or normal" & vbCrLf & "Multiuser Dungeon and 20% high technology." & vbCrLf & _
                "Guns and Modern weapons usually just weaken and never instant death mobs." & vbCrLf & _
                "Which means with all your technology that you will find you will" & vbCrLf & "always have to SLAY your opponent." & vbCrLf & _
                "A sort of mortal blow which can Annihilate or Assassinate your opponent." & vbCrLf & _
                "Player vs Player is an arena battle everywhere." & vbCrLf & _
                "You never corpse your items either when you die from lack of hit points." & vbCrLf & _
                "We are a totally original code base as well so be a proud player!" & vbCrLf & _
                "Many player wish lists have been covered." & vbCrLf & _
                "&GSee Also: HELP &g[QUEST/AREA/LEARN/MOB/TELNET/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
            subSendMsg vbCrLf & "&G~AREA INFORMATION~" & vbCrLf & _
                gblzFNGRE & "The realm has eleven different area types:" & vbCrLf & _
                "Normal areas - have day and night area descriptions, some words may be highlighted." & vbCrLf & _
                "Fly only areas - requires fly potions or natural pixie fly or the fly spells" & vbCrLf & _
                "Height restricted areas - requires shrink potions which are used for these areas" & vbCrLf & _
                "Offensive and/or defensive spell restricted areas" & vbCrLf & _
                "Water areas - aquabreath is required or if your hit points dont fall below zero while slowly drowning" & vbCrLf & _
                "Pass or Object Areas - objects are sometimes required to cross a guarded area." & vbCrLf & _
                "Trap Areas - when you enter these areas you may be trapped and might take damage (unless you dodge) until the trap resets." & vbCrLf & _
                "Instant Death Areas - there is only a few of these and you dont loose your equipment to them." & vbCrLf & _
                "Oxygen required Areas - there are potions for this in the realm." & vbCrLf & _
                "Gravity/gas/fire/radiation areas - there are item pieces you can put together for these areas." & vbCrLf & _
                "Forge areas - this is where you will make your own weapons." _
            , zPortID
            subSendMsg vbCrLf & "              &G~&YOne Mans Magic is another Mans Technology&G~", zPortID
        Case "USE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&gGame Commands - Use:&g" & vbCrLf & _
                "PICK        - USE PICK [N S E W NE NW SE SW U D]  - thieves do this best" & vbCrLf & _
                "KEY         - USE KEY [N S E W NE NW SE SW U D]   - to be performed on a door" & vbCrLf & _
                "LEVER/KNOB  - USE LEVER (lever name)              - for a room with a lever or knob" & vbCrLf & _
                "COMBO       - USE COMBO (word/number)             - for combination locks" & vbCrLf & _
                "&GSee Also: HELP &g[AREA/BASIC COMMANDS/ADVANCED COMMANDS/LEARN TREE/SLIST]", zPortID
        Case "AREA", "ROOM"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~AREA SWITCH COMMANDS~" & vbCrLf & "&g" & _
                "ENTER (object)      EXIT (object)       CLIMB (object)      FIX (object)" & vbCrLf & _
                "MOVE (object)       PRESS (object)      PULL (object)       PUSH (object)" & vbCrLf & _
                "SPIN (object)       SPEAK (word)        SPREAD (object)     SWING (object)" & vbCrLf & _
                "TOUCH (object)      TAP (object)        TURN (object)       TUG (object)" & vbCrLf & _
                "TWIST (object)      SHOVE (object)      SLIDE (object)" & vbCrLf & _
                "SEARCH (area) (floor) (ceiling) (wall)" & vbCrLf & vbCrLf & _
                "(object)       - being any one word from the full object name or any descriptions" _
            , zPortID
            subSendMsg vbCrLf & "&G~AREA COMMANDS~" & vbCrLf & "&g" & _
                "AREAS          - lists the most popular areas of the system." & vbCrLf & _
                "AREAS PLACE    - will help direct you toward an area." _
            , zPortID
            subSendMsg "&GHELP &g[USE/MORE/ADVANCED/BASIC/BANK/COMMANDS/DOOR/FORGE]", zPortID
            If (lImmortalLevel > 0) Then subSendMsg "&GHELP &gLESSAR  &aor  &GHELP &gIMMORTAL", zPortID
        Case "MAGI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GMobs and Magic Find:" & vbCrLf & _
                gblzFNGRE & "Mobs may or may not have equipment you can kill them for." & vbCrLf & _
                gblzFNGRE & "To see if they have any equipment you have to look at them." & vbCrLf & _
                gblzFNGRE & "If a mob does have an item you will see the chance that" & vbCrLf & _
                gblzFNGRE & "the item will populate the corpse in a 1 in ODDS chance." & vbCrLf & _
                gblzFNGRE & "Magic find reduces the ODDS giving you a better chance for the item to" & vbCrLf & _
                gblzFNGRE & "populate into the corpse." & vbCrLf & _
                gblzFNGRE & "Magic find also comes from your luck stat and some equipment" & vbCrLf & _
                gblzFNGRE & "in the realm has natural magic find on it." & vbCrLf & _
                "&GSee Also: HELP &g[MOB/QUEST/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
            subSendMsg vbCrLf & "&GMagic Words:" & vbCrLf & _
                gblzFNGRE & "Magic words are exactly five characters long. To use them type SAY <word>" & vbCrLf & _
                gblzFNGRE & "They help you travel our large realm faster." & vbCrLf & _
                gblzFNGRE & "You can find these in descriptions or maybe when looking" & vbCrLf & _
                gblzFNGRE & "at objects or mobs of the realm." & vbCrLf & _
                "&GSee Also: HELP &g[MORE/MOB/QUEST/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
        Case "BANK", "MOBS", "MOB", "TALK", "SPEL"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GMob Commands:" & vbCrLf & _
                gblzFNGRE & "TALK (MOBname) (keyword)" & vbCrLf & _
                "                          - tells the mob the keyword," & vbCrLf & _
                "                          - there are no more than three keywords per quest mob" & vbCrLf & _
                "                          - EXAMPLE: TALK MAXIMUS FURRY and TALK MAXIMUS CORPSE" & vbCrLf & _
                "                          - keywords come from what mobs tell you" & vbCrLf & _
                "                          - or you can get keywords from their speech" & vbCrLf & _
                "GIVE (object) (MOBname)  - will give a quest object to that mob" & vbCrLf & _
                "REPAIR (armourer name)    - any items you have equipped will be fixed at a cost" & vbCrLf & _
                "LIST                      - to see what a mob merchant sells" & vbCrLf & _
                "SELL (object name)        - You can sell most anything for money at merchants" & vbCrLf & _
                "BUY (object name)         - You can buy anything for money at a merchant" & vbCrLf & _
                "BANK LIST                 - to see your amount at this bank" & vbCrLf & _
                "BANK DEPO (gold amount)" & vbCrLf & _
                "BANK WITH (gold amount)" & vbCrLf & _
                "&GSee Also: HELP &g[CHANNELS/PETS/LEARN/TRAIN/AREA/QUEST/COMMANDS/MAGIC FIND]" _
            , zPortID
            subSendMsg vbCrLf & "&G~CHANNELS~" & vbCrLf & "&gChannels are used to communicate with the other players." & vbCrLf & "HELP CHANNELS" & vbCrLf & "HELP RAMBLE" & vbCrLf & "Type RAMBLE HI EVERYONE for example!", zPortID
            If (lImmortalLevel > 2) Then
                subSendMsg "&w" & _
                    "MC          - immo mc mobname, short desc - to create a mobile, then:" & vbCrLf & _
                    "MEDIT       - locks the Mob Edit ID Number to the mob - seen under SCORE" & vbCrLf & _
                    "MID         - Mob Identification - use MEDIT to set the value before using MID" & vbCrLf & _
                    "MFORGE      - will forge skills and spells to a mobile" & vbCrLf & _
                    "&GSee Also: HELP &g[LESSAR/IMMORTAL/RC/OC/DC/MC]" _
                , zPortID
                subMagicalMobSpells zPortID, 1
            End If
        Case "QUES"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&W~Quest Commands~" & vbCrLf & "&a" & _
                "LISTENING    - Sometimes you will hear monsters talking about stuff." & vbCrLf & _
                "TALKING      - TALK SYDIRA DIAMOND, this will ask sydira about a diamond." & vbCrLf & _
                "               keywords can be found by listening all over the realm and" & vbCrLf & _
                "               piecing information together." & vbCrLf & _
                "IMMORTALS    - give quests for 'crowns of glory' where you have to find the object" & vbCrLf & "               the quest will involve a roleplay and story line." & vbCrLf & _
                "GIVING MONSTERS OBJECTS - this can be anything from a corpse to a rare item." & vbCrLf & _
                "                          GIVE MONKEY BANANA - would give the banana to the monkey." & vbCrLf & _
                "CANCEL       - this will cancel an Oracle (Quest Master) assigned quest" _
            , zPortID
            
            subSendMsg "&a" & _
                "QUEST MASTER - gives quests to help increase your" & vbCrLf & "               crowns of glory, hit points, essence, mana, or soul." & vbCrLf & _
                "               It is recommended to be level 15 before you start so you know" & vbCrLf & "               where he is sending you and " & vbCrLf & _
                "               so you have the move points to quest there." & vbCrLf & _
                "               It costs one learn/practice point to receive a quest, a small gamble." & vbCrLf & _
                "GUIDE MASTER - the system has the ability to make quests automatically" & vbCrLf & "               from these quests you can attain crowns of glory, bonus xp," & vbCrLf & "               and gold or all three at once." & vbCrLf & _
                "BOUNTIES     - at anytime you can type BOUNTY to quest for pure gold." _
            , zPortID
            subSendMsg "&a" & _
                "QUEST GROUPS - You will find herds or groups of creatures in the realm" & vbCrLf & "               which you must sucessfully dispose of to complete the quest." & vbCrLf & _
                "NOTE: All the above quests can all interact with each other to make your questing a journey." _
            , zPortID
            
            If (lImmortalLevel >= 1) Then
                subSendMsg "&W~Make Mob Quests, Immortals Only~" & vbCrLf & "&a" & _
                    "MQUE will make a quest for you - you need two items and a mob to do this" _
                , zPortID
            End If
            
            If (lImmortalLevel > 9) Then
                subSendMsg "&W~IMMORTAL QUEST COMMANDS~&a" & vbCrLf & _
                    "HOSTILE     - creates a spaceship quest to phaser hostiles" & vbCrLf & _
                    "SPACE       - creates a spaceship quest to phaser mobships in space" & vbCrLf & _
                    "OBJECT      - drops a glory item into the realm" & vbCrLf & _
                    "MOB         - drops a glory creature into the realm" & vbCrLf & _
                    "&GHELP &g[DC/MC/RC/OC/IMMORTAL]" _
                , zPortID
                subSendMsg "&W~QUEST IDEAS FOR IMMORTALS~&a" & vbCrLf & _
                    "ROLEPLAY    - for glory take these 3 words: " & vbCrLf & _
                    "              Ogre Vampire and Sword and make a mini-story." & vbCrLf & _
                    "BACKWARDS   - Write the playername backwards - or a mobname" & vbCrLf & _
                    "DESCRIPTION - The player with the best player description (DESC command) wins something." & vbCrLf & _
                    "MAKE A WORD - Put up lots of letters and let the person that makes" & vbCrLf & _
                    "              the longest word get an award, say of crowns, or an item." _
                , zPortID
            End If
            subSendMsg "&GSee Also: HELP &g[FORGE/PLAY/MOB/TALK/BASIC COMMANDS/ADVANCED COMMANDS/SLIST]", zPortID
        Case "RACE", "CLAS", "CHAR"
            bHelpSystemOkay = True
            subTranslateChartRaces zPortID
            subTranslateChartClasses zPortID
        Case "CHAN", "IGNO", "SAY", "TELL", "GLOB", "SILE", "QUIE"
            bHelpSystemOkay = True
            subSendMsg "&G~CHANNELS~" & vbCrLf & "&g" & _
                "CHAN [+/-]AUCTION" & vbCrLf & _
                "CHAN [+/-]INFOLINE" & vbCrLf & _
                "CHAN [+/-]TELL" & vbCrLf & _
                "CHAN [+/-]PRAY" & vbCrLf & _
                "CHAN [+/-]NEWBIE" & vbCrLf & _
                "CHAN [+/-]OOC Out-Of-Character for Real life topics" & vbCrLf & _
                "CHAN [+/-]RAMBLE" & vbCrLf & _
                "CHAN [+/-]GOSSIP In-Character to Roleplay" & vbCrLf & _
                "CHAN [+/-]QUOTE" & vbCrLf & _
                "CHAN [+/-]QUEST" & vbCrLf & _
                "CHAN [+/-]MUSIC" & vbCrLf & _
                "CHAN [+/-]IMC      - intermud chat" & vbCrLf & _
                "CHAN [+/-]CLAN/MIC - does both clan channels" & vbCrLf & _
                "CHAN [+/-]CLSS     - class channel" & vbCrLf & _
                "CHAN [+/-]RACE     - race channel" & vbCrLf & _
                "CHAN [+/-]HERO     - level 60" & vbCrLf & _
                "CHAN [+/-]LORD     - level 100" & vbCrLf & _
                "CHAN [+/-]ALL      - silences all channels" & vbCrLf & _
                "Example: CHAN -TELL (or) CHAN +MUSIC" & vbCrLf & _
                "&GSee Also: HELP &g[CLAN/MICROPHONE]" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "EMOTE           - Try: emote flys away! (or) emote A pole falls on *!! ACK!" & vbCrLf & _
                "SAY             - works in the same room." & vbCrLf & _
                "YELL            - communicates with those on the WHERE list" & vbCrLf & _
                "MIC             - HELP MIC, creates your own communication friends list" _
            , zPortID
            subSendMsg "&M~Ignore Command~" & vbCrLf & gblzFNMAG & _
                "IGNORE (player) - this will toggle the target player from bothering you." & vbCrLf & _
                "IGNORE LIST     - this will show you who you have placed on your ignore list." & vbCrLf & _
                "NOTE: You cannot ignore the SAY channel since you can walk away." & vbCrLf & _
                "      IGNORE will also prevent an intolerant player from murdering you." _
            , zPortID
            If (lClanMemberLevel > 16) Then
                subSendMsg "&W~Special Channels~" & vbCrLf & "&w" & _
                    "ETERNAL         - A channel for level 175 players, and cannot be silenced." & vbCrLf & _
                    "LEADER          - Leadership channel, and cannot be silenced." _
                , zPortID
            Else
                subSendMsg "&W~Special Channels~" & vbCrLf & "&w" & _
                    "ETERNAL         - A channel for level 175 players, and cannot be silenced." _
                , zPortID
            End If
            
            If (lImmortalLevel >= 1) Then
                subSendMsg "&W~Immortal Special Channels~" & vbCrLf & "&a" & _
                    "GTC/ITC/ITG     - Global Echo channel or the immortal tease channel global" & vbCrLf & _
                    "ITR             - Room Echo channel or the immortal tease channel room" & vbCrLf & _
                    "HAIL is a channel that cannot be blocked - and only immortals may use it!" _
                , zPortID
            End If
            subPrintChannelStatusAll zPortID
        Case "MIC", "MICR", "FRIE", "ADD", "ERAS", "MUTE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Microphone:&g" & vbCrLf & _
                "MIC        - MIC MSG, to broadcast to all of your microphone friends." & vbCrLf & _
                "MUTE       - MUTE PLAYERNAME, See Also: IGNORE PLAYERNAME and IGNORE LIST" & vbCrLf & "             they will be reminded you have them on mute" & vbCrLf & _
                "UNMUTE     - UNMUTE PLAYERNAME" & vbCrLf & _
                "ERASE      - ERASE PLAYERNAME, will remove someone from your microphone list" & vbCrLf & _
                "ADD        - ADD PLAYERNAME, will add someone to your list" & vbCrLf & _
                "&GSee Also: HELP &g[CHANNEL/IGNORE PLAYER]" _
            , zPortID
        Case "RANK", "INDU"
            bHelpSystemOkay = True
            If lImmortalLevel >= 1 Then subSendMsg "&GIMMO COMPLETE LIST     IMMO SET <COMPLETEBANMAX>    IMMO SPAM (toggle)", zPortID
            subSendMsg vbCrLf & "&GClan Commands - INDUCT" & vbCrLf & "&g" & _
                "INDUCT     - *Officers* are able to induct WILLING players into their clan." & vbCrLf & _
                "             If you are an officer you MUST ASK a player if they" & vbCrLf & _
                "             WISH to join your clan. Abuse of your INDUCTION command results" & vbCrLf & _
                "             in the punishment of being banned to the powerless OUTCASTED clan." _
            , zPortID
            
            subSendMsg vbCrLf & "&GClan Induction:" & vbCrLf & _
                gblzFNGRE & "Type INDUCT alone for the rank levels and command syntax." & vbCrLf & _
                "&GSee Also: HELP &g[CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]" & vbCrLf & vbCrLf, zPortID
            
            If lImmortalLevel >= 1 Then subSendMsg "&GIMMO COMPLETE LIST     IMMO SET <COMPLETEBANMAX>    IMMO SPAM (toggle)", zPortID
            If (lImmortalLevel >= 4) Then
                subSendMsg vbCrLf & "&GImmortal Induction:" & vbCrLf & _
                    gblzFNGRE & "IMMO RANK PLAYERNAME IMMORTAL 0     - to unrank an immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 100   - to rank an immortal as the 1st immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 99    - to rank an immortal as the 2nd immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 98    - to rank an immortal as the 3rd immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 2     - CLOG - IMMO HEAVEN - IMMO ARENA - IP SPY" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 1     - CLOG - WHOIS/IP SPY" & vbCrLf & _
                                "IMMO RANK PLAYERNAME BAN            - to uninduct a player from a clan" & vbCrLf & _
                                "IMMO RANK PLAYERNAME CLANNAME RANK  - to induct a player into a clan" & vbCrLf & _
                    "&GSee Also: HELP &g[CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
            End If
        Case "CLAN", "BOOK"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GPersonal Clan Commands - MIC" & vbCrLf & "&g" & _
                "CLAN OF FRIENDS" & vbCrLf & _
                "ADD/BOOK   - to add a person to your friends list" & vbCrLf & _
                "ERASE      - to remove a person from friends list" & vbCrLf & _
                "MUTE       - MUTE PLAYERNAME, See Also: IGNORE PLAYERNAME and IGNORE LIST" & vbCrLf & "             they will be reminded you have them on mute" & vbCrLf & _
                "UNMUTE     - to unmute a friend member" & vbCrLf & _
                "MIC        - speak or shows everyone in your friend list" & vbCrLf & _
                "CLAN       - you must be in a clan to use this channel" & vbCrLf & _
                "&GSee Also: HELP &g[CHANNEL/RANK]" _
            , zPortID
            subSendMsg "&GClan Commands - Clan Reports" & vbCrLf & _
                gblzFNGRE & "CLAN FLAG     - shows you who has all the flags in the realm" & vbCrLf & _
                "RETURN        - will return any clan flags that you carry" & vbCrLf & _
                "CLAN NAMES    - to see a list of clan names" & vbCrLf & _
                "CLAN RANKS    - to see a list of your clan leaders" & vbCrLf & _
                "CLAN LEVEL    - to see a list of your clan high levels" & vbCrLf & _
                "CLAN LEAVE THIS GUILD - to leave your current clan" & vbCrLf & _
                "CLAN EXPIRES  - players that do not login within " & cstlRankLost & " days" & vbCrLf & "                 will loose their clan rank" _
            , zPortID
        Case "COLO", "PROM", "TOGG"
            bHelpSystemOkay = True
            subSendMsg "&G~REQUIRED WEEKLY COLONISTS~&A" & vbCrLf & "Planets: " & cstlRequiredTotalPlanets & " Colonists: " & cstlRequiredTotalColonists, zPortID
            subSendMsg vbCrLf & "&G~Listed Game Colours~" & vbCrLf & _
                gblzFNGRE & "Colours cannot be used in all areas of the system." & vbCrLf & _
                gblzFNGRE & "Normal: &r& r &w& w " & gblzFNMAG & "& m " & gblzFNBLU & "& b &y& y &c& c &g& g" & vbCrLf & _
                gblzFNGRE & "  Bold: &R& R &W& W " & "&M" & "& M &B& B &Y& Y &C& C &G& G" & vbCrLf & _
                gblzFNGRE & "  Gray: &a& a or & A      (remove the extra space after the ampersand)" _
            , zPortID
            subSendMsg vbCrLf & "&G~Toggled Game Colours~" & vbCrLf & _
                gblzFNGRE & "COLOUR PROMPT 0 1 2" & vbCrLf & _
                "COLOUR AREA 0 1 2" & vbCrLf & _
                "0 bright colours" & vbCrLf & _
                "1 dim colours" & vbCrLf & _
                "2 mostly one solid colour" & vbCrLf & _
                "&GSee Also: &gHELP &g[COLOR/TITLE/DESC]" _
            , zPortID
        Case "BODY"
            bHelpSystemOkay = True
            If (lImmortalLevel >= 4) Then 'headset trisker
                subSendMsg vbCrLf & "&w~BODY LOCATIONS~&a" & vbCrLf & _
                    "0       - mortals cannot pick this up only high level immortals can" & vbCrLf & _
                    "8       - headset" & vbCrLf & _
                    "9       - forehead, ie. head bands, reef of throns" & vbCrLf & _
                    "10      - head" & vbCrLf & _
                    "11      - collar - skin of neck - choke chains for example - or gills" & vbCrLf & _
                    "12      - around neck, ie. scarfs" & vbCrLf & _
                    "13      - talismans" & vbCrLf & _
                    "14      - pendants" & vbCrLf & _
                    "15      - amulets" & vbCrLf & _
                    "16      - over mouth" & vbCrLf & _
                    "17      - inner mouth" & vbCrLf & _
                    "18      - face mask" & vbCrLf & _
                    "19      - eyes" & vbCrLf & _
                    "20LR    - hand held object, ie. weapons, bags, keys" & vbCrLf & _
                    "21      - buckler, ie. this is a little shield that goes over one forearm" & vbCrLf & _
                    "22      - pair of gloves or gauntlets" & vbCrLf & _
                    "30LR    - any finger, ie. ring" & vbCrLf & _
                    "31LR    - thumbs, ie. thumb ring" & vbCrLf & _
                    "32      - tongue stud" & vbCrLf & _
                    "33      - nose ring" _
                , zPortID
                subSendMsg _
                    "40LR    - wrist item, ie. bracelets" & vbCrLf & _
                    "41LR    - cuff item, ie. cufflinks" & vbCrLf & _
                    "45LR    - upper arms/biceps, ie. bracers" & vbCrLf & _
                    "50      - forearms, ie. chainlink arms" & vbCrLf & _
                    "60      - leggings" & vbCrLf & _
                    "61LR    - ankles" & vbCrLf & _
                    "62      - knee pads" & vbCrLf & _
                    "63      - elbow pads" _
                , zPortID
                subSendMsg _
                    "70      - torso, ie. breastplate armour" & vbCrLf & _
                    "71      - broach" & vbCrLf & _
                    "72      - centre chest insignia, ie. Insignia of the Ancients" & vbCrLf & _
                    "73      - over body, ie. robes, cloaks" & vbCrLf & _
                    "80      - back middle, ie. backpacks" & vbCrLf & _
                    "81      - back upper, ie. wings" & vbCrLf & _
                    "82      - hips, ie. loin cloth" & vbCrLf & _
                    "83      - waist, ie. belt" & vbCrLf & _
                    "84LR    - over a shoulder, ie. shoulder pouch" & vbCrLf & _
                    "85      - reserved - corpse carrying location only!" & vbCrLf & _
                    "90      - feet" & vbCrLf & _
                    "100LR   - earrings" & vbCrLf & _
                    "110     - reserved: light source" & vbCrLf & _
                    "120     - reserved: gold stash, pickup from the ground - Gold must be set." & vbCrLf & _
                    "121     - reserved: experience bonus, pickup from the ground - BonusXP must be set" _
                , zPortID
            End If
        Case "SKIL"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&gGame Commands - Remove and Wear Skills:" & vbCrLf & _
                "This is a list of all the quest skills players can quest for." & vbCrLf & _
                "Assassins, Monks, and Fighter classes are the best at these skills." & vbCrLf & _
                "Mages are deadly with spells and but weaker with skill damage." & vbCrLf & _
                "The rest of the classes can be good at one or more of these skills." & vbCrLf & _
                "Berserk" & vbCrLf & _
                "Double Punch" & vbCrLf & _
                "Drop Kick" & vbCrLf & _
                "Meditate - NOTE: rings of regeneration are available too" & vbCrLf & _
                "Head Butt" & vbCrLf & _
                "Elbow" & vbCrLf & _
                "Knee" & vbCrLf & _
                "Claw Hand" & vbCrLf & _
                "Knife Hand" & vbCrLf & _
                "Dragon Uppercut" & vbCrLf & _
                "Power Kick" & vbCrLf & _
                "Hurricane Kick" & vbCrLf & _
                "Type RELOAD to load all of your skills this prevents remove and wear spam" _
            , zPortID
            
            subSendMsg vbCrLf & "&gGame Commands - Permanent Skills:" & vbCrLf & _
                "Lock Pick               - this improves your chance to pick locks on doors" & vbCrLf & _
                "Grip                    - items can come with grip to help against being disarmed" & vbCrLf & _
                "Number of Attacks       - items and weapons give you more attacks a round" & vbCrLf & _
                "Slay Chance             - instant death for mobs or players" & vbCrLf & _
                "Fire Elemental Damage   - instant damage to your opponent" & vbCrLf & _
                "Cold Elemental Damage   - instant damage to your opponent" & vbCrLf & _
                "Shock Elemental Damage  - instant damage to your opponent" & vbCrLf & _
                "Regeneration Level      - when you sleep this helps your hitpoints and soul gain faster" & vbCrLf & _
                "Backstab Level          - this is by class" & vbCrLf & _
                "Missile Range Level     - this is by class" & vbCrLf & _
                "Destiny Weapons         - these newbie weapons come with dual wield" & vbCrLf & _
                "Magic Find              - increases your chances to find equipment" _
            , zPortID
            
            subSendMsg "&G" & _
                gblzFNGRE & _
                "Learn                   - If you are at a teacher this will list their skills" & vbCrLf & _
                "                          they can teach you" & vbCrLf & _
                "Learn (skill name)      - Will allow you to learn a skill" & vbCrLf & _
                "Learn Tree              - Will show your complete skill tree" & vbCrLf & _
                "&GSee Also: HELP &g[TRAIN/STATS]", zPortID
        Case "RXYZ"
            bHelpSystemOkay = True
            If (lImmortalLevel >= 4) Then
                subSendMsg vbCrLf & "&gGame Commands - Teleport Pod X Y Z - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "Syntax: RXYZ X Y Z" & vbCrLf & _
                    gblzFNGRE & "ROOM: To make a room teleport you when you move into it modify the RXYZ of the area." & vbCrLf & "Use the command RTDT to disable the teleporting feature." & vbCrLf & _
                    gblzFNGRE & "OBJECTS: To make an object teleport you modify the RXYZ of the area." & vbCrLf & "Use the command RTDT to disable the teleporting feature." & vbCrLf & _
                    "&GSee Also: HELP &g[RTDT, ROOM, RBC]" _
                , zPortID
            End If
        Case "RR"
            bHelpSystemOkay = True
            subHelpSystemRR lX, lY, lZ, lImmortalLevel, lPlayerID, zPortID
        Case "RBC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&gGame Commands - Room Block Construct - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "Syntax: RBC COMMAND|DIRECTION|OBJECT|EMOTE PERSONAL ACTIVATE|EMOTE PERSONAL DEACTIVATE|EMOTE 3rd PERSON ACTIVATE|EMOTE 3rd PERSON DEACTIVATE|CLASS CONSTRAINT|LEVEL CONSTRAINT" & vbCrLf & _
                    gblzFNGRE & "To make an object teleport you modify the RXYZ of the area as normally you would." & vbCrLf & "Use the command RXYZ 0 0 0 to disable the teleporting feature." _
                , zPortID
                subSendMsg vbCrLf & "&gGame Commands - Room Block Construct Commands - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "COMMAND LIST" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "PRESS MOVE PULL PUSH SEARCH SHOVE SPIN SWING TAP TOUCH TUG TURN TWIST ENTER EXIT" & vbCrLf & vbCrLf & _
                    gblzFNGRE & "DIRECTION LIST" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "NE NW SE SW N S E W U D" & vbCrLf & vbCrLf & _
                    gblzFNGRE & "OBJECT LIST" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "STONE ROCK KEY ROPE - anything at all!" _
                , zPortID
                subSendMsg _
                    gblzFNGRE & "EMOTE ACTIVATES" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "You (emote activate) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "3rd Person: Trisker (emote activates) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "EMOTE DEACTIVATES" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "Personal: You (emote deactivate) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "3rd Person: Trisker (emote deactivates) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "CLASS CONSTRAINT" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "If left blank all classes are allowed to use the RBC command." & vbCrLf & "If a class is specified then only that class can activate the RBC command." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "LEVEL CONSTRAINT" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "If left blank all levels are allowed to use the RBC command." & vbCrLf & "If a class is specified then only that level or higher can activate the RBC command." & vbCrLf & vbCrLf & _
                    "&GHELP &g[ROOM, RBCD, RXYZ]" _
                , zPortID
            End If
        Case "RBCD"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&gGame Commands - Room Block Construct Delete - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "Syntax: RBCD @RBCDELETE@   - this will only remove the RBC command, the room will not be affected." & vbCrLf & _
                    "&GHELP &g[ROOM, RBC/DSTA]" _
                , zPortID
            End If
        Case "DWIN"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&G~BUILDING WINDOWS FOR DOORS~&g" & vbCrLf & _
                    "0 = no window, the door is solid" & vbCrLf & _
                    "1 = barred window" & vbCrLf & _
                    "2 = glass window" & vbCrLf & _
                    "3 = arrow hole" & vbCrLf & _
                    "&GHELP &g[DOOR/RBCD/DSTA/LEVEL/IMMORTAL]" _
                , zPortID
            End If
        Case "DSTA"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&W~IMMORTAL BUILDING - SETTING DOOR STATUS~&w" & vbCrLf & _
                    "You have to be in the door, use TELE X Y Z to get in there." & vbCrLf & _
                    "OPEN:     0 = stays always open       3=open but is lockable/pickable" & vbCrLf & _
                    "          5 = bashed open            10=magic opens" & vbCrLf & _
                    "UNLOCKED: 1 = unlocked but closed" & vbCrLf & _
                    "CLOSED:   6 = closed and not lockable 7=bashed closed" & vbCrLf & _
                    "          8=Bashable                 11=magic closed" & vbCrLf & _
                    "LOCKED:   2 = locked                 12=magically locked " & vbCrLf & _
                    "&GHELP &w[DOOR/DWIN/DSTA/LEVEL/IMMORTAL]" _
                , zPortID
            End If
        Case "CREA", "WEAP", "TYPE", "ABIL", "STRE", "INTE", "WISD", "DEXT", "CONS", "CHAR", "LUCK", "DODG", "PARR"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Abilities:&g" & vbCrLf & _
                "STRENGTH       - improves your hitroll and damage roll, extra damage," & vbCrLf & "                 and weight, it also helps to raise soul" & vbCrLf & _
                "INTELLIGENCE   - helps with spell casting, learning skills faster, and for your mana gains" & vbCrLf & _
                "WISDOM         - helps with spell casting, learning skills faster, and for your essence gains" & vbCrLf & _
                "DEXTERITY      - helps with stun, dodge and parry and for your move gains" & vbCrLf & _
                "                 ** Dodge, parry, and weapons block requires at least " & gblcstlDodgeParryWeaponsBlockXPMin & " xp to level up" & vbCrLf & _
                "CONSTITUTION   - helps with your move and hit point gains" & vbCrLf & _
                "CHARISMA/CHARM - helps with mobs so they dont auto attack you and for various similar features" & vbCrLf & "                 the guide master for example likes charming players" & vbCrLf & _
                "LUCK           - helps you with your magic find" & vbCrLf & _
                "&GSee Also: HELP &g[STATS/LEARN/MOB/TELNET/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
            
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&W~BUILDING WEAPON TYPES~&a" & vbCrLf & _
                    "These are all hand object weapon types:" & vbCrLf & _
                    "BLUD    = Bludgeons" & vbCrLf & _
                    "LANC    = Lance" & vbCrLf & _
                    "POLE    = Polearm" & vbCrLf & _
                    "JAVI    = Javelins" & vbCrLf & _
                    "SPEA    = Spears" & vbCrLf & _
                    "FLEX    = Flexible arms" & vbCrLf & _
                    "LBLA    = Long Blades" & vbCrLf & _
                    "SBLA    = Short Blades" & vbCrLf & _
                    "PUGI    = Pugilism" & vbCrLf & _
                    "SSTA    = Short staff" & vbCrLf & _
                    "LSTA    = Long Staff" & vbCrLf & _
                    "SAXE    = Small axe" & vbCrLf & _
                    "GAXE    = Great axe" & vbCrLf & _
                    "TALO    = Talonous" & vbCrLf & _
                    "BOW     = uses arrows   - ARRO" & vbCrLf & _
                    "XBOW    = uses bolts    - BOLT" & vbCrLf & _
                    "SLIN    = uses stones   - STON" & vbCrLf & _
                    "MGUN    = uses ammo     - CLIP" & vbCrLf & _
                    "PHAS    = uses energy   - BLAS" & vbCrLf & _
                    "NET     = Netting someone" _
                , zPortID
                'more or less MGUN PHAS BOW XBOW are all similar just tagged differently
                subSendMsg "&wIMMO WEAPONTYPES         (summary of useage)", zPortID
                subSendMsg "&GSee Also: HELP &g[OC/MC/MOB/RC/ROOM/IMMORTAL]", zPortID
            End If
        Case "STAT", "ESSE", "MANA", "SOUL", "MOVE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Stats:&g" & vbCrLf & _
                "Hit points     - when this falls below zero you die, if you do die you only drop your gold" & vbCrLf & _
                "Mana           - all offensive spells, such as fireball, use this" & vbCrLf & _
                "Essence        - all defensive spells, such as shields, use this" & vbCrLf & _
                "Soul           - this is used for skills such as disarm, stun, steal, and other skills" & vbCrLf & _
                "Move           - as you move around this value will fall depending where you are " & vbCrLf & _
                "                 adventuring. Hitroll and Damage Roll (average damage) will weaken" & vbCrLf & _
                "                 when your move points fall below half. Use SCORE or X to check this." & vbCrLf & _
                "                 Those that fight barehanded will use up more move points to hit" & vbCrLf & _
                "                 than those that use weapons." & vbCrLf & _
                "&GSee Also: HELP &g[ABILITIES/LEARN/MOB/BASIC COMMANDS/TELNET/ADVANCED COMMANDS]" _
            , zPortID
        Case "MC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&G~BUILDING/CREATE MOBILES~&g" & vbCrLf & _
                    "MC          - creates a new mobile to be edited" & vbCrLf & _
                    "MD          - deletes a mob" & vbCrLf & _
                    "MEDIT       - Use IMMO RALL to view all the room mobile ids" & vbCrLf & _
                    "              Then MEDIT the ID#." & vbCrLf & _
                    "MID           Mobile Identification - Capital Letters represent the commands" & vbCrLf & _
                    "              WeaponType for example, mforge wt axe  or  mforge desc This is my first mob!" & vbCrLf & _
                    "MFORGE      - Use MEDIT and MID first then this command." _
                , zPortID
            End If
            
            If (lImmortalLevel > 3) Then
                subSendMsg gblzFNGRE & _
                    "MQUE       - Mobile Quest - type IMMO MQUE for the syntax" & vbCrLf & _
                    "MERG       - gives the item to a mob and marks the mob a merchant" & vbCrLf & _
                    "MCOPY      - IMMO MCOPY MOBID will copy that mob to your current location" & vbCrLf & _
                    "MGIV       - give Mobile Armour or Weapons to increase the mobile's AC and DAMAGE" & vbCrLf & _
                    "MAPA       - Mobile add path" & vbCrLf & _
                    "MDPA       - Mobile delete path" _
                , zPortID
                subSendMsg "&GSee Also: &gHELP &g[MOB/SPELLSFORMOBS/OC/RC/LESSAR IMMORTAL/HIGHER IMMORTAL/DC]", zPortID
            End If
        Case "RC", "HOUS", "DONA", "PAYP", "AREA"
            bHelpSystemOkay = True
            'bHelpSystemOkay = False 'we want to let immortals add their own DONATION search to tblSystemHelp
            subSendMsg "&GDONATIONS" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "We accept donations, and in turn we award you" & vbCrLf & "either a house, or some crowns of glory, or both." & vbCrLf & "Please visit the housing district for further details." & vbCrLf & "You can donate directly to our PAYPAL account, HELP PAYPAL.", zPortID
            subSendMsg "&GHELP &g[EMAIL/BUILD/RULES]", zPortID
            subSendMsg "&G~AREA COMMANDS~" & vbCrLf & "&g" & _
                    "AREA        - lists the popular area where titles in the system" _
            , zPortID
            If (lImmortalLevel > 90) Then
                subSendMsg "&w~BUILDING A HOUSE FOR A PLAYER FOR DONATIONS~" & vbCrLf & "&a" & _
                    "1)   When a player donates you want to type IMMO TRANS YOURPLAYERNAME MATRIX" & vbCrLf & _
                    "     You will now be in the Housing Matrix area." & vbCrLf & _
                    "     You can also travel north from the City of Ages to the City of Marble." & vbCrLf & _
                    "     OR type: TELE 100000 100000 100000 to teleport to the centre of the matrix" & vbCrLf & _
                    "2)   type LOOK" & vbCrLf & _
                    "3)   type MAP" & vbCrLf & _
                    "     LOOK and MAP will help you find an empty spot to build the house." & vbCrLf & _
                    "     Move as close as you can to this spot using N S E W NE NW SE SW U D." & vbCrLf & _
                    "4)   type LOCATION" & vbCrLf & _
                    "5)   type TELE X Y Z" & vbCrLf & _
                    "     X Y Z are coordinate numbers you use from the" & vbCrLf & _
                    "     LOCATION command, do not put in the X Y Z, See #1 above." & vbCrLf & _
                    "     If you use the EXACT same numbers from the LOCATION command" & vbCrLf & _
                    "     you will just teleport to your current location." & vbCrLf & _
                    "     You want to be able to move from that position to an empty spot to build." _
                , zPortID
                subSendMsg "&a" & _
                    "6)   type WHOIS PLAYERNAME" & vbCrLf & _
                    "     Playername is the person you are building the house for." & vbCrLf & _
                    "     Get the ID number from the WHOIS, if you see some IP numbers then just scroll back up" & vbCrLf & _
                    "7)   type IMMO RC" & vbCrLf & _
                    "     if you did #5 above correctly you will of created a room. See also: HELP [RC]" & vbCrLf & _
                    "8)   type IMMO TYPE 1 PLAYERID" & vbCrLf & _
                    "9)   Now open directions for the player to move into their house: use IMMO RB" & vbCrLf & _
                    "     See also: HELP [RC] and find the RB command for futher help." _
                , zPortID
                subSendMsg "&w~ROOM CONTROLS~" & vbCrLf & "&a" & _
                    "TYPE        - immo type will set the area PlayerTypes, 0:normal 1:house 2:starship" & vbCrLf & _
                    "              See also: HELP [RC/HOUSE/BUILD]" & vbCrLf & _
                    "MAP         - to see your map" & vbCrLf & _
                    "WHERE       - this will show the room/area's where information" & vbCrLf & _
                    "AREA        - immo area or immo rall to show the area in detail" _
                , zPortID
            End If
            
            If (lImmortalLevel > 2) Then
                subSendMsg "&G~AREA ELEMENTAL~" & vbCrLf & _
                    "SYNTAX: IMMO AE BELOWCOMMAND VALUE&g" & vbCrLf & _
                    " BELOWCOMMANDS," & vbCrLf & _
                    "      ORL  - Oxygen Required Level" & vbCrLf & _
                    "      GL   - Gravity Level" & vbCrLf & _
                    "      RAL  - Radiation Area Level" & vbCrLf & _
                    "      GAL  - Gas Area Level" & vbCrLf & _
                    "      GAD  - Gas Area Description" & vbCrLf & _
                    "      HAL  - Heat Area Level" & vbCrLf & _
                    "     VALUE is a number, the higher the number the more dmg per turn." _
                , zPortID
                subSendMsg vbCrLf & "&G~IMMORTAL AREA COMMANDS~" & vbCrLf & "&g" & _
                    "RC         - room - creation at your location" & vbCrLf & _
                    "RD         - immo rd @deletespot@" & vbCrLf & _
                    "RR         - set room rules see also, HELP RR" & vbCrLf & _
                    "RB         - room blockage (dir) +/-" & vbCrLf & _
                    "RR         - modification of room area rules" & vbCrLf & _
                    "RH         - hides doors or room exits, ie. RH (dir) +/-" & vbCrLf & _
                    "AMOV       - set area move points to your area location" & vbCrLf & _
                    "QUEST      - immo quest sets the rooms ability to accept quests or not" & vbCrLf & _
                    "UNDERWATER - immo under 10 will set the room with 10cm of water" _
                , zPortID
                subSendMsg gblzFNGRE & _
                    "FLY        - immo fly will toggle the area as a fly zone or not" & vbCrLf & _
                    "MAPT       - immo mapt will toggle the MAP visibility" & vbCrLf & _
                    "RDD        - room - set day desc. this works if it is day or not" & vbCrLf & _
                    "RND        - room - set night desc" & vbCrLf & _
                    "WDES/WAPP  - apply an area where description title where you stand" & vbCrLf & _
                    "WADD       - add a new area where title to the system" & vbCrLf & _
                    "WDEL       - delete full area where title" _
                , zPortID
                subSendMsg vbCrLf & "&g" & _
                    "RBC        - room blockage construct - ie. TOUCH STAFF" & vbCrLf & _
                    "RALL       - immo area or immo rall, reveals full room information," & vbCrLf & _
                    "WHERE      - immo where, reveals full room where information," _
                , zPortID
                subSendMsg "&GSee Also: &g[FORGE,OC,MC]", zPortID
            End If
            
            If (lImmortalLevel > 3) Then
                subSendMsg gblzFNGRE & _
                    "RXYZ       - set room teleportation destination" & vbCrLf & _
                    "RTDT       - set room teleportation destination toggle on/off" & vbCrLf & _
                    "RSCK       - immo RSCK will spell check the area the immortal is in" & vbCrLf & _
                    "TYPE       - immo type will set the area PlayerTypes, 0:normal 1:house 2:starship" _
                , zPortID
                subSendMsg vbCrLf & "&G~ROOM TRANSIT~&g" & vbCrLf & _
                    "TAPA       - add area transit path - you must start on an area" & vbCrLf & _
                    "TDPA       - delete area transit path" & vbCrLf & _
                    "TDES       - transit destination" & vbCrLf & _
                    "CLAN       - set the area clan id" & vbCrLf & _
                    "RRNK       - immo rank 0-10 - there is actually no limited number" _
                , zPortID
                subSendMsg "&GSee Also: &gHELP &g[RC/RR/OC/MC/IMMORTAL]", zPortID
            End If
        Case "DOOR", "DC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg "&G~DOOR COMMANDS~&g" & vbCrLf & _
                    "DC         - door create, when a door is created it only operates" & vbCrLf & _
                    "             N S E W Up or Down not angles such as NE NW SE SW" & vbCrLf & _
                    "DWIN       - create a window for this door you are in, See Also: HELP DWIN" & vbCrLf & _
                    "DSTA       - set door status, open, locked, unlock..." & vbCrLf & "0 = Open, 1 = Unlocked but closed, 2 = Locked, 3=open but is lock/pickable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and not lockable, 7 = Bashed closed, 8=Bashable 10=magic open 11=magic closed 12=magically locked" & vbCrLf & "&GHELP DSTA" & vbCrLf & _
                    "DD         - door delete" & vbCrLf & _
                    "&GHELP &g[DWIN, DSTA, RBC]" _
                , zPortID
            End If
            subSendMsg vbCrLf & "&GGame Command - Door Examples:&g" & vbCrLf & _
                    "DOOR       - USE KEY (dir)" & vbCrLf & _
                    "DOOR       - OPEN (dir)" & vbCrLf & _
                    "DOOR       - CLOSE (dir)" & vbCrLf & _
                    "DOOR       - LOOK (dir)" & vbCrLf & _
                    "&GHELP &g[AREA/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
        Case "OBJE", "ITEM", "OC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 3) Then
                subSendMsg vbCrLf & "&G~OBJECT EDIT COMMANDS~&g" & vbCrLf & _
                    "* OC       - object create" & vbCrLf & _
                    "* OAVG     - set weapon average damage, if this is zero then this is " & vbCrLf & _
                    "             NOT a damage inflicting object" & vbCrLf & _
                    "* OTYP     - object weapon type             &GSee Also: HELP WEAPONTYPES&g" & vbCrLf & _
                    "* OLOC     - set the object's body location &GSee Also: HELP BODY&g" & vbCrLf & _
                    "             ie. FORGE LOCA 10  << immortals only - players see an error msg" & vbCrLf & _
                    "* OWEI     - set the object's weight in grams, 2.2lbs = 1kg (kilogram). " & vbCrLf & _
                    "* ODES     - set the object's description" & vbCrLf & _
                    "* OAC      - when you create armour of anykind don't forget this command" & vbCrLf & "for example:" & vbCrLf & _
                    "             200AC is a great breast plate armour" & vbCrLf & _
                    "             20AC on plate leggings is reasonable too " & vbCrLf & _
                    "             put minus DEX on plate armour pieces please" & vbCrLf & _
                    "             ie. Seagull Feather = 1 gram, Swords are 15kgs, Clubs are 1kg" & vbCrLf & _
                    "OD         - delete object and" & vbCrLf & _
                    "             if you have problems deleting do this: first drop the" & vbCrLf & _
                    "             object somewhere safe LOOK at the area and" & vbCrLf & "note the object's EXACT and FULL name." _
                , zPortID
                subSendMsg gblzFNGRE & _
                    "PLANT       - immo plant objectid containerobjectid" & vbCrLf & "               will bolt the containerobject to the ground and" & vbCrLf & "               in 20 minutes respawn the item inside of it." & vbCrLf & _
                    "DROP        - this will drop ANY item off a mobile: MERG, MQUE" & vbCrLf & _
                    "OGL         - shows the xyz location of all glory items - so you can't loose them" & vbCrLf & _
                    "OREN        - rename the object, ie. OREN test|test2" & vbCrLf & vbCrLf & _
                    "* = most important when you first create an object." & vbCrLf & _
                    "&GSee Also: HELP &g[CROWNS, FORGE]" _
                , zPortID
                subSendMsg "&GSee Also: &gHELP &g[MOB/MC/RC/IMMORTAL/DC]", zPortID
                subSendMsg "&G" & vbCrLf & vbCrLf & "Special Interactive Object Commands: " & vbCrLf & "&g'SLID', 'ENTE', 'EXIT', 'CLIM', 'MOVE', 'PRES'," & vbCrLf & "'PULL', 'PUSH', 'SEAR', 'SHOV', 'SPRE', 'SWIN', 'SPIN', 'SPEA'," & vbCrLf & "'TOUC', 'TAP', 'TUG', 'TURN', 'TWIS', 'FIX'," & vbCrLf & ("if you dont chose the right word CoA server MUD will hint to you what the answer is. If you guess how to open a perminant fixtured ground Object you will save your Learn Points on hints from the CoA MUD Server") & vbCrLf, zPortID
            End If
        Case "BACK"
            If (lImmortalLevel > 90) Then
                subSendMsg vbCrLf & "&G~SYSTEM BACKUP~&g" & vbCrLf & _
                    "BACKUP      - will freeze all port timers, disconnect the database from the," & vbCrLf & _
                    "operating system then proceeds to make an exact copy of the realm database. The" & vbCrLf & _
                    "system will make grandfather backups as well so make sure you have enough" & vbCrLf & _
                    "harddrive space for at least a few database copies. The copy is sent directly" & vbCrLf & _
                    "to the root folder/directory or also known as C:\ Files are placed at that" & vbCrLf & _
                    "location since you should be running the MUD on an entirely different" & vbCrLf & _
                    "harddrive location. There can be too much activity on a harddrive running" & vbCrLf & _
                    "an operating system and a server at the same time. Both need to read and write" & vbCrLf & _
                    "their own data." & vbCrLf & _
                    "&GSee Also: HELP &g[COLOUR/IMMORTAL]" _
                , zPortID
            End If
        Case "KEEP", "UNKE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&gGame Commands - NO SELL:" & vbCrLf & _
                "KEEP   - everything in your EQuipment list will be marked NO SELL." & vbCrLf & _
                "UNKEEP - everything in your INVentory list will be marked SELL." _
            , zPortID
        Case "CROW", "GLOR", "FORG"
            bHelpSystemOkay = True
            subSendMsg "&W~FORGE UPGRADE COMMANDS~&a" & vbCrLf & _
                "1) Only have that item in your inventory." & vbCrLf & _
                "2) You must also be at an armourer." & vbCrLf & _
                "SYNTAX: FORGE # COMMAND" & vbCrLf & _
                "        FORGE STAMP/UNSTAMP" & vbCrLf & _
                "        FORGE RENAME <newname>" & vbCrLf & _
                "        FORGE DESC <newdescription>" _
            , zPortID
            subSendMsg vbCrLf & _
              "&aSTR        -  " & gbllForgeCostSTRCrowns & " crowns forges 1 strength to an object" & vbCrLf & _
                "INT        -  " & gbllForgeCostINTCrowns & " crowns forges 1 intelligence to an object" & vbCrLf & _
                "WIS        -  " & gbllForgeCostWISCrowns & " crowns forges 1 wisdom to an object" & vbCrLf & _
                "DEX        -  " & gbllForgeCostDEXCrowns & " crowns forges 1 dexterity to an object" & vbCrLf & _
                "CON        -  " & gbllForgeCostCONCrowns & " crowns forges 1 constitution to an object" & vbCrLf & _
                "CHA        -  " & gbllForgeCostCHACrowns & " crowns forges 1 charisma to an object" & vbCrLf & _
                "LUC        -  " & gbllForgeCostLUCCrowns & " crowns forges 1 luck to an object" & vbCrLf, zPortID
            subSendMsg "&a" & _
                "HR         -  1 crown forges 3 hitroll to an object" & vbCrLf & _
                "DR         -  1 crown forges 2 average damage roll to an object" & vbCrLf & _
                "AC         -  1 crown forges 2 armour class to your item" & vbCrLf & _
                "HP         -  1 crown forges 4 hit points to an object" & vbCrLf & _
                "MANA       -  1 crown forges 10 offensive mana to an object" & vbCrLf & _
                "ESSE       -  1 crown forges 10 essence" & vbCrLf & _
                "MOVE       -  1 crown forges 10 move" & vbCrLf & _
                "SOUL       -  1 crown forges 10 soul", zPortID
            subSendMsg "&a" & _
                "STAMP      -  5 crowns stamps this object as yours forever" & vbCrLf & _
                "UNSTAMP    -  9 crowns unstamps this object" & vbCrLf & _
                "TEMPER     -  " & cstlTemperCost & " crowns, randoms level requirement" & vbCrLf & _
                "CHIZZLE    -  " & cstlChizzleCost & " crowns, alignment sets to neutral" & vbCrLf & _
                "RENA       -  1 crown cost per change, renames/restrings an object" & vbCrLf & _
                "DESC       -  1 crown cost per change, modifies the object's description" & vbCrLf & _
                "                object description is revealed when you look at the item," & vbCrLf & _
                "                this command will overwrite the previous item description so" & vbCrLf & _
                "                if you want to keep the previous description you will have" & vbCrLf & _
                "                to append it with your new description.", zPortID
            subSendMsg "&w" & _
                "FORGE YOUR OWN SET by CLASS - Rule: You stamp ~O N C E~ per item, making matching set items:" & vbCrLf & "&a" & _
                "BACKStbSTAMP 199 a stackable damage Backstab stamping" & vbCrLf & _
                "MISSILESTAMP  99 a stackable range stackable Missile stamping", zPortID
            
            If (lImmortalLevel > 3) Then
                subSendMsg "&W~Immortal Forge Commands~&a" & vbCrLf & _
                    "LOCK/UNLOCK-  immo lock playername - will stamp all the players stuff" & vbCrLf & _
                    "TYPE       -  sets the weapon type to the object, HELP TYPE" & vbCrLf & _
                    "LOCA       -  sets the body location, HELP BODY" & vbCrLf & _
                    "WEIG       -  sets the item weight, this is important to keep inventory clean" & vbCrLf & _
                    "IAS        -  Increased Attack Speed" & vbCrLf & _
                    "NOA        -  Number of Attacks" & vbCrLf & _
                    "SLAY       -  Instand death chance percent" & vbCrLf & _
                    "MAGICFIND  -  Helps to find harder to get items" & vbCrLf & _
                    "FIRE       -  Fire enchant" & vbCrLf & _
                    "COLD       -  Cold enchant" & vbCrLf & _
                    "LIGHT      -  Lightning enchant" & vbCrLf & _
                    "POISON     -  Poison enchant" & vbCrLf & _
                    "WB         -  Weapon block percent, *use body location 20 and 21 only*" & vbCrLf & _
                    "MR         -  Move reduction", zPortID
                
                subSendMsg "&a" & _
                    "ACF        -  toggles colors allowed to ground items (IMMO LOCA 0)" & vbCrLf & _
                    "OASN       -  forge an Object Activate Spell Number to the item" _
                , zPortID
                
                subSendMsg "&a" & _
                    "ALIGNMENT  -  forge align 0/1/2" & vbCrLf & _
                    "LEVEL REQ  -  forge lvr playerlevel - sets item level req" & vbCrLf & _
                    "FOOD       -  forge 1-20 FOOD - creates a food item" & vbCrLf & _
                    "SM         -  forge SM numberofseats" & vbCrLf & _
                    "WM         -  makes a container - forge weight weightmax - use immo lock too" & vbCrLf & _
                    "LOCK       -  sets the lock status of 10 20 or 30 to an item - use weightmax too" _
                , zPortID
            End If
        Case "AUCT"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~Game Commands~" & vbCrLf & _
                "&aAUCTION     - ie. AUCTION GLOVES 200" & vbCrLf & _
                "BID         - bid on an item at the auction" & vbCrLf & _
                "AUCTION     - typed alone will give you an identify of the item" & vbCrLf & _
                "Immortals reserve the right to cancel an auction for any reason." & vbCrLf & _
                "&GSee Also: HELP &g[CAST/IMM/USE/SOCIALS/DOOR/OBJECT/USE]", zPortID
            If (lImmortalLevel >= 1) Then
                subSendMsg "&gImmortals can stop an auction with IMMO AUCTION" & vbCrLf & "Use IMMO AUCTION LIST to see who is at the auction.", zPortID
            End If
        Case "MAPS", "MAP", "LIGH", "TORC"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MAP COMMAND~" & vbCrLf & "&g" & _
                gblzFNGRE & "The MAP command requires you to LIGHT a torch or cast a light spell." & vbCrLf & _
                "&GSee Also: HELP &g[MAP/MOB/AREA/BASIC COMMANDS/ADVANCED COMMANDS/TELNET/SLIST]", zPortID
        Case "SCAN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~SCAN COMMAND~" & vbCrLf & "&g" & _
                gblzFNGRE & "SCAN 1         - will scan around you one area" & vbCrLf & _
                "SCAN 1 PLAY    - will scan around you one area for only players" & vbCrLf & _
                "SCAN 4 MOBS    - will scan around you four areas for only mobs" & vbCrLf & "               - assuming your SLIST permits this far" & vbCrLf & _
                "If you are a thief you scan for objects automatically." & vbCrLf & _
                "&GSee Also: HELP &g[MAP/MOB/AREA/BASIC COMMANDS/ADVANCED COMMANDS/TELNET/SLIST]", zPortID
        Case "WORM", "SHEL", "SIGN"
            'bHelpSystemOkay = True
            subSendMsg "&G~SIGNATURE~" & vbCrLf & "&g" & _
                "Signature is the distance to the other starship until they spot you." & vbCrLf & _
                "Even when you cloak you give off a signature. If an enemy starship sees this  " & vbCrLf & _
                "you could very well be attacked or chased." _
            , zPortID
            subSendMsg "&G~WORMHOLES~" & vbCrLf & "&g" & _
                "If your starship scanners are high, say over 1500 you will" & vbCrLf & _
                "see wormholes in many places around the Universe!" _
            , zPortID
            If (lImmortalLevel >= 88) Then
                subSendMsg "&G~SPACE COMMANDS~" & vbCrLf & "&g" & _
                    "WORM        - This will create a wormhole from your current" & vbCrLf & _
                    "              location to the x y z desination given." & vbCrLf & _
                    "Shell information and hints to build:" & vbCrLf & _
                    "RepairPort that are true will not show up on the viewer." & vbCrLf & _
                    "The Starship must be between the shell's xs xe ys ye zs ze" & vbCrLf & _
                    "ShellGroupCode will ignore matching shell ShellGroupCode values after the first shell qualifies." & vbCrLf & _
                    "ShellGroupCode will continue to show all other ShellGroupCode not repeating." & vbCrLf & _
                    "The ShellOrderFromSource closest to the destination point must be the" & vbCrLf & _
                    "      SMALLEST set shell value of the same ShellGroupCode." & vbCrLf & _
                    "Shell search order are: ShellGroupCode, ShellOrderFromSource" _
                , zPortID
                
                subSendMsg "&GSee Also: &gHELP[STARSHIP/SLIST/IMMORTAL/RC/MC/OC/FORGE].", zPortID
            End If
        Case "MESS"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MESSAGE BOARDS~" & vbCrLf & _
                gblzFNGRE & "MBC  - will create a message " & vbCrLf & "     ie. MBC Hello everyone!" & vbCrLf & "     will post a new message on the message board" & vbCrLf & _
                "MBD  - will delete a message from the board" & vbCrLf & "     ie. MBD 235" & vbCrLf & "     will delete note 235" & vbCrLf & _
                "MBV  - will view the message board" & vbCrLf & "     ie. MBV ALL will show them all" & vbCrLf & "     MBV 10 will show the top 10" & vbCrLf & "MBV alone will list the first few notes" & vbCrLf & _
                "&GSee Also: HELP &g[MOB/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        Case "MERC"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MERCHANT~" & vbCrLf & "&g" & _
                "LIST        - shows what the merchant has for sale" & vbCrLf & _
                "SELL        - sell an item to a merchant, see also: AUCTION" & vbCrLf & _
                "BUY         - buy soemthing from a merchant" & vbCrLf & _
                "&GSee Also: HELP &g[ROOM/MOB/AUCTION]", zPortID
        Case "PAGE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~PAGE REPORTS~" & vbCrLf & "&g" & _
                "Type PAGE alone for a list of page reports available to players.", zPortID
        Case "MORP", "REMO"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MORPHING~" & vbCrLf & "&g" & _
                "There are two types of morphing at City of Ages:" & vbCrLf & _
                "        -     Class morphing and Organic morphing." & vbCrLf & _
                "Class morphing is similar to remorting." & vbCrLf & _
                "Organic morphing is similar to turning someone into a frog." & vbCrLf & _
                "At City of Ages both have their advantages and disadvantages." & vbCrLf & _
                "Being a certain morphs allows you in certain areas as well." _
            , zPortID
        Case "PLAG", "GUAR"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~PLAGUE COMMANDS~" & vbCrLf & "&g" & _
                "DREAM    - so you can pickup a guard duty right away" & vbCrLf & _
                "When you recieve a guard quest it is to test your prowlness." & vbCrLf & _
                "If you do not find the location or forget to, you become a LAZY GUARD." & vbCrLf & _
                "See Also: [ORACLE/MAP/PAGE QUEST]" _
            , zPortID
        Case "SPAC", "STAR", "SHIP", "SS", "PILO", "CHEV" 'chevrons
            bHelpSystemOkay = True
            subSendMsg "&G~REQUIRED WEEKLY COLONISTS~&A" & vbCrLf & "Planets: " & cstlRequiredTotalPlanets & " Colonists: " & cstlRequiredTotalColonists, zPortID
            subSendMsg vbCrLf & "&G~PILOT COMMANDS~" & vbCrLf & "&g" & _
                "STARGATE         - stargate chevrons will open the event horizon of a stargate" & vbCrLf & _
                "SS               - will show all the available commands" & vbCrLf & _
                "                 ie. STARGATE CHEVRONPATTERN to activate a stargate" & vbCrLf & _
                "                     STARGATE alone to enter an open stargate" _
            , zPortID
            
            subSendMsg vbCrLf & "&G~PILOT NAVIGATION~" & vbCrLf & "&g" & _
                "The use of warp technology works in a rubics cube 3D Matrix like environment." & vbCrLf & _
                "West is -X and East is X+" & vbCrLf & _
                "North is -Y and South is Y+" & vbCrLf & _
                "Up is -Z and Down is Z+" & vbCrLf & _
                "When you put in your coordinates you never include the X Y Z letters," & vbCrLf & "only the numbers." & vbCrLf & _
                "These are location examples:" & vbCrLf & _
                "SS NAVIGATION -2 3 -708 will take you to the Red Planets Docking Port" & vbCrLf & _
                "SS NAVIGATION 0 0 -110 will take you above High in the Clouds" & vbCrLf & _
                "SS NAVIGATION 0 0 -50 will take you above the Newbie Zone" & vbCrLf & _
                "SS NAVIGATION 0 0 -6 will take you above heaven," & vbCrLf & "beam down and then enter the " & gblzMUDName & vbCrLf & _
                "The centre of the " & gblzMUDName & " is located at 0 0 0" & vbCrLf & _
                "Your warpdrive capable ship can get damaged but repairs are free." & vbCrLf & _
                "Your warpdrive ship never blows up no matter how much damage" & vbCrLf & "is sustained to it." & vbCrLf & _
            "&GSee Also: HELP &g[ROOM/MOB/AUCTION/WORM] also type SS for the starport prices", zPortID
            If (lImmortalLevel > 2) Then
                subSendMsg "&G~ROOM COMMANDS~&g" & vbCrLf & _
                    "WORM        - immo worm x y z creates a worm hole to x y z" & vbCrLf & _
                    "NAVIG       - will randomly select a mobship and move it." & _
                    "See Also: [RC/IMMORTAL/OC/MC]" _
                , zPortID
            End If
        Case "SLIS", "PRAC", "LEAR", "COST", "AFK", "MODE", "QUIC", "FAST", "NOW", "GOGO", "GO", "DAMA", "BAN", "COMP"
            bHelpSystemOkay = True
            If lImmortalLevel >= 1 Then subSendMsg "&GIMMO COMPLETE LIST     IMMO SET <COMPLETEBANMAX>    IMMO SPAM (toggle)", zPortID
            subSendMsg vbCrLf & "&G~QUICK COMMANDS~" & vbCrLf & "&g" & _
                "SLIST       - SKILLS->This will list all of your natural spells/crafts/and skills." & vbCrLf & _
                "LEARN TREE  - SPELLS->This will list all of your possible s/c/and s." & vbCrLf & _
                "PRACTICE    - This will list all of your practiced s/c/and s." & vbCrLf & _
                "COST        - List of casting costs" & vbCrLf & _
                "DAMAGE      - List of heal and damage causing spells" & vbCrLf & _
                "USE         - USE LEVERS, USE KNOBS, USE KEYS, COMBINATION, USE PICKLOCK" & vbCrLf & _
                "LEARN       - Use at a teacher! LEARN (alone) to lists all s/c/&s there." & vbCrLf & _
                "REPORT      - tells everyone around your area your current status" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "PAGE        - you can read over many system reports" & vbCrLf & _
                "IGNORE      - you can completely ignore a player" & vbCrLf & _
                "X or SCORE  - see your player stats and adjustments" & vbCrLf & _
                "REPEAT      - REPEAT or ! character will repeat your last command." & vbCrLf & _
                "KEEP        - KEEP and UNKEEP will toggle if you can sell your items or not" & vbCrLf & _
                "AFK         - toggle your away from keyboard status" & vbCrLf & _
                "PAGE COMP   - PAGE COMPONENTS lists your required spell components" & vbCrLf & _
                "&GSee Also: HELP &g[AREA/BASIC COMMANDS/ADVANCED COMMANDS/TELNET]", zPortID
        Case "TELN", "REPE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GTelnet Commands:" & vbCrLf & "&g" & _
                "REPEAT      - REPEAT or ! character will repeat your last command." & vbCrLf & _
                "&GSee Also: HELP &g[SLIST/FORGE/CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        Case "SQL", "TABL", "FIEL", "VARI" 'IMMO TABLE FIELDS TABLENAME
            bHelpSystemOkay = True
            If (lImmortalLevel > 90) Then
                subSendMsg vbCrLf & "&w~SQL COMMANDS~&a" & vbCrLf & _
                    "TABLES    - immo table list  or  immo table tablename" & vbCrLf & _
                    "FIELDS    - same as immo table fields tablename" & vbCrLf & _
                    "            LIST will list them all" & vbCrLf & _
                    "&GSee Also: HELP &g[IMMORTAL]", zPortID
            End If
        Case "EQUI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GPlayer Equipment (worn):&g" & vbCrLf & _
                "EQUIP     - Will list all the equipment you are wearing." & vbCrLf & _
                "EMPTY     - Will list all the empty equipment slots." & vbCrLf & _
                "EQUIP     - EQ BACK or EQ MIDDLE or EQ HEAD   ..." & vbCrLf & _
                "&GSee Also: HELP &g[CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        Case "STOC"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~STOCK MARKET~&g" & vbCrLf & _
                "STOCK     - this typed alone will show you the complete syntax of the command." & vbCrLf & _
                "&GSee Also: HELP &g[INVESTMENTS]", zPortID
        Case "INVE", "VARI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~STOCK MARKET INVESTMENT VARIABLES~&g" & vbCrLf & _
                " VARIABLES:  A to M shows disruption in the stock index" & vbCrLf & _
                "             N to Z shows a positive fluxuation in the stock" & vbCrLf & _
                "             A - financial sheet did not balance" & vbCrLf & _
                "             B - there was a mismanagement of funds" & vbCrLf & _
                "             C - poor investments" & vbCrLf & _
                "             D - inventory did not balance (thieft?)" & vbCrLf & _
                "             W - fiscal sheet balanced" & vbCrLf & _
                "             X - there was a balance or profit" & vbCrLf & _
                "             Y - investment balance or profit" & vbCrLf & _
                "             Z - inventory balanced" & vbCrLf & _
                "EXAMPLE:     There are four checks as well ie. (A2ZZ)" & vbCrLf & _
                "             This example means," & vbCrLf & _
                "               the fiscal sheet did not balance" & vbCrLf & _
                "               any number ie. this 2 indicates a perfect balance" & vbCrLf & _
                "               and the inventory balanced" & vbCrLf & _
                "               and again the inventory balanced" & vbCrLf & _
                "NOTE:        The fall(3) and the winter(4) terms usually balance" & vbCrLf & _
                "             due to a slow peroid." & vbCrLf & _
                "&GSee Also: HELP &g[STOCK]", zPortID
    End Select
    
    If (Len(MyCStr(zFocusWord)) > 0) Then
        Set rsHelpSystem = MyDB.OpenRecordset("SELECT SystemHelpID, SystemHelpTitle, SystemHelpKeywords, SystemHelpDesc, ImmortalLevel FROM tblSystemHelp WHERE (ImmortalLevel Is Null or ImmortalLevel <= " & lImmortalLevel & ")  AND (SystemHelpKeywords Like '*" & zAntiSQLCrash(zFocusWord) & "*') ORDER BY ImmortalLevel, SystemHelpTitle;", dbOpenSnapshot)
        If (Not rsHelpSystem.EOF) Then
            bHelpSystemOkay = True
            rsHelpSystem.MoveLast
            lRecordCount = rsHelpSystem.RecordCount
            rsHelpSystem.MoveFirst
            
            If (lRecordCount < 9) Then
                Do While (Not rsHelpSystem.EOF)
                    If (MyCLng(rsHelpSystem!ImmortalLevel) > 0) Then
                        subSendMsg vbCrLf & "&r(EYE)&r IMMORTAL HELP FILE (IL" & MyCLng(rsHelpSystem!ImmortalLevel) & "+) &w- HELPID#" & MyCLng(rsHelpSystem!SystemHelpID), zPortID
                    Else
                        If (lImmortalLevel > 3) Then subSendMsg vbCrLf & "&r(EYE)&w HELPID#" & MyCLng(rsHelpSystem!SystemHelpID), zPortID
                    End If
                    subSendMsg "&G" & MyCStr(rsHelpSystem!SystemHelpTitle) & vbCrLf & "&g" & (MyCStr(rsHelpSystem!SystemHelpDesc)), zPortID
                    rsHelpSystem.MoveNext
                Loop
            Else
                subSendMsg "&GHelp System - " & lRecordCount & " matches found." & vbCrLf & "&gPlease try a more unique search word.", zPortID
            End If
        End If
        Set rsHelpSystem = Nothing
    End If
    
    If (Not bHelpSystemOkay) Then
        subSendMsg vbCrLf & "                           &CC&city of &CA&cges &C~&GH&gELP &GS&gYSTEM&C~", zPortID
        subSendMsg "&G+&g==============================================================================&G+&g", zPortID
        subSendMsg "    Use the HELP system with single wording, ex: HELP REPAIR, HELP <word>", zPortID
        subSendMsg "&G+&g---------------|---------------|---------------|---------------|--------------&G+&g", zPortID
        subSendMsg _
            "|ADVANCED       |BASIC COMMANDS |LEARN TREE     |SLIST          |CHANNELS      |" & vbCrLf & _
            "|STATISTICS     |SCORE / X      |SCAN           |PAGE           |USE / LEVER   |", zPortID
        subSendMsg _
            "|COLOR          |PROMPT         |CONFIG         |AUCTION        |TRAIN PETS    |" & vbCrLf & _
            "|TITLE          |REPAIR <name>  |CRAFTING       |MESSAGEBOARDS  |PETS          |" & vbCrLf & _
            "|WHOIS          |               |STARSHIPS      |QUEST COMMANDS |BANK          |" & vbCrLf & _
            "|BUY / SELL     |               |               |               |              |" & vbCrLf & _
            "|               |FORGE          |               |               |              |" & vbCrLf & _
            "|PARTY          |SS             |KEEP / UNKEEP  |RULES          |NOOBIE        |", zPortID
        subSendMsg "&G+&g---------------|---------------|---------------|---------------|--------------&G+", zPortID
        subSendMsg "            &C* &C* &C* &C* &GS&gafari Expansion Unlocked Version 2027 &C* &C* &C* &C*", zPortID
    End If
    ''AbsorbsSameLeft Transmute
    Exit Sub
Err_Check:
    subWriteErrorFile "subHelpSystem," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub


