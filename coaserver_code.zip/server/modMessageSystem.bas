Attribute VB_Name = "modMessageSystem"
Option Explicit
Public Sub subSendMsgAreaRadius(zMessage As String, lX As Long, lY As Long, lZ As Long)
On Error GoTo Err_Check 'TWO
    Dim rsData As Recordset
    
    'a radius of 2 around the x y z location will receive this message - this is excellent for sound effects!
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (Len([PortID])>1) AND (X=" & lX & " or X=" & lX - 1 & " or X=" & lX + 1 & " or X=" & lX - 2 & " or X=" & lX + 2 & ") AND (Y=" & lY & " or Y=" & lY - 1 & " or Y=" & lY + 1 & " or Y=" & lY - 2 & " or Y=" & lY + 2 & ") AND (Z=" & lZ & " or Z=" & lZ - 1 & " or Z=" & lZ + 1 & " or Z=" & lZ - 2 & " or Z=" & lZ + 2 & ");", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        subSendMsg zMessage, MyCStr(rsData!PortID)
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaRadius," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaRadiusFOUR(zMessage As String, lX As Long, lY As Long, lZ As Long)
On Error GoTo Err_Check 'TWO
    Dim rsData As Recordset
    
    'a radius of 2 around the x y z location will receive this message - this is excellent for sound effects!
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (Len(PortID)>1) AND (X=" & lX & " or X=" & lX - 1 & " or X=" & lX + 1 & " or X=" & lX - 2 & " or X=" & lX + 2 & " or X=" & lX - 3 & " or X=" & lX + 3 & " or X=" & lX - 4 & " or X=" & lX + 4 & ") AND (Y=" & lY & " or Y=" & lY - 1 & " or Y=" & lY + 1 & " or Y=" & lY - 2 & " or Y=" & lY + 2 & " or Y = " & lY - 3 & " or y = " & lY + 3 & " or Y = " & lY - 4 & " or Y = " & lY + 4 & ") AND (Z=" & lZ & " or Z=" & lZ - 1 & " or Z=" & lZ + 1 & " or Z=" & lZ - 2 & " or Z=" & lZ + 2 & " or Z=" & lZ - 3 & " or Z=" & lZ + 3 & " or Z=" & lX - 4 & " or Z=" & lZ + 4 & ");", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        subSendMsg zMessage, MyCStr(rsData!PortID)
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaRadiusFOUR," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAll(zMessage As String, lX As Long, lY As Long, lZ As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'DO NOT BLOCK FORMAT THIS
    'The player is at the location and the port is active.
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (Len([PortID])>1 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Status<>50 AND SleepDuration=0 AND BlindDuration=0 AND StunDuration=0);", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        subSendMsg zMessage, rsData!PortID
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAll," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAllNotBM(zMessage As String, lX As Long, lY As Long, lZ As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lPortID As Long
    'DO NOT BLOCK FORMAT THIS
    'The player is at the location and the port is active.
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (Len([PortID])>1 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Status<>50 AND SleepDuration=0 AND BlindDuration=0 AND StunDuration=0);", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        lPortID = MyCLng(rsData!PortID)
        If (Not gblbFilterMode(lPortID)) Then subSendMsg zMessage, lPortID
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllNotBM," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAllBM(zMessage As String, lX As Long, lY As Long, lZ As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lPortID As Long
    'DO NOT BLOCK FORMAT THIS
    'The player is at the location and the port is active.
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (Len([PortID])>1 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Status<>50 AND SleepDuration=0 AND BlindDuration=0 AND StunDuration=0);", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        lPortID = MyCLng(rsData!PortID)
        If (gblbFilterMode(lPortID)) Then subSendMsg zMessage, lPortID
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllBM," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAllStarshipNoSpotRange(zMessage As String, lX As Long, lY As Long, lZ As Long, lRange As Long)
On Error GoTo Err_Check
    Dim bSpot As Boolean
    Dim rsData As Recordset
    
    'The player is at the location and the port is active.
    Set rsData = MyDB.OpenRecordset("SELECT X, Y, Z, PortID FROM tblPlayer WHERE (Len([PortID])>1 AND X>=" & lX - lRange & " AND X<=" & lX + lRange & " AND Y>=" & lY - lRange & " AND Y<=" & lY + lRange & " AND Z>=" & lZ - lRange & " AND Z<=" & lZ + lRange & " AND Status<>50 AND BlindDuration=0 AND StunDuration=0);", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        bSpot = (MyCLng(rsData!x) = lX And MyCLng(rsData!y) = lY And MyCLng(rsData!z) = lZ)
        If (Not bSpot) Then subSendMsg zMessage, MyCStr(rsData!PortID)
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllStarshipNoSpotRange," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAllRange(zMessage As String, lX As Long, lY As Long, lZ As Long, lRange As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'The player is at the location and the port is active.
    Set rsData = MyDB.OpenRecordset("SELECT X, Y, Z, PortID FROM tblPlayer WHERE (Len([PortID])>1 AND X>=" & lX - lRange & " AND X<=" & lX + lRange & " AND Y>=" & lY - lRange & " AND Y<=" & lY + lRange & " AND Z>=" & lZ - lRange & " AND Z<=" & lZ + lRange & " AND Status <> 50 AND SleepDuration=0 AND BlindDuration=0 AND StunDuration=0);", dbOpenSnapshot)
    Do While (Not rsData.EOF)
        subSendMsg zMessage, MyCStr(rsData!PortID)
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllRange," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsg(zPassColorMsg As String, ParamArray vPortID() As Variant) 'vPortID you can add more than one portid to the end
On Error Resume Next
    Dim lPortID As Long
    Dim bSkipPort As Boolean
    Dim vEachPort As Variant
    Dim lLen As Long 'Trap and ignore colours here down
    Dim lCount As Long
    Dim bInsertSpace As Boolean
    Dim lSpaceDetected As Long
    Dim bIgnore As Boolean
    Dim lRealChars As Long
    Dim zChr As String
    Dim zColorMsg As String
    Dim zHoldMsg As String
    Dim bEOL As Boolean 'End of Line
    Dim lOffset As Long
    Dim zOffsetChr As String
    
    zColorMsg = zTranslateColour(zPassColorMsg)
    lLen = Len(zColorMsg): lCount = 0
    'We first want to strip out the message and ignore the colours
    zHoldMsg = "": bIgnore = False: lRealChars = 0: lSpaceDetected = 0
    If (Len(zColorMsg) > 0) Then
        Do
            lCount = lCount + 1
            zChr = Mid(zColorMsg, lCount, 1)
            zHoldMsg = zHoldMsg & zChr
            
            If (zChr = Chr(27)) Then bIgnore = True  'we turn on ignore colors
            
            If (bIgnore) Then
                If (zChr = "m") Then bIgnore = False 'off again - this is how we ignore the ascii colors
            Else
                Select Case zChr
                    Case vbCr, vbLf
                        lRealChars = 0 'We detected a vbCr/vbLf meaning that the variable zColorMsg came with its own vbCrLf formatting for this part of the message passed, so that line is complete
                    Case " "
                        lRealChars = lRealChars + 1 'detected a human readable character
                        lSpaceDetected = lCount
                    Case Else
                        lRealChars = lRealChars + 1 'detected a human readable character
                End Select
    
                If (lRealChars = 80) Then
                    lRealChars = 0 'we found 80 useful human readable characters from the alphebet so we insert the last space we detected
                    bEOL = (lCount = lLen Or Mid(zColorMsg, lCount + 1, 1) = vbCr Or Mid(zColorMsg, lCount + 1, 1) = vbLf)
                    If (Not bEOL) Then
                        If (lSpaceDetected <> 0) Then
                            zHoldMsg = Mid(zHoldMsg, 1, lSpaceDetected - 1) & Chr(255) & Mid(zHoldMsg, lSpaceDetected + 1)
                            lRealChars = (lCount - lSpaceDetected) 'this is the realcharacters that were scanned already so we reuse them
                            lSpaceDetected = 0
                        End If
                    End If
                End If
            End If
        Loop Until (lCount = lLen)
    End If
    
    If (zHoldMsg <> "") Then
        zHoldMsg = strReplaceWordWithThisWord(zHoldMsg, Chr(255), vbCrLf)
        For Each vEachPort In vPortID()
            If (gbliFlow(MyCLng(vEachPort)) > 99) Then 'is the user fully logged in and in the game or at the login screen?
                Select Case vEachPort
                    'Case "23" 'for port full string
                    '    If (frmPort23!ctlServer.State = sckConnected) Then frmPort23!lstPortMsg.AddItem zHoldMsg
                    Case "2011"
                        If (frmPort2011!ctlServer.State = sckConnected) Then frmPort2011!lstPortMsg.AddItem zHoldMsg
                    Case "2012"
                        If (frmPort2012!ctlServer.State = sckConnected) Then frmPort2012!lstPortMsg.AddItem zHoldMsg
                    Case "2013"
                        If (frmPort2013!ctlServer.State = sckConnected) Then frmPort2013!lstPortMsg.AddItem zHoldMsg
                    Case "2014"
                        If (frmPort2014!ctlServer.State = sckConnected) Then frmPort2014!lstPortMsg.AddItem zHoldMsg
                    Case "2015"
                        If (frmPort2015!ctlServer.State = sckConnected) Then frmPort2015!lstPortMsg.AddItem zHoldMsg
                    Case "2016"
                        If (frmPort2016!ctlServer.State = sckConnected) Then frmPort2016!lstPortMsg.AddItem zHoldMsg
                    Case "2017"
                        If (frmPort2017!ctlServer.State = sckConnected) Then frmPort2017!lstPortMsg.AddItem zHoldMsg
                    Case "2018"
                        If (frmPort2018!ctlServer.State = sckConnected) Then frmPort2018!lstPortMsg.AddItem zHoldMsg
                    Case "2019"
                        If (frmPort2019!ctlServer.State = sckConnected) Then frmPort2019!lstPortMsg.AddItem zHoldMsg
                    Case "2020"
                        If (frmPort2020!ctlServer.State = sckConnected) Then frmPort2020!lstPortMsg.AddItem zHoldMsg
                    Case "2021"
                        If (frmPort2021!ctlServer.State = sckConnected) Then frmPort2021!lstPortMsg.AddItem zHoldMsg
                    Case "2022"
                        If (frmPort2022!ctlServer.State = sckConnected) Then frmPort2022!lstPortMsg.AddItem zHoldMsg
                    Case "2023"
                        If (frmPort2023!ctlServer.State = sckConnected) Then frmPort2023!lstPortMsg.AddItem zHoldMsg
                    Case "2024"
                        If (frmPort2024!ctlServer.State = sckConnected) Then frmPort2024!lstPortMsg.AddItem zHoldMsg
                    Case "2025"
                        If (frmPort2025!ctlServer.State = sckConnected) Then frmPort2025!lstPortMsg.AddItem zHoldMsg
                    Case "2026"
                        If (frmPort2026!ctlServer.State = sckConnected) Then frmPort2026!lstPortMsg.AddItem zHoldMsg
                    Case "2027"
                        If (frmPort2027!ctlServer.State = sckConnected) Then frmPort2027!lstPortMsg.AddItem zHoldMsg
                    Case "2028"
                        If (frmPort2028!ctlServer.State = sckConnected) Then frmPort2028!lstPortMsg.AddItem zHoldMsg
                    Case "2029"
                        If (frmPort2029!ctlServer.State = sckConnected) Then frmPort2029!lstPortMsg.AddItem zHoldMsg
                    Case "2030"
                        If (frmPort2030!ctlServer.State = sckConnected) Then frmPort2030!lstPortMsg.AddItem zHoldMsg
                    Case "2031"
                        If (frmPort2031!ctlServer.State = sckConnected) Then frmPort2031!lstPortMsg.AddItem zHoldMsg
                    Case "2032"
                        If (frmPort2032!ctlServer.State = sckConnected) Then frmPort2032!lstPortMsg.AddItem zHoldMsg
                    Case "2033"
                        If (frmPort2033!ctlServer.State = sckConnected) Then frmPort2033!lstPortMsg.AddItem zHoldMsg
                    Case "2034"
                        If (frmPort2034!ctlServer.State = sckConnected) Then frmPort2034!lstPortMsg.AddItem zHoldMsg
                    Case "2035"
                        If (frmPort2035!ctlServer.State = sckConnected) Then frmPort2035!lstPortMsg.AddItem zHoldMsg
                    Case "2036"
                        If (frmPort2036!ctlServer.State = sckConnected) Then frmPort2036!lstPortMsg.AddItem zHoldMsg
                    Case "2037"
                        If (frmPort2037!ctlServer.State = sckConnected) Then frmPort2037!lstPortMsg.AddItem zHoldMsg
                    Case "2038"
                        If (frmPort2038!ctlServer.State = sckConnected) Then frmPort2038!lstPortMsg.AddItem zHoldMsg
                    Case "2039"
                        If (frmPort2039!ctlServer.State = sckConnected) Then frmPort2039!lstPortMsg.AddItem zHoldMsg
                    Case "2040"
                        If (frmPort2040!ctlServer.State = sckConnected) Then frmPort2040!lstPortMsg.AddItem zHoldMsg
                    Case "2041"
                        If (frmPort2041!ctlServer.State = sckConnected) Then frmPort2041!lstPortMsg.AddItem zHoldMsg
                    Case "2042"
                        If (frmPort2042!ctlServer.State = sckConnected) Then frmPort2042!lstPortMsg.AddItem zHoldMsg
                    Case "2043"
                        If (frmPort2043!ctlServer.State = sckConnected) Then frmPort2043!lstPortMsg.AddItem zHoldMsg
                    Case "2044"
                        If (frmPort2044!ctlServer.State = sckConnected) Then frmPort2044!lstPortMsg.AddItem zHoldMsg
                    Case "2045"
                        If (frmPort2045!ctlServer.State = sckConnected) Then frmPort2045!lstPortMsg.AddItem zHoldMsg
                    Case "2046"
                        If (frmPort2046!ctlServer.State = sckConnected) Then frmPort2046!lstPortMsg.AddItem zHoldMsg
                    Case "2047"
                        If (frmPort2047!ctlServer.State = sckConnected) Then frmPort2047!lstPortMsg.AddItem zHoldMsg
                    Case "2048"
                        If (frmPort2048!ctlServer.State = sckConnected) Then frmPort2048!lstPortMsg.AddItem zHoldMsg
                    Case "2049"
                        If (frmPort2049!ctlServer.State = sckConnected) Then frmPort2049!lstPortMsg.AddItem zHoldMsg
                    Case "2050"
                        If (frmPort2050!ctlServer.State = sckConnected) Then frmPort2050!lstPortMsg.AddItem zHoldMsg
                    Case "2051"
                        If (frmPort2051!ctlServer.State = sckConnected) Then frmPort2051!lstPortMsg.AddItem zHoldMsg
                    Case "2052"
                        If (frmPort2052!ctlServer.State = sckConnected) Then frmPort2052!lstPortMsg.AddItem zHoldMsg
                    Case "2053"
                        If (frmPort2053!ctlServer.State = sckConnected) Then frmPort2053!lstPortMsg.AddItem zHoldMsg
                    Case "2054"
                        If (frmPort2054!ctlServer.State = sckConnected) Then frmPort2054!lstPortMsg.AddItem zHoldMsg
                    Case "2055"
                        If (frmPort2055!ctlServer.State = sckConnected) Then frmPort2055!lstPortMsg.AddItem zHoldMsg
                    Case "2056"
                        If (frmPort2056!ctlServer.State = sckConnected) Then frmPort2056!lstPortMsg.AddItem zHoldMsg
                    Case "2057"
                        If (frmPort2057!ctlServer.State = sckConnected) Then frmPort2057!lstPortMsg.AddItem zHoldMsg
                End Select
            End If
        Next
    End If
End Sub
Public Sub subSendMsgNoPortCheck(zPassColorMsg As String, ParamArray vPortID() As Variant) 'vPortID you can add more than one portid to the end
On Error Resume Next
    Dim vEachPort As Variant
    Dim zHoldMsg As String
    
    If (zPassColorMsg <> "") Then
        zHoldMsg = zTranslateColour(zPassColorMsg)
        zHoldMsg = strReplaceWordWithThisWord(zHoldMsg, Chr(255), vbCrLf)
        For Each vEachPort In vPortID()
            'subSendMsgNoPortCheck' If (gbliFlow(MyCLng(vEachPort)) > 99) Then 'is the user fully logged in and in the game or at the login screen?
            Select Case vEachPort
                'Case "23" 'for port full string
                '    If (frmPort23!ctlServer.State = sckConnected) Then frmPort23!lstPortMsg.AddItem zHoldMsg
                Case "2011"
                    If (frmPort2011!ctlServer.State = sckConnected) Then frmPort2011!lstPortMsg.AddItem zHoldMsg
                Case "2012"
                    If (frmPort2012!ctlServer.State = sckConnected) Then frmPort2012!lstPortMsg.AddItem zHoldMsg
                Case "2013"
                    If (frmPort2013!ctlServer.State = sckConnected) Then frmPort2013!lstPortMsg.AddItem zHoldMsg
                Case "2014"
                    If (frmPort2014!ctlServer.State = sckConnected) Then frmPort2014!lstPortMsg.AddItem zHoldMsg
                Case "2015"
                    If (frmPort2015!ctlServer.State = sckConnected) Then frmPort2015!lstPortMsg.AddItem zHoldMsg
                Case "2016"
                    If (frmPort2016!ctlServer.State = sckConnected) Then frmPort2016!lstPortMsg.AddItem zHoldMsg
                Case "2017"
                    If (frmPort2017!ctlServer.State = sckConnected) Then frmPort2017!lstPortMsg.AddItem zHoldMsg
                Case "2018"
                    If (frmPort2018!ctlServer.State = sckConnected) Then frmPort2018!lstPortMsg.AddItem zHoldMsg
                Case "2019"
                    If (frmPort2019!ctlServer.State = sckConnected) Then frmPort2019!lstPortMsg.AddItem zHoldMsg
                Case "2020"
                    If (frmPort2020!ctlServer.State = sckConnected) Then frmPort2020!lstPortMsg.AddItem zHoldMsg
                Case "2021"
                    If (frmPort2021!ctlServer.State = sckConnected) Then frmPort2021!lstPortMsg.AddItem zHoldMsg
                Case "2022"
                    If (frmPort2022!ctlServer.State = sckConnected) Then frmPort2022!lstPortMsg.AddItem zHoldMsg
                Case "2023"
                    If (frmPort2023!ctlServer.State = sckConnected) Then frmPort2023!lstPortMsg.AddItem zHoldMsg
                Case "2024"
                    If (frmPort2024!ctlServer.State = sckConnected) Then frmPort2024!lstPortMsg.AddItem zHoldMsg
                Case "2025"
                    If (frmPort2025!ctlServer.State = sckConnected) Then frmPort2025!lstPortMsg.AddItem zHoldMsg
                Case "2026"
                    If (frmPort2026!ctlServer.State = sckConnected) Then frmPort2026!lstPortMsg.AddItem zHoldMsg
                Case "2027"
                    If (frmPort2027!ctlServer.State = sckConnected) Then frmPort2027!lstPortMsg.AddItem zHoldMsg
                Case "2028"
                    If (frmPort2028!ctlServer.State = sckConnected) Then frmPort2028!lstPortMsg.AddItem zHoldMsg
                Case "2029"
                    If (frmPort2029!ctlServer.State = sckConnected) Then frmPort2029!lstPortMsg.AddItem zHoldMsg
                Case "2030"
                    If (frmPort2030!ctlServer.State = sckConnected) Then frmPort2030!lstPortMsg.AddItem zHoldMsg
                Case "2031"
                    If (frmPort2031!ctlServer.State = sckConnected) Then frmPort2031!lstPortMsg.AddItem zHoldMsg
                Case "2032"
                    If (frmPort2032!ctlServer.State = sckConnected) Then frmPort2032!lstPortMsg.AddItem zHoldMsg
                Case "2033"
                    If (frmPort2033!ctlServer.State = sckConnected) Then frmPort2033!lstPortMsg.AddItem zHoldMsg
                Case "2034"
                    If (frmPort2034!ctlServer.State = sckConnected) Then frmPort2034!lstPortMsg.AddItem zHoldMsg
                Case "2035"
                    If (frmPort2035!ctlServer.State = sckConnected) Then frmPort2035!lstPortMsg.AddItem zHoldMsg
                Case "2036"
                    If (frmPort2036!ctlServer.State = sckConnected) Then frmPort2036!lstPortMsg.AddItem zHoldMsg
                Case "2037"
                    If (frmPort2037!ctlServer.State = sckConnected) Then frmPort2037!lstPortMsg.AddItem zHoldMsg
                Case "2038"
                    If (frmPort2038!ctlServer.State = sckConnected) Then frmPort2038!lstPortMsg.AddItem zHoldMsg
                Case "2039"
                    If (frmPort2039!ctlServer.State = sckConnected) Then frmPort2039!lstPortMsg.AddItem zHoldMsg
                Case "2040"
                    If (frmPort2040!ctlServer.State = sckConnected) Then frmPort2040!lstPortMsg.AddItem zHoldMsg
                Case "2041"
                    If (frmPort2041!ctlServer.State = sckConnected) Then frmPort2041!lstPortMsg.AddItem zHoldMsg
                Case "2042"
                    If (frmPort2042!ctlServer.State = sckConnected) Then frmPort2042!lstPortMsg.AddItem zHoldMsg
                Case "2043"
                    If (frmPort2043!ctlServer.State = sckConnected) Then frmPort2043!lstPortMsg.AddItem zHoldMsg
                Case "2044"
                    If (frmPort2044!ctlServer.State = sckConnected) Then frmPort2044!lstPortMsg.AddItem zHoldMsg
                Case "2045"
                    If (frmPort2045!ctlServer.State = sckConnected) Then frmPort2045!lstPortMsg.AddItem zHoldMsg
                Case "2046"
                    If (frmPort2046!ctlServer.State = sckConnected) Then frmPort2046!lstPortMsg.AddItem zHoldMsg
                Case "2047"
                    If (frmPort2047!ctlServer.State = sckConnected) Then frmPort2047!lstPortMsg.AddItem zHoldMsg
                Case "2048"
                    If (frmPort2048!ctlServer.State = sckConnected) Then frmPort2048!lstPortMsg.AddItem zHoldMsg
                Case "2049"
                    If (frmPort2049!ctlServer.State = sckConnected) Then frmPort2049!lstPortMsg.AddItem zHoldMsg
                Case "2050"
                    If (frmPort2050!ctlServer.State = sckConnected) Then frmPort2050!lstPortMsg.AddItem zHoldMsg
                Case "2051"
                    If (frmPort2051!ctlServer.State = sckConnected) Then frmPort2051!lstPortMsg.AddItem zHoldMsg
                Case "2052"
                    If (frmPort2052!ctlServer.State = sckConnected) Then frmPort2052!lstPortMsg.AddItem zHoldMsg
                Case "2053"
                    If (frmPort2053!ctlServer.State = sckConnected) Then frmPort2053!lstPortMsg.AddItem zHoldMsg
                Case "2054"
                    If (frmPort2054!ctlServer.State = sckConnected) Then frmPort2054!lstPortMsg.AddItem zHoldMsg
                Case "2055"
                    If (frmPort2055!ctlServer.State = sckConnected) Then frmPort2055!lstPortMsg.AddItem zHoldMsg
                Case "2056"
                    If (frmPort2056!ctlServer.State = sckConnected) Then frmPort2056!lstPortMsg.AddItem zHoldMsg
                Case "2057"
                    If (frmPort2057!ctlServer.State = sckConnected) Then frmPort2057!lstPortMsg.AddItem zHoldMsg
            End Select
            'End If
        Next
    End If
End Sub

Public Sub subSendMsgAreaAllDetectInvisibility(zColour As String, lPlayerID As Long, zMessageNoDetectInvisibility As String, zMessageDetectInvisibility As String, zMessageSelfNoDetectInvisibility As String, zMessageSelfDetectInvisibility As String, lX As Long, lY As Long, lZ As Long, bInvisible As Boolean, Optional zNoShowPortID As String)
'subSendMsgAreaAllDetectInvisibility gblzFBRED, MyCLng(rsPlr!PlayerID), zMessageNoDetectInvisibility, zMessageDetectInvisibility, zMessageSelfNoDetectInvisibility, zMessageSelfDetectInvisibility, lOX, lOY, lOZ, MyCLng(rsMob!Visible), ""
'lPlayerID OR zPortID will not see any messages, this is very similar to the subSendMsgAreaExcept2 function
On Error GoTo Err_Check
'Message all in room except me and target!
    Dim rsData As Recordset
    Dim bSkipPort As Boolean
    Dim bVerboseName As Boolean
    Dim bMessageNoDetectInvisibility As Boolean
    Dim bMessageDetectInvisibility As Boolean
    Dim bMessageSelfNoDetectInvisibility As Boolean
    Dim bMessageSelfDetectInvisibility As Boolean
    Dim zPortID As String
    
    Set rsData = MyDB.OpenRecordset("SELECT SleepDuration, DetectInvisibilityDuration, BlindDuration, StunDuration, PlayerID, PortID FROM tblPlayer WHERE (Len([PortID])>1 and Status<>50 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot) 'Status <> 50 means not asleep
    Do While (Not rsData.EOF)
        zPortID = rsData!PortID
        If (zPortID <> zNoShowPortID) Then 'sometimes we dont want some ports to see this port such as self
            If (bInvisible) Then
                bVerboseName = (MyCLng(rsData!DetectInvisibilityDuration) <> 0) And (MyCLng(rsData!BlindDuration) = 0) And (MyCLng(rsData!StunDuration) = 0) And (MyCLng(rsData!SleepDuration) = 0)
            Else
                bVerboseName = (MyCLng(rsData!BlindDuration) = 0) And (MyCLng(rsData!StunDuration) = 0) And (MyCLng(rsData!SleepDuration) = 0)
            End If
            
            If (rsData!PlayerID = lPlayerID) Then
                'The player can be invisible to themselves - such as when they pick something up or removes something
                If (bVerboseName) Then
                    If (Len(zMessageSelfDetectInvisibility) > 0) Then subSendMsg zColour & zMessageSelfDetectInvisibility, zPortID
                Else
                    If (Len(zMessageSelfNoDetectInvisibility) > 0) Then subSendMsg zColour & zMessageSelfNoDetectInvisibility, zPortID
                End If
            Else
                'The player is invisible to the other players
                If (bVerboseName) Then
                    If (Len(zMessageDetectInvisibility) > 0) Then subSendMsg zColour & zMessageDetectInvisibility, zPortID
                Else
                    If (Len(zMessageNoDetectInvisibility) > 0) Then subSendMsg zColour & zMessageNoDetectInvisibility, zPortID
                End If
            End If
        End If
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllDetectInvisibility," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAllDISmart(zColour As String, zOActorPlayerName As String, zOMessage As String, zTActorPlayerName As String, zTMessage As String, lX As Long, lY As Long, lZ As Long, Optional zNoShowPortID As String, Optional lTargetInvisible As Long)
'subSendMsgAreaAllDetectInvisibility gblzFBRED, MyCLng(rsPlr!PlayerID), zMessageNoDetectInvisibility, zMessageDetectInvisibility, zMessageSelfNoDetectInvisibility, zMessageSelfDetectInvisibility, lOX, lOY, lOZ, MyCLng(rsMob!Visible), ""
'lPlayerID OR zPortID will not see any messages, this is very similar to the subSendMsgAreaExcept2 function
On Error GoTo Err_Check
'%s1 = zOActorPlayerName %s2 = zTActorPlayerName
'Original actor and target actors act to the room
'the rest of the room sees them as people or a you (self) etc...
'Message all in room except me and target!
    Dim rsData As Recordset
    Dim bSkipPort As Boolean
    
    Dim bMessageNoDetectInvisibility As Boolean
    Dim bMessageDetectInvisibility As Boolean
    Dim bMessageSelfNoDetectInvisibility As Boolean
    Dim bMessageSelfDetectInvisibility As Boolean
    
    'shared variables
    Dim zPlayerName As String
    Dim zPortID As String
    
    Dim bOVerboseName As Boolean
    Dim bOActorInvisible As Boolean
    
    Dim bTVerboseName As Boolean
    Dim zPrintMessage As String
    Dim bTActorInvisible As Boolean
    
    Dim zOGender As String
    Dim zTGender As String
    
    'subSendMsgAreaAllDISmart "Traer", "Charlie", "%s1 casted as heal spell on %s2.", 0, 0, 0
    'for example
    'In the room
    '"%s1 casts a heal on %s2" (zTMessage)
    '"Traer casts a heal on Charlie"
    '"Someone casts a heal on Charlie"
    '"Traer casts a heal on Someone"
    '"Someone casts a heal on Someone"
    'Original Self (zOMessage)
    '"You casted a heal on Charlie"
    '"You casted a heal on Someone"
    'Target (zTMessage)
    '"Traer casted a heal on You."
    '"Someone casted a heal on You."
    
    'zTActorPlayerName As String, bTActorInvisible As Boolean
    
    'Look for the PlayerName
    zOGender = ""
    bOActorInvisible = False
    Set rsData = MyDB.OpenRecordset("SELECT Gender, HideDuration, CamoflaguedDuration, InvisibilityDuration FROM tblPlayer WHERE (PlayerName='" & zKeepLettersOnly(zOActorPlayerName) & "' AND Len([PortID])>1);", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        bOActorInvisible = (MyCLng(rsData!InvisibilityDuration) <> 0 Or MyCLng(rsData!HideDuration) <> 0 Or MyCLng(rsData!CamoflaguedDuration) <> 0)
        zOGender = UCase(MyCStr(rsData!Gender))
    End If
    Set rsData = Nothing
    'Debug.Print zOActorPlayerName & " I" & bOActorInvisible
    
    'the target doesnt have to be in the same room.
    zTGender = ""
    bTActorInvisible = False
    Set rsData = MyDB.OpenRecordset("SELECT Gender, HideDuration, CamoflaguedDuration, InvisibilityDuration FROM tblPlayer WHERE (PlayerName='" & zKeepLettersOnly(zTActorPlayerName) & "' AND Len([PortID])>1);", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        bTActorInvisible = (MyCLng(rsData!InvisibilityDuration) <> 0 Or MyCLng(rsData!HideDuration) <> 0 Or MyCLng(rsData!CamoflaguedDuration) <> 0)
        zTGender = UCase(MyCStr(rsData!Gender))
    End If
    Set rsData = Nothing
    
    If (lTargetInvisible <> 0) Then 'mobs and objects need this if optional statement
        bTActorInvisible = True
        zTGender = "M"
    End If
    
    'Debug.Print zTActorPlayerName & " I" & bOActorInvisible
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName, Status, DetectInvisibilityDuration, BlindDuration, StunDuration, PlayerID, PortID FROM tblPlayer WHERE (Len([PortID])>1 AND SleepDuration=0 AND Status<>50 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot) 'Status <> 50 means not asleep
    Do While (Not rsData.EOF)
        zPortID = rsData!PortID
        zPlayerName = rsData!PlayerName
        If (zPortID <> zNoShowPortID) Then 'sometimes we dont want some ports to see this port such as self
            If (bOActorInvisible) Then
                bOVerboseName = (MyCLng(rsData!DetectInvisibilityDuration) <> 0) And (MyCLng(rsData!BlindDuration) = 0) And (MyCLng(rsData!StunDuration) = 0)
            Else
                bOVerboseName = (MyCLng(rsData!BlindDuration) = 0) And (MyCLng(rsData!StunDuration) = 0)
            End If
            
            If (bTActorInvisible) Then
                bTVerboseName = (MyCLng(rsData!DetectInvisibilityDuration) <> 0) And (MyCLng(rsData!BlindDuration) = 0) And (MyCLng(rsData!StunDuration) = 0)
            Else
                bTVerboseName = (MyCLng(rsData!BlindDuration) = 0) And (MyCLng(rsData!StunDuration) = 0)
            End If
            
            'If (zPlayerName = "Epic") Then
            '    'Debug.Print zPlayerName & " can see " & zOActorPlayerName & "I" & bOActorInvisible & " OV" & bOVerboseName & " - " & zTActorPlayerName & "I" & bTActorInvisible & " TV" & bTVerboseName & vbCrLf
            'End If
            
            Select Case (zPlayerName = zOActorPlayerName)
                Case True 'player to themselves
                    If (Len(zOMessage) > 0) Then
                        zPrintMessage = strReplaceWordWithThisWord(zOMessage, "%s1", "you") 'we can always see ourselves
                    Else
                        zPrintMessage = strReplaceWordWithThisWord(zTMessage, "%s1", "you") 'we can always see ourselves
                    End If
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "yourself")
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "yourself")
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "yourself")
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "yourself")
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "yourself")
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "yourself")
                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "yourself")
                    
                    Select Case zTGender
                        Case "M"
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "him")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "he")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "his")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "himself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "male")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "guy")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "boy")
                        Case "F"
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "her")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "she")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "her")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "herself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "female")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "gal")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "girl")
                        Case Else
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "it")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "it")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "its")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "itself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "it")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "it")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "it")
                    End Select
                    
                    If (bTVerboseName) Then
                        zPrintMessage = strReplaceWordWithThisWord(zPrintMessage, "%s2", zTActorPlayerName)
                    Else
                        zPrintMessage = strReplaceWordWithThisWord(zPrintMessage, "%s2", "Someone")
                    End If
                Case False
                    Select Case (zPlayerName = zTActorPlayerName)
                        Case True
                            zPrintMessage = strReplaceWordWithThisWord(zTMessage, "%s2", "you") 'we can always see ourselves
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "yourself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "yourself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "yourself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "yourself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "yourself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "yourself")
                            zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "yourself")
                            
                            Select Case zOGender
                                Case "M"
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "him")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "he")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "his")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "himself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "male")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "guy")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "boy")
                                Case "F"
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "her")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "she")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "her")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "herself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "female")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "gal")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "girl")
                                Case Else
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "its")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "itself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "it")
                            End Select
                            If (bOVerboseName) Then
                                zPrintMessage = strReplaceWordWithThisWord(zPrintMessage, "%s1", zOActorPlayerName)
                            Else
                                zPrintMessage = strReplaceWordWithThisWord(zPrintMessage, "%s1", "Someone")
                            End If
                        Case False '3rd persons watching
                            If (bOVerboseName) Then
                                zPrintMessage = strReplaceWordWithThisWord(zTMessage, "%s1", zOActorPlayerName)
                            Else
                                zPrintMessage = strReplaceWordWithThisWord(zTMessage, "%s1", "Someone")
                            End If
                            Select Case zOGender
                                Case "M"
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "him")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "he")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "his")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "himself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "male")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "guy")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "boy")
                                Case "F"
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "her")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "she")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "her")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "herself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "female")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "gal")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "girl")
                                Case Else
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g10", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g11", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g12", "its")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g13", "itself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g14", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g15", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g16", "it")
                            End Select
                            
                            If (bTVerboseName) Then
                                zPrintMessage = strReplaceWordWithThisWord(zPrintMessage, "%s2", zTActorPlayerName)
                            Else
                                zPrintMessage = strReplaceWordWithThisWord(zPrintMessage, "%s2", "Someone")
                            End If
                            Select Case zTGender
                                Case "M"
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "him")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "he")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "his")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "himself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "male")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "guy")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "boy")
                                Case "F"
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "her")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "she")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "her")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "herself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "female")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "gal")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "girl")
                                Case Else
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g20", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g21", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g22", "its")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g23", "itself")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g24", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g25", "it")
                                    zPrintMessage = basReplaceCharWithThisWord(zPrintMessage, "%g26", "it")
                            End Select
                    End Select
            End Select
            
            'Caps the first letter whatever it is
            zPrintMessage = (UCase(Mid(zPrintMessage, 1, 1)) & Mid(zPrintMessage, 2))
            
            If (Len(zPrintMessage) > 0) Then subSendMsg (zColour & zPrintMessage), zPortID
        End If
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllDISmart," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMsgAreaAllInvisibility(zColour As String, zPlayerName As String, lPlayerLevel As Long, lInvisibilityDuration As Long, lCINT As Long, lPlayerID As Long, zMessage As String, lX As Long, lY As Long, lZ As Long, Optional zPortID As String)
'lPlayerID OR zPortID will not see any messages, this is very similar to the subSendMsgAreaExcept2 function
On Error GoTo Err_Check
'Message all in room except me and target! You have send yourself the message before you call this sub using subSendMsg zPrintMessage, zPortID
    Dim rsData As Recordset
    Dim bSkipPort As Boolean
    
    Set rsData = MyDB.OpenRecordset("SELECT SleepDuration, BlindDuration, StunDuration, DetectInvisibilityDuration, PlayerLevel, CINT, PlayerName, PortID FROM tblPlayer WHERE (Status <> 50) AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ") AND (PlayerID<>" & lPlayerID & ");", dbOpenSnapshot) 'Status <> 50 means not asleep
    Do While (Not rsData.EOF)
        If (MyCStr(rsData!PortID) <> zPortID) Then
            If (MyCLng(rsData!SleepDuration) = 0) And (MyCLng(rsData!StunDuration) = 0) And (MyCLng(rsData!BlindDuration) = 0) And ((lInvisibilityDuration = 0) Or (MyCLng(rsData!DetectInvisibilityDuration) <> 0)) Then
                If (InStr(zPlayerName, "*")) Then 'this is a coders code to allow the message to flow freely
                    subSendMsg zColour & zMessage, MyCStr(rsData!PortID)
                Else
                    subSendMsg zColour & zPlayerName & " " & zMessage, MyCStr(rsData!PortID)
                End If
            Else
                If (InStr(zPlayerName, "*")) Then 'this is a coders code to all the message to flow freely
                    subSendMsg zColour & zMessage, MyCStr(rsData!PortID)
                Else
                    subSendMsg zColour & "Someone " & zMessage, MyCStr(rsData!PortID)
                End If
            End If
        End If
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMsgAreaAllInvisibility," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub

