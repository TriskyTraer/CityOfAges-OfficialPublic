VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.MDIForm mdiMainMenu 
   Appearance      =   0  'Flat
   BackColor       =   &H00004000&
   Caption         =   "City of Ages Server"
   ClientHeight    =   5430
   ClientLeft      =   60
   ClientTop       =   630
   ClientWidth     =   5520
   Icon            =   "mdiMainMenu.frx":0000
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   2  'CenterScreen
   WindowState     =   1  'Minimized
   Begin CityofAgesServer.uc_systray Systray 
      Left            =   3120
      Top             =   1800
      _ExtentX        =   847
      _ExtentY        =   847
      Icon            =   "mdiMainMenu.frx":0442
      Visible         =   -1  'True
      SysMenu         =   0   'False
   End
   Begin VB.PictureBox pichook 
      Align           =   1  'Align Top
      Height          =   135
      Left            =   0
      ScaleHeight     =   75
      ScaleWidth      =   5460
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   5520
   End
   Begin VB.PictureBox picMainMenu 
      Align           =   2  'Align Bottom
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H00004000&
      BorderStyle     =   0  'None
      CausesValidation=   0   'False
      ClipControls    =   0   'False
      ForeColor       =   &H80000008&
      Height          =   1260
      Left            =   0
      ScaleHeight     =   1260
      ScaleWidth      =   5520
      TabIndex        =   0
      Top             =   4170
      Width           =   5520
      Begin VB.ListBox lstErrorMsgs 
         Appearance      =   0  'Flat
         Height          =   1005
         ItemData        =   "mdiMainMenu.frx":0894
         Left            =   0
         List            =   "mdiMainMenu.frx":0896
         TabIndex        =   1
         ToolTipText     =   "Errors Box"
         Top             =   0
         Width           =   5535
      End
   End
   Begin MSComDlg.CommonDialog CDCommon 
      Left            =   1440
      Top             =   1800
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuProgramTitle 
         Caption         =   "City of Ages"
      End
      Begin VB.Menu mnuRunCoAClient 
         Caption         =   "&Run CoA Client"
      End
      Begin VB.Menu mnuMinimizeToTray 
         Caption         =   "&Minimize to Tray"
      End
      Begin VB.Menu mnuRestoreTaskbar 
         Caption         =   "&Restore Task Bar"
      End
      Begin VB.Menu mnuHideTaskbar 
         Caption         =   "&Hide Task Bar"
      End
      Begin VB.Menu mnuHardQuit 
         Caption         =   "&Quit"
      End
   End
   Begin VB.Menu mnuUtilities 
      Caption         =   "&Utilities"
      Begin VB.Menu mnuMakePlayerAdministrator 
         Caption         =   "Make Player Administrator"
      End
      Begin VB.Menu mnuAsciiArt 
         Caption         =   "&Ascii Art"
      End
      Begin VB.Menu mnuAreaAllStaticMode 
         Caption         =   "Make all Areas not Recalculate - Fast Static Mode (5 mins work)"
      End
      Begin VB.Menu mnuAreaAllDynamicMode 
         Caption         =   "Make all Areas Recalculate EXITS - Slow Dynamic Mode (5 mins work)"
      End
      Begin VB.Menu mnuResetAllMobs 
         Caption         =   "Reset all Mobs"
      End
      Begin VB.Menu mnuProtectSystemObjects 
         Caption         =   "Protect System Objects"
      End
      Begin VB.Menu mnuBalanceTheMUDMyWay 
         Caption         =   "Balance the MUD my way"
         Visible         =   0   'False
      End
      Begin VB.Menu mnuVerifyMobEquipment 
         Caption         =   "Verify Mob Equipment"
      End
      Begin VB.Menu mnuClearRedErrorMessages 
         Caption         =   "Clear Red Error Messages (hides the errors does not fix them)"
      End
   End
   Begin VB.Menu mnuWindow 
      Caption         =   "&Ports"
      WindowList      =   -1  'True
      Begin VB.Menu mnuRemoveBannedPorts 
         Caption         =   "Clear and Forgive all &Banned Players"
      End
      Begin VB.Menu mnuChangeDynamicPorts 
         Caption         =   "Change Dynamic Ports"
      End
      Begin VB.Menu mnuListofAllPorts 
         Caption         =   "List of All Ports"
      End
   End
   Begin VB.Menu mnuSteamPoweredUsers 
      Caption         =   "Steam Powered Users"
      Begin VB.Menu mnuSteamPoweredUsersSetup 
         Caption         =   "Steam Setup"
      End
   End
End
Attribute VB_Name = "mdiMainMenu"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const bWait = False
Private Type NOTIFYICONDATA
    cbSize As Long
    hWnd As Long
    uId As Long
    uFlags As Long
    uCallBackMessage As Long
    hIcon As Long
    szTip As String * 64
End Type

Private Const NIM_ADD = &H0
Private Const NIM_MODIFY = &H1
Private Const NIM_DELETE = &H2
Private Const WM_MOUSEMOVE = &H200
Private Const NIF_MESSAGE = &H1
Private Const NIF_ICON = &H2
Private Const NIF_TIP = &H4

Private Const WM_LBUTTONDBLCLK = &H203
Private Const WM_LBUTTONDOWN = &H201
Private Const WM_LBUTTONUP = &H202
Private Const WM_RBUTTONDBLCLK = &H206
Private Const WM_RBUTTONDOWN = &H204
Private Const WM_RBUTTONUP = &H205

Private Declare Function Shell_NotifyIcon Lib "shell32" Alias "Shell_NotifyIconA" (ByVal dwMessage As Long, pnid As NOTIFYICONDATA) As Boolean
Dim t As NOTIFYICONDATA
Private Sub MDIForm_Activate()
On Error Resume Next
    gblbArenaOnOff = False '1=on anything else means off
    gblbServerWillBeRightBack = False
    gblbAlternateConnectPortsEnabled = True 'This is an extra connect port - some players may find it useful if their port 23 is blocked
End Sub
Private Sub subInitRealmGhostOnServer()
    gblzServerGhostPortID = ""
    gbllServerGhostPlayerID = 0
    gblbRealmGhostCemetaryAwake = False
    gbllServerGhostX = 0
    gbllServerGhostY = 0
    gbllServerGhostZ = 0
    gbllServerGhostDX1 = -9 'cemetary
    gbllServerGhostDX2 = -12
    gbllServerGhostDY1 = -1
    gbllServerGhostDY2 = -7
End Sub
Private Sub MDIForm_Load()
On Error Resume Next
    subInitRealmGhostOnServer

    frmPort23.Show
    
    frmDTPortAlternate1.Show
    frmDTPortAlternate2.Show
    frmTelnetServerEngine.Show
    subRemoveAreaDayNiteColours
End Sub
Private Sub subSoftUnload()
On Error Resume Next
    gblbServerWillBeRightBack = True
    subCleanUpPorts
    'subShutdownPorts "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "23", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "2036", "2037", "2038", "2039", "2040", "2041", "2042", "2043", "2044", "2045", "2046", "2047", "2048", "2049", "2050", "2051", "2052", "2053", "2054", "2055", "2056", "2057", "4000", MyCStr(gbllDynamicPortID2)
    'subCompactNRepair 1
    'basAdminFollowText "SYSTEM OFFLINE: " & Format(Date, "mmm dd, yyyy") & " TIME: " & Format(Time(), "HH:NN")
    End
End Sub

Private Sub MDIForm_Resize()
    If (Not gblbAsciiFormActive) Then subPicHookTrayFormLoad
    cmdResizemdiMainMenuForm
End Sub
Private Sub MDIForm_Unload(Cancel As Integer)
    subSoftUnload
End Sub

Private Sub mnuAreaAllStaticMode_Click()
    If (MsgBox("Set All Areas to Static Faster Movement Mode?" & vbCrLf & "This will cause each area you move into to be faster as all 'Quick Exits:' are calculated ONE TIME, for each and every area." & vbCrLf & " NOTE: An immortal can use IMMO DYNA S/D to manually toggle each area.", vbOKCancel) = vbOK) Then
        subSetEntireMUDAreasToEitherStaticOrDynamic "S"
    End If
End Sub

Private Sub mnuAreaAllDynamicMode_Click()
    If (MsgBox("Set All Areas to Dynamic Slower Movement Mode?" & vbCrLf & "This will cause each area you move into to be slower as all 'Quick Exits:' are recalculated each and everytime.", vbOKCancel) = vbOK) Then
        subSetEntireMUDAreasToEitherStaticOrDynamic "D"
    End If
End Sub


Private Sub mnuAsciiArt_Click()
    mdiMainMenu.WindowState = vbMaximized
    mdiMainMenu.Show
    frmAsciiArt.Show
End Sub

Private Sub mnuChangeDynamicPorts_Click()
    frmDTPortChanges.Show
End Sub

Private Sub mnuClearRedErrorMessages_Click()
'on error resume next
    MyDB.Execute "delete * from tblsystemerrors;", dbFailOnError
    frmTelnetServerEngine.lblSystemErrors = "...waiting for update..."
End Sub

Private Sub mnuMakePlayerAdministrator_Click()
    frmMakePlayerAdministrator.Show
End Sub

Private Sub mnuMinimizeToTray_Click()
    subPicHookTrayFormLoad
End Sub

Private Sub mnuProgramTitle_Click()
On Error Resume Next
    MsgBox "~City of Ages~" & vbCrLf & "WRITTEN BY:" & vbCrLf & vbCrLf & zDecrypt("CbqsdoO-!Kpqz)Ss`fq*"), vbOKOnly
End Sub
Public Sub subRemoveAreaDayNiteColours() 'we do not allow any ascii colors into the area descriptions
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim zADD As String
    Dim zADN As String
    Dim zHold As String
    Dim zChar As String
    Dim lCounter As Long
    Dim lLen As Long
    
    Set rsArea = MyDB.OpenRecordset("SELECT AreaName, AreaDescDay, AreaDescNight FROM tblArea;", dbOpenDynaset)
    Do While (Not rsArea.EOF)
        zADD = MyCStr(rsArea!AreaDescDay)
        If (InStr(zADD, "&") <> 0) Then
            lLen = Len(zADD): lCounter = 0: zHold = ""
            Do
                lCounter = lCounter + 1
                zChar = Mid(zADD, lCounter, 1)
                Select Case zChar
                    Case "&" 'we skip color codes
                        lCounter = lCounter + 1
                    Case Else
                        zHold = zHold & zChar
                End Select
            Loop Until (lCounter >= lLen)
            'Debug.Print "DBEFORE" & vbCrLf & zADD
            'Debug.Print "DAFTER" & vbCrLf & zHold
            rsArea.Edit
            rsArea!AreaDescDay = zHold
            rsArea.Update
        End If
        
        zADN = MyCStr(rsArea!AreaDescNight)
        If (InStr(zADN, "&") <> 0) Then
            lLen = Len(zADN): lCounter = 0: zHold = ""
            Do
                lCounter = lCounter + 1
                zChar = Mid(zADN, lCounter, 1)
                Select Case zChar
                    Case "&" 'we skip color codes
                        lCounter = lCounter + 1
                    Case Else
                        zHold = zHold & zChar
                End Select
            Loop Until (lCounter >= lLen)
            
            'Debug.Print "NBEFORE" & vbCrLf & zADN
            'Debug.Print "NAFTER" & vbCrLf & zHold
            rsArea.Edit
            rsArea!AreaDescNight = zHold
            rsArea.Update
        End If
        rsArea.MoveNext
    Loop
    Set rsArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subRemoveAreaDayNiteColours," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub mnuProtectSystemObjects_Click()
On Error GoTo Err_Check
'Dim rsData As Recordset
'Set rsData = MyDB.OpenRecordset("", dbOpenSnapshot)
'Do While (Not rsData.EOF)
    'rsData.MoveNext
'Loop
'Set rsData = Nothing
    Dim zMsg As String
    zMsg = ""

    'SystemProtected MDB variable: 0=no 1=yes, object is part of the system quests or perminant ground items
    MyDB.Execute "UPDATE tblObject SET tblObject.SystemProtected = 1 WHERE (((tblObject.Status)=1));", dbFailOnError
    zMsg = zMsg & "Mob held Items [ie. female guard's Spiked Buckler Shield]" & vbCrLf
    MyDB.Execute "UPDATE tblObject INNER JOIN tblMobQuestObject ON tblObject.ObjectName = tblMobQuestObject.ObjectName SET tblObject.SystemProtected = 1 WHERE (((tblObject.Status)=1));", dbFailOnError
    zMsg = zMsg & "Give a Quest Item [ie. wolf-tooth]" & vbCrLf
    MyDB.Execute "UPDATE tblMobQuestObject INNER JOIN tblObject ON tblMobQuestObject.QuestObjectID = tblObject.ObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    zMsg = zMsg & "Quest Items [ie. rabbit earring]" & vbCrLf
    MyDB.Execute "UPDATE tblMobQuestHerd INNER JOIN tblObject ON tblMobQuestHerd.ObjectID = tblObject.ObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    zMsg = zMsg & "Herd Quests [ie. Mosquito weapon]" & vbCrLf
    MyDB.Execute "UPDATE tblObject SET tblObject.SystemProtected = 1 WHERE (((tblObject.SitMAX)>0)) OR (((tblObject.Location)=0));", dbFailOnError
    zMsg = zMsg & "Perminant Sit down on fixtures [ie. bench at 0,0,0]" & vbCrLf
    zMsg = zMsg & "Perminant Container Items ground locked [ie. corpse at -22 -11 4]" & vbCrLf
    MyDB.Execute "UPDATE tblObject SET SystemProtected = 1 WHERE (CaptureFlagClanID<>0);", dbFailOnError
    zMsg = zMsg & "Clan Flags get system proteted" & vbCrLf
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectContainerRespawn ON tblObject.ObjectID = tblObjectContainerRespawn.ObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    zMsg = zMsg & "Perminant Container's [ie. labby pirate-chest]" & vbCrLf
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectContainerRespawn ON tblObject.ObjectID = tblObjectContainerRespawn.ContainerObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    MyDB.Execute "UPDATE tblObject AS tblObjectInContainer INNER JOIN (tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ContainerObjectID) ON tblObjectInContainer.ObjectID = tblPlayerContainer.ObjectID SET tblObjectInContainer.SystemProtected = 1 WHERE (((tblObject.Location)=0) AND ((tblObject.LockStatus)<>0));", dbFailOnError
    zMsg = zMsg & "Perminant Container Items [ie. Scully Whapper in the labby pirate-chest]" & vbCrLf
    MyDB.Execute "UPDATE tblObjectContainerRespawn SET tblObjectContainerRespawn.RespawnDuration = 3;", dbFailOnError 'this one is special as we make sure the items respawn back into the chests
    MyDB.Execute "UPDATE tblMerchandise INNER JOIN tblObject ON tblMerchandise.ObjectID = tblObject.ObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    zMsg = zMsg & "Mob Merchandise items" & vbCrLf
    MyDB.Execute "UPDATE tblMobEquipmentItems INNER JOIN tblObject ON tblMobEquipmentItems.ObjectID = tblObject.ObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    zMsg = zMsg & "Mob Equipment items [ie. farmer John's bangle]"
    MyDB.Execute "UPDATE tblObject INNER JOIN tblAreaTransmute ON tblObject.ObjectID = tblAreaTransmute.MorphObjectID SET tblObject.SystemProtected = 1;", dbFailOnError
    zMsg = zMsg & "Transmute objects produced"
    basPrintMessage64 "The System Protected the following System Objects:" & vbCrLf & zMsg
    Exit Sub
Err_Check:
    basPrintMessage64 "mnuProtectSystemObjects_Click:" & vbCrLf & "Scripting error contact your programmer!"
    'subWriteErrorFile "subTitleScreen," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub mnuBalanceTheMUDMyWay_Click()
On Error GoTo Err_Check
    Dim lCount As Long
    Dim zClass As String
    Dim zMsg As String
    zMsg = ""

    'Move Cost of an Area should be around 20
    MyDB.Execute "UPDATE tblArea SET MoveCost=20 WHERE MoveCost>20;", dbFailOnError
    zMsg = zMsg & "Moving through Areas was balanced from 0 to 20." & vbCrLf
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectStargate ON tblObject.ObjectID = tblObjectStargate.ObjectID SET tblObject.StargateEnergyCharge = 100, tblObject.StargateStatus = 2;", dbFailOnError
    zMsg = zMsg & "Stargates safely reset." & vbCrLf
    
    'Balance Class [AS BA CL DR GL GY KN MA MO PA RA TH WA] Costs for Mana Ess Soul Move
    For lCount = 1 To 13
        Select Case lCount
            Case 1
                zClass = "AS"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 30+([LearnLevelRestricted]*3), ActivateEssenceCost = 50+([LearnLevelRestricted]*2), ActivateSoulCost = 120+([LearnLevelRestricted]*4), ActivateMoveCost = 50+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 2
                zClass = "BA"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 41+([LearnLevelRestricted]*3), ActivateEssenceCost = 55+([LearnLevelRestricted]*2), ActivateSoulCost = 55+([LearnLevelRestricted]*4), ActivateMoveCost = 95+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 3
                zClass = "CL"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 120+([LearnLevelRestricted]*2), ActivateSoulCost = 35+([LearnLevelRestricted]*4), ActivateMoveCost = 65+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 4
                zClass = "DR"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 120+([LearnLevelRestricted]*2), ActivateSoulCost = 35+([LearnLevelRestricted]*4), ActivateMoveCost = 65+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 5
                zClass = "GL"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 55+([LearnLevelRestricted]*2), ActivateSoulCost = 50+([LearnLevelRestricted]*4), ActivateMoveCost = 115+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 6
                zClass = "GY"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 41+([LearnLevelRestricted]*3), ActivateEssenceCost = 55+([LearnLevelRestricted]*2), ActivateSoulCost = 55+([LearnLevelRestricted]*4), ActivateMoveCost = 95+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 7
                zClass = "KN"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 41+([LearnLevelRestricted]*3), ActivateEssenceCost = 55+([LearnLevelRestricted]*2), ActivateSoulCost = 70+([LearnLevelRestricted]*4), ActivateMoveCost = 45+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 8
                zClass = "MA"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 120+([LearnLevelRestricted]*3), ActivateEssenceCost = 60+([LearnLevelRestricted]*2), ActivateSoulCost = 9+([LearnLevelRestricted]*4), ActivateMoveCost = 15+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 9
                zClass = "MO"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 100+([LearnLevelRestricted]*3), ActivateEssenceCost = 50+([LearnLevelRestricted]*2), ActivateSoulCost = 60+([LearnLevelRestricted]*4), ActivateMoveCost = 120+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 10
                zClass = "PA"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 120+([LearnLevelRestricted]*2), ActivateSoulCost = 35+([LearnLevelRestricted]*4), ActivateMoveCost = 65+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 11
                zClass = "RA"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 90+([LearnLevelRestricted]*2), ActivateSoulCost = 35+([LearnLevelRestricted]*4), ActivateMoveCost = 85+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 12
                zClass = "TH"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 55+([LearnLevelRestricted]*2), ActivateSoulCost = 65+([LearnLevelRestricted]*4), ActivateMoveCost = 125+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
            Case 13
                zClass = "WA"
                MyDB.Execute "UPDATE tblPlayerLearn SET ActivateManaCost = 55+([LearnLevelRestricted]*3), ActivateEssenceCost = 60+([LearnLevelRestricted]*2), ActivateSoulCost = 95+([LearnLevelRestricted]*4), ActivateMoveCost = 65+([LearnLevelRestricted]*2) WHERE (((ClassRestricted)='" & zClass & "'));", dbFailOnError
        End Select
        zMsg = zMsg & "Balance " & zTranslateClass(zClass) & " Mana Essence Soul Move Costs" & vbCrLf
    Next lCount
    
    'Balance Heal and Damage spells based on Costs
    MyDB.Execute "UPDATE tblPlayerLearn SET LearnDamage = -1 * ([LearnLevelRestricted]+[ActivateManaCost]+[ActivateSoulCost]+[ActivateEssenceCost]+([ActivateMoveCost]/2)+100) WHERE (LearnDamage<0);", dbFailOnError 'heal are * -1
    MyDB.Execute "UPDATE tblPlayerLearn SET LearnDamage = +1 * [LearnLevelRestricted]+[ActivateManaCost]+[ActivateSoulCost]+[ActivateEssenceCost]+([ActivateMoveCost]/2)+100 WHERE (LearnDamage>0);", dbFailOnError 'damage area * +1
    MyDB.Execute "UPDATE tblPlayerLearn SET LearnType = 1 WHERE (LearnType=2);", dbFailOnError
    zMsg = zMsg & "Balance all classes so that multiplying learntype is adding LearnType=1 to add level to damage only." & vbCrLf
    basPrintMessage64 "Balanced the Following:" & vbCrLf & zMsg
    
    Exit Sub
Err_Check:
    basPrintMessage64 "mnuBalanceTheMUDMyWay_Click:" & vbCrLf & "Scripting error contact your programmer!"
End Sub

Private Sub mnuRemoveBannedPorts_Click()
On Error Resume Next
    MyDB.Execute "UPDATE tblPlayerRemoteHost SET BannedIP=FALSE;", dbFailOnError
    MyDB.Execute "DELETE RemoteHostIP FROM tblPlayerRemoteHostCompletelyBanned;", dbFailOnError
    MsgBox "Completely banned list cleared!", vbOKOnly
End Sub

Private Sub mnuResetAllMobs_Click()
    MyDB.Execute "UPDATE tblMob SET RespawnDelay=1;", dbFailOnError
    subAutomaticallyReconfigure
    MsgBox "All the mobiles in the realm will disappear for a few minutes, this is normal on a reset.", vbOKOnly
End Sub

Private Sub mnuRunCoAClient_Click()
    subCoAClientLoad
End Sub
Private Sub mnuHardQuit_Click()
    subSoftUnload
End Sub
Private Sub mnuRestoreTaskbar_Click()
On Error Resume Next
    mdiMainMenu.Show
End Sub
Private Sub mnuHideTaskbar_Click()
On Error Resume Next
    mdiMainMenu.Hide
End Sub

Private Sub mnuSteamPoweredUsersSetup_Click()
    frmSteamPoweredConsiderTHIS.Show
End Sub
Private Sub mnuVerifyMobEquipment_Click()
    subVerifyMobEquipment
    basPrintMessage64 "V E R I F Y  M O B  E Q." & vbCrLf & "All the mob equipment in the system has been counted and validated to the mobs!" & vbCrLf & "ie. blob of good, is like jelly *I2*" & vbCrLf & "    - The blob has two items on it. This is so players can quickly swing by mobs and see who has items on it."
End Sub
Private Sub pichook_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
On Error Resume Next
    Static rec As Boolean, msg As Long
    msg = x / Screen.TwipsPerPixelX
    If rec = False Then
        rec = True
        Select Case msg
            Case WM_LBUTTONDBLCLK:
                Me.Show
            Case WM_LBUTTONDOWN:
            Case WM_LBUTTONUP:
            Case WM_RBUTTONDBLCLK:
            Case WM_RBUTTONDOWN:
            Case WM_RBUTTONUP:
                Me.PopupMenu mnuFile
        End Select
        rec = False
    End If
End Sub
Private Sub subPicHookTrayFormLoad()
On Error Resume Next
    t.cbSize = Len(t)
    t.hWnd = pichook.hWnd
    t.uId = 1&
    t.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
    t.uCallBackMessage = WM_MOUSEMOVE
    t.hIcon = Me.Icon
    t.szTip = "Shell_NotifyIcon ..." & Chr$(0)
    Shell_NotifyIcon NIM_ADD, t
    mdiMainMenu.Hide
    App.TaskVisible = False
End Sub
Private Sub MDIForm_QueryUnload(Cancel As Integer, UnloadMode As Integer)
On Error Resume Next
    gblbServerWillBeRightBack = True
    t.cbSize = Len(t)
    t.hWnd = pichook.hWnd
    t.uId = 1&
    Shell_NotifyIcon NIM_DELETE, t
End Sub
Private Sub Systray_Click(ai_button As Integer)
On Error Resume Next
    If ai_button = 2 Then PopupMenu mnuFile, 2
End Sub
Private Sub Systray_DblClick(ai_button As Integer)
On Error Resume Next
    If ai_button = 1 Then
        WindowState = 0: Show: AppActivate Caption, bWait
    End If
End Sub
Private Sub Systray_SingleClick(ai_button As Integer)
On Error Resume Next
    PopupMenu mnuFile, 2
End Sub
