Attribute VB_Name = "modProcessUserData"
Option Explicit
'LINKER ERROR??? - NO PROBLEM ! your SOLUTION YOU NEED TO JUST MOVE ALL YOUR CODE INTO YOUR OWN MODULE - ie modReport has lots of room left
'START HERE mudverse.com colours to follow pattern: subSendMsgInfoChannel "&W" & zMomentumPlayerName & " &wGUARDED [&g" & gblzQuestGuardAreaDesc(lPortID) & "&w] [&W+&Y" & lRewardTEMP1 & "&Wcofg&w] [&W+" & lRewardTEMP3 & "&wlps&w] [&W+&Y" & lRewardTEMP2 & "&ygold&w]"
'           make alot of use of ? zFormatGoldCofGLearnpts(12,"c")
'           for Player Level requirements use: zReturnPlayerLevelAscii((long)PlayerLevel)

Public Sub subProcessUserLine(zPortID As String, zUserData As String)
On Error GoTo Err_Check
    Const cstVersion = "-=coaSAFARI.CODE.2026=-"
    Dim zWord(5) As String 'We dont bother with handling more than 5 key words and one original prompt copy.
    Dim zPromptOriginal As String
    Dim zPromptMessage As String
    Dim lPortID As Long 'Port Controls
    Dim bInterrupt As Boolean 'knight has  interrupt for pvp paladins maybe too
    
    gblbIgnoreSpamWarning = False
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'we make sure the port is of a legal range
        'Handling Interrupt Curse
        bInterrupt = gblbInterruptPlayer(lPortID) 'happens right on their port
        If (bInterrupt) Then
            bInterrupt = (lRandom(lReturnClassInterruptSavingthrow(zPortID)) = 1)             'chance for attacker to fail -- we dont always force interrupt perfectly
            If (Not bInterrupt) Then 'YA saving throw won
                If (Not gblbFilterMode(lPortID)) Then subSendMsg "&G[Interrupt nearly got YOU]", zPortID
                gblbInterruptPlayer(lPortID) = False
                bInterrupt = False
            End If
        End If
        If (bInterrupt) Then 'they fail on their own sometimes
            If (lRandom(12 - lReturnClassInterruptSavingthrow(zPortID)) < 4) Then 'everyone has some kind of skin armor
                If (Not gblbFilterMode(lPortID)) Then subSendMsg "&G[Interrupt Evaded]", zPortID
                bInterrupt = False
            End If
        End If
        If (Not bInterrupt) Then 'Interrupt is a force command skill
            'zUserData = zRemoveSwears(zUserData)
            subParser zUserData, zPromptOriginal, zWord(1), zWord(2), zWord(3), zWord(4), zWord(5), zPortID 'Debug.Print "1]zwords//" & zWord(1) & " " & zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5) & vbCrLf & "po=" & zPromptOriginal & vbCrLf & "ud=" & zUserData
            If (Len(zPromptOriginal) > 0) Then
                If (zWatchzPromptOriginal(lPortID) <> zPromptOriginal) Then 'this is to keep people from spamming the same thing in channels
                    zWatchzPromptOriginal(lPortID) = zPromptOriginal
                Else
                    If (lCountOfChar(zPromptOriginal, " ") > 2) Then
                        gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1 + MyCLng(Len(zPromptOriginal) / 4)
                    End If
                End If
                
                'subSeeIfWePlantAGloryItem 1
                Select Case UCase(Mid(zWord(1), 1, 4))
                    Case "VENT"
                        subCyborgVentingSystem zPortID
                    Case "X", "SC", "SCOR", "LEVE" 'SCO-ld emote part is db reserved
                        subSystemScoreSheetPlayer zPortID
                    Case "N", "S", "E", "W", "NE", "NW", "SE", "SW", "U", "D"
                        subMessagesMovementResult (iMomentumEngineXYZ(zWord(1), False, gblbFilterMode(lPortID), gblbGraphicIDsOnOff(lPortID), zPortID)), zPortID
                    Case "STUN" 'this is a shoulder attack to lay a mob or player on the ground unable to play!
                        subCombatStun zPortID, MyCStr(zWord(2) & " " & zWord(3))
                    Case "STEA" 'steal
                        subThiefSteal zWord(2), zWord(3), zPortID
                        'subHarassANearbyRandomPlayer 1
                    Case "BATT"
                        subShowBattleStatus zPortID, zWord(2)
                    Case "BREA"
                        subBreakEntangle zPortID 'If (lEntanglementDuration = 0 Or (zClass = "GL" Or zClass = "WA" Or zClass = "PL" Or zClass = "KN")) Then
                    Case "CLEA", "LITT" 'LITTER CLEAN
                        subCleanTheDamagedArea zPortID
                    Case "BREA", "HIT", "K", "KIL", "KILL", "JAB", "ATTA", "STAB", "DEST", "SMAS" 'kill mobiles
                        subCombatAttack zPortID, MyCStr(zWord(2) & " " & zWord(3))
                    Case "PETS"
                        subShowPets zPortID
                    Case "DISA" 'and DISARM TRAPs
                        subCombatDisarm zPortID, MyCStr(zWord(2) & " " & zWord(3)) 'subCombatDisarm zWord(2), zPortID, lPlayerID, zPortID, lX, lY, lZ, lCLuc + lCDex + lPlayerLevel + lGrip, zPlayerName, lCSoul, zClass, lDisarmInterruption, lDetectInvisibilityDuration
                    Case "BS" 'some classes get backstab
                        subBackstab zPortID, MyCStr(zWord(2) & " " & zWord(3))
                    Case "I", "IN", "INV", "INVE"
                        subPlayerInventoryList zPortID, 0
                    Case "EQ", "EQU", "EQUI"
                        subPlayerEquipmentList zPortID, zWord(2), zWord(3), 0
                    Case "SCRY" 'dig and create a pentagram
                        subSCRY zPortID, zPromptOriginal, zWord(1), zWord(2)
                    Case "SHOW"
                        subShowtimePlayer zPortID, zWord(2), zWord(3)
                    Case "DRE", "THIN", "THOU", "DREA" 'just a player level test environment
                        subDreamscape zPortID
                    Case "ANGE"
                        subSpellAngerMobileVSMobile 1, zPortID, True
                    Case "LOCA"
                        subMobLocation zPortID, zWord(2), zWord(3), zWord(4)
                    Case "QUIT", "LOGO" 'logout
                        subQuitTheGame zPortID
                    Case "PLYR", "PCOD"
                        subSendPlayerList zPortID, zWord(2), zWord(3), zWord(4), zWord(5), zPromptOriginal
                    Case "MOBS", "MOBI", "MCOD"
                        subSendMobileList zPortID
                    Case "OBJE", "OCOD"
                        subSendObjectList zPortID
                    Case "DEFA"
                        Select Case UCase(CStr(zWord(2)))
                            Case "CM", "FM", "GUI"
                                gblbGraphicIDsOnOff(lPortID) = True
                                gblbFilterMode(lPortID) = False
                                gblbClientMode(lPortID) = True
                                subSendMsg "&GAdjusted only for GUI ON/FM OFF/CM ON", zPortID
                            Case Else
                                gblbGraphicIDsOnOff(lPortID) = False
                                subSendMsg "&GGraphical ID mode OFF", zPortID
                                gblbSensesMode(lPortID) = True
                                subSendMsg "&GSenses mode ON", zPortID
                                gblbFilterMode(lPortID) = False
                                subSendMsg "&GFilter mode OFF", zPortID
                                gblbScareMode(lPortID) = False
                                subSendMsg "&GScarey Hunted mode OFF", zPortID
                                gblbClientMode(lPortID) = True
                                subSendMsg "&GClient mode ON", zPortID
                        End Select
                    Case "CM"
                        Select Case UCase(CStr(zWord(2)))
                            Case "ON"
                                gblbClientMode(lPortID) = True
                            Case "OFF"
                                gblbClientMode(lPortID) = False
                            Case "ST", "STA", "STAT"
                            Case Else
                                gblbClientMode(lPortID) = Not gblbClientMode(lPortID)
                        End Select
                        Select Case gblbClientMode(lPortID)
                            Case True
                                subSendMsg "&GToggle: Client mode -is- now ON", zPortID
                            Case False
                                subSendMsg "&GToggle: Client mode -is- now OFF", zPortID
                        End Select
                    Case "CMON"
                        gblbClientMode(lPortID) = True
                        subSendMsg "&GClient mode ON", zPortID
                    Case "CMOF"
                        gblbClientMode(lPortID) = False
                        subSendMsg "&GClient mode OFF", zPortID
                    Case "CMS", "CMST" 'status
                        Select Case gblbClientMode(lPortID)
                            Case True
                                subSendMsg "&GClient mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GClient mode -is- OFF", zPortID
                        End Select
                    Case "GMON"
                        gblbGraphicIDsOnOff(lPortID) = True
                        subSendMsg "&GGraphical ID mode ON", zPortID
                    Case "GMOF"
                        gblbGraphicIDsOnOff(lPortID) = False
                        subSendMsg "&GGraphical ID mode OFF", zPortID
                    Case "GMS", "GMST" 'status
                        Select Case gblbGraphicIDsOnOff(lPortID)
                            Case True
                                subSendMsg "&GGraphical ID mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GGraphical ID mode -is- OFF", zPortID
                        End Select
                    Case "GM"
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbGraphicIDsOnOff(lPortID)
                                        Case True
                                            subSendMsg "&GGUId mode -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GGUId mode -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbGraphicIDsOnOff(lPortID) = True
                                Case Else
                                    gblbGraphicIDsOnOff(lPortID) = False
                            End Select
                        Else
                            gblbGraphicIDsOnOff(lPortID) = Not gblbGraphicIDsOnOff(lPortID)
                        End If
                        
                        If (gblbGraphicIDsOnOff(lPortID)) Then
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GGUId mode ON", zPortID
                        Else
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GGUId mode OFF", zPortID
                        End If
                    Case "SENS", "SMON"
                        If (bCheckSM(zPortID)) Then
                            gblbSensesMode(lPortID) = True
                            subSendMsg "&GSenses mode ON", zPortID
                        Else
                            gblbSensesMode(lPortID) = False
                            subSendMsg "&GYou cannot sense with your current race and class combination." & vbCrLf & "&GALLOWED:" & vbCrLf & "&YRace &gHUMAN HALFLING DWARF FELPUR &GOr &YClass &gRANGER ASSASSIN PALADIN CYBORG", zPortID
                        End If
                    Case "SENC", "SMOF"
                        If (bCheckSM(zPortID)) Then
                            gblbSensesMode(lPortID) = False
                            subSendMsg "&GSenses mode OFF", zPortID
                        Else
                            gblbSensesMode(lPortID) = False
                            subSendMsg "&GYou cannot sense with your current race and class combination." & vbCrLf & "&GALLOWED:" & vbCrLf & "&YRace &gHUMAN HALFLING DWARF FELPUR &GOr &YClass &gRANGER ASSASSIN PALADIN CYBORG", zPortID
                        End If
                    Case "SM"
                        If (bCheckSM(zPortID)) Then
                            If (Len(zWord(2) & zWord(3)) > 0) Then
                                Select Case Mid(UCase(zWord(2)), 1, 2)
                                    Case "ST"
                                        Select Case gblbSensesMode(lPortID)
                                            Case True
                                                subSendMsg "&GSenses -is- ON", zPortID
                                            Case Else
                                                subSendMsg "&GSenses -is- OFF", zPortID
                                        End Select
                                    Case "ON", "TR", "1", "T"
                                        gblbSensesMode(lPortID) = True
                                    Case Else
                                        gblbSensesMode(lPortID) = False
                                End Select
                            Else
                                gblbSensesMode(lPortID) = Not gblbSensesMode(lPortID)
                            End If
                            
                            If (gblbSensesMode(lPortID)) Then
                                If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GSenses ON", zPortID
                            Else
                                If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GSenses OFF", zPortID
                            End If
                        Else
                            gblbSensesMode(lPortID) = False
                            subSendMsg "&GYou cannot sense with your current race and class combination." & vbCrLf & "&GALLOWED:" & vbCrLf & "&YRace &gHUMAN HALFLING DWARF FELPUR &GOr &YClass &gRANGER ASSASSIN PALADIN CYBORG", zPortID
                        End If
                    Case "BMON", "FMON"
                        gblbFilterMode(lPortID) = True
                        subSendMsg "&GFilter mode ON", zPortID
                    Case "BMOF", "FMOF"
                        gblbFilterMode(lPortID) = False
                        subSendMsg "&GFilter mode OFF", zPortID
                    Case "FMS", "FMST", "BMS", "BMST" 'status
                        Select Case gblbFilterMode(lPortID)
                            Case True
                                subSendMsg "&GFilter mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GFilter mode -is- OFF", zPortID
                        End Select
                    Case "FM", "BM", "BLIN", "VI", "IMPA", "VISU"
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbFilterMode(lPortID)
                                        Case True
                                            subSendMsg "&GFilter -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GFilter -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbFilterMode(lPortID) = True
                                Case Else
                                    gblbFilterMode(lPortID) = False
                            End Select
                        Else
                            gblbFilterMode(lPortID) = Not gblbFilterMode(lPortID)
                        End If
                        
                        If (gblbFilterMode(lPortID)) Then
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GFilter ON", zPortID
                        Else
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GFilter OFF", zPortID
                        End If
                    Case "HMON"
                        gblbScareMode(lPortID) = True
                        subSendMsg "&GHunted mode ON", zPortID
                    Case "HMOF"
                        gblbScareMode(lPortID) = False
                        subSendMsg "&GHunted mode OFF", zPortID
                    Case "HMS", "HMST" 'status
                        Select Case gblbScareMode(lPortID)
                            Case True
                                subSendMsg "&GHunted mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GHunted mode -is- OFF", zPortID
                        End Select
                    Case "HM" 'works with subHarassANearbyRandomPlayer gblbHarassANearbyRandomPlayerMS
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbScareMode(lPortID)
                                        Case True
                                            subSendMsg "&GHunted mode -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GHunted mode -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbScareMode(lPortID) = True
                                Case Else
                                    gblbScareMode(lPortID) = False
                            End Select
                        Else
                            gblbScareMode(lPortID) = Not gblbScareMode(lPortID)
                        End If
                        
                        If (gblbScareMode(lPortID)) Then
                            gblbHarassANearbyRandomPlayerMS = True
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GHunted mode ON", zPortID
                        Else
                            gblbHarassANearbyRandomPlayerMS = bSetHarassANearbyRandomPlayerMS()
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GHunted mode OFF", zPortID
                        End If
                    Case "WH", "WHO"
                        subSystemReportWho zPortID
                    Case "HURT", "NUKE", "SUCI", "SUIC", "SLAM", "FIST", "DELE", "THUN" 'slam fists together // HOWEVER, NUKE is delete char forever!!! thunder fist of god
                        'Monk suicide doesnt give the nuke msg
                        subSuicide zPortID, zPromptOriginal, zWord(1), zWord(2)
                    Case "SABA", "SABO" 'Gypsy power skill - someone might spell it Sabatauge or something
                        subSabotage zPortID
                    Case "REPO"
                        subReportCharacterSheet zPortID
                    Case "NAME", "WHOA", "WHAT"
                        subReportCharacterSheetNAME zPortID
                    Case "BIG", "DD", "DDES", "ND", "DN", "NDES", "DAY", "NIGH", "BOTH" 'big screen for [night-day] doubled description
                        subPlayerDAYNIGHTDESCQuick zPortID
                    Case "QUIC", "DOOR"
                        subPlayerExitsQuicks zPortID
                    Case "WHOI", "FING", "FIN", "FI", "PROF" 'profile finger whois
                        subPlayerWhoIS zWord(2), zPromptOriginal, zPortID
                    Case "DIRE", "DIR", "DI"
                        subShowMyExits zPortID
                    Case "READ", "L", "LOOK", "INSP", "EX", "EXA", "EXAM", "LO", "LOO", "OK", "OOK" 'inspect examine look ... the spam system doesn't look for anything other than these two
                        subLookAreaDesc zPortID, zPromptOriginal, zWord(2), zWord(3), zWord(4), gblbFilterMode(lPortID), gblbGraphicIDsOnOff(lPortID)
                    Case "MBC"
                        subPlayerMessageBoardCreate zPortID, zPromptOriginal
                    Case "MBD"
                        subPlayerMessageBoardDelete zPortID, MyCLng(zWord(2))
                    Case "MBV", "MBR" 'message board view or read
                        subPlayerMessageBoardView zPortID, zWord(2)
                    Case "RETU" 'return clan flags
                        basCaptureTheFlag zPortID
                        subSendMsg "&GDone, any flags you were holding were returned.", zPortID
                    Case "BRID", "SIGN", "CROS", "LOWE" 'cross the bridge, lower the bridge
                        subBridgeRaiseLower zPortID
                    Case "MAGI", "MAJI", "UNDO" 'similar to bash in the door
                        subMagicInTheDoor zWord(2), zPortID 'Word(2) is the direction
                    Case "BUST", "BASH", "SPLI" 'similar to Bash in the Majic Door
                        subBashInTheDoor zWord(2), zPortID 'Word(2) is the direction
                    Case "AZUL"
                        gblbIgnoreSpamWarning = True
                        subGraphicalRequestCode zPortID
                    Case "MARK"
                        subPlayerMark zPortID
                    Case "RECA"
                        subPlayerRecall zPortID
                    Case "POT"
                        subPotArea zWord(2), zWord(3), zPortID
                    Case "RND", "RNDR", "RAND", "DICE"
                        subRandomRoll zWord(2), zPortID
                    Case "DRAW", "DECK", "DEAL"
                        subDrawPlayerCards zWord(2), zWord(3), zPortID
                    Case "HP", "HPET" 'heal pets
                        subSpellListHealPets zPortID, False 'this is a skill to some classes and is just soul cost
                    Case "DEAD", "RD"
                        subSpellListRaiseArea zPortID, False 'this is a skill to some classes and is just soul cost
                    Case "CHAI"
                        subSpellListChainAreas zPortID, False 'this is a skill to some classes and is just soul cost
                    Case "FORC"
                        subUseForce zPortID, zWord(2)
                    Case "WEA", "WEAR", "WAE", "WIE", "WIEL", "HOLD", "ARM", "DUAL", "WERA", "WAER", "WEAL"
                        subWearObject zPortID, zWord(2)
                    Case "REM", "REMO", "UNEQ", "UNWE" 'unequipt/unwear an item
                        subRemoveObject zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                    Case "DRO", "DROP"
                        subDropObject zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                    Case "GE", "GET", "TA", "TAK", "TAKE" 'this one looks messy but its self-contained in the new method
                        If (Len(zWord(2)) <> 0) Then
                            If (Len(zWord(3)) <> 0 Or Len(zWord(4)) <> 0) Then
                                subGetObjectContainer zPortID, zWord(2), MyCStr(zWord(3) & " " & zWord(4))
                            Else
                                subGetObjectGround zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                            End If
                        Else
                            subSendMsg "&GGet what?", zPortID
                        End If
                    Case "PUT"
                        subPutObjectContainer zPortID, zWord(2), zWord(3)
                    Case "EAT"
                        subPlayerEatInventoryItem zWord(2), zPortID
                    Case "FAVO" 'favour your immortal and vote for your immortal!
                        subPlayerFavour zWord(2), zPortID
                    Case "DRIN", "SIP"
                        subPlayerDrink zPortID, zWord(2)
                    Case "RECI"
                        subReciteObject zPortID, zWord(2), zWord(3)
                    Case "FISH"
                        subFishAreaForObjectsSetUp zPortID
                    Case "QUAF"
                        subQuaffObject zPortID, zWord(2)
                    Case "EXCH" 'must be on a starship
                        subPlayerExchangeBoard zPortID, zWord(2), zWord(3), zWord(4), zWord(5)
                    Case "GOLF" 'GOLF OBJECT HOLENUMBER
                        subGolfGame zPortID, zWord(2), zWord(3)
                    Case "LON"
                        gblbLineFeed(MyCLng(zPortID)) = True
                    Case "LOFF"
                        gblbLineFeed(MyCLng(zPortID)) = False
                    Case "CLRS", "CLR", "CLS", "CLSR" 'clear the screen
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "CLS1" 'scroll the screen up
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf, zPortID
                        DoEvents
                    Case "CLS2" 'scroll the screen up
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "CLSS", "CLS3" 'clear the screen - 3lines small
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "CLSM", "CLS4" 'clear the screen - 3lines small
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf & vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "STAR" 'stargate
                        subActivateStargate zPortID, zWord(2)
                    Case "PHAS"
                        subPhaserPistol zPortID, zWord(2)
                    Case "HELP", "BRIE" 'help or brief
                        subHelpSystem zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                    Case "GAMB", "PLAY"
                        subGamble zWord(2), zWord(3), zPortID
                    Case "PAGE", "PGAE", "PAEG" 'Pages of reports
                        subPlayerReports zPortID, zWord(2)
                    Case "EYEB"
                        subEyeBeamToggle zPortID
                    Case "HINT" 'this one looks messey but its the new method
                        gblbHint(lPortID) = Not gblbHint(lPortID)
                        If (gblbHint(lPortID)) Then
                            subSendMsg "&gHints are now on.", zPortID
                        Else
                            subSendMsg "&gHints are now off.", zPortID
                        End If
                        subSendMsg "&gCommands to interact with ground items are:" & vbCrLf & "'ENTER', 'EXIT', 'CLIMB', 'FIX', 'MOVE', 'PRESS', 'PULL', 'PUSH', 'SEARCH', 'SLIDE', 'SPREAD', 'SWING', 'SHOVE', 'SPIN', 'SPEAK', 'TOUCH', 'TAP', 'TUG', 'TURN', 'TWIS'" & vbCrLf & "Note: USE LEVER (objectname) might also be your solution!", zPortID
                    Case "ENTE", "EXIT", "SLID", "CLIM", "MOVE", "PRES", "PULL", "PUSH", "SEAR", "SHOV", "SPRE", "SWIN", "SPIN", "SPEA", "TOUC", "TAP", "TUG", "TURN", "TWIS", "FIX"
                        subAreaConstruct zPortID, zWord(1), zPromptOriginal 'subAreaConstruct zPortID, zPlayerName, lPlayerID, lX, lY, lZ, zClass, zWord(1), zPromptOriginal, lPlayerLevel, lStatus, lEntanglementDuration
                    Case "CHAN"
                        subChannelControl zPortID, zWord(2)
                    Case "STEP" 'so we can step on eachother when a frog or mouse
                        subPlayerStepPlayer zWord(2), zPortID
                    Case "AUTO", "+AUT" 'this one looks like its old-style but its NOT - but it could still be in a PROC
                        If ((lPortID >= cstlMinPort And lPortID <= cstlMaxPort)) Then
                            Select Case UCase(Mid(zWord(2), 1, 2))
                                Case "ON", "+"
                                    gblbAutoloot(lPortID) = True
                                Case "OF", "-"
                                    gblbAutoloot(lPortID) = False
                                Case Else
                                    gblbAutoloot(lPortID) = (Not gblbAutoloot(lPortID))
                            End Select
                            Select Case (gblbAutoloot(lPortID))
                                Case True
                                    subSendMsg "&GAutoloot - on", zPortID
                                Case False
                                    subSendMsg "&gAutoloot - off", zPortID
                            End Select
                        End If
                    Case "VERS", "VER", "ABOU", "WRIT"
                        subSendMsg "&G~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", zPortID
                        subSendMsg "&G                             ~C I T Y  of  A G E S~", zPortID
                        subSendMsg "&g                        Coded by: " & zDecrypt("CbqsdoO-!Kpqz)Ss`fq*"), zPortID
                        subSendMsg "&g               Copyright " & zDecrypt("CbqsdoO-!Kpqz)Ss`fq*") & ", " & cstVersion, zPortID
                        subSendMsg "&G~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", zPortID
                        'with port counting max
                    Case "ENSN", "ENTR", "NET" 'ensnare - must be holding a net item
                        subEnsnare zPortID, zWord(2)
                    Case "EMPT", "NEED", "DIAG" 'Diagnose missing and needed or empty. What is empty for equipment locations - stuff we need
                        subMissingEq zPortID
                    Case "STOC"
                        subPlayerStockMarket zWord(2), zWord(3), zWord(4), zWord(5), zPortID
                    'Case "BEAU", "BS" 'beauty - painting
                    '    subPlayerBeauty zPortID, zWord(2), zWord(3)
                    Case "TRAN", "CRAF" 'transmute
                        subQuestTransmute zPortID
                    Case "HORS"
                        subHorseBet zPortID, zWord(2), zWord(3)
                    Case "ROUL"
                        subRouletteScreen zPortID, UCase(zWord(2)), UCase(zWord(3)), UCase(zWord(4))
                    Case "COM", "COMP" 'Compare two items in inventory
                        If (Len(zWord(4)) > 0 And Len(zWord(5)) > 0) Then
                            subCompare MyCStr(zWord(2) & zWord(3)), MyCStr(zWord(4) & zWord(5)), zPortID
                        Else
                            subCompare zWord(2), MyCStr(zWord(3) & zWord(4)), zPortID
                        End If
                    Case "WIZL", "WIZ", "WLIS", "IMMS"
                        subWizList zPortID
                    Case "SAVE" 'yep this does nothing cuz we use a SQL database - try to use a SDD drive whoowhoo!!
                        subSendMsg "&gDone, your game is now saved." & vbCrLf & "Note, the system auto-saves for you when you play in the realm.", zPortID
                    Case "MEDI"
                        subForgeMobTag zWord(2), zPortID
                    Case "GOTO"
                        subImmortalGotoMeditMob zPortID
                    Case "SS"
                        subFleetCommand zWord(2), zWord(3), zWord(4), zWord(5), zPortID
                    Case "OFOR", "FORG", "OEDI" 'obj edit/forge
                        subForge zWord(2), zWord(3), zPromptOriginal, zPortID
                    Case "HOUS", "HOME" 'Players with a house can use this to get back home fast.
                        subPlayerGotoHouse zPortID
                    Case "TELE" 'Room teleport
                        subImmortalTeleport zPortID, zWord(2), zWord(3), zWord(4)
'                        Case "SUPE" 'Report: Immortal Supervisor this requires no immortal level
'                            subImmortalSupervisorReport zPortID, zWord(2), zWord(3), iImmortalSupervisor, zClass, lImmortalLevel, lClanMemberLevel, lPlayerID
                    Case "ATMO"
                        If (gbllAtmosphereStaticCharges > cstAtmozDefault) Then gbllAtmosphereStaticCharges = cstAtmozDefault
                        subSendMsg "&WATMOZ " & gbllAtmosphereStaticCharges & " pps", zPortID
                    Case "SCAN"
                        subCombatScan zPortID, zWord(2), zWord(3)
                    Case "MAPS", "MAP" 'Shows the matrix you are in
                        subShow11x11Map zPortID
                    Case "PAM", "GUAR"
                        subGuardDetails zPortID
                    Case "PEST", "SICK", "SNEE", "PAND", "PLAG"
                        subShowPestilance zPortID
                    Case "SAY", "SAYS", "'" 'SAY/EXCLAIM/ASK CHANNEL
                        subSpeakSayAskExclaim zPortID, zRemoveInvalidChatChars(zPromptOriginal)
                    Case "WHER"
                        subPlayerWhereAreas zPortID
                    Case "OOC", "OCC"
                        If (gbliOOCChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "ooc", zPromptOriginal, gblzFNBLA
                        Else
                            subSendMsg "&rOut-of-Character Channel: You have this channel turned off.", zPortID
                        End If
                    Case "RUMO", "RHUM", "RHOM", "RUME"
                        If (gbliRumoChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "rumor", zPromptOriginal, gblzFNCYA
                        Else
                            subSendMsg "&rRUMOR: Your realm channel is turned off.", zPortID
                        End If
                    Case "GLOB", "R", "RA", "RAM", "RAMB"
                        If (gbliRambChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "ramble", zPromptOriginal, gblzFBBLU
                        Else
                            subSendMsg "&rRAMBLE: Your channel is turned off.", zPortID
                        End If
                    Case "GO", "GOS", "GOSS", "IC"
                        If (gbliGossipChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "ic", zPromptOriginal, gblzFBMAG
                        Else
                            subSendMsg "&rGOSSIP-In-Character Chatting: Your channel is turned off.", zPortID
                        End If
                    Case "NOOB", "NOO", "NEW", "NEWB"
                        If (gbliNewbieChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "noobie", zPromptOriginal, gblzFBGRE
                        Else
                            subSendMsg "&rNEWBIE CHANNEL: You have this channel turned off.", zPortID
                        End If
                    Case "YELL", "COMM", "SHOU" 'CHANNEL YELL/SHOUT
                        subChannelYell zPortID, zPromptOriginal, zWord(2)
                    Case "INTE", "IMC", "CHAT" 'Intermud chat
                        If (gbliIMCChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "imc", zPromptOriginal, gblzFNWHI
                        Else
                            subSendMsg "&rQUOTE: Your channel is turned off.", zPortID
                        End If
                    Case "QUO", "QUOT" 'QUOTE
                        If (gbliQuotChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "quote", zPromptOriginal, gblzFBCYA
                        Else
                            subSendMsg "&rQUOTE: Your channel is turned off.", zPortID
                        End If
                    Case "QUE", "QUES" 'QUEST CHANNEL
                        If (gbliQuotChannelStatus(lPortID)) Then
                            subQuestSystemAndChannel zWord(2), zWord(3), zPromptOriginal, zPortID
                        Else
                            subSendMsg "&rQUEST: Your channel is turned off.", zPortID
                        End If
                    Case "MUS", "MUSI" 'MUSIC CHANNEL
                        If (gbliMusiChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "music", zPromptOriginal, gblzFBBLU
                        Else
                            subSendMsg "&rMUSIC: Your channel is turned off.", zPortID
                        End If
                    Case "LEAD" 'leaders and entities and immortals only
                        subLeaderOnlyChannel zPortID, zPromptOriginal
                    Case "GOC", "GOD", "GODS", "ENTI" 'GOD ONLY CHANNEL
                        subImmortalOnlyChannel zPortID, zPromptOriginal
                    Case "GOP", "GODP", "CLOU", "HAIL", "HEAV"
                        subImmortalCloudChannel zPortID, zPromptOriginal
                    Case "EM", "SOCI", "POSE", "EMO", "EMOT" 'EMOTE CHANNEL
                        subEmoteSpeak zPortID, zRemoveInvalidChatChars(zPromptOriginal)
                    Case "REPL", "REP", "RE"
                        If (gbliTellChannelStatus(lPortID)) Then
                            gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1
                            If (gbllSpeakControl(lPortID) < 150 + gbllSpeakControlMax) Then
                                zPromptOriginal = "tell " & gblzTelnetReplyCommand(lPortID) & " " & Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1)
                                
                                If ((lPortID >= cstlMinPort And lPortID <= cstlMaxPort) And (Len(zWord(2)) <> 0)) Then
                                    zWord(2) = gblzTelnetReplyCommand(lPortID)
                                    subTellChannel zPortID, zWord(2), zPromptOriginal
                                Else
                                    subSendMsg "&RREPLY (Message)" & vbCrLf & "&gYou need to tell to the person once if you wish to use this command.", zPortID
                                End If
                            Else
                                subTryUsingTheMICCommand 2, zPortID
                            End If
                        Else
                            subSendMsg "&RYour tell channel is currently set to off.", zPortID
                        End If
                    Case "TELL", "TEL", "T", "TLL", "TE" 'TELL CHANNEL
                        If (gbliTellChannelStatus(lPortID)) Then
                            gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1
                            If (gbllSpeakControl(lPortID) < 90 + gbllSpeakControlMax) Then
                                subTellChannel zPortID, zWord(2), zPromptOriginal
                                If (Len(zWord(2)) <> 0) Then gblzTelnetReplyCommand(MyCInt(zPortID)) = zWord(2)
                            Else
                                subTryUsingTheMICCommand 2, zPortID
                            End If
                        Else
                            subSendMsg "&RYour tell channel is currently set to off.", zPortID
                        End If
                    Case "CLAN"
                        If (Len(zWord(2)) <> 0) Then
                            If (zWord(2) = "LEAVE" And zWord(3) = "THIS" And zWord(4) = "GUILD") Then
                                subLeaveMyGuild zPortID
                            Else
                                If (Len(zWord(3)) = 0) Then 'we want people to be able to start words with: CLAN name is Traer of the Gh'oul - without it just running the CLAN NAME report
                                    Select Case zWord(2)
                                        Case "FLA", "FLAS", "FLGA", "FLGAS", "FLAG", "FLAGS", "FAGS" 'yeas FAGS gets typed by accident and its stoopid to see lol
                                            subIndicatePlayerWhereWithFlags zPortID
                                        Case "LIST", "NAME", "NAMES"
                                            subSystemReportClanNameList zPortID
                                        Case "EXPIRE", "EXPIRES" 'expires (DateDiff('d',[LastPlayed],Date()))>" & cstlRankLost & ")
                                            subSystemReportClanExpireLevel zPortID, "E"
                                        Case "RANK", "RANKS"
                                            subSystemReportClanRankLevel zPortID, "R"
                                        Case "LEVEL", "LEVELS"
                                            subSystemReportClanRankLevel zPortID, "L"
                                        Case Else
                                            If (gbliClanChannelStatus(lPortID)) Then
                                                subClanSpeak zPortID, zPromptOriginal
                                            Else
                                                subSendMsg "&rCLAN: Your channel is turned off.", zPortID
                                            End If
                                    End Select
                                Else
                                    If (gbliClanChannelStatus(lPortID)) Then
                                        subClanSpeak zPortID, zPromptOriginal
                                    Else
                                        subSendMsg "&rCLAN: Your channel is turned off.", zPortID
                                    End If
                                End If
                            End If
                        Else
                            subSendMsg "&gtype HELP CLAN" & vbCrLf & "Type CLAN LEAVE THIS GUILD to leave your clan." & vbCrLf & "See Also: HELP INDUCT", zPortID
                        End If
                    Case "MIC", "FRIE" 'speak through the speakerphone
                        If (Len(zWord(2)) <> 0) Then
                            'This sends the message over Speaker phone
                            subSpeakerPhoneMic zPortID, zPromptOriginal
                        Else
                            'List all the people on your Mic list.
                            subSpeakerPhoneMicList zPortID
                        End If
                    Case "BOOK", "ADD"
                        If (Len(zWord(2)) > 0) Then
                            subSpeakerPhoneBookAdd zPortID, zWord(2)
                        Else
                            subSendMsg "&gSyntax: BOOK (add player name to your clan black book)", zPortID
                        End If
                    Case "ERAS"
                        subSpeakerPhoneBookDelete zPortID, zWord(2)
                    Case "MUTE", "HANG" 'hang up on/mute a member
                        subSpeakerPhoneBookMute zPortID, zWord(2), -1
                    Case "UNMU"  'listen to/unmute member
                        subSpeakerPhoneBookMute zPortID, zWord(2), 0
                    Case "PRAY" 'Only gods hear this channel - anyone can use it.
                        subImmortalPrayChannel zPortID, zPromptOriginal
                    Case "CHR"
                        subImmortalRaceOnlyChannel zPortID, zPromptOriginal
                    Case "CHC"
                           subImmortalClassOnlyChannel zPortID, zPromptOriginal
                    Case "HOC", "HERO"
                        subImmortalHeroOnlyChannel zPortID, zPromptOriginal
                    Case "LOC", "LORD"
                        subImmortalLordOnlyChannel zPortID, zPromptOriginal
                    Case "ETE", "ETER"
                        subImmortalEternalOnlyChannel zPortID, zPromptOriginal
                    Case "GTC", "ITC", "ITG"  'IMM Global TEASE CHANNEL
                        subImmortalEchoChannel zPortID, zPromptOriginal
                    Case "GTR", "ITR"  'IMM Room TEASE CHANNEL
                        subImmortalTeaseRoomChannelAll zPortID, zPromptOriginal
                    Case "Q", "EXIT", "BYE"
                        subSendMsg "&RTo quit you must type QUIT.", zPortID
                    Case "AFK"
                        subSetAFKMode zPortID
                    Case "FLE", "FLEE" 'Flee from combat
                        subCombatPlayerFlee zPortID
                    Case "FACT"
                        subShowFactionColonistsInArea zPortID
                        subFactionList zPortID, zWord(2), zWord(3)
                    Case "LITE", "LIGH", "IGNI" 'ignite/light torch, light lamp, for example
                        subLightObject zPortID, zWord(2)
                    Case "TIME", "DATE", "CALA"
                        bWhenIsIt zPortID, True
                    Case "PEEK", "PEER"
                        If (Len(zWord(2)) > 0) Then
                            subLookPeek zPortID, zWord(2), False
                        Else
                            subSendMsg "&gSYNTAX: PEEK [direction].", zPortID
                        End If
                    Case "SPEL"
                        subPlayerAffects zPortID, "SPELLS"
                    Case "SKIL"
                        subPlayerAffects zPortID, "SKILLS"
                    Case "AFF", "AFFE"
                        subPlayerAffects zPortID, "BOTH"
                    Case "SHOP", "LIST", "LST", "WARE", "SHOW", "MERC"
                        subMerchantInAreaWares zPortID
                    Case "SELL"
                        subMarketSell MyCStr(zWord(2) & " " & zWord(3)), zPortID
                    Case "BUY"
                        subMerchantInAreaPurchase zPortID, zWord(2)
                    Case "ARMA", "ARME"
                        subArmageddonReport zPortID
                    Case "SACR", "SAC", "TRAS", "JUNK", "DELE" 'SACROOM SACRIFICE SACAREA
                        subSacrificeObjects zPortID, zWord(2)
                    Case "JUMP", "POLE", "VAUL", "VALT"
                        subSkillJump zPortID, zWord(2), zWord(3)
                    Case "STOM"
                        subWarriorStomp zPortID
                    Case "HA", "HITA"
                        subHitAllInArea zPortID
                    Case "KE", "KEN", "KENE", "B", "BOL", "BOLT", "ARCA", "ARC" 'ARCANE BOLT for MAGE
                        subCombatARCANEBOLT zPortID, zWord(1), zWord(2), zWord(3) 'quick fire mode too
                    Case "MISS", "FIRE"
                        Select Case Mid(zWord(2), 1, 4)
                            Case "TARG" 'Target for missile weapon, bow, crossbow, or sling
                                subCombatMissileTarget zPortID, MyCStr(zWord(3) & " " & zWord(4)), True, False
                            Case "FIRE" 'fire bow, crossbow, sling to the direction, Arrows, Bolts, Stones must be in inventory
                                subCombatMissileWeapons zPortID
                            Case Else
                                subSendMsg "&gMISSILE TARGET (target name) - will spy your target you must be within range" & vbCrLf & "MISSILE FIRE                 - will fire your weapon at the target", zPortID
                        End Select
                    Case "SNEA" 'sneak
                        subSneak zPortID
                    Case "LOAD"
                        subPlayerLoad zPortID, zWord(2)
                    Case "VET", "HEAL", "VETE"
                        subPlayerVet zPortID, zWord(2)
                    Case "A", "ACT", "ACTI"  'Activate Learn Skill - some of them require it.
                        subActivateLearnSkill zPromptOriginal, zPortID
                    Case "PRAC", "PRA", "PR", "P"
                        If (gblbClientMode(lPortID)) Then
                            subPlayerSkillsLearnTree zPortID, "", "", "<::=-PRACTICED TREE-=::>", True, False, True
                        Else
                            subPlayerSkillsLearnTree zPortID, "", "", "PRACTICED TREE", True, False, True
                        End If
                    Case "C", "CAS", "CAST"
                        subCastGroupOfProcedures zPortID, zWord(2), zWord(3), zWord(4), zWord(5), zPromptOriginal
                    Case "SHEE", "CHAR" 'or CHARACTER SHEET or LEARN TREE short cut command
                        subPlayerSkillsLearnTree zPortID, "", "", "<::=-LEARN TREE-=::>", False, False, True
                    Case "CLAS", "LEAR", "TEAC" 'class room get it lol and Learn Points get traded for a better skill in a weapon type or something unique.
                        If (gblbClientMode(lPortID)) Then
                        Select Case Mid(zWord(2), 1, 4)
                            Case "TREE"
                                subPlayerSkillsLearnTree zPortID, "", "", "<::=-LEARN TREE-=::>", False, False, True
                            Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "FELP", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                                subPlayerSkillsLearnTree zPortID, Mid(zWord(2), 1, 2), Mid(zWord(3), 1, 3), "<::=-LEARN TREE-=::> (peaked)", False, False, False
                            Case Else
                                subPlayerSkillsLearn zPortID, UCase(MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5) & " "))
                        End Select
                        Else
                        Select Case Mid(zWord(2), 1, 4)
                            Case "TREE"
                                subPlayerSkillsLearnTree zPortID, "", "", "LEARN TREE", False, False, True
                            Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "FELP", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                                subPlayerSkillsLearnTree zPortID, Mid(zWord(2), 1, 2), Mid(zWord(3), 1, 3), "LEARN TREE (peaked)", False, False, False
                            Case Else
                                subPlayerSkillsLearn zPortID, UCase(MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5) & " "))
                        End Select
                        End If
                    Case "ABSO" 'absorbs same item object, see also merge
                        subGambleAbsorbsLocationObject zPortID
                    Case "JOYS"
                        subAracadeSetup zWord(2), zPortID
                    Case "SLIS"
                        subSLISTSelector Mid(zWord(2), 1, 4), Mid(zWord(3), 1, 4), zPortID
                    Case "AREA"
                        subAreaArchitectureWhereListLoad zPromptOriginal, zPortID
                    Case "TALK", "ASK", "SAYT"
                        subMobQuestSystemLoad zWord(2), zWord(3), zPortID
                    Case "BID" 'auction bid
                        subAuctionBidLoad zWord(2), zPortID
                    Case "AUCT" 'this is a global auction
                        subAuctionLoad zWord(2), zWord(3), zPortID
                    Case "USE", "UNLO"
                        subUseUnlock zWord(2), zWord(3), zWord(4), zPortID
                    Case "AID", "UNST" 'unstun
                        subCombatAid zWord(2), zPortID
                    Case "GI", "GIV", "GIVE"
                        subPlayerGive zWord(2), zWord(3), zWord(4), zPortID
                    Case "OPEN", "CLOS"
                        subDoorOpenClose zWord(1), zWord(2), zPortID
                    Case "TRAI" 'Train mob TRAIN (mobname one word use) DISBAND
                        subTrainAnimal zWord(2), zWord(3), zPortID
                    Case "DISM", "UNMO", "MOUN", "RIDE"
                        subTrainAnimalControl zWord(1), zWord(2), zPortID
                    Case "DONA" 'donate an item to the weapon type
                        subDonateObjectLoad zWord(2), zPortID
                    Case "DISB"
                        subGroupRemoveMemberLoad zWord(2), zPortID
                    Case "FO", "FOL", "FOLL", "STOP"
                        subFollowPlayerLoad zWord(2), zPortID
                    Case "GR", "GRO", "GROU", "FORM"
                        subGroupFollowingPlayerLoad zWord(2), zPortID
                    Case "BOTH", "MOST", "ALL", "DOLL", "COIN", "GOLD", "LIFE", "RPG", "HEIG", "WEIG", "KGS", "LBS", "NA", "NAR", "NOA", "SLAY", "HR", "DR", "AC", "MF", "BMF", "RECO", "COOR", "STAT", "RACE", "ALI", "ALIG", "LG", "LAZY", "TAG", "TAGS", "TNL", "DND", "GLOR", "CFOG", "COFG", "CROW", "LP", "LPS", "LVL", "LV", "XX", "XXX", "XXXX", "YY", "YYY", "YYYY", "ZZ", "ZZZ", "ZZZZ", "XP", "HHH", "HPS", "HPZ", "HPTS", "PTS", "HITP", "ES", "ESS", "ESSE", "MAN", "MANA", "SOU", "SOUL", "MV", "MOV"
                        subSelfStats UCase(Mid(zWord(1), 1, 4)), zPortID
                    Case "XYZ"
                        subXYZ zPortID
                    Case "REPA"
                        subRepairDurabilityLoad zWord(2), zPortID
                    Case "MURD" 'murder player
                        subPlayerVsPlayerCombatSetUpLoad zWord(2), zPortID
                    Case "ST", "STA", "STAN"
                        subPlayerPositionLoad 5, zWord(1), zWord(2), zPortID
                    Case "RELA"
                        subPlayerPositionLoad 10, zWord(1), zWord(2), zPortID
                    Case "REST"
                        subPlayerPositionLoad 15, zWord(1), zWord(2), zPortID
                    Case "SIT"
                       subPlayerPositionSitObjectLoad zWord(1), zWord(2), zPortID
                    Case "SL", "SLE", "SLEE", "NAP", "BED"
                       subPlayerPositionSleep zPortID
                    Case "WA", "WAK", "WAKE"
                       subWAKELoad zWord(2), zPortID
                    Case "BANK", "BNK"
                       subBankingLoad zWord(2), zWord(3), zPortID
                    Case "DIG", "FIND", "UNBU" 'unbury and dig
                        subDigFindLoad zPortID
                    Case "BURY" 'bury object
                        subBuryLoad zWord(2), zPortID
                    Case "RELO", "POWE"
                        subSkillReloadRemoveWearLoad zPortID
                    Case "KEEP", "UNKE", "UNMA" 'unmark or unkeep
                        subKeepUnkeep zWord(1), zWord(2), zPortID
                    Case "DECL", "MORT", "DENY"
                        subDeclineImmortalStatus zPortID
                    Case "PEMO", "PETE" 'pet emote
                        subChartEmotePetLoad zPromptOriginal, zWord(2), zWord(3), zWord(4), zPortID
                     Case "COLO"
                         subColourPallets lReturnPlayerIDPort(zPortID), zWord(2), MyCLng(zWord(3)), zPortID
                     Case "CONF" 'config type +/-
                         subPlayerConfig zWord(2), zWord(3), lReturnPlayerIDPort(zPortID), zPortID
                    Case "PASS" 'change password
                        subChangePassword zPortID, lReturnPlayerIDPort(zPortID), MyCStr(zWord(2))
                    Case "IGNO" 'ignore player - this will also unflag ignore
                        If (UCase(zWord(2)) = "LIST" Or UCase(zWord(2)) = "BOOK") Then
                            subPlayerIgnoredCommandList zPortID
                        Else
                            subPlayerIgnoredCommand lReturnPlayerIDPort(zPortID), zWord(2), zPortID
                        End If
                    Case "GUES", "SCRA"
                        subGuessTheWordGameLoad zWord(2), zPortID
                    Case "MERG" 'merging cards, see also: absorb
                        subGambleMergeCardsLoad zWord(2), zWord(3), zPortID
                    Case "CANC"
                        subCancelQuest lReturnPlayerIDPort(zPortID), zPortID
                    Case "COST", "DAMA", "DMG", "DAMG", "DMAG", "DMGA"
                        subCostDamageReport zWord(1), zWord(2), zWord(3), zPortID
                    Case "BOUN"
                        subQuestBountyLoad zPortID
                    Case "VOTE", "POLL"
                        subVOTELoad zPromptOriginal, zWord(2), zPortID
                    Case "IMMO"
                        subImmortalCommandLoad zPromptOriginal, zWord(2), zWord(3), zWord(4), zWord(5), zPortID
                    Case "CON", "CONS"
                        subConsiderTargetLoad zWord(2), zPortID
                    Case "PDES", "DESC"
                        subPlayerDescLoad zPromptOriginal, "D", zPortID
                    Case "PTIT", "TITL"
                        subPlayerDescLoad zPromptOriginal, "T", zPortID
                    Case "INDU"
                        subInductionSetClanMemberLevelLoad zWord(2), zWord(3), zPortID
                    Case "DISP"
                        subImmortalWHODisplayed zPortID
                    Case "GT", "GRPT", "GTAL", ";"
                        subGroupTalkLoad zPromptMessage, zPromptOriginal, zWord(2), zWord(3), zPortID
                    Case "IDM", "MID" 'identify Mob, Mob Identify
                        subIdentifyMobLoad zPortID
                    Case "MFOR", "EDIT" 'mob forge - mob edit - edit 10 bonusac - medit or tag
                        subForgeMobLoad zPromptOriginal, zWord(2), zWord(3), zPortID
                        

                    'Case "BITE", "MORP" 'I disabled this
                    '    If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                    '        subMorph zPlayerName, lPlayerID, lPlayerLevel, zWord(2), zClass, lX, lY, lZ, zPortID
                    '    Else
                    '        subSendMsg "&rYou can't morph players while in combat.", zPortID
                    '    End If
                    'Case "TRAC", "PATH" 'Track
                    '     If (lPlayerLevel >= 30) Then 'Level to use
                    '         zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                    '         If (Len(zPromptMessage) <> 0) Then
                    '             subMobArchitecturePath zPortID, zPlayerName, lX, lY, lZ, lImmortalLevel, zPromptMessage, "ALL"
                    '             If (lImmortalLevel >= 10) Then 'Level to use
                    '                 subAreaArchitectureTransit zPortID, lX, lY, lZ, "ALL"
                    '             End If
                    '         Else
                    '             subSendMsg "&GCOMMAND: TRACK (full mobile name)", zPortID
                    '         End If
                    '     Else
                    '         subSendMsg "&CPL30: You can track at level 30.", zPortID
                    '     End If
                    Case Else 'No commands matched? We now check the emote system
                        If (Not bChartEmote(zWord(1), zWord(2), zPortID, "", "", "")) Then
                            If (Len(zPromptOriginal) > 0) Then subSendMsg "&g" & MyCStr(Mid(zPromptOriginal, 1, 10) & " huh?"), zPortID
                        End If
                End Select
                'Check AFK and VOID status
                If (gbliPortStatus(MyCLng(zPortID)) <> 0) And (zWord(1) <> "AFK") Then subSetAFKMode zPortID
            Else
                subSendMsg "&gEhh?", zPortID
            End If
        Else
            gblbInterruptPlayer(lPortID) = False
            Select Case lRandom(3)
                Case 1
                    subSendMsg "&ROops! You were interrupted!", zPortID
                Case 2
                    subSendMsg "&ROops! Some sneaky person interrupted you!", zPortID
                Case 3
                    subSendMsg "&ROops! Something interrupted that command!", zPortID
            End Select
        End If
        gblzTelnetRepeatCommand(lPortID) = zPromptOriginal
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subProcessUserLine," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
