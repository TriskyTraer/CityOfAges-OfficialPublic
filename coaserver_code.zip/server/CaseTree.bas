Attribute VB_Name = "modCaseTree"
Option Explicit
Public Sub subLoginUserPort(zPortID As String, zOUserData As String, zRemoteHostIP As String, frmPort As Form)
'See Also: gblzLocalHost
'CONNECTION PLAYER START: As soon as the port reads data this procedure executes!
'Check point and Start point! GO! GO! GO!
'We have ban checks: COMPLETE BAN OF THE IP
'                    Banned IP until the player deletes - we can also use immo never ban
On Error GoTo Err_Check 'XOn-error
    Const cstzACCEPT = "Accept: image/gif, image/x-xbitmap, image/jpeg, image/pjpeg, application/x-shockwave-flash, application/vnd.ms-excel, application/msword, application/vnd.ms-powerpoint, */*"
    Const cstlMaxPlayersFromIP = 3
    Const cstlNameLenMin = 5
    Const cstlNameLenMax = 15
    Dim bLocalPorts As Boolean
    Dim rsPlayerName As Recordset
    Dim zPlayerName As String
    Dim zPlayerPassword As String
    Dim strPlayerConfirmPassword As String
    Dim zUserData As String
    Dim iHoldFlow As Integer
    Dim iPortID As Integer
    Dim bGETHTTP As Boolean
    Dim bACCEPT As Boolean
    Dim bTelnetMode As Boolean
    Dim bHTTP As Boolean
    Dim bSaveIPDate As Boolean
    Dim bDDoS As Boolean

    iPortID = MyCInt(zPortID) 'every time the user types something this subroutien hits
    If (iPortID > 1) Then
        zUserData = zCleanChatMessage(zOUserData) 'must go before <> 100 check
        If gbliFlow(iPortID) <> 100 Then
            bDDoS = False
            If (InStr(UCase(zUserData), "REQUEST") <> 0 Or Len(zUserData) >= (cstlNameLenMax * 3)) Then 'MSSP-REQUEST comes from Grapevine.com to test port-proof-of-life
                gbliFlow(iPortID) = 0 'Disconnect DDoS ??
                subSendMsgNoPortCheck cstzTimerControlGoodbye, zPortID
                bDDoS = True
            End If
            
            If (Not bDDoS) Then
                'if zUserData shows these lines of info we send them html back
                    'GET / HTTP/1.1
                    'Accept: */*
                    'Accept-Language: en -us
                    'Accept-Encoding: gzip , deflate
                    'User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)
                    'Host: 198.53.108.148:23
                    'Connection: Keep-Alive
                bTelnetMode = (gbliFlow(iPortID) > 11)
                If (Not bTelnetMode) Then
                    bSaveIPDate = (bIPHeader(zUserData, iPortID))
                    bGETHTTP = (Mid(zUserData, 1, 10) = "GET / HTTP")
                    bHTTP = (bHTTPHeader(zUserData, iPortID))   'See Also: (bHTTPHeader(zUserData))
                Else
                    bSaveIPDate = False
                    bHTTP = False
                End If
                
                If (Not bSaveIPDate) Then
                    If (Not bHTTP) Then
                        If (Mid(zUserData, 1, 4) <> "HELP") Then
                            bLocalPorts = (Mid(zRemoteHostIP, 1, 4) = "127." Or Mid(zRemoteHostIP, 1, 4) = "192.")
                            If (bLocalPorts Or lCountMatchingPorts(zRemoteHostIP) <= glblMaxConnectionsFromIP) Then
                                Select Case gbliFlow(iPortID)
                                    Case 11 'Confirm player name.
                                        gbliPlayerNameTries(iPortID) = gbliPlayerNameTries(iPortID) + 1
                                        If (lLoginCompletelyBannedIP(zRemoteHostIP) >= lgblCompletelyBannedMAX) Then
                                            If (gbllImmortalPortEAR > 3) Then subSystemMessageToImmortals gblzFBRED & "(EAR) IMMO COMPLETE LIST: BAN-Port[" & zPortID & "] IP[" & zRemoteHostIP & "]", 1
                                            subSendMsgNoPortCheck "&RIP Complete Ban: This IP is temporarly not available to play on this MUD." & vbCrLf & "Someone using your IP has caused a problem that cannot" & vbCrLf & "be resolved from your IP address." & vbCrLf & "You are welcome to try the Administrator E-mail: " & zSystemConfig(2) & vbCrLf & "If you feel this IP ban does not apply to you." & vbCrLf & "Solution!!! Do NOT logon for a few hours and the MUD will auto-release this BAN." & vbCrLf & "During a BAN repeat tries to reconnect may be held against you!", zPortID
                                            subSendMsgNoPortCheck cstzTimerControlQuit, zPortID
                                        Else
                                            zUserData = zKeepLettersOnly(zUserData)
                                            
                                            Select Case UCase(zUserData)
                                                Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                    gbliFlow(iPortID) = 0 'Disconnect
                                                Case "START", "OVER", "TOP", "REDO"
                                                    gbliFlow(iPortID) = 10
                                                    subClearCreatePlayerLoggedInPort zPortID
                                            End Select
                                            
                                            If (gbliFlow(iPortID) > 0) Then
                                                If (Len(zUserData) > cstlNameLenMax Or Len(zUserData) < cstlNameLenMin) Then   'Test for accuracy.
                                                    subSendMsgNoPortCheck vbCrLf & "&rInvalid player name . . . " & cstlNameLenMin & " - " & cstlNameLenMax & " characters, long and no spaces." & vbCrLf & "You may have also tried a reserved name that is no longer available.", zPortID
                                                    
                                                    If (Len(zUserData) > cstlNameLenMin) Then
                                                        If (lRandom(9) > 2) Then subCompleteBadPersonPoints gbliFlow(iPortID), zRemoteHostIP, 10 + lRandom(5)
                                                        If (gbllImmortalPortEAR > 2) Then subSystemMessageToImmortals gblzFNRED & "(EAR) Name>" & cstlNameLenMax & " Port[" & zPortID & "] IP[" & zRemoteHostIP & "]" & vbCrLf & "&a" & zOUserData, 1
                                                    End If
                                                    gbliFlow(iPortID) = 10 'Start again
                                                Else
                                                    zPlayerName = zNameFormat(zUserData)
                                                    If (bPlayerNameExists(zPlayerName) Or bPlayerNameExistsLoggedIn(zPlayerName)) Then
                                                        If (gbllImmortalPortEAR > -1) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &g" & zPlayerName & " [login] Port[" & zPortID & "] IP[" & zRemoteHostIP & "]", 1
                                                        gbliFlow(iPortID) = 20 'Log in person
                                                    Else
                                                        If (Not bAllowNewPlayerName(zUserData, zPortID)) Then
                                                            If lRandom(12) > 5 Then subCompleteBadPersonPoints gbliFlow(iPortID), zRemoteHostIP, lRandom(4) + 1 'just going though this side can cost a ding
                                                            If (gbllImmortalPortEAR > 2) Then subSystemMessageToImmortals gblzFBRED & "(EAR) " & "&y" & zPlayerName & "&c [rejected] &wPort[" & zPortID & "] IP[" & zRemoteHostIP & "]", 1
                                                            subSendMsgNoPortCheck vbCrLf & "&RThat was NOT a valid name, try again." & vbCrLf, zPortID
                                                            gbliFlow(iPortID) = 10 'Start again
                                                        Else
                                                            gbliFlow(iPortID) = 30 'New player
                                                            If (gbllImmortalPortEAR > -1) Then subSystemMessageToImmortals gblzFNRED & "(EAR) " & "&y" & zPlayerName & "&c [NEW] &wPort[" & zPortID & "] IP[" & zRemoteHostIP & "]", 1
                                                            If lRandom(3) = 1 Then subCompleteBadPersonPoints gbliFlow(iPortID), zRemoteHostIP, lRandom(3) 'new names get a bit more of a break on a ding
                                                        End If
                                                    End If
                                                    
                                                    If (gbliFlow(iPortID) <> 10) Then
                                                        iHoldFlow = gbliFlow(iPortID)
                                                        subClearLoginPort zPortID
                                                        gbliFlow(iPortID) = iHoldFlow
                                                        subPlaceNameOnPortForm zPortID, zPlayerName 'show player name on port form
                                                        subLoginAddPlayerName zPortID, zPlayerName, zRemoteHostIP
                                                    End If
                                                    
                                                    If (Not bReturnPlayerNeverBanned(zPlayerName)) Then 'the player is not marked as never ban so we try to see if they have been banned
                                                        Select Case (lLoginBannedIP(zRemoteHostIP))
                                                            Case 1
                                                                If (gbllImmortalPortEAR >= 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) " & "&R1: IP Ban - Full Matching Remote Host IP Ban successful on Port " & zPortID & " IP" & zRemoteHostIP, 1
                                                                subSendMsgNoPortCheck "&RMatching Ban by Player: This IP is no longer available to play on this MUD." & vbCrLf & "Someone using your IP has caused a problem that cannot" & vbCrLf & "be resolved from your IP address." & vbCrLf & "You are welcome to try the Administrator E-mail: " & zSystemConfig(2) & vbCrLf & "if you feel this IP ban does not apply to you.", zPortID
                                                                subSendMsgNoPortCheck cstzTimerControlQuit, zPortID 'we close down their port
                                                            Case 2
                                                                If (gbllImmortalPortEAR >= 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) " & "&R2: Network Ban - Partial Matching Remote Host IP Ban successful on Port " & zPortID & " IP" & zRemoteHostIP, 1
                                                                subSendMsgNoPortCheck "&RNetwork Ban by Player: This IP is no longer available to play on this MUD." & vbCrLf & "Someone using your IP has caused a problem that cannot" & vbCrLf & "be resolved from your IP address." & vbCrLf & "You are welcome to try the Administrator E-mail: " & zSystemConfig(2) & vbCrLf & "if you feel this IP ban does not apply to you.", zPortID
                                                                subSendMsgNoPortCheck cstzTimerControlQuit, zPortID 'we close down their port
                                                            Case 3
                                                                If (gbllImmortalPortEAR >= 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) " & "&R3: Network Ban - Partial Matching Complete IP Ban successful on Port " & zPortID & " IP" & zRemoteHostIP, 1
                                                                subSendMsgNoPortCheck "&RComplete Network Ban: This IP is no longer available to play on this MUD." & vbCrLf & "Someone using your IP has caused a problem that cannot" & vbCrLf & "be resolved from your IP address." & vbCrLf & "You are welcome to try the Administrator E-mail: " & zSystemConfig(2) & vbCrLf & "if you feel this IP ban does not apply to you.", zPortID
                                                                subSendMsgNoPortCheck cstzTimerControlQuit, zPortID 'we close down their port
                                                        End Select
                                                    End If
                                                End If
                                            End If
                                        End If
                                    Case 21 'Player password:
                                        gbliPasswordTries(iPortID) = gbliPasswordTries(iPortID) + 1
                                        
                                        zUserData = zKeepLettersOnly(MyCStr(UCase(zUserData)))
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            If (InStr(" ", zUserData) > 0 Or Len(zUserData) > 15 Or Len(zUserData) < 4) Then 'Test for accuracy.
                                                If lRandom(20) = 1 Then subCompleteBadPersonPoints gbliFlow(iPortID), zRemoteHostIP, 1
                                                If (gbllImmortalPortEAR >= 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) " & "&RInvalid password on Port " & zPortID & ", IP " & zRemoteHostIP, 1
                                                subSendMsgNoPortCheck vbCrLf & "&rInvalid player password . . . 4 - 15 characters, long no spaces!", zPortID
                                                gbliFlow(iPortID) = 20
                                            Else
                                                zPlayerPassword = zKeepLettersOnly(zUserData)
                                                If (bLoginPlayerNameExistsAndCorrectPassword(zPortID, zPlayerPassword)) Then
                                                    subSendMsgNoPortCheck gblzFNYEL & vbCrLf & "Password Accepted !", zPortID
                                                    If (bPlayerAlreadyLoggedIn(zPortID)) Then
                                                        subReconnectPlayer zPortID
                                                    End If
                                                    subLoginAddPassword zPortID, zPlayerPassword
                                                    gbliFlow(iPortID) = 99 'Done
                                                Else
                                                    subSendMsgNoPortCheck vbCrLf & "&rIncorrect Password . . .", zPortID
                                                    gbliFlow(iPortID) = 20
                                                End If
                                            End If
                                        End If
                                    Case 31 'Add new player y/n?
                                        zUserData = MyCStr(UCase(zUserData))
                                        
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            Select Case zUserData
                                                Case "Y", "YES"
                                                    gbliFlow(iPortID) = 40 'Information was correct!
                                                Case "N", "NO"
                                                    gbliFlow(iPortID) = 10 'Start over
                                                    subClearCreatePlayerLoggedInPort zPortID
                                                Case Else
                                                    gbliFlow(iPortID) = 30 'Wrong Information for Player.
                                            End Select
                                        End If
                                    Case 41 'Create password:
                                        zUserData = zKeepLettersOnly(MyCStr(UCase(zUserData)))
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            If (InStr(" ", zUserData) > 0 Or Len(zUserData) < 4 Or Len(zUserData) > 15) Then 'Test for accuracy.
                                                If lRandom(20) = 1 Then subCompleteBadPersonPoints gbliFlow(iPortID), zRemoteHostIP, 1
                                                subSendMsgNoPortCheck vbCrLf & "&rInvalid new password . . . 4 - 15 characters, long no spaces!", zPortID
                                                gbliFlow(iPortID) = 10 'Start again
                                            Else
                                                zPlayerPassword = zKeepLettersOnly(zUserData)
                                                subLoginAddPassword zPortID, zPlayerPassword
                                                gbliFlow(iPortID) = 50 'Renter password
                                            End If
                                        End If
                                    Case 51 'Confirm password:
                                        zUserData = zKeepLettersOnly(MyCStr(UCase(zUserData)))
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            If (InStr(" ", zUserData) > 0 Or Len(zUserData) < 4 Or Len(zUserData) > 15) Then 'Test for accuracy.
                                                If lRandom(20) = 1 Then subCompleteBadPersonPoints gbliFlow(iPortID), zRemoteHostIP, 1
                                                subSendMsgNoPortCheck vbCrLf & "&rInvalid confirmed password . . . 4 - 15 characters, long no spaces!", zPortID
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Else
                                                zPlayerPassword = zKeepLettersOnly(zUserData)
                                                subLoginAddConfirmPassword zPortID, zPlayerPassword
                                                
                                                If (bLoginPlayerDoesPasswordMatchConfirm(zPortID)) Then
                                                    gbliFlow(iPortID) = 60
                                                Else
                                                    subSendMsgNoPortCheck vbCrLf & "&rFailed! Passwords do not match!", zPortID
                                                    gbliFlow(iPortID) = 0 'Disconnect: Password and Reentered passwords failed
                                                End If
                                            End If
                                        End If
                                    Case 61 'Choose your Gender:
                                        zUserData = zKeepLettersOnly(MyCStr(UCase(zUserData)))
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            If (Not bAmong(zUserData, "M", "MALE", "F", "FEMALE")) Then 'Test for accuracy.
                                                gbliFlow(iPortID) = 60 'Repeat question
                                            Else
                                                subLoginAddGender zPortID, Mid(zUserData, 1, 1)
                                                gbliFlow(iPortID) = 64 'Pick race
                                            End If
                                        End If
                                    Case 65 'Choose your Race:
                                        zUserData = zKeepLettersOnly(MyCStr(UCase(zUserData)))
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            If (Not bAmong(zUserData, "PIXIE", "DWARF", "HUMAN", "OGRE", "ORC", "GNOME", "TROLL", "ELF", "MINOTAUR", "DRAC", "HALFLING", "UNDEAD", "FELPUR")) Then 'Test for accuracy.
                                                gbliFlow(iPortID) = 64 'Repeat question
                                            Else
                                                subLoginAddRace zPortID, Mid(zUserData, 1, 3)
                                                gbliFlow(iPortID) = 70 'Pick class
                                            End If
                                        End If
                                    Case 71 'Choose your Class:
                                        zUserData = zKeepLettersOnly(MyCStr(UCase(zUserData)))
                                        Select Case UCase(zUserData)
                                            Case "CLOSE", "STOP", "DONE", "QUIT", "FINISH", "SAVE"
                                                gbliFlow(iPortID) = 0 'Disconnect
                                            Case "START", "OVER", "TOP", "REDO"
                                                gbliFlow(iPortID) = 10
                                                subClearCreatePlayerLoggedInPort zPortID
                                        End Select
                                        If (gbliFlow(iPortID) > 0 And gbliFlow(iPortID) <> 10) Then
                                            If (Not bAmong(zUserData, "MAGE", "CLERIC", "DRUID", "BARD", "MONK", "ASSASSIN", "GLADIATOR", "RANGER", "KNIGHT", "PALADIN", "THIEF", "GYPSY", "WARRIOR")) Then 'Test for accuracy.
                                                gbliFlow(iPortID) = 70 'Repeat question
                                            Else
                                                subLoginAddClass zPortID, Mid(zUserData, 1, 2)
                                                If (bLoginCreateAccount(zPortID, Mid(zUserData, 1, 2))) Then 'Write the account to the main table
                                                    subSendMsgNoPortCheck "&W" & vbCrLf & "W E L C O M E  A B O A R D!", zPortID
                                                    'If (bReturnEveryoneWelcomeDateTime()) Then subSimpleEchoChannel "&WEveryone Welcome &Y" & zPlayerLoggedIn(zPortID) & "&W into the realm!"
                                                    gbliFlow(iPortID) = 99 'Done
                                                End If
                                            End If
                                        End If
                                End Select
                            Else
                                subSendMsgNoPortCheck "&R" & vbCrLf & "Too many connections recorded from your location!" & vbCrLf & "No more than " & glblMaxConnectionsFromIP & " connections are allowed at one time.", zPortID
                                subSendMsgNoPortCheck cstzTimerControlQuit, zPortID
                            End If
                        End If
                        
                        'Help Machine
                        Select Case zUserData
                            Case "HELP"
                                Select Case gbliFlow(iPortID)
                                    Case 11
                                        'subSendMsgNoPortCheck "&W"  & vbCrLf & "Simply enter your player name from " & cstlNameLenMin & " - " & cstlNameLenMax & " characters long, without spaces in the name." & vbCrLf, zPortID
                                        subSendMsgNoPortCheck "&WEnter your player name [&wQUIT/REDO&W]&w:", zPortID
                                        gbliFlow(iPortID) = 10
                                    Case 64
                                        subTranslateChartRaces zPortID
                                        subTranslateChartClasses zPortID
                                        gbliFlow(iPortID) = 64
                                    Case 70
                                        subTranslateChartClasses zPortID
                                        subTranslateChartRaces zPortID
                                        gbliFlow(iPortID) = 70
                                    Case Else
                                        subSendMsgNoPortCheck "&W" & vbCrLf & "There is no help on this topic." & vbCrLf & vbCrLf, zPortID
                                End Select
                        End Select
                        
                        'Message Machine
                        Select Case gbliFlow(iPortID)
                            Case 0 'Close port
                                subSendMsgNoPortCheck cstzTimerControlGoodbye, zPortID
                            Case 10 'Player name?
                                If (gbliPlayerNameTries(iPortID) > 5) Then
                                    subSendMsgNoPortCheck "&RToo many attempts, try again later.", zPortID
                                    subSendMsgNoPortCheck cstzTimerControlQuit, zPortID
                                Else
                                    'subSendMsgNoPortCheck "&w"  & "QUIT or REDO at anytime." & vbCrLf & "Make your player name " & cstlNameLenMin & " - " & cstlNameLenMax & " letters long." & vbCrLf & vbCrLf & "&GIf you use CoA Client go to MENU: Creator > Character Profile." & vbCrLf & "Now make your character name in there then make the" & vbCrLf & "same character name right here for the server.", zPortID
                                    subSendMsgNoPortCheck "&WEnter your player name [&wQUIT/REDO&W]&w:", zPortID
                                    gbliFlow(iPortID) = 11
                                End If
                            Case 20 'Player password?
                                If (gbliPasswordTries(iPortID) > 2) Then
                                    subSendMsgNoPortCheck "&RToo many attempts, your IP has been logged.", zPortID
                                    subSendMsgNoPortCheck cstzTimerControlQuit, zPortID
                                Else
                                    subSendMsgNoPortCheck gblzFBYEL & "Enter your password: ", zPortID
                                    gbliFlow(iPortID) = 21
                                End If
                            Case 30 'Create account Y or N?
                                'If (lCountMatchingPlayerNamesAtIP(zPortID) < cstlMaxPlayersFromIP) Then
                                    subSendMsgNoPortCheck "&WAccount Creation: Create account " & zPlayerLoggedIn(zPortID) & ", Y/N: ", zPortID
                                    gbliFlow(iPortID) = 31
                                'Else
                                '    subSendMsgNoPortCheck "&R~ACCOUNT CREATION FAILED~" & gblzFNMAG & vbCrLf & "Too many player names exist from your IP location." & vbCrLf & "Please delete the extra player names at your location." & vbCrLf & "~CONNECTION CLOSED~", zPortID
                                '    subSendMsgNoPortCheck cstzTimerControlQuit, zPortID
                                'End If
                            Case 40 'Enter your password?
                                subSendMsgNoPortCheck "&WAccount Creation: Enter your password (15 chars, letters only): ", zPortID
                                gbliFlow(iPortID) = 41
                            Case 50 'Confirm password:
                                subSendMsgNoPortCheck "&WAccount Creation: Confirm the password (15 chars, letters only): ", zPortID
                                gbliFlow(iPortID) = 51
                            Case 60 'Gender M or F?
                                subSendMsgNoPortCheck "&WAccount Creation: Pick your gender, M/F: ", zPortID
                                gbliFlow(iPortID) = 61
                            Case 64 'Race?
                                subSendMsgNoPortCheck vbCrLf & "&WAccount Creation:" & vbCrLf & "Pick a race that has discovered the Stargate system:" & vbCrLf & "HELP will show you the race chart." & vbCrLf & "Drac Dwarf Elf Felpur Gnome Halfling Human Minotaur" & vbCrLf & "Ogre Orc Pixie Troll Undead:", zPortID
                                gbliFlow(iPortID) = 65
                            Case 70 'Class? Bard Druid Cleric Mage Monk...
                                subSendMsgNoPortCheck vbCrLf & "&WAccount Creation: Pick your class," & vbCrLf & "HELP will show you the class chart." & vbCrLf & "Assassin Bard Cleric Druid Gladiator Gypsy Knight Mage Monk" & vbCrLf & "Paladin Ranger Thief Warrior:", zPortID
                                gbliFlow(iPortID) = 71
                            Case 99
                                subUpdatePlayerPortID zPortID 'must be before subRecordPlayerRemoteID
                                subRecordPlayerRemoteID zPortID, zRemoteHostIP
                                subSendMsgNoPortCheck cstzTimerControlLook, zPortID
                                subIndicateGameEnterExit zPortID, "ENTERS"
                                gbliFlow(iPortID) = 100
                                subIfRequiredCrownTheNewAdministrator
                            Case 100 'we take repeat requests now from the player here
                                subProcessUserLine zPortID, zUserData
                        End Select
                    End If
                End If
                
                
                If (bSaveIPDate) Then 'DISABLED ON THE CALL OUT SIDE >> this is so that other coa systems can call into coa.servegame.com and report their ip to this system
                    If (lngSQLRecordCount("SELECT Attempts FROM tblCallOut WHERE (RemoteHostIP='" & zRemoteHostIP & "');") = 0) Then
                        MyDB.Execute "INSERT INTO tblCallOut ( IPActivated, RemoteHostIP ) SELECT '" & zOUserData & "', '" & zRemoteHostIP & "';", dbFailOnError
                    Else
                        MyDB.Execute "UPDATE tblCallOut SET IPActivated='" & zOUserData & "', Attempts=[Attempts]+1 WHERE (RemoteHostIP='" & zRemoteHostIP & "');", dbFailOnError
                    End If
                End If
                
                If (bGETHTTP) Then
                    subSendMsgNoPortCheck zHTML(1), zPortID  'we only reply to the initial request
                End If
            End If '(Not bDDoS)
        Else
            subProcessUserLine zPortID, zUserData
        End If 'gbliFlow(iPortID) <> 100
    End If '(iPortID > 1)
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginUserPort," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bReturnEveryoneWelcomeDateTime()
On Error Resume Next
    Dim bReturn As String 'if a lot of people entered it would spam too much
    If (Len(gblzEveryoneWelcomeDateTime) = 0) Then
        bReturn = True
    Else
        bReturn = (DateDiff("n", gblzEveryoneWelcomeDateTime, Format(Now(), "mmm dd, yyyy hh:nn")) > 29) 'half hour
    End If
    If (bReturn) Then gblzEveryoneWelcomeDateTime = Format(Now(), "mmm dd, yyyy hh:nn")
    bReturnEveryoneWelcomeDateTime = bReturn
End Function
Public Sub subImmortalSilence(zWord2 As String, zType As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lSilencedGlobal As Long
    Dim lSilencedRoom As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, SilencedGlobal, SilencedRoom FROM tblPlayer WHERE (PlayerName Like '" & zWord2 & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lSilencedGlobal = MyCLng(rsPlayer!SilencedGlobal)
        lSilencedRoom = MyCLng(rsPlayer!SilencedRoom)
        rsPlayer.Edit
        Select Case zType
            Case "SG"
                Select Case (lSilencedGlobal)
                    Case True
                        subSendMsg "&G" & zPlayerName & " is no longer globally silenced.", zPortID
                    Case False
                        subSendMsg gblzFBRED & zPlayerName & " is now globally silenced!", zPortID
                End Select
                lSilencedGlobal = (Not lSilencedGlobal)
            Case "SR"
                Select Case (lSilencedRoom)
                    Case True
                        subSendMsg "&G" & zPlayerName & " is no longer room silenced.", zPortID
                    Case False
                        subSendMsg gblzFBRED & zPlayerName & " is now room silenced!", zPortID
                End Select
                lSilencedRoom = (Not lSilencedRoom)
        End Select
        If (lSilencedGlobal <> 0 And lSilencedRoom <> 0) Then subSendMsg gblzFBRED & zPlayerName & "&r" & " is now completely silenced! *enjoy the piece and quiet*", zPortID
        rsPlayer!SilencedGlobal = lSilencedGlobal
        rsPlayer!SilencedRoom = lSilencedRoom
        rsPlayer.Update
    Else
        subSendMsg "&gIMMO SG PLAYERNAME" & vbCrLf & "IMMO SR PLAYERNAME", zPortID
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalSilence," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bImmortalPlayerWithInRadius(lPlayerID As Long, lX As Long, lY As Long, lZ As Long) As Boolean
On Error GoTo Err_Check
'Player is in their build area if this returns true.
    Dim bReturn As Boolean
    Dim rsPlayer As Recordset
    Set rsPlayer = MyDB.OpenRecordset("SELECT tblPlayerAssignedArea.PlayerID, [X]-[Radius] AS XRadiusStart, [X]+[Radius] AS XRadiusEnd, [Y]-[Radius] AS YRadiusStart, [Y]+[Radius] AS YRadiusEnd, [Z]-[Radius] AS ZRadiusStart, [Z]+[Radius] AS ZRadiusEnd, tblPlayerAssignedArea.Radius FROM tblPlayerAssignedArea WHERE (((tblPlayerAssignedArea.PlayerID)=" & lPlayerID & ") AND (([X]-[Radius])<=" & lX & ") AND (([X]+[Radius])>=" & lX & ") AND (([Y]-[Radius])<=" & lY & ") AND (([Y]+[Radius])>=" & lY & ") AND (([Z]-[Radius])<=" & lZ & ") AND (([Z]+[Radius])>=" & lZ & "));", dbOpenSnapshot)
    bReturn = (Not rsPlayer.EOF)
    Set rsPlayer = Nothing
    bImmortalPlayerWithInRadius = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bImmortalPlayerWithInRadius," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Sub subImmortalReturnPlayerIDPortLock(zPlayerName As String, zShadowDuration As String, zPortID As String, bLock As Boolean)
On Error GoTo Err_Check
'Player is in their build area if this returns true.
    Dim bReturn As Boolean
    Dim rsPlayer As Recordset
    Dim lShadowDuration As Long
    Dim lPlayerID As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        
        If (bLock) Then
            MyDB.Execute "UPDATE tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID SET tblObject.ReturnPlayerID = " & lPlayerID & " WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));", dbFailOnError
            MyDB.Execute "UPDATE tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID SET tblObject.ReturnPlayerID = " & lPlayerID & " WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & "));", dbFailOnError
            subSendMsg "&M" & zPlayerName & "'s equipment and inventory items ARE NOW all stamped.", zPortID
        Else
            MyDB.Execute "UPDATE tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID SET tblObject.ReturnPlayerID = 0 WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));", dbFailOnError
            MyDB.Execute "UPDATE tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID SET tblObject.ReturnPlayerID = 0 WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & "));", dbFailOnError
            subSendMsg "&M" & zPlayerName & "'s equipment and inventory items are NO LONGER stamped.", zPortID
        End If
    Else
        subSendMsg "&gPlayer name not found in the realm.", zPortID
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalReturnPlayerIDPortLock," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalSetShadowLevel(zPlayerName As String, zShadowDuration As String, zPortID As String)
On Error GoTo Err_Check
'Player is in their build area if this returns true.
    Dim rsPlayer As Recordset
    Dim lShadowDuration As Long
    
    If (UCase(zPlayerName) <> "ALL") Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, ShadowCloakDuration FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenDynaset)
        If (Not rsPlayer.EOF) Then
            lShadowDuration = MyCLng(zShadowDuration)
            If (lShadowDuration < 0) Then lShadowDuration = 0
            rsPlayer.Edit
            rsPlayer!ShadowCloakDuration = lShadowDuration
            rsPlayer.Update
            subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " was set to a shadow cloak duration of " & lShadowDuration & " rounds.", zPortID
        Else
            subSendMsg "&gPlayer name not found in the realm.", zPortID
        End If
        Set rsPlayer = Nothing
    Else
        MyDB.Execute "UPDATE tblPlayer SET ShadowCloakDuration=0;", dbFailOnError
        subSendMsg "&GAll players in the realm no longer have shadow cloak on.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalSetShadowLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalSetHallucinateLevel(zPlayerName As String, zDuration As String, zPortID As String)
On Error GoTo Err_Check
'Player is in their build area if this returns true.
    Dim rsPlayer As Recordset
    Dim lDuration As Long
    
    If (UCase(zPlayerName) <> "ALL") Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, Hallucinate FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenDynaset)
        If (Not rsPlayer.EOF) Then
            lDuration = MyCLng(zDuration)
            If (lDuration < 0) Then lDuration = 0
            rsPlayer.Edit
            rsPlayer!Hallucinate = lDuration
            rsPlayer.Update
            subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " was set to a hallucinate duration of " & lDuration & " rounds.", zPortID
        Else
            subSendMsg "&gPlayer name not found in the realm.", zPortID
        End If
        Set rsPlayer = Nothing
    Else
        MyDB.Execute "UPDATE tblPlayer SET Hallucinate=5 WHERE Len([PortID])>1;", dbFailOnError
        subSendMsg "&RAll players in the realm are now hallucinating for 5 rounds.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalSetHallucinateLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalSetScareLevel(zPlayerName As String, zDuration As String, zPortID As String)
On Error GoTo Err_Check
'Player is in their build area if this returns true.
    Dim rsPlayer As Recordset
    Dim lDuration As Long
    
    lDuration = MyCLng(zDuration)
    If (UCase(zPlayerName) <> "ALL") Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, PlayerFleeDuration FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenDynaset)
        If (Not rsPlayer.EOF) Then
            rsPlayer.Edit
            rsPlayer!PlayerFleeDuration = lDuration
            rsPlayer.Update
            subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " was set to a fear duration of " & lDuration & " rounds.", zPortID
        Else
            subSendMsg "&gIMMO SCARE [ALL/PLAYERNAME] DURATION", zPortID
        End If
        Set rsPlayer = Nothing
    Else
        Select Case lDuration
            Case 0
                MyDB.Execute "UPDATE tblPlayer SET PlayerFleeDuration=0;", dbFailOnError
                subSendMsg "&g*POOF* All players in the realm are no longer scared!", zPortID
            Case Else
                MyDB.Execute "UPDATE tblPlayer SET PlayerFleeDuration=" & lDuration & " WHERE ImmortalLevel=0;", dbFailOnError
                subSendMsg "&R*POOF* All players in the realm are now scared for " & lDuration & " rounds.", zPortID
        End Select
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalSetScareLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalSetEnterExitMsg(zPlayerName As String, zPromptOriginal As String, zType As String, zPortID As String, lImmortalLevel As Long)
On Error GoTo Err_Check
'Player is in their build area if this returns true.
    Dim rsPlayer As Recordset
    Dim zMsg As String
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerDesc, ImmortalLevel, LastPlayed, PlayerName, Title, X, Y, Z, PlayerFleeDuration FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        If (MyCLng(rsPlayer!ImmortalLevel) <= lImmortalLevel) Then
            zMsg = zDropFirstWordCleanLine(zPromptOriginal)
            zMsg = zDropFirstWordCleanLine(zMsg)
            
            If (UCase(zMsg) = UCase(zPlayerName)) Then
                zMsg = ""
                subSendMsg "&GClearing the message.", zPortID
            End If
            
            subSendMsg "&M>" & zMsg & "<", zPortID
            
            Select Case zType
                Case "TITLE"
                    rsPlayer.Edit
                    rsPlayer!Title = Mid(zMsg, 1)
                    rsPlayer.Update
                    subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " title set, type WHO when they are online.", zPortID
                    subSendMsg "&a" & (Mid(zMsg, 1)), zPortID
                Case "DESC"
                    rsPlayer.Edit
                    rsPlayer!PlayerDesc = MyCStr(zMsg)
                    rsPlayer.Update
                    Select Case (Len(zMsg) > 0)
                        Case True
                            subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " description was updated! Len(" & Len(zMsg) & ")", zPortID
                        Case Else
                            subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " description was cleared!", zPortID
                    End Select
                    subSendMsg "&a" & (zMsg), zPortID
                Case "DATE", "LAST"
                    If (IsDate(Format(zMsg, "mmm dd, yyyy"))) Then
                        rsPlayer.Edit
                        rsPlayer!LastPlayed = Format(zMsg, "mmm dd, yyyy hh:nn")
                        rsPlayer.Update
                        subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " last played date message set.", zPortID
                    Else
                        subSendMsg "&gIMMO LASTDATE SYNTAX: Use the format Jan-21-1972 or Jan-01-2005...", zPortID
                    End If
            End Select
        Else
            subSendMsg "&RYou are too weak to play around with that immortal!", zPortID
        End If
    Else
        subSendMsg "&gPlayer name not found in the realm.", zPortID
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalSetEnterExitMsg (title too)," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub strImmortalTransportPlayer(zWord2 As String, zWord3 As String, lWhereID As Long, lX As Long, lY As Long, lZ As Long, zPortID As String)   'immo trans playername [areaname/playername]
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lTPlayerID As Long
    Dim zTPlayerName As String
    Dim lDPlayerID As Long
    Dim zDPlayerName As String
    Dim zDPortID As String
    Dim lAreaX As Long
    Dim lAreaY As Long
    Dim lAreaZ As Long
    Dim lTWhereID As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim zAreaName As String
    Dim bOkay As Boolean
    
    bOkay = False
    If (UCase(zWord2) = "@STAMP@" Or UCase(zWord2) = "@LOCATION@" Or UCase(zWord2) = "@POINT@" Or UCase(zWord2) = "@TRANSPORT@" Or UCase(zWord2) = "@TRANSPORTSPOT@") Then
        'We default the where transport location to here
        subSendMsg "&yYou stamp here as the area immortal transport point.", zPortID
        MyDB.Execute "UPDATE tblWhere SET tblWhere.TransportX = " & lX & ", tblWhere.TransportY = " & lY & ", tblWhere.TransportZ = " & lZ & " WHERE (((tblWhere.WhereID)=" & lWhereID & "));", dbFailOnError
    Else
        zTPlayerName = ""
        
        'Get the player information
        Set rsPlayer = MyDB.OpenRecordset("SELECT PortID, PlayerID, PlayerName, X, Y, Z, WhereID FROM tblPlayer WHERE (PlayerName='" & zWord2 & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lTWhereID = MyCLng(rsPlayer!WhereID)
            lTPlayerID = MyCLng(rsPlayer!PlayerID)
            zTPlayerName = MyCStr(rsPlayer!PlayerName)
            zDPortID = MyCStr(rsPlayer!PortID)
            lTX = MyCLng(rsPlayer!x)
            lTY = MyCLng(rsPlayer!y)
            lTZ = MyCLng(rsPlayer!z)
            subCombatEndedInitializeCombatCellsPortID MyCLng(zDPortID)
        End If
        Set rsPlayer = Nothing
        
        'try to transport to a player first
        lDPlayerID = 0
        Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, PlayerID, PlayerName, WhereID FROM tblPlayer WHERE (PlayerName='" & zWord3 & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lTWhereID = MyCLng(rsPlayer!WhereID)
            lDPlayerID = MyCLng(rsPlayer!PlayerID)
            zDPlayerName = MyCStr(rsPlayer!PlayerName)
            lAreaX = MyCLng(rsPlayer!x)
            lAreaY = MyCLng(rsPlayer!y)
            lAreaZ = MyCLng(rsPlayer!z)
            bOkay = True
        End If
        Set rsPlayer = Nothing
        
        'Area
        If (Not bOkay) Then
            zAreaName = ""
            Set rsPlayer = MyDB.OpenRecordset("SELECT tblWhere.WhereID, tblWhere.WhereTitle, tblWhere.TransportX, tblWhere.TransportY, tblWhere.TransportZ FROM tblWhere WHERE (((tblWhere.WhereTitle) Like '*" & zWord3 & "*'));", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                lTWhereID = MyCLng(rsPlayer!WhereID)
                lAreaX = MyCLng(rsPlayer!TransportX)
                lAreaY = MyCLng(rsPlayer!TransportY)
                lAreaZ = MyCLng(rsPlayer!TransportZ)
                bOkay = True
                If (bCheckAreaExists(zPortID, lAreaX, lAreaY, lAreaZ, False)) Then
                    zAreaName = (MyCStr(rsPlayer!WhereTitle))
                Else
                    subSendMsg "&Y" & "The default transport location no longer exists at x" & lAreaX & " y" & lAreaY & " z" & lAreaZ & ".", zPortID
                    lAreaX = 0
                    lAreaY = 0
                    lAreaZ = 0
                End If
            End If
            Set rsPlayer = Nothing
        End If
        
        'Creature in the mobile realm
        If (Not bOkay) Then
            Set rsPlayer = MyDB.OpenRecordset("SELECT tblArea.WhereID, tblMob.MobID, tblMob.MobName, tblMob.X, tblMob.Y, tblMob.Z FROM tblArea INNER JOIN tblMob ON (tblArea.Z = tblMob.Z) AND (tblMob.Y = tblArea.Y) AND (tblArea.X = tblMob.X) WHERE (((tblMob.MobName) Like '*" & zWord3 & "*') AND ((tblMob.RespawnDelay)=0));", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                lTWhereID = MyCLng(rsPlayer!WhereID)
                lAreaX = MyCLng(rsPlayer!x)
                lAreaY = MyCLng(rsPlayer!y)
                lAreaZ = MyCLng(rsPlayer!z)
                zAreaName = (zShortstop(MyCStr(rsPlayer!MobName))) & " ID#" & MyCLng(rsPlayer!MobID)
                bOkay = True
            End If
            Set rsPlayer = Nothing
        End If
        
        'Transport to an Object
        'If (Not bOkay) Then 'OH WOW this is lagger after so many 10's of thousands of items
        '    Set rsPlayer = MyDB.OpenRecordset("SELECT tblArea.WhereID, tblObject.ObjectID, tblObject.ObjectName, tblObject.X, tblObject.Y, tblObject.Z FROM tblArea INNER JOIN tblObject ON (tblArea.Z = tblObject.Z) AND (tblObject.Y = tblArea.Y) AND (tblArea.X = tblObject.X) WHERE (((tblObject.ObjectName) Like '*" & zWord3 & "*') AND ((tblObject.Status)<2) AND ((tblArea.PlayerType)=0) AND ((tblObject.Burried)=False));", dbOpenSnapshot) 'this can be laggy
        '    If (Not rsPlayer.EOF) Then
        '        lTWhereID = MyCLng(rsPlayer!WhereID)
        '        lAreaX = MyCLng(rsPlayer!X)
        '        lAreaY = MyCLng(rsPlayer!Y)
        '        lAreaZ = MyCLng(rsPlayer!Z)
        '        zAreaName = (zShortstop(MyCStr(rsPlayer!ObjectName))) & " ID#" & MyCLng(rsPlayer!ObjectID)
        '        bOkay = True
        '    End If
        '    Set rsPlayer = Nothing
        'End If
        
        If (zTPlayerName <> "") Then
            If (zAreaName <> "") Then
                subSendMsg "&Y" & zTPlayerName & " was transported to " & zAreaName & ".", zPortID
            Else
                If (zDPlayerName <> "") Then
                    subSendMsg "&Y" & zTPlayerName & " was transported to " & zDPlayerName & ".", zPortID
                Else
                    If (zTPlayerName <> "") Then
                        subSendMsg gblzFBRED & zTPlayerName & " was not transported." & vbCrLf & "&gIMMORTAL TRANSPORT AREANAME/PLAYERNAME   - type AREAS for an areaname.", zPortID
                    Else
                        subSendMsg "&RThat person was not found in the realm." & vbCrLf & "&gIMMORTAL TRANSPORT AREANAME/PLAYERNAME   - type AREAS for an areaname.", zPortID
                    End If
                End If
            End If
            
            If (bOkay) Then
                subCombatEndedInitializeCombatCellsPortID MyCLng(zDPortID)
                subSendMsg "&Y" & "You are transported!", zDPortID
                subSendMsgAreaAll gblzFBYEL & zTPlayerName & " transports into the room!", lAreaX, lAreaY, lAreaZ
                MyDB.Execute "UPDATE tblPlayer SET SitObjectID=0, Status=5, X = " & lAreaX & ", Y = " & lAreaY & ", Z = " & lAreaZ & ", WhereID=" & lTWhereID & " WHERE (PlayerID=" & lTPlayerID & ");", dbFailOnError
                subSendMsgAreaAll gblzFBYEL & zTPlayerName & " is transported out of the area!", lTX, lTY, lTZ
            End If
        Else
            subSendMsg "&RTransport failed: &gThe target could not be found." & vbCrLf & "IMMO TRANS PLAYER LOCATION" & vbCrLf & "You can also transport mark a spot in a where area:" & vbCrLf & "IMMO TRANS @STAMP@", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "strImmortalTransportPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub strImmortalAssignRadiusPlayer(zWord2 As String, zWord3 As String, lImmX As Long, lImmY As Long, lImmZ As Long, zPortID As String)   'immo trans playername [areaname/playername]
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lTPlayerID As Long
    Dim zTPlayerName As String
    Dim lDPlayerID As Long
    Dim zDPlayerName As String
    Dim zDPortID As String
    Dim lAreaX As Long
    Dim lAreaY As Long
    Dim lAreaZ As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim zAreaName As String
    Dim bOkay As Boolean
    
    bOkay = False
    
    lAreaX = lImmX
    lAreaY = lImmY
    lAreaZ = lImmZ
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PortID, PlayerID, PlayerName, X, Y, Z FROM tblPlayer WHERE (PlayerName='" & zWord2 & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bOkay = True
        lTPlayerID = MyCLng(rsPlayer!PlayerID)
        zTPlayerName = MyCStr(rsPlayer!PlayerName)
        zDPortID = MyCStr(rsPlayer!PortID)
        lTX = MyCLng(rsPlayer!x)
        lTY = MyCLng(rsPlayer!y)
        lTZ = MyCLng(rsPlayer!z)
    End If
    Set rsPlayer = Nothing
    
    If (bOkay) Then
        MyDB.Execute "DELETE PlayerID FROM tblPlayerAssignedArea WHERE (PlayerID=" & lTPlayerID & ");", dbFailOnError
        subSendMsg "&RAll assigned areas for this player were cleared.", zPortID
        If (MyCLng(zWord3) > 0) Then
            subSendMsg "&Y" & "Area Assigned to " & zTPlayerName & " at " & lAreaX & " " & lAreaY & " " & lAreaZ & " created with a radius of " & MyCLng(zWord3) & ".", zPortID
            MyDB.Execute "INSERT INTO tblPlayerAssignedArea ( X, Y, Z, PlayerID, Radius ) SELECT " & lAreaX & ", " & lAreaY & ", " & lAreaZ & ", " & lTPlayerID & ", " & MyCLng(zWord3) & ";", dbFailOnError
        Else
            subSendMsg "&GASSIGN PLAYERNAME RADIUS", zPortID
        End If
    Else
        subSendMsg "&GASSIGN PLAYERNAME RADIUS" & vbCrLf & "&gPlayer not found in the realm.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "strImmortalAssignRadiusPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalForce(zPortID As String, zTargetPortID As String, zUserData As String, lImmortalLevel As Long)
On Error GoTo Err_Check
    Dim lPortID As Long
    Dim zMsg As String
    
    lPortID = MyCLng(zTargetPortID)
    If (InStr(UCase(zUserData), "IMMO") > 0) Then
        subSendMsg "&RYou cannot force someone to perform that command." & vbCrLf & "&gSYNTAX: IMMO FORCE PORTID COMMANDLINE", zPortID
    Else
        If (lImmortalLevel > lImmortalLevelPortID(MyCStr(lPortID))) Then
            If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                zMsg = zDropFirstWordCleanLine(zUserData)
                subSendMsg zMsg, MyCStr(lPortID)
                subProcessUserLine MyCStr(lPortID), zMsg
                subSendMsg "&GSent: " & zMsg & " to port " & zTargetPortID, zPortID
            Else
                subSendMsg "&RInvalid Port " & lPortID & " - " & cstlMinPort & " to " & cstlMaxPort & " are avaliable." & vbCrLf & "&gSYNTAX: IMMO FORCE PORTID COMMANDLINE", zPortID
            End If
        Else
            subSendMsg "&RYou are too weak to force that person to do anything!" & vbCrLf & "&gSYNTAX: IMMO FORCE PORTID COMMANDLINE", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalForce," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalRemoteHost(zRemoteHostIP As String, zPortID As String)
On Error GoTo Err_Check
    Dim lCount As Long
    lCount = lngSQLRecordCount("SELECT RemoteHostID FROM tblPlayerRemoteHost WHERE (RemoteHostID='" & zRemoteHostIP & "');")
    If (lCount > 0) Then
        MyDB.Execute "DELETE RemoteHostID FROM tblPlayerRemoteHost WHERE (RemoteHostID='" & zRemoteHostIP & "');", dbFailOnError
        subSendMsg gblzFBRED & lCount & " Remote Host IPs matching " & zRemoteHostIP & " were deleted.", zPortID
    Else
        subSendMsg "&GThere were no Remote Host IPs matching " & zRemoteHostIP & ".", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalRemoteHost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalNuke(zPlayerName As String, zPassword As String, zPortID As String)
On Error GoTo Err_Check
    Const cstRollMax = 50
    Dim rsPlayer As Recordset
    Dim bNuke As Boolean
    Dim lRoll As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT NukeAllowed, PlayerID, PlayerName, Password, PortID FROM tblPlayer WHERE (PlayerName Like '" & zPlayerName & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        bNuke = (MyCInt(rsPlayer!NukeAllowed) <> 0)
        If (UCase(MyCStr(rsPlayer!Password)) = UCase(zPassword)) Then
            subSendMsg "&ROH WOW WHAT IS WRONG WITH YOU??" & vbCrLf & "THINK HARD!!" & vbCrLf & "ITS PROBABLY A KID OR HAS A MENTAL DISORDER OR DRUNK OR SOMETHING!!" & vbCrLf & "TRY TO SILENCE OR CHANGE THE PERSONS PASSWORD FIRST!" & vbCrLf, zPortID
            lRoll = lRandom(cstRollMax)
            If (lRoll = cstRollMax) Then
                If (bNuke) Then
                    subShutdownPorts MyCStr(rsPlayer!PortID)
                    subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " was removed from the system.", zPortID
                    subDeleteMyselfForever "", MyCLng(rsPlayer!PlayerID)
                Else
                    subSendMsg "&R" & vbCrLf & "CALM DOWN!!! CALM DOWN!!!" & vbCrLf, zPortID
                    subSendMsg "&RTHIS PLAYER IS NUKE PROTECTED!!! YOU MUST DISABLE THIS FIRST!", zPortID
                    subSendMsg "&RDO NOT EVER NUKE SOMEONE JUST CHANGE THEIR PASSWORD OR SOMETHING!", zPortID
                    subSendMsg "&R" & vbCrLf & "CALM DOWN!!! CALM DOWN!!!" & vbCrLf, zPortID
                    subSendMsg "&gIMMO NUKE PLAYERNAME - toggles the player nuke status", zPortID
                End If
            Else
                subSendMsg "&R" & vbCrLf & vbCrLf & lRoll & " was not the required perfect " & cstRollMax & vbCrLf & vbCrLf, zPortID
                subSendMsg "&R" & vbCrLf & "Y O U  F A I L E D  Y O U R  N U K E  R O L L ! ! !" & vbCrLf, zPortID
                subSendMsg "&R" & vbCrLf & "CALM DOWN!!! CALM DOWN!!!" & vbCrLf, zPortID
                subSendMsg "&R" & vbCrLf & "CALM DOWN!!! CALM DOWN!!!" & vbCrLf, zPortID
                subSendMsg "&R" & vbCrLf & "Y O U  F A I L E D  Y O U R  N U K E  R O L L ! ! !" & vbCrLf, zPortID
            End If
        Else
            If (Len(zPassword) = 0) Then
                rsPlayer.Edit
                rsPlayer!NukeAllowed = (Not bNuke)
                rsPlayer.Update
                If (Not bNuke) Then
                    subSendMsg "&Y" & zPlayerName & " can now nuke at will.", zPortID
                Else
                    subSendMsg "&G" & zPlayerName & " can no longer nuke.", zPortID
                End If
                subSendMsg "&gIMMO NUKE PLAYERNAME - toggles the player nuke status", zPortID
            Else
                subSendMsg "&G" & zPlayerName & " password did not match." & vbCrLf & "&gIMMO NUKE PLAYERNAME PASSWORD", zPortID
            End If
        End If
    Else
        subSendMsg "&G" & zPlayerName & " was not found in the realm.", zPortID
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalNuke," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalForcesPlayersIgnore(zWord2 As String, zWord3 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zIPlayerName As String
    Dim lIPlayerID As Long
    Dim lTotalPlayers As Long
    Dim zSQL As String
    
    lIPlayerID = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (PlayerName='" & zWord2 & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lIPlayerID = MyCLng(rsPlayer!PlayerID)
        zIPlayerName = MyCStr(rsPlayer!PlayerName)
        subSendMsg "&GPlayer Name to be Ignored Found! ID:" & lIPlayerID & " Name:" & zIPlayerName, zPortID
    End If
    Set rsPlayer = Nothing
    
    If (lIPlayerID <> 0) Then
        lTotalPlayers = 0
        subSendMsg "&GAll the players in the realm no longer ignore " & zIPlayerName & ".", zPortID
        MyDB.Execute "DELETE PlayerIgnoredID FROM tblPlayerIgnoreCommand WHERE (PlayerIgnoredID=" & lIPlayerID & ");", dbFailOnError 'we stop everyone from ignoring this player
        If (Mid(UCase(zWord3), 1, 1) <> "C") Then 'clear only?
            Select Case Mid(UCase(zWord3), 1, 1)
                Case "A" 'All people in the realm will ignore this player
                    zSQL = "SELECT PlayerName, PlayerID FROM tblPlayer WHERE (PlayerID<>" & lIPlayerID & " AND PortID<>'" & zPortID & "');"
                Case Else
                    zSQL = "SELECT PlayerName, PlayerID FROM tblPlayer WHERE (PlayerID<>" & lIPlayerID & " AND PortID<>'" & zPortID & "' AND Len([PortID])>1 AND PortID<>'');"
            End Select
            Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                Do While (Not rsPlayer.EOF)
                    lTotalPlayers = lTotalPlayers + 1
                    'subSendMsg "&GPlayer Name: " & MyCStr(rsPlayer!PlayerName) & " ignores " & zIPlayerName & ". (this player was not informed of this)", zPortID
                    MyDB.Execute "INSERT INTO tblPlayerIgnoreCommand ( PlayerID, PlayerIgnoredID ) SELECT " & MyCLng(rsPlayer!PlayerID) & ", " & lIPlayerID & ";", dbFailOnError
                    rsPlayer.MoveNext
                Loop
                subSendMsg "&G" & lTotalPlayers & " players online have ignored " & zIPlayerName & "!" & vbCrLf & "You can still hear " & zIPlayerName & "! You will need to use the IGNORE command.", zPortID
            End If
            Set rsPlayer = Nothing
        End If
    Else
        If (Len(zWord2) <> 0) Then
            subSendMsg "&RPlayer Name: " & zWord2 & " not found in the realm.", zPortID
        Else
            subSendMsg "&gSyntax: IMMO IGNORE PLAYERNAME [O(default)/A/C]" & vbCrLf & "        IMMO IGNORE PLAYERNAME CLEAR" & vbCrLf & "        CLEAR - Will set it so all people in the realm will no longer ignore the player." & vbCrLf & "        IMMO IGNORE PLAYERNAME ALL" & vbCrLf & "        ALL - Will set it so all people in the realm will ignore the player." & vbCrLf & "        ONLINE - Will set it so all people online will ignore the player.", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalForcesPlayersIgnore," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subClearBountyLog(zPortID As String)
On Error Resume Next
    subSendMsg "&GBounty List Cleared!", zPortID
    MyDB.Execute "UPDATE tblMob SET DefeatedMobDesc = '';", dbFailOnError
End Sub
Public Sub subImmortalClanRename(zClanName1 As String, zClanName2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsClan1 As Recordset
    Dim rsClan2 As Recordset
    Dim bOkay As Boolean
    'zMsg = zDropFirstWordCleanLine(zPromptOriginal)
    
    bOkay = False
    
    Set rsClan1 = MyDB.OpenRecordset("SELECT ClanName FROM tblPlayerClan WHERE (ClanName='" & zClanName1 & "');", dbOpenSnapshot)
    If (Not rsClan1.EOF) Then
        bOkay = True
        subSendMsg "&GClan Name " & rsClan1!ClanName & " found!", zPortID
    Else
        subSendMsg "&gClan Name " & zClanName1 & " not found!", zPortID
    End If
    Set rsClan1 = Nothing
    
    Set rsClan2 = MyDB.OpenRecordset("SELECT ClanName FROM tblPlayerClan WHERE (ClanName='" & zClanName2 & "');", dbOpenSnapshot)
    If (Not rsClan2.EOF) Then
        bOkay = False
        subSendMsg "&gClan Name " & rsClan2!ClanName & " already exists!", zPortID
    Else
        subSendMsg "&GClan Name " & zClanName2 & " not found!", zPortID
    End If
    Set rsClan2 = Nothing
    
    If (bOkay) Then
        subSendMsg "&GRenaming Clan Name " & zClanName1 & " to " & zClanName2 & ".", zPortID
        Set rsClan1 = MyDB.OpenRecordset("SELECT ClanName FROM tblPlayerClan WHERE (ClanName='" & zClanName1 & "');", dbOpenDynaset)
        If (Not rsClan1.EOF) Then
            rsClan1.Edit
            rsClan1!ClanName = Mid(zClanName2, 1, 99)
            rsClan1.Update
            subSendMsg "&GClan Name " & rsClan1!ClanName & " modified!", zPortID
        Else
            subSendMsg "&RFailure: Clan Name " & zClanName1 & " not found (2nd attempt failed)!", zPortID
        End If
        Set rsClan1 = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalClanRename," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSQLSelectStatementResults(zLine As String, zPortID As String)
On Error GoTo Err_Check
    Dim MyRS As Recordset
    Dim lTotalResults As Long
    Dim lTotalFields As Long
    Dim lTotalFieldsStop As Long
    Dim zItem As String
    Dim iSpacer As Integer
    Dim lFieldsRead As Long
    Dim zSQL As String
    Dim fRS As Field
    
    'it would be nice to show a report and to stop the report after it counts past 100 lines of data
    zSQL = zLine
    If (UCase(Mid(zSQL, 1, 6)) = "SELECT" And Len(zSQL) > 9) Then
        subSendMsg "&w" & zSQL, zPortID
        lTotalResults = 0
        lTotalFields = 0
        
        Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        If (Not MyRS.EOF) Then
            MyRS.MoveLast
            lTotalResults = MyRS.RecordCount
            lTotalFields = MyRS.Fields.Count
            subSendMsg "&Greturned " & lTotalResults & " results and " & lTotalFields & " fields.", zPortID
            DoEvents
            If (lTotalFields < 1) Then lTotalFields = 1
            If (lTotalFields > 9) Then lTotalFields = 9 'this keeps the SELECT * with 200 field tables from lagging the mud
            
            iSpacer = (79 / lTotalFields)
            If (lTotalResults > 1 And lTotalFields > 0) Then 'we get the header information for the dynamic chart and multi-fields
                zItem = ""
                lTotalFieldsStop = lTotalFields
                For Each fRS In MyRS.Fields
                    lTotalFieldsStop = lTotalFieldsStop - 1
                    zItem = zItem & strForceSize(fRS.Name, iSpacer, " ", "A")
                    If (lTotalFieldsStop < 1) Then Exit For
                Next fRS
                
                subSendMsg "&W" & zItem & vbCrLf & "&w" & "-------------------------------------------------------------------------------", zPortID  'print the dynamic header
            End If
        End If
        Set MyRS = Nothing
        
        If (lTotalResults > 0 And lTotalFields > 0) Then
            lFieldsRead = lTotalResults
            Select Case lFieldsRead
                Case 1 'if its just one record we are getting we zoom in
                    subSendMsg gblzFNBLA, zPortID
                    Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                    If (Not MyRS.EOF) Then
                        For Each fRS In MyRS.Fields
                            Select Case fRS.Type
                                Case 10, 12 'string and memo fields we print below the field name/table variable
                                    zItem = fRS.Name & vbCrLf & fRS.Value
                                Case Else
                                    zItem = strForceSize(Mid(fRS.Name, 1, 50), 50, " ", "A") & " " & Mid(fRS.Value, 1, 29)
                            End Select
                            subSendMsg zItem, zPortID
                        Next fRS
                    Else
                        subSendMsg "&RSingle data record not found.", zPortID
                    End If
                    Set MyRS = Nothing
                Case Else 'we allow a maximum of 9 columns of data for multiple fields
                    'We now report the data
                    Select Case (InStr(UCase(zSQL), "SELECT TOP "))
                        Case 0 'the top code is not there so we place a max to it
                            If (lFieldsRead > 60) Then
                                lFieldsRead = 60
                                subSendMsg "Use SELECT TOP VALUE to exceed the " & lFieldsRead & " record maximum.", zPortID
                            End If
                            zSQL = "SELECT TOP " & lFieldsRead & Mid(zSQL, 7)
                    End Select
                    
                    Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                    Do While Not MyRS.EOF
                        zItem = ""
                        lTotalFieldsStop = lTotalFields
                        For Each fRS In MyRS.Fields
                            lTotalFieldsStop = lTotalFieldsStop - 1
                            zItem = zItem & strForceSize(fRS.Value, iSpacer, " ", "A")
                            If (lTotalFieldsStop < 1) Then Exit For
                        Next fRS
                        
                        subSendMsg "&a" & zItem, zPortID
                        MyRS.MoveNext
                    Loop
                    Set MyRS = Nothing
            End Select
        Else
            subSendMsg "&Areturned no results.", zPortID
        End If
    Else
        subSendMsg gblzFBRED & zSQL, zPortID
        subSendMsg "&RThis is not a valid select statement.", zPortID
    End If
    Exit Sub
Err_Check:
    subSendMsg "&RsubSQLSelectStatementResults," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCrLf & "Failed: " & zSQL, zPortID
End Sub
Public Sub subCreateWormHole(lPX As Long, lPY As Long, lPZ As Long, zX As String, zY As String, zZ As String, zPortID As String)
On Error GoTo Err_Check
    'Syntax: immo worm x y z
    Dim rsWormHole As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    lX = MyCLng(zX)
    lY = MyCLng(zY)
    lZ = MyCLng(zZ)
    
    If (Not bCheckAreaExists(zPortID, lX, lY, lZ, False)) Then
        If (Not bCheckDoorExists(zPortID, lX, lY, lZ)) Then
            subSendMsg "&RCreating wormhole...", zPortID
            Set rsWormHole = MyDB.OpenRecordset("tblAreaSpaceFlightEmote", dbOpenTable)
            rsWormHole.AddNew
            subSendMsg "&R                   Wormhole ID..." & MyCLng(rsWormHole!AreaSpaceFlightEmoteID), zPortID
            rsWormHole!ShellOrderFromSource = 1
            rsWormHole!ShellGroupCode = 32 + lRandom(999)
            rsWormHole!DStatus = 1
            rsWormHole!XS = lPX - 2
            rsWormHole!XE = lPX + 2
            rsWormHole!YS = lPY - 2
            rsWormHole!YE = lPY + 2
            rsWormHole!zS = lPZ - 2
            rsWormHole!zE = lPZ + 2
            rsWormHole!DX = lX
            rsWormHole!DY = lY
            rsWormHole!DZ = lZ
            rsWormHole!FlightDesc = "&rA wormhole flashes as you pilot through the vortex of analog energy."
            'rsWormHole!FlightDesc = "&rA wormhole flashes as you pilot through the vortex of analog energy.*(Water World detected at 0 -15000 0)*(wormhole entrance at 0 -16000 600)"
            rsWormHole.Update
            Set rsWormHole = Nothing
            subSendMsg "&GWormhole now connects [" & lPX & " " & lPY & " " & lPZ & "] to [dx" & lX & " y" & lY & " z" & lZ & "]", zPortID
            subSendMsg "&RNOTE: This is a one way wormhole, make it on the other end for a two way wormhole.", zPortID
        Else
            subSendMsg "&RFailed! Door detected.", zPortID
            subSendMsg "&gSYNTAX: IMMO WORM X Y Z" & vbCrLf & "Where you stand is the origin and x y z is the destination!", zPortID
        End If
    Else
        subSendMsg "&RFailed! Area detected.", zPortID
        subSendMsg "&gSYNTAX: IMMO WORM X Y Z" & vbCrLf & "Where you stand is the origin and x y z is the destination!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subTableShowFields," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRunSQL(zLine As String, zPortID As String)
On Error GoTo Err_Check
    Select Case UCase(Mid(zLine, 1, 3))
        Case "SQL", ""
            subSendMsg "&gYou cannot run this type of SQL statement: &g" & zLine, zPortID
            subSendMsg "&WEXAMPLES" & vbCrLf & "&a-------------------------------------------------------------------------------" _
                & vbCrLf & "&w" & "Add a Field to a Table" & vbCrLf & "&aALTER TABLE tblTableName ADD FieldName INTEGER;" _
                & vbCrLf & vbCrLf & "&w" & "Drop a Field from a Table" & vbCrLf & "&aALTER TABLE tblTableName DROP FieldName INTEGER;" _
                & vbCrLf & vbCrLf & "&w" & "Update Data in a Table" & vbCrLf & "&aUPDATE tblGameGuessWord SET GuessWord = 'TEST1' WHERE (GuessWord='TEST2');" _
                & vbCrLf & vbCrLf & "&w" & "Simple Select" & vbCrLf & "&aSELECT PlayerID FROM tblPlayer WHERE (PlayerLevel>100);" _
            , zPortID
            subSendMsg "&w2-Table 1-Conn Join" & vbCrLf & "&aSELECT tblPlayer.PlayerID FROM tblPlayer INNER JOIN tblWhere ON tblPlayer.WhereID = tblWhere.WhereID WHERE (((tblPlayer.PlayerLevel)>100));" _
                & vbCrLf & vbCrLf & "&w" & "2-Table 3-Conn Join" & vbCrLf & "&aSELECT tblPlayer.PlayerID FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X) WHERE (((tblPlayer.PlayerLevel)>100));" _
                & vbCrLf & vbCrLf & "&w" & "1-Table    Group by" & vbCrLf & "&aSELECT tblPlayer.PlayerLevel, Count(tblPlayer.PlayerLevel) AS CountOfPlayerLevel FROM tblPlayer GROUP BY tblPlayer.PlayerLevel ORDER BY tblPlayer.PlayerLevel DESC;" _
            , zPortID
            subSendMsg "&wInsert Into (APPEND)" & vbCrLf & "&aINSERT INTO tblPlayerScar(PlayerID) SELECT 1239;" _
            & vbCrLf & vbCrLf & "&w" & "3-Table 3-Conn Join" & vbCrLf & "&aSELECT tblPlayer.PlayerName, tblArea.AreaName, tblWhere.WhereTitle FROM tblPlayer INNER JOIN (tblArea INNER JOIN tblWhere ON tblArea.WhereID = tblWhere.WhereID) ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X);" _
            , zPortID
            subSendMsg "&gSYNTAX: IMMO SQL YOURSQLCODEHERE", zPortID
        Case "SEL" 'we send select statments to the reporter
            subSQLSelectStatementResults zLine, zPortID
        Case Else
            MyDB.Execute zLine, dbFailOnError
            subSendMsg "&GSuccess: &g" & zLine, zPortID
    End Select
    Exit Sub
Err_Check:
    subSendMsg "&RsubRunSQL," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCrLf & "Failed: " & zLine, zPortID
End Sub
Public Function oFieldNames(zTableName As String) As Collection
On Error GoTo Err_Check
    Dim oCol As Collection
    Dim oTD As TableDef 'DAO.TableDef
    Dim lCount As Long
    Dim lCtr As Long
    Dim zItem As String
    
    If (Len(zTableName) > 0) Then
        Set oTD = MyDB.TableDefs(zTableName)
        Set oCol = New Collection
        With oTD
            lCount = .Fields.Count
            For lCtr = 0 To lCount - 1
                zItem = .Fields(lCtr).Name
                zItem = strForceSize(zItem, 50, " ", "A") & " " & strForceSize(zTranslateFieldNumber(.Fields(lCtr).Type), 10, " ", "A") & " " & Mid(.Fields(lCtr).DefaultValue, 1, 17)
                oCol.Add zItem
            Next lCtr
        End With
        Set oFieldNames = oCol
        Set oTD = Nothing
    Else
        Set oFieldNames = Nothing
    End If
    Exit Function
Err_Check:
    Set oFieldNames = Nothing 'table name not found
    Set oTD = Nothing
    'subWriteErrorFile "oFieldNames," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subTableShowFields(zPortID As String, zTableName As String)
On Error GoTo Err_Check
    'Show all the field names in the table
    Dim vEachChar As Variant
    Dim oList As Collection
    Dim iFieldCount As Integer
    
    iFieldCount = 0
    subSendMsg "&GFIELDS IN TABLE " & UCase(zTableName) & vbCrLf & "&g------------------------------------------------------------", zPortID
    Set oList = oFieldNames(zTableName)
    If (Not oList Is Nothing) Then
        For Each vEachChar In oList
            iFieldCount = iFieldCount + 1
            subSendMsg CStr(vEachChar), zPortID
        Next
    End If
    
    If (iFieldCount = 0) Then
        subSendMsg "&gTable name not found or the table is empty of any fields." & vbCrLf & "SYNTAX: IMMO TABLE FIELD TABLENAME", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subTableShowFields," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function oTableNames() As Collection
On Error GoTo Err_Check
    Dim oCol As Collection
    Dim oTD As TableDef 'DAO.TableDef
    'finish this trisker
    'Set oTD = MyDB.TableDef
    Set oCol = New Collection
    
    For Each oTD In MyDB.TableDefs
        With oTD
            oCol.Add .Name
        End With
    Next
    Set oTableNames = oCol
    'Set oTD = Nothing
    Exit Function
Err_Check:
    Set oTableNames = Nothing 'table name not found
    Set oTD = Nothing
    'subWriteErrorFile "oTableNames," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subTableShowNames(zPortID As String)
On Error GoTo Err_Check
    'Show all the table names
    Dim vEachChar As Variant
    Dim oList As Collection
    Dim iFieldCount As Integer
    
    iFieldCount = 0
    subSendMsg "&GTABLE NAMES CURRENTLY IN THE DATABASE" & vbCrLf & "&g------------------------------------------------------------", zPortID
    Set oList = oTableNames()
    For Each vEachChar In oList
        iFieldCount = iFieldCount + 1
        subSendMsg CStr(vEachChar), zPortID
    Next
    
    If (iFieldCount = 0) Then
        subSendMsg "&gSYNTAX: IMMO TABLE FIELD TABLENAME        - lists all the fields in the table" & vbCrLf & "        IMMO TABLE                        - lists all the tables", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subTableShowNames," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subFindReplaceMemoTextDb(zPortID As String, zPromptOriginal As String, bFindOnly As Boolean)
On Error GoTo Err_Check
    'Show all the table names
    Const cstMaxFinds = 50
    Dim MyRS As Recordset
    Dim vEachChar As Variant
    Dim oList As Collection
    Dim iFieldCount As Integer
    Dim zSQL As String
    Dim zItem As String
    Dim fRS As Field
    Dim zPrimaryKey As String
    Dim zPrimaryValue As String
    Dim bPrimaryKey As Boolean
    Dim bContinue As Boolean
    Dim lStopAt As Long
    Dim zTableName As String
    Dim zCleanLine As String
    Dim zWord1 As String
    Dim zWord2 As String
    
    zCleanLine = zDropFirstWordCleanLine(zPromptOriginal) 'this drops the REPLACE command
    zWord1 = Mid(zCleanLine, 1, InStr(zCleanLine & " ", " ") - 1) 'get the search word
    zCleanLine = zDropFirstWordCleanLine(zCleanLine)
    zWord2 = Mid(zCleanLine, 1, InStr(zCleanLine & " ", " ") - 1)
    
    iFieldCount = 0
    
    bContinue = (Len(zWord2) > 0 Or bFindOnly)
    If (bContinue) Then
        gblbTiming = True 'turns off the timers
        lStopAt = 0
        Select Case bFindOnly
            Case True
                subSendMsg "&a" & cstMaxFinds & " FIND -> " & zWord1 & vbCrLf & "&w" & "------------------------------------------------------------", zPortID
            Case False
                subSendMsg "&a" & cstMaxFinds & " SEARCH " & zWord1 & " AND REPLACE WITH " & zWord2 & vbCrLf & "&w" & "------------------------------------------------------------", zPortID
        End Select
        subSendMsg "&A(skipped tables: tblGameGuessWord, tblSystemHelp, tblSystemAsciiPix)" & vbCrLf & "&w" & "------------------------------------------------------------", zPortID
        Set oList = oTableNames()
        For Each vEachChar In oList
            zTableName = vEachChar
            If (zTableName <> "tblSystemAsciiPix" And zTableName <> "tblGameGuessWord" And zTableName <> "tblSystemHelp") Then 'We skip the dictionary and the massive help file
                iFieldCount = iFieldCount + 1
                If (UCase(Mid(zTableName, 1, 3)) = "TBL") Then
                    subSendMsg " - " & zTableName & " - ", zPortID
                    DoEvents
                    'Begin Find and Replace
                    zSQL = "SELECT * FROM " & zTableName & ";"
                    Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                    Do While (Not MyRS.EOF And lStopAt < cstMaxFinds)
                        'Search for the primary key
                        bPrimaryKey = False
                        For Each fRS In MyRS.Fields
                            If (Len(fRS.Name) > 2 And Len(fRS.Value) > 0) Then
                                Select Case fRS.Type
                                    Case 4 'autonumber or long
                                        'We search this value
                                        If (UCase(Mid(MyCStr(fRS.Name), Len(fRS.Name) - 1)) = "ID") Then 'probably a primary key id
                                            zPrimaryKey = MyCStr(fRS.Name)
                                            zPrimaryValue = MyCStr(fRS.Value)
                                            If (lngSQLRecordCount("SELECT " & zPrimaryKey & " FROM " & zTableName & " WHERE " & zPrimaryKey & " = " & zPrimaryValue & ";") = 1) Then 'there is only one occurance of this ID and number it must be unique somehow
                                                bPrimaryKey = True
                                                Exit For
                                            End If 'else we continue checking the row for a primary key
                                        End If
                                End Select
                            End If
                        Next fRS
                        
                        If (bPrimaryKey) Then
                            For Each fRS In MyRS.Fields
                                If (Not IsNull(fRS.Value)) Then
                                    Select Case fRS.Type
                                        Case 10, 12 'string/memo
                                            zItem = fRS.Value
                                            'We search this value
                                            If (InStr(zItem, zWord1) > 0) Then
                                                If (Not bFindOnly) Then zItem = strReplaceWordWithThisWord(zItem, zWord1, zWord2, False)
                                                zSQL = "UPDATE " & zTableName & " SET " & fRS.Name & "=""" & zItem & """ WHERE " & zPrimaryKey & " = " & zPrimaryValue & ";"
                                                subSendMsg "          " & fRS.Type & " " & vbCrLf & zSQL, zPortID
                                                If (Not bFindOnly) Then subRunSQL zSQL, zPortID
                                                lStopAt = lStopAt + 1
                                            End If
                                    End Select
                                End If
                            Next fRS
                        End If
                        MyRS.MoveNext
                    Loop
                    Set MyRS = Nothing
                    If (lStopAt >= cstMaxFinds) Then subSendMsg "&RStopped at the set limit of " & cstMaxFinds & " finds.", zPortID
                    DoEvents
                End If
            End If
            If (lStopAt >= cstMaxFinds) Then Exit For
        Next
    End If
    If (iFieldCount = 0) Then
        subSendMsg "&gSYNTAX: IMMO FIND THEWORD" & vbCrLf & "IMMO REPLACE OLDWORD NEWWORD", zPortID
    End If
    gblbTiming = False 'turns on the timers
    Exit Sub
Err_Check:
    gblbTiming = False 'turns on the timers
    subWriteErrorFile "subSearchMemoTextDb," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subVoidMobs(zBRINGTOIMMOXYZ As String, lPX As Long, lPY As Long, lPZ As Long, zPortID As String)
    Dim rsArea As Recordset
    Dim rsMob As Recordset
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMVoid As Long
    Dim lID As Long
    Dim zName As String
    
    lMVoid = 0
    subSendMsg "&Y" & "SCANNING FOR MOBILES IN THE VOID", zPortID
    Set rsMob = MyDB.OpenRecordset("SELECT MobID, MobName, X, Y, Z, RespawnX, RespawnY, RespawnZ FROM tblMob;", dbOpenSnapshot)
    Do While (Not rsMob.EOF)
        lID = MyCLng(rsMob!MobID)
        zName = MyCStr(rsMob!MobName)
        lMX = MyCLng(rsMob!x)
        lMY = MyCLng(rsMob!y)
        lMZ = MyCLng(rsMob!z)
        Set rsArea = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z FROM tblArea WHERE X=" & lMX & " AND Y=" & lMY & " AND Z=" & lMZ & ";", dbOpenSnapshot)
        If (rsArea.EOF) Then
            lMVoid = lMVoid + 1
            subSendMsg "&Y" & "Void**" & zShortstop(zName) & "[" & lID & "] @ (" & lMX & ", " & lMY & ", " & lMZ & ")", zPortID
            If (Mid(zBRINGTOIMMOXYZ, 1, 4) = "BRIN") Then MyDB.Execute "UPDATE tblMob SET MobLevel=35, MobAutoAttacks=False, X=" & lPX & ", Y=" & lPY & ", Z=" & lPZ & ", RespawnX=" & lPX & ", RespawnY=" & lPY & ", RespawnZ=" & lPZ & " WHERE MobID=" & lID & ";", dbFailOnError
        End If
        Set rsArea = Nothing
        rsMob.MoveNext
    Loop
    Set rsMob = Nothing
    subSendMsg "&Y" & "TOTAL Void Mobs (" & lMVoid & ")", zPortID
    Set rsMob = Nothing
End Sub

Public Sub subVoidObjects(zBRINGTOIMMOXYZ As String, lPX As Long, lPY As Long, lPZ As Long, zPortID As String)
    Dim rsArea As Recordset
    Dim rsObj As Recordset
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lOStatus As Long
    Dim lOLoc As Long
    Dim lOVoid As Long
    Dim lID As Long
    Dim zName As String
    
    lOVoid = 0
    subSendMsg "&Y" & "SCANNING FOR OBJECTS IN THE VOID", zPortID
    Set rsObj = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, X, Y, Z, Status, Location FROM tblObject WHERE Status=0;", dbOpenSnapshot)
    Do While (Not rsObj.EOF)
        lID = MyCLng(rsObj!ObjectID)
        zName = MyCStr(rsObj!ObjectName)
        lOX = MyCLng(rsObj!x)
        lOY = MyCLng(rsObj!y)
        lOZ = MyCLng(rsObj!z)
        lOStatus = MyCLng(rsObj!Status)
        lOLoc = MyCLng(rsObj!Location)
        Set rsArea = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z FROM tblArea WHERE X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ";", dbOpenSnapshot)
        If (rsArea.EOF) Then
            lOVoid = lOVoid + 1
            If (Mid(zBRINGTOIMMOXYZ, 1, 4) = "BRIN") Then MyDB.Execute "UPDATE tblObject SET X=" & lPX & ", Y=" & lPY & ", Z=" & lPZ & " WHERE ObjectID=" & lID & ";", dbFailOnError
            subSendMsg "&Y" & "Void**" & Mid(zShortstop(zName), 1, 10) & "[" & lID & "] @ (" & lOX & ", " & lOY & ", " & lOZ & ") St(" & lOStatus & ") Loc(" & lOLoc & ")", zPortID
        End If
        Set rsArea = Nothing
        rsObj.MoveNext
    Loop
    Set rsObj = Nothing
    subSendMsg "&Y" & "TOTAL Void Obj (" & lOVoid & ")", zPortID
    Set rsObj = Nothing
End Sub

Public Sub subOrphanedObjects(lPX As Long, lPY As Long, lPZ As Long, zPortID As String) 'These are objects wtih no playerlink but status = 2, no mob link but status = 1, not burried, no quest link, no give quest link, has no container anymore but status=3
    Dim rsTest As Recordset
    Dim rsObj As Recordset
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lOStatus As Long
    Dim lOLoc As Long
    Dim lOBurried As Long
    Dim lOOrphaned As Long
    Dim lOID As Long
    Dim zOName As String
    Dim bOrphaned As Boolean
    Dim bPlayer As Boolean
    Dim bContainer As Boolean
    
    bOrphaned = False: lOOrphaned = 0
    subSendMsg "&Y" & "SCANNING FOR ORPHANED OBJECTS", zPortID
    Set rsObj = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, X, Y, Z, Burried, Status, Location WHERE Burried=False FROM tblObject;", dbOpenSnapshot) 'we ignore burried objects
    If (Not rsObj.EOF) Then
        lOID = MyCLng(rsObj!ObjectID)
        zOName = MyCStr(rsObj!ObjectName)
        lOX = MyCLng(rsObj!x)
        lOY = MyCLng(rsObj!y)
        lOZ = MyCLng(rsObj!z)
        lOBurried = MyCLng(rsObj!Burried)
        lOStatus = MyCLng(rsObj!Status)
        lOLoc = MyCLng(rsObj!Location)
        'Is the Object with a Player?
        bPlayer = True
        Set rsTest = MyDB.OpenRecordset("SELECT ObjectName, X, Y, Z, Burried, Status, Location, PlayerID FROM tblObject WHERE (PlayerID<>0);", dbOpenSnapshot)
        If (rsTest.EOF) Then
            bPlayer = False
            lOOrphaned = lOOrphaned + 1
        End If
        Set rsTest = Nothing
        
        'Is the Object in a Container?
        bContainer = True
        If (lOStatus = 3) Then
            Set rsTest = MyDB.OpenRecordset("SELECT ObjectName, X, Y, Z, Burried, Status, Location, PlayerID FROM tblObject WHERE (Status=3);", dbOpenSnapshot)
            If (rsTest.EOF) Then
                bContainer = False
                lOOrphaned = lOOrphaned + 1
            End If
            Set rsTest = Nothing
        End If
        
        bOrphaned = (Not bPlayer And Not bContainer)
        If (bOrphaned) Then subSendMsg "&Y" & "Orphaned**" & zOName & "[" & lOID & "] @ (" & lOX & ", " & lOY & ", " & lOZ & ") Status(" & lOStatus & ") Location(" & lOLoc & ") Burried(" & lOBurried & ")", zPortID
    End If
    
    subSendMsg "&Y" & "TOTAL Orphaned Obj (" & lOOrphaned & ")", zPortID
    Set rsObj = Nothing
End Sub

Private Sub subSetSettingsConfigImmortalNames(zName As String, iValue As Integer, zPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("tblSystemConfig", dbOpenTable)
    If (Not rsData.EOF) Then
        rsData.Edit
        Select Case iValue
            Case 1
                rsData!ImmortalName1 = Mid(MyCStr(zName), 1, 15)
                gblzImmortalName1 = Mid(MyCStr(zName), 1, 15)
            Case 2
                gblzImmortalName2 = Mid(MyCStr(zName), 1, 15)
                rsData!ImmortalName2 = Mid(MyCStr(zName), 1, 15)
            Case 3
                gblzImmortalName3 = Mid(MyCStr(zName), 1, 15)
                rsData!ImmortalName3 = Mid(MyCStr(zName), 1, 15)
            Case 4
                gblzImmortalName4 = Mid(MyCStr(zName), 1, 15)
                rsData!ImmortalName4 = Mid(MyCStr(zName), 1, 15)
        End Select
        rsData.Update
    Else
        rsData.AddNew
        rsData!ImmortalName1 = Mid(MyCStr(zName), 1, 15)
        rsData.Update
    End If
    Set rsData = Nothing
    subSendMsg "&GImmortal Name " & iValue & " [" & Mid(MyCStr(zName), 1, 15) & "] Updated!", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetSettingsConfigImmortalNames," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subSetSettingsConfigEmail(zImmyEmail As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("tblSystemConfig", dbOpenTable)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!MailFromAddy = Mid(MyCStr(zImmyEmail), 1, 65)
        rsData.Update
    Else
        rsData.AddNew
        rsData!MailFromAddy = Mid(MyCStr(zImmyEmail), 1, 65)
        rsData.Update
    End If
    Set rsData = Nothing
    gblzImmortalEmail = Mid(MyCStr(zImmyEmail), 1, 65)
    subSendMsg "&GImmortal Email Address [" & Mid(MyCStr(zImmyEmail), 1, 65) & "] Updated!", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetSettingsConfigEmail," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subSetSettingsConfigHomepage(zImmyHomePage As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("tblSystemConfig", dbOpenTable)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!HomePageURL = Mid(MyCStr(zImmyHomePage), 1, 65)
        rsData.Update
    Else
        rsData.AddNew
        rsData!HomePageURL = Mid(MyCStr(zImmyHomePage), 1, 65)
        rsData.Update
    End If
    Set rsData = Nothing
    gblzMUDHomePageURL = Mid(MyCStr(zImmyHomePage), 1, 65)
    subSendMsg "&GImmortal Homepage URL [" & Mid(MyCStr(zImmyHomePage), 1, 65) & "] Updated!", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetSettingsConfigHomepage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subSetSettingsConfigMUDName(zImmyMUDName As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("tblSystemConfig", dbOpenTable)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!HomePageURL = Mid(MyCStr(zImmyMUDName), 1, 65)
        rsData.Update
    Else
        rsData.AddNew
        rsData!HomePageURL = Mid(MyCStr(zImmyMUDName), 1, 65)
        rsData.Update
    End If
    Set rsData = Nothing
    gblzMUDName = Mid(MyCStr(zImmyMUDName), 1, 65)
    subSendMsg "&GImmortal MUD Name [" & Mid(MyCStr(zImmyMUDName), 1, 65) & "] Updated!", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetSettingsConfigMUDName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subSetSettingsConfigMUDTelnet(zImmyTelnetName As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("tblSystemConfig", dbOpenTable)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!MUDTelnetURL = Mid(MyCStr(zImmyTelnetName), 1, 65)
        rsData.Update
    Else
        rsData.AddNew
        rsData!MUDTelnetURL = Mid(MyCStr(zImmyTelnetName), 1, 65)
        rsData.Update
    End If
    Set rsData = Nothing
    gblzMUDTelnetURL = Mid(MyCStr(zImmyTelnetName), 1, 65)
    subSendMsg "&GImmortal TELNET [" & Mid(MyCStr(zImmyTelnetName), 1, 65) & "] Updated!", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetSettingsConfigMUDTelnet," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subCreatePlayerHouse(zPortID As String, zWord2 As String)
    'get immortal XYZ location, get PlayerName as zWord2, check area to make sure it exists and doesnt have a tagstatus like house or starship
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lIX As Long
    Dim lIY As Long
    Dim lIZ As Long
    Dim lAID As Long
    Dim lPT As Long
    Dim lPID As Long
    Dim zPN As String
    Dim lStatus As Long
    Dim bImmortalFound As Boolean
    Dim bPlayerFound As Boolean
    Dim bUndoHouse As Boolean
    
    bUndoHouse = (Len(MyCStr(zWord2)) = 0)
    
    'immortal info.
    bImmortalFound = False
    Set rsData = MyDB.OpenRecordset("SELECT PlayerID, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset) 'get immortal location
    If (Not rsData.EOF) Then
        bImmortalFound = True
        lIX = MyCLng(rsData!x)
        lIY = MyCLng(rsData!y)
        lIZ = MyCLng(rsData!z)
    End If
    Set rsData = Nothing
    
    lStatus = 1
    If (bImmortalFound) Then
        If (Not bUndoHouse) Then
        
            'Player target
            lPID = 0
            Set rsData = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (Ucase(PlayerName)='" & UCase(zWord2) & "');", dbOpenDynaset) 'get the player info. to create the house
            If (Not rsData.EOF) Then
                lPID = MyCLng(rsData!PlayerID)
                zPN = MyCStr(rsData!PlayerName)
            End If
            Set rsData = Nothing
            
            If (lPID <> 0) Then 'Player name found? Yes, then cont...
                'Area
                If (Not bCheckAreaExists(zPortID, lIX, lIY, lIZ, True)) Then
                    MyDB.Execute "INSERT INTO tblArea ( AreaName, X, Y, Z ) SELECT 'New Area now use, IMMO RN/RDD/RDN/WAPP commands.', " & lIX & ", " & lIY & ", " & lIZ & ";", dbFailOnError 'create the area
                    subSendMsg "&GArea [x" & lIX & " y" & lIY & " z" & lIZ & "] created!", zPortID
                End If
                lPT = 0
                Set rsData = MyDB.OpenRecordset("SELECT AreaID, PlayerType FROM tblArea WHERE (X=" & lIX & " AND Y=" & lIY & " AND Z=" & lIZ & ");", dbOpenDynaset) 'get the area information and playertype of that area - 1=house this must be zero
                If (Not rsData.EOF) Then
                    lAID = MyCLng(rsData!AreaID)
                    lPT = MyCLng(rsData!PlayerType)
                End If
                Set rsData = Nothing
            
                'Put it all together
                If (lPT = 0 Or lPT = 1) Then 'if its already a house or a normal standard area then continue...
                    subSendMsg "&GSetting up a House in Area @ [x" & lIX & " y" & lIY & " z" & lIZ & "]", zPortID
                    MyDB.Execute "UPDATE tblArea SET PlayerID=" & lPID & ", PlayerType=1 WHERE AreaID=" & lAID & ";", dbFailOnError
                    subSendMsg "&GFinished successfully, enjoy!", zPortID
                    lStatus = 0
                Else
                    subSendMsg "&rArea [x" & lIX & " y" & lIY & " z" & lIZ & "] has an area type that is already set, it is not possible to continue." & vbCrLf & "Use IMMO TYPE command to clear this area, not recommended but still safe to use.", zPortID
                End If
            Else
                subSendMsg "&RPlayer Name [" & zWord2 & "] was not found in the system.", zPortID
            End If
        Else
            lPT = 0
            Set rsData = MyDB.OpenRecordset("SELECT AreaID, PlayerType FROM tblArea WHERE (X=" & lIX & " AND Y=" & lIY & " AND Z=" & lIZ & ");", dbOpenDynaset) 'get the area information and playertype of that area - 1=house this must be zero
            If (Not rsData.EOF) Then
                lAID = MyCLng(rsData!AreaID)
                lPT = MyCLng(rsData!PlayerType)
            End If
            Set rsData = Nothing
            If (lPT = 1) Then
                MyDB.Execute "UPDATE tblArea SET PlayerID=0, PlayerType=0 WHERE AreaID = " & MyCStr(lAID) & ";", dbFailOnError
                subSendMsg "&GArea [x" & lIX & " y" & lIY & " z" & lIZ & "] is no longer a house but a normal area.", zPortID
                lStatus = 0
            End If
        End If
    End If
    
    Select Case lStatus
        Case 1
            subSendMsg "&gSYNTAX: IMMO HOUSE <playername>" & vbCrLf & "        IMMO HOUSE sets safely a house back to a normal area, same as IMMO TYPE", zPortID
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subCreatePlayerHouse," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlantAThiefChestOfGlory(lChance As Long)
    Dim rsQuestArea As Recordset 'THIEF CHEST OF GLORY
    Dim zMobName As String
    Dim lTotalResult As Long
    Dim lThiefMobID As Long
    Dim lThiefMobX As Long
    Dim lThiefMobY As Long
    Dim lThiefMobZ As Long
    Dim lTotalArea As Long
    Dim lQWhereID As Long
    Dim lQAreaID As Long
    Dim lQAX As Long
    Dim lQAY As Long
    Dim lQAZ As Long
    Dim bOkay As Boolean
    
    If (lRandom(lChance) = 1) Then
        lThiefMobID = 0
        'Find a Mob in the Area make them the thief
        lTotalResult = lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (Z=-4 or Z=-2 or Z=0 or Z=2 or Z=4) AND (Questable=True AND RespawnDelay=0);") 'find a mob where a noobie most likely has a chance to find it
        Set rsQuestArea = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalResult) & " MobID, MobName, X, Y, Z FROM tblMob WHERE (Z=-4 or Z=-2 or Z=0 or Z=2 or Z=4) AND (RespawnDelay=0);", dbOpenSnapshot)
        If (Not rsQuestArea.EOF) Then
            rsQuestArea.MoveLast
            bOkay = False
            Do While (Not rsQuestArea.BOF And Not bOkay)
                zMobName = MyCStr(rsQuestArea!MobName)
                lThiefMobID = MyCLng(rsQuestArea!MobID)
                lThiefMobX = MyCLng(rsQuestArea!x)
                lThiefMobY = MyCLng(rsQuestArea!y)
                lThiefMobZ = MyCLng(rsQuestArea!z)
                lQAZ = MyCLng(rsQuestArea!z)
                bOkay = (bEven(lQAZ))
                rsQuestArea.MovePrevious
            Loop
        End If
        Set rsQuestArea = Nothing
        
        If (lThiefMobID <> 0) Then
            lQAreaID = 0
            bOkay = False
            'Find the Area around this Thief 'PlayerID=0 AND PlayerType=0 AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0
            lTotalResult = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (X>" & lThiefMobX - 21 & " AND Y>" & lThiefMobY - 21 & " AND Z>" & lThiefMobZ - 5 & " AND X<" & lThiefMobX + 21 & " AND Y<" & lThiefMobY + 21 & " AND Z<" & lThiefMobZ + 5 & " AND Mid([AreaRules],11,1) = '1' AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0);")
            Set rsQuestArea = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalResult) & " AreaID, WhereID, X, Y, Z FROM tblArea WHERE (X>" & lThiefMobX - 21 & " AND Y>" & lThiefMobY - 21 & " AND Z>" & lThiefMobZ - 5 & " AND X<" & lThiefMobX + 21 & " AND Y<" & lThiefMobY + 21 & " AND Z<" & lThiefMobZ + 5 & " AND Mid([AreaRules],11,1) = '1' AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0);", dbOpenSnapshot)
            If (Not rsQuestArea.EOF) Then
                rsQuestArea.MoveLast
                Do While (Not rsQuestArea.BOF And Not bOkay)
                    lQWhereID = MyCLng(rsQuestArea!WhereID)
                    lQAreaID = MyCLng(rsQuestArea!AreaID)
                    lQAX = MyCLng(rsQuestArea!x)
                    lQAY = MyCLng(rsQuestArea!y)
                    lQAZ = MyCLng(rsQuestArea!z)
                    bOkay = (bEven(lQAZ))
                    rsQuestArea.MovePrevious
                Loop
            End If
            Set rsQuestArea = Nothing
             
            If (bOkay And lQAreaID <> 0) Then
                'Make the Quest
                lTotalArea = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (WhereID=" & lQWhereID & ");")
                MyDB.Execute "UPDATE tblArea SET ThiefMobID=" & lThiefMobID & ", ThiefChestOfGlory=" & lRandom(3) + MyCLng(lTotalArea / 10) + lRandom(lReturnMobLevel(lThiefMobID) / 8) + 2 & " WHERE (AreaID=" & lQAreaID & ");", dbFailOnError
                subSimpleQuestChannel "&GUNKNOWN THIEF &Y[&yhid&Y] &GMASSIVE CHEST &Y[&y" & zWhereID(lQWhereID) & "&Y]"
            'Else 'the next part means something failed to make the quest work.
            '    subSendMsgInfoChannel "&M" & zMobName & " &wjust saw one of the realm thiefs go by--couldnot find a hiding spot and left, go figure!"
            End If
        End If
    End If
End Sub
Public Function lReturnONEGloryXYZObjectID(lX As Long, lY As Long, lZ As Long) As Long
On Error GoTo Err_Check
    Dim rsGO As Recordset
    Dim lObjectID As Long
    lObjectID = 0
    Set rsGO = MyDB.OpenRecordset("SELECT ObjectID FROM tblObject WHERE (Location<>0 AND QuestForGlory<>0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    If (Not rsGO.EOF) Then
        lObjectID = MyCLng(rsGO!ObjectID)
    End If
    Set rsGO = Nothing
    lReturnONEGloryXYZObjectID = lObjectID
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnONEGloryXYZObjectID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subSeeIfWePlantAGloryItem(lChance As Long)
On Error GoTo Err_Check
    Dim lTotalArea As Long
    Dim lQAX As Long
    Dim lQAY As Long
    Dim lQAZ As Long
    Dim bOkay As Boolean
    Dim zObjectFullName As String
    Dim rsQuestArea As Recordset
    Dim lQuestForGlory As Long
    Dim lLocation As Long
    Dim lGold As Long
    Dim lBonusXP As Long
    Dim zColourDesc As String
    Dim lQWhereID As Long
    Dim lQAreaID As Long
    
    If (lRandom(lChance) = 1) Then
        If (lngSQLRecordCount("SELECT PlayerID FROM tblPlayer WHERE (Len([PortID])>1);") > 0) Then 'any player online?
            bOkay = False
            lTotalArea = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (Mid([AreaRules],11,1) = '1' AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0);")
            Set rsQuestArea = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalArea) & " AreaID, WhereID, X, Y, Z FROM tblArea WHERE (Mid([AreaRules],11,1) = '1' AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0);", dbOpenSnapshot)
            If (Not rsQuestArea.EOF) Then
                rsQuestArea.MoveLast
                Do While (Not rsQuestArea.BOF And Not bOkay)
                    lQWhereID = MyCLng(rsQuestArea!WhereID)
                    lQAreaID = MyCLng(rsQuestArea!AreaID)
                    lQAX = MyCLng(rsQuestArea!x)
                    lQAY = MyCLng(rsQuestArea!y)
                    lQAZ = MyCLng(rsQuestArea!z)
                    bOkay = (bEven(lQAZ))
                    rsQuestArea.MovePrevious
                Loop
            End If
            Set rsQuestArea = Nothing
            
            If (bOkay) Then
                zColourDesc = ""
                Select Case lRandom(20)
                    Case 1
                        zColourDesc = " green "
                    Case 2
                        zColourDesc = " blue "
                    Case 3
                        zColourDesc = " purple "
                    Case 4
                        zColourDesc = " yellow "
                    Case 5
                        zColourDesc = " pink "
                    Case 6
                        zColourDesc = " red "
                    Case 7
                        zColourDesc = " white "
                    Case 8
                        zColourDesc = " black "
                    Case 9
                        zColourDesc = " brown "
                    Case 10
                        zColourDesc = " silver "
                    Case 11
                        zColourDesc = " gold "
                    Case 12
                        zColourDesc = " smokey "
                    Case 13
                        zColourDesc = " cyan "
                    Case 14
                        zColourDesc = " crystal "
                    Case 15
                        zColourDesc = " emerald "
                End Select
                        
                zObjectFullName = ""
                
                Select Case lRandom(23)
                    Case 1
                        zObjectFullName = zObjectFullName & zColourDesc & "stone of the gods"
                    Case 2
                        zObjectFullName = zObjectFullName & zColourDesc & "insignia buckle of the gods"
                    Case 3
                        zObjectFullName = zObjectFullName & zColourDesc & "ribbon of the gods"
                    Case 4
                        zObjectFullName = zObjectFullName & "fluffy piece of a cloud"
                    Case 5
                        zObjectFullName = zObjectFullName & "quark from the beginning of time"
                    Case 6
                        zObjectFullName = zObjectFullName & "glueon from the beginning of time"
                    Case 7
                        zObjectFullName = zObjectFullName & "piece of " & MyCStr(zColourDesc & "quartz")
                    Case 8
                        zObjectFullName = zObjectFullName & zColourDesc & "key"
                    Case 9
                        zObjectFullName = zObjectFullName & zColourDesc & "dagger"
                    Case 10
                        zObjectFullName = zObjectFullName & zColourDesc & "sword"
                    Case 11
                        zObjectFullName = zObjectFullName & zColourDesc & "mace"
                    Case 12
                        zObjectFullName = zObjectFullName & zColourDesc & "claw"
                    Case 13
                        zObjectFullName = zObjectFullName & zColourDesc & "hat"
                    Case 14
                        Select Case lRandom(11) 'Legends of the realm
                            Case 1
                                zObjectFullName = zObjectFullName & "single strand of hair from CHAOS"
                            Case 2
                                zObjectFullName = zObjectFullName & "single strand of hair from ORDER"
                            Case 3
                                zObjectFullName = zObjectFullName & "single strand of hair from DEATH"
                            Case 4
                                zObjectFullName = zObjectFullName & "single strand of hair from Draegar"
                            Case 5
                                zObjectFullName = zObjectFullName & "single strand of hair from Rangek"
                            Case 6
                                zObjectFullName = zObjectFullName & "single strand of hair from Trisker"
                            Case 7
                                zObjectFullName = zObjectFullName & "single strand of hair from Eternal"
                            Case 8
                                zObjectFullName = zObjectFullName & "single strand of hair from Lanos"
                            Case 9
                                zObjectFullName = zObjectFullName & "single strand of hair from Ratnas"
                            Case 10
                                zObjectFullName = zObjectFullName & "single strand of hair from Jabber"
                            Case 11
                                zObjectFullName = zObjectFullName & "single strand of hair from Gromit"
                        End Select
                    Case 15
                        zObjectFullName = zObjectFullName & zColourDesc & "carpet"
                    Case 16
                        zObjectFullName = zObjectFullName & zColourDesc & "lamp"
                    Case 17
                        zObjectFullName = zObjectFullName & zColourDesc & "dagger"
                    Case 18
                        zObjectFullName = zObjectFullName & zColourDesc & "sword"
                    Case 19
                        zObjectFullName = zObjectFullName & zColourDesc & "carbonite"
                    Case 20
                        zObjectFullName = zObjectFullName & zColourDesc & "element"
                    Case Else
                        zObjectFullName = zObjectFullName & zColourDesc & "bow tie of the gods"
                End Select
                
                Select Case lRandom(21)
                    Case 1
                        zObjectFullName = zObjectFullName & ", is translucent" & zColourDesc
                    Case 2
                        zObjectFullName = zObjectFullName & ", is lost"
                    Case 3
                        zObjectFullName = zObjectFullName & ", is missing"
                    Case 4
                        zObjectFullName = zObjectFullName & ", fell from the heavens"
                    Case 5
                        zObjectFullName = zObjectFullName & ", glows " & MyCStr(zColourDesc & "here")
                    Case 6
                        zObjectFullName = zObjectFullName & ", pulsates"
                    Case 7
                        zObjectFullName = zObjectFullName & ", rests here on the ground"
                    Case 8
                        zObjectFullName = zObjectFullName & ", is a godly item"
                    Case 9
                        zObjectFullName = zObjectFullName & ", is embedded in the ground"
                    Case 10
                        zObjectFullName = zObjectFullName & ", is laying on its side"
                    Case 11
                        zObjectFullName = zObjectFullName & ", is a rainbow of colours"
                    Case 12
                        zObjectFullName = zObjectFullName & ", has a green flashing light"
                    Case 13
                        zObjectFullName = zObjectFullName & ", has a purple flashing light"
                    Case 14
                        zObjectFullName = zObjectFullName & ", has a blue flashing light"
                    Case 15
                        zObjectFullName = zObjectFullName & ", has a yellow flashing light"
                    Case 16
                        zObjectFullName = zObjectFullName & ", has a golden symbol of the newt"
                    Case 17
                        zObjectFullName = zObjectFullName & ", has a platinum newt insignia"
                    Case 18
                        zObjectFullName = zObjectFullName & ", has a silvery symbol of the bear"
                    Case 19
                        zObjectFullName = zObjectFullName & ", has a claw mark over its surface"
                    Case 20
                        zObjectFullName = zObjectFullName & ", has bits of jewelery over its surface"
                    Case Else
                        zObjectFullName = zObjectFullName & ", is laying on the ground here"
                End Select
                
                zObjectFullName = MyCStr(zObjectFullName)
                lGold = 0
                lBonusXP = 0
                lQuestForGlory = 1
                Select Case lRandom(3)
                    Case 1
                        lLocation = 120
                        lGold = lRandom(150) + 100
                        If (lRandom(3) = 1) Then
                            lQuestForGlory = lQuestForGlory + 1
                            lGold = lGold + lRandom(200) + 500
                        End If
                    Case Else
                        lLocation = 121
                        lBonusXP = lRandom(2000) + 1000
                        If (lRandom(3) = 1) Then
                            lQuestForGlory = lQuestForGlory + 1
                            lBonusXP = lBonusXP + lRandom(2200) + 2000
                        End If
                End Select
                'If (lRandom(5) = 1) Then lQuestForGlory = lQuestForGlory + lRandom(2) 'chance to make it a glory item
                'We got the location now we need to make the glory item
                MyDB.Execute "INSERT INTO tblObject ( GroundTimer, GroundTimerNotAvailable, ObjectName, QuestRespawnX, QuestRespawnY, QuestRespawnZ, X, Y, Z, QuestForGlory, BonusXP, Gold, Location, ObjectDesc) SELECT 0, True, """ & zObjectFullName & """, 0, 0, -1000, " & lQAX & ", " & lQAY & ", " & lQAZ & ", " & lQuestForGlory & ", " & lBonusXP & ", " & lGold & ", " & lLocation & ", 'Congratulations! You have found a quest object. Pick up this quest item and you shall receive crowns of glory! HELP FORGE to know what you can purchase with them.';", dbFailOnError
                MyDB.Execute "INSERT INTO tblPlayerLostItem ( PlayerID, ObjectID, X, Y, Z, LostMsg ) SELECT 0, " & lReturnONEGloryXYZObjectID(lQAX, lQAY, lQAZ) & ", " & lQAX & ", " & lQAY & ", " & lQAZ & ", 'GI';", dbFailOnError
                subSendMsgSQRumorChannel "&W" & zShortstop(zObjectFullName) & " &wfell into the realm," & vbCrLf & " &W[&wx" & lQAX & " y" & lQAY & " z" & lQAZ & "&W] &a@ &W[" & zReturnAreaWhereName(lQAX, lQAY, lQAZ) & "&W]"
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSeeIfWePlantAGloryItem," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoadRandomGivesObjectID()
On Error GoTo Err_Check 'Trisker work here, this might need tweeking its new
    Const zLoadSQL = "RottingRounds=0 AND SitMAX=0 AND Gold=0 AND BonusXP=0 AND Rare=0 AND Treasure=0 AND QuestForGlory=0 AND WeightMax=0 AND SystemObjectType=0 AND SystemProtected<>0 AND ObjectIDOriginal=0 AND ObjectIDPandora=0 AND OriginalMobID=0"
    Dim rsQuestArea As Recordset
    Dim lngCountSQL As Long
    
    gbllLoadRandomGivesObjectID = 0
    gblzLoadRandomGivesObjectID = ""
    lngCountSQL = lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE (" & zLoadSQL & ");")
    'Debug.Print "SELECT TOP " & lRandom(lngCountSQL) & " ObjectName, ObjectID, WeightMax, SystemObjectType, SystemProtected, ObjectIDOriginal, ObjectIDPandora, OriginalMobID FROM tblObject WHERE (" & zLoadSQL & ");"
    Set rsQuestArea = MyDB.OpenRecordset("SELECT TOP " & lRandom(lngCountSQL) & " ObjectName, ObjectID, WeightMax, SystemObjectType, SystemProtected, ObjectIDOriginal, ObjectIDPandora, OriginalMobID FROM tblObject WHERE (" & zLoadSQL & ");", dbOpenSnapshot)
    If (Not rsQuestArea.EOF) Then
        rsQuestArea.MoveLast
        gbllLoadRandomGivesObjectID = MyCLng(rsQuestArea!ObjectID)
        gblzLoadRandomGivesObjectID = MyCStr(rsQuestArea!ObjectName)
    End If
    Set rsQuestArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoadRandomGivesObjectID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSeeIfWePlantAGlorySelfDeletingOriginalMob(lChance As Long) 'Create a Glory Mobile - create glory mob
'See Also: subCreatorMobGroup
On Error GoTo Err_Check
    Dim rsQuestArea As Recordset
    Dim lTotalArea As Long
    Dim lBeconPlayerID As Long 'lBeconPlayerID = lReturnRandomPlayerID()
    Dim bAggro As Boolean 'MobAutoAttacks Y<>0 or N=0
    Dim lForceInterrupt As Long
    Dim lPandemicSpreadRange As Long
    Dim lTarzaiBlindLevel As Long
    Dim lTarzaiLungeLevel As Long
    Dim lQAX As Long
    Dim lQAY As Long
    Dim lQAZ As Long
    Dim lAlignment As Long
    Dim zMobFullName As String
    Dim bOkay As Boolean
    Dim lMResWaterElementalDamage As Long
    Dim lMResAirElementalDamage As Long
    Dim lMResEarthElementalDamage As Long
    Dim lMResHeatElementalDamage As Long 'Celcius > 35
    Dim lMResPhysicalDamage As Long
    Dim lMResLightningElementalDamage As Long
    Dim lMResColdElementalDamage As Long 'Celcius < 0
    Dim lMResFireElementalDamage As Long
    Dim lMobLevel As Long
    Dim lCHITROLLBase As Long
    Dim lCDAMROLLBase As Long
    Dim lMHP As Long
    Dim lMAC As Long
    Dim lStunRandom As Long
    Dim zStunEmoteFirstPerson As String
    Dim zStunEmoteThirdPerson As String
    Dim lBlindRandom As Long
    Dim zBlindEmoteFirstPerson As String
    Dim zBlindEmoteThirdPerson As String
    Dim lMobSpellDefensiveNo As Long
    Dim lMobSpellDefensiveChance As Long
    Dim lMobSpellOffensiveNo As Long
    Dim lMobSpellOffensiveChance As Long
    Dim lSpecialGloryPlayerAmt As Long
    Dim lNumAttRnd As Long
    Dim zWeaponName As String
    Dim zGender As String
    Dim zSQL As String
    Dim zMobKillPlayerDesc As String
    Dim bMobEmotePlayerAllowed As Boolean
    Dim lMorphType As Long
    Dim lMorphChance As Long
    Dim lInitativeChance As Long
    Dim lCurseChance As Long
    
    bOkay = False
    If (lRandom(lChance) = 1) Then
        If (lRandom(30) = 1) Then MyDB.Execute "DELETE MobID FROM tblMob WHERE (SpecialSelfDeleting=True AND PlayerID=0);", dbFailOnError 'We delete all glory quest mobs now and then that never faught anyone
        
        If (lngSQLRecordCount("SELECT PlayerID, PortID FROM tblPlayer WHERE (Len([PortID])>1);") > 0) Then 'any player online?
            If (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (SpecialGloryPlayerAmt>0);") < 50) Then 'If there are less than 50 quest mobs we make another one
                lPandemicSpreadRange = -1 'disabled state for all
                lSpecialGloryPlayerAmt = 1
                lTotalArea = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (Mid([AreaRules],1,1) = '1' AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0);")
                Set rsQuestArea = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalArea) & " AreaID, X, Y, Z FROM tblArea WHERE (Mid([AreaRules],1,1) = '1' AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0);", dbOpenSnapshot)
                If (Not rsQuestArea.EOF) Then
                    rsQuestArea.MoveLast
                    bOkay = False
                    Do While (Not rsQuestArea.BOF And Not bOkay)
                        lQAX = MyCLng(rsQuestArea!x)
                        lQAY = MyCLng(rsQuestArea!y)
                        lQAZ = MyCLng(rsQuestArea!z)
                        bOkay = (bEven(lQAZ))
                        rsQuestArea.MovePrevious
                    Loop
                End If
                Set rsQuestArea = Nothing
                
                If (bOkay) Then
                    If (lRandom(3) = 1) Then lForceInterrupt = lRandom(25) + 25
                    zMobFullName = ""
                    lCurseChance = 0
                    lMorphType = 0
                    lMorphChance = 0
                    lTarzaiBlindLevel = 0
                    lTarzaiLungeLevel = 0
                    zWeaponName = ""
                    lAlignment = 0
                    bAggro = False
                    Select Case lRandom(30)
                        Case 1 To 12
                            zMobFullName = zMobFullName & "Evil "
                            lAlignment = lRandom(250) * 4
                        Case 13 To 25
                            zMobFullName = zMobFullName & "Good "
                            lAlignment = lRandom(250) * -4
                        Case 26
                            zMobFullName = zMobFullName & "Tyrant "
                            If (lRandom(5) > 1) Then bAggro = True
                            lTarzaiBlindLevel = 16
                            lTarzaiLungeLevel = 9
                            lAlignment = 250 + (lRandom(75) * 7)
                            If (lRandom(6) = 1) Then lBeconPlayerID = lReturnRandomPlayerID()
                    End Select 'we are neutral otherwise
                    
                    If (lRandom(3) = 1) Then
                        If (lRandom(4) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                        lMobSpellDefensiveNo = lRandom(3)
                        lMobSpellDefensiveChance = lRandom(3)
                    End If
                    
                    If (lRandom(3) = 1) Then
                        If (lRandom(4) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                        lMobSpellOffensiveNo = lRandom(15)
                        lMobSpellOffensiveChance = lRandom(3)
                    End If
                    
                    Select Case lRandom(2)
                        Case 1 'gender
                            zGender = "M"
                            If (lRandom(3) = 1) Then
                                If (lRandom(2) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                                lStunRandom = lRandom(3)
                                zStunEmoteFirstPerson = "uses his shoulder and slams you, you see stars and will be out for awhile!"
                                zStunEmoteThirdPerson = "uses his shoulder and slams into"
                                lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 2
                            End If
                            If (lRandom(3) = 1) Then
                                If (lRandom(2) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                                lBlindRandom = lRandom(3)
                                zBlindEmoteFirstPerson = "double punches both your eyes and blinds you!"
                                zBlindEmoteThirdPerson = "uses his fists and double punches the eyes blinding"
                                lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 2
                            End If
                            
                            Select Case lRandom(40) 'we want to have some without a title too
                                Case 1
                                    If zGender = "F" Then
                                        zMobFullName = zMobFullName & "Queen "
                                    Else
                                        zMobFullName = zMobFullName & "King "
                                    End If
                                    If (lRandom(9) = 1) Then lBeconPlayerID = lReturnRandomPlayerID()
                                Case 2
                                    zMobFullName = zMobFullName & "Prince "
                                Case 3
                                    zMobFullName = zMobFullName & "Count "
                                Case 4
                                    zMobFullName = zMobFullName & "Baron "
                                Case 5
                                    zMobFullName = zMobFullName & "Captain "
                                    If (lRandom(12) = 1) Then lBeconPlayerID = lReturnRandomPlayerID()
                                Case 6
                                    zMobFullName = zMobFullName & "Fighter "
                                Case 7
                                    zMobFullName = zMobFullName & "Scribe "
                                Case 8
                                    zMobFullName = zMobFullName & "Buccaneer "
                                Case 9
                                    zMobFullName = zMobFullName & "Pirate "
                                    If (lRandom(6) = 1) Then lBeconPlayerID = lReturnRandomPlayerID()
                                Case 10
                                    zMobFullName = zMobFullName & "Thug "
                                Case 11
                                    zMobFullName = zMobFullName & "Beggar "
                                Case 12
                                    zMobFullName = zMobFullName & "Mage "
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(15)
                                Case 13
                                    zMobFullName = zMobFullName & "Cleric "
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(20)
                                Case 14
                                    zMobFullName = zMobFullName & "Ranger "
                                Case 15
                                    zMobFullName = zMobFullName & "Druid "
                                Case 16
                                    zMobFullName = zMobFullName & "Warloc "
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(9)
                                Case 17
                                    zMobFullName = zMobFullName & "Thief "
                                    If (lRandom(9) = 1) Then lBeconPlayerID = lReturnRandomPlayerID()
                                Case 18
                                    zMobFullName = zMobFullName & "Barbarian "
                                Case 19
                                    zMobFullName = zMobFullName & "Vampyre "
                                    If (lRandom(9) = 1) Then lBeconPlayerID = lReturnRandomPlayerID()
                                Case 20
                                    zMobFullName = zMobFullName & "Undead "
                                Case 21
                                    zMobFullName = zMobFullName & "Jester "
                                Case 22
                                    zMobFullName = zMobFullName & "Ghost "
                                    lCurseChance = lRandom(13) + 3
                                Case 23
                                    zMobFullName = zMobFullName & "Poltergeist "
                                    lCurseChance = lRandom(6) + 3
                                Case 24
                                    zMobFullName = zMobFullName & "Doctor "
                                Case 25
                                    zMobFullName = zMobFullName & "Mayor "
                                Case 26
                                    If (zGender = "F") Then
                                        zMobFullName = zMobFullName & "Nurse "
                                    Else
                                        zMobFullName = zMobFullName & "Orderly "
                                    End If
                                Case 27
                                    zMobFullName = zMobFullName & "Chief "
                                Case 28
                                    zMobFullName = zMobFullName & "Major "
                                Case 29
                                    zMobFullName = zMobFullName & "General "
                                Case 30
                                    zMobFullName = zMobFullName & "Giant "
                            End Select 'we miss on 10 so this is random(40) with case 30 for example
                            
                            Select Case lRandom(31)
                                Case 1
                                    zMobFullName = zMobFullName & "Blackeye"
                                Case 2
                                    zMobFullName = zMobFullName & "Barnical"
                                Case 3
                                    zMobFullName = zMobFullName & "Peter"
                                Case 4
                                    zMobFullName = zMobFullName & "George"
                                Case 5
                                    zMobFullName = zMobFullName & "James"
                                Case 6
                                    zMobFullName = zMobFullName & "Raymond"
                                Case 7
                                    zMobFullName = zMobFullName & "Michael"
                                Case 8
                                    zMobFullName = zMobFullName & "Elliot"
                                Case 9
                                    zMobFullName = zMobFullName & "Gnoll"
                                Case 10
                                    zMobFullName = zMobFullName & "Spider"
                                Case 11
                                    zMobFullName = zMobFullName & "Minotaur"
                                Case 12
                                    zMobFullName = zMobFullName & "Demon"
                                Case 13
                                    zMobFullName = zMobFullName & "Kobold"
                                Case 14
                                    zMobFullName = zMobFullName & "Knight"
                                    lForceInterrupt = 10 + lRandom(25)
                                Case 15
                                    zMobFullName = zMobFullName & "Skeleton"
                                    lPandemicSpreadRange = lRandom(5)
                                Case 16
                                    zMobFullName = zMobFullName & "Elemental"
                                Case 17
                                    zMobFullName = zMobFullName & "Spirit"
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(9)
                                Case 18
                                    zMobFullName = zMobFullName & "Bakula"
                                    lBeconPlayerID = lReturnRandomPlayerID()
                                Case 19
                                    zMobFullName = zMobFullName & "Professor"
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(9)
                                Case 20
                                    zMobFullName = zMobFullName & "Warloc"
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(9)
                                Case 21
                                    zMobFullName = zMobFullName & "Baldwin"
                                    lPandemicSpreadRange = lRandom(5)
                                Case 22
                                    zMobFullName = zMobFullName & "Cosby"
                                    lPandemicSpreadRange = lRandom(5)
                                Case 23
                                    zMobFullName = zMobFullName & "Jared"
                                    lPandemicSpreadRange = lRandom(5)
                                Case 24
                                    zMobFullName = zMobFullName & "Dameous"
                                Case 25
                                    zMobFullName = zMobFullName & "Iaen"
                                Case 26
                                    zMobFullName = zMobFullName & "Bowden"
                                Case 27
                                    zMobFullName = zMobFullName & "Darren"
                                Case 28
                                    zMobFullName = zMobFullName & "Lory"
                                Case 29
                                    zMobFullName = zMobFullName & "Nickolas"
                                Case 30
                                    zMobFullName = zMobFullName & "Louis"
                                Case 31
                                    zMobFullName = zMobFullName & "Massey"
                            End Select
                            
                            If (lMorphChance = 1) Then lMorphChance = lMorphChance + 2
                            If (lMorphType <> 0) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 3
                            If (lCurseChance = 1) Then lCurseChance = lCurseChance + 2
                            If (lCurseChance <> 0) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 3
                            
                            Select Case lRandom(17)
                                Case 1
                                    zMobFullName = zMobFullName & ", is waiting for your next move"
                                Case 2
                                    zMobFullName = zMobFullName & ", has a bad temper"
                                Case 3
                                    zMobFullName = zMobFullName & ", is trying to get away with something"
                                Case 4
                                    zMobFullName = zMobFullName & ", is battle ready"
                                Case 5
                                    zMobFullName = zMobFullName & ", is polishing a weapon"
                                Case 6
                                    zMobFullName = zMobFullName & ", is insane"
                                Case 7
                                    zMobFullName = zMobFullName & ", has been waiting for you"
                                Case 8
                                    zMobFullName = zMobFullName & ", is up to something"
                                Case 9
                                    zMobFullName = zMobFullName & ", is looking past you"
                                Case 10
                                    zMobFullName = zMobFullName & ", has tan muscles"
                                Case 11
                                    zMobFullName = zMobFullName & ", has blonde hair"
                                Case 12
                                    zMobFullName = zMobFullName & ", has huge muscles"
                                Case 13
                                    zMobFullName = zMobFullName & ", is laughing at you"
                                Case 14
                                    zMobFullName = zMobFullName & ", is a brutal manic"
                                Case 15
                                    zMobFullName = zMobFullName & ", is muscular"
                                Case 16
                                    zMobFullName = zMobFullName & ", smells really bad"
                                    lPandemicSpreadRange = lRandom(5)
                                Case 17
                                    zMobFullName = zMobFullName & ", is drunk"
                            End Select
                        Case 2
                            zGender = "F"
                            If (lRandom(3) = 1) Then
                                If (lRandom(2) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                                lStunRandom = lRandom(3)
                                zStunEmoteFirstPerson = "uses her shoulder and slams you, you see stars and will be out for awhile!"
                                zStunEmoteThirdPerson = "uses her shoulder and slams into"
                                lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 2
                            End If
                            If (lRandom(3) = 1) Then
                                If (lRandom(2) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                                lBlindRandom = lRandom(3)
                                zBlindEmoteFirstPerson = "double punches both your eyes and blinds you!"
                                zBlindEmoteThirdPerson = "uses her fists and double punches the eyes to blind"
                                lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 2
                            End If
                            
                            Select Case lRandom(15) 'We can miss a title sometimes
                                Case 1
                                    zMobFullName = zMobFullName & "Queen "
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(5)
                                Case 2
                                    zMobFullName = zMobFullName & "Princess "
                                    lMorphType = lRandom(9)
                                    lMorphChance = lRandom(9)
                                Case 3
                                    zMobFullName = zMobFullName & "Madam "
                                Case 4
                                    zMobFullName = zMobFullName & "Miss "
                                Case 5
                                    zMobFullName = zMobFullName & "Mrs "
                                Case 6
                                    zMobFullName = zMobFullName & "Gal "
                                Case 7
                                    zMobFullName = zMobFullName & "Smiling "
                                Case 8
                                    zMobFullName = zMobFullName & "Happy "
                                Case 9
                                    zMobFullName = zMobFullName & "Maid "
                                Case 10
                                    zMobFullName = zMobFullName & "Ms "
                                Case 11
                                    zMobFullName = zMobFullName & "Witch "
                                    lMorphType = lRandom(3)
                                    lMorphChance = lRandom(9)
                                Case 12
                                    zMobFullName = zMobFullName & "Waitress "
                                Case 13
                                    zMobFullName = zMobFullName & "Stripper "
                                    lMorphType = lRandom(2)
                                    lMorphChance = 1
                            End Select
                            
                            Select Case lRandom(13)
                                Case 1
                                    zMobFullName = zMobFullName & "Janice"
                                Case 2
                                    zMobFullName = zMobFullName & "Betty"
                                Case 3
                                    zMobFullName = zMobFullName & "Robyn"
                                Case 4
                                    zMobFullName = zMobFullName & "Lisa"
                                Case 5
                                    zMobFullName = zMobFullName & "Tracy"
                                Case 6
                                    zMobFullName = zMobFullName & "April"
                                Case 7
                                    zMobFullName = zMobFullName & "Olivia"
                                Case 8
                                    zMobFullName = zMobFullName & "Jessica"
                                Case 9
                                    zMobFullName = zMobFullName & "Goblin"
                                Case 10
                                    zMobFullName = zMobFullName & "Orc"
                                Case 11
                                    zMobFullName = zMobFullName & "Minotaur"
                                Case 12
                                    zMobFullName = zMobFullName & "Demon"
                                    lMorphType = lRandom(5)
                                    lMorphChance = lRandom(4) + 5
                                Case 13
                                    zMobFullName = zMobFullName & "Kobold"
                            End Select
                            
                            Select Case lRandom(16)
                                Case 1
                                    zMobFullName = zMobFullName & ", is waiting for your next move"
                                Case 2
                                    zMobFullName = zMobFullName & ", is rich"
                                Case 3
                                    zMobFullName = zMobFullName & ", is trying to get away with something"
                                Case 4
                                    zMobFullName = zMobFullName & ", is battle ready"
                                Case 5
                                    zMobFullName = zMobFullName & ", is polishing a weapon"
                                Case 6
                                    zMobFullName = zMobFullName & ", is insane"
                                Case 7
                                    zMobFullName = zMobFullName & ", has been waiting for you"
                                Case 8
                                    zMobFullName = zMobFullName & ", is up to something"
                                Case 9
                                    zMobFullName = zMobFullName & ", is looking past you"
                                Case 10
                                    zMobFullName = zMobFullName & ", has tan muscles"
                                Case 11
                                    zMobFullName = zMobFullName & ", has blonde hair"
                                Case 12
                                    zMobFullName = zMobFullName & ", is a redhead"
                                Case 13
                                    zMobFullName = zMobFullName & ", is a brunette"
                                Case 14
                                    zMobFullName = zMobFullName & ", is pretty"
                                Case 15
                                    zMobFullName = zMobFullName & ", has hairy armpits"
                                Case 16
                                    zMobFullName = zMobFullName & ", is a knight"
                                    lForceInterrupt = 25 + lRandom(25)
                                    lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                            End Select
                    End Select
                                       
                    If (lRandom(50) = 1) Then lPandemicSpreadRange = lRandom(5)
                    lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + lPandemicSpreadRange
                    
                    If (lRandom(5) = 1) Then
                        lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                        Select Case lRandom(16)
                            Case 1
                                zWeaponName = "dagger"
                            Case 2
                                zWeaponName = "sword"
                            Case 3
                                zWeaponName = "mace"
                            Case 4
                                zWeaponName = "hammer"
                            Case 5
                                zWeaponName = "club"
                            Case 6
                                zWeaponName = "lance"
                            Case 7
                                zWeaponName = "spear"
                            Case 8
                                zWeaponName = "mace"
                            Case 9
                                zWeaponName = "fork"
                            Case 10
                                zWeaponName = "pitch fork"
                            Case 11
                                zWeaponName = "claymore"
                            Case 12
                                zWeaponName = "knife"
                            Case 13
                                zWeaponName = "awl"
                            Case 14
                                zWeaponName = "staff"
                                lMorphType = lRandom(9) 'this is turn into animal morph not class morphing like vampire and stuff
                                lMorphChance = lRandom(9)
                            Case 15
                                zWeaponName = "broadsword"
                            Case 16
                                zWeaponName = "litesabre"
                                lForceInterrupt = 60 + lRandom(20)
                        End Select
                        If (lRandom(3) = 1) Then 'there is a chance the mob just wont have morph to frog or whatever, this is a mobs instant slay because it makes the person super weak
                            lMorphType = 0
                            lMorphChance = 0
                        End If
                        lMobSpellOffensiveNo = 15 + lRandom(2)
                        lMobSpellOffensiveChance = lRandom(2)
                        If (lMobSpellOffensiveNo = 17) Then zWeaponName = "Poisoned-" & zWeaponName 'poison
                    End If
                    
                    If (Len(zWeaponName) > 0 And lRandom(4) = 1) Then lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + 1
                    
                    lMobLevel = 30 + lRandom(200) + lRandom(200) + lRandom(20)
                    lMHP = lMobLevel * (cstMobHPRespawn * 2)
                    lMAC = lMobLevel * (cstMobACRespawn * 2)
                    lCHITROLLBase = (lMobLevel * (cstMobHRRespawn * 3))
                    lCDAMROLLBase = (lMobLevel * (cstMobDRRespawn * 3))
                    
                    Select Case lRandom(50) 'makes some mobs harder
                        Case 1
                            lMHP = lMHP * 2
                            lMAC = lMAC * 2
                            lCHITROLLBase = lCHITROLLBase * 3
                            lCDAMROLLBase = lCDAMROLLBase * 2
                        Case 2
                            lMHP = lMHP * 2
                            lMAC = lMAC * 3
                            lCHITROLLBase = lCHITROLLBase * 4
                            lCDAMROLLBase = lCDAMROLLBase * 2
                    End Select
                    
                    Select Case lRandom(lMobLevel)
                        Case 51 To 100
                            lNumAttRnd = 2 + lRandom(2)
                        Case 101 To 125
                            lNumAttRnd = 3 + lRandom(3)
                        Case 126 To 150
                            lNumAttRnd = 4 + lRandom(4)
                        Case 151 To 175
                            lNumAttRnd = 5 + lRandom(5)
                        Case 176 To 200
                            lNumAttRnd = 6 + lRandom(6)
                        Case 201 To 225
                            lNumAttRnd = 7 + lRandom(7)
                        Case 226 To 300
                            lNumAttRnd = 8 + lRandom(8)
                        Case 301 To 1000
                            lNumAttRnd = 10 + lRandom(9)
                        Case Else
                            lNumAttRnd = 1 + lRandom(5)
                    End Select
                    lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + MyCLng(lNumAttRnd / 3)
                    
                    Select Case lRandom(8)
                        Case 1
                            zMobKillPlayerDesc = "%s2 -=SLAYS=- %s1!"
                        Case 2
                            zMobKillPlayerDesc = "%s2 decapitates %s1!"
                        Case 3
                            zMobKillPlayerDesc = "%s2 executes %s1!"
                        Case 4
                            zMobKillPlayerDesc = "%s2 pulls the entrails out of %s1!"
                        Case 5
                            zMobKillPlayerDesc = "%s2 beats %s1 to death!"
                        Case 6
                            zMobKillPlayerDesc = "%s2 rips %s1 apart limb-from-limb!"
                        Case 7
                            zMobKillPlayerDesc = "%s2 disembowels %s1!"
                        Case Else
                            zMobKillPlayerDesc = "%s2 kills %s1!"
                    End Select
                    
                    lSpecialGloryPlayerAmt = lSpecialGloryPlayerAmt + lNumAttRnd
                    If (lSpecialGloryPlayerAmt > 5) Then lSpecialGloryPlayerAmt = 3 + lRandom(lSpecialGloryPlayerAmt - 3)
                    If (lSpecialGloryPlayerAmt > 12) Then lSpecialGloryPlayerAmt = 12
                    
                    lMResWaterElementalDamage = lRandom(90)
                    lMResAirElementalDamage = lRandom(90)
                    lMResEarthElementalDamage = lRandom(90)
                    lMResHeatElementalDamage = lRandom(90) 'Celcius > 35
                    
                    lMResPhysicalDamage = lRandom(90)
                    lMResLightningElementalDamage = lRandom(90)
                    lMResColdElementalDamage = lRandom(90)
                    lMResFireElementalDamage = lRandom(90)
                    lInitativeChance = lRandom(90)
                    bMobEmotePlayerAllowed = True
                    
                    If (lRandom(200) = 1) Then
                        subLoadRandomGivesObjectID 'loads gbllLoadRandomGivesObjectID and gblzLoadRandomGivesObjectID
                        If (gbllLoadRandomGivesObjectID <> 0) Then
                            zMobFullName = "&Y[&y" & zShortstop(gblzLoadRandomGivesObjectID) & "&Y] &W" & zMobFullName
                        End If
                    End If
                    
                    zSQL = "INSERT INTO tblMob ( GivesObjectID, ResWaterElementalDamage, ResAirElementalDamage, ResEarthElementalDamage, ResHeatElementalDamage, PandemicSpreadRange, CurseChance, ForceInterrupt, ResPhysicalDamage, ResLightningElementalDamage, ResColdElementalDamage, ResFireElementalDamage, InitativeChance, MobName, RespawnX, RespawnY, RespawnZ, X, Y, Z, ImmunitySummonSpell, SpecialSelfDeleting, SpecialGloryPlayerAmt, Alignment, MobLevel, CHITROLLBase, CDAMROLLBase, MHP, MAC, QuestMobNotAvailable, StunRandom, StunEmoteFirstPerson, StunEmoteThirdPerson, BlindRandom, BlindEmoteFirstPerson, BlindEmoteThirdPerson, MobSpellDefensiveNo, MobSpellDefensiveChance, MobSpellOffensiveNo, MobSpellOffensiveChance, WeaponName, Gender, NumAttRnd, MobKillPlayerDesc, MobDesc, MobEmotePlayerAllowed, MorphType, MorphChance, TarzaiBlindLevel, TarzaiLungeLevel, MobAutoAttacks, BeconPlayerID) "
                    zSQL = zSQL & "SELECT " & gbllLoadRandomGivesObjectID & ", " & lMResWaterElementalDamage & ", " & lMResAirElementalDamage & ", " & lMResEarthElementalDamage & ", " & lMResHeatElementalDamage & ", " & lPandemicSpreadRange & ", " & lCurseChance & ", " & lForceInterrupt & ", " & lMResPhysicalDamage & ", " & lMResLightningElementalDamage & ", " & lMResColdElementalDamage & ", " & lMResFireElementalDamage & ", " & lInitativeChance & ", """ & zMobFullName & """, " & lQAX & ", " & lQAY & ", " & lQAZ & ", " & lQAX & ", " & lQAY & ", " & lQAZ & ", Yes, Yes, "
                    zSQL = zSQL & lSpecialGloryPlayerAmt & ", " & lAlignment & ", " & lMobLevel & ", " & lCHITROLLBase & ", " & lCDAMROLLBase & ", " & lMHP & ", " & lMAC & ", Yes, " & lStunRandom & ", '" & zStunEmoteFirstPerson & "', '" & zStunEmoteThirdPerson & "', " & lBlindRandom & ", '" & zBlindEmoteFirstPerson & "', '" & zBlindEmoteThirdPerson & "', " & lMobSpellDefensiveNo & ", " & lMobSpellDefensiveChance & ", " & lMobSpellOffensiveNo & ", " & lMobSpellOffensiveChance & ", '" & zWeaponName & "', '" & zGender & "'," & lNumAttRnd & ", '" & zMobKillPlayerDesc & "', 'Congratulations! You have found a quest mob. Defeat this quest mob and you shall receive crowns of glory! HELP FORGE to know what you can purchase with them.', " & bMobEmotePlayerAllowed & ", " & lMorphType & ", " & lMorphChance & ", " & lTarzaiBlindLevel & ", " & lTarzaiLungeLevel & ", " & bAggro & ", " & lBeconPlayerID & ";"
                    MyDB.Execute zSQL, dbFailOnError
                    If (Len(zWeaponName) = 0) Then
                        subSendMsgSQRumorChannel "&W" & zShortstop(zMobFullName) & " &wenters the realm!" & vbCrLf & " &W[&wx" & lQAX & " y" & lQAY & " z" & lQAZ & "&W] &a@ &W[" & zReturnAreaWhereName(lQAX, lQAY, lQAZ) & "&W]"
                    Else
                        subSendMsgSQRumorChannel "&W" & zShortstop(zMobFullName) & " and the " & zWeaponName & " &wenters the realm!" & vbCrLf & " &W[&wx" & lQAX & " y" & lQAY & " z" & lQAZ & "&W] &a@ &W[" & zReturnAreaWhereName(lQAX, lQAY, lQAZ) & "&W]"
                    End If
                    
                    gbllLoadRandomGivesObjectID = 0
                    gblzLoadRandomGivesObjectID = ""
                End If
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSeeIfWePlantAGlorySelfDeletingOriginalMob," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subCreatorMobGroup(zPortID As String, zWord1 As String, zPromptOriginal As String)
'See Also: subSeeIfWePlantAGlorySelfDeletingOriginalMob
On Error GoTo Err_Check
    Dim lCount As Long
    Dim rsPlayer As Recordset
    Dim rsMob As Recordset
    Dim zHoldPO As String
    Dim zHoldWord1 As String
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMobLevel As Long
    Dim lAlignment As Long
    Dim zSize As String
    Dim zGender As String
    Dim zWeaponName As String
    Dim zActivity As String
    Dim lCountWords As Long
    Dim lLen As Long
    
    lCountWords = 0
    lLen = Len(zPromptOriginal)
    For lCount = 1 To lLen
        If (Mid(zPromptOriginal, lCount, 1) = " ") Then lCountWords = lCountWords + 1
    Next lCount
    
    zHoldWord1 = MyCStr(MyCLng(zWord1))
    If (MyCLng(zHoldWord1) <> 0) Then
        If (lCountWords > 1) Then
            Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, PlayerID, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
               lMX = MyCLng(rsPlayer!x)
               lMY = MyCLng(rsPlayer!y)
               lMZ = MyCLng(rsPlayer!z)
            End If
            Set rsPlayer = Nothing
            
            lMobLevel = MyCLng(zHoldWord1)
            
            zHoldPO = MyCStr(Mid(zPromptOriginal, InStr(zPromptOriginal, zWord1)))
            zHoldPO = MyCStr(Mid(zHoldPO, InStr(zHoldPO, " ")))
            subSendMsg "&WMobiles lv &w[" & zHoldWord1 & "] &gin the area will start with:&M" & vbCrLf & zHoldPO & ".", zPortID
            For lCount = 1 To 5
                Select Case lRandom(10)
                    Case 1
                        zActivity = "patrols here"
                    Case 2
                        zActivity = "is part of a tribe"
                    Case 3
                        zActivity = "is looking at you"
                    Case 4
                        zActivity = "is glaring at you"
                    Case 5
                        zActivity = "barely noticed you"
                    Case 6
                        zActivity = "is waiting"
                    Case 7
                        zActivity = "is chatting"
                    Case 8
                        zActivity = "noticed you"
                    Case 9
                        zActivity = "is ready for you"
                    Case 10
                        zActivity = "is watching you"
                End Select
                
                Select Case lRandom(2)
                    Case 1
                        zGender = "M"
                    Case 2
                        zGender = "F"
                End Select
                Select Case lRandom(12)
                    Case 1
                        zSize = "short"
                    Case 2
                        zSize = "tall"
                    Case 3
                        zSize = "small"
                    Case 4
                        zSize = "medium"
                    Case 5
                        zSize = "large"
                    Case 6
                        zSize = "jester"
                        zWeaponName = "rattle"
                    Case 7
                        zSize = "drunk"
                    Case 8
                        zSize = "queen"
                        zGender = "F"
                        zWeaponName = "sceptre"
                    Case 9
                        zSize = "king"
                        zGender = "M"
                        zWeaponName = "staff"
                    Case 10
                        zSize = "big"
                    Case 11
                        zSize = "hulking"
                    Case 12
                        zSize = "massive"
                End Select
                Select Case lRandom(2)
                    Case 1
                        lAlignment = 1
                    Case 2
                        lAlignment = -1
                End Select
                Set rsMob = MyDB.OpenRecordset("tblMob", dbOpenTable)
                If (Not rsMob.EOF) Then
                    rsMob.AddNew
                    rsMob!MobName = zSize & " " & zHoldPO & ", " & zActivity
                    rsMob!x = lMX
                    rsMob!y = lMY
                    rsMob!z = lMZ
                    rsMob!RespawnX = lMX
                    rsMob!RespawnY = lMY
                    rsMob!RespawnZ = lMZ
                    rsMob!MobLevel = lMobLevel
                    rsMob!MHP = lMobLevel * (cstMobHPRespawn * 2)
                    rsMob!Mac = lMobLevel * (cstMobACRespawn * 2)
                    rsMob!CHITROLLBase = (lMobLevel * (cstMobHRRespawn * 3))
                    rsMob!CDAMROLLBase = (lMobLevel * (cstMobDRRespawn * 3))
                    rsMob!Alignment = lRandom(1000) * lAlignment
                    If (lRandom(3) = 1) Then
                        rsMob!MobSpellDefensiveNo = lRandom(3)
                        rsMob!MobSpellDefensiveChance = lRandom(3)
                    End If
                    If lRandom(30) = 1 Then
                        rsMob!MorphType = lRandom(9)
                        rsMob!MorphChance = lRandom(5)
                    End If
                    rsMob!WeaponName = zWeaponName
                    If (lRandom(3) = 1) Then
                        rsMob!MobSpellOffensiveNo = lRandom(15)
                        rsMob!MobSpellOffensiveChance = lRandom(3)
                    End If
                    rsMob!NumAttRnd = lRandom(4)
                    rsMob!Gender = zGender
                    rsMob!WeaponName = zWeaponName
                    rsMob!MobKillPlayerDesc = "%s2 rips %s1 apart limb-from-limb!"
                    rsMob.Update
                End If
                Set rsMob = Nothing
            Next lCount
            subSendMsg "&GSuccess! A mobile group has been randomly created in the area.", zPortID
        Else
            subSendMsg "&gSYNTAX: IMMO CREATOR <moblevel> <shortnamedesc> ", zPortID
        End If
    Else
        subSendMsg "&gSYNTAX: IMMO CREATOR <moblevel> <shortnamedesc> ", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCreatorMobGroup," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zTranslatePlayerType(lPlayerType As Long) As String
    Dim zReturn As String
    zReturn = "regular"
    Select Case lPlayerType
        Case 1
            zReturn = "house"
        Case 2
            zReturn = "starship"
        Case 3
            zReturn = "colony"
        Case 4
            zReturn = "military"
    End Select
    zTranslatePlayerType = zReturn
End Function
Public Sub subMakePrimitivesArea(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim bPFound As Boolean
    Dim lPlayerType As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim rsArea As Recordset
    Dim zAreaName As String
    Dim lCNumb As Long
    Dim lCFarm As Long
    Dim lCFact As Long
    Dim lCASFP As Long
    Dim lCHull As Long
    Dim lCShield As Long
    
    bPFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPFound = True
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
    End If
    Set rsPlayer = Nothing
    
    If (bPFound) Then
        Set rsArea = MyDB.OpenRecordset("SELECT SSHullLevel, SSShieldLevel, AreaName, PlayerType, ColonistAllowed, ColonistsNumber, ColonistsFarm, ColonistsFactory, AreaSpeciesFertilityPercent FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenDynaset)
        If (Not rsArea.EOF) Then
            lPlayerType = MyCLng(rsArea!PlayerType)
            If (lPlayerType = 0 Or lPlayerType > 2) Then
                zAreaName = MyCStr(rsArea!AreaName)
                subSendMsg "&Y" & "Area [" & zAreaName & "] Found!", zPortID
                rsArea.Edit
                If (MyCLng(rsArea!ColonistAllowed) <> 0) Then
                    rsArea!ColonistAllowed = False
                    rsArea!ColonistsNumber = 0
                    rsArea!ColonistsFarm = 0
                    rsArea!ColonistsFactory = 0
                    rsArea!AreaSpeciesFertilityPercent = 0
                    rsArea!SSHullLevel = 0
                    rsArea!SSShieldLevel = 0
                    rsArea!PlayerType = 0 'reg. area
                    subSendMsg "&g Area [" & zAreaName & "] is no longer a colonists area.", zPortID
                Else
                    rsArea!ColonistAllowed = True
                    lCNumb = lRandom(500) + 700
                    rsArea!ColonistsNumber = lCNumb
                    lCFarm = lRandom(25) + 25
                    rsArea!ColonistsFarm = lCFarm
                    lCFact = lRandom(25) + 25
                    rsArea!ColonistsFactory = lCFact
                    lCHull = lRandom(250) + 100
                    rsArea!SSHullLevel = lCHull
                    lCShield = lRandom(250) + 100
                    rsArea!SSShieldLevel = lCShield
                    lPlayerType = 2 + lRandom(2) '3=Colony area, 4=Military
                    lCASFP = lRandom(10) + 3
                    If (lPlayerType = 4) Then
                        lCHull = lCHull * 3
                        lCShield = lCShield * 3
                    Else
                        lCASFP = lCASFP + 2 + lRandom(9)
                    End If
                    rsArea!AreaSpeciesFertilityPercent = lCASFP
                    rsArea!PlayerType = lPlayerType
                    subSendMsg "&G Area [" & zAreaName & "] is now a primitives area!", zPortID
                    subSendMsg "&G            Primitives", zPortID
                    subSendMsg "&G            Player Type       [" & zTranslatePlayerType(lPlayerType) & "]", zPortID
                    subSendMsg "&G            Hull Level        [" & lCHull & "]", zPortID
                    subSendMsg "&G            Shield Level      [" & lCShield & "]", zPortID
                    subSendMsg "&G            Default Number    [" & lCNumb & "]", zPortID
                    subSendMsg "&G            Default Farms     [" & lCFarm & "]", zPortID
                    subSendMsg "&G            Default Factories [" & lCFact & "]", zPortID
                    subSendMsg "&G            Default Fertility%[" & lCASFP & "]", zPortID
                    subSendMsg "&G            NOTE: You can random reroll for colony or military.", zPortID
                End If
                rsArea.Update
            Else
                subSendMsg "&RArea cannot be modified to a primitives colony!", zPortID
            End If
        Else
            subSendMsg "&RArea not Found here...Use IMMO RC first!", zPortID
        End If
        Set rsArea = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMakePrimitivesArea," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subProcessCMD(zRunLine As String)    'subProcessCMD ( "shutdown.exe /r /t 0" ) 'server 2019 code "shutdown / r / t 0" you can also use schedular to reboot the server every 12 hours.
'immo reboot Case "REBO"    subProcessCMD ( "shutdown.exe /r /t 0" )
    Dim zFilename As String  ' App.Path & "\coaserver.bat"
    Dim iResult As Integer
    Dim iFileNo As Integer 'see also: AppActivate App.Path & Shell("\coaserver.bat") RunCommand App.Path & "\coaserver.bat"
    zFilename = App.Path & "\coaserver.bat"
    iFileNo = FreeFile
    Open zFilename For Output As #iFileNo 'overwrite always
    Print #iFileNo, zRunLine 'string writes to the file + linefeed
    Close #iFileNo 'save n close
    iResult = Shell(zFilename)  'run this batfile
End Sub
Public Sub subImmortalCommand(zPortID As String, zWord1 As String, zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, lImmortalLevel As Long, zPlayerName As String, lPlayerID As Long, lPlayerLevel As Long, zPlayerTitle As String, lX As Long, lY As Long, lZ As Long, lCrown As Long, lLightRadius As Long, lWhereID As Long, zClassType As String, lBlindDuration As Long, lLightDuration As Long, bRebootAllowed As Boolean)
On Error GoTo Err_Check
    Const bStatusGUID = False
    Const bStatusBM = False
    Dim zPromptMessage As String
    Dim bShow As Boolean
    Dim iSuccess As Integer
    Dim iPort As Integer
    Dim zFile As String
    Dim lResult As Long
    Dim zFileCopyName As String
    Dim lCountSystemErrors As Long
    Dim bFound As Boolean
    Dim lGetDoorID As Long
    Dim zGetDoorName As String
    
    iSuccess = 0
    If (bImmortalPlayerWithInRadius(lPlayerID, lX, lY, lZ)) Then 'a player has build powers in this area
        If (lImmortalLevel < 4) Then lImmortalLevel = 4 'they can build in their own areas
    End If
    
    If (lImmortalLevel > 0) Then
        If (iSuccess = 0) Then
            'If an area is finished the following few commands can still be ran by an immortal
            bFound = False
            Select Case UCase(Mid(zWord1, 1, 4))
                Case "VOID" 'View any mobs or objects sitting in a void
                    bFound = True
                    Select Case UCase(Mid(zWord2, 1, 4))
                        Case "MOB" 'View any mobs or objects sitting in a void
                            bFound = True
                            subVoidMobs zWord3, lX, lY, lZ, zPortID
                        Case "OBJE" 'View any mobs or objects sitting in a void
                            bFound = True
                            subVoidObjects zWord3, lX, lY, lZ, zPortID
                        Case Else
                            subSendMsg "&GIMMO VOID MOB BRINGTOIMMOXYZ or IMMO VOID OBJECTS BRINGTOIMMOXYZ", zPortID
                    End Select
                Case "ORPH" 'orphaned objects
                    'bFound = True
                    'subOrphanedObjects lX, lY, lZ, zPortID
                    subSendMsg "&Gin the works....", zPortID
            End Select
            
            If (lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE FinishedImmortalLevel>" & lImmortalLevel & " AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ";") = 0) Then 'If the area is marked with the finish rule as 100 no one can edit it as the immortal level max is 100
                bShow = False
                Select Case (lImmortalLevel <> 0)
                    Case True
                        Select Case UCase(Mid(zWord1, 1, 4))
                            'Case "RECA"
                            '    subSendMsg "&GRecalculate player Status Duration: " & gbllRecalculatedDelay(MyCLng(zPortID)), zPortID
                            Case "ATMO"
                                subSendMsg "&MATMOz CURRENTLY [" & cstAtmozDefault & "]", zPortID
                                If (Len(zWord2) > 0 And Len(zWord2) < 5) Then
                                    cstAtmozDefault = MyCLng(zWord2)
                                    If cstAtmozDefault > 9999 Then cstAtmozDefault = 9999
                                    subSendMsg "&GATMOz NOW SET TO [" & cstAtmozDefault & "]", zPortID
                                    'subLightningBoltARandomPlayer True
                                Else
                                    subSendMsg "&RIMMO ATMO 9999 is the max value.", zPortID
                                End If
                            Case "SHIP"
                                subCheckMobSpaceShipFireOnPlayer 1
                            Case "EAR", "SPAM"
                                gbllImmortalPortEAR = gbllImmortalPortEAR - 1
                                If (gbllImmortalPortEAR < -1) Then gbllImmortalPortEAR = 5 'we revolve
                                If (gbllImmortalPortEAR > 5) Then gbllImmortalPortEAR = -1
                                Select Case gbllImmortalPortEAR
                                    Case -1
                                        subSendMsg "&GEAR: PORT SPAM CONTROLLER [OFF]", zPortID
                                    Case 5
                                        subSendMsg "&GEAR: PORT SPAM CONTROLLER [VERBOSE]", zPortID
                                    Case Else
                                        subSendMsg "&GEAR: PORT SPAM CONTROLLER [" & gbllImmortalPortEAR & "]", zPortID
                                End Select
                            Case "DEFC"
                                subSendMsg "&GDEFCON [" & gbllDefcon & "] now set to DefCON -1 off", zPortID
                                gbllDefcon = -1
                            Case "IO", "WITC", "WARL"
                                gbllWITCHLOCKDuration = 999
                                gbllWITCHLOCKPlayerID = lPlayerID
                                subSendMsg "&AMAJIK &yPOOF&Yt&ma ! ! !", zPortID
                                MyDB.Execute "UPDATE tblPlayer SET Class='IO' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                subSendMsg "&G*CACKLE* &RY&rOUR A &RW&rITCH&RL&rocke!", zPortID
                            Case "SHOW", "TIME"
                                subShowtime 1
                            Case "AMC", "AAMC"
                                gblbRealmAdditionalMoveCosts = Not gblbRealmAdditionalMoveCosts
                                subSendMsg "&GActive Additional Move Cost from Plague and Blocking " & zTranslateBoolean(gblbRealmAdditionalMoveCosts), zPortID
                            Case "MIM", "LAG"
                                gblbMOBINTELLIGENCEMODE = Not gblbMOBINTELLIGENCEMODE
                                Select Case UCase(zTranslateBoolean(gblbMOBINTELLIGENCEMODE))
                                    Case "YES"
                                        subSendMsg "&GMob Intelligence MODE Less Frequently", zPortID
                                    Case Else
                                        subSendMsg "&GMob Intelligence MODE More Frequently", zPortID
                                End Select
                            Case "LAZY"
                                gbllQuestGuardFailCount(MyCLng(zPortID)) = 33 + lRandom(20)
                                subSendMsg "&GYou evil lazy guard status AFFECTGs =" & gbllQuestGuardFailCount(MyCLng(zPortID)), zPortID
                            Case "PLAG"
                                gbllDEATHX = 0
                                gbllDEATHY = 0
                                gbllDEATHZ = 0
                                subSendMsg "&GPlague now at 0 0 0//IMMO AMC, Active Additional Move Cost from Plague and Blocking " & zTranslateBoolean(gblbRealmAdditionalMoveCosts), zPortID
                            Case "MYST"
                                subSendMsg "&GMyst ontop of 0 0 0//IMMO AMC, Active Additional Move Cost from Plague and Blocking " & zTranslateBoolean(gblbRealmAdditionalMoveCosts), zPortID
                                gbllCLOUDX1 = -10
                                gbllCLOUDY1 = -10
                                gbllCLOUDZ1 = -10
                                gbllCLOUDX2 = 10
                                gbllCLOUDY2 = 10
                                gbllCLOUDZ2 = 10
                            Case "SET"
                                lgblCompletelyBannedMAX = MyCLng(zWord2) 'tblPlayerRemoteHostCompletelyBanned
                                If (lgblCompletelyBannedMAX < 9) Then lgblCompletelyBannedMAX = 9
                                If (lgblCompletelyBannedMAX > 999) Then lgblCompletelyBannedMAX = 999
                                subSendMsg "&gIMMO COMPLETE LIST [" & lgblCompletelyBannedMAX & "]", zPortID
                            Case "REBO"
                                lgblCompletelyBannedMAX = 30
                                If (bRebootAllowed Or lImmortalLevel > 97) Then
                                    subSendMsgInfoChannel "&WTHE SERVER IS ATTEMPTING TO REBOOT..."
                                    basDelay 1000
                                    subSendMsg "&gWIN 10/SERVER 2019 ISSUED: subProcessCMD ""shutdown.exe /r /t 0""", zPortID
                                    basDelay 1000
                                    subProcessCMD "shutdown.exe /r /t 0"
                                    basDelay 1000
                                    lResult = ExitWindowsEx(EWX_REBOOT, 0&) 'restart the computer
                                    basDelay 1000
                                    subSendMsg "&gWIN XP/7 ISSUED: lResult = ExitWindowsEx(EWX_REBOOT, 0&)", zPortID
                                    basDelay 5000
                                    End
                                Else
                                    subSendMsg "&RNOT ISSUED [IL98+ or RebootAllowed flag]: lResult = ExitWindowsEx(EWX_REBOOT, 0&)", zPortID
                                End If
                            '=========================== SQL COMMANDS - start
                            Case "FIEL"
                                If (Len(zWord2) = 0) Then
                                    subSendMsg "&gSyntax: IMMO FIELDS TABLENAME" & vbCrLf & "See Also: IMMO TABLE", zPortID
                                Else
                                    subTableShowFields zPortID, zWord2
                                End If
                            Case "TABL", "TBL"
                                If (Len(zWord2) = 0) Then
                                    subSendMsg "&gSyntax: IMMO TABLE LIST" & vbCrLf & "        IMMO TABLE FIELDS TABLENAME" & vbCrLf & "See Also: IMMO FIELDS TABLENAME", zPortID
                                Else
                                    Select Case Mid(zWord2, 1, 4)
                                        Case "FIEL", "VARI"
                                            subTableShowFields zPortID, zWord3
                                        Case Else
                                            subTableShowNames zPortID
                                    End Select
                                End If
                            Case "SQL"
                                If (lImmortalLevel > 99) Then
                                    subRunSQL zDropFirstWordCleanLine(zPromptOriginal), zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            '=========================== SQL COMMANDS - end
                            Case "TELN"
                                subSetSettingsConfigMUDTelnet zWord2, zPortID
                            Case "ABDU"
                                subUFOAbduction 1, True
                            Case "LEAP", "LURC", "BECO"
                                subSafariBecon 1, True
                                subSafariLeap 1, True
                            Case "IMM1"
                                subSetSettingsConfigImmortalNames zWord2, 1, zPortID
                            Case "IMM2"
                                subSetSettingsConfigImmortalNames zWord2, 2, zPortID
                            Case "IMM3"
                                subSetSettingsConfigImmortalNames zWord2, 3, zPortID
                            Case "IMM4"
                                subSetSettingsConfigImmortalNames zWord2, 4, zPortID
                            Case "MUD"
                                subSetSettingsConfigMUDName zWord2, zPortID
                            Case "URL", "HOME"
                                subSetSettingsConfigHomepage zWord2, zPortID
                            Case "EMAI"
                                subSetSettingsConfigEmail zWord2, zPortID
                            Case "RAID"
                                subChanceForARaid 1
                            Case "AE", "AELE", "AE", "AEL", "RE", "RELE" 'area room elemental
                                subRoomAreaElementalTraps zPortID, lX, lY, lZ, zWord2, zWord3, zPromptOriginal
                            Case "HINT"
                                subShowStargateMagicWordAreaLocHints "[CREATED WITH command IMMO HINT]", zPortID
                            Case "CREA" 'creator of mobs in the area need a word give by immortal
                                subCreatorMobGroup zPortID, zWord2, zPromptOriginal
                            Case "SMEA"
                                If (lImmortalLevel > 99) Then
                                    subSmeagolAnkhs 1
                                    subSendMsg "&RSmeagols sent!", zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "HEAL" 'refresh, reset, heal
                                If (lImmortalLevel > 99) Then
                                    subSeeIfRealmHealsEveryone 1
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "WORM"
                                If (lImmortalLevel > 99) Then
                                    subCreateWormHole lX, lY, lZ, zWord2, zWord3, zWord4, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "IGNO"
                                subImmortalForcesPlayersIgnore zWord2, zWord3, zPortID
                            Case "BOUN"
                                subClearBountyLog zPortID
                            Case "CRAF" 'transmute
                                subMobCraftingTransmutingEditor zWord2, zWord3, zWord4, zPromptOriginal, lX, lY, lZ, lPlayerID, zPortID
                            Case "EEC" 'Edit Emote Chart
                                subEditEmoteChart zWord2, zWord3, zPromptOriginal, zPortID
                            Case "MSE"
                                subMobSpeakEditor zWord2, zWord3, zWord4, zPromptOriginal, zPortID
                            Case "MQE"
                                subMobQuestEditor zWord2, zWord3, zWord4, zPromptOriginal, zPortID
                            Case "MEP"
                                subMobEmotePlayerEditor zWord2, zWord3, zWord4, zPromptOriginal, zPortID
                            Case "MQHE"
                                subMobQuestHerdEditor zWord2, zWord3, zWord4, zPromptOriginal, zPortID
                            Case "MPE"
                                subMobPhraseEditor zWord2, zWord3, zWord4, zPromptOriginal, zPortID
                            Case "HELP", "EHS"
                                subHelpEditor zWord2, zWord3, zPromptOriginal, zPortID
                            Case "COPY", "MCOP" 'mob copy IMMO MCOPY MOBID
                                subMobCopy zWord2, zPortID, lX, lY, lZ
                            Case "CR" 'clan rename - rename old clanname newclanname
                                subImmortalClanRename zWord2, zWord3, zPortID
                            Case "MW", "WORD", "STAR", "SECR"
                                subReportSecretWords zPortID
                            Case "HOUS"
                                subCreatePlayerHouse zPortID, zWord2
                            Case "VOTE"
                                Select Case Mid(zWord2, 1, 4)
                                    Case "ABST", "FORC", "QUIC" 'force quick abstain
                                        If (gbllVoteDuration > 3) Then
                                            gbllVoteDuration = 3
                                            subSendMsg "&wVote was forced to end quickly.", zPortID
                                        Else
                                            If (gbllVoteDuration = 0) Then
                                                subSendMsg "&wThere is nothing running at the polls.", zPortID
                                            Else
                                                subSendMsg "&wVote duration was already forced to three rounds.", zPortID
                                            End If
                                        End If
                                    Case "LIST"
                                        For iPort = cstlMinPort To cstlMaxPort
                                            If (lngSQLRecordCount("SELECT PortID FROM tblPlayerLoggedIn WHERE (PortID='" & MyCStr(iPort) & "');") > 0) Then 'is this player connected
                                                Select Case gblzVoteCasted(iPort)
                                                    Case ""
                                                        subSendMsg "&wPort " & iPort & " - " & zPlayerNameByPortID(MyCStr(iPort)) & " has not voted.", zPortID
                                                End Select
                                            End If
                                        Next iPort
                                    Case "CLEA"
                                        gblzVoteTopic = ""
                                        gbllVoteDuration = 0
                                        subSendMsg "&gVote system and previous vote was cleared.", zPortID
                                    Case "STOP", "PAUS"
                                        gbllVoteDuration = 0
                                        subSendMsg "&gVote system stopped - previous vote was retained.", zPortID
                                    Case Else
                                        If (Len(zWord3) > 0) Then
                                            gblzVoteTopic = zPromptOriginal
                                            gblzVoteTopic = zDropFirstWordCleanLine(gblzVoteTopic)
                                            If (Len(gblzVoteTopic) > 0) Then
                                                gbllVoteDuration = 32
                                                subVoteClear
                                                subSimpleEchoChannel "&WYou can now vote on a new topic...cast your vote now." & vbCrLf & "&aY o u r  v o t e  c o u n t s  t o o!&w" & vbCrLf & gblzVoteTopic
                                            Else
                                                gbllVoteDuration = 0
                                            End If
                                        End If
                                End Select
                                
                                subSendMsg "&gSYNTAX: IMMO VOTE MESSAGE/CLEAR/STOP/FORCE QUICK END", zPortID
                            Case "COLO"
                                subMakePrimitivesArea zPortID
                            Case "GUES"
                                Select Case Mid(zWord3, 1, 4)
                                    Case "DELE"
                                        subGuessWordMaintenance zWord2, "D", zPortID
                                    Case "LIST", "DICT" 'shows the word and number of uses
                                        subGuessWordMaintenance zWord2, "L", zPortID
                                    Case "RAND"
                                        subGuessWordRandomize 1
                                    Case Else
                                        subClearGuessWord
                                        subSendMsg "&RGuess the Word Game is now cleared.", zPortID
                                End Select
                                subSendMsg "&GIMMO GUESS WORD [DELETE/LIST/RANDOM RANDOM].", zPortID
                            Case "PASS" 'Set player password
                                If (lImmortalLevel > 99) Then
                                    subRoomPlayerSetPassword zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "GOLD" 'Set player's gold
                                If (lImmortalLevel > 99) Then
                                    subRoomPlayerSetGold zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "DEAT" 'Set player deaths
                                If (lImmortalLevel > 99) Then
                                    subRoomPlayerSetDeaths zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "XP", "EXPE" 'Set player xp
                                If (lImmortalLevel > 99) Then
                                    subRoomPlayerSetXP zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "RENA", "NAME"
                                If (Len(zWord2) > 0) Then
                                    subRoomPlayerRename zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&gSYNTAX: IMMO RENAME OLDNAME NEWNAME" & vbCrLf & "See Also: immo name testname", zPortID
                                End If
                            Case "PLAY"
                                If (Len(zWord2) > 0) Then
                                    If (bAllowNewPlayerName(zWord2, zPortID)) Then
                                        subSendMsg "&G" & UCase(zWord2) & " is a valid name!", zPortID
                                    Else
                                        subSendMsg gblzFBRED & UCase(zWord2) & " is an invalid name!", zPortID
                                    End If
                                Else
                                    subSendMsg "&gSYNTAX: IMMO PLAYERNAME TESTNAME" & vbCrLf & "See Also: immo playername oldname newname", zPortID
                                End If
                            Case "REMO" 'we delete matching remote host ips
                                subImmortalRemoteHost zWord2, zPortID
                            Case "FORC" 'force a player to do something
                                gblbTiming = False
                                subImmortalForce zPortID, zWord2, zCleanChatMessage(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1)), lImmortalLevel
                            Case "FLAG" 'Marks one item in inventory as a flag.
                                If (lImmortalLevel > 99) Then
                                    subImmortalFlag zWord2, zPortID, lImmortalLevel
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "RARE" 'this will clear out the inventory except for rares out of the person's inventory
                                If (lImmortalLevel > 99) Then
                                    subImmortalInventory zWord2, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "MAGI" 'set area magicword
                                If (lImmortalLevel > 99) Then
                                    subRoomMagicWord zPortID, lX, lY, lZ, zWord2
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "FLY" 'set fly toggle
                                subRoomFlyZoneToggle zPortID, lX, lY, lZ
                            Case "UNDE" 'set underwater level
                                subRoomWaterZoneToggle zPortID, lX, lY, lZ, zWord2
                            Case "HEIG", "CEIL" 'set room height level
                                subRoomHeightZoneToggle zPortID, lX, lY, lZ, zWord2
                            Case "COMP"
                                subSystemWideUnDoCompleteBanByDate
                                If (lImmortalLevel > 99) Then
                                    subLoginEditRemoveCompletelyBannedIP zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "HOST"
                                If (lImmortalLevel > 99) Then
                                    subAddColonistHostileForces 1
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "SPAC", "STAR"
                                If (lImmortalLevel > 20) Then
                                    subStarshipMobshipQuest 1
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "TITL", "PTIT" 'set who title
                                subImmortalSetEnterExitMsg zWord2, zPromptOriginal, "TITLE", zPortID, lImmortalLevel
                            Case "DESC" 'clear player description
                                subImmortalSetEnterExitMsg zWord2, zPromptOriginal, "DESC", zPortID, lImmortalLevel
                            Case "DATE", "LAST" 'set LastEnterDate
                                If (lImmortalLevel > 99) Then
                                    subImmortalSetEnterExitMsg zWord2, zPromptOriginal, "DATE", zPortID, lImmortalLevel
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "ENTE" 'set enter message
                                subImmortalSetEnterExitMsg zWord2, zPromptOriginal, "ENTER", zPortID, lImmortalLevel
                            Case "EXIT" 'set exit message
                                subImmortalSetEnterExitMsg zWord2, zPromptOriginal, "EXIT", zPortID, lImmortalLevel
                            Case "LOCK"
                                subImmortalReturnPlayerIDPortLock zWord2, zWord3, zPortID, True
                            Case "UNLO"
                                subImmortalReturnPlayerIDPortLock zWord2, zWord3, zPortID, False
                            Case "SHAD"
                                subImmortalSetShadowLevel zWord2, zWord3, zPortID
                            Case "OFIX"
                                subGroundObjectFix lX, lY, lZ, zPortID
                            Case "HALL", "HULL", "WEED" 'hallucinate then ask them to LOOK :D
                                subImmortalSetHallucinateLevel zWord2, zWord3, zPortID
                            Case "SCAR" 'scare
                                If (lImmortalLevel > 99) Then 'Level to use
                                    subImmortalSetScareLevel zWord2, zWord3, zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "ASSI"
                                If (lImmortalLevel > 99) Then
                                    strImmortalAssignRadiusPlayer zWord2, zWord3, lX, lY, lZ, zPortID 'immo Assign playername
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "TRAN"
                                strImmortalTransportPlayer zWord2, MyCStr(zWord3 & " " & zWord4), lWhereID, lX, lY, lZ, zPortID  'immo trans playername [areaname/playername]
                            Case "AUCT"
                                Select Case Mid(zWord2, 1, 4)
                                    Case "LIST" 'see whoes bidding and selling
                                        subImmortalStopAuction zPortID, "L"
                                    Case "STOP"
                                        subImmortalStopAuction zPortID, "S"
                                    Case Else
                                        subSendMsg "&gIMMO AUCTION [LIST/STOP]", zPortID
                                End Select
                            Case "SG", "GS", "GSIL"
                                subImmortalSilence zWord2, "SG", zPortID
                            Case "SR", "RS", "RSIL"
                                subImmortalSilence zWord2, "SR", zPortID
                            Case "EXPL" 'exploits search
                                subSystemReportTotalExploits zPortID
                            Case "RANK", "INDU"
                                subImmortalRankPlayer zWord2, zWord3, zWord4, zPortID, lImmortalLevel, lPlayerID
                            Case "SPY1"
                                If (lImmortalLevel >= 98) Then 'Level to use
                                    If (MyCLng(zWord2) <> 0) Then
                                        gblzPortSpy1(MyCLng(zPortID)) = zWord2 'immortal at his port has spying trained on the PortID/zWord2
                                        subSendMsg "&MPort spy1: Port #" & zWord2 & " now being spied.", zPortID
                                    Else
                                        gblzPortSpy1(MyCLng(zPortID)) = ""
                                        subSendMsg "&mYour port spy1 is now disabled.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gHuh?", zPortID
                                End If
                            Case "SPY2"
                                If (lImmortalLevel >= 98) Then 'Level to use
                                    If (MyCLng(zWord2) <> 0) Then
                                        gblzPortSpy2(MyCLng(zPortID)) = zWord2 'immortal at his port has spying trained on the PortID/zWord2
                                        subSendMsg "&MPort spy2: Port #" & zWord2 & " now being spied.", zPortID
                                    Else
                                        gblzPortSpy2(MyCLng(zPortID)) = ""
                                        subSendMsg "&mYour port spy2 is now disabled.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gHuh?", zPortID
                                End If
                            Case "MEDI", "TAG", "MTAG", "TAGM"
                                subForgeMobTag zWord2, zPortID
                            Case "AREN"
                                If (gblbArenaOnOff = 1) Then
                                    gblbArenaOnOff = 0
                                    subSendMsgInfoChannel "&GPlayer Arena Offline!"
                                Else
                                    gblbArenaOnOff = 1
                                    subSendMsgInfoChannel "&RPlayer Arena Online!"
                                End If
                            Case "STUN", "KILL", "STOP", "CLOS"
                                If (Len(MyCStr(zWord2 & " " & zWord3 & " " & zWord4)) > 0) Then
                                    subShutdownPorts zWord2, zWord3, zWord4
                                    subSendMsg "&R-Port Closed-", zPortID
                                    subSystemReportPortList zPortID, lImmortalLevel
                                Else
                                    subSendMsg "&gSyntax: IMMO KILL 2011 2012 2013", zPortID
                                End If
                            Case "NEVE"
                                subTogglePlayerNeverBan zWord2, zPortID
                            Case "UNBA"
                                subBanUnbanRemoteHostIP zWord2, False, zPortID
                            Case "BAN"
                                subBanUnbanRemoteHostIP zWord2, True, zPortID
                            Case "FIRE"
                                subImmortalSpellZAPPlayer zWord2, 1, zPortID
                            Case "BOLT"
                                subImmortalSpellZAPPlayer zWord2, 2, zPortID
                            Case "HEAV"
                                subImmortalSpellZAPPlayer zWord2, 3, zPortID
                            Case "HELL"
                                subImmortalSpellZAPPlayer zWord2, 4, zPortID
                            Case "CLAS", "WORL"
                                subSystemReportPlayerData zPortID
                            Case "IP"
                                subSystemReportRemoteHostIP zPortID, lImmortalLevel
                            Case "LIVE"
                                subSystemReportShowLivePorts zPortID, lImmortalLevel
                            Case "SITT", "ACTI"
                                'subSystemReportPortSitting zPortID, lImmortalLevel
                                subSystemReportPortSittingLoop zPortID, lImmortalLevel
                            Case "PORT"
                                subSystemReportPortList zPortID, lImmortalLevel
                            Case "RR" 'Room Area Rules
                                subAreaRules zPortID, lImmortalLevel, lPlayerID, zWord2, lX, lY, lZ
                            Case "MAPA" 'Mobile Add Path
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                    If (Len(zPromptMessage) <> 0) Then
                                        subMobArchitecturePath zPortID, zPlayerName, lX, lY, lZ, lImmortalLevel, zPromptMessage, "ADD"
                                    Else
                                        subSendMsg "&GCOMMAND: MAPA MOBID" & vbCrLf & "see also: MDPA and MLPA", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MLPA" 'Mobile List Path
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                    If (Len(zPromptMessage) <> 0) Then
                                        subMobArchitecturePath zPortID, zPlayerName, lX, lY, lZ, lImmortalLevel, zPromptMessage, "ALL"
                                    Else
                                        subSendMsg "&GCOMMAND: MDPA (full mobile name)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MDPA" 'Mobile Delete Path
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                    If (Len(zPromptMessage) <> 0) Then
                                        subMobArchitecturePath zPortID, zPlayerName, lX, lY, lZ, lImmortalLevel, zPromptMessage, "DEL"
                                    Else
                                        subSendMsg "&GCOMMAND: MDPA (full mobile name)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "TDES" 'Area Track modify destination X Y Z
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    subAreaArchitectureTransitDestXYZ zPortID, lX, lY, lZ, MyCLng(zWord2), MyCLng(zWord3), MyCLng(zWord4)
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "TDPA" 'Area Track delete path
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (zWord2 = "@DELAREATRANSIT@") Then
                                        subAreaArchitectureTransit zPortID, lX, lY, lZ, "DEL"
                                    Else
                                        subSendMsg "&GCOMMAND: TDPA (confirm word)     - password is @DELAREATRANSIT@", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "TAPA" 'Area Track add path
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (zWord2 = "@ADDAREATRANSIT@") Then
                                        subAreaArchitectureTransit zPortID, lX, lY, lZ, "ADD"
                                    Else
                                        subSendMsg "&GCOMMAND: TAPA (confirm word)     - password is @ADDAREATRANSIT@", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MAPT" 'Toggles if area is available on the map
                                subToggle11x11Map zPortID, lX, lY, lZ
                                subShow11x11Map zPortID
                            Case "OC" 'Object Creation
                                If (Len(zWord2) > 0) Then
                                    subObjectArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lCrown, lImmortalLevel, lX, lY, lZ, "OC", "DWA"
                                Else
                                    subSendMsg "&gSyntax: OC (object name)", zPortID
                                End If
                            Case "OD", "EAT" 'Object Delete
                                If (Len(zWord2) > 0) Then
                                    subObjectArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lCrown, lImmortalLevel, lX, lY, lZ, "OD", "DWA"
                                Else
                                    subSendMsg "&gSyntax: OD (object name)", zPortID
                                End If
                            Case "OTCF" 'Object toggle colour format
                                If (Len(zWord2) > 0) Then
                                    subObjectArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lCrown, lImmortalLevel, lX, lY, lZ, "OTCF", "DWA"
                                Else
                                    subSendMsg "&gSyntax: OTCF (object name)", zPortID
                                End If
                            Case "OTYP" 'Set Object Type - (SBLA) Short blades etc...
                                subObjectArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lCrown, lImmortalLevel, lX, lY, lZ, "OTYP", "DWA"
                            Case "OAVG" 'Average damage
                                subObjectArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lCrown, lImmortalLevel, lX, lY, lZ, MyCStr(zWord1), "DWA"
                            Case "OWEI", "OLOC" 'location on the body, 20 is the hands for weapons
                                subObjectArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lCrown, lImmortalLevel, lX, lY, lZ, MyCStr(zWord1), "DWA"
                            Case "CLOG" 'Create log for all imms to see
                                If (lImmortalLevel >= 5) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        subLogCreate zPortID, "TO ALL IMMORTALS, FROM: " & UCase(zPlayerName) & ", " & zPlayerTitle & vbCrLf & zCleanChatMessage(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1)) & vbCrLf & "reported from " & lX & " " & lY & " " & lZ & " " & Format(Now(), "mmm dd, yyyy hh:nn AMPM"), lX, lY, lZ
                                    Else
                                        subSendMsg "&gSyntax: CLOG (message)" & vbCrLf & "See Also: DLOG [number]" & vbCrLf & "See Also: VLOG [How Many or ALL of them]", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL10: You are not ready for that path my child!", zPortID
                                End If
                            Case "VLOG"
                                If (lImmortalLevel >= 10) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        subLogView zPortID, zWord2
                                    Else
                                        subSendMsg "&gSyntax: VLOG [How Many or ALL]", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL10: You are not ready for that path my child!", zPortID
                                End If
                            Case "DLOG"
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        subLogDelete zPortID, zWord2
                                    Else
                                        subSendMsg "&gSyntax: DLOG [number]     - deletes a log!", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "GCRO", "GGLO" 'Give 1 - 15 crowns/glory to person.
                                If (lImmortalLevel >= 98) Then 'Level to use
                                    If (MyCLng(zWord2) > 0 And MyCLng(zWord2) < 16) Then
                                        subGiveGloryPerson zPortID, zPlayerName, zWord3, MyCLng(zWord2)
                                    Else
                                        If (MyCLng(zWord2) < 0) Then
                                            subSendMsg "&Y" & "You cannot take glory away.", zPortID
                                        Else
                                            subSendMsg "&GCOMMAND: GCROWNS (1 to 15) (person)", zPortID
                                        End If
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL98: You are not ready for that path my child!", zPortID
                                End If
                            Case "GALL", "CALL" 'Give glory to all logged on
                                If (lImmortalLevel >= 99) Then 'Level to use
                                    If (MyCLng(zWord2) > 0 And MyCLng(zWord2) < 6) Then
                                        MyDB.Execute "UPDATE tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PlayerName = tblPlayerLoggedIn.PlayerName SET tblPlayer.Crown = [Crown]+" & MyCLng(zWord2) & ";", dbFailOnError
                                        'subSendMsgAll "", gblzFBWHI, "", zPlayerName & gblzFBMAG & " is pleased with the realm." & vbCrLf & "&WYou receive " & MyCLng(zWord2) & " crown(s).", zPortID, 0
                                        Select Case MyCLng(zWord2)
                                            Case 0
                                                subSendMsgInfoChannel "&M" & zPlayerName & " gives everyone a hug instead!"
                                            Case 1
                                                subSendMsgInfoChannel "&w" & zPlayerName & " gives everyone one crown of glory!"
                                            Case Else
                                                subSendMsgInfoChannel "&w" & zPlayerName & " gives everyone " & MyCLng(zWord2) & " crowns of glory!"
                                        End Select
                                    Else
                                        If (MyCLng(zWord2) < 0) Then
                                            subSendMsg "&Y" & "You cannot take glory away.", zPortID
                                        Else
                                            subSendMsg "&GCOMMAND: GALL (1 to 5)", zPortID
                                        End If
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL99: You are not ready for that path my child!", zPortID
                                End If
                            Case "RXYZ" 'Set Room XYZ teleport destination
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (Len(zWord2) > 0 And Len(zWord3) > 0 And Len(zWord4) > 0) Then
                                        subAreaModificationDXYZActive zPortID, lX, lY, lZ, MyCLng(zWord2), MyCLng(zWord3), MyCLng(zWord4), "UPDATE XYZ"
                                    Else
                                        subSendMsg "&GSyntax: RXYZ X Y Z" & vbCrLf & "See Also: RTDT", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90 - ROOM TELEPORT TOGGLE: You are not ready for that path my child!", zPortID
                                End If
                            Case "RTDT" 'Room XYZ teleport destination toggle
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (zWord2 = "@TOGGLEPOD@") Then
                                        subAreaModificationDXYZActive zPortID, lX, lY, lZ, MyCLng(zWord2), MyCLng(zWord3), MyCLng(zWord4), "TOGGLE"
                                        subSendMsg "&g* When you toggle a pod to an object use also IMMO RBC command." & vbCrLf & "  This allows a user to touch an object to activate an IMMO RXYZ teleportation.", zPortID
                                    Else
                                        subSendMsg "&GSyntax for Room Teleportation Destination Toggle: RTDT (confirm word)            - confirm word is @TOGGLEPOD@" & vbCrLf & "See Also: RXYZ X Y Z", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90 - ROOM TELEPORT TOGGLE: You are not ready for that path my child!", zPortID
                                End If
                            Case "RC" 'Room Creation
                                If (MyCInt(lImmortalLevel) >= 90) Then 'Level to use
                                    If (Not bCheckDoorExists(zPortID, lX, lY, lZ)) Then
                                        If (Not bCheckAreaExists(zPortID, lX, lY, lZ, True)) Then
                                            subAreaArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lX, lY, lZ, "RC"
                                        Else
                                            subSendMsg "&RAn area already exists at this location." & vbCrLf & "&GSee Also: Room Delete - RD (room name)", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RA door already exists at this location." & vbCrLf & "&GSee Also: Door Delete - DD (door name)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MDES" 'Mobile Description - if you change this name command you have to change 6 to seomthing else
                                If (lImmortalLevel >= 40) Then 'Level to use
                                    If (InStr(zPromptOriginal, "|") <> 0) Then
                                        zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, "|") + 1))
                                        If (Len(zPromptMessage) <> 0) Then
                                            subMobArchitectureDesc zPortID, lX, lY, lZ, basRemoveChr1310(Mid(zPromptOriginal, 6, InStr(zPromptOriginal, "|") - 6)), zPromptMessage
                                        Else
                                            subSendMsg "&GCOMMAND: MDES (full mobile name)|(description)" & vbCrLf & "The bar | separates the mobile name and mobile description." & vbCrLf & "EXAMPLE: MDES Maximus, is here holding a sword high|the description goes here", zPortID
                                        End If
                                    Else
                                        subSendMsg "&GCOMMAND: MDES (full mobile name)|(description)" & vbCrLf & "The bar | separates the mobile name and mobile description." & vbCrLf & "EXAMPLE: MDES Maximus, is here holding a sword high|the description goes here", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "RBCD" 'Delete RBC
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (zWord2 = "@RBCDELETE@") Then
                                        MyDB.Execute "DELETE X, Y, Z FROM tblAreaBlockedPath WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
                                        subSendMsg "&WYour &Ymagical energy " & "&Rremoves &WRBC power from the area.", zPortID
                                    Else
                                        subSendMsg gblzFBCYA & "Syntax: RBCD @RBCDELETE@", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "TYPE"
                                If (lImmortalLevel > 99) Then
                                    subRoomPlayerTypeZoneToggle zPortID, lX, lY, lZ, zWord2, zWord3
                                Else
                                    subSendMsg gblzFBCYA & "IL100: You are not ready for that path my child!", zPortID
                                End If
                            Case "CLAN"
                                subRoomClanZoneToggle zPortID, lX, lY, lZ, zWord2
                            Case "QUES"
                                subRoomQuestZoneToggle zPortID, lX, lY, lZ
                            Case "FLEE"
                                subRoomFleeZoneToggle zPortID, lX, lY, lZ
                            Case "RBC" 'Make RBC
                                subRoomBlockConstruct zPortID, zPlayerName, zPromptOriginal, lX, lY, lZ, lImmortalLevel
                                subSendMsg "&gNote: RBCD @RBCDELETE@ to remove a Room Block Contruct from an area." & vbCrLf & "&gCONTROL" & vbCrLf & "PRESS MOVE PULL PUSH SEARCH SHOVE SPIN SWING TAP TOUCH TUG TURN TWIST ENTER EXIT", zPortID
                            Case "RB" 'Room blockage dir +/-
                                If (lImmortalLevel >= 80) Then 'Level to use
                                    If (bAmong(zWord2, "N", "S", "E", "W", "NE", "NW", "SE", "SW", "U", "D")) Then
                                        If (bAmong(zWord3, "-", "+")) Then
                                            subAreaArchitecturePort zPortID, zWord2, lX, lY, lZ, zWord3, "RB"
                                            Select Case zWord3
                                                Case "+"
                                                    subSendMsg "&MOne Way Blockage: Quark Gluon Plasma sprays from your finger!" & vbCrLf & "&BA portal has been opened to the " & zTranslateDirection(zWord2, 0), zPortID
                                                Case "-"
                                                    subSendMsg "&MOne Way Blockage: Quark Gluon Plasma sprays from your finger!" & vbCrLf & "&WA portal has been closed to the " & zTranslateDirection(zWord2, 0), zPortID
                                            End Select
                                            subSendMsg "&GCOMMAND: RB - Successful!", zPortID
                                        Else
                                            subSendMsg "&GSyntax: RB [n,s,e,w,ne,nw,se,sw,u,d] [-,+]", zPortID
                                        End If
                                    Else
                                        subSendMsg "&GSyntax: RB [n,s,e,w,ne,nw,se,sw,u,d] [-,+]", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL80 - MOVE PORTAL: You are not ready for that path my child!", zPortID
                                End If
                            Case "RH" 'Room hidden dir +/-
                                If (lImmortalLevel >= 80) Then 'Level to use
                                    If (bAmong(zWord2, "N", "S", "E", "W", "NE", "NW", "SE", "SW", "U", "D")) Then
                                        If (bAmong(zWord3, "-", "+")) Then
                                            subAreaArchitecturePort zPortID, zWord2, lX, lY, lZ, zWord3, "RH"
                                            subAreaArchitecturePort zPortID, zWord2, lX, lY, lZ, zWord3, "RB"
                                            Select Case zWord3
                                                Case "+"
                                                    subSendMsg "&MHidden Quark Gluon Plasma sprays from your finger!" & vbCrLf & "&BA portal has been opened to the " & zTranslateDirection(zWord2, 0), zPortID
                                                Case "-"
                                                    subSendMsg "&MHidden Quark Gluon Plasma sprays from your finger!" & vbCrLf & "&WA portal has been closed to the " & zTranslateDirection(zWord2, 0), zPortID
                                            End Select
                                            subSendMsg "&GCOMMAND: RH - Successful!", zPortID
                                        Else
                                            subSendMsg "&GSyntax: RH [n,s,e,w,ne,nw,se,sw,u,d] [-,+]", zPortID
                                        End If
                                    Else
                                        subSendMsg "&GSyntax: RH [n,s,e,w,ne,nw,se,sw,u,d] [-,+]", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL80 - MOVE PORTAL: You are not ready for that path my child!", zPortID
                                End If
                            Case "RD" 'Room delete
                                If (lImmortalLevel >= 99) Then 'Level to use
                                    If (bAmong(zWord2, "@DELETESPOT@")) Then 'Deletes the spot password the imm is standing upon.
                                        subAreaArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lX, lY, lZ, "RD"
                                    Else
                                        subSendMsg "&GSyntax: RD (confirm word)            - the confirm word is @DELETESPOT@", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90 - ROOM DELETE: You are not ready for that path my child!", zPortID
                                End If
                            Case "RN" 'Room Desctipion Name (port in)
                                If (lImmortalLevel >= 10) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        subAreaArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lX, lY, lZ, "RN"
                                        subSendMsg "&gSee Also: IMMO RDD/RDN and IMMO WAPP to finish off this room.", zPortID
                                    Else
                                        subSendMsg "&GSyntax: RN (area room name)", zPortID
                                    End If
                                    subSendMsg "&mFor a faster calculated 'Quick Exits:' use IMMO DYNAMIC YES/NO" & vbCrLf & "yes means Exits do not realtime calculate to be used in areas" & vbCrLf & "that do not have changing exits in the room. eg." & vbCrLf & "Switch objects that open EAST and close EAST" & vbCrLf & "you do -NOT- want that room to be a dynamic room.", zPortID
                                Else
                                    subSendMsg gblzFBCYA & "IL70: You are not ready for that path my child!", zPortID
                                End If
                            Case "WDEL" 'Room - Delete Where Description
                                If (lImmortalLevel >= 99) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                        subAreaArchitectureWhereDelete zPortID, zPlayerName, lX, lY, lZ, zPromptMessage
                                    Else
                                        subSendMsg "&GSyntax: WDEL (full area where description)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL99: You are not ready for that path my child!", zPortID
                                End If
                            Case "WAPP", "WDES", "WUSE" 'Room - Apply Where Description - use where desc etc
                                subAreaArchitectureWhereApply zPortID, zPlayerName, lX, lY, lZ, lImmortalLevel, basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                subSendMsg "&mFor a faster calculated 'Quick Exits:' use IMMO DYNAMIC YES/NO" & vbCrLf & "yes means Exits do not realtime calculate to be used in areas" & vbCrLf & "that do not have changing exits in the room. eg." & vbCrLf & "Switch objects that open EAST and close EAST" & vbCrLf & "you do -NOT- want that room to be a dynamic room.", zPortID
                            Case "WADD", "WNEW" 'Room - Add Where Description
                                If (lImmortalLevel >= 10) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                        subAreaArchitectureWhereAdd zPortID, zPlayerName, lX, lY, lZ, zPromptMessage
                                    Else
                                        subSendMsg "&GSyntax: WDES (area where description)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL70: You are not ready for that path my child!", zPortID
                                End If
                            Case "SPEL", "RSP" 'Room spell checker
                                If (bAreaSpellCheck(lX, lY, lZ, zPortID)) Then
                                End If
                            Case "WHER"
                                subAreaMobObjectID lX, lY, lZ, zPortID, True
                            Case "RALL", "ALL", "AREA", "ROOM"
                                subSendMsg "&w        IMMO RR             (will show you all the rules set to the area)", zPortID
                                subAreaMobObjectID lX, lY, lZ, zPortID, False
                                subAreaDesc 0, 0, zPortID, lX, lY, lZ, lPlayerLevel, 0, 0, 0, "", "", "11111", 0, 1, bStatusBM, bStatusGUID, "BOTH"
                            Case "RDD" 'Room Desctipion Day
                                If (lImmortalLevel >= 10) Then 'Level to use
                                    bShow = True
                                    If (Len(zWord2) <> 0) Then
                                        subAreaArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lX, lY, lZ, "RDD"
                                    Else
                                        subSendMsg "&GSyntax: RDD (description)", zPortID
                                    End If
                                    subSendMsg "&mFor a faster calculated 'Quick Exits:' use IMMO DYNAMIC YES/NO" & vbCrLf & "yes means Exits do not realtime calculate to be used in areas" & vbCrLf & "that do not have changing exits in the room. eg." & vbCrLf & "Switch objects that open EAST and close EAST" & vbCrLf & "you do -NOT- want that room to be a dynamic room.", zPortID
                                Else
                                    subSendMsg gblzFBCYA & "IL70: You are not ready for that path my child!", zPortID
                                End If
                            Case "RND", "RDN" 'Room Desctipion Night
                                If (lImmortalLevel >= 10) Then 'Level to use
                                    bShow = True
                                    If (Len(zWord2) <> 0) Then
                                        subAreaArchitecture zPortID, zPromptOriginal, zPlayerName, lPlayerID, lX, lY, lZ, "RND"
                                    Else
                                        subSendMsg "&GSyntax: RND (description)", zPortID
                                    End If
                                    subSendMsg "&mFor a faster calculated 'Quick Exits:' use IMMO DYNAMIC YES/NO" & vbCrLf & "yes means Exits do not realtime calculate to be used in areas" & vbCrLf & "that do not have changing exits in the room. eg." & vbCrLf & "Switch objects that open EAST and close EAST" & vbCrLf & "you do -NOT- want that room to be a dynamic room.", zPortID
                                Else
                                    subSendMsg gblzFBCYA & "IL70: You are not ready for that path my child!", zPortID
                                End If
                            Case "AMOV", "MOVE" 'AREA set MOVE points
                                subAreaSetMoveCost MyCLng(zWord2), zPortID, lX, lY, lZ
                            Case "JUMP" 'AREA set JUMP value
                                subAreaSetZoneJumpChance MyCLng(zWord2), zPortID, lX, lY, lZ
                            Case "DYNA" 'Toggle if area uses dynamic or static exits. Static is WAY faster.
                                subAreaSetExitsDynamicStaticToggle zWord2, zPortID, lX, lY, lZ, True
                            Case "ACHE", "CARE" 'AREA CHECK
                                If (lImmortalLevel >= 30) Then 'Level to use
                                    bCheckAreaExists zPortID, MyCLng(zWord2), MyCLng(zWord3), MyCLng(zWord4), True
                                Else
                                    subSendMsg gblzFBCYA & "IL30 - CHECK AREA: You are not ready for that path my child!", zPortID
                                End If
                            Case "DC" 'Door Create - doors are treated like areas because they affect areas.
                                bShow = True
                                If (Not bCheckDoorExists(zPortID, lX, lY, lZ)) Then
                                    If (Not bCheckAreaExists(zPortID, lX, lY, lZ, True)) Then
                                        subDoorArchitectureCreate zPortID, lPlayerID, lX, lY, lZ, basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                    Else
                                        subSendMsg "&RAn area already exists at this location." & vbCrLf & "&gSee Also: Room Delete - RD (room name)", zPortID
                                    End If
                                Else
                                    subSendMsg "&RA door already exists at this location." & vbCrLf & "&gSee Also: Door Delete - RD (door name)", zPortID
                                End If
                            Case "DD" 'Door delete
                                zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                If (Len(zPromptMessage) <> 0) Then
                                    subDoorArchitectureDelete zPortID, lX, lY, lZ, zPromptMessage
                                Else
                                    subSendMsg "&GCOMMAND: DD (door name)" & vbCrLf & "&gDD place the name of the door here", zPortID
                                End If
                            Case "DSTA" 'Door status = 0 = always open, 1 = locked, 2 = unlocked, 3 = lockable but open ... etc
                                If (Len(zWord2) <> 0) Then
                                    Select Case MyCLng(zWord2)
                                        Case 0 To 12
                                            If (bCheckDoorExists(zPortID, lX, lY, lZ)) Then
                                                subShowDoorStatus zPortID, lX, lY, lZ, MyCLng(zWord2)
                                            Else
                                                subSendMsg "&GThis command must be used in a door, there is no doorway here." & vbCrLf & "USE: TELE x y z      and then     IMMO DC (doorname with a comma-short-desc)", zPortID
                                            End If
                                        Case Else
                                            subSendMsg "&gSYNTAX: DSTA <value>" & vbCrLf & "<values> are: 0=Open" & vbCrLf & "              1=Unlocked but closed" & vbCrLf & "              2=Locked" & vbCrLf & "              3=open but is lock/pickable" & vbCrLf & "              4=not used" & vbCrLf & "              5=Bashed Open" & vbCrLf & "              6=Closed and not lockable" & vbCrLf & "              7=Bashed closed" & vbCrLf & "              8=Bashable" & vbCrLf & "              9=notused" & vbCrLf & "              10=magic open" & vbCrLf & "              11=magic closed" & vbCrLf & "              12=magically locked", zPortID
                                    End Select
                                Else
                                    subSendMsg "&gSYNTAX: DSTA <value>" & vbCrLf & "<values> are: 0=Open" & vbCrLf & "              1=Unlocked but closed" & vbCrLf & "              2=Locked" & vbCrLf & "              3=open but is lock/pickable" & vbCrLf & "              4=not used" & vbCrLf & "              5=Bashed Open" & vbCrLf & "              6=Closed and not lockable" & vbCrLf & "              7=Bashed closed" & vbCrLf & "              8=Bashable" & vbCrLf & "              9=notused" & vbCrLf & "              10=magic open" & vbCrLf & "              11=magic closed" & vbCrLf & "              12=magically locked", zPortID
                                End If
                            Case "DDES" 'Door Description - if you change this name command you have to change 6 to seomthing else
                                subDoorArchitectureDesc lX, lY, lZ, zPromptOriginal, zPortID
                            Case "DWIN" 'Door Window toggle
                                If (MyCInt(zWord2) > -1) Then
                                    subDoorArchitectureWindow zPortID, lX, lY, lZ, MyCInt(zWord2)
                                Else
                                    subSendMsg "&gSyntax: DWIN (window value 0 - 3)" & vbCrLf & "See Also: DSTATUS 0 - 5" & vbCrLf, zPortID
                                End If
                            Case "DLEV"
                                subDoorArchitectureLever lX, lY, lZ, zWord2, zPortID
                            Case "MREN" 'Mobile Rename
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (InStr(zPromptOriginal, "|") <> 0) Then
                                        zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, "|") + 1))
                                        If (lInStrOccurance(zPromptOriginal, ",", 2) > 0) Then 'is there a comma in the second name?
                                            If (Len(zPromptMessage) <> 0) Then
                                                subMobArchitectureRename zPortID, lX, lY, lZ, basRemoveChr1310(Mid(zPromptOriginal, 6, InStr(zPromptOriginal, "|") - 6)), zPromptMessage
                                            Else
                                                subSendMsg "&GCOMMAND: MREN (full mobile name)|(new name)" & vbCrLf & "The bar | separates the mobile name and mobile new name." & vbCrLf & "EXAMPLE: MREN Maximus, is here holding a sword high|Maxo, is a poor weak beggar", zPortID
                                            End If
                                        Else
                                            subSendMsg "&GCOMMAND: MREN (full mobile name)|(new name)" & vbCrLf & "The bar | separates the mobile name and mobile new name." & vbCrLf & "EXAMPLE: MREN Maximus, is here holding a sword high|Maxo, is a poor weak beggar" & vbCrLf & "Syntax Error - Comma Required: Maxo&Y, &Gis a poor weak beggar", zPortID
                                        End If
                                    Else
                                        subSendMsg "&GCOMMAND: MREN (full mobile name)|(new name)" & vbCrLf & "The bar | separates the mobile name and mobile new name." & vbCrLf & "EXAMPLE: MREN Maximus, is here holding a sword high|Maxo, is a poor weak beggar", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MC" 'Mobile Create
                                If (lImmortalLevel >= 40) Then 'Level to use
                                    If (Not bOdd(lZ)) Then
                                        If (InStr(zPromptOriginal, ",") <> 0) Then
                                            zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                                            If (Len(zPromptMessage) <> 0) Then
                                                subMobArchitectureCreate zPortID, lX, lY, lZ, zPromptMessage
                                            Else
                                                subSendMsg "&GCOMMAND: MC (full name[,] and a brief social)" & vbCrLf & "EXAMPLE: MC Maximus, is here holding a sword high", zPortID
                                            End If
                                        Else
                                            subSendMsg "&GCOMMAND: MC (full name[,] and a brief social)" & vbCrLf & "EXAMPLE: MC Maximus&Y, &Gis here holding a sword high" & vbCrLf & "&RViewing Standard: The comma MUST be placed after the full name of a mobile.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RYou may not create a mob on a odd plane that is reserved for up and down areas or trap doors only!", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MRES" 'Set Mobile respawn location
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (InStr(zPromptOriginal, ",") > 0) Then 'is there a comma in the second name?
                                        subMobArchitectureSetRespawnXYZ zPortID, lX, lY, lZ, zPromptOriginal
                                    Else
                                        subSendMsg "&GCOMMAND: MRES (full mobile)" & vbCrLf & "Your comma in the mobile name is missing.", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "DROP" 'forces the mob to drop the named item
                                If (lImmortalLevel >= 99) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        subMobDropObject zPortID, zPlayerName, lPlayerID, lX, lY, lZ, zWord2, zWord3
                                    Else
                                        subSendMsg "&GIMMO DROP (partial object name) (mobile ID)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL99: You are not ready for that path my child!", zPortID
                                End If
                            Case "MGIV" 'Give the mobile something - same object locations get overwritten
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    If (Len(zWord2) <> 0) Then
                                        subMobGiveObject zPortID, zPlayerName, lPlayerID, lX, lY, lZ, zWord2, zWord3
                                        'subVerifyMobEquipment 'yes it does all mobs in case, basRecalculateMobEquipment lMobID is more specific
                                    Else
                                        subSendMsg "&GMGIV (object ID) (mobile ID)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MQUE" 'Mobile Quest - you give an item to this mob to recieve a reward
                                If (lImmortalLevel >= 90) Then 'Level to use
                                    subMobArchitectureQuest zPortID, lX, lY, lZ, lPlayerID, zWord2, zWord3, zWord4
                                Else
                                    subSendMsg gblzFBCYA & "IL90: You are not ready for that path my child!", zPortID
                                End If
                            Case "MERG", "MERC" 'Give the mobile something to sell.
                                If (lImmortalLevel >= 99) Then 'Level to use
                                    If (Len(zWord2) <> 0 And Len(zWord3) And MyCLng(zWord4) > 0) Then
                                        subMobGiveObjectMerchant zPortID, zPlayerName, lPlayerID, lX, lY, lZ, zWord2, zWord3, zWord4
                                    Else
                                        subSendMsg "&GMERC (objectid) (mobileid) (value)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL99: You are not ready for that path my child!", zPortID
                                End If
                            Case "MD" 'Mobile Delete
                                If (lImmortalLevel >= 80) Then 'Level to use
                                    If (MyCLng(zWord2) <> 0) Then
                                        subMobArchitectureDelete lX, lY, lZ, MyCLng(zWord2), zPortID
                                    Else
                                        subSendMsg "&GCOMMAND: MD (mobileid)", zPortID
                                    End If
                                Else
                                    subSendMsg gblzFBCYA & "IL80: You are not ready for that path my child!", zPortID
                                End If
                            Case "SC", "SCM" 'SpeakControlMax
                                If (Len(zWord2) < 7) Then
                                    subSendMsg "&gSpeak Control Capping currently is set to " & gbllSpeakControlMax & ".", zPortID
                                    gbllSpeakControlMax = MyCLng(zWord2)
                                    subSendMsg "&GSpeak Control Capping now set to " & gbllSpeakControlMax & ". (40 is bootup default)", zPortID
                                Else
                                    subSendMsg "&RSpeak Control Capping not set!", zPortID
                                End If
                            Case "SAC", "SACR"
                                subSacrificeObjectsImmortal zPortID, zWord2
                            Case "PLAN", "CHES", "CONT"
                                If (lImmortalLevel > 99) Then
                                    subObjectPlantContainer zPortID, zWord2, zWord3, lPlayerID, lX, lY, lZ
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "NETW"
                                If (lImmortalLevel > 99) Then
                                    subEnableNetworkBanToggle zPortID, True
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "EQUI", "LOCA"
                                subSystemReportTotalItemGroup zPortID
                                subSendMsg "&gSee also: IMMO WEAPONTYPES", zPortID
                            Case "WEAP"
                                subReportItemTypes zPortID
                                subSendMsg "&gSee also: IMMO EQUIPMENTS", zPortID
                            Case "FIND"
                                If (lImmortalLevel > 99) Then
                                    subFindReplaceMemoTextDb zPortID, zPromptOriginal, True
                                    subSendMsg "&G.", zPortID
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "REPL"
                                If (lImmortalLevel > 99) Then
                                    If (Len(zWord4) = 0) Then
                                        subFindReplaceMemoTextDb zPortID, zPromptOriginal, False
                                        subSendMsg "&G.", zPortID
                                    Else
                                        subSendMsg "&gSYNTAX: IMMO REPLACE OLDWORD NEWWORD" & vbCrLf & "WARNING: You cannot undo this process once it is complete!", zPortID
                                    End If
                                Else
                                    subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                End If
                            Case "DTP" 'SET Dynamic Telnet Port
                                If (MyCLng(zWord2) = 0) Then
                                    subSendMsg "&RDynamic Telnet Port [" & zWord2 & "] is an invalid value!", zPortID
                                Else
                                    If (lImmortalLevel > 99) Then
                                        subSystemConfigDynamicPort zPortID, zWord2
                                    Else
                                        subSendMsg "&RIL100: You cannot perform that function.", zPortID
                                    End If
                                End If
                            Case "EVIL", "SKUL", "PVP"
                                If (gbllMoon <> -5) Then
                                    gbllMoon = -5
                                    subSimpleEchoChannel "&RA &Askull moon &Rfalls over the realm, hunting mode is on for all!"
                                    gblbArenaOnOff = 1 'arena online
                                Else
                                    gbllMoon = 0
                                    subSimpleEchoChannel "&rThe skull moon ends quickly!"
                                    gblbArenaOnOff = 0 'arena offline
                                End If
                                subSendMsg "&GSee Also: IMMO ECLIPSE", zPortID
                            Case "ECLI"
                                If (gbllMoon <> 5) Then
                                    gbllMoon = 5
                                    subSimpleEchoChannel "&AAn eclipse falls over the realm! 8)"
                                    gblbArenaOnOff = 1 'arena online
                                Else
                                    gbllMoon = 0
                                    subSimpleEchoChannel "&AThe eclipse ends sharply! :)"
                                    gblbArenaOnOff = 0 'arena offline
                                End If
                                subSendMsg "&GSee Also: IMMO EVIL", zPortID
                            Case "POOF"
                                subPoofPlayernameType zWord2, zWord3, zPortID, 0
                            Case "RESP"
                                subMobRespawnPointXYZ zWord2, lX, lY, lZ, zPortID
                            Case "EQ", "EART", "QUAK"
                                subEarthQuake 1
                            Case "KEY" 'make another key for this door
                                If (bCheckDoorExists("", lX, lY, lZ)) Then
                                    lGetDoorID = lDoorID(lX, lY, lZ)
                                    zGetDoorName = zShortstop(zDoorName(lGetDoorID))
                                    subSendMsg "&RYou are in the Doorway ID#(" & lGetDoorID, zPortID
                                    subSendMsg zDoorDesc(lX, lY, lZ), zPortID
                                    MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & lPlayerID & ", " & lCreateKeyForDoorID(zPortID, lPlayerID, lX, lY, lZ, lGetDoorID, zRandomKeyNames() & " " & zGetDoorName & " key", 1, 20, 2) & ";", dbFailOnError 'Give object to player
                                    subSendMsg "&Y" & "Poof now you have a new door key in your inventory." & vbCrLf & "NOTE: This key is probably a similar name as the original that was first created.", zPortID
                                Else
                                    subSendMsg "&AYou need to move to the X Y Z inside the door to make a key.", zPortID
                                End If
                            Case "BIRD"
                                subSendMsg "&ABird request sent! No Colony zones qualify. No Immortals qualify.", zPortID
                                subFlyingBirdReality 1
                            Case "FINI", "DONE" 'we can mark a room finished
                                Select Case lImmortalLevel
                                    Case 90 To 999
                                        subRoomFinishedToggle zPortID, lX, lY, lZ, lImmortalLevel
                                    Case Else
                                        subSendMsg gblzFNGRE & MyCStr(Mid(zPromptOriginal, 1, 10) & " huh?"), zPortID
                                End Select
                            Case "FACT"
                                subFactionGeneration 1
                                subFactionRealmWin 1
                                subFactionGenesis 'this runs twice in case the two week doesnt reset for the immortal
                        Case Else
                            If (Not bFound) Then subSendMsg gblzFNGRE & MyCStr(Mid(zPromptOriginal, 1, 10) & " huh?"), zPortID
                    End Select
                    
                    Case Else
                        If (Not bFound) Then subSendMsg gblzFNGRE & MyCStr(Mid(zPromptOriginal, 1, 10) & " huh?"), zPortID
                End Select
            Else
                subSendMsg "&RThe area was marked finished.", zPortID
                Select Case Mid(zWord1, 1, 4)
                    Case "FINI"
                        Select Case lImmortalLevel
                            Case 90 To 999
                                subRoomFinishedToggle zPortID, lX, lY, lZ, lImmortalLevel
                            Case Else
                                subSendMsg gblzFNGRE & MyCStr(Mid(zPromptOriginal, 1, 10) & " huh?"), zPortID
                        End Select
                End Select
            End If
            If (bShow) Then subAreaDesc 0, 0, zPortID, lX, lY, lZ, lPlayerLevel, 0, 0, 0, "ELF", zClassType, "11111", 0, 1, bStatusBM, bStatusGUID, ""
        Else
            subWizList zPortID
            'subSendMsg "&gHuh?", zPortID
        End If
    Else
        subWizList zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalCommand," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zTranslateFactionName(lFaction As Long) As String
On Error Resume Next
    Dim zReturn As String
    Select Case lFaction
        Case 1
            zReturn = "Luix"
        Case 2
            zReturn = "Kuik"
        Case 3
            zReturn = "Sufi"
        Case 4
            zReturn = "Hatz"
        Case 5
            zReturn = "Waeb"
        Case 6
            zReturn = "Motz"
        Case 7
            zReturn = "Hani"
        Case 8
            zReturn = "Selo"
        Case 9
            zReturn = "Tran"
        Case Else
            zReturn = "no one"
    End Select
    zTranslateFactionName = zReturn
End Function
Public Function zTranslatePoofAnimalTypes(lUseType As Long, lAnimalType As Long) As String
On Error Resume Next
'See Also: zTranslateRaceSay
    Dim zReturn As String
    Select Case lUseType
        Case 1 'Creature
            Select Case lAnimalType
                Case 1
                    zReturn = "frog" 'height is short for tunnels so they can go in them always
                Case 2
                    zReturn = "mouse" 'short for tunnels
                Case 3
                    zReturn = "cat" 'short for tunnels
                Case 4
                    zReturn = "dog" 'short for tunnels
                Case 5
                    zReturn = "bird" 'can fly, short for tunnels
                Case 6
                    zReturn = "lizard" 'short for tunnels
                Case 7
                    zReturn = "bull" 'can attacked
                Case 8
                    zReturn = "icicle"
                Case 9
                    zReturn = "pumpkin" 'short for tunnels
                Case Else
                    zReturn = "citizen"
            End Select
        Case 2 'Channels
            Select Case lAnimalType
                Case 1
                    zReturn = "ribbit"
                Case 2
                    zReturn = "squeek"
                Case 3
                    zReturn = "meow"
                Case 4
                    zReturn = "bark"
                Case 5
                    zReturn = "chirp"
                Case 6
                    zReturn = "breath"
                Case 7
                    zReturn = "moo"
                Case 8
                    zReturn = "shiver"
                Case 9
                    zReturn = "burn"
                Case Else
                    zReturn = "commons"
            End Select
        Case 3 'Movement
            Select Case lAnimalType
                Case 1
                    zReturn = "flippers"
                Case 2
                    zReturn = "scatters"
                Case 3
                    zReturn = "pounces"
                Case 4
                    zReturn = "chases"
                Case 5
                    zReturn = "flutters"
                Case 6
                    zReturn = "swaggers"
                Case 7
                    zReturn = "troddens"
                Case 8
                    zReturn = "sparkles"
                Case 9
                    zReturn = "rolls"
                Case Else
                    zReturn = "leaves"
            End Select
    End Select

    zTranslatePoofAnimalTypes = zReturn
End Function
Public Sub subMobRespawnPointXYZ(zMobID As String, lX As Long, lY As Long, lZ As Long, zPortID As String)
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim lMobID As Long
    
    lMobID = MyCLng(zMobID)
    If (lMobID <> 0) Then
        Set rsMob = MyDB.OpenRecordset("SELECT MobName, X, Y, Z, RespawnX, RespawnY, RespawnZ FROM tblMob WHERE MobID=" & lMobID & ";", dbOpenDynaset)
        If (Not rsMob.EOF) Then
            If (rsMob!x = lX And rsMob!y = lY And rsMob!z = lZ) Then
                subSendMsg gblzFNGRE & MyCStr(rsMob!MobName) & " is already at [" & lX & " " & lY & " " & lZ & "]", zPortID
            Else
                rsMob.Edit
                rsMob!x = lX
                rsMob!y = lY
                rsMob!z = lZ
                rsMob!RespawnX = lX
                rsMob!RespawnY = lY
                rsMob!RespawnZ = lZ
                rsMob.Update
                subSendMsg "&G" & MyCStr(rsMob!MobName) & vbCrLf & "Has been moved successfully and will now respawn to [" & lX & " " & lY & " " & lZ & "]", zPortID
            End If
        End If
        Set rsMob = Nothing
    Else
        subSendMsg "&gSYNTAX: RESPAWN MobID" & vbCrLf & "This will move the mob to your location.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobRespawnPointXYZ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPoofPlayernameType(zTPlayerName As String, zAnimalType As String, zPortID As String, lPlayerID As Long)
On Error GoTo Err_Check
    Dim lAnimalType As Long
    Dim zPlayerName As String
    Dim rsPlayer As Recordset
    Dim zSQL As String
    zPlayerName = zTPlayerName
    If (lPlayerID = 0) Then subSendMsg "&gYou can turn someone into a FROG, MOUSE, CAT, DOG, BIRD, LIZARD, BULL, ICICLE, PUMPKIN HEAD", zPortID
    If (Len(zPlayerName) > 4 And Len(zPlayerName) < 16) Or (lPlayerID <> 0) Then
        lAnimalType = MyCLng(zAnimalType)
        Select Case Mid(UCase(zAnimalType), 1, 4)
            Case "FROG", "F", "FR", "FRO"
                lAnimalType = 1
            Case "MOUS", "MOU", "MO", "M"
                lAnimalType = 2
            Case "CAT", "C", "CA"
                lAnimalType = 3
            Case "DOG", "D", "DO"
                lAnimalType = 4
            Case "BIRD", "B", "BI", "BIR"
                lAnimalType = 5
            Case "LIZA", "LIZ", "LI", "LIZZ", "LISS", "L"
                lAnimalType = 6
            Case "BULL", "BU", "BUL"
                lAnimalType = 7
            Case "ICIC", "I"
                lAnimalType = 8
            Case "PUMP", "P", "PU", "PUM"
                lAnimalType = 9
        End Select
        
        If (lAnimalType > 0) Then
            If (lPlayerID <> 0) Then
                zSQL = "SELECT ImmortalLevel, BlindDuration, StunDuration, X, Y, Z, PortID, PlayerName, TurnedIntoAnimalType FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");" 'computer is using this function when it uses this one
            Else
                zSQL = "SELECT ImmortalLevel, BlindDuration, StunDuration, X, Y, Z, PortID, PlayerName, TurnedIntoAnimalType FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');"
            End If
            
            Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
            If (Not rsPlayer.EOF) Then
                zPlayerName = MyCStr(rsPlayer!PlayerName)
                rsPlayer.Edit
                If (MyCLng(rsPlayer!ImmortalLevel) = 0) Then
                    rsPlayer!BlindDuration = lRandom(2)
                    rsPlayer!StunDuration = lRandom(2)
                End If
                rsPlayer!TurnedIntoAnimalType = lAnimalType
                rsPlayer.Update
                If (lPlayerID <> 0) Then
                    'means the cpu did it
                    subSendMsg "&A* * - = P &wO O &aF = - * *", MyCStr(rsPlayer!PortID)
                    subSendMsgAreaExcept2 "&a* * &w" & zPlayerName & "&a  - = P &wO O &aF = -  &w" & zTranslatePoofAnimalTypes(1, lAnimalType) & "&a * *", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, MyCStr(rsPlayer!PortID)
                Else 'means the immortal did it
                    subSendMsg "&A! ! &w" & zPlayerName & "&a  - = P &wO O &aF = -  &w" & zTranslatePoofAnimalTypes(1, lAnimalType) & "&a ! !" & vbCrLf & "&g" & zPlayerName & "&a is now a " & zTranslatePoofAnimalTypes(1, lAnimalType) & "[0 to 9|" & lAnimalType & "]!", zPortID
                    subSendMsg "&A! ! - = P &wO O &aF = - ! !", MyCStr(rsPlayer!PortID)
                    subSendMsgAreaExcept2 "&a! ! &w" & zPlayerName & "&a  - = P &wO O &aF = -  &w" & zTranslatePoofAnimalTypes(1, lAnimalType) & "&a ! !", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, MyCStr(rsPlayer!PortID)
                End If
            Else
                If (lPlayerID = 0) Then subSendMsg "&gPlayerName (" & zPlayerName & ") not found in the realm.", zPortID
            End If
            Set rsPlayer = Nothing
        Else
            MyDB.Execute "UPDATE tblPlayer SET TurnedIntoAnimalType=0 WHERE (PlayerName='" & zPlayerName & "');", dbFailOnError
            subSendMsg "&M*POOF* " & zPlayerName & " is now a " & zTranslatePoofAnimalTypes(1, lAnimalType) & " again. *WHEW*", zPortID
        End If
    Else
        If (lPlayerID = 0) Then subSendMsg "&gPlayerName 5 to 15 long.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPoofPlayernameType," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSystemConfigDynamicPort(zPortID As String, zWord2 As String)
On Error GoTo Err_Check
    Dim lDynamicTelnetPort2 As Long
    Dim zDynamicTelnetPort2 As String
    Dim zODynamicTelnetPort2 As String
    
    zDynamicTelnetPort2 = MyCStr(zWord2)
    lDynamicTelnetPort2 = MyCLng(zDynamicTelnetPort2)
    zODynamicTelnetPort2 = zSystemConfig(28)
    
    Select Case (lDynamicTelnetPort2)
        Case 0
            subSendMsg "&GDynamic Port is currently set to (" & zODynamicTelnetPort2 & ")" & vbCrLf & "&gSYNTAX: IMMO DYNAMIC PORTID" & vbCrLf & "This will create an additional connection port." & vbCrLf & "This server does allow HTTP requests to port 80." & vbCrLf & "Shut down all internet browsers and HTTP servers before proceeding.", zPortID
        Case 23, 4000, 2000 To 2100
            subSendMsg "&gReserved Port(" & lDynamicTelnetPort2 & ") [23] [4000] [2000 to 2100]", zPortID
        Case Else
            If (Len(zDynamicTelnetPort2) > 0) Then
                subShutdownPorts zODynamicTelnetPort2
                gbllDynamicPortID2 = lDynamicTelnetPort2
                MyDB.Execute "UPDATE tblSystemConfig SET DynamicTelnetPort2='" & Mid(zDynamicTelnetPort2, 1, 4) & "';", dbFailOnError
                subSendMsg "&GDynamic Port Set -> Before (" & zODynamicTelnetPort2 & ") After (" & zDynamicTelnetPort2 & ")", zPortID
            Else
                subSendMsg "&gInvalid Port(" & zDynamicTelnetPort2 & ")", zPortID
            End If
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subSystemConfigDynamicPort," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendDatabaseFile(zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim bOkay As Boolean
    Dim zIP As String
    zIP = zDropFirstWordCleanLine(zDropFirstWordCleanLine(zPromptOriginal))
    If (Len(zIP) > 0) Then
        If (InStr(zIP, ".") > 0) Then
            bOkay = True
        End If
    End If
    
    If (bOkay) Then
        subSendMsg "&gSending file in 15 seconds to: IP" & zIP, zPortID
        'frmSendDataBase.Show
        'frmSendDataBase!ctlTimerChecksSend.Interval = 15000
        'frmSendDataBase!txtIP = zIP 'the form uses this seconds timer to check if zIP is blank or not.
    Else
        subSendMsg "&gInvalid IP" & zIP & ", a peroid is required such as X.XXX.XX.XXX", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendDatabaseFile," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subGroundObjectFix(lX As Long, lY As Long, lZ As Long, zPortID As String)
On Error GoTo Err_Check
    subSendMsg "&GAll ground objects in this room SpecialSelfDeletingDelay set to OFF.", zPortID
    MyDB.Execute "UPDATE tblObject SET SpecialSelfDeletingDelay=0, GroundTimer = 0, GroundTimerNotAvailable = True WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subGroundObjectFix," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMakeNewSpell(lMobID As Long, zLearnName As String, lActivateCommand As Long, lLearnX As Long, lLearnY As Long, lLearnZ As Long, zClassRestricted As String, lLearnLevelRestricted As Long, lObjectActivateSpellNo As Long, lActivateManaCost As Long, lActivateEssenceCost As Long, lActivateSoulCost As Long, lActivateMoveCost As Long, zPortID As String)
On Error GoTo Err_Check
    Dim rsNewSpell As Recordset
    
    If (lngSQLRecordCount("SELECT TargetID FROM tblPlayerLearn WHERE (LearnName Like '*" & zLearnName & "*' AND ClassRestricted ='" & zClassRestricted & "' AND TargetID=0);") = 0) Then
        Set rsNewSpell = MyDB.OpenRecordset("tblPlayerLearn", dbOpenTable)
        If (Not rsNewSpell.EOF) Then
            rsNewSpell.AddNew
            rsNewSpell!MobID = lMobID
            rsNewSpell!LearnName = zLearnName
            rsNewSpell!ActivateCommand = lActivateCommand
            rsNewSpell!LearnX = lLearnX
            rsNewSpell!LearnY = lLearnY
            rsNewSpell!LearnZ = lLearnZ
            rsNewSpell!ClassRestricted = zClassRestricted
            rsNewSpell!LearnLevelRestricted = lLearnLevelRestricted
            rsNewSpell!ObjectActivateSpellNo = lObjectActivateSpellNo
            rsNewSpell!ActivateManaCost = lActivateManaCost
            rsNewSpell!ActivateEssenceCost = lActivateEssenceCost
            rsNewSpell!ActivateSoulCost = lActivateSoulCost
            rsNewSpell!ActivateMoveCost = lActivateMoveCost
            rsNewSpell.Update
        End If
        Set rsNewSpell = Nothing
        subSendMsg "&G" & zClassRestricted & " " & zLearnName & " was ADDED successfully!", zPortID
    Else
        subSendMsg gblzFBRED & zClassRestricted & " " & zLearnName & " already exists!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMakeNewSpell," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobCraftingTransmutingEditor(zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, lX As Long, lY As Long, lZ As Long, lPlayerID As Long, zPortID As String)
On Error GoTo Err_Check
    Dim rsHelp As Recordset
    Dim rsObject As Recordset
    Dim lHelpID As Long
    Dim lLineID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    Dim lRollA As Long
    Dim lRollB As Long
    Dim bFailed As Boolean
    
    If (Len(zWord3) < 12) Then
        lHelpID = MyCLng(zWord3)
        lLineID = MyCLng(zWord4)
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        If (zWord4 = "") Then zLine = ""
        bShow = False: bFailed = False
        zSQL = ""
        Select Case Mid(zWord2, 1, 4)
            Case "SHOW" 'show
                bShow = True
            Case "MOBI"
                bShow = True
                If (lngSQLRecordCount("SELECT MobID FROM tblAreaTransmute WHERE (MobID=" & lHelpID & ");") = 0) Then
                    If (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lHelpID & ");") <> 0) Then
                        If (lngSQLRecordCount("SELECT MobID FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") <> 0) Then
                            MyDB.Execute "UPDATE tblAreaTransmute SET MobID=" & lHelpID & " WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
                            subSendMsg "&RUpdating the transmuter in the area of " & lX & " " & lY & " " & lZ, zPortID
                        Else
                            subSendMsg "&RTransmuter not found here at " & lX & " " & lY & " " & lZ, zPortID
                        End If
                    Else
                        subSendMsg "&RMOBID " & lHelpID & " not found.", zPortID
                    End If
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lHelpID & " is already in use by the transmuter system.", zPortID
                End If
            Case "GON", "GONI"
                bShow = True
                zSQL = "SELECT ObjectName FROM tblAreaTransmute WHERE (AreaTransmuteID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AAreaTransmuteID " & lHelpID & " old value: " & MyCStr(rsHelp!ObjectName), zPortID
                    rsHelp.Edit
                    rsHelp!ObjectName = MyCStr(zLine)
                    rsHelp.Update
                    subSendMsg "&AAreaTransmuteID " & lHelpID & " Object Name " & MyCStr(zLine) & " set!", zPortID
                Else
                    bFailed = True
                    subSendMsg "&RAreaTransmuteID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "OBJE", "OID", "RON", "RONI"
                bShow = True
                If (lngSQLRecordCount("SELECT MobID FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") <> 0) Then
                    If (lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE (ObjectID=" & lHelpID & ");") <> 0) Then
                        zSQL = "SELECT tblObject.ObjectName, tblPlayerInventoryItems.PlayerInventoryItemsID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerInventoryItems.ObjectID)=" & lHelpID & "));"
                        Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                        If (Not rsHelp.EOF) Then
                            MyDB.Execute "DELETE ObjectName FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND ObjectName='" & MyCStr(rsHelp!ObjectName) & "');", dbFailOnError 'remove this objectname from area transmute
                            MyDB.Execute "DELETE PlayerEquipmentItemsID FROM tblPlayerEquipmentItems WHERE (ObjectID=" & lHelpID & ");", dbFailOnError 'unlink from inventory 'unlink from inventory
                            MyDB.Execute "DELETE PlayerInventoryItemsID FROM tblPlayerInventoryItems WHERE (ObjectID=" & lHelpID & ");", dbFailOnError 'unlink from inventory 'unlink from inventory
                            MyDB.Execute "UPDATE tblObject SET PlayerID=0, Burried=False, Status=1, SystemObjectType=1, VisibleLevel=0, Rare=0, Treasure=0, CanSellItem=False, AuctionAllowed=False, X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE (ObjectID=" & lHelpID & ");", dbFailOnError 'we clean the object perfectly and hide it to area
                            subSendMsg "&GObjectID " & lHelpID & " added to the area.", zPortID
                        Else
                            subSendMsg "&RObjectID " & lHelpID & " not found in your inventory.", zPortID
                        End If
                        Set rsHelp = Nothing
                    Else
                        subSendMsg "&RObjectID (player receives this item) " & lHelpID & " not found in the realm.", zPortID
                    End If
                Else
                    bFailed = True
                    subSendMsg "&RTransmuter not found at " & lX & " " & lY & " " & lZ, zPortID
                End If
            Case "MO"
                bShow = True
                zSQL = "SELECT MorphObjectID FROM tblAreaTransmute WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " MorphObjectID " & lLineID & " old value:" & vbCrLf & MyCStr(rsHelp!MorphObjectID), zPortID
                    MyDB.Execute "UPDATE tblAreaTransmute SET MorphObjectID=" & lLineID & ", X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE (MobID=" & lHelpID & ");", dbFailOnError
                    If (lLineID = 0) Then subSendMsg "&AlLineID=" & lLineID & ", No item will be generated.", zPortID
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "NEW" 'New MobID
                If (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lHelpID & ");") = 1) Then
                    If (lngSQLRecordCount("SELECT MobID FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") = 0) Then
                        zSQL = "SELECT tblPlayerInventoryItems.PlayerID, tblObject.ObjectName FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & "));"
                        Set rsObject = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                        If (Not rsObject.EOF) Then
                            Do While (Not rsObject.EOF)
                                MyDB.Execute "INSERT INTO tblAreaTransmute ( MorphObjectID, MobID, ObjectName, X, Y, Z ) SELECT " & lLineID & ", " & lHelpID & ", " & MyCStr(rsObject!ObjectName) & ", " & lX & ", " & lY & ", " & lZ & ";", dbFailOnError
                                rsObject.MoveNext
                            Loop
                            subSendMsg "&gNote: You need to set the MorphObjectID now." & vbCrLf & "      IMMO CRAFT OBJECT OBJECTID is the next step.", zPortID
                        Else
                            subSendMsg "&RtblMob.MobID " & lHelpID & " not found at " & lX & " " & lY & " " & lZ & vbCrLf & "No items in inventory.", zPortID
                        End If
                        Set rsObject = Nothing
                    Else
                        subSendMsg "&RThere is already a transmuter device print here." & vbCrLf & "You can delete the transmuter x y z print if you wish with DID.", zPortID
                    End If
                Else
                    bFailed = True
                    subSendMsg "&RMOBID " & lHelpID & " not found in the area of " & lX & " " & lY & " " & lZ & ".", zPortID
                End If
            Case "DID" 'Delete Mob Area Transmute ID
                lRollA = lRandom(9)
                lRollB = lRandom(100)
                If (lRollA >= lRollB) Then
                    If (lngSQLRecordCount("SELECT MobID FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") <> 0) Then
                        MyDB.Execute "DELETE MobID FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
                        subSendMsg "&GTransmuting device was removed from the area!", zPortID
                    Else
                        subSendMsg "&RNo transmuter was found in the area!", zPortID
                    End If
                    Set rsHelp = Nothing
                Else
                    bFailed = True
                    subSendMsg "&ARolls Failed: " & lRollA & " vs " & lRollB & "&R" & vbCrLf & "The transmuter in the area resists your delete! Try again!" & vbCrLf & "&r" & "The purpose of this message is to protect existing area transmuters." & vbCrLf & "Only delete ones that belong to you!", zPortID
                End If
            Case Else
               bFailed = True
        End Select
        
        If (bShow) Then
            zSQL = "SELECT AreaTransmuteID, MobID, ObjectName, X, Y, Z, MorphObjectID, HerdTransmuteID FROM tblAreaTransmute WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ") ORDER BY AreaTransmuteID, MobID, HerdTransmuteID;"
            Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsHelp.EOF) Then
                subSendMsg "&W:MOBID:&a#&w" & MyCStr(rsHelp!MobID), zPortID
                subSendMsg "&W:Receive Object Name ID: &w" & MyCStr(rsHelp!MorphObjectID) & " " & gblzFBWHI & zReturnObjectName(MyCLng(rsHelp!MorphObjectID)), zPortID
                subSendMsg "&A >X:" & strForceSize(MyCStr(rsHelp!x), 15, " ", "A") & "Y:" & strForceSize(MyCStr(rsHelp!y), 15, " ", "A") & "Z:" & MyCStr(rsHelp!z), zPortID
                Do While (Not rsHelp.EOF)
                    subSendMsg "&W :AreaTransmuteID:&a#&w" & MyCStr(rsHelp!AreaTransmuteID), zPortID
                    subSendMsg "&w >Herd Transmute ID: " & MyCStr(rsHelp!HerdTransmuteID), zPortID
                    subSendMsg "&w >Give Object Name: " & MyCStr(rsHelp!ObjectName), zPortID
                    rsHelp.MoveNext
                Loop
            Else
                subSendMsg "&RtblAreaTransmute.X .Y .Z at " & lX & " " & lY & " " & lZ & " not found here.", zPortID
            End If
            Set rsHelp = Nothing
        End If
        If (bFailed) Then subSendMsg "&gNEW MOBID - Creates a new Mob Transmuting Line, mob must be in area (must be done first)" & vbCrLf & "SHOW      - Shows the complete Mob Transmuting Lines" & vbCrLf & "MOBID     - Mobile ID linked to this list." & vbCrLf & "GON       - Object Name for the transmuting matches" & vbCrLf & "MO        - Set the transmuting ObjectID" & vbCrLf & "RON       - Sets the quest Object to the area which the player receives as a reward" & vbCrLf & "DID       - Deletes the Transmuting Line ID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO CRAFTING MO MOBID LINEID", zPortID
    Else
        subSendMsg "&RMobID " & zWord3 & " is too long a value to process.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobCraftingTransmutingEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobEmotePlayerEditor(zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsHelp As Recordset
    Dim lHelpID As Long
    Dim lLineID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    Dim lRollA As Long
    Dim lRollB As Long
    If (Len(zWord3) < 12) Then
        lHelpID = MyCLng(zWord3)
        lLineID = MyCLng(zWord4)
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        If (zWord4 = "") Then zLine = ""
        bShow = False
        zSQL = ""
        Select Case Mid(zWord2, 1, 4)
            Case "SHOW" 'show
                bShow = True
            Case "SE1", "SEON"
                bShow = True
                zSQL = "SELECT SpeakEmote1 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakEmote1), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakEmote1 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SM1", "SMON"
                bShow = True
                zSQL = "SELECT SpeakMessage1 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakMessage1), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakMessage1 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SE2", "SETW"
                bShow = True
                zSQL = "SELECT SpeakEmote2 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakEmote2), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakEmote2 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SM2", "SMTW"
                bShow = True
                zSQL = "SELECT SpeakMessage2 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakMessage2), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakMessage2 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SE3", "SETH"
                bShow = True
                zSQL = "SELECT SpeakEmote3 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakEmote3), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakEmote3 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SM3", "SMTH"
                bShow = True
                zSQL = "SELECT SpeakMessage3 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakMessage3), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakMessage3 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SE4", "SEFO"
                bShow = True
                zSQL = "SELECT SpeakEmote4 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakEmote4), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakEmote4 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SM4", "SMFO"
                bShow = True
                zSQL = "SELECT SpeakMessage4 FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakMessage4), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakMessage4 = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "NEW" 'New MobID
                If (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lHelpID & ");") = 1) Then
                    bShow = True
                    zSQL = "tblMobEmotePlayer"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenTable)
                    rsHelp.AddNew
                    rsHelp!MobID = lHelpID
                    subSendMsg "&WNEW! MobID " & lHelpID & " MobEmotePlayerID " & MyCLng(rsHelp!MobEmotePlayerID) & " created successfully!", zPortID
                    rsHelp.Update
                    Set rsHelp = Nothing
                Else
                    subSendMsg "&RMOBID " & lHelpID & " not found.", zPortID
                End If
            Case "DID" 'Delete ID
                If (lngSQLRecordCount("SELECT MobEmotePlayerID FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");") <> 0) Then
                    lRollA = lRandom(5)
                    lRollB = lRandom(100)
                    If (lRollA >= lRollB) Then
                        subSendMsg "&G" & lngSQLRecordCount("SELECT MobEmotePlayerID FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");") & " mobile emotes linked to MobID " & lHelpID & " were removed.", zPortID
                        MyDB.Execute "DELETE MobID FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");", dbFailOnError
                    Else
                        subSendMsg "&a" & lRollA & " vs " & lRollB & "&R, you did not roll high enough to delete the emote line(s.", zPortID
                    End If
                Else
                    subSendMsg "&RMobID " & lHelpID & ", mob emote player record line(s not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case Else
               subSendMsg "&gNEW MOBID - Creates a new Mob Emote Player Line (must be done first)" & vbCrLf & "SHOW      - Shows the complete MobEmotePlayer ID" & vbCrLf & "SEONE     - Speak Emote One" & vbCrLf & "SMONE     - Speak Message One" & vbCrLf & "DID       - Deletes all phrases matching the MobID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO MEP <command> MOBID LINEID", zPortID
        End Select
        
        If (bShow) Then
            'SELECT MobPhraseID, MobID, PhraseKeyword1, PhraseKeyword2, PhraseKeyword3, PhraseKeyword4, PhraseDesc1, PhraseEmote1, PhraseDesc2, PhraseEmote2, PrintOrder FROM tblMobPhrase;
            zSQL = "SELECT MobEmotePlayerID, MobID, ChartEmoteID, GlobalToAllMobs, SpeakEmote1, SpeakMessage1, SpeakEmote2, SpeakMessage2, SpeakEmote3, SpeakMessage3, SpeakEmote4, SpeakMessage4, Gold, SpellNo, SkillNo, Status FROM tblMobEmotePlayer WHERE (MobID=" & lHelpID & ");"
            Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsHelp.EOF) Then
                subSendMsg "&W:MOBID:&a#&w" & MyCStr(rsHelp!MobID), zPortID
                Do While (Not rsHelp.EOF)
                    subSendMsg "&W:MobEmotePlayerID:&a#&w" & MyCStr(rsHelp!MobEmotePlayerID), zPortID
                    subSendMsg "&M >Chart Emote ID: " & vbCrLf & MyCStr(rsHelp!ChartEmoteID), zPortID
                    subSendMsg "&M >Global To All Mobs: " & vbCrLf & basBoolean(MyCInt(rsHelp!GlobalToAllMobs) <> 0), zPortID
                    subSendMsg "&M >Speak Emote ONe: " & vbCrLf & MyCStr(rsHelp!SpeakEmote1), zPortID
                    subSendMsg "&y >Speak Message ONe: " & vbCrLf & MyCStr(rsHelp!SpeakMessage1), zPortID
                    subSendMsg "&M >Speak Emote TWo: " & vbCrLf & MyCStr(rsHelp!SpeakEmote2), zPortID
                    subSendMsg "&y >Speak Message TWo: " & vbCrLf & MyCStr(rsHelp!SpeakMessage2), zPortID
                    subSendMsg "&M >Speak Emote THree: " & vbCrLf & MyCStr(rsHelp!SpeakEmote3), zPortID
                    subSendMsg "&y >Speak Message THree: " & vbCrLf & MyCStr(rsHelp!SpeakMessage3), zPortID
                    subSendMsg "&M >Speak Emote Four: " & vbCrLf & MyCStr(rsHelp!SpeakEmote4), zPortID
                    subSendMsg "&y >Speak Message Four: " & vbCrLf & MyCStr(rsHelp!SpeakMessage4), zPortID
                    'subSendMsg "&Y" & " >GOLD: " & vbCrLf & MyCStr(rsHelp!Gold), zPortID
                    'subSendMsg gblzFBCYA & " >SPell #: " & vbCrLf & MyCStr(rsHelp!SpellNo), zPortID
                    'subSendMsg "&G >SKill #: " & vbCrLf & MyCStr(rsHelp!SkillNo), zPortID
                    'subSendMsg "&w"  & " >STATus: " & vbCrLf & MyCStr(rsHelp!Status), zPortID
                    rsHelp.MoveNext
                Loop
            Else
                subSendMsg "&RData not found for tblMobEmotePlayer.MobID " & lHelpID & ".", zPortID
            End If
            Set rsHelp = Nothing
        End If
    Else
        subSendMsg "&RMobID " & zWord3 & " is too long a value to process.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobEmotePlayerEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobQuestEditor(zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsHelp As Recordset
    Dim lMobID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    Dim bFailed As Boolean
    
    lMobID = MyCLng(zWord3)
    If (lMobID <> 0) Then 'this is the mobid ie: immo mqe qeon 1415600255 emote/speakphrase
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        If (zWord4 = "") Then zLine = ""
        bShow = False
        zSQL = "SELECT MobID, ObjectName, QuestObjectID, FinishQuestEmote1, FinishQuestMessage1, FinishQuestEmote2, FinishQuestMessage2, FinishQuestEmote3 FROM tblMobQuestObject WHERE (MobID=" & lMobID & ");"
        Select Case Mid(zWord2, 1, 4)
            Case "SHOW" 'show
                bShow = True
            Case "QE1", "QEON"
                bShow = True
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!FinishQuestEmote1), zPortID
                    rsHelp.Edit
                    rsHelp!FinishQuestEmote1 = zLine
                    rsHelp.Update
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lMobID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "QE2", "QETW"
                bShow = True
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!FinishQuestEmote2), zPortID
                    rsHelp.Edit
                    rsHelp!FinishQuestEmote2 = zLine
                    rsHelp.Update
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lMobID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "QE3", "QETH"
                bShow = True
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!FinishQuestEmote3), zPortID
                    rsHelp.Edit
                    rsHelp!FinishQuestEmote3 = zLine
                    rsHelp.Update
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lMobID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "QM1", "QMON"
                bShow = True
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!FinishQuestMessage1), zPortID
                    rsHelp.Edit
                    rsHelp!FinishQuestMessage1 = zLine
                    rsHelp.Update
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lMobID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "QM2", "QMTW"
                bShow = True
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!FinishQuestMessage2), zPortID
                    rsHelp.Edit
                    rsHelp!FinishQuestMessage2 = zLine
                    rsHelp.Update
                Else
                    bFailed = True
                    subSendMsg "&RMobID " & lMobID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "NEW" 'New MobID
                If (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lMobID & ");") = 1) Then
                    subSendMsg "&gWAIT! Use the Mob Quest command for this instead!", zPortID
                Else
                    bFailed = True
                    subSendMsg "&RMOBID " & lMobID & " not found.", zPortID
                End If
                subSendMsg "&GSYNTAX: &gIMMO MQUE (mobid) (give objectid) (reward objectid recieved)", zPortID
            Case Else
               subSendMsg "&gNEW MOBID - Creates a new Mob Quest Line (must be done first)" & vbCrLf & "SHOW      - Shows the complete Mob Quest Object ID" & vbCrLf & "QEONE     - Quest Emote One" & vbCrLf & "QMONE     - Quest Message One" & vbCrLf & "DID       - Deletes the Quest Editor Line ID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO MQE <command> MOBID LINEID", zPortID
        End Select
        
        If (bShow) Then
            'SELECT MobPhraseID, MobID, PhraseKeyword1, PhraseKeyword2, PhraseKeyword3, PhraseKeyword4, PhraseDesc1, PhraseEmote1, PhraseDesc2, PhraseEmote2, PrintOrder FROM tblMobPhrase;
            zSQL = "SELECT MobID, ObjectName, QuestObjectID, FinishQuestEmote1, FinishQuestEmote1, FinishQuestMessage1, FinishQuestEmote2, FinishQuestMessage2, FinishQuestEmote3 FROM tblMobQuestObject WHERE (MobID=" & lMobID & ");"
            Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsHelp.EOF) Then
                subSendMsg "&W:MOBID:&a#&w" & MyCStr(rsHelp!MobID), zPortID
                Do While (Not rsHelp.EOF)
                    subSendMsg "&A :QuestObjectID Player Receives: " & MyCStr(rsHelp!QuestObjectID) & " " & gblzFBWHI & zReturnObjectName(MyCLng(rsHelp!QuestObjectID)), zPortID
                    subSendMsg "&M >Quest Emote ONe: " & vbCrLf & MyCStr(rsHelp!FinishQuestEmote1), zPortID
                    subSendMsg "&y >Quest Message ONe: " & vbCrLf & MyCStr(rsHelp!FinishQuestMessage1), zPortID
                    subSendMsg "&M >Quest Emote TWo: " & vbCrLf & MyCStr(rsHelp!FinishQuestEmote2), zPortID
                    subSendMsg "&y >Quest Message TWo: " & vbCrLf & MyCStr(rsHelp!FinishQuestMessage2), zPortID
                    subSendMsg "&M >Quest Emote THree: " & vbCrLf & MyCStr(rsHelp!FinishQuestEmote3), zPortID
                    subSendMsg "&A :ObjectName: " & MyCStr(rsHelp!ObjectName), zPortID
                    rsHelp.MoveNext
                Loop
            Else
                subSendMsg "&RData not found for tblMobQuestObject.MobID " & lMobID & ".", zPortID
            End If
            Set rsHelp = Nothing
        End If
    Else
        subSendMsg "&rMobID [" & zWord3 & "] and invalid mobile identifier.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobQuestEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobPhraseReorder(lMobID As Long)
On Error GoTo Err_Check
    Dim lCount As Long
    Dim rsHelp As Recordset
    lCount = 0
    Set rsHelp = MyDB.OpenRecordset("SELECT PrintOrder FROM tblMobPhrase WHERE (MobID=" & lMobID & ") ORDER BY PrintOrder;", dbOpenDynaset)
    Do While (Not rsHelp.EOF)
        lCount = lCount + 1
        rsHelp.Edit
        rsHelp!PrintOrder = lCount
        rsHelp.Update
        rsHelp.MoveNext
    Loop
    Set rsHelp = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobPhraseReorder," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lReturnLastPrintOrder(lMobID As Long) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    Dim lValue As Long
    Dim rsHelp As Recordset
    lReturn = 0
    Set rsHelp = MyDB.OpenRecordset("SELECT PrintOrder FROM tblMobPhrase WHERE (MobID=" & lMobID & ") ORDER BY PrintOrder;", dbOpenSnapshot)
    Do While (Not rsHelp.EOF)
        lValue = MyCLng(rsHelp!PrintOrder)
        If (lReturn < lValue) Then lReturn = lValue
        rsHelp.MoveNext
    Loop
    Set rsHelp = Nothing
    lReturnLastPrintOrder = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnLastPrintOrder," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subMobPhraseEditor(zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsHelp As Recordset
    Dim lMobID As Long
    Dim lLineID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShowSyntax As Boolean
    Dim bShow As Boolean 'ie. immo mpe pkon -1196038600 line# Killar is a few floors up in Marble City Castle, and is usually in his hidden corner.
    Dim zMobName As String
    Dim zCommand As String
    bShowSyntax = False
    lMobID = MyCLng(zWord3)
    zMobName = zReturnMobName(lMobID)
    If (Len(zMobName) > 0) Then
        subSendMsg "&W" & zMobName & " ID#" & lMobID, zPortID
        lLineID = MyCLng(zWord4)
        zCommand = UCase(Mid(zWord2, 1, 4))
        If (lLineID <> 0 Or zCommand = "SHOW") Then
            zLine = zDropFirstWordCleanLine(zPromptOriginal)
            zLine = zDropFirstWordCleanLine(zLine)
            zLine = zDropFirstWordCleanLine(zLine)
            zLine = zDropFirstWordCleanLine(zLine)
            If (InStr(zLine, " ") = 0) Then zLine = UCase(zLine)
            If (zWord4 = "") Then zLine = ""
            bShow = False
            zSQL = ""
            Select Case zCommand
                Case "SHOW" 'show
                    bShow = True
                Case "PK1", "PKON"
                    bShow = True
                    zSQL = "SELECT PhraseKeyword1 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseKeyword1), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseKeyword1 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PK2", "PKTW"
                    bShow = True
                    zSQL = "SELECT PhraseKeyword2 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseKeyword2), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseKeyword2 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PK3", "PKTH"
                    bShow = True
                    zSQL = "SELECT PhraseKeyword3 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseKeyword3), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseKeyword3 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PK4", "PKFO"
                    bShow = True
                    zSQL = "SELECT PhraseKeyword4 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseKeyword4), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseKeyword4 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PD1", "PDON"
                    bShow = True
                    zSQL = "SELECT PhraseDesc1 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseDesc1), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseDesc1 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PD2", "PDTW"
                    bShow = True
                    zSQL = "SELECT PhraseDesc2 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseDesc2), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseDesc2 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PE1", "PEON"
                    bShow = True
                    zSQL = "SELECT PhraseEmote1 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseEmote1), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseEmote1 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "PE2", "PETW"
                    bShow = True
                    zSQL = "SELECT PhraseEmote2 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!PhraseEmote2), zPortID
                        rsHelp.Edit
                        rsHelp!PhraseEmote2 = zLine
                        rsHelp.Update
                    Else
                        subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case "NEW" 'New MobID
                    bShow = True
                    Set rsHelp = MyDB.OpenRecordset("tblMobPhrase", dbOpenTable)
                    rsHelp.AddNew
                    rsHelp!PrintOrder = lReturnLastPrintOrder(lMobID) + 1
                    rsHelp!MobID = lMobID
                    rsHelp.Update
                    subSendMsg "&W*NEW* Mob Phrase Editor line created successfully!", zPortID
                    Set rsHelp = Nothing
                Case "DID" 'Delete Mob Phrase ID
                    zSQL = "SELECT PhraseEmote2 FROM tblMobPhrase WHERE (MobID=" & lMobID & " AND PrintOrder=" & lLineID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        rsHelp.Delete
                        subSendMsg "&G" & zMobName & " and Line ID " & lLineID & " were deleted.", zPortID
                    Else
                        subSendMsg "&G" & zMobName & "&R Line ID " & lLineID & " not found.", zPortID
                    End If
                    Set rsHelp = Nothing
                Case Else
                   bShowSyntax = True
            End Select
            
            subMobPhraseReorder lMobID
    
            If (bShow) Then
                'SELECT MobPhraseID, MobID, PhraseKeyword1, PhraseKeyword2, PhraseKeyword3, PhraseKeyword4, PhraseDesc1, PhraseEmote1, PhraseDesc2, PhraseEmote2, PrintOrder FROM tblMobPhrase;
                zSQL = "SELECT MobPhraseID, MobID, PhraseKeyword1, PhraseKeyword2, PhraseKeyword3, PhraseKeyword4, PhraseDesc1, PhraseEmote1, PhraseDesc2, PhraseEmote2, PrintOrder FROM tblMobPhrase WHERE (MobID=" & lMobID & ") ORDER BY PrintOrder;"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsHelp.EOF) Then
                    Do While (Not rsHelp.EOF)
                        subSendMsg "&A:Print Order: " & MyCStr(rsHelp!PrintOrder), zPortID
                        subSendMsg "&g >Phrase Key ONe: " & MyCStr(rsHelp!PhraseKeyword1), zPortID
                        subSendMsg "&g >Phrase Key TWo: " & MyCStr(rsHelp!PhraseKeyword2), zPortID
                        subSendMsg "&g >Phrase Key THree: " & MyCStr(rsHelp!PhraseKeyword3), zPortID
                        subSendMsg "&g >Phrase Key FOur: " & MyCStr(rsHelp!PhraseKeyword4), zPortID
                        subSendMsg "&y >Phrase Desc ONe: " & vbCrLf & MyCStr(rsHelp!PhraseDesc1), zPortID
                        subSendMsg "&M >Phrase Emote ONe: " & vbCrLf & MyCStr(rsHelp!PhraseEmote1), zPortID
                        subSendMsg "&y >Phrase Desc TWo: " & vbCrLf & MyCStr(rsHelp!PhraseDesc2), zPortID
                        subSendMsg "&M >Phrase Emote TWo: " & vbCrLf & MyCStr(rsHelp!PhraseEmote2), zPortID
                        rsHelp.MoveNext
                    Loop
                Else
                    subSendMsg "&RData not found for tblMobPhrase.MobID " & lMobID & ".", zPortID
                End If
                Set rsHelp = Nothing
            End If
        Else
            bShowSyntax = True
        End If
    Else
        subSendMsg "&RMobID " & lMobID & " is not a valid mobile identifier.", zPortID
        bShowSyntax = True
    End If
    
    If (bShowSyntax) Then
        subSendMsg "&GMob Phrase Editor makes it so the mobile TALKS back to you." & vbCrLf & "See Also: TALK command", zPortID
        subSendMsg "&gNEW MOBID - Creates a new Mob Phrase Line (must be done first)" & vbCrLf & "SHOW      - Shows the complete MobPhrase ID" & vbCrLf & "PKONE     - Phrase Keyword One" & vbCrLf & "PDONE     - Phrase Desc One" & vbCrLf & "PEONE     - Phrase Emote One" & vbCrLf & "DID       - Deletes the MobID LineID (this cannot be undone)", zPortID
        subSendMsg "&gSYNTAX: IMMO MPE <command> MOBID LINEID <your descriptions>" & vbCrLf & "Each time you create a NEW Phrase Line you will reference it as Line#." & vbCrLf & "Also: Any of the four Phrases will trigger Phrase Desc one and two and Emote One and Two. It is optional to use all four or part of these replies." & vbCrLf & "You would test your phrases with the player TALK command.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobPhraseEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub basUnlinkPlayerSetQuestItemToTheArea(lObjectID As Long, lX As Long, lY As Long, lZ As Long, lSystemObjectType As Long, zPortID As String)
On Error GoTo Err_Check
    If (lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE (ObjectID=" & lObjectID & ");") = 1) Then
        MyDB.Execute "DELETE PlayerEquipmentItemsID FROM tblPlayerEquipmentItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError 'Unlink from the player
        MyDB.Execute "DELETE PlayerInventoryItemsID FROM tblPlayerInventoryItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError 'Unlink from the player
        MyDB.Execute "DELETE ObjectID FROM tblPlayerContainer WHERE (ObjectID=" & lObjectID & ");", dbFailOnError 'Unlink from player containers
        MyDB.Execute "UPDATE tblObject SET PlayerID=0, Burried=False, Status=1, SystemObjectType=" & lSystemObjectType & ", VisibleLevel=0, Rare=0, Treasure=0, CanSellItem=False, AuctionAllowed=False, X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE (ObjectID=" & lObjectID & ");", dbFailOnError 'we clean the object perfectly and hide it to area
        subSendMsg "&GObjectID " & lObjectID & " successfully immortal hidden and set for a quest to this area!", zPortID 'this is optional you can make zPortID nothing  or ""
    Else
        subSendMsg "&RUnlink failed ObjectID " & lObjectID & " not found in the realm.", zPortID 'this is optional you can make zPortID nothing  or ""
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "basUnlinkPlayerSetQuestItemToTheArea," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobQuestHerdEditor(zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim rsHelp As Recordset
    Dim lMobQuestHerdID As Long
    Dim lObjectID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    Dim lShow As Long
    Dim lHerdMobID As Long
    Dim zCommand As String
    Dim bShowSyntax As Boolean
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
    End If
    Set rsPlayer = Nothing
    
    bShowSyntax = False
    zCommand = UCase(Mid(zWord2, 1, 4))
    lMobQuestHerdID = MyCLng(zWord3)
    If (lMobQuestHerdID <> 0 Or zCommand = "SHOW" Or zCommand = "REVE" Or zCommand = "NEW") Then
        lObjectID = MyCLng(zWord3)
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        If (zWord4 = "") Then zLine = ""
        bShow = False
        zSQL = ""
        Select Case zCommand
            Case "REVE" 'reveal all mob herd quests
                subSendMsg "&AEditorHerdID TagMobilesID", zPortID
                zSQL = "SELECT MobQuestHerdID, HerdQuestTitle, ObjectID, RareRandom, MsgSuccess, MsgFailure, HerdMobID FROM tblMobQuestHerd ORDER BY MobQuestHerdID;"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsHelp.EOF) Then
                    Do While (Not rsHelp.EOF)
                        subSendMsg "&W" & strForceSize(MyCStr(rsHelp!MobQuestHerdID), 13, " ", "A") & strForceSize(MyCStr(rsHelp!HerdMobID), 12, " ", "A") & "&g" & strForceSize(MyCStr(rsHelp!HerdQuestTitle), 54, " ", "A"), zPortID
                        rsHelp.MoveNext
                    Loop
                Else
                    subSendMsg "&rNo data was found start your first Mob Quest Herd ID with " & vbCrLf & "IMMO MQHE NEW", zPortID
                End If
                Set rsHelp = Nothing
            Case "SHOW" 'show
                bShow = True
            Case "NEW" 'New MobHerdQuestID
                lShow = 0
                If (lngSQLRecordCount("SELECT tblPlayerInventoryItems.PlayerID, tblObject.ObjectID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.ObjectID)=" & lObjectID & "));") <> 0) Then 'is the object in their inventory, this is a must
                    'We find the next herd mob id
                    lHerdMobID = 0
                    zSQL = "SELECT TOP 1 HerdMobID FROM tblMobQuestHerd ORDER BY HerdMobID DESC;"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                    If (Not rsHelp.EOF) Then
                        rsHelp.MoveLast
                        lHerdMobID = MyCLng(rsHelp!HerdMobID) + 1
                    End If
                    Set rsHelp = Nothing
                    
                    If (lngSQLRecordCount("SELECT HerdMobID FROM tblMobQuestHerd WHERE (HerdMobID=" & lHerdMobID & ");") = 0) Then
                        bShow = True
                        Set rsHelp = MyDB.OpenRecordset("tblMobQuestHerd", dbOpenTable)
                        rsHelp.AddNew
                        lMobQuestHerdID = MyCLng(rsHelp!MobQuestHerdID)
                        rsHelp!HerdMobID = lHerdMobID
                        rsHelp!ObjectID = lObjectID
                        rsHelp.Update
                        Set rsHelp = Nothing
                        MyDB.Execute "DELETE PlayerInventoryItemsID FROM tblPlayerInventoryItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError 'move the object from the players inventory to the herd quest
                        MyDB.Execute "UPDATE tblObject SET PlayerID=0, Status=1 WHERE (ObjectID=" & lObjectID & ");", dbFailOnError '1=with the mobs
                        
                        subSendMsg "&W*NEW* EditorHerdID# " & lMobQuestHerdID & " created successfully!", zPortID
                        subSendMsg "&W      TagMobilesID# " & lHerdMobID & " created successfully!", zPortID
                        subSendMsg "&W   Reward ObjectID# " & lObjectID & " " & Mid(zReturnObjectName(lObjectID), 1, 42), zPortID
                        subSendMsg "&A-------------------------------", zPortID
                        subSendMsg "&GYour next step is to Title the newly created Mob Herd Quest: &gIMMO MQHE HQT (herd title)", zPortID
                    End If
                Else
                    subSendMsg "&RObjectID " & lObjectID & " must be in your inventory to create a new Mob Herd Quest.", zPortID
                    lShow = 1
                End If
                
                If (lShow = 1) Then subSendMsg "&gSYNTAX: IMMO MQHE NEW ObjectID", zPortID
            Case "HQT"
                bShow = True
                zSQL = "SELECT HerdQuestTitle FROM tblMobQuestHerd WHERE (MobQuestHerdID=" & lMobQuestHerdID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobQuestHerdID & " old description:" & vbCrLf & MyCStr(rsHelp!HerdQuestTitle), zPortID
                    rsHelp.Edit
                    rsHelp!HerdQuestTitle = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobQuestHerdID " & lMobQuestHerdID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "MS"
                bShow = True
                zSQL = "SELECT MsgSuccess FROM tblMobQuestHerd WHERE (MobQuestHerdID=" & lMobQuestHerdID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobQuestHerdID & " old description:" & vbCrLf & MyCStr(rsHelp!MsgSuccess), zPortID
                    rsHelp.Edit
                    rsHelp!MsgSuccess = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobQuestHerdID " & lMobQuestHerdID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "MF"
                bShow = True
                zSQL = "SELECT MsgFailure FROM tblMobQuestHerd WHERE (MobQuestHerdID=" & lMobQuestHerdID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobQuestHerdID & " old description:" & vbCrLf & MyCStr(rsHelp!MsgFailure), zPortID
                    rsHelp.Edit
                    rsHelp!MsgFailure = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RMobQuestHerdID " & lMobQuestHerdID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "RR"
                bShow = True
                zSQL = "SELECT RareRandom FROM tblMobQuestHerd WHERE (MobQuestHerdID=" & lMobQuestHerdID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    rsHelp.Edit
                    rsHelp!RareRandom = MyCLng(zLine)
                    rsHelp.Update
                Else
                    subSendMsg "&RMobQuestHerdID " & lMobQuestHerdID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "TAG", "ADD"
                'SELECT MobID, MobName, HerdMobID FROM tblMob WHERE (((MobID)=" & lMobQuestHerdID & "));
                lShow = 0
                If (lMobQuestHerdID <> 0) Then
                    bShow = True
                    zSQL = "SELECT MobID, MobName, HerdMobID FROM tblMob WHERE (MobID=" & MyCLng(zWord4) & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    rsHelp.Edit
                    rsHelp!HerdMobID = lMobQuestHerdID
                    subSendMsg "&M" & MyCStr(rsHelp!MobName) & gblzFNMAG & " added to &wHerd Group Quest " & lMobQuestHerdID & gblzFNMAG & "!", zPortID
                    rsHelp.Update
                    Set rsHelp = Nothing
                Else
                    subSendMsg "&RThat HerdMobID Quest Group does not exist.", zPortID
                    lShow = 1
                End If
                If (lShow = 1) Then subSendMsg "&gSYNTAX: IMMO MQHE TAG HerdMobID# MobID", zPortID
            Case "DID" 'Delete Mob Quest Herd Editor ID line and clear mobs to it
                If (lngSQLRecordCount("SELECT HerdMobID FROM tblMobQuestHerd WHERE (HerdMobID=" & lMobQuestHerdID & ");") <> 0) Then
                    'Detatch Mobs to this HerdMobID
                    zSQL = "SELECT HerdMobID, MobID, MobName, X, Y, Z FROM tblMob WHERE (HerdMobID=" & lMobQuestHerdID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        Do While (Not rsHelp.EOF)
                            rsHelp.Edit
                            rsHelp!HerdMobID = 0
                            rsHelp.Update
                            subSendMsg "&MMOB DETACHED (but still well in the realm) MATCHING HerdMobID " & lMobQuestHerdID & "!" & vbCrLf & "&W:MOBID:&a#&w" & MyCStr(rsHelp!MobID) & vbCrLf & gblzFBMAG & " >Mob Name: " & gblzFNMAG & MyCStr(rsHelp!MobName) & vbCrLf & "&a >X:" & strForceSize(MyCStr(rsHelp!x), 15, " ", "A") & "Y:" & strForceSize(MyCStr(rsHelp!y), 15, " ", "A") & "Z:" & MyCStr(rsHelp!z), zPortID  'Check MobQuestHerdID for exact line matching in the record
                            rsHelp.MoveNext
                        Loop
                    End If
                    Set rsHelp = Nothing
                    
                    zSQL = "SELECT ObjectID FROM tblMobQuestHerd WHERE (HerdMobID=" & lMobQuestHerdID & ");"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                    If (Not rsHelp.EOF) Then
                        lObjectID = MyCLng(rsHelp!ObjectID)
                    End If
                    Set rsHelp = Nothing
                    
                    'Now place the object in front of the immortal
                    MyDB.Execute "UPDATE tblObject SET X=" & lX & ", Y=" & lY & ", Z=" & lZ & ", PlayerID=0, Status=0 WHERE (ObjectID=" & lObjectID & ");", dbFailOnError '0=ground
                    'Now remove the herd mob id
                    MyDB.Execute "DELETE HerdMobID FROM tblMobQuestHerd WHERE (HerdMobID=" & lMobQuestHerdID & ");", dbFailOnError
                    subSendMsg "&GMob Herd Quest was undone, ObjectID# " & lObjectID & " is on the ground before you.", zPortID
                Else
                    subSendMsg "&RHerdMobID " & lMobQuestHerdID & " group herd quest not found.", zPortID
                End If
            Case Else
               subSendMsg "&gNEW MOBID - Creates a new Mob Phrase Line (must be done first)" & vbCrLf & "HQT       - Set the Herd Quest Title." & vbCrLf & "OBID      - Add an Object ID to the herd link list." & vbCrLf & "PDONE     - Phrase Desc One" & vbCrLf & "ADD       - IMMO ADD HerdMobID MobID" & vbCrLf & "DID       - Deletes the MobID LineID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO MQHE <command> HerdMobID Object/MobID", zPortID
        End Select
        
        If (bShow) Then
            'lShow autodetects to show the mobs involved or the herd quest grouping record
            lShow = 1
            zSQL = "SELECT MobQuestHerdID, HerdQuestTitle, HerdMobID, ObjectID, AreaID, RareRandom, MsgSuccess, MsgFailure, OxygenRequiredLevel, GravityLevel, RadiatedAreaLevel, GasAreaLevel, GasAreaLevelDesc, HeatAreaLevel, ModificationDuration FROM tblMobQuestHerd WHERE (MobQuestHerdID=" & lMobQuestHerdID & ");"
            If (lngSQLRecordCount(zSQL) = 0) Then
                lShow = 2
                zSQL = "SELECT MobQuestHerdID, HerdQuestTitle, HerdMobID, ObjectID, AreaID, RareRandom, MsgSuccess, MsgFailure, OxygenRequiredLevel, GravityLevel, RadiatedAreaLevel, GasAreaLevel, GasAreaLevelDesc, HeatAreaLevel, ModificationDuration FROM tblMobQuestHerd WHERE (HerdMobID=" & lMobQuestHerdID & ");"
            End If
            
            lHerdMobID = 0
            Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsHelp.EOF) Then
                lHerdMobID = MyCLng(rsHelp!HerdMobID) 'used to find the mobs after this data record is shown
                subSendMsg "&A----------------------------------&W{&aHERD QUEST&W}&a----------------------------------", zPortID
                subSendMsg "&WEditorHerdID# " & MyCStr(rsHelp!MobQuestHerdID) & "     TagMobilesID# " & MyCStr(lHerdMobID), zPortID  'Check MobQuestHerdID for exact line matching in the record
                subSendMsg "&w >Object ID: " & "&a" & MyCStr(rsHelp!ObjectID) & " &w" & zReturnObjectName(MyCLng(rsHelp!ObjectID)), zPortID
                subSendMsg "&W >Herd Quest Title: " & MyCStr(rsHelp!HerdQuestTitle), zPortID
                subSendMsg "&Y" & " >Rare Random: " & MyCStr(rsHelp!RareRandom), zPortID
                subSendMsg "&G >Msg Success: " & vbCrLf & " " & MyCStr(rsHelp!MsgSuccess), zPortID
                subSendMsg "&R >Msg Failure: " & vbCrLf & " " & MyCStr(rsHelp!MsgFailure), zPortID
            Else
                subSendMsg gblzFBRED & lMobQuestHerdID & " did not match the MobQuestHerdID or the HerdMobID.", zPortID
            End If
            Set rsHelp = Nothing
            
            If (lHerdMobID <> 0) Then
                subSendMsg "&AMobiles are tagged to the above Herd Quest with TagMobilesID# " & lHerdMobID & vbCrLf & "The Mobiles are as follows:", zPortID
                'Show Mobs Attatched to this HerdMobID
                zSQL = "SELECT MobID, MobName, X, Y, Z FROM tblMob WHERE (HerdMobID=" & lHerdMobID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsHelp.EOF) Then
                    Do While (Not rsHelp.EOF)
                        subSendMsg "&MMobID# " & strForceSize(MyCStr(rsHelp!MobID), 12, " ", "A") & " " & gblzFNMAG & strForceSize(MyCStr(rsHelp!MobName), 30, " ", "A") & "&a at x" & MyCStr(rsHelp!x) & " y" & MyCStr(rsHelp!y) & " z" & MyCStr(rsHelp!z), zPortID
                        rsHelp.MoveNext
                    Loop
                Else
                    subSendMsg "&gNo mobiles matched the HerdMobID " & lHerdMobID & ".", zPortID
                    subSendMsg "&gYou can 'IMMO MQHE TAG # MobID' to the herd <value> group.", zPortID
                End If
                Set rsHelp = Nothing
            End If
        End If
    Else
        bShowSyntax = True
    End If
    
    If (bShowSyntax) Then
        subSendMsg "&GMob Quest Herd Editor makes it so many mobiles are involved in a quest." & vbCrLf & "The Player would kill all the mobiles of the herd group to recieve their reward." & vbCrLf & "So the very first thing you would do is create two to maybe nine mobiles." & vbCrLf & "Use the IMMO MC (mobname) command and MEDIT to create your mob." & vbCrLf & "Write down the created MobIDs, you will need to tag them soon." & vbCrLf & "Use the IMMO OC (objectname) and FORGE command to make your magical object." & vbCrLf & "Write down the Object ID to insert into the Mob Quest Herd record.", zPortID
        subSendMsg "&gNow that you have your MobIDs and your one ObjectID you can begin creating your Mob Herd Quest!" & vbCrLf, zPortID
        subSendMsg "&gNEW    - Creates a new Quest Herd record to edit (must be done first)", zPortID
        subSendMsg "&gREVEAL - Shows all the EditorHerdIDs (the #s) in the System", zPortID
        subSendMsg "&gHQT # <title> - Creates a Title of your Quest Herd record", zPortID
        subSendMsg "&gSHOW #        - Shows you the EditorHerdID details and all MobileIDs involved", zPortID
        subSendMsg "&gMS # <msg>    - Create success msg, as all the mobs were dispatched in time", zPortID
        subSendMsg "&gMF # <msg>    - Create failure msg, the chance for a rare failed", zPortID
        subSendMsg "&gRR # <value>  - Create a rare chance number to get the reward object", zPortID
        subSendMsg "&gTAG # <mobid> - This is the Tagger command you would use for each Mobile ID", zPortID
        subSendMsg "&gDID #         - Delete this EditorHerdID, mobiles will only lose their" & vbCrLf & "                TagMobilesID and will be safe and active afterwards.", zPortID
    End If
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobQuestHerdEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobSpeakReorder(lMobID As Long)
On Error GoTo Err_Check
    Dim lCount As Long
    Dim rsHelp As Recordset
    Dim bSpeakCombat As Boolean
    Dim bSpeakDeath As Boolean
    Dim bHoldSpeakCombat As Boolean
    Dim bHoldSpeakDeath As Boolean
    lCount = 0
    bHoldSpeakCombat = False
    bHoldSpeakDeath = False
    Set rsHelp = MyDB.OpenRecordset("SELECT MobSpeakSortOrder, SpeakCombat, SpeakDeath FROM tblMobSpeak WHERE (MobID=" & lMobID & ") ORDER BY MobSpeakSortOrder, SpeakCombat DESC, SpeakDeath DESC;", dbOpenDynaset)
    Do While (Not rsHelp.EOF)
        lCount = lCount + 1
        bSpeakCombat = (MyCInt(rsHelp!SpeakCombat) <> 0)
        If (bHoldSpeakCombat <> bSpeakCombat) Then
            bHoldSpeakCombat = bSpeakCombat
            lCount = 1
        End If
        
        bSpeakDeath = (MyCInt(rsHelp!SpeakDeath) <> 0)
        If (bHoldSpeakDeath <> bSpeakDeath) Then
            bHoldSpeakDeath = bSpeakDeath
            lCount = 1
        End If
        rsHelp.Edit
        rsHelp!MobSpeakSortOrder = lCount
        rsHelp.Update
        rsHelp.MoveNext
    Loop
    Set rsHelp = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobSpeakReorder," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobSpeakEditor(zWord2 As String, zWord3 As String, zWord4 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsHelp As Recordset
    Dim lMobID As Long
    Dim lLineID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    Dim bShowSyntax As Boolean
    Dim zMobName As String
    Dim zCommand As String
    
    lMobID = MyCLng(zWord3)
    zMobName = zReturnMobName(lMobID)
    If (Len(zMobName) > 0) Then
        subSendMsg "&W" & zMobName & " ID#" & lMobID, zPortID
        bShowSyntax = False
        zCommand = UCase(Mid(zWord2, 1, 4))
        lLineID = MyCLng(zWord4)
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        If (zWord4 = "") Then zLine = ""
        bShow = False
        zSQL = ""
        Select Case zCommand
            Case "SHOW" 'show
                bShow = True
            Case "MS"
                bShow = True
                zSQL = "SELECT MobSocial FROM tblMobSpeak WHERE (MobID=" & lMobID & " AND MobSpeakSortOrder=" & lLineID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!MobSocial), zPortID
                    rsHelp.Edit
                    rsHelp!MobSocial = zLine
                    rsHelp.Update
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SM"
                bShow = True
                zSQL = "SELECT SpeakMessage FROM tblMobSpeak WHERE (MobID=" & lMobID & " AND MobSpeakSortOrder=" & lLineID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old description:" & vbCrLf & MyCStr(rsHelp!SpeakMessage), zPortID
                    rsHelp.Edit
                    rsHelp!SpeakMessage = zLine
                    rsHelp.Update
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SC"
                bShow = True
                zSQL = "SELECT SpeakCombat FROM tblMobSpeak WHERE (MobID=" & lMobID & " AND MobSpeakSortOrder=" & lLineID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old value:" & vbCrLf & MyCStr(rsHelp!SpeakCombat), zPortID
                    rsHelp.Edit
                    Select Case UCase(zLine)
                        Case "TRUE", "1", "-1"
                            rsHelp!SpeakCombat = True
                        Case Else
                            rsHelp!SpeakCombat = False
                    End Select
                    rsHelp.Update
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SD"
                bShow = True
                zSQL = "SELECT SpeakDeath FROM tblMobSpeak WHERE (MobID=" & lMobID & " AND MobSpeakSortOrder=" & lLineID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old value:" & vbCrLf & MyCStr(rsHelp!SpeakDeath), zPortID
                    rsHelp.Edit
                    Select Case UCase(zLine)
                        Case "TRUE", "1", "-1"
                            rsHelp!SpeakDeath = True
                        Case Else
                            rsHelp!SpeakDeath = False
                    End Select
                    rsHelp.Update
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "MSO", "SO", "MSSO"
                bShow = True
                zSQL = "SELECT MobSpeakSortOrder FROM tblMobSpeak WHERE (MobID=" & lMobID & " AND MobSpeakSortOrder=" & lLineID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AMobID " & lMobID & " old value:" & vbCrLf & MyCStr(rsHelp!MobSpeakSortOrder), zPortID
                    rsHelp.Edit
                    rsHelp!MobSpeakSortOrder = Abs(MyCLng(Mid(zLine, 1, 5)))
                    rsHelp.Update
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "NEW" 'New MobID
                If (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lMobID & ");") = 1) Then
                    bShow = True
                    zSQL = "tblMobSpeak"
                    Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenTable)
                    rsHelp.AddNew
                    rsHelp!MobSpeakSortOrder = lLineID
                    rsHelp!MobID = lMobID
                    rsHelp.Update
                    subSendMsg "&W*NEW* Mob Speak Editor line created successfully!", zPortID
                    Set rsHelp = Nothing
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
            Case "DID" 'Delete Mob Speak ID
                zSQL = "SELECT MobID FROM tblMobSpeak WHERE (MobID=" & lMobID & " AND MobSpeakSortOrder=" & lLineID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    rsHelp.Delete
                    subSendMsg "&WMobID " & lMobID & " and Speak Order Line " & lLineID & " record line was deleted successfully!", zPortID
                Else
                    bShowSyntax = True
                    subSendMsg "&R Line ID " & lLineID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case Else
                bShowSyntax = True
        End Select
        
        subMobSpeakReorder lMobID

        If (bShow) Then
            zSQL = "SELECT MobID, ObjectName, MobSocial, SpeakMessage, SpeakCombat, CombatAverageDmg, SpeakObject, MoveObject, SpeakDeath, DX, DY, DZ, SpeakDestination, MobSpeakSortOrder FROM tblMobSpeak WHERE (MobID=" & lMobID & ") ORDER BY MobSpeakSortOrder;"
            Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsHelp.EOF) Then
                Do While (Not rsHelp.EOF)
                    subSendMsg "&A:Speak Order: " & MyCStr(rsHelp!MobSpeakSortOrder), zPortID
                    subSendMsg "&M >Mob Social: " & vbCrLf & MyCStr(rsHelp!MobSocial), zPortID
                    subSendMsg "&y >Speak Message:" & vbCrLf & MyCStr(rsHelp!SpeakMessage), zPortID
                    subSendMsg "&g >Speak Combat:" & basBoolean(MyCInt(rsHelp!SpeakCombat)), zPortID
                    subSendMsg "&g >Speak Death:" & basBoolean(MyCInt(rsHelp!SpeakDeath)), zPortID
                    'subSendMsg "&g >Combat Average Dmg:" & MyCStr(rsHelp!CombatAverageDmg), zPortID
                    'subSendMsg "&w"  & " >Full Object Name: " & vbCrLf & MyCStr(rsHelp!ObjectName), zPortID
                    'subSendMsg "&g >Speak Object:" & vbCrLf & MyCStr(rsHelp!SpeakObject), zPortID
                    'subSendMsg "&g >Move Object:" & vbCrLf & MyCStr(rsHelp!MoveObject), zPortID
                    'subSendMsg "&g >DX:" & strForceSize(MyCStr(rsHelp!DX), 15, " ", "A") & "DY:" & strForceSize(MyCStr(rsHelp!DY), 15, " ", "A") & "DZ:" & strForceSize(MyCStr(rsHelp!DZ), 15, " ", "A"), zPortID
                    'subSendMsg "&g >SpeakDestination:" & vbCrLf & MyCStr(rsHelp!SpeakDestination), zPortID
                    rsHelp.MoveNext
                Loop
            End If
            Set rsHelp = Nothing
        End If
    Else
        subSendMsg "&RMobID " & lMobID & " is not a valid mobile identifier.", zPortID
        bShowSyntax = True
    End If
    
    If (bShowSyntax) Then subSendMsg "&gNEW MOBID - Creates a new Mob Speak Line (must be done first)" & vbCrLf & "SHOW      - Shows the complete Mob Speak Lines" & vbCrLf & "MS        - Mob Social" & vbCrLf & "SM        - Speak Message" & vbCrLf & "SC        - Speak Combat True False" & vbCrLf & "SD        - Speak Death" & vbCrLf & "DID       - Deletes the MobID LineID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO MSE MOBID LINEID" & vbCrLf & "    ie: IMMO MSE <command> MOBID LINEID <value>", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobSpeakEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subHelpEditor(zWord2 As String, zWord3 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsHelp As Recordset
    Dim lHelpID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    
    If (Len(zWord3) < 12) Then
        lHelpID = MyCLng(zWord3)
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        bShow = False
        zSQL = ""
        Select Case Mid(zWord2, 1, 4)
            Case "SHOW" 'show
                bShow = True
            Case "IVL", "IL", "IMMO", "IMM", "IM", "I", "GOD" 'set immortallevel
                bShow = True
                zSQL = "SELECT ImmortalLevel FROM tblSystemHelp WHERE (SystemHelpID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AHELPID " & lHelpID & " old ImmortalLevel: " & MyCStr(rsHelp!ImmortalLevel), zPortID
                    rsHelp.Edit
                    rsHelp!ImmortalLevel = MyCLng(zLine)
                    rsHelp.Update
                    subSendMsg "&AHELPID " & lHelpID & " new ImmortalLevel: " & MyCLng(zLine), zPortID
                Else
                    subSendMsg "&RHELPID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "TITL" 'save title
                bShow = True
                zSQL = "SELECT SystemHelpTitle FROM tblSystemHelp WHERE (SystemHelpID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AHELPID " & lHelpID & " old title:" & vbCrLf & MyCStr(rsHelp!SystemHelpTitle), zPortID
                    rsHelp.Edit
                    rsHelp!SystemHelpTitle = Mid(UCase(zLine), 1, 255)
                    rsHelp.Update
                Else
                    subSendMsg "&RHELPID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "SKEY", "KEY", "KEYS", "KEYW", "KSW" 'save: key search words
                bShow = True
                zSQL = "SELECT SystemHelpKeywords FROM tblSystemHelp WHERE (SystemHelpID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AHELPID " & lHelpID & " old keywords:" & vbCrLf & MyCStr(rsHelp!SystemHelpKeywords), zPortID
                    rsHelp.Edit
                    rsHelp!SystemHelpKeywords = Mid(UCase(zLine), 1, 255)
                    rsHelp.Update
                Else
                    subSendMsg "&RHELPID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "DESC" 'overwrite description
                bShow = True
                zSQL = "SELECT SystemHelpDesc FROM tblSystemHelp WHERE (SystemHelpID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    subSendMsg "&AHELPID " & lHelpID & " old description:" & vbCrLf & MyCStr(rsHelp!SystemHelpDesc), zPortID
                    rsHelp.Edit
                    rsHelp!SystemHelpDesc = zLine
                    rsHelp.Update
                Else
                    subSendMsg "&RHELPID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case "NEW" 'New HelpID
                bShow = True
                zSQL = "tblSystemHelp"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenTable)
                rsHelp.AddNew
                lHelpID = MyCLng(rsHelp!SystemHelpID)
                rsHelp!SystemHelpKeywords = "HELPID"
                rsHelp.Update
                subSendMsg "&WNEW HELPID " & lHelpID & " created successfully!" & vbCrLf & gblzFBMAG & "You can find all new HELPIDs by typing HELP HELPID.", zPortID
                Set rsHelp = Nothing
            Case "DID" 'Delete HelpID
                zSQL = "SELECT SystemHelpID FROM tblSystemHelp WHERE (SystemHelpID=" & lHelpID & ");"
                Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsHelp.EOF) Then
                    rsHelp.Delete
                    subSendMsg "&WHELPID " & lHelpID & " was deleted successfully!", zPortID
                Else
                    subSendMsg "&RHELPID " & lHelpID & " not found.", zPortID
                End If
                Set rsHelp = Nothing
            Case Else
                subSendMsg "&gNEW       - Creates a new HelpID (must be done first)" & vbCrLf & "SHOW      - Shows the complete HelpID" & vbCrLf & "TITLE     - Overwrites the HelpID's TITLE" & vbCrLf & "DESC      - Overwrites the HelpID's DESCRIPTION" & vbCrLf & "IL        - Sets the Immortal Level (0 for mortals)" & vbCrLf & "SKEY      - Overwrites the HelpID's KEYWORDS" & vbCrLf & "DID       - Deletes the HelpID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO HELP [NEW/SHOW/TITLE/DESC/SKEY/IL/DID] HELPID", zPortID
        End Select
        
        If (bShow) Then
            zSQL = "SELECT SystemHelpID, SystemHelpTitle, SystemHelpKeywords, SystemHelpDesc, ImmortalLevel FROM tblSystemHelp WHERE (SystemHelpID=" & lHelpID & ");"
            Set rsHelp = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsHelp.EOF) Then
                subSendMsg "&w>HELPID#" & MyCStr(rsHelp!SystemHelpID), zPortID
                subSendMsg "&w>Immortal View Level (mortals see lv 0 only): " & MyCStr(rsHelp!ImmortalLevel), zPortID
                subSendMsg "&w>SKEY (key search words)" & vbCrLf & MyCStr(rsHelp!SystemHelpKeywords), zPortID
                subSendMsg "&G>TITLE" & vbCrLf & MyCStr(rsHelp!SystemHelpTitle), zPortID
                subSendMsg "&g>DESCRIPTION" & vbCrLf & MyCStr(rsHelp!SystemHelpDesc), zPortID
            Else
                subSendMsg "&RData not found for HELPID " & lHelpID & ".", zPortID
            End If
            Set rsHelp = Nothing
        End If
    Else
        subSendMsg "&RHelpID " & zWord3 & " is too long a value to process.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subHelpEditor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subEditEmoteChart(zWord2 As String, zWord3 As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsChart As Recordset
    Dim lChartEmoteID As Long
    Dim zSQL As String
    Dim zLine As String
    Dim bShow As Boolean
    
    If (Len(zWord3) < 11) Then
        lChartEmoteID = MyCLng(zWord3)
        zLine = zDropFirstWordCleanLine(zPromptOriginal)
        zLine = zDropFirstWordCleanLine(zLine)
        zLine = zDropFirstWordCleanLine(zLine)
        If (zWord3 = "") Then zLine = ""
        bShow = False
        zSQL = ""
        Select Case Mid(zWord2, 1, 4)
            Case "SHOW" 'show
                bShow = True
            Case "EMOT", "KC", "SKEY", "KEY", "KEYS" 'save keywords
                bShow = True
                zSQL = "SELECT KeywordCommand FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    subSendMsg "&AChartEmoteID " & lChartEmoteID & " old KeywordCommand:" & vbCrLf & MyCStr(rsChart!KeywordCommand), zPortID
                    rsChart.Edit
                    rsChart!KeywordCommand = Mid(UCase(zLine), 1, 15)
                    rsChart.Update
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case "E1PN" 'save keywords Emote1stPerson, Emote2ndPerson, Emote3rdPerson, Emote3rdPersonNoTarget, WhereWeatherType, AutoMovesPlayer
                bShow = True
                zSQL = "SELECT Emote1stPersonNoTarget FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    subSendMsg "&AChartEmoteID " & lChartEmoteID & " old KeywordCommand:" & vbCrLf & MyCStr(rsChart!Emote1stPersonNoTarget), zPortID
                    rsChart.Edit
                    rsChart!Emote1stPersonNoTarget = zLine
                    rsChart.Update
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case "E1P" 'save keywords Emote2ndPerson, Emote3rdPerson, Emote3rdPersonNoTarget, WhereWeatherType, AutoMovesPlayer
                bShow = True
                zSQL = "SELECT Emote1stPerson FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    subSendMsg "&AChartEmoteID " & lChartEmoteID & " old KeywordCommand:" & vbCrLf & MyCStr(rsChart!Emote1stPerson), zPortID
                    rsChart.Edit
                    rsChart!Emote1stPerson = zLine
                    rsChart.Update
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case "E2P" 'save keywords Emote3rdPerson, Emote3rdPersonNoTarget, WhereWeatherType, AutoMovesPlayer
                bShow = True
                zSQL = "SELECT Emote2ndPerson FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    subSendMsg "&AChartEmoteID " & lChartEmoteID & " old KeywordCommand:" & vbCrLf & MyCStr(rsChart!Emote2ndPerson), zPortID
                    rsChart.Edit
                    rsChart!Emote2ndPerson = zLine
                    rsChart.Update
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case "E3P" 'save keywords Emote3rdPersonNoTarget
                bShow = True
                zSQL = "SELECT Emote3rdPerson FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    subSendMsg "&AChartEmoteID " & lChartEmoteID & " old KeywordCommand:" & vbCrLf & MyCStr(rsChart!Emote3rdPerson), zPortID
                    rsChart.Edit
                    rsChart!Emote3rdPerson = zLine
                    rsChart.Update
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case "E3PN" 'save keywords
                bShow = True
                zSQL = "SELECT Emote3rdPersonNoTarget FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    subSendMsg "&AChartEmoteID " & lChartEmoteID & " old KeywordCommand:" & vbCrLf & MyCStr(rsChart!Emote3rdPersonNoTarget), zPortID
                    rsChart.Edit
                    rsChart!Emote3rdPersonNoTarget = zLine
                    rsChart.Update
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case "NEW" 'New ChartEmoteID
                bShow = True
                zSQL = "tblChartEmote"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenTable)
                rsChart.AddNew
                lChartEmoteID = MyCLng(rsChart!ChartEmoteID)
                rsChart!KeywordCommand = MyCStr(lChartEmoteID)
                rsChart.Update
                subSendMsg "&WNEW ChartEmoteID " & lChartEmoteID & " created successfully!" & vbCrLf & gblzFBMAG & "You can find all new ChartEmoteIDs by typing HELP EMOTION.", zPortID
                Set rsChart = Nothing
            Case "DID" 'Delete ChartEmoteID
                zSQL = "SELECT ChartEmoteID FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & ");"
                Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                If (Not rsChart.EOF) Then
                    rsChart.Delete
                    subSendMsg "&WChartEmoteID " & lChartEmoteID & " was deleted successfully!", zPortID
                Else
                    subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
                End If
                Set rsChart = Nothing
            Case Else
                subSendMsg "&gNEW   Creates a new ChartEmoteID (must be done first)" & vbCrLf & "SHOW      - Shows the complete ChartEmoteID" & vbCrLf & "E1PN      - Overwrites Emote1stPersonNoTarget" & vbCrLf & "E1P       - Overwrites Emote1stPerson" & vbCrLf & "E2P       - Overwrites Emote2ndPerson" & vbCrLf & "E3P       - Overwrites Emote3rdPerson" & vbCrLf & "E3PN      - Overwrites Emote1stPersonNoTarget" & vbCrLf & "WWT       - Overwrites WhereWeatherType #" & vbCrLf & "SKEY      - Overwrites the ChartEmoteID's EmoteName" & vbCrLf & "DID       - Deletes the ChartEmoteID (this cannot be undone)" & "&G" & vbCrLf & "SYNTAX: IMMO EEC [NEW/SHOW/DID/EMOTE/E1PN/E1P/E2P/E3P/E3PN] ChartEmoteID&g" & vbCrLf & "NOTE: You must use the EMOTEID to edit values." & vbCrLf & "      IMMO EEC SHOW EMOTENAME/ID will show you the ID.", zPortID
                subSendMsg "&gNOTE: Variables: Name: %s1 1stPerson, %g10 him/her, %g11 he/she, %g12 his/her, %g13 his/herself" & vbCrLf & "%g14 male/female, %g15 guy/gal, %g15 boy/girl", zPortID
                subSendMsg "&gNOTE: replace the 1 with a 2 as in %s1 make it %s2 to use the targets name and gender.", zPortID
                subSendMsg "&g      the system will look after these variables.", zPortID
        End Select
        
        If (bShow) Then
            zSQL = "SELECT ChartEmoteID, KeywordCommand, Emote1stPersonNoTarget, Emote1stPerson, Emote2ndPerson, Emote3rdPerson, Emote3rdPersonNoTarget, WhereWeatherType, AutoMovesPlayer FROM tblChartEmote WHERE (ChartEmoteID=" & lChartEmoteID & " or KeywordCommand='" & zKeepLettersOnly(zLine) & "');"
            Set rsChart = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsChart.EOF) Then
                subSendMsg "&w>ChartEmoteID#               : " & MyCStr(rsChart!ChartEmoteID), zPortID
                subSendMsg "&M>KeywordCommand         EMOTE: " & gblzFNMAG & MyCStr(rsChart!KeywordCommand), zPortID
                subSendMsg "&M>Emote1stPersonNoTarget E1PN : " & vbCrLf & gblzFNMAG & MyCStr(rsChart!Emote1stPersonNoTarget), zPortID
                subSendMsg "&g   &MYou ponder the meaning of the universe.", zPortID
                subSendMsg "&M>Emote1stPerson         E1P  : " & vbCrLf & gblzFNMAG & MyCStr(rsChart!Emote1stPerson), zPortID
                subSendMsg "&g   &MYou ponder some thoughts with %s2.", zPortID
                subSendMsg "&M>Emote2ndPerson         E2P  : " & vbCrLf & gblzFNMAG & MyCStr(rsChart!Emote2ndPerson), zPortID
                subSendMsg "&g   &M%s1 ponders some thoughts with you.", zPortID
                subSendMsg "&M>Emote3rdPerson         E3P  : " & vbCrLf & gblzFNMAG & MyCStr(rsChart!Emote3rdPerson), zPortID
                subSendMsg "&g   &M%s1 ponders some thoughts with %s2.", zPortID
                subSendMsg "&M>Emote3rdPersonNoTarget E3PN : " & vbCrLf & gblzFNMAG & MyCStr(rsChart!Emote3rdPersonNoTarget), zPortID
                subSendMsg "&g   &M%s1 ponders the meaning of the universe.", zPortID
                subSendMsg "&gor &M%s1 ponders to %g13.", zPortID
                subSendMsg "&g>WhereWeatherType       WWT  : " & MyCStr(rsChart!WhereWeatherType), zPortID
                subSendMsg "&g>AutoMovesPlayer             : " & MyCStr(rsChart!AutoMovesPlayer), zPortID
            Else
                subSendMsg "&RChartEmoteID " & lChartEmoteID & " not found.", zPortID
            End If
            Set rsChart = Nothing
        End If
    Else
        subSendMsg "&RChartEmoteID " & zWord3 & " is too long a value to process.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subEditEmoteChart," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalRankPlayer(zPlayerName As String, zClan As String, zRank As String, zPortID As String, lImmortalLevel As Long, lPlayerID As Long)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim rsClan As Recordset
    Dim lClanID As Long
    Dim zClanName As String
    Dim lClanMemberLevel As Long
    Dim iError As Integer
    Dim zSQL As String
    
    lClanMemberLevel = -1
    If (zClan = "BAN" Or Mid(zClan, 1, 4) = "IMMO") Then
        lClanMemberLevel = 0
    Else
        lClanMemberLevel = lRankLevel(zRank)
    End If
    iError = 0
    If (lClanMemberLevel <> -1) Then
        lClanID = -1
        If (zClan = "BAN" Or Mid(zClan, 1, 4) = "IMMO") Then
            zSQL = ""
            lClanID = 0
            lClanMemberLevel = 0
        Else
            zSQL = "SELECT ClanID, ClanName FROM tblPlayerClan WHERE (ClanName Like '*" & zClan & "*');"
            Set rsClan = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsClan.EOF) Then
                lClanID = MyCLng(rsClan!ClanID)
                zClanName = MyCStr(rsClan!ClanName)
            Else
                iError = 1
            End If
            Set rsClan = Nothing
        End If
        
        If (lClanID <> -1) Then
            Set rsPlayer = MyDB.OpenRecordset("SELECT RecallX, RecallY, RecallZ, X, Y, Z, ImmortalLevel, PlayerID, PlayerName, ClanID, ClanMemberLevel FROM tblPlayer WHERE (PlayerName Like '" & zPlayerName & "');", dbOpenDynaset)
            If (Not rsPlayer.EOF) Then
                Select Case Mid(zClan, 1, 4)
                    Case "IMMO", "GOD", "GODS"
                        If (lImmortalLevel > 99) Then
                            rsPlayer.Edit
                            rsPlayer!ImmortalLevel = MyCLng(zRank)
                            rsPlayer.Update
                        Else
                            subSendMsg "&GIL100: You do not have the security permissions to set immortal ranks.", zPortID
                        End If
                    Case Else
                        rsPlayer.Edit
                        rsPlayer!x = 0
                        rsPlayer!y = 0
                        rsPlayer!z = 0
                        rsPlayer!RecallX = 0
                        rsPlayer!RecallY = 0
                        rsPlayer!RecallZ = 0
                        rsPlayer!ClanID = lClanID
                        rsPlayer!ClanMemberLevel = lClanMemberLevel
                        rsPlayer.Update
                End Select
                subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " was rank modified.", zPortID
            Else
                iError = 1
            End If
            Set rsPlayer = Nothing
        End If
    Else
        iError = 1
    End If
    
    Select Case iError
        Case 1
            subSendMsg "&GIMMO RANK (full playername) (player induction clan) (player induction rank)", zPortID
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalRankPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lAreaClanID(lX As Long, lY As Long, lZ As Long) As Long
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    Set rsArea = MyDB.OpenRecordset("SELECT ClanID FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot) 'rsSList!SpellName = "" '25 long max
    If (Not rsArea.EOF) Then
        lReturn = MyCLng(rsArea!ClanID)
    End If
    Set rsArea = Nothing
    lAreaClanID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lAreaClanID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subSpellCreateBodyLocation(zPlayerName As String, zRealSpellName As String, lLearnLevelRestricted As Long, zCreateWeaponType As String, lCreateBodyLocation As Long, lPlayerID As Long, lX As Long, lY As Long, lZ As Long, lPlayerLevel As Long, zPortID As String, lSpellHP As Long, lSpellAC As Long, lSpellHITROLL As Long, lSpellDAMROLL As Long, lSpellStr As Long, lSpellInt As Long, lSpellWis As Long, lSpellDex As Long, lSpellCon As Long, lSpellCha As Long, lSpellLuc As Long, lSpellGrip As Long, lSpellMana As Long, lSpellSoul As Long, lSpellEssence As Long, lSpellMove As Long, lLevelRequirement As Long, lCraftedLevel As Long, lWeight As Long, lGold As Long)
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim zObjectName As String
    Dim lObjectID As Long
    Dim lFireElementalDamageMAX As Long
    Dim lLightningElementalDamageMAX As Long
    Dim lColdElementalDamageMAX As Long
    Dim lPoisonElementalDamageMAX As Long
    Dim lRare As Long
    Dim lTreasure As Long
    Dim lTotalElementalMAX As Long
    Dim lTotalStats As Long
    Dim lAC As Long
    Dim lMAXCheck As Long
    
    zObjectName = zDropFirstWordCleanLine(LCase(zRealSpellName)) 'all craft spells should start with craftspell mystical armour
    zObjectName = zObjectName & ", was crafted as " & MyCStr(zAdverb(zTranslateLocation(lCreateBodyLocation, "S"), 3) & zTranslateLocation(lCreateBodyLocation, "S") & " item")
    
    lRare = 0
    lTreasure = 0
    lTotalStats = 0
    lTotalElementalMAX = 0
    lFireElementalDamageMAX = 0
    lLightningElementalDamageMAX = 0
    lColdElementalDamageMAX = 0
    lPoisonElementalDamageMAX = 0
    
    Set rsObject = MyDB.OpenRecordset("tblObject", dbOpenDynaset) 'Find the object
    rsObject.AddNew
    lObjectID = MyCLng(rsObject!ObjectID)
    rsObject!x = lX
    rsObject!y = lY
    rsObject!z = lZ
    rsObject!WeaponType = zCreateWeaponType
    
    If (lCraftedLevel > 1) Then
        If (Len(zCreateWeaponType) > 0) Then 'weapons can be enchanted to
            lMAXCheck = lRandom(2) + 1
            If lRandom(25) = 1 Then lMAXCheck = lMAXCheck + lRandom(2) + 1
            If lRandom(25) = 1 Then lMAXCheck = lMAXCheck + lRandom(3) + 1
            Do While (lMAXCheck > 0)
                lMAXCheck = lMAXCheck - 1
                Select Case lRandom(13)
                    Case 1
                        lFireElementalDamageMAX = lFireElementalDamageMAX + 50 + lRandom(100)
                        lLightningElementalDamageMAX = lLightningElementalDamageMAX + 50 + lRandom(100)
                        lColdElementalDamageMAX = lColdElementalDamageMAX + 50 + lRandom(100)
                        lPoisonElementalDamageMAX = lPoisonElementalDamageMAX + 50 + lRandom(100)
                    Case 2 To 4
                        lFireElementalDamageMAX = lFireElementalDamageMAX + 100 + lRandom(100) + lPlayerLevel
                    Case 5 To 7
                        lLightningElementalDamageMAX = lLightningElementalDamageMAX + 100 + lRandom(100) + lPlayerLevel
                    Case 8 To 10
                        lColdElementalDamageMAX = lColdElementalDamageMAX + 100 + lRandom(100) + lPlayerLevel
                    Case 11 To 13
                        lPoisonElementalDamageMAX = lPoisonElementalDamageMAX + 100 + lRandom(100) + lPlayerLevel
                End Select
            Loop
        End If
        lTotalElementalMAX = lFireElementalDamageMAX + lLightningElementalDamageMAX + lColdElementalDamageMAX + lPoisonElementalDamageMAX
        If (lTotalElementalMAX > 999) Then lTreasure = lTreasure + 1
    End If
    
    rsObject!FireElementalDamageMAX = lFireElementalDamageMAX
    rsObject!LightningElementalDamageMAX = lLightningElementalDamageMAX
    rsObject!ColdElementalDamageMAX = lColdElementalDamageMAX
    rsObject!PoisonElementalDamageMAX = lPoisonElementalDamageMAX
    rsObject!PlayerID = lPlayerID
    rsObject!Status = 2 'player has it
    rsObject!ObjectName = LCase(zAntiSQLCrash(zObjectName))
    rsObject!LevelRequirement = lLevelRequirement
    rsObject!Weight = lWeight + lRandom(200)
    rsObject!Gold = lGold
    rsObject!HP = lSpellHP
    If (lCraftedLevel > 2) Then
        lAC = lSpellAC + lRandom(lPlayerLevel) + lCreateBodyLocation + lRandom(20)
        rsObject!AC = lAC
        rsObject!CHITROLL = lSpellHITROLL + lRandom(lPlayerLevel) + lCreateBodyLocation + lRandom(20)
        rsObject!AverageDamage = lSpellDAMROLL + lRandom(lPlayerLevel) + lCreateBodyLocation + lRandom(20)
        If (lRandom(300) = 1) Then lSpellStr = lRandom(9) + lSpellStr
        If (lRandom(200) = 1) Then lSpellInt = lRandom(9) + lSpellInt
        If (lRandom(200) = 1) Then lSpellWis = lRandom(9) + lSpellWis
        If (lRandom(300) = 1) Then lSpellDex = lRandom(9) + lSpellDex
        If (lRandom(400) = 1) Then lSpellCon = lRandom(9) + lSpellCon
        If (lRandom(200) = 1) Then lSpellCha = lRandom(9) + lSpellCha
        If (lRandom(500) = 1) Then lSpellLuc = lRandom(9) + lSpellLuc
    
        rsObject!Str = lSpellStr
        rsObject!Int = lSpellInt
        rsObject!Wis = lSpellWis
        rsObject!Dex = lSpellDex
        rsObject!Con = lSpellCon
        rsObject!Cha = lSpellCha
        rsObject!Luc = lSpellLuc
        rsObject!Grip = lSpellGrip
        rsObject!mana = lSpellMana
        rsObject!essence = lSpellEssence
        rsObject!soul = lSpellSoul
        rsObject!Move = lSpellMove
    End If
    If (lLearnLevelRestricted) > 3 Then
        If (lRandom(900) = 1) Then
            lRare = lRare + 1
            rsObject!MagicFind = 1 + lRandom(3)
        End If
        If (lRandom(1500) = 1) Then
            lRare = lRare + 1
            rsObject!MagicFindBase = lRandom(3)
        End If
    End If
    rsObject!Rare = lRare
    rsObject!Treasure = lTreasure
    lTotalStats = lSpellStr + lSpellInt + lSpellWis + lSpellDex + lSpellCon + lSpellCha + lSpellLuc
    rsObject!Location = lCreateBodyLocation 'default to hand item
    rsObject!CraftingPreserveYN = 0
    rsObject!DevalueDivider = 12
    '    lSpellHP, lSpellAC, lSpellHITROLL, lSpellDAMROLL, lSpellStr, lSpellInt, lSpellWis, lSpellDex, lSpellCon, lSpellCha, lSpellLuc, lSpellGrip, lSpellMana, lSpellSoul, lSpellEssence, lSpellMove
    rsObject.Update
    Set rsObject = Nothing
    'Now send this to the player's inventory
    If (lObjectID <> 0) Then
        MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & lPlayerID & ", " & lObjectID & ";", dbFailOnError
    End If
    
    'show off a nice object name
    zObjectName = zAdverb(zObjectName, 3) & zObjectName
    subSendMsgAreaAllDISmart "&g", zPlayerName, "%s1 create " & zObjectName & ".", "", "%s1 created " & zObjectName & ".", lX, lY, lZ
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpellCreateBodyLocation," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lTranslateMagicIASBonusFromClass(zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 239
        Case "CL", "IO"
            lReturn = 65
        Case "DR"
            lReturn = 50
        Case "BA"
            lReturn = 45
        Case "MO"
            lReturn = 13
        Case "AS"
            lReturn = 7
        Case "GY"
            lReturn = 41
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 4
        Case "GL"
            lReturn = 8
        Case "RA"
            lReturn = 31
        Case "KN"
            lReturn = 41
        Case "PA"
            lReturn = 36
        Case "WE"
            lReturn = 38
        Case "VA"
            lReturn = 27
        Case "PL", "VE"
            lReturn = 29
        Case "CY"
            lReturn = 19
    End Select
    
    lTranslateMagicIASBonusFromClass = lReturn
End Function
Public Function lTranslateMagicIASBonusFromRace(zRace As String) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 20
    Select Case zRace
        Case "GNO"
            lReturn = 30
        Case "HAL"
            lReturn = 35
        Case "OGE"
            lReturn = 5
        Case "ELF"
            lReturn = 50
        Case "ORC"
            lReturn = 11
        Case "FEL"
            lReturn = 33
        Case "PIX"
            lReturn = 60
        Case "HUM"
            lReturn = 21
        Case "MIN"
            lReturn = 19
        Case "DWA"
            lReturn = 19
        Case "TRO"
            lReturn = 4
        Case "DRA", "PIX"
            lReturn = 22
        Case "UND"
            lReturn = 1
    End Select
    lTranslateMagicIASBonusFromRace = lReturn
End Function
Public Function bObjectNamePresent(lX As Long, lY As Long, lZ As Long, zGroundObjectName As String) As Boolean
    Dim rsObject As Recordset
    Dim lObjectID As Long
    lObjectID = 0
    Set rsObject = MyDB.OpenRecordset("SELECT ObjectID FROM tblObject WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND ObjectName='" & zGroundObjectName & "');", dbOpenSnapshot)
    If (Not rsObject.EOF) Then
        lObjectID = MyCLng(rsObject!ObjectID)
    End If
    Set rsObject = Nothing
    bObjectNamePresent = (lObjectID <> 0)
End Function
Public Function bMorphState(zPassClass As String) As Boolean
Dim bReturn As Boolean
    bReturn = False
    Select Case zPassClass
        Case "VA", "WE", "PL", "VE", "CY", "IO"
            bReturn = True
    End Select
    bMorphState = bReturn
End Function
Public Sub subCastGroupOfProcedures(zPortID As String, zSpellName As String, zTargetName As String, zWord4 As String, zWord5 As String, zPromptOriginal As String)
'See also: GAINS subSpellListRaiseStats
On Error GoTo Err_Check 'spells dont change the players alignment
    Dim rsLearn As Recordset 'see also: subSpellListAttackSpells
    Dim rsObject As Recordset
    Dim lObjectID As Long
    Dim lDummy As Long
    Dim zSQL As String
    Dim bMoonAlignment As Boolean
    Dim lObjectActivateSpellNo As Long
    Dim bSpellCast As Boolean
    Dim zErrorLine As String
    Dim zCastError As String
    Dim lWeight As Long
    Dim lGold As Long
    Dim lCreateBodyLocation As Long
    Dim lRecordCount As Long
    Dim zGetSpellName As String
    Dim lPlayerLearnID As Long
    Dim lActivateManaCost As Long
    Dim lActivateEssenceCost As Long
    Dim lActivateSoulCost As Long
    Dim lActivateMoveCost As Long
    'Dim lResWaterElementalDamage As Long
    'Dim lResAirElementalDamage As Long
    'Dim lResEarthElementalDamage As Long
    'Dim lResHeatElementalDamage As Long 'Celcius > 35
    'Dim lResPhysicalDamage As Long
    'Dim lResLightningElementalDamage As Long
    'Dim lResColdElementalDamage As Long 'Celcius < 0
    'Dim lResFireElementalDamage As Long 'lOffensiveSpellDmg = (lElementalResistance(lOffensiveSpellDmg, lMResFireElementalDamage))
    
    Dim lXP As Long
    Dim bCostEssence As Boolean
    Dim bCostMana As Boolean
    Dim bCostMove As Boolean
    Dim bCostSoul As Boolean
    Dim zCastObjectName As String
    Dim zRealSpellName As String
    Dim lLearnLevelRestricted As Long
    Dim lSpellHP As Long
    Dim lSpellAC As Long
    Dim lSpellHITROLL As Long
    Dim lSpellDAMROLL As Long
    Dim lSpellStr As Long
    Dim lSpellInt As Long
    Dim lSpellWis As Long
    Dim lSpellDex As Long
    Dim lSpellCon As Long
    Dim lSpellCha As Long
    Dim lSpellLuc As Long
    Dim lSpellGrip As Long
    Dim lSpellMana As Long
    Dim lSpellEssence As Long
    Dim lSpellSoul As Long
    Dim lSpellMove As Long
    Dim bSpellComponentRequired As Boolean
    Dim bSpellComponentUsed As Boolean
    Dim zCreateWeaponType  As String
    Dim lLevelRequirement As Long
    Dim lCraftedLevel As Long
    
    Dim rsPlayer As Recordset
    Dim lFPlayerGroupStatus As Long
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zGender As String
    Dim zClass As String
    Dim zRace As String
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lCLuc As Long
    Dim lCCHA As Long
    Dim lCEssence As Long
    Dim lCMana As Long
    Dim lCSoul As Long
    Dim lCMove As Long
    Dim lFireballInterruption As Long
    Dim lSleepSpellInterruption As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lBlindDuration As Long
    Dim lStatus As Long
    Dim lStunDuration As Long
    Dim lEntanglementDuration As Long
    Dim bPlayerFound As Boolean
    Dim zPlayerName As String
    Dim lPlayerFleeDuration As Long
    Dim lAreaTrapDuration As Long
    Dim lInvisibilityDuration As Long
    Dim lFlyDuration As Long
    Dim lPlayerHeight As Long
    Dim lCalcuActivateDuration As Long
    Dim bAttackAway As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim lJailDuration As Long
    Dim lCamoflaguedDuration As Long
    Dim lImaginaryDuration As Long
    Dim lInvisLevel As Long
    Dim lElementalType As Long
    Dim lElementalCelsius As Long
    bPlayerFound = False
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT ImaginaryDuration, CamoflaguedDuration, JailDuration, TurnedIntoAnimalType, Height, FlyDuration, InvisibilityDuration, AreaTrapDuration, PlayerFleeDuration, PlayerName, PlayerID, PlayerLevel, Gender, Class, Race, ImmortalLevel, X, Y, Z, CInt, CWis, CLuc, CCha, CEssence, CMana, CSoul, CMove, FireballInterruption, SleepSpellInterruption, Status, DetectInvisibilityDuration, BlindDuration, StunDuration, EntanglementDuration, FPlayerGroupStatus FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        bPlayerFound = True
        lFlyDuration = MyCLng(rsPlayer!FlyDuration)
        lPlayerHeight = MyCLng(rsPlayer!Height)
        lCamoflaguedDuration = MyCLng(rsPlayer!CamoflaguedDuration)
        lImaginaryDuration = MyCLng(rsPlayer!ImaginaryDuration)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lInvisLevel = lCamoflaguedDuration + lInvisibilityDuration
        lJailDuration = MyCLng(rsPlayer!JailDuration)
        lAreaTrapDuration = MyCLng(rsPlayer!AreaTrapDuration)
        lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        zGender = MyCStr(rsPlayer!Gender)
        zClass = MyCStr(rsPlayer!Class)
        zRace = MyCStr(rsPlayer!Race)
        lCINT = MyCLng(rsPlayer!CInt)
        lCWIS = MyCLng(rsPlayer!CWIS)
        lCLuc = MyCLng(rsPlayer!CLuc)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lCEssence = MyCLng(rsPlayer!CEssence)
        lCMana = MyCLng(rsPlayer!CMana)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lCMove = MyCLng(rsPlayer!CMove)
        lFireballInterruption = MyCLng(rsPlayer!FireballInterruption)
        lSleepSpellInterruption = MyCLng(rsPlayer!SleepSpellInterruption)
        lStatus = MyCLng(rsPlayer!Status)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
    End If
    Set rsPlayer = Nothing
    
    If (lJailDuration = 0) Then
    If (lTurnedIntoAnimalType = 0) Then
    If (lAreaTrapDuration = 0) Then
        If (lPlayerFleeDuration = 0) Then
            If (bPlayerFound) Then
                If (lStunDuration = 0) Then
                    'If (lBlindDuration = 0) Then
                        If (lStatus <> 20 And lStatus <> 15) Then
                            If (lStatus <> 50) Then
                                If (lEntanglementDuration = 0) Then
                                    If (Len(zTargetName) >= cstMinAttackMobLen Or zTargetName = "") Then
                                        zSQL = "SELECT * FROM tblPlayerLearn WHERE ((LearnName Like '*" & zKeepLettersOnly(zSpellName) & "*') AND (TargetID=" & lPlayerID & ") AND (LearnStatus=2) AND (ActivateCommand=2 Or ActivateCommand=3)) ORDER BY Len([LearnName]), LearnName;" '2 and 3 are cast learn spells
                                        Set rsLearn = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                        If (Not rsLearn.EOF) Then
                                            rsLearn.MoveLast
                                            lRecordCount = rsLearn.RecordCount
                                            rsLearn.MoveFirst
                                            zRealSpellName = LCase(MyCStr(rsLearn!LearnName))
                                            lPlayerLearnID = MyCLng(rsLearn!PlayerLearnID)
                                            zCastObjectName = MyCStr(rsLearn!ObjectName)
                                            lLevelRequirement = MyCLng(rsLearn!LevelRequirement)
                                            lCraftedLevel = MyCLng(rsLearn!CraftedLevel)
                                            bSpellComponentRequired = (Len(zCastObjectName) <> 0)
                                            lSpellHP = MyCLng(rsLearn!HP)
                                            lSpellAC = MyCLng(rsLearn!AC)
                                            lSpellHITROLL = MyCLng(rsLearn!HITROLL)
                                            lSpellDAMROLL = MyCLng(rsLearn!DAMROLL)
                                            lWeight = MyCLng(rsLearn!Weight)
                                            lGold = MyCLng(rsLearn!Gold)
                                            lSpellStr = MyCLng(rsLearn!Str)
                                            lSpellInt = MyCLng(rsLearn!Int)
                                            lSpellWis = MyCLng(rsLearn!Wis)
                                            lSpellDex = MyCLng(rsLearn!Dex)
                                            lSpellCon = MyCLng(rsLearn!Con)
                                            lSpellCha = MyCLng(rsLearn!Cha)
                                            lSpellLuc = MyCLng(rsLearn!Luc)
                                            lSpellGrip = MyCLng(rsLearn!Grip)
                                            lSpellMana = MyCLng(rsLearn!mana)
                                            lSpellEssence = MyCLng(rsLearn!essence)
                                            lSpellSoul = MyCLng(rsLearn!soul)
                                            lSpellMove = MyCLng(rsLearn!Move)
                                            zCreateWeaponType = MyCStr(rsLearn!WeaponType)
                                            lLearnLevelRestricted = MyCLng(rsLearn!LearnLevelRestricted)
                                            lCreateBodyLocation = MyCLng(rsLearn!CreateBodyLocation)
                                            lObjectActivateSpellNo = MyCLng(rsLearn!ObjectActivateSpellNo)
                                            lElementalType = MyCLng(rsLearn!ElementalType)
                                            lElementalCelsius = MyCLng(rsLearn!ElementalCelsius)
                                            
                                            zErrorLine = ""
                                            zCastError = ""
                                            
                                            If (lRecordCount >= 1 And lRecordCount <= 2) Then
                                                bCostEssence = False
                                                bCostMana = False
                                                bCostSoul = False
                                                bCostMove = False
                                                If (Len(zCastError) = 0) Then
                                                    lActivateEssenceCost = MyCLng(rsLearn!ActivateEssenceCost)
                                                    If (lActivateEssenceCost > 0) Then
                                                        If (lCEssence >= lActivateEssenceCost) Then
                                                            bCostEssence = True
                                                        Else
                                                            zCastError = zCastError & "You are short " & lActivateEssenceCost - lCEssence & " essence." & vbCrLf
                                                        End If
                                                    End If
                                                End If
                                                
                                                If (Len(zCastError) = 0) Then
                                                    lActivateManaCost = MyCLng(rsLearn!ActivateManaCost)
                                                    If (lActivateManaCost > 0) Then
                                                        If (lCMana >= lActivateManaCost) Then
                                                            bCostMana = True
                                                        Else
                                                            zCastError = zCastError & "You are short " & lActivateManaCost - lCMana & " mana." & vbCrLf
                                                        End If
                                                    End If
                                                End If
                                                
                                                If (Len(zCastError) = 0) Then
                                                    lActivateSoulCost = MyCLng(rsLearn!ActivateSoulCost)
                                                    If (lActivateSoulCost > 0) Then
                                                        If (lCSoul >= lActivateSoulCost) Then
                                                            bCostSoul = True
                                                        Else
                                                            zCastError = zCastError & "You are short " & lActivateSoulCost - lCSoul & " soul." & vbCrLf
                                                        End If
                                                    End If
                                                End If
                                                
                                                If (Len(zCastError) = 0) Then
                                                    lActivateMoveCost = MyCLng(rsLearn!ActivateMoveCost)
                                                    If (lActivateMoveCost > 0) Then
                                                        If (lCMove >= lActivateMoveCost) Then
                                                            bCostMove = True
                                                        Else
                                                            zCastError = zCastError & "You are short " & lActivateMoveCost - lCMove & " move." & vbCrLf
                                                        End If
                                                    End If
                                                End If
                                                
                                                If (Len(zCastError) = 0) Then
                                                    'we dont want to waste the spell component if they are short mana or essence or something
                                                    If (bSpellComponentRequired) Then
                                                        bSpellComponentUsed = (bCastObjectNameFromLearnSpell(lPlayerID, zCastObjectName))
                                                        If (bSpellComponentUsed) Then subSendMsg gblzFNYEL & zCastObjectName & "&g is used with the spell.", zPortID
                                                    Else
                                                        bSpellComponentUsed = False
                                                    End If
                                                    
                                                    If ((Not bSpellComponentRequired) Or (bSpellComponentRequired And bSpellComponentUsed)) Then
                                                        If (bCostEssence) Then MyDB.Execute "UPDATE tblPlayer SET CEssence = [CEssence]-" & lActivateEssenceCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        If (bCostMana) Then MyDB.Execute "UPDATE tblPlayer SET CMana = [CMana]-" & lActivateManaCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        If (bCostSoul) Then MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lActivateSoulCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        If (bCostMove) Then MyDB.Execute "UPDATE tblPlayer SET CMove = [CMove]-" & lActivateMoveCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        
                                                        If (lRandom(lTranslateMagicIASBonusFromClass(zClass) + lTranslateMagicIASBonusFromRace(zRace)) + lRandom(MyCLng(rsLearn!LearnPercent) + lRandom(lCINT) + lRandom(lCWIS)) >= lRandom(50)) Then
                                                            'Success, the player at this point has all the essence mana mov soul to cast the spell
                                                            If (Not bMorphState(zClass)) Then 'morphs give no xp
                                                            If (MyCLng(rsLearn!LearnPercent) < 59 + lTranslateLearnPointsSpell(zClass)) Then
                                                                'Is the spell less than the class allows - if so give XP !
                                                                lXP = 0
                                                                If (lRandom(lCINT) + lRandom(lCWIS * 3) + lTranslateClassLearnGainBonus(zClass) > lRandom(100)) Then
                                                                    'player gets SWEET XP BONUS for a successful learn by stats!
                                                                    'anyone with high wisdom has a better chance at a great xp bonus
                                                                    'mages also get a nice natural class bonus in lTranslateClassLearnGainBonus
                                                                    lXP = 999 + (lRandom(lCINT + lCWIS) * 5) 'mages and clerics have a chance and a nice bonus!
                                                                    Select Case zClass
                                                                        Case "MA"
                                                                            lXP = lXP + lRandom(100 - MyCLng(rsLearn!LearnPercent)) + (500 - MyCLng(rsLearn!LearnPercent))
                                                                        Case "CL"
                                                                            lXP = lXP + lRandom(200 - MyCLng(rsLearn!LearnPercent)) + (400 - MyCLng(rsLearn!LearnPercent))
                                                                        Case "DR"
                                                                            lXP = lXP + lRandom(400 - MyCLng(rsLearn!LearnPercent)) + (200 - MyCLng(rsLearn!LearnPercent))
                                                                        Case "BA"
                                                                            lXP = lXP + lRandom(500 - MyCLng(rsLearn!LearnPercent)) + (100 - MyCLng(rsLearn!LearnPercent))
                                                                    End Select
                                                                Else
                                                                    'player gets a low xp bonus for a successful learn, boring but award them ;)
                                                                    lXP = 99 + (lRandom(lCINT + lCWIS) * 5)
                                                                    Select Case zClass
                                                                        Case "MA"
                                                                            lXP = lXP + lRandom(300)
                                                                        Case "CL", "PA" 'paladins fail better than most warrior classes since they are one fifth cleric
                                                                            lXP = lXP + lRandom(200)
                                                                        Case "DR"
                                                                            lXP = lXP + lRandom(300)
                                                                        Case "BA"
                                                                            lXP = lXP + lRandom(100)
                                                                    End Select
                                                                End If
                                                                
                                                                Select Case lPlayerLevel 'we now scale the xp bonus according to the caster's cast power
                                                                    Case 0 To 4
                                                                        lXP = lXP / 5
                                                                    Case 5 To 15
                                                                        lXP = lXP / 4
                                                                    Case 16 To 25
                                                                        lXP = lXP / 2
                                                                    Case 26 To 40
                                                                        lXP = lXP * 2
                                                                    Case 41 To 80
                                                                        lXP = lXP * 3
                                                                    Case 81 To 99
                                                                        lXP = lXP * 3
                                                                    Case 100 To 150
                                                                        lXP = lXP * 10
                                                                    Case 151 To 200
                                                                        lXP = lXP * 20
                                                                    Case Else
                                                                        lXP = lXP * 40
                                                                End Select
                                                                
                                                                subSendMsg "&WYAY! You gain " & lXP & " experience points for your success with " & zRealSpellName & "!", zPortID
                                                                MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+" & lXP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblPlayerLearn SET LearnPercent = [LearnPercent]+1 WHERE (PlayerLearnID=" & lPlayerLearnID & ");", dbFailOnError
                                                            End If 'spells that have reached top xp skip this now
                                                            End If
                                                            
                                                            bSpellCast = False
                                                            zGetSpellName = UCase(Mid(zSpellName, 1, 5))
                                                            Select Case MyCLng(rsLearn!GroundObjectType) 'see also: subSpecialSelfObjectMagic
                                                                Case 1 'Healing Spring (druids and bards mostly) See Also: subSpecialSelfDeletingObject() and subSpecialSelfObjectMagic()
                                                                    bSpellCast = True
                                                                    subSendMsgAreaAllDISmart "&B", zPlayerName, "You mutter some magical words.", "", "%s1 mutters some magical words.", lX, lY, lZ
                                                                    If (Not bObjectNamePresent(lX, lY, lZ, MyCStr(rsLearn!GroundObjectName))) Then
                                                                        Set rsObject = MyDB.OpenRecordset("tblObject", dbOpenTable)
                                                                        If (Not rsObject.EOF) Then
                                                                            rsObject.AddNew
                                                                            lObjectID = MyCLng(rsObject!ObjectID)
                                                                            rsObject!ObjectName = MyCStr(rsLearn!GroundObjectName)
                                                                            rsObject!x = lX
                                                                            rsObject!y = lY
                                                                            rsObject!z = lZ
                                                                            rsObject!Location = 0
                                                                            rsObject!SpecialSelfDeletingDelay = 6 + MyCLng(lPlayerLevel / 6) 'we delete it a few ticks after the spring stops gushing
                                                                            rsObject!GroundObjectType = MyCLng(rsLearn!GroundObjectType)
                                                                            rsObject!GroundObjectTypeDuration = 5 + MyCLng(lPlayerLevel / 6)
                                                                            MyDB.Execute "INSERT INTO tblObjectSpecialSelfDeletingDelay (ObjectID) SELECT " & lObjectID & ";", dbFailOnError
                                                                            rsObject.Update
                                                                        End If
                                                                        Set rsObject = Nothing
                                                                        subSendMsgAreaAll "&CA magical spring appears in the room with you!", lX, lY, lZ
                                                                    Else
                                                                        subSendMsgAreaAll "&rA magical spring appears and then fizzles out!", lX, lY, lZ
                                                                    End If
                                                            End Select
                                                            
                                                            Select Case lObjectActivateSpellNo 'offensive spells can also be cast on ones self too unless it does damage
                                                                Case 1 'all heal spells
                                                                    If (zAreaRules(7, lX, lY, lZ) = "1") Then
                                                                        subSpellListHeal zRealSpellName, zPortID, lX, lY, lZ, lPlayerLevel, lPlayerID, zPlayerName, zTargetName, zClass, Abs(MyCLng(rsLearn!LearnDamage)), zCastObjectName, bSpellComponentRequired, bSpellComponentUsed
                                                                    Else
                                                                        subSendMsg "&RYour spell was negated!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 111 'all refresh spells
                                                                    If (zAreaRules(7, lX, lY, lZ) = "1") Then
                                                                        subSpellListRefreshMove zPortID, lX, lY, lZ, lPlayerLevel, lPlayerID, zPlayerName, zTargetName, zClass, Abs(MyCLng(rsLearn!LearnDamage))
                                                                    Else
                                                                        subSendMsg "&RYour spell was negated!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 2
                                                                    If (zAreaRules(7, lX, lY, lZ) = "1") Then
                                                                        subSpellListRestoreHealth zPortID, lX, lY, lZ, lPlayerLevel, lPlayerID, zPlayerName, zTargetName, zClass, zCastObjectName
                                                                    Else
                                                                        subSendMsg "&RYour spell was negated!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 3
                                                                    If (zAreaRules(1, lX, lY, lZ) = "1") Then
                                                                        If (zAreaRules(6, lX, lY, lZ) = "1") Then
                                                                            subSpellListSleep zPortID, lPlayerID, lPlayerLevel, zClass, lX, lY, lZ, zTargetName, zPlayerName, lCINT, lCWIS, lCMana, lSleepSpellInterruption
                                                                        Else
                                                                            subSendMsg "&RYour spell was negated!", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&BA magical barrier prevents you from attacking.", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 4
                                                                    subSpellListAquaBreath zPortID, zTargetName
                                                                    bSpellCast = True
                                                                Case 513 'drop shields
                                                                    subSpellDispelShields zPortID, zTargetName
                                                                    bSpellCast = True
                                                                Case 5 'summon
                                                                    If (lAreaClanID(lX, lY, lZ) = 0) Then
                                                                        If (zAreaRules(1, lX, lY, lZ) = "1") Then
                                                                            subSpellListPlayerMob zPortID, MyCLng(rsLearn!ObjectActivateSpellNo), MyCStr(zTargetName & " " & zWord4 & " " & zWord5), zPlayerName, lPlayerID, lX, lY, lZ, lPlayerLevel, zClass, lImmortalLevel
                                                                        Else
                                                                            subSendMsg "&RNo Attack Zone: This is a no summon zone.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&RClan Hall: This is a no summon zone.", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 6 'ITEM IDENTIFY TO only their SELF
                                                                    subSpellListIdentify zTargetName, zPortID, False
                                                                    bSpellCast = True
                                                                Case 61 'ROOM/AREA IDENTIFY TO ALL
                                                                    subSpellListIdentify zTargetName, zPortID, True
                                                                    bSpellCast = True
                                                                Case 50 'gate
                                                                    If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                                                                        If (lAreaClanID(lX, lY, lZ) = 0) Then
                                                                            subSpellListPlayerMob zPortID, MyCLng(rsLearn!ObjectActivateSpellNo), MyCStr(zTargetName & " " & zWord4 & " " & zWord5), zPlayerName, lPlayerID, lX, lY, lZ, lPlayerLevel, zClass, lImmortalLevel
                                                                        Else
                                                                            subSendMsg "&RClan Hall: This is a no gate zone.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&gYou cannot do that while you are fighting! [try to FLEE]", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 117 'xray spell too look though walls
                                                                    subLookPeek zPortID, zTargetName, True
                                                                    bSpellCast = True
                                                                Case 150
                                                                    subImaginaryStats zPortID
                                                                    bSpellCast = True
                                                                Case 70 'all armour class spells
                                                                    If (MyCLng(rsLearn!ActivateDuration) = 0) Then
                                                                        lCalcuActivateDuration = 25 + (lPlayerLevel * 3)
                                                                        If (lCalcuActivateDuration < 100) Then lCalcuActivateDuration = 100
                                                                        If (lCalcuActivateDuration > 500) Then lCalcuActivateDuration = 500
                                                                        MyDB.Execute "UPDATE tblPlayerLearn SET ActivateDuration = [ActivateDurationStart]+" & lCalcuActivateDuration & " WHERE (PlayerLearnID=" & lPlayerLearnID & ");", dbFailOnError
                                                                        subRecalculatePlayerEquipment lPlayerID, zPortID
                                                                        subSendMsgAreaAllDISmart "&B", zPlayerName, "You invoke " & zRealSpellName & ".", "", "%s1 invokes " & zRealSpellName & ".", lX, lY, lZ
                                                                        subSendMsg "&yYour " & zRealSpellName & " adds " & MyCLng(rsLearn!AC) & " to your armour class for " & lCalcuActivateDuration & " durations.", zPortID
                                                                    Else
                                                                        subSendMsg "&yYour " & zRealSpellName & " is already cast upon you.", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 12
                                                                    If (zAreaRules(10, lX, lY, lZ) = "1" And zAreaRules(11, lX, lY, lZ) = "1") Then
                                                                        If (lBlindDuration = 0) Then
                                                                            subSpellListRemoveCurse zPortID, zGetSpellName, zTargetName, zPlayerName, lPlayerID, lX, lY, lZ, lPlayerLevel, zClass
                                                                        Else
                                                                            subSendMsg "&RYour eyes are in too much pain to concentrate on a spell!", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&RSomething in the area negated your spell!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 19
                                                                    subSpellListGoVisibile zPortID, lPlayerID, lPlayerLevel
                                                                    bSpellCast = True
                                                                Case 20, 200, 512 '2001 specical conditions applied 20 are all cast attack spells, 200 is net and web like spells
                                                                    If (lBlindDuration = 0) Then
                                                                        If (zAreaRules(1, lX, lY, lZ) = "1") Then
                                                                            If (zAreaRules(6, lX, lY, lZ) = "1") Then
                                                                                If (rSCombat(MyCLng(zPortID)).iStatus = 0) Then 'if the player is attacking something we default to it
                                                                                    bAttackAway = bPlayerVsMobCombatSetUp(zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, False, True)
                                                                                End If
                                                                                subSpellListAttackSpells zPortID, lPlayerID, lPlayerLevel, zTargetName, zRace, zClass, lFireballInterruption, zRealSpellName, MyCLng(rsLearn!LearnDamage), MyCLng(rsLearn!ObjectActivateSpellNo), MyCLng(rsLearn!LearnType), lDetectInvisibilityDuration, MyCLng(rsLearn!EntangleLevel), MyCLng(rsLearn!EntangleChance), MyCLng(rsLearn!PoisonLevel), MyCLng(rsLearn!PoisonStrength), MyCLng(rsLearn!PoisonChance), MyCLng(rsLearn!StunLevel), MyCLng(rsLearn!StunChance), MyCLng(rsLearn!BlindLevel), MyCLng(rsLearn!BlindChance), MyCLng(rsLearn!PindownLevel), MyCLng(rsLearn!PindownChance), MyCLng(rsLearn!ElementalType), MyCLng(rsLearn!ElementalCelsius), MyCLng(rsLearn!SleepLevel), MyCLng(rsLearn!SleepChance)
                                                                            Else
                                                                                subSendMsg "&RYour spell was negated!", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&BA magical barrier prevents you from attacking.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&RYour eyes are in too much pain to concentrate on a spell!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 21 'locate
                                                                    subSpellListLocateMobEqObject zPortID, lPlayerID, lPlayerLevel, zClass, zPromptOriginal, lImmortalLevel
                                                                    bSpellCast = True
                                                                Case 210 'and powerful locate with where id
                                                                    subSpellListLocateWhereNameMobEqObject zPortID, lPlayerID, lPlayerLevel, zClass, zPromptOriginal, lImmortalLevel
                                                                    bSpellCast = True
                                                                Case 211 'and powerful locate with where id
                                                                    subSpellListLocateMobName zPortID, lPlayerID, lPlayerLevel, zClass, zPromptOriginal, lImmortalLevel
                                                                    bSpellCast = True
                                                                Case 22
                                                                    If (zAreaRules(1, lX, lY, lZ) = "1") Then
                                                                        If (zAreaRules(6, lX, lY, lZ) = "1") Then
                                                                            subSpellListExorcise zPortID, zTargetName 'exorcism
                                                                        Else
                                                                            subSendMsg "&RYour spell was negated!", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&BA magical barrier prevents you from attacking.", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 220
                                                                    subSpellListRaiseArea zPortID, True
                                                                    bSpellCast = True
                                                                Case 23
                                                                    If (gbllMoon > -4) Then
                                                                        subSpellListTransport zPortID, lPlayerID, zTargetName, zWord4, zPlayerName, lX, lY, lZ
                                                                    Else
                                                                        subSendMsg "&R~the moon is not in a proper phase~", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 24, 25, 26, 27
                                                                    subSpellListElemental zPortID, lPlayerID, zRealSpellName, zPlayerName, MyCLng(rsLearn!ObjectActivateSpellNo), lX, lY, lZ, lPlayerLevel, lCLuc, lCWIS, lCINT, zCastObjectName, zRace, bSpellComponentUsed, bSpellComponentRequired
                                                                    bSpellCast = True
                                                                Case 30
                                                                    If (gbllMoon > -1) Then
                                                                        If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                                                                            subSpellListPortal zPortID, lPlayerID, lPlayerLevel, MyCStr(zTargetName & " " & zWord4 & " " & zWord5), zClass
                                                                        Else
                                                                            subSendMsg "&gYou cannot do that while you are fighting! [try to FLEE]", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&R~the moon is not in a proper phase~", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                'Case 7, 71, 8, 9 'these are old but still work 70 replaces these - we could pull barkskin and demonskil and dragonskin - the emotes are fun though
                                                                    'subSpellListSkinDurations zPortID, lPlayerID, lPlayerLevel, MyCLng(rsLearn!ObjectActivateSpellNo), zClass
                                                                'Case 17
                                                                 '   subSpellListSanctuary zPortID, lPlayerID, lPlayerLevel, zClass
                                                                'Case 15
                                                                '    subSpellListFireshield zPortID, lPlayerID, lPlayerLevel, zClass
                                                                'Case 16
                                                                '    subSpellListIceshield zPortID, lPlayerID, lPlayerLevel, zClass
                                                                'Case 14
                                                                    'subSpellListInvisibility zPortID, lPlayerID, lPlayerLevel, zClass, LCase(MyCStr(rsLearn!LearnName))
                                                                'Case 18
                                                                    'subSpellListDetectInvisibility zPortID, lPlayerID, lPlayerLevel, zClass
                                                                'Case 13
                                                                    'subSpellListCreateLight zPortID, lPlayerID, lPlayerLevel, zClass
                                                                'Case 10
                                                                 '   subSpellListFly zPortID, lPlayerID, lPlayerLevel, zClass, zPlayerName, zTargetName, lX, lY, lZ, zRace, LCase(MyCStr(rsLearn!LearnName))
                                                                'Case 11
                                                                    'subSpellListNegate zPortID, lPlayerID, lPlayerLevel, zClass
                                                                Case 11, 13, 500, 14, 1499, 14999, 18, 10, 4, 15, 1501, 1502, 16, 17, 7, 71, 8, 9, 300 To 307, 510, 511, 400, 401, 402 'all raise stats and bless spells
                                                                    If (lBlindDuration = 0) Then 'gainstr and other gains 300 To 307
                                                                        subSpellListRaiseStats zPortID, lX, lY, lZ, lPlayerLevel, lPlayerID, zPlayerName, zTargetName, zRace, zClass, Abs(MyCLng(rsLearn!LearnDamage)), MyCLng(rsLearn!ObjectActivateSpellNo), zRealSpellName, zCastObjectName, bSpellComponentRequired, bSpellComponentUsed, lCINT, lCWIS, lCCHA
                                                                    Else
                                                                        subSendMsg "&RYour eyes are in too much pain to concentrate on a spell!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 240
                                                                    If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                                                                        subSpellListPasswall zPortID, lPlayerID, zRealSpellName, zPlayerName, MyCLng(rsLearn!ObjectActivateSpellNo), lX, lY, lZ, lPlayerLevel, lCLuc, lCWIS, lCINT, zTargetName
                                                                    Else
                                                                        subSendMsg "&gYou cannot do that while you are fighting! [try to FLEE]", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 340
                                                                    subSystemReportPlayerData zPortID
                                                                    bSpellCast = True
                                                                Case 343 'Nanite Corpse - makes a corpse rot longer
                                                                    If (lBlindDuration = 0) Then
                                                                        subSpellListNaniteCorpse zPortID, lPlayerID, zRealSpellName, zPlayerName, MyCLng(rsLearn!ObjectActivateSpellNo), lX, lY, lZ, lPlayerLevel, lCLuc, lCWIS, lCINT, zCastObjectName
                                                                    Else
                                                                        subSendMsg "&RYour eyes are in too much pain to concentrate on a spell!", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                                Case 2000
                                                                    subSpellListDurability zPortID, lPlayerID, zRealSpellName, zPlayerName, MyCLng(rsLearn!ObjectActivateSpellNo), lX, lY, lZ, lPlayerLevel, lCLuc, lCWIS, lCINT, zCastObjectName
                                                                    bSpellCast = True
                                                                Case 1212
                                                                    subSpellCreateBodyLocation zPlayerName, zRealSpellName, lLearnLevelRestricted, zCreateWeaponType, lCreateBodyLocation, lPlayerID, lX, lY, lZ, lPlayerLevel, zPortID, lSpellHP, lSpellAC, lSpellHITROLL, lSpellDAMROLL, lSpellStr, lSpellInt, lSpellWis, lSpellDex, lSpellCon, lSpellCha, lSpellLuc, lSpellGrip, lSpellMana, lSpellSoul, lSpellEssence, lSpellMove, lLevelRequirement, lCraftedLevel, lWeight, lGold
                                                                    bSpellCast = True
                                                                Case 814 'summon eclipses prevent magic words from working
                                                                    bMoonAlignment = (gbllTornadeoX = gbllPentagramX And gbllTornadeoY = gbllPentagramY And gbllTornadeoZ = gbllPentagramZ)
                                                                    If (bMoonAlignment) Then
                                                                        If (lRandom(10) = 1) Then
                                                                            If (gbllMoon > 0) Then
                                                                                If (gbllMoon <> 5) Then
                                                                                    gbllMoon = 5
                                                                                    subSimpleEchoChannel "&AAn eclipse falls over the realm!"
                                                                                    gblbArenaOnOff = 1 'arena online
                                                                                Else
                                                                                    gbllMoon = lRandom(4) - 1 'normal moon to 3 moon phases
                                                                                    subSimpleEchoChannel "&AThe eclipse ends quickly!"
                                                                                    gblbArenaOnOff = 0 'arena offline
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&R~the moon is not in a phase you can control~", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&R~eerie, nothing happened, try again~", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&R~the MAP eclipses need to be scry-aligned~", zPortID
                                                                    End If
                                                                    bSpellCast = True
                                                            End Select
                                                            
                                                            If (Not bSpellCast) Then subSendMsg "&R" & vbCrLf & vbCrLf & "Grid LearnTree Design Flaw " & zSpellName & " is not tied to a spell." & vbCrLf, zPortID
                                                            
                                                            subPlayerGains lPlayerID 'xp level might happen here
                                                        Else
                                                            subSendMsg "&gYou lost your concentration.", zPortID
                                                        End If
                                                    Else
                                                        zCastError = zShortstop(LCase(zCastObjectName)) & " is missing from your inventory."
                                                    End If
                                                End If
                                            Else
                                                subSendMsg "&gWhich spell were you referring to?", zPortID
                                                Do While (Not rsLearn.EOF)
                                                    zErrorLine = zErrorLine & MyCStr(rsLearn!LearnName) & vbCrLf
                                                    If (Len(zErrorLine) > 200) Then
                                                        If (Len(zErrorLine) > 0) Then
                                                            subSendMsg zTrimCrLf(zErrorLine), zPortID
                                                            zErrorLine = ""
                                                        End If
                                                    End If
                                                    rsLearn.MoveNext
                                                Loop
                                            End If
                                            If (Len(zErrorLine) > 0) Then subSendMsg gblzFNGRE & zTrimCrLf(zErrorLine), zPortID
                                            If (Len(zCastError) > 0) Then subSendMsg gblzFNGRE & zTrimCrLf(zCastError), zPortID
                                        Else
                                            subSendMsg "&gSpell " & zKeepLettersOnly(UCase(zSpellName)) & " unknown or not learnt.", zPortID
                                        End If
                                        Set rsLearn = Nothing
                                    Else
                                        subSendMsg "&gYour target name must be at least " & cstMinAttackMobLen & " characters in length." & vbCrLf & "&aIf you are using directions you need to use the full directional name." & vbCrLf & " - ABOVE BELOW NORTHEAST NORTHWEST SOUTHEAST SOUTHWEST NORTH SOUTH EAST WEST", zPortID
                                    End If
                                Else
                                    subSendMsg "&yYour hands are too entangled to cast a spell.", zPortID
                                End If
                            Else
                                subSendMsg "&GYou dream about feats of magic.", zPortID
                            End If
                        Else
                            subSendMsg "&GYou have to stand to cast a spell.", zPortID
                        End If
                    'Else
                    '    subSendMsg "&RYour eyes are in too much pain to concentrate on a spell!", zPortID
                    'End If
                Else
                    subSendMsg "&RYou are too stunned to concentrate on a spell!", zPortID
                End If
            End If
        Else
            subSendMsg "&RYou are too scared to do that right now!", zPortID
        End If
    Else
        subSendMsg "&RYou are too trapped to be able to cast any spell!", zPortID
    End If
    Else
        subSendMsg "&MYou are only a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ", you cannot do that!", zPortID
    End If
    Else
        subSendMsg "&MYou are sitting out jail time!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCastGroupOfProcedures," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRealmRules(zPortID As String, iPage As Integer, iType As Integer)
On Error Resume Next
    Select Case iType
        Case 1 'verbose
            Select Case iPage
                Case 0
                Case 1
                    subSendMsg "&WR E A L M  R U L E S                                                      [p1/4]", zPortID
                    subSendMsg "&a" & _
                        "1)  You may NOT multiplay, unless HELP MULTIPLAY says otherwise." & vbCrLf & _
                        "2)  If you and your friends are behind a router you should prove this somehow." & vbCrLf & _
                        "3)  One person may have up to 3 other characters, but no more." & vbCrLf & _
                        "    You may NOT use these characters just to hold items." & vbCrLf & _
                        "    You MUST play and level your other characters." & vbCrLf & _
                        "    You CANNOT share characters. If a friend of yours knows your password" & vbCrLf & _
                        "    then you MUST change your password!" & vbCrLf & _
                        "    Your friend cannot login your characters for ANY reason at all!" & vbCrLf & _
                        "4)  Always log into the realm, do not hang at the ports." & vbCrLf & _
                        "5)  No harassing or being offensive in anyway to players of the realm." & vbCrLf & _
                        "6)  BOTTING: You may run triggers and aliases in our realm but only when you are" & vbCrLf & _
                        "    watching the commands execute. True botting is when you are not" & vbCrLf & _
                        "    at your keyboard and running an area, this is not permitted." _
                    , zPortID
                Case 2
                    subSendMsg "&WR E A L M  R U L E S                                                      [p2/4]", zPortID
                    subSendMsg "&a" & _
                        "7)  ABUSIVE LANGUAGE: Rudeness towards another player is forbidden even if the" & vbCrLf & _
                        "    other player doesn't mind or complain about it, including, but not" & vbCrLf & _
                        "    limited to: cursing, race, religion, nationality, colour," & vbCrLf & _
                        "    sexual orientation, or demeaning, or derogatory comments to or about" & vbCrLf & _
                        "    another player. You may not rename items or use your TITLE or DESC commands" & vbCrLf & _
                        "    or any other command that gives you voice in the realm to be rude." & vbCrLf & _
                        "8)  Player killing and player stealing is allowed within reason, but not to the" & vbCrLf & _
                        "    point of harassment of other players." & vbCrLf & _
                        "9)  You may NOT SPAM any channel! Saying its a stuck key or it was an accident" & vbCrLf & _
                        "    or that it was a joke is no excuse. This includes: showing item information," & vbCrLf & _
                        "    showing casino winnings, attack information, bragging, or anything else." & vbCrLf & _
                        "    Especially no advertising anything! Channels are for communication only! " _
                    , zPortID
                Case 3
                    subSendMsg "&WR E A L M  R U L E S                                                      [p3/4]", zPortID
                    subSendMsg "&a" & _
                        "10) Requests from administration or immortals are to be complied with promptly." & vbCrLf & _
                        "    If you disagree with something an immortal has asked you to do or not do," & vbCrLf & _
                        "    you must Email administration for a final decision. Until then you must" & vbCrLf & _
                        "    comply. Under NO circumstances should administration or immortals be spoken" & vbCrLf & _
                        "    to in a disrespectful way." & vbCrLf & _
                        "11) All in-game problems should be logged and the log Emailed to administration" & vbCrLf & _
                        "    for review." & vbCrLf & _
                        "12) Courtesy toward other players is expected as determined by common sense." & vbCrLf & _
                        "13) You may NOT advertise anything anywhere at anytime in the realm!" _
                    , zPortID
                    subSendMsg "&a" & _
                        "14) ALL determinations as to what constitutes harassment or disregard of the" & vbCrLf & _
                        "    rules are the sole judgement of the administration and all decisions will" & vbCrLf & _
                        "    be final. Punishment can take the form of reprimands, silencing, temporary" & vbCrLf & _
                        "    bans, permant bans, character deletion or other punishment thought necessary" & vbCrLf & _
                        "    by administration. Any arguing or whining regarding the decision of" & vbCrLf & _
                        "    administration may cause the applicable punishment to be extended." _
                    , zPortID
                Case Else
                    subSendMsg "&WR E A L M  R U L E S                                                      [p4/4]", zPortID
                    subSendMsg "&a" & _
                        "15) A player will be given verbal or written warnings before an offense" & vbCrLf & _
                        "    becomes punishable by permanent deletion or banning of the character. Verbal" & vbCrLf & _
                        "    warnings will be logged by administration. Character deletion will then be" & vbCrLf & _
                        "    at the sole discretion of the administration, depending on the offenses." & vbCrLf & _
                        "16) All Emails to administration should be addressed to " & UCase(zSystemConfig(2)) & vbCrLf & _
                        "17) Failure to read this file or ignorance of its content is not an acceptable" & vbCrLf & _
                        "    excuse for breaking the rules. It is your duty to know the rules" & vbCrLf & _
                        "    of this game and abide by them!" _
                    , zPortID
            End Select
        Case 2 'brief
            subSendMsg "&WR E A L M  R U L E S", zPortID
            subSendMsg "&a" & _
                "1)  You may NOT multiplay, unless HELP MULTIPLAY says otherwise." & vbCrLf & _
                "2)  If there will more than one person behind your router you should prove it." & vbCrLf & _
                "3)  One person may have up to 3 other characters, but no more." & vbCrLf & _
                "4)  Always log into the realm, do not hang at the ports." & vbCrLf & _
                "5)  No harassing or being offensive in anyway to anyone ever." & vbCrLf & _
                "6)  No botting, unless you are there at your keyboard to respond to messages." _
            , zPortID
            subSendMsg _
                "7)  Cursing is forbidden." & vbCrLf & _
                "8)  Player killing and player stealing is allowed within reason." & vbCrLf & _
                "9)  You may NOT SPAM any channel, especially other game advertisements!" _
            , zPortID
            subSendMsg _
                "10) Requests from administration or immortals are to be complied with promptly." & vbCrLf & _
                "11) All in-game problems should be logged and emailed to administration." & vbCrLf & _
                "12) Courtesy toward other players is expected as determined by common sense." _
            , zPortID
            subSendMsg _
                "13) ALL determinations as to what constitutes harassment or disregard of the" & vbCrLf & _
                "    rules are the sole judgement of administration." & vbCrLf & _
                "14) You may NOT advertise anything anywhere at anytime in the realm!" _
            , zPortID
            subSendMsg _
                "15) A player will be given verbal or written warnings before an offense" & vbCrLf & _
                "    becomes punishable by any means the immortal finds fitting." & vbCrLf & _
                "16) All Emails to administration should be addressed to " & UCase(zSystemConfig(2)) & vbCrLf & _
                "17) Failure to read this file or ignorance of its content is not an acceptable" & vbCrLf & _
                "    excuse for breaking the rules. It is your duty to know the rules" & vbCrLf & _
                "    of this game and abide by them!" _
            , zPortID
    End Select
    subSendMsg "&RYOUR CHARACTER IS NOW MARKED AS HAVING READ THE REALM RULES!" & "&g", zPortID
End Sub
Public Sub subHelpSystemRR(lX As Long, lY As Long, lZ As Long, lImmortalLevel As Long, lPlayerID As Long, zPortID As String)
On Error GoTo Err_Check
    Dim zArea(1 To 15) As String
    Dim iCount As Integer
    If (lImmortalLevel > 2 Or lTotalAssignedAreas(lPlayerID) > 0) Then
        For iCount = 1 To 15
            Select Case (zAreaRules(iCount, lX, lY, lZ) = "1")
                Case True
                    Select Case iCount
                        Case 1
                            zArea(iCount) = gblzFBGRE & "available" & "&a"
                        Case 8
                            zArea(iCount) = gblzFBGRE & "active" & "&a"
                        Case 9, 12
                            zArea(iCount) = gblzFBGRE & "relevant" & "&a"
                        Case 10, 11, 15
                            zArea(iCount) = gblzFBGRE & "capable" & "&a"
                        Case Else
                            zArea(iCount) = gblzFBGRE & "allowed" & "&a"
                    End Select
                Case Else
                    Select Case iCount
                        Case 1
                            zArea(iCount) = gblzFBRED & "unavailable" & "&a"
                        Case 8
                            zArea(iCount) = gblzFBRED & "inactive" & "&a"
                        Case 9, 12
                            zArea(iCount) = gblzFBRED & "irrelevant" & "&a"
                        Case 10, 11, 15
                            zArea(iCount) = gblzFBRED & "uncapable" & "&a"
                        Case Else
                            zArea(iCount) = gblzFBRED & "disallowed" & "&a"
                    End Select
            End Select
        Next iCount
        subSendMsg vbCrLf & "&W~ROOM RULE TOGGLES~" & vbCrLf & "&a" & _
            "01: fighting/stealing (" & (zArea(1)) & ")" & vbCrLf & _
            "02: invisiblility/shadowcloak (" & (zArea(2)) & ")" & vbCrLf & _
            "03: recall (" & (zArea(3)) & ")" & vbCrLf & _
            "04: mark (" & (zArea(4)) & ")" & vbCrLf & _
            "05: portal/transport (" & (zArea(5)) & ")" & vbCrLf & _
            "06: spell offensive (" & (zArea(6)) & ")" & vbCrLf & _
            "07: spell defensive (" & (zArea(7)) & ")" & vbCrLf & _
            "08: say channel/passwall (" & (zArea(8)) & ")" & vbCrLf & _
            "09: any type of quitting (" & (zArea(9)) & ")" & vbCrLf & _
            "10: bury/dropping (" & (zArea(10)) & ")" & vbCrLf & _
            "11: pickup (" & (zArea(11)) & ")" & vbCrLf & _
            "12: summon/gate (" & (zArea(12)) & ")" & vbCrLf & _
            "13: magic word (" & (zArea(13)) & ")" & vbCrLf & _
            "14: starship commands (" & (zArea(14)) & ")" & vbCrLf & _
            "15: teleportation to spot (" & (zArea(15)) & ")" & vbCrLf & _
            gblzFBGRE & "HELP &g[ROOM/RC/OC/MOB/MC/IMMORTAL]   Extended Help: IMMO RR HELP" _
        , zPortID
        subSendMsg "&wSyntax: &gIMMO RR [CELLNUMBER]" & vbCrLf & "        Toggles the cell number rule for the area." & _
        vbCrLf & "&w" & "        &gIMMO RR 9           (will toggle rule 9 on or off)" & vbCrLf & "        IMMO RR             (will show you all the rules set to the area)", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subHelpSystemRR," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMagicalMobSpells(zPortID As String, lType As Long)
On Error GoTo Err_Check
    subSendMsg vbCrLf & "&W~DEFENSIVE SPELL NUMBER~" & "&a" & vbCrLf & _
        "1          Shockshield   2          Minor Heal    3          Major Heal" _
    , zPortID
    subSendMsg vbCrLf & "&W~OFFENSIVE SPELL NUMBER~" & "&a" & vbCrLf & _
        "1          Frost orb     2          Fireball      3          Energy Blast  " & vbCrLf & _
        "4          Drain XP      5          Drain Soul    6          Drain Essence " & vbCrLf & _
        "7          Drain Mana    8          Arrow         9          Bolt          " & vbCrLf & _
        "10         Grenade       11         Bullet        12         Uzi           " & vbCrLf & _
        "13         Energy Cell   14         Energy Rifle  " & vbCrLf & _
        "15         Draining bite (soul and xp loss) when activated" & vbCrLf & _
        "16         Weapon Type becomes a swinging deadly weapon" & vbCrLf & _
        "17         Weapon Type becomes a swinging deadly poisoned weapon" _
    , zPortID
    If (lType = 1) Then
        subSendMsg "&wPLEASE: DO NOT FORGET TO SET THE CHANCES TO CAST THEM" & vbCrLf & "        IN MID/MFORGE OR THE TWO ABOVE WILL NOT WORK!", zPortID
        subSendMsg "&AMEDIT MOBID (look at them)" & vbCrLf & "ie.  MFORGE 1 OSN    MFORGE 3 OSC" & vbCrLf & "ie.  MFORGE 1 DSN    MFORGE 5 DSC", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMagicalMobSpells," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLessarImmortalCommands(zPortID As String)
On Error GoTo Err_Check
    subSendMsg vbCrLf & "&w" & "~LESSAR  I M M O R T A L  C O M M A N D S~" & vbCrLf & "&a------------------------------------------------------------", zPortID
    subSendMsg "&a" & _
        "RC              - Room Create" & vbCrLf & _
        "RN              - Room Name" & vbCrLf & _
        "RD              - Room Delete (type LOOK before using this command)" & vbCrLf & _
        "RDD             - Room Day Description" & vbCrLf & _
        "RDN             - Room Night Description" & vbCrLf & _
        "RBC             - Room Build Construct - toggles Exits" & vbCrLf & _
        "RBCD            - Room Build Construct Delete it" & vbCrLf & _
        "RB              - Room Block Direction +/-" & vbCrLf & _
        "RH              - Room Hide Direction +/-" & vbCrLf & _
        "RR              - Room area rules" & vbCrLf & _
        "WADD            - immo wadd &xWhereName    &x = colour codes allowed" & vbCrLf & _
        "WAPP            - immo wapp &xWhereName    &x = help colours" _
    , zPortID
    subSendMsg "&a" & _
        "LOCA            - shows your x y z location to teleport" & vbCrLf & _
        "TELEPORT        - tele x y z" & vbCrLf & _
        "WHERE           - this will show area's where information" & vbCrLf & _
        "RALL/AREA       - Room information verbose, random block or non-formatted views" & vbCrLf & _
        "                - immo area or immo rall to show the area in detail" & vbCrLf & _
        "MAPT            - Toggles the room shown on the MAP command" _
    , zPortID
    subSendMsg "&a" & _
        "AE              - type IMMO AE for condition syntax" & vbCrLf & _
        "DC              - door name, short description" & vbCrLf & _
        "DDEC            - door name, short description|<door full desc here>" & vbCrLf & _
        "DSTA            - Door Status (unlocked, uses key)" & vbCrLf & _
        "DWIN            - Door Window" & vbCrLf & _
        "FLEE            - Toggle fleeing is allowed" & vbCrLf & _
        "FLY             - Toggle Fly ability" & vbCrLf & _
        "UNDERWATER      - Sets water level" & vbCrLf & _
        "HEIGHT          - Sets room ceiling height - need shrink potion for some" & vbCrLf & _
        "QUEST           - Toggle Mob and Object drops allowed to this Room" & vbCrLf & _
        "                  See Also: MFORGE 1 IM and MFORGE 1 QMNA" & vbCrLf & _
        "MOVEMENT        - Area Movement cost to pass (immo amov) - huff puff!" _
    , zPortID
    
    subSendMsg "&a" & vbCrLf & _
        "MC              - Mob Creation: mob name, short description" & vbCrLf & _
        "MEDIT           - Lock your MFORGE command to Edit a mobile" & vbCrLf & _
        "MID             - Mob Identify, the capitols are the commands to use" & vbCrLf & _
        "MFORGE          - This will mobile forge skills, and spells, and descriptions" & vbCrLf & _
        "                  MFORGE uses MEDIT's TARGETID" & vbCrLf & _
        "                  MFORGE's commands are the capitols in MID" & vbCrLf & _
        "            ie.   MFORGE DESC <mob long desc here>" & vbCrLf & _
        "MD              - Mob Delete: mob name, short description" _
    , zPortID
    
    subMagicalMobSpells zPortID, 1
    subSendMsg "&GSee Also: &gHELP [IMMORTAL/LESSAR/AREA/SLIST/BASIC/ADVANCED]", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subLessarImmortalCommands," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subHigherImmortalCommands(zPortID As String)
On Error GoTo Err_Check
    subSendMsg vbCrLf & "&w" & "~HIGHER  I M M O R T A L  C O M M A N D S~" & vbCrLf & "&a------------------------------------------------------------", zPortID
    subSendMsg "&w~SPACE COMMANDS~" & "&a" & vbCrLf & _
        "NAVIG       - will randomly select a mobship and move it" & vbCrLf & _
        "WORM        - This will create a wormhole from your current" & vbCrLf & _
        "              location to the x y z desination given." _
    , zPortID
    
    subSendMsg "&w~QUEST CONTROL~" & "&a" & vbCrLf & _
        "HOSTILE     - creates a spaceship quest to phaser hostiles" & vbCrLf & _
        "SPACE       - creates a spaceship quest to phaser mobships in space" & vbCrLf & _
        "GUESS       - GUESS FIVE-LETTER-WORD-MINIMUM sets up the guess game" & vbCrLf & _
        "              IMMO GUESS clears the guess game" & vbCrLf & _
        "OBJECT      - drops a glory item into the realm" & vbCrLf & _
        "MOB         - drops a glory creature into the realm" & vbCrLf & _
        "BIRD        - a random bird +1 rnd glory" & vbCrLf & _
        "PICTURE     - immo picture rand rand" & vbCrLf & _
        "BOUNTY      - immo bounty - will clear the bounty list" _
    , zPortID
    
    subSendMsg "&w~PORT CONTROLS~" & "&a" & vbCrLf & _
        "LIVE        - ports that are live with player names" & vbCrLf & _
        "              last attempt complete bans older than 3 months are deleted" & vbCrLf & _
        "IP          - immo ip will show you a list of player ips on line" & vbCrLf & _
        "PORT        - immo port will show you a list of player ports on line" & vbCrLf & _
        "ACTIVE      - This is powerful, shows all activity on all ports" _
    , zPortID
    subSendMsg "&a" & _
        "COMPLETE    - this will completely ban an IP - never ban won't even help" & vbCrLf & _
        "              immo complete list will list all completely banned IPs" & vbCrLf & _
        "NETWORK     - immo network - this will toggle if the system will network ban immo banned ips" & vbCrLf & _
        "NEVER       - you can use PID and PEDIT to see what this status is" & vbCrLf & _
        "              use this to toggle if you want the player to be immune to banned ports" & vbCrLf & _
        "BAN         - immo ban playername - bans all their IPs - immo never allows" & vbCrLf & _
        "              specific people through the port" & vbCrLf & _
        "DYNAMIC     - immo dyna portnumber   will set the dynamic port, default is 4000" & vbCrLf & _
        "UNBAN       - immo unban playername - will undo immo ban" & vbCrLf & _
        "SPY12345    - immo spy1 portid - will spy port 1 there are 5 spy commands" & vbCrLf & _
        "CLOSE       - immo close portid - immo active to see the ports" _
    , zPortID
    
    subSendMsg "&w~HIGH IMMORTAL AREA TOGGLES~" & vbCrLf & "&a" & _
        "FINISHED    - toggle area finished by immortal level" & vbCrLf & _
        "JUMP        - immo jump value sets   from 0:none 1:ez to 255:HARD to jump into" & vbCrLf & _
        "CARE        - check if an area exists where you are not, ie. area X Y Z" _
    , zPortID
    
    subSendMsg "&w~GODS COMMANDS~" & vbCrLf & "&a" & _
        "GTC         - Gods Tease channel - all mortals can see this" & vbCrLf & _
        "GOC         - Gods only channel" & vbCrLf & _
        "CLOG        - Create Log - so immortals can leave message for eachother" & vbCrLf & _
        "VLOG        - View Log - How Many or ALL" & vbCrLf & _
        "DLOG        - Delete Log" _
    , zPortID
    
    subSendMsg "&w~OBJECT CONTROLS~" & vbCrLf & "&a" & _
        "RARE        - deletes anything except rares in the target's inventory" & vbCrLf & _
        "OFIX        - will object fix anything someone cannot pickup from the ground " & vbCrLf & _
        "FLAG        - this will turn an item into a clan flag" & vbCrLf & _
        "CRAFT       - creates a transmuting device in the area" & vbCrLf & _
        "OTCF        - toggles an item in inventory to use colours HELP COLOURS" _
    , zPortID
    
    subSendMsg "&w~MOBILE/CREATURE CONTROLS~" & vbCrLf & "&a" & _
        "MCOPY       - immo mcop mobid will copy that mobid to the new location you are at" & vbCrLf & _
        "MEDIT       - locks the Mob Edit ID Number to the mob - seen under SCORE" & vbCrLf & _
        "              immo tag/medit a mob for editing, " & vbCrLf & _
        "MFORGE      - MID will list all the skills to edit by capitals of the name." & vbCrLf & _
        "              MFORGE 3 NOA will forge 3 attacks a round to the medited mobile." & vbCrLf & _
        "MID         - Mob Identification - use MEDIT to set the value before using MID" & vbCrLf & _
        "              See Also: PEDIT PLAYERID (from look)" _
    , zPortID
    
    subSendMsg "&w~PLAYER CONTROLS~" & vbCrLf & "&a" & _
        "EMAIL       - immo email will present the email list to the high level immortals" & vbCrLf & _
        "DEMAIL      - immo demail will clear matching emails, good for returned emails" & vbCrLf & _
        "VOTE        - You can IMMO VOTE MESSAGE/STOP/CLEAR" & vbCrLf & _
        "RENAME/NAME - will rename a playername to another playername" & vbCrLf & _
        "IGNORE      - everyone online will ignore the player automatically - immo ignore for syntax" & vbCrLf & _
        "              immo ignore personname all - will make everyone in the realm ignore them" & vbCrLf & _
        "              immo ignore personname clear - clears all players ignoring them" _
    , zPortID
    subSendMsg "&a" & _
        "HALLUCINATE - sets the player to be hallucinating for awhile" & vbCrLf & _
        "WORLD       - immo world will show the locations of all mortals" & vbCrLf & _
        "POOF        - immo poof playername [0 to 9]" & vbCrLf & _
        "NUKE        - immo nuke player password - will nuke a player" & vbCrLf & _
        "NUKE        - immo nuke player - will toggle the player's nuke control" _
    , zPortID
    subSendMsg "&a" & _
        "CR          - Clan rename, immo cr oldclanname newclanname" & vbCrLf & _
        "PLAYERNAME  - will test a name without having to login" & vbCrLf & _
        "PEDIT       - allows an immortal to see the status of a player" & vbCrLf & _
        "PID         - Player Identification - use PEDIT" & vbCrLf & _
        "              See Also: MEDIT MOBID (from look)" & vbCrLf & _
        "RANK        - immo rank toggles immortal and player clan and ranks" & vbCrLf & _
        "FORCE       - immo force portid commandline" & vbCrLf & _
        "              makes a player perform the command" & vbCrLf & _
        "LEVEL       - sets the player level, there will be no gain changes" _
    , zPortID
    subSendMsg "&a" & _
        "DATE        - immo date playername Jan 21, 1972 - sets the last played date" & vbCrLf & _
        "TITLE       - immo title playername NewWhoTitle" & vbCrLf & _
        "DESC        - immo desc playername         - clears that player's description" & vbCrLf & _
        "              immo desc playername msghere -   adds that player's description" & vbCrLf & _
        "ENTER       - immo enter playername message - sets login message" & vbCrLf & _
        "EXIT        - immo exit playername message - sets logout message" & vbCrLf & _
        "NUKE        - immo nuke playername password - deletes a player" & vbCrLf & _
        "              immo nuke playername  - will toggle player delete ability on/off" & vbCrLf & _
        "REMOTE      - immo remote ip - will delete this remote host ip" & vbCrLf & _
        "LOCK/UNLOCK - immo lock playername - will toggle-lock all worn equipment" & vbCrLf & "               or carried inventory forever, FORGE STAMP is similar." _
    , zPortID
    subSendMsg "&a" & _
        "CHAN [+/-] GOD        - all high level builders can see this channel" & vbCrLf & _
        "CHAN [+/-] GTC or ITC - immortals can use this as an echo channel" & vbCrLf & _
        "ITC/GTC/ITG - Global Echo channel or the immortal tease channel global" & vbCrLf & _
        "ITR         - Room Echo channel or the immortal tease channel room" & vbCrLf & _
        "EEC         - Edit Emote Chart, see also: HELP EMOTE and IMMO EEC" & vbCrLf & _
        "MSE         - Mob Speak Editor, see also: IMMO MSE" & vbCrLf & _
        "MQE         - Mob Quest Editor, see also: IMMO MQE" & vbCrLf & _
        "MEP         - Mob Emote Player, see also: IMMO MEP" & vbCrLf & _
        "MPE         - Mob Phrase Editor, see also: IMMO MPE" & vbCrLf & _
        "MQHE        - Mob Quest Herd Editor, see also: IMMO MPE" & vbCrLf & _
        "HELP        - Help System editor, immo help for the syntax" & vbCrLf & _
        "HAIL is a channel that cannot be blocked - and only immortals can use it" _
    , zPortID
    
    subSendMsg "&w~PLAYER DISCIPLINES~" & vbCrLf & "&a" & _
        "AUCTION     - immo auction list/stop" & vbCrLf & _
        "SHADOW      - immo shadow playername duration" & vbCrLf & _
        "TITLE       - immo title playername msg - will overwrite their title" & vbCrLf & _
        "DESC        - immo desc playername - will wipe their desc clean" & vbCrLf & _
        "SR          - immo rs playername     - they cannot use say or yell" & vbCrLf & _
        "SG          - immo gs playername     - they cannot use ramble, quest, etc..." & vbCrLf & _
        "SCARE       - sets the player to be too scared to do anything" & vbCrLf & _
        "ARENA       - immo arena toggles pk on and off" _
    , zPortID
    subSendMsg "&a" & _
        "SCM         - immo scm value - allows players to talk longer (40 is default)" & vbCrLf & _
        "HEAVEN      - immo heaven target - adds 5 round stun and 1 hitpoints" & vbCrLf & _
        "HELL        - immo hell target - adds 50 round stun and 1 hitpoints" & vbCrLf & _
        "BOLT        - immo bolt target - 50 round stun and half hitpoints" & vbCrLf & _
        "FIREBALL    - immo fireball target - sets 5 round stun and half hitpoints" & vbCrLf & _
        "              * Note: These all set TITLE and DESC commands to a higher level to use." & vbCrLf & _
        "POOF        - immo poof target - sets 2 round stun and blind and morphs them" _
    , zPortID
    subSendMsg "&a" & _
        "PASSWORD    - immo pass playername newpassword" & vbCrLf & _
        "XP          - immo pass playername xp" & vbCrLf & _
        "PLAYERNAME  - immo player playername - the system will test a name" & vbCrLf & _
        "RENAME      - immo rename oldplayername newplayername" & vbCrLf & _
        "GOLD        - immo gold playername amount sets the gold" _
    , zPortID
    
    subSendMsg "&w~AREA ASSIGNMENTS AND CONTROLS~" & vbCrLf & "&a" & _
        "ASSIGN      - you can assign an area to a player" & vbCrLf & _
        "              they will have immortal level 3 powers at that location radius" & vbCrLf & _
        "              immo assign traer 10, will assign the area" & vbCrLf & "around the admin for a radius" & vbCrLf & _
        "              This is to give immortal commands to the builder for the area" & vbCrLf & _
        "TRANSPORT   - immo transport playername [playername/areaname]" & vbCrLf & _
        "              immo transport @POINT@  - will set the transport point" & vbCrLf & _
        "SPOT        - immo spot will try to force mobs in the area to move" _
    , zPortID
    
    subSendMsg "&w~DATABASE UTILITIES~" & vbCrLf & "&a" & _
        "SQL         - immo sql sqlcodehere - you cannot undo this command!" & vbCrLf & _
        "              If you learn SQL you will be able to use this command" & vbCrLf & _
        "              in the place of nearly all existing immortal build commands." & vbCrLf & _
        "TABLES      - immo tables for the syntax" & vbCrLf & _
        "TABLE       - immo table - lists all the table names in the database" & vbCrLf & _
        "TABLE FIELD - immo table field TABLENAME - to see that tables field list" & vbCrLf & _
        "TIMER       - immo timer will show you if the system is up" & vbCrLf & _
        "MODE        - This will toggle from 9x mode to XP Mode" & vbCrLf & "            - use IMMO ACTIVE to verify" _
    , zPortID
    subSendMsg "&a" & _
        "ARCHIVE     - activates forge and chat in a word document" & vbCrLf & _
        "BACKUP      - immo backup to back up the system to C:\" & vbCrLf & _
        "RBWX        - this will attempt to reboot a windows 9x operating system" & vbCrLf & _
        "RBXP        - this will attempt to reboot a windows XP/NT operating system" & vbCrLf & _
        "              Note: RebootAllowed must be set to true for the player." & vbCrLf & _
        "FIND        - this will search most of the system for a match" & vbCrLf & _
        "REPLACE     - this will search most of the system and replace the word" _
    , zPortID
    subSendMsg "&a" & _
        "REFRESH     - This will refresh only the realm ports" & vbCrLf & _
        "STATUS      - this will show the server memory status" & vbCrLf & _
        "SEND        - SEND IPADDY - will attempt to transmit the entire" & vbCrLf & "database file to the" & vbCrLf & _
        "              server at the IPADDY. You must be running the server first." & vbCrLf & _
        "              The file being transmitted will save to (C:\CoABakUp.DNL)." & vbCrLf & _
        "HEAL        - This will heal/repair all players and" & vbCrLf & "damaged starships in the realm" _
    , zPortID
    
    subSendMsg "&w~SYSTEM REPORTS~" & vbCrLf & "&a" & _
        "EQUIPMENT   - immo equi - will give you a rough idea what is missing from the system" _
    , zPortID
    
    subSendMsg "&w~AREA TOGGLES~" & vbCrLf & "&a" & _
        "CLAN        - immo clan 0123..9 ie. immo clan 3" & vbCrLf & _
        "RRNK        - immo rrnk inductvalue - will make the room rank resistant" _
    , zPortID
    subSendMsg "&w~ROOM CONTROLS~" & vbCrLf & "&a" & _
        "TYPE        - immo type will set the area PlayerTypes" & vbCrLf & "0:normal 1:house 2:starship 3:colony 4:militarybase 5:militarydefends" & vbCrLf & _
        "              See also: HELP HOUSE" _
    , zPortID
    subSendMsg "&a" & _
        "RECALL\MARK - these are used to get around fast and mark where you last worked" & vbCrLf & _
        "LOCA        - tells you your X Y Z position in the system" & vbCrLf & _
        "TELE        - move to X (west -/ east +) Y (north -/south +) Z (up -/down +)" & vbCrLf & _
        "MAGICWORD   - immo magic magicword - magicword must be 5 chars long exactly" & vbCrLf & _
        "MAPT        - toggles if the area can be seen using the MAP command" _
    , zPortID
    subSendMsg "&w~SYSTEM DIFFICULTY SETTINGS~" & "&a" & vbCrLf & _
        "MSLOW       - immo mslo for a slow speed server PII" & vbCrLf & _
        "MNORMAL     - immo mnor for a normal speed server PIII" & vbCrLf & _
        "MFAST       - immo mfas for more mob AI Pentium 4+ LAGGY MODE" & vbCrLf & _
        "ON          - immo son   we turn the server-on" & vbCrLf & _
        "OFF         - immo soff  we turn the server-off, try to log in" & vbCrLf & _
        "MODE        - This will toggle from 9x mode to XP Mode - use IMMO ACTIVE to verify" & vbCrLf & _
        "See Also: IMMO MODE" _
    , zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subHigherImmortalCommands," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subHelpSystem(zPortID As String, zPassFocusWord As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim rsHelpSystem As Recordset
    Dim lCount As Long
    Dim lRecordCount As Long
    Dim lEmoteCount As Long
    Dim zEmoteList As String
    Dim zEmote As String
    Dim bHelpSystemOkay As Boolean
    Dim lPlayerID As Long
    Dim lImmortalLevel As Long
    Dim zPlayerClass As String
    Dim lClanMemberLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lTotalEmoteCount As Long
    Dim zFocusWord As String
    
    zFocusWord = zPassFocusWord
    zFocusWord = strTrimEOLMatching(zFocusWord, "S", "", True)
    zFocusWord = strTrimEOLMatching(zFocusWord, "ED", "", True)
    zFocusWord = strTrimEOLMatching(zFocusWord, "ING", "", True)
    zFocusWord = strTrimEOLMatching(zFocusWord, "ES", "", True)
    
    'subHelpSystem zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5)), lImmortalLevel, zClass, lClanMemberLevel, lPlayerID
    ', lImmortalLevel As Long, zPlayerClass As String, lClanMemberLevel As Long, lPlayerID As Long
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, ImmortalLevel, Class, ClanMemberLevel, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
        zPlayerClass = MyCStr(rsPlayer!Class)
    End If
    Set rsPlayer = Nothing
    
    If (lTotalAssignedAreas(lPlayerID) > 0) Then
        lImmortalLevel = 4
    End If
    
    bHelpSystemOkay = False
    
    Select Case MyCStr(Mid(zFocusWord, 1, 4))
        Case "HINT"
            subSendMsg vbCrLf & "&gType HINTS alone to manage tricky to use ground objects.", zPortID
        Case "LEVE", "LIST", "LESS", "LICL", "LOWE"
            If (lImmortalLevel > 0) Then subLessarImmortalCommands zPortID
        Case "SUPE" 'Supervisor
            If (lImmortalLevel > 4) Then
                bHelpSystemOkay = True
                subSendMsg vbCrLf & "&gGame Commands - Immortal Supervisors:" & vbCrLf & _
                    gblzFNGRE & "Supervisor command examples:" & vbCrLf & _
                    "SUPE 10 - will show you the last ten commands used by the immortals" & vbCrLf & _
                    "SUPE Trisker 10 - will show you the last 10 commands used by this immortal" & vbCrLf & _
                    "" _
                , zPortID
            End If
        Case "IMM", "IMMO", "GOD", "BUIL", "TOOL", "HIGH"
            bHelpSystemOkay = True
            If (lImmortalLevel > 0) Then
                If (lImmortalLevel > 4) Then
                    subHigherImmortalCommands zPortID
                End If
                If (lImmortalLevel < 5) Then
                    subSendMsg "&GHELP &g[LESSER IMMORTAL COMMANDS, MC, RC, OC, DOOR, MOB, ROOM, OBJECT, AREA, FORGE]", zPortID
                Else
                    subSendMsg "&GHELP &g[LESSER IMMORTAL COMMANDS, SUPERVISOR, MC, RC, OC, DOOR, MOB, ROOM, OBJECT, AREA, FORGE, WORM]", zPortID
                End If
                subLessarImmortalCommands zPortID
            End If
        Case "QUIV"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~QUIVERS~&g" & vbCrLf & _
                "Quivers are arrows for bows." & vbCrLf & _
                "Note: Bows are a two handed item." _
            , zPortID
        Case "FACT"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~FACTIONS~&g" & vbCrLf & _
                "When you pick a faction you become innoculated because those are you PEOPLE, to an extent. There are 9 factions to choose from." & vbCrLf & _
                "Each time you cross though a faction that does not match with yours, you can catch the flu and cough up blood and toxins. Thieves hate cataching the flu and should FACTION COMMAND their favorite stealing locations." _
            , zPortID
            subSendMsg "&AFACTIONS DECLARE A WINNER at 100 Million total population", zPortID
        Case "QUAR"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~QUARRELS~&g" & vbCrLf & _
                "Quarrels are bolts for crossbows." & vbCrLf & _
                "Note: Crossbows are a two handed item." _
            , zPortID
        Case "GOLD", "SOD", "GRAS", "XP", "EXPE", "DISA"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~WHY DID MY ITEM DISAPPEAR~&g" & vbCrLf & _
                "Gold items and Grass Sod items can be removed and worn," & vbCrLf & _
                "however when you drop a gold item or a sod item it becomes a tangible asset" & vbCrLf & _
                "on the ground." & vbCrLf & _
                "You can turn special items into actual gold or experience by dropping" & vbCrLf & _
                "it onto the ground and then picking it up. This can be useful or a hindrance." _
            , zPortID
            
            subSendMsg vbCrLf & "&G~GIVING GOLD~&g" & vbCrLf & _
                "To give gold to a player, type GIVE for the syntax." _
            , zPortID
        Case "GUES"
            bHelpSystemOkay = True
            subSendMsg "&GGUESS WORD GAME" & vbCrLf & "&gThe guess word game is a method to earn crowns of glory." & vbCrLf & "This is useful to forge - HELP FORGE.", zPortID
            If (lImmortalLevel > 79) Then
                subSendMsg "&GIL80+: IMMORTAL GUESS WORD GAME COMMANDS" & "&g", zPortID
                subSendMsg "IMMO GUESS             - will cancel the current guess word that is running.", zPortID
                subSendMsg "IMMO GUESS RAND RAND   - will force the system to select a word to use from the dictionary.", zPortID
                subSendMsg "IMMO GUESS WORD DELETE - will delete the word from the dictionary.", zPortID
                subSendMsg "IMMO GUESS WORD LIST   - will list a matching word to the pattern word.", zPortID
                subSendMsg "                       - You can use a wild card * after a few letters.", zPortID
                subSendMsg "                       - for example: IMMO GUESS WOR* LIST", zPortID
                subSendMsg "&wNOTE: When a player correctly guesses a word it will be added to the dictionary.", zPortID
            End If
        Case "GOLF"
            bHelpSystemOkay = True
            subSendMsg "&GSYNTAX: &gGolf BallName NameOfHole", zPortID
            subSendMsg "&gSTRENGTH       - Str helps to strike the ball which gives it the distance it should travel." & vbCrLf & "DEXTERITY      - Dex helps the accuracy so that you can land the ball closer to the green.", zPortID
            subSendMsg "&gPAR            - A par in this mud is 15 from hole to hole." & vbCrLf & "AIMING         - If your ball gets stuck try to aim at one of the" & vbCrLf & "                 other hole names, and shoot your way to freedom." & vbCrLf & "SWINGS         - Putting into a cup will reset your swings as will" & vbCrLf & "                 logging out of the realm.", zPortID
            subSendMsg "&g                 Note: You cannot golf from colonist areas;", zPortID
            subSendMsg "&g                       clan areas; water areas more than a few inches deep.", zPortID
            subSendMsg "&g                       From Even message areas; nor non-flee zones; and" & vbCrLf & "                       also the areas must accept quests.", zPortID
            If (lImmortalLevel > 1) Then
                subSendMsg "&gTo allow golfing in the area the following must be correct in tblArea:", zPortID
                subSendMsg "&g    (Underwater<9 AND DXYZActive=0 AND NoFleeZone=False AND NoQuestZone=0 AND", zPortID
                subSendMsg "&g    ClanID=0 AND PlayerType=0 AND X=# AND Y=# AND Z=#)", zPortID
                subSendMsg "&g    Where # is the location of the player-golfer.", zPortID
            End If
        Case "TITL"
            bHelpSystemOkay = True
            subSendMsg "&GSyntax: &gTITLE YOUR-TITLE-HERE" & vbCrLf & "This will set your title in WHO." & vbCrLf & "&GSee Also: HELP &g[COLOR/WHOIS/DESC]", zPortID
        Case "DESC"
            bHelpSystemOkay = True
            subSendMsg "&GSyntax: &gDESC YOUR-PARAGRAPH-HERE" & vbCrLf & "This will set your title in WHO." & vbCrLf & "&GSee Also: HELP &g[COLOR/WHOIS/TITLE]", zPortID
        Case "AUTO"
            bHelpSystemOkay = True
            subSendMsg "&gThis will toggle your Autoloot On or Off." & vbCrLf & "Autoloot gets the item from a corpse automatically." & vbCrLf & "If you do not use autoloot then you would" & vbCrLf & "need to use the GET command.", zPortID
        Case "PART", "TEAM", "PARTY", "GROU", "FOLL" 'party or group help
            subSendMsg "&G~GROUPING~" & vbCrLf & "SYNTAX: &gGROUP PLAYERNAME" & vbCrLf & "        GROUP PLAYER DISBAND" & vbCrLf & "        FOLLOW SELF" & vbCrLf & "Also: GROUP ALL and GROUP PLAYERNAME" & vbCrLf & "When you attack everyone in the group will attack if they are grouped.", zPortID
        Case "LESS" 'lessar gods
            'bHelpSystemOkay = False we want to check the help system too
            Select Case lImmortalLevel
                Case 1
                    subSendMsg "&GLevel 1 - LESSAR GOD COMMANDS" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "&gFIRE BOLT AUCTION GS RS CLOG(creates admin a msg) RALL(spell checking)" & vbCrLf & "You cannot edit or change the system in anyway using these commands.", zPortID
                    subSendMsg "&GHELP &g[IMMORTAL/FORGE]", zPortID
                Case 2 To 999
                    subSendMsg "&GLevel 2 - LESSAR GOD COMMANDS" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "&gFIRE BOLT AUCTION GS RS CLOG(creates admin a msg) RALL(spell checking)" & vbCrLf & "HEAVEN HELL PORT ARENA IP LIVE ACTIVE REBOOT CLOSE" & vbCrLf & "You cannot edit or change the system in anyway using these commands.", zPortID
                    subSendMsg "&GHELP &g[IMMORTAL/FORGE]", zPortID
                Case Else
                    subSendMsg "&gYou are not enlightened enough to read these commands.", zPortID
            End Select
        Case "STEA" 'steal
            'bHelpSystemOkay = False 'we want to let immortals add their own DONATION search to tblSystemHelp
            subSendMsg "&GSTEALING" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "&gFORGE STAMP   - will protect your best items from theft." & vbCrLf & "SCARED        - if some one steals from you and fails" & vbCrLf & "              they become very easy to kill - even the high levels.", zPortID
            subSendMsg "&GHELP &g[FORGE/RULES]", zPortID
        Case "FAVO", "VOTE"
            bHelpSystemOkay = True
            subSendMsg "&gSYNTAX: FAVOUR IMMORTALENTITYNAME" & vbCrLf & "        This command toggles the vote on or off as well." & vbCrLf & "        This command alone to see your vote.", zPortID
            subSendMsg "&gSYNTAX: VOTE [Y/N/Abstain]", zPortID
        Case "CLEA", "RAID"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~RAIDS or DAMAGED AREAS~&g" & vbCrLf & _
                "Use the CLEAN command, which takes from your MOVE points." & vbCrLf & _
                "Note: Raids and Player areas which makes the most corpses cause areas to be littered and damaged." _
            , zPortID
        Case "EMAI"
            bHelpSystemOkay = True
            subSendMsg "&WSend your area descriptions and/or the descriptions of your house to:" & vbCrLf & "Email: " & zSystemConfig(2) & vbCrLf & "&GPLEASE READ THIS! IMPORTANT! Before you send your descriptions," & vbCrLf & "please read HELP BUILD and HELP DONATIONS!", zPortID
            subSendMsg "&GHELP &g[DONATIONS/BUILD/IMMORTAL/RULES]", zPortID
        Case "EMOT", "SOCI"
            bHelpSystemOkay = True
            lEmoteCount = 0: lTotalEmoteCount = 0: zEmoteList = ""
            Set rsHelpSystem = MyDB.OpenRecordset("SELECT ChartEmoteID, KeywordCommand FROM tblChartEmote ORDER BY KeywordCommand;", dbOpenSnapshot)
            Do While (Not rsHelpSystem.EOF)
                zEmote = MyCStr(rsHelpSystem!KeywordCommand)
                lTotalEmoteCount = lTotalEmoteCount + 1
                lEmoteCount = lEmoteCount + 1
                Select Case lEmoteCount
                    Case 2, 4, 6
                        zEmoteList = zEmoteList & "&c"
                    Case Else
                        zEmoteList = zEmoteList & "&C"
                End Select
                
                zEmoteList = zEmoteList & strForceSize(zEmote, 9, " ", "A") & " "
                
                If (lEmoteCount > 6) Then
                    subSendMsg zEmoteList, zPortID
                    lEmoteCount = 0
                    zEmoteList = ""
                End If
                rsHelpSystem.MoveNext
            Loop
            Set rsHelpSystem = Nothing
            If (lEmoteCount <> 0) Then subSendMsg zEmoteList, zPortID
            subSendMsg gblzFBCYA & "ROULETTE  " & "&cDECK      &CHORSE     " & "&cDICE      ANGER    " & "&c(special emotes)", zPortID
            If (lTotalEmoteCount <> 0) Then subSendMsg "&w" & lTotalEmoteCount & " total emotes.", zPortID
            subSendMsg "&GSee Also: HELP &g[PETS/PEMOTE/BASIC/ADVANCED/SLIST/LEARN TREE/AREA/MOB]" & vbCrLf & "&aNote: You can use * with the command EMOTE to move your name." & vbCrLf & "emote smiles sheepishly.    emote With a wide grin * gazes sheepishly." & vbCrLf & "You can also use PEMOTE.", zPortID
        Case "PLAY", "PROL"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~PROLOGUE~&g" & vbCrLf & _
                "Okay, could you tell me a little about it?" & vbCrLf & _
                "Its a heavy quest mud and you can learn skills." & vbCrLf & _
                "Our objects and items in the game are very good with" & vbCrLf & _
                "lots of stats raising items, spells, and skills come from them." & vbCrLf & _
                "You can also build your own stats using the forge command." & vbCrLf & _
                "We have magic find and in high levels this helps you to level." & vbCrLf & _
                "Mobs are a challenging fight similar to players with increased skills and magic." & vbCrLf & _
                "Type SCORE for your starting magic find." & vbCrLf & _
                "When you get high level magic find help you get experience with bonus xp chunks." & vbCrLf & _
                "In here you level with fighting and later ob powerful magic find items for the bonus xp." & vbCrLf & _
                "Many of your your skills are automatic, some ar not," & vbCrLf & _
                "read about this in help basic and help advanced." & vbCrLf & _
                "We have treasure items which are rarer than our uniques and godly items." & vbCrLf & _
                "" _
            , zPortID
            
            subSendMsg vbCrLf & "&GGame Commands - Prologue:&g" & vbCrLf & _
                "Mobs have lots of different spells." & vbCrLf & _
                "The mud is 100% customized in visual basic." & vbCrLf & _
                "Map moves with you so you dont become too lost and confused." & vbCrLf & _
                "MARK and RECALL move you around and there are magic words to move you around" & vbCrLf & _
                "faster around the realm, its faster and easier too" & vbCrLf & _
                "There are quests everwhere and are all well done." & vbCrLf & _
                "Remember to look at everything and get anything from corpses." & vbCrLf & _
                "Quests are given to win crowns of glory from the immortals." & vbCrLf & _
                "Quests from quest masters helps to raise your hit points, essence, mana, or soul." & vbCrLf & _
                "Type X or SCORE - how much glory do you have now?" & vbCrLf & _
                "Type help forge with crowns of glory you can forge your own weapons in here at the blacksmith." & vbCrLf & _
                "You can compound forge to one item so most find a really good item and keep adding to it - help forge." & vbCrLf & _
                "You can rename one of your items to what you like with oren too, most do this first." & vbCrLf & _
                "Mobs can throw you in jail if you are really evil with your alignment." & vbCrLf & _
                "New angle to mudding with new quests added daily." & vbCrLf & _
                "" _
            , zPortID
            'int wis for mana and essence, soul is con str, move is dex etc...I will make a help on this now
        Case "AC"
            bHelpSystemOkay = False
            subSendMsg vbCrLf & "&W~Armour Class~&w" & vbCrLf & _
                "Armour Class is generally your body worn protection." & vbCrLf & _
                "&aWhen Hitroll is finally able to cut into your armour the damage inflicted" & vbCrLf & _
                "can be absorbed. Certain classes have the natural ability to" & vbCrLf & _
                "effectively allow their armour to absorb damage more often." & vbCrLf & _
                "Some items such as shields carry a naturally high absorption capability." _
            , zPortID
        Case "PET", "TRAI", "PETS", "PEMO", "ANIM", "MOUN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Train:&g" & vbCrLf & _
                "TRAIN (mob name)           - add a trainable pet to your side." & vbCrLf & _
                "        If your level is high enough you can add the mob to your" & vbCrLf & _
                "        group of fighters." & vbCrLf & _
                "        You may not add the same mob more than once to your group." & vbCrLf & _
                "        There are many trainable mobiles in the realm as well." & vbCrLf & _
                "        Once the pet is assigned to you, you cant look at the pet." & vbCrLf & _
                "TRAIN (mob name) DISBAND   - to remove the pet from your side." & vbCrLf & _
                "PEMOTE (pet name) (emote) (target name) - will make your pets pet-emote." & vbCrLf & _
                "MOUNT (pet name) - mount a pet for its minor skills and low movement cost." _
            , zPortID
            subSendMsg "&GImportant: Your CHArisma helps pets hit and gain extra experience points!", zPortID
            subSendMsg "&GImportant for Knights: There is a chance when your pet dies it ::FORCE ASCENDS:: instead.", zPortID
            subSendMsg "&GSee Also: HELP &g[EMOTE/LEARN/MOB/BASIC COMMANDS/TELNET/ADVANCED COMMANDS/TITLE]", zPortID
        Case "RULA", "NEWB", "FAQ", "RULE", "BOTT", "BOT", "NOOB", "NEW", "LOGI", "LOGO", "REAL"
            bHelpSystemOkay = True
            subRealmRules zPortID, 1, 1
            subSendMsg "&GThank you for reading the first quarter of the rules.&g (HELP RULB)" & vbCrLf & "&gHELP [RULB/RULC/RULD]", zPortID
        Case "RULB"
            bHelpSystemOkay = True
            subRealmRules zPortID, 2, 1
            subSendMsg "&GThank you for reading the second quarter of the rules.&g (HELP RULC)" & vbCrLf & "&gHELP [RULA/RULC/RULD]", zPortID
        Case "RULC"
            bHelpSystemOkay = True
            subRealmRules zPortID, 3, 1
            subSendMsg "&GThank you for reading the third quarter of the rules.&g (HELP RULD)" & vbCrLf & "&gHELP [RULA/RULB/RULD]", zPortID
        Case "RULD"
            bHelpSystemOkay = True
            subRealmRules zPortID, 4, 1
            subSendMsg "&GThank you for reading the last quarter of the rules.&g (HELP RULA or HELP RULE)" & vbCrLf & "&gHELP [RULA/RULB/RULC]", zPortID
        Case "LANG"
            bHelpSystemOkay = True
            subSendMsg "&GGame System - Language List:" & vbCrLf & "&g" & _
                "Languages are used to understand what creatures of the realm are trying" & vbCrLf & _
                "to communicate to you. You gain languages by looking for the" & vbCrLf & _
                "orbs, translators, and other high technology magical equipment." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[MOBS/AREA]" _
            , zPortID
            For lCount = 1 To 14
                subSendMsg "&G" & "&C" & strForceSize(lCount & " ", 20, " ", "A") & zTranslateLanguage(lCount), zPortID
            Next lCount
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&G~FORGE LANGUAGE~&g" & vbCrLf & _
                    "SYNTAX: Type FORGE ABOVENUMBER LANGUAGE" _
                , zPortID
            End If
        Case "ADVA", "COMM", "ACTI", "SCRO", "RECI", "IDEN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GPlayer Game Commands - Advanced Commands:" & vbCrLf & "&g" & _
                "QUAFF          - to drink an equipped potion in your hands" & vbCrLf & _
                "DRINK          - Drink fountain" & vbCrLf & _
                "RECITE         - recite scroll targetobject" & vbCrLf & _
                "MARK and RECALL- help you explore the world faster." & vbCrLf & _
                "X or SCORE     - shows your your character's abilities" _
            , zPortID
            subSendMsg vbCrLf & "&GPlayer Game Commands - Advanced Commands:" & vbCrLf & "&g" & _
                "CONSIDER       - consider a target before you attack" & vbCrLf & _
                "DIG/BURY       - hides an object in the area" & vbCrLf & _
                "CAST           - cast a spell" & vbCrLf & _
                "MAP            - map command, see also: LIGHT TORCH (or) CAST LIGHTSPELL" & vbCrLf & _
                "SCAN           - SCAN # [PLAY/MOBS] See also: help scan" & vbCrLf & _
                "FLEE           - run to disengage combat" _
            , zPortID
            
            subSendMsg gblzFNGRE & _
                "AID            - use your soul to try and revive a stunned player." & vbCrLf & _
                "STUN           - stun your opponent" & vbCrLf & _
                "BS             - backstab stuns and causes light dmg vs your opponent" & vbCrLf & _
                "STEP           - step on the magically short" & vbCrLf & _
                "DISARM         - attempts to disarm your opponent" & vbCrLf & _
                "MISSILE        - to use missile weapons" & vbCrLf & _
                "LEARN          - to learn in the realm" & vbCrLf & _
                "LOOK           - look around your area" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "PATH           - look for paths left behind in the area" & vbCrLf & _
                "STEAL          - steal from a player - thieves are the best at this" & vbCrLf & _
                "COST           - to list your skill cast costs" & vbCrLf & _
                "ACTIVATE       - Activates skills marked activate. ie. AC BASIC GRIP" & vbCrLf & _
                "TRAIN          - train a creature of the realm: HELP PETS" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "POT            - uses the casino poker table calculator" & vbCrLf & _
                "VET            - to heal your pets at a Veterinarian" & vbCrLf & _
                "LOAD           - load your ammo back up at most rangers" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "ABSORBING      - Some items have the godly <>Ankh of Absorption<>." & vbCrLf & _
                "                 Place only the Ankh and the other item into your inventory" & vbCrLf & _
                "                 and then type ABSORB. You will be prompted if necessary." & vbCrLf & _
                "                 The Ankh item has the ability to absorb another similar item." & vbCrLf & _
                "                 The Ankh item will grow its strength from other items." & vbCrLf & _
                "                 The Ankh absorbing them is the Ankh that rules them all!" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "MERGING        - This will place together one card with another card." & vbCrLf & _
                "                 Both cards must be in your inventory to do this." _
            , zPortID
            subSendMsg gblzFNGRE & _
                "CRAFTING       - To craft something place the items alone in your inventory then" & vbCrLf & _
                "                 use this command. You must be standing at a transmuting device." & vbCrLf & _
                "                 Note: Explore the realm! Find the crafting transmute spots." _
            , zPortID
            
            subSendMsg "&gHigh Ranks Only:" & vbCrLf & _
                "VOTE           - Vote message will start a poll by a leader!" _
            , zPortID
            
            subSendMsg "&GSee Also: HELP &g[SLIST/LEARN TREE/TELNET/BASIC COMMANDS/SOCIALS/AREA/FORGE WEAPONS/USE PICKLOCK/USE KEYS]", zPortID
        Case "BASI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GBasic Game Commands - Game Commands:&g" & vbCrLf & _
                "LEARN          - typing this at a teacher will show you all the skills they teach" & vbCrLf & _
                "WEAR           - wear (object)    will wear items you have in your inventory" & vbCrLf & _
                "REMOVE         - remove (object)" & vbCrLf & _
                "GET/TAKE       - get (object)     places an object in the area into your inventory" & vbCrLf & _
                "GIVE           - give (object) (playername)  or  give (value) gold (playername)" & vbCrLf & _
                "DROP           - drop (object)    removes an object from your inventory and onto the ground" & vbCrLf & _
                "LIGHT          - LIGHT an object" & vbCrLf & "                    ie. LIGHT TORCH this is so you can use your MAP command" & vbCrLf & _
                "PEEK           - peek into other rooms without moving from your area" & vbCrLf & _
                "AFFECT         - see what skills and spells are on you" & vbCrLf & _
                "MERGE          - will merge poker cards together" & vbCrLf & _
                "SAC            - to sacrifice junk items in the room" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "U (up), D (down) and N,S,E,W and NE,NW,SE,SW" & vbCrLf & _
                "               - game movement for your player" & vbCrLf & _
                "WHERE          - shows you everyone in your general area" & vbCrLf & _
                "AREAS          - lists the most popular areas of the system." & vbCrLf & _
                "AREAS PLACE    - will help direct you toward an area." & vbCrLf & _
                "SCAN           - looks around the area for mobs or players" & vbCrLf & _
                "MAP            - shows you where you are in the realm" & vbCrLf & _
                "                 without having to map. You are the green spot at the centre." _
            , zPortID
            subSendMsg gblzFNGRE & _
                "EMOTE          - EMOTE embraces you! (or try) EMOTE A mudball hits * in the face!" & vbCrLf & _
                "PEMOTE         - make your pets emote for roleplay" & vbCrLf & _
                "WHOIS          - Will read someones title and desc, you can use the LOOK ocmmand as well" & vbCrLf & _
                "TITLE          - this will set your title in WHO" & vbCrLf & _
                "DESC           - this will descript your character when you look at yourself" & vbCrLf & _
                "GUESS          - you can play guess the word game, immortals can set up the game" _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[USE/AREA/SLIST/LEARN TREE/SOCIALS/TELNET/ADVANCED COMMANDS/AREA/FORGE WEAPONS/USE PICKLOCK/USE KEYS]", zPortID
        Case "WHOI", "WHO", "FING"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~WhoIs~&g" & vbCrLf & _
                "WHO            - This will list everyone online" & vbCrLf & _
                "WHOIS          - Will read someones title and desc," & vbCrLf & "                  you can use the LOOK command as well." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[ADVANCED COMMANDS/BASIC COMMANDS/TITLE/DESC]", zPortID
        Case "BOUN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~BOUNTY QUESTING~" & vbCrLf & "&g" & _
                "BOUNTY         - Type this to list TOP 20 easy bounties and 10 hardest ones." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE/MORE]", zPortID
        Case "MERG", "POKE", "CARD"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MERGE CARDS and POKER CARDS~" & vbCrLf & _
                gblzFNGRE & "MERGE (keepcard) (mergingcard)" & vbCrLf & "NOTE: You will keep the name of the keep card" & vbCrLf & "ALSO: POT      - in poker rooms to calculate your bets." & vbCrLf & "      DECK     - Draws your own card/poker games.", zPortID
            subSendMsg "&GSee Also: HELP &g[ABSORBS/TRANSMUTING/ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE]", zPortID
        Case "CRAF", "TRAN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~CRAFTING SYSTEM~" & vbCrLf & "&g" & _
                "CRAFTING       - To craft something place the items alone in your inventory then" & vbCrLf & _
                "                 use this command. You must be standing at a transmuting device." & vbCrLf & _
                "                 Note: Crafting is difficult to do unless you have explored the realm." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[ABSORBS/MERGE CARDS/ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE]", zPortID
        Case "ABSO"
            bHelpSystemOkay = True
            subSendMsg gblzFNGRE & _
                "ABSORBING      - Some items have the godly <>Ankh of Absorption<>." & vbCrLf & _
                "                 Note: To use this command have only the two items you want to" & vbCrLf & _
                "                       put together in your inventory." _
            , zPortID
            subSendMsg "&GSee Also: HELP &g[MERGE CARDS/TRANSMUTING/ADVANCED COMMANDS/BASIC COMMANDS/COLOUR/SLIST/USE/FORGE]", zPortID
        Case "EVOL", "MUD", "STOR", "MORE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~GAME EVOLUTION~" & vbCrLf & "&g" & _
                "spells -> skills -> swords -> guns + grenades -> energy weapons -> warp drive" & vbCrLf & _
                "Basically this MUD shows you an evolution of technology and where the" & vbCrLf & _
                "human race will be sometime into the future." & vbCrLf & _
                "The game is about 80% swords and spells or normal" & vbCrLf & "Multiuser Dungeon and 20% high technology." & vbCrLf & _
                "Guns and Modern weapons usually just weaken and never instant death mobs." & vbCrLf & _
                "Which means with all your technology that you will find you will" & vbCrLf & "always have to SLAY your opponent." & vbCrLf & _
                "A sort of mortal blow which can Annihilate or Assassinate your opponent." & vbCrLf & _
                "Player vs Player is an arena battle everywhere." & vbCrLf & _
                "You never corpse your items either when you die from lack of hit points." & vbCrLf & _
                "We are a totally original code base as well so be a proud player!" & vbCrLf & _
                "Many player wish lists have been covered." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[QUEST/AREA/LEARN/MOB/TELNET/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
            subSendMsg vbCrLf & "&G~AREA INFORMATION~" & vbCrLf & _
                gblzFNGRE & "The realm has eleven different area types:" & vbCrLf & _
                "Normal areas - have day and night area descriptions, some words may be highlighted." & vbCrLf & _
                "Fly only areas - requires fly potions or natural pixie fly or the fly spells" & vbCrLf & _
                "Height restricted areas - requires shrink potions which are used for these areas" & vbCrLf & _
                "Offensive and/or defensive spell restricted areas" & vbCrLf & _
                "Water areas - aquabreath is required or if your hit points dont fall below zero while slowly drowning" & vbCrLf & _
                "Pass or Object Areas - objects are sometimes required to cross a guarded area." & vbCrLf & _
                "Trap Areas - when you enter these areas you may be trapped and might take damage (unless you dodge) until the trap resets." & vbCrLf & _
                "Instant Death Areas - there is only a few of these and you dont loose your equipment to them." & vbCrLf & _
                "Oxygen required Areas - there are potions for this in the realm." & vbCrLf & _
                "Gravity/gas/fire/radiation areas - there are item pieces you can put together for these areas." & vbCrLf & _
                "Forge areas - this is where you will make your own weapons." _
            , zPortID
            subSendMsg vbCrLf & "              &G~&YOne Mans Magic is another Mans Technology&G~", zPortID
        Case "USE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&gGame Commands - Use:&g" & vbCrLf & _
                "PICK        - USE PICK [N S E W NE NW SE SW U D]  - thieves do this best" & vbCrLf & _
                "KEY         - USE KEY [N S E W NE NW SE SW U D]   - to be performed on a door" & vbCrLf & _
                "LEVER/KNOB  - USE LEVER (lever name)              - for a room with a lever or knob" & vbCrLf & _
                "COMBO       - USE COMBO (word/number)             - for combination locks" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[AREA/BASIC COMMANDS/ADVANCED COMMANDS/LEARN TREE/SLIST]", zPortID
        Case "AREA", "ROOM"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~AREA SWITCH COMMANDS~" & vbCrLf & "&g" & _
                "ENTER (object)      EXIT (object)       CLIMB (object)      FIX (object)" & vbCrLf & _
                "MOVE (object)       PRESS (object)      PULL (object)       PUSH (object)" & vbCrLf & _
                "SPIN (object)       SPEAK (word)        SPREAD (object)     SWING (object)" & vbCrLf & _
                "TOUCH (object)      TAP (object)        TURN (object)       TUG (object)" & vbCrLf & _
                "TWIST (object)      SHOVE (object)      SLIDE (object)" & vbCrLf & _
                "SEARCH (area) (floor) (ceiling) (wall)" & vbCrLf & vbCrLf & _
                "(object)       - being any one word from the full object name or any descriptions" _
            , zPortID
            subSendMsg vbCrLf & "&G~AREA COMMANDS~" & vbCrLf & "&g" & _
                "AREAS          - lists the most popular areas of the system." & vbCrLf & _
                "AREAS PLACE    - will help direct you toward an area." _
            , zPortID
            subSendMsg "&GHELP &g[USE/MORE/ADVANCED/BASIC/BANK/COMMANDS/DOOR/FORGE]", zPortID
            If (lImmortalLevel > 0) Then subSendMsg "&GHELP &gLESSAR  &aor  &GHELP &gIMMORTAL", zPortID
        Case "MAGI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GMobs and Magic Find:" & vbCrLf & _
                gblzFNGRE & "Mobs may or may not have equipment you can kill them for." & vbCrLf & _
                gblzFNGRE & "To see if they have any equipment you have to look at them." & vbCrLf & _
                gblzFNGRE & "If a mob does have an item you will see the chance that" & vbCrLf & _
                gblzFNGRE & "the item will populate the corpse in a 1 in ODDS chance." & vbCrLf & _
                gblzFNGRE & "Magic find reduces the ODDS giving you a better chance for the item to" & vbCrLf & _
                gblzFNGRE & "populate into the corpse." & vbCrLf & _
                gblzFNGRE & "Magic find also comes from your luck stat and some equipment" & vbCrLf & _
                gblzFNGRE & "in the realm has natural magic find on it." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[MOB/QUEST/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
            subSendMsg vbCrLf & "&GMagic Words:" & vbCrLf & _
                gblzFNGRE & "Magic words are exactly five characters long. To use them type SAY <word>" & vbCrLf & _
                gblzFNGRE & "They help you travel our large realm faster." & vbCrLf & _
                gblzFNGRE & "You can find these in descriptions or maybe when looking" & vbCrLf & _
                gblzFNGRE & "at objects or mobs of the realm." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[MORE/MOB/QUEST/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
        Case "BANK", "MOBS", "MOB", "TALK", "SPEL"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GMob Commands:" & vbCrLf & _
                gblzFNGRE & "TALK (mob name) (keyword)" & vbCrLf & _
                "                          - tells the mob the keyword," & vbCrLf & _
                "                          - there are no more than three keywords per quest mob" & vbCrLf & _
                "                          - EXAMPLE: TALK MAXIMUS FURRY and TALK MAXIMUS CORPSE" & vbCrLf & _
                "                          - keywords come from what mobs tell you" & vbCrLf & _
                "                          - or you can get keywords from their speech" & vbCrLf & _
                "GIVE (object) (mob name)  - will give a quest object to that mob" & vbCrLf & _
                "REPAIR (armourer name)    - any items you have equipped will be fixed at a cost" & vbCrLf & _
                "LIST                      - to see what a mob merchant sells" & vbCrLf & _
                "SELL (object name)        - You can sell most anything for money at merchants" & vbCrLf & _
                "BUY (object name)         - You can buy anything for money at a merchant" & vbCrLf & _
                "BANK LIST                 - to see your amount at this bank" & vbCrLf & _
                "BANK DEPO (gold amount)" & vbCrLf & _
                "BANK WITH (gold amount)" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CHANNELS/PETS/LEARN/TRAIN/AREA/QUEST/COMMANDS/MAGIC FIND]" _
            , zPortID
            subSendMsg vbCrLf & "&G~CHANNELS~" & vbCrLf & "&gChannels are used to communicate with the other players." & vbCrLf & "HELP CHANNELS" & vbCrLf & "HELP RAMBLE" & vbCrLf & "Type RAMBLE HI EVERYONE for example!", zPortID
            If (lImmortalLevel > 2) Then
                subSendMsg "&w" & _
                    "MC          - immo mc mobname, short desc - to create a mobile, then:" & vbCrLf & _
                    "MEDIT       - locks the Mob Edit ID Number to the mob - seen under SCORE" & vbCrLf & _
                    "MID         - Mob Identification - use MEDIT to set the value before using MID" & vbCrLf & _
                    "MFORGE      - will forge skills and spells to a mobile" & vbCrLf & _
                    gblzFBGRE & "See Also: HELP &g[LESSAR/IMMORTAL/RC/OC/DC/MC]" _
                , zPortID
                subMagicalMobSpells zPortID, 1
            End If
        Case "QUES"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&W~Quest Commands~" & vbCrLf & "&a" & _
                "LISTENING    - Sometimes you will hear monsters talking about stuff." & vbCrLf & _
                "TALKING      - TALK SYDIRA DIAMOND, this will ask sydira about a diamond." & vbCrLf & _
                "               keywords can be found by listening all over the realm and" & vbCrLf & _
                "               piecing information together." & vbCrLf & _
                "IMMORTALS    - give quests for 'crowns of glory' where you have to find the object" & vbCrLf & "               the quest will involve a roleplay and story line." & vbCrLf & _
                "GIVING MONSTERS OBJECTS - this can be anything from a corpse to a rare item." & vbCrLf & _
                "                          GIVE MONKEY BANANA - would give the banana to the monkey." & vbCrLf & _
                "CANCEL       - this will cancel an Oracle (Quest Master) assigned quest" _
            , zPortID
            
            subSendMsg "&a" & _
                "QUEST MASTER - gives quests to help increase your" & vbCrLf & "               crowns of glory, hit points, essence, mana, or soul." & vbCrLf & _
                "               It is recommended to be level 15 before you start so you know" & vbCrLf & "               where he is sending you and " & vbCrLf & _
                "               so you have the move points to quest there." & vbCrLf & _
                "               It costs one learn/practice point to receive a quest, a small gamble." & vbCrLf & _
                "GUIDE MASTER - the system has the ability to make quests automatically" & vbCrLf & "               from these quests you can attain crowns of glory, bonus xp," & vbCrLf & "               and gold or all three at once." & vbCrLf & _
                "BOUNTIES     - at anytime you can type BOUNTY to quest for pure gold." _
            , zPortID
            subSendMsg "&a" & _
                "QUEST GROUPS - You will find herds or groups of creatures in the realm" & vbCrLf & "               which you must sucessfully dispose of to complete the quest." & vbCrLf & _
                "NOTE: All the above quests can all interact with each other to make your questing a journey." _
            , zPortID
            
            If (lImmortalLevel >= 1) Then
                subSendMsg "&W~Make Mob Quests, Immortals Only~" & vbCrLf & "&a" & _
                    "MQUE will make a quest for you - you need two items and a mob to do this" _
                , zPortID
            End If
            
            If (lImmortalLevel > 9) Then
                subSendMsg "&W~IMMORTAL QUEST COMMANDS~" & "&a" & vbCrLf & _
                    "HOSTILE     - creates a spaceship quest to phaser hostiles" & vbCrLf & _
                    "SPACE       - creates a spaceship quest to phaser mobships in space" & vbCrLf & _
                    "OBJECT      - drops a glory item into the realm" & vbCrLf & _
                    "MOB         - drops a glory creature into the realm" & vbCrLf & _
                    gblzFBGRE & "HELP &g[DC/MC/RC/OC/IMMORTAL]" _
                , zPortID
                subSendMsg "&W~QUEST IDEAS FOR IMMORTALS~" & "&a" & vbCrLf & _
                    "ROLEPLAY    - for glory take these 3 words: " & vbCrLf & _
                    "              Ogre Vampire and Sword and make a mini-story." & vbCrLf & _
                    "BACKWARDS   - Write the playername backwards - or a mobname" & vbCrLf & _
                    "DESCRIPTION - The player with the best player description (DESC command) wins something." & vbCrLf & _
                    "MAKE A WORD - Put up lots of letters and let the person that makes" & vbCrLf & _
                    "              the longest word get an award, say of crowns, or an item." _
                , zPortID
            End If
            subSendMsg "&GSee Also: HELP &g[FORGE/PLAY/MOB/TALK/BASIC COMMANDS/ADVANCED COMMANDS/SLIST]", zPortID
        Case "RACE", "CLAS", "CHAR"
            bHelpSystemOkay = True
            subTranslateChartRaces zPortID
            subTranslateChartClasses zPortID
        Case "CHAN", "IGNO", "SAY", "TELL", "GLOB", "SILE", "QUIE"
            bHelpSystemOkay = True
            subSendMsg "&G~CHANNELS~" & vbCrLf & "&g" & _
                "CHAN [+/-]AUCTION" & vbCrLf & _
                "CHAN [+/-]INFOLINE" & vbCrLf & _
                "CHAN [+/-]TELL" & vbCrLf & _
                "CHAN [+/-]PRAY" & vbCrLf & _
                "CHAN [+/-]NEWBIE" & vbCrLf & _
                "CHAN [+/-]OOC Out-Of-Character for Real life topics" & vbCrLf & _
                "CHAN [+/-]RAMBLE" & vbCrLf & _
                "CHAN [+/-]GOSSIP In-Character to Roleplay" & vbCrLf & _
                "CHAN [+/-]QUOTE" & vbCrLf & _
                "CHAN [+/-]QUEST" & vbCrLf & _
                "CHAN [+/-]MUSIC" & vbCrLf & _
                "CHAN [+/-]IMC      - intermud chat" & vbCrLf & _
                "CHAN [+/-]CLAN/MIC - does both clan channels" & vbCrLf & _
                "CHAN [+/-]CLSS     - class channel" & vbCrLf & _
                "CHAN [+/-]RACE     - race channel" & vbCrLf & _
                "CHAN [+/-]HERO     - level 60" & vbCrLf & _
                "CHAN [+/-]LORD     - level 100" & vbCrLf & _
                "CHAN [+/-]ALL      - silences all channels" & vbCrLf & _
                "Example: CHAN -TELL (or) CHAN +MUSIC" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CLAN/MICROPHONE]" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "EMOTE           - Try: emote flys away! (or) emote A pole falls on *!! ACK!" & vbCrLf & _
                "SAY             - works in the same room." & vbCrLf & _
                "YELL            - communicates with those on the WHERE list" & vbCrLf & _
                "MIC             - HELP MIC, creates your own communication friends list" _
            , zPortID
            subSendMsg "&M~Ignore Command~" & vbCrLf & gblzFNMAG & _
                "IGNORE (player) - this will toggle the target player from bothering you." & vbCrLf & _
                "IGNORE LIST     - this will show you who you have placed on your ignore list." & vbCrLf & _
                "NOTE: You cannot ignore the SAY channel since you can walk away." & vbCrLf & _
                "      IGNORE will also prevent an intolerant player from murdering you." _
            , zPortID
            If (lClanMemberLevel > 16) Then
                subSendMsg "&W~Special Channels~" & vbCrLf & "&w" & _
                    "ETERNAL         - A channel for level 175 players, and cannot be silenced." & vbCrLf & _
                    "LEADER          - Leadership channel, and cannot be silenced." _
                , zPortID
            Else
                subSendMsg "&W~Special Channels~" & vbCrLf & "&w" & _
                    "ETERNAL         - A channel for level 175 players, and cannot be silenced." _
                , zPortID
            End If
            
            If (lImmortalLevel >= 1) Then
                subSendMsg "&W~Immortal Special Channels~" & vbCrLf & "&a" & _
                    "GTC/ITC/ITG     - Global Echo channel or the immortal tease channel global" & vbCrLf & _
                    "ITR             - Room Echo channel or the immortal tease channel room" & vbCrLf & _
                    "HAIL is a channel that cannot be blocked - and only immortals may use it!" _
                , zPortID
            End If
            subPrintChannelStatusAll zPortID
        Case "MIC", "MICR", "FRIE", "ADD", "ERAS", "MUTE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Microphone:&g" & vbCrLf & _
                "MIC        - MIC MSG, to broadcast to all of your microphone friends." & vbCrLf & _
                "MUTE       - MUTE PLAYERNAME, See Also: IGNORE PLAYERNAME and IGNORE LIST" & vbCrLf & "             they will be reminded you have them on mute" & vbCrLf & _
                "UNMUTE     - UNMUTE PLAYERNAME" & vbCrLf & _
                "ERASE      - ERASE PLAYERNAME, will remove someone from your microphone list" & vbCrLf & _
                "ADD        - ADD PLAYERNAME, will add someone to your list" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CHANNEL/IGNORE PLAYER]" _
            , zPortID
        Case "RANK", "INDU"
            bHelpSystemOkay = True
            If lImmortalLevel >= 1 Then subSendMsg "&GIMMO COMPLETE LIST     IMMO SET <COMPLETEBANMAX>    IMMO SPAM (toggle)", zPortID
            subSendMsg vbCrLf & "&GClan Commands - INDUCT" & vbCrLf & "&g" & _
                "INDUCT     - *Officers* are able to induct WILLING players into their clan." & vbCrLf & _
                "             If you are an officer you MUST ASK a player if they" & vbCrLf & _
                "             WISH to join your clan. Abuse of your INDUCTION command results" & vbCrLf & _
                "             in the punishment of being banned to the powerless OUTCASTED clan." _
            , zPortID
            
            subSendMsg vbCrLf & "&GClan Induction:" & vbCrLf & _
                gblzFNGRE & "Type INDUCT alone for the rank levels and command syntax." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]" & vbCrLf & vbCrLf, zPortID
            
            If lImmortalLevel >= 1 Then subSendMsg "&GIMMO COMPLETE LIST     IMMO SET <COMPLETEBANMAX>    IMMO SPAM (toggle)", zPortID
            If (lImmortalLevel >= 4) Then
                subSendMsg vbCrLf & "&GImmortal Induction:" & vbCrLf & _
                    gblzFNGRE & "IMMO RANK PLAYERNAME IMMORTAL 0     - to unrank an immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 100   - to rank an immortal as the 1st immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 99    - to rank an immortal as the 2nd immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 98    - to rank an immortal as the 3rd immortal" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 2     - CLOG - IMMO HEAVEN - IMMO ARENA - IP SPY" & vbCrLf & _
                                "IMMO RANK PLAYERNAME IMMORTAL 1     - CLOG - WHOIS/IP SPY" & vbCrLf & _
                                "IMMO RANK PLAYERNAME BAN            - to uninduct a player from a clan" & vbCrLf & _
                                "IMMO RANK PLAYERNAME CLANNAME RANK  - to induct a player into a clan" & vbCrLf & _
                    gblzFBGRE & "See Also: HELP &g[CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
            End If
        Case "CLAN", "BOOK"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GPersonal Clan Commands - MIC" & vbCrLf & "&g" & _
                "CLAN OF FRIENDS" & vbCrLf & _
                "ADD/BOOK   - to add a person to your friends list" & vbCrLf & _
                "ERASE      - to remove a person from friends list" & vbCrLf & _
                "MUTE       - MUTE PLAYERNAME, See Also: IGNORE PLAYERNAME and IGNORE LIST" & vbCrLf & "             they will be reminded you have them on mute" & vbCrLf & _
                "UNMUTE     - to unmute a friend member" & vbCrLf & _
                "MIC        - speak or shows everyone in your friend list" & vbCrLf & _
                "CLAN       - you must be in a clan to use this channel" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CHANNEL/RANK]" _
            , zPortID
            subSendMsg "&GClan Commands - Clan Reports" & vbCrLf & _
                gblzFNGRE & "CLAN FLAG     - shows you who has all the flags in the realm" & vbCrLf & _
                "RETURN        - will return any clan flags that you carry" & vbCrLf & _
                "CLAN NAMES    - to see a list of clan names" & vbCrLf & _
                "CLAN RANKS    - to see a list of your clan leaders" & vbCrLf & _
                "CLAN LEVEL    - to see a list of your clan high levels" & vbCrLf & _
                "CLAN LEAVE THIS GUILD - to leave your current clan" & vbCrLf & _
                "CLAN EXPIRES  - players that do not login within " & cstlRankLost & " days" & vbCrLf & "                 will loose their clan rank" _
            , zPortID
        Case "COLO", "PROM", "TOGG"
            bHelpSystemOkay = True
            subSendMsg "&G~REQUIRED WEEKLY COLONISTS~&A" & vbCrLf & "Planets: " & cstlRequiredTotalPlanets & " Colonists: " & cstlRequiredTotalColonists, zPortID
            subSendMsg vbCrLf & "&G~Listed Game Colours~" & vbCrLf & _
                gblzFNGRE & "Colours cannot be used in all areas of the system." & vbCrLf & _
                gblzFNGRE & "Normal: &r& r &w& w " & gblzFNMAG & "& m " & gblzFNBLU & "& b &y& y " & "&c& c &g& g" & vbCrLf & _
                gblzFNGRE & "  Bold: " & "&R& R &W& W " & gblzFBMAG & "& M &B& B &Y& Y &C& C &G& G" & vbCrLf & _
                gblzFNGRE & "  Gray: &a& a or & A      (remove the extra space after the ampersand)" _
            , zPortID
            subSendMsg vbCrLf & "&G~Toggled Game Colours~" & vbCrLf & _
                gblzFNGRE & "COLOUR PROMPT 0 1 2" & vbCrLf & _
                "COLOUR AREA 0 1 2" & vbCrLf & _
                "0 bright colours" & vbCrLf & _
                "1 dim colours" & vbCrLf & _
                "2 mostly one solid colour" & vbCrLf & _
                gblzFBGRE & "See Also: &gHELP &g[COLOR/TITLE/DESC]" _
            , zPortID
        Case "BODY"
            bHelpSystemOkay = True
            If (lImmortalLevel >= 4) Then 'headset trisker
                subSendMsg vbCrLf & "&w" & "~BODY LOCATIONS~" & "&a" & vbCrLf & _
                    "0       - mortals cannot pick this up only high level immortals can" & vbCrLf & _
                    "8       - headset" & vbCrLf & _
                    "9       - forehead, ie. head bands, reef of throns" & vbCrLf & _
                    "10      - head" & vbCrLf & _
                    "11      - collar - skin of neck - choke chains for example - or gills" & vbCrLf & _
                    "12      - around neck, ie. scarfs" & vbCrLf & _
                    "13      - talismans" & vbCrLf & _
                    "14      - pendants" & vbCrLf & _
                    "15      - amulets" & vbCrLf & _
                    "16      - over mouth" & vbCrLf & _
                    "17      - inner mouth" & vbCrLf & _
                    "18      - face mask" & vbCrLf & _
                    "19      - eyes" & vbCrLf & _
                    "20LR    - hand held object, ie. weapons, bags, keys" & vbCrLf & _
                    "21      - buckler, ie. this is a little shield that goes over one forearm" & vbCrLf & _
                    "22      - pair of gloves or gauntlets" & vbCrLf & _
                    "30LR    - any finger, ie. ring" & vbCrLf & _
                    "31LR    - thumbs, ie. thumb ring" & vbCrLf & _
                    "32      - tongue stud" & vbCrLf & _
                    "33      - nose ring" _
                , zPortID
                subSendMsg _
                    "40LR    - wrist item, ie. bracelets" & vbCrLf & _
                    "41LR    - cuff item, ie. cufflinks" & vbCrLf & _
                    "45LR    - upper arms/biceps, ie. bracers" & vbCrLf & _
                    "50      - forearms, ie. chainlink arms" & vbCrLf & _
                    "60      - leggings" & vbCrLf & _
                    "61LR    - ankles" & vbCrLf & _
                    "62      - knee pads" & vbCrLf & _
                    "63      - elbow pads" _
                , zPortID
                subSendMsg _
                    "70      - torso, ie. breastplate armour" & vbCrLf & _
                    "71      - broach" & vbCrLf & _
                    "72      - centre chest insignia, ie. Insignia of the Ancients" & vbCrLf & _
                    "73      - over body, ie. robes, cloaks" & vbCrLf & _
                    "80      - back middle, ie. backpacks" & vbCrLf & _
                    "81      - back upper, ie. wings" & vbCrLf & _
                    "82      - hips, ie. loin cloth" & vbCrLf & _
                    "83      - waist, ie. belt" & vbCrLf & _
                    "84LR    - over a shoulder, ie. shoulder pouch" & vbCrLf & _
                    "85      - reserved - corpse carrying location only!" & vbCrLf & _
                    "90      - feet" & vbCrLf & _
                    "100LR   - earrings" & vbCrLf & _
                    "110     - reserved: light source" & vbCrLf & _
                    "120     - reserved: gold stash, pickup from the ground - Gold must be set." & vbCrLf & _
                    "121     - reserved: experience bonus, pickup from the ground - BonusXP must be set" _
                , zPortID
            End If
        Case "SKIL"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&gGame Commands - Remove and Wear Skills:" & vbCrLf & _
                "This is a list of all the quest skills players can quest for." & vbCrLf & _
                "Assassins, Monks, and Fighter classes are the best at these skills." & vbCrLf & _
                "Mages are deadly with spells and but weaker with skill damage." & vbCrLf & _
                "The rest of the classes can be good at one or more of these skills." & vbCrLf & _
                "Berserk" & vbCrLf & _
                "Double Punch" & vbCrLf & _
                "Drop Kick" & vbCrLf & _
                "Meditate - NOTE: rings of regeneration are available too" & vbCrLf & _
                "Head Butt" & vbCrLf & _
                "Elbow" & vbCrLf & _
                "Knee" & vbCrLf & _
                "Claw Hand" & vbCrLf & _
                "Knife Hand" & vbCrLf & _
                "Dragon Uppercut" & vbCrLf & _
                "Power Kick" & vbCrLf & _
                "Hurricane Kick" & vbCrLf & _
                "Type RELOAD to load all of your skills this prevents remove and wear spam" _
            , zPortID
            
            subSendMsg vbCrLf & "&gGame Commands - Permanent Skills:" & vbCrLf & _
                "Lock Pick               - this improves your chance to pick locks on doors" & vbCrLf & _
                "Grip                    - items can come with grip to help against being disarmed" & vbCrLf & _
                "Number of Attacks       - items and weapons give you more attacks a round" & vbCrLf & _
                "Slay Chance             - instant death for mobs or players" & vbCrLf & _
                "Fire Elemental Damage   - instant damage to your opponent" & vbCrLf & _
                "Cold Elemental Damage   - instant damage to your opponent" & vbCrLf & _
                "Shock Elemental Damage  - instant damage to your opponent" & vbCrLf & _
                "Regeneration Level      - when you sleep this helps your hitpoints and soul gain faster" & vbCrLf & _
                "Backstab Level          - this is by class" & vbCrLf & _
                "Missile Range Level     - this is by class" & vbCrLf & _
                "Destiny Weapons         - these newbie weapons come with dual wield" & vbCrLf & _
                "Magic Find              - increases your chances to find equipment" _
            , zPortID
            
            subSendMsg "&G" & _
                gblzFNGRE & _
                "Learn                   - If you are at a teacher this will list their skills" & vbCrLf & _
                "                          they can teach you" & vbCrLf & _
                "Learn (skill name)      - Will allow you to learn a skill" & vbCrLf & _
                "Learn Tree              - Will show your complete skill tree" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[TRAIN/STATS]", zPortID
        Case "RXYZ"
            bHelpSystemOkay = True
            If (lImmortalLevel >= 4) Then
                subSendMsg vbCrLf & "&gGame Commands - Teleport Pod X Y Z - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "Syntax: RXYZ X Y Z" & vbCrLf & _
                    gblzFNGRE & "ROOM: To make a room teleport you when you move into it modify the RXYZ of the area." & vbCrLf & "Use the command RTDT to disable the teleporting feature." & vbCrLf & _
                    gblzFNGRE & "OBJECTS: To make an object teleport you modify the RXYZ of the area." & vbCrLf & "Use the command RTDT to disable the teleporting feature." & vbCrLf & _
                    gblzFBGRE & "See Also: HELP &g[RTDT, ROOM, RBC]" _
                , zPortID
            End If
        Case "RR"
            bHelpSystemOkay = True
            subHelpSystemRR lX, lY, lZ, lImmortalLevel, lPlayerID, zPortID
        Case "RBC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&gGame Commands - Room Block Construct - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "Syntax: RBC COMMAND|DIRECTION|OBJECT|EMOTE PERSONAL ACTIVATE|EMOTE PERSONAL DEACTIVATE|EMOTE 3rd PERSON ACTIVATE|EMOTE 3rd PERSON DEACTIVATE|CLASS CONSTRAINT|LEVEL CONSTRAINT" & vbCrLf & _
                    gblzFNGRE & "To make an object teleport you modify the RXYZ of the area as normally you would." & vbCrLf & "Use the command RXYZ 0 0 0 to disable the teleporting feature." _
                , zPortID
                subSendMsg vbCrLf & "&gGame Commands - Room Block Construct Commands - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "COMMAND LIST" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "PRESS MOVE PULL PUSH SEARCH SHOVE SPIN SWING TAP TOUCH TUG TURN TWIST ENTER EXIT" & vbCrLf & vbCrLf & _
                    gblzFNGRE & "DIRECTION LIST" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "NE NW SE SW N S E W U D" & vbCrLf & vbCrLf & _
                    gblzFNGRE & "OBJECT LIST" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "STONE ROCK KEY ROPE - anything at all!" _
                , zPortID
                subSendMsg _
                    gblzFNGRE & "EMOTE ACTIVATES" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "You (emote activate) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "3rd Person: Trisker (emote activates) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "EMOTE DEACTIVATES" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "Personal: You (emote deactivate) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "3rd Person: Trisker (emote deactivates) the western key." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "CLASS CONSTRAINT" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "If left blank all classes are allowed to use the RBC command." & vbCrLf & "If a class is specified then only that class can activate the RBC command." & vbCrLf & vbCrLf & _
                    gblzFNGRE & "LEVEL CONSTRAINT" & vbCrLf & _
                    gblzFNGRE & "==================" & vbCrLf & _
                    gblzFNGRE & "If left blank all levels are allowed to use the RBC command." & vbCrLf & "If a class is specified then only that level or higher can activate the RBC command." & vbCrLf & vbCrLf & _
                    gblzFBGRE & "HELP &g[ROOM, RBCD, RXYZ]" _
                , zPortID
            End If
        Case "RBCD"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&gGame Commands - Room Block Construct Delete - Immortals Only:" & vbCrLf & _
                    gblzFNGRE & "Syntax: RBCD @RBCDELETE@   - this will only remove the RBC command, the room will not be affected." & vbCrLf & _
                    gblzFBGRE & "HELP &g[ROOM, RBC/DSTA]" _
                , zPortID
            End If
        Case "DWIN"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&G~BUILDING WINDOWS FOR DOORS~&g" & vbCrLf & _
                    "0 = no window, the door is solid" & vbCrLf & _
                    "1 = barred window" & vbCrLf & _
                    "2 = glass window" & vbCrLf & _
                    "3 = arrow hole" & vbCrLf & _
                    gblzFBGRE & "HELP &g[DOOR/RBCD/DSTA/LEVEL/IMMORTAL]" _
                , zPortID
            End If
        Case "DSTA"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&W~IMMORTAL BUILDING - SETTING DOOR STATUS~&w" & vbCrLf & _
                    "You have to be in the door, use TELE X Y Z to get in there." & vbCrLf & _
                    "OPEN:     0 = stays always open       3=open but is lockable/pickable" & vbCrLf & _
                    "          5 = bashed open            10=magic opens" & vbCrLf & _
                    "UNLOCKED: 1 = unlocked but closed" & vbCrLf & _
                    "CLOSED:   6 = closed and not lockable 7=bashed closed" & vbCrLf & _
                    "          8=Bashable                 11=magic closed" & vbCrLf & _
                    "LOCKED:   2 = locked                 12=magically locked " & vbCrLf & _
                    gblzFBGRE & "HELP &w[DOOR/DWIN/DSTA/LEVEL/IMMORTAL]" _
                , zPortID
            End If
        Case "CREA", "WEAP", "TYPE", "ABIL", "STRE", "INTE", "WISD", "DEXT", "CONS", "CHAR", "LUCK", "DODG", "PARR"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Abilities:&g" & vbCrLf & _
                "STRENGTH       - improves your hitroll and damage roll, extra damage," & vbCrLf & "                 and weight, it also helps to raise soul" & vbCrLf & _
                "INTELLIGENCE   - helps with spell casting, learning skills faster, and for your mana gains" & vbCrLf & _
                "WISDOM         - helps with spell casting, learning skills faster, and for your essence gains" & vbCrLf & _
                "DEXTERITY      - helps with stun, dodge and parry and for your move gains" & vbCrLf & _
                "                 ** Dodge, parry, and weapons block requires at least " & gblcstlDodgeParryWeaponsBlockXPMin & " xp to level up" & vbCrLf & _
                "CONSTITUTION   - helps with your move and hit point gains" & vbCrLf & _
                "CHARISMA/CHARM - helps with mobs so they dont auto attack you and for various similar features" & vbCrLf & "                 the guide master for example likes charming players" & vbCrLf & _
                "LUCK           - helps you with your magic find" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[STATS/LEARN/MOB/TELNET/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
            
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&W~BUILDING WEAPON TYPES~" & "&a" & vbCrLf & _
                    "These are all hand object weapon types:" & vbCrLf & _
                    "BLUD    = Bludgeons" & vbCrLf & _
                    "LANC    = Lance" & vbCrLf & _
                    "POLE    = Polearm" & vbCrLf & _
                    "JAVI    = Javelins" & vbCrLf & _
                    "SPEA    = Spears" & vbCrLf & _
                    "FLEX    = Flexible arms" & vbCrLf & _
                    "LBLA    = Long Blades" & vbCrLf & _
                    "SBLA    = Short Blades" & vbCrLf & _
                    "PUGI    = Pugilism" & vbCrLf & _
                    "SSTA    = Short staff" & vbCrLf & _
                    "LSTA    = Long Staff" & vbCrLf & _
                    "SAXE    = Small axe" & vbCrLf & _
                    "GAXE    = Great axe" & vbCrLf & _
                    "TALO    = Talonous" & vbCrLf & _
                    "BOW     = uses arrows   - ARRO" & vbCrLf & _
                    "XBOW    = uses bolts    - BOLT" & vbCrLf & _
                    "SLIN    = uses stones   - STON" & vbCrLf & _
                    "MGUN    = uses ammo     - CLIP" & vbCrLf & _
                    "PHAS    = uses energy   - BLAS" & vbCrLf & _
                    "NET     = Netting someone" _
                , zPortID
                'more or less MGUN PHAS BOW XBOW are all similar just tagged differently
                subSendMsg "&wIMMO WEAPONTYPES         (summary of useage)", zPortID
                subSendMsg "&GSee Also: HELP &g[OC/MC/MOB/RC/ROOM/IMMORTAL]", zPortID
            End If
        Case "STAT", "ESSE", "MANA", "SOUL", "MOVE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GGame Commands - Stats:&g" & vbCrLf & _
                "Hit points     - when this falls below zero you die, if you do die you only drop your gold" & vbCrLf & _
                "Mana           - all offensive spells, such as fireball, use this" & vbCrLf & _
                "Essence        - all defensive spells, such as shields, use this" & vbCrLf & _
                "Soul           - this is used for skills such as disarm, stun, steal, and other skills" & vbCrLf & _
                "Move           - as you move around this value will fall depending where you are " & vbCrLf & _
                "                 adventuring. Hitroll and Damage Roll (average damage) will weaken" & vbCrLf & _
                "                 when your move points fall below half. Use SCORE or X to check this." & vbCrLf & _
                "                 Those that fight barehanded will use up more move points to hit" & vbCrLf & _
                "                 than those that use weapons." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[ABILITIES/LEARN/MOB/BASIC COMMANDS/TELNET/ADVANCED COMMANDS]" _
            , zPortID
        Case "MC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg vbCrLf & "&G~BUILDING/CREATE MOBILES~&g" & vbCrLf & _
                    "MC          - creates a new mobile to be edited" & vbCrLf & _
                    "MD          - deletes a mob" & vbCrLf & _
                    "MEDIT       - Use IMMO RALL to view all the room mobile ids" & vbCrLf & _
                    "              Then MEDIT the ID#." & vbCrLf & _
                    "MID           Mobile Identification - Capital Letters represent the commands" & vbCrLf & _
                    "              WeaponType for example, mforge wt axe  or  mforge desc This is my first mob!" & vbCrLf & _
                    "MFORGE      - Use MEDIT and MID first then this command." _
                , zPortID
            End If
            
            If (lImmortalLevel > 3) Then
                subSendMsg gblzFNGRE & _
                    "MQUE       - Mobile Quest - type IMMO MQUE for the syntax" & vbCrLf & _
                    "MERG       - gives the item to a mob and marks the mob a merchant" & vbCrLf & _
                    "MCOPY      - IMMO MCOPY MOBID will copy that mob to your current location" & vbCrLf & _
                    "MGIV       - give Mobile Armour or Weapons to increase the mobile's AC and DAMAGE" & vbCrLf & _
                    "MAPA       - Mobile add path" & vbCrLf & _
                    "MDPA       - Mobile delete path" _
                , zPortID
                subSendMsg "&GSee Also: &gHELP &g[MOB/SPELLSFORMOBS/OC/RC/LESSAR IMMORTAL/HIGHER IMMORTAL/DC]", zPortID
            End If
        Case "RC", "HOUS", "DONA", "PAYP", "AREA"
            bHelpSystemOkay = True
            'bHelpSystemOkay = False 'we want to let immortals add their own DONATION search to tblSystemHelp
            subSendMsg "&GDONATIONS" & vbCrLf & "&g----------------------------------------------------" & vbCrLf & "We accept donations, and in turn we award you" & vbCrLf & "either a house, or some crowns of glory, or both." & vbCrLf & "Please visit the housing district for further details." & vbCrLf & "You can donate directly to our PAYPAL account, HELP PAYPAL.", zPortID
            subSendMsg "&GHELP &g[EMAIL/BUILD/RULES]", zPortID
            subSendMsg "&G~AREA COMMANDS~" & vbCrLf & "&g" & _
                    "AREA        - lists the popular area where titles in the system" _
            , zPortID
            If (lImmortalLevel > 90) Then
                subSendMsg "&w~BUILDING A HOUSE FOR A PLAYER FOR DONATIONS~" & vbCrLf & "&a" & _
                    "1)   When a player donates you want to type IMMO TRANS YOURPLAYERNAME MATRIX" & vbCrLf & _
                    "     You will now be in the Housing Matrix area." & vbCrLf & _
                    "     You can also travel north from the City of Ages to the City of Marble." & vbCrLf & _
                    "     OR type: TELE 100000 100000 100000 to teleport to the centre of the matrix" & vbCrLf & _
                    "2)   type LOOK" & vbCrLf & _
                    "3)   type MAP" & vbCrLf & _
                    "     LOOK and MAP will help you find an empty spot to build the house." & vbCrLf & _
                    "     Move as close as you can to this spot using N S E W NE NW SE SW U D." & vbCrLf & _
                    "4)   type LOCATION" & vbCrLf & _
                    "5)   type TELE X Y Z" & vbCrLf & _
                    "     X Y Z are coordinate numbers you use from the" & vbCrLf & _
                    "     LOCATION command, do not put in the X Y Z, See #1 above." & vbCrLf & _
                    "     If you use the EXACT same numbers from the LOCATION command" & vbCrLf & _
                    "     you will just teleport to your current location." & vbCrLf & _
                    "     You want to be able to move from that position to an empty spot to build." _
                , zPortID
                subSendMsg "&a" & _
                    "6)   type WHOIS PLAYERNAME" & vbCrLf & _
                    "     Playername is the person you are building the house for." & vbCrLf & _
                    "     Get the ID number from the WHOIS, if you see some IP numbers then just scroll back up" & vbCrLf & _
                    "7)   type IMMO RC" & vbCrLf & _
                    "     if you did #5 above correctly you will of created a room. See also: HELP [RC]" & vbCrLf & _
                    "8)   type IMMO TYPE 1 PLAYERID" & vbCrLf & _
                    "9)   Now open directions for the player to move into their house: use IMMO RB" & vbCrLf & _
                    "     See also: HELP [RC] and find the RB command for futher help." _
                , zPortID
                subSendMsg "&w~ROOM CONTROLS~" & vbCrLf & "&a" & _
                    "TYPE        - immo type will set the area PlayerTypes, 0:normal 1:house 2:starship" & vbCrLf & _
                    "              See also: HELP [RC/HOUSE/BUILD]" & vbCrLf & _
                    "MAP         - to see your map" & vbCrLf & _
                    "WHERE       - this will show the room/area's where information" & vbCrLf & _
                    "AREA        - immo area or immo rall to show the area in detail" _
                , zPortID
            End If
            
            If (lImmortalLevel > 2) Then
                subSendMsg "&G~AREA ELEMENTAL~" & vbCrLf & _
                    "SYNTAX: IMMO AE BELOWCOMMAND VALUE&g" & vbCrLf & _
                    " BELOWCOMMANDS," & vbCrLf & _
                    "      ORL  - Oxygen Required Level" & vbCrLf & _
                    "      GL   - Gravity Level" & vbCrLf & _
                    "      RAL  - Radiation Area Level" & vbCrLf & _
                    "      GAL  - Gas Area Level" & vbCrLf & _
                    "      GAD  - Gas Area Description" & vbCrLf & _
                    "      HAL  - Heat Area Level" & vbCrLf & _
                    "     VALUE is a number, the higher the number the more dmg per turn." _
                , zPortID
                subSendMsg vbCrLf & "&G~IMMORTAL AREA COMMANDS~" & vbCrLf & "&g" & _
                    "RC         - room - creation at your location" & vbCrLf & _
                    "RD         - immo rd @deletespot@" & vbCrLf & _
                    "RR         - set room rules see also, HELP RR" & vbCrLf & _
                    "RB         - room blockage (dir) +/-" & vbCrLf & _
                    "RR         - modification of room area rules" & vbCrLf & _
                    "RH         - hides doors or room exits, ie. RH (dir) +/-" & vbCrLf & _
                    "AMOV       - set area move points to your area location" & vbCrLf & _
                    "QUEST      - immo quest sets the rooms ability to accept quests or not" & vbCrLf & _
                    "UNDERWATER - immo under 10 will set the room with 10cm of water" _
                , zPortID
                subSendMsg gblzFNGRE & _
                    "FLY        - immo fly will toggle the area as a fly zone or not" & vbCrLf & _
                    "MAPT       - immo mapt will toggle the MAP visibility" & vbCrLf & _
                    "RDD        - room - set day desc. this works if it is day or not" & vbCrLf & _
                    "RND        - room - set night desc" & vbCrLf & _
                    "WDES/WAPP  - apply an area where description title where you stand" & vbCrLf & _
                    "WADD       - add a new area where title to the system" & vbCrLf & _
                    "WDEL       - delete full area where title" _
                , zPortID
                subSendMsg vbCrLf & "&g" & _
                    "RBC        - room blockage construct - ie. TOUCH STAFF" & vbCrLf & _
                    "RALL       - immo area or immo rall, reveals full room information," & vbCrLf & _
                    "WHERE      - immo where, reveals full room where information," _
                , zPortID
                subSendMsg "&GSee Also: &g[FORGE,OC,MC]", zPortID
            End If
            
            If (lImmortalLevel > 3) Then
                subSendMsg gblzFNGRE & _
                    "RXYZ       - set room teleportation destination" & vbCrLf & _
                    "RTDT       - set room teleportation destination toggle on/off" & vbCrLf & _
                    "RSCK       - immo RSCK will spell check the area the immortal is in" & vbCrLf & _
                    "TYPE       - immo type will set the area PlayerTypes, 0:normal 1:house 2:starship" _
                , zPortID
                subSendMsg vbCrLf & "&G~ROOM TRANSIT~&g" & vbCrLf & _
                    "TAPA       - add area transit path - you must start on an area" & vbCrLf & _
                    "TDPA       - delete area transit path" & vbCrLf & _
                    "TDES       - transit destination" & vbCrLf & _
                    "CLAN       - set the area clan id" & vbCrLf & _
                    "RRNK       - immo rank 0-10 - there is actually no limited number" _
                , zPortID
                subSendMsg "&GSee Also: &gHELP &g[RC/RR/OC/MC/IMMORTAL]", zPortID
            End If
        Case "DOOR", "DC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 2) Then
                subSendMsg "&G~DOOR COMMANDS~&g" & vbCrLf & _
                    "DC         - door create, when a door is created it only operates" & vbCrLf & _
                    "             N S E W Up or Down not angles such as NE NW SE SW" & vbCrLf & _
                    "DWIN       - create a window for this door you are in, See Also: HELP DWIN" & vbCrLf & _
                    "DSTA       - set door status, open, locked, unlock..." & vbCrLf & "0 = Open, 1 = Unlocked but closed, 2 = Locked, 3=open but is lock/pickable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and not lockable, 7 = Bashed closed, 8=Bashable 10=magic open 11=magic closed 12=magically locked" & vbCrLf & "&GHELP DSTA" & vbCrLf & _
                    "DD         - door delete" & vbCrLf & _
                    gblzFBGRE & "HELP &g[DWIN, DSTA, RBC]" _
                , zPortID
            End If
            subSendMsg vbCrLf & "&GGame Command - Door Examples:&g" & vbCrLf & _
                    "DOOR       - USE KEY (dir)" & vbCrLf & _
                    "DOOR       - OPEN (dir)" & vbCrLf & _
                    "DOOR       - CLOSE (dir)" & vbCrLf & _
                    "DOOR       - LOOK (dir)" & vbCrLf & _
                    gblzFBGRE & "HELP &g[AREA/BASIC COMMANDS/ADVANCED COMMANDS]" _
            , zPortID
        Case "OBJE", "ITEM", "OC"
            bHelpSystemOkay = True
            If (lImmortalLevel > 3) Then
                subSendMsg vbCrLf & "&G~OBJECT EDIT COMMANDS~&g" & vbCrLf & _
                    "* OC       - object create" & vbCrLf & _
                    "* OAVG     - set weapon average damage, if this is zero then this is " & vbCrLf & _
                    "             NOT a damage inflicting object" & vbCrLf & _
                    "* OTYP     - object weapon type             &GSee Also: HELP WEAPONTYPES&g" & vbCrLf & _
                    "* OLOC     - set the object's body location &GSee Also: HELP BODY&g" & vbCrLf & _
                    "             ie. FORGE LOCA 10  << immortals only - players see an error msg" & vbCrLf & _
                    "* OWEI     - set the object's weight in grams, 2.2lbs = 1kg (kilogram). " & vbCrLf & _
                    "* ODES     - set the object's description" & vbCrLf & _
                    "* OAC      - when you create armour of anykind don't forget this command" & vbCrLf & "for example:" & vbCrLf & _
                    "             200AC is a great breast plate armour" & vbCrLf & _
                    "             20AC on plate leggings is reasonable too " & vbCrLf & _
                    "             put minus DEX on plate armour pieces please" & vbCrLf & _
                    "             ie. Seagull Feather = 1 gram, Swords are 15kgs, Clubs are 1kg" & vbCrLf & _
                    "OD         - delete object and" & vbCrLf & _
                    "             if you have problems deleting do this: first drop the" & vbCrLf & _
                    "             object somewhere safe LOOK at the area and" & vbCrLf & "note the object's EXACT and FULL name." _
                , zPortID
                subSendMsg gblzFNGRE & _
                    "PLANT       - immo plant objectid containerobjectid" & vbCrLf & "               will bolt the containerobject to the ground and" & vbCrLf & "               in 20 minutes respawn the item inside of it." & vbCrLf & _
                    "DROP        - this will drop ANY item off a mobile: MERG, MQUE" & vbCrLf & _
                    "OGL         - shows the xyz location of all glory items - so you can't loose them" & vbCrLf & _
                    "OREN        - rename the object, ie. OREN test|test2" & vbCrLf & vbCrLf & _
                    "* = most important when you first create an object." & vbCrLf & _
                    gblzFBGRE & "See Also: HELP &g[CROWNS, FORGE]" _
                , zPortID
                subSendMsg "&GSee Also: &gHELP &g[MOB/MC/RC/IMMORTAL/DC]", zPortID
                subSendMsg "&G" & vbCrLf & vbCrLf & "Special Interactive Object Commands: " & vbCrLf & "&g'SLID', 'ENTE', 'EXIT', 'CLIM', 'MOVE', 'PRES'," & vbCrLf & "'PULL', 'PUSH', 'SEAR', 'SHOV', 'SPRE', 'SWIN', 'SPIN', 'SPEA'," & vbCrLf & "'TOUC', 'TAP', 'TUG', 'TURN', 'TWIS', 'FIX'," & vbCrLf & ("if you dont chose the right word CoA server MUD will hint to you what the answer is. If you guess how to open a perminant fixtured ground Object you will save your Learn Points on hints from the CoA MUD Server") & vbCrLf, zPortID
            End If
        Case "BACK"
            If (lImmortalLevel > 90) Then
                subSendMsg vbCrLf & "&G~SYSTEM BACKUP~&g" & vbCrLf & _
                    "BACKUP      - will freeze all port timers, disconnect the database from the," & vbCrLf & _
                    "operating system then proceeds to make an exact copy of the realm database. The" & vbCrLf & _
                    "system will make grandfather backups as well so make sure you have enough" & vbCrLf & _
                    "harddrive space for at least a few database copies. The copy is sent directly" & vbCrLf & _
                    "to the root folder/directory or also known as C:\ Files are placed at that" & vbCrLf & _
                    "location since you should be running the MUD on an entirely different" & vbCrLf & _
                    "harddrive location. There can be too much activity on a harddrive running" & vbCrLf & _
                    "an operating system and a server at the same time. Both need to read and write" & vbCrLf & _
                    "their own data." & vbCrLf & _
                    gblzFBGRE & "See Also: HELP &g[COLOUR/IMMORTAL]" _
                , zPortID
            End If
        Case "KEEP", "UNKE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&gGame Commands - NO SELL:" & vbCrLf & _
                "KEEP   - everything in your EQuipment list will be marked NO SELL." & vbCrLf & _
                "UNKEEP - everything in your INVentory list will be marked SELL." _
            , zPortID
        Case "CROW", "GLOR", "FORG"
            bHelpSystemOkay = True
            subSendMsg "&W~FORGE UPGRADE COMMANDS~&a" & vbCrLf & _
                "1) Only have that item in your inventory." & vbCrLf & _
                "2) You must also be at an armourer." & vbCrLf & _
                "SYNTAX: FORGE # COMMAND" & vbCrLf & _
                "        FORGE STAMP/UNSTAMP" & vbCrLf & _
                "        FORGE RENAME <newname>" & vbCrLf & _
                "        FORGE DESC <newdescription>" _
            , zPortID
            subSendMsg vbCrLf & _
              "&aSTR        -  " & gbllForgeCostSTRCrowns & " crowns forges 1 strength to an object" & vbCrLf & _
                "INT        -  " & gbllForgeCostINTCrowns & " crowns forges 1 intelligence to an object" & vbCrLf & _
                "WIS        -  " & gbllForgeCostWISCrowns & " crowns forges 1 wisdom to an object" & vbCrLf & _
                "DEX        -  " & gbllForgeCostDEXCrowns & " crowns forges 1 dexterity to an object" & vbCrLf & _
                "CON        -  " & gbllForgeCostCONCrowns & " crowns forges 1 constitution to an object" & vbCrLf & _
                "CHA        -  " & gbllForgeCostCHACrowns & " crowns forges 1 charisma to an object" & vbCrLf & _
                "LUC        -  " & gbllForgeCostLUCCrowns & " crowns forges 1 luck to an object" & vbCrLf, zPortID
            subSendMsg "&a" & _
                "HR         -  1 crown forges 3 hitroll to an object" & vbCrLf & _
                "DR         -  1 crown forges 2 average damage roll to an object" & vbCrLf & _
                "AC         -  1 crown forges 2 armour class to your item" & vbCrLf & _
                "HP         -  1 crown forges 4 hit points to an object" & vbCrLf & _
                "MANA       -  1 crown forges 10 offensive mana to an object" & vbCrLf & _
                "ESSE       -  1 crown forges 10 essence" & vbCrLf & _
                "MOVE       -  1 crown forges 10 move" & vbCrLf & _
                "SOUL       -  1 crown forges 10 soul", zPortID
            subSendMsg "&a" & _
                "STAMP      -  5 crowns stamps this object as yours forever" & vbCrLf & _
                "UNSTAMP    -  9 crowns unstamps this object" & vbCrLf & _
                "TEMPER     -  " & cstlTemperCost & " crowns, randoms level requirement" & vbCrLf & _
                "CHIZZLE    -  " & cstlChizzleCost & " crowns, alignment sets to neutral" & vbCrLf & _
                "RENA       -  1 crown cost per change, renames/restrings an object" & vbCrLf & _
                "DESC       -  1 crown cost per change, modifies the object's description" & vbCrLf & _
                "                object description is revealed when you look at the item," & vbCrLf & _
                "                this command will overwrite the previous item description so" & vbCrLf & _
                "                if you want to keep the previous description you will have" & vbCrLf & _
                "                to append it with your new description.", zPortID
            subSendMsg "&w" & _
                "FORGE YOUR OWN SET by CLASS - Rule: You stamp ~O N C E~ per item, making matching set items:" & vbCrLf & "&a" & _
                "BACKStbSTAMP 199 a stackable damage Backstab stamping" & vbCrLf & _
                "MISSILESTAMP  99 a stackable range stackable Missile stamping", zPortID
            
            If (lImmortalLevel > 3) Then
                subSendMsg "&W~Immortal Forge Commands~&a" & vbCrLf & _
                    "LOCK/UNLOCK-  immo lock playername - will stamp all the players stuff" & vbCrLf & _
                    "TYPE       -  sets the weapon type to the object, HELP TYPE" & vbCrLf & _
                    "LOCA       -  sets the body location, HELP BODY" & vbCrLf & _
                    "WEIG       -  sets the item weight, this is important to keep inventory clean" & vbCrLf & _
                    "IAS        -  Increased Attack Speed" & vbCrLf & _
                    "NOA        -  Number of Attacks" & vbCrLf & _
                    "SLAY       -  Instand death chance percent" & vbCrLf & _
                    "MAGICFIND  -  Helps to find harder to get items" & vbCrLf & _
                    "FIRE       -  Fire enchant" & vbCrLf & _
                    "COLD       -  Cold enchant" & vbCrLf & _
                    "LIGHT      -  Lightning enchant" & vbCrLf & _
                    "POISON     -  Poison enchant" & vbCrLf & _
                    "WB         -  Weapon block percent, *use body location 20 and 21 only*" & vbCrLf & _
                    "MR         -  Move reduction", zPortID
                
                subSendMsg "&a" & _
                    "ACF        -  toggles &colors to an item, ground items only (LOCATION 0)" & vbCrLf & _
                    "OASN       -  forge an Object Activate Spell Number to the item" _
                , zPortID
                
                subSendMsg "&a" & _
                    "ALIGNMENT  -  forge align 0/1/2" & vbCrLf & _
                    "LEVEL REQ  -  forge lvr playerlevel - sets item level req" & vbCrLf & _
                    "FOOD       -  forge 1-20 FOOD - creates a food item" & vbCrLf & _
                    "SM         -  forge SM numberofseats" & vbCrLf & _
                    "WM         -  makes a container - forge weight weightmax - use immo lock too" & vbCrLf & _
                    "LOCK       -  sets the lock status of 10 20 or 30 to an item - use weightmax too" _
                , zPortID
            End If
        Case "AUCT"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~Game Commands~" & vbCrLf & _
                "&aAUCTION     - ie. AUCTION GLOVES 200" & vbCrLf & _
                "BID         - bid on an item at the auction" & vbCrLf & _
                "AUCTION     - typed alone will give you an identify of the item" & vbCrLf & _
                "Immortals reserve the right to cancel an auction for any reason." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CAST/IMM/USE/SOCIALS/DOOR/OBJECT/USE]", zPortID
            If (lImmortalLevel >= 1) Then
                subSendMsg "&gImmortals can stop an auction with IMMO AUCTION" & vbCrLf & "Use IMMO AUCTION LIST to see who is at the auction.", zPortID
            End If
        Case "MAPS", "MAP", "LIGH", "TORC"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MAP COMMAND~" & vbCrLf & "&g" & _
                gblzFNGRE & "The MAP command requires you to LIGHT a torch or cast a light spell." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[MAP/MOB/AREA/BASIC COMMANDS/ADVANCED COMMANDS/TELNET/SLIST]", zPortID
        Case "SCAN"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~SCAN COMMAND~" & vbCrLf & "&g" & _
                gblzFNGRE & "SCAN 1         - will scan around you one area" & vbCrLf & _
                "SCAN 1 PLAY    - will scan around you one area for only players" & vbCrLf & _
                "SCAN 4 MOBS    - will scan around you four areas for only mobs" & vbCrLf & "               - assuming your SLIST permits this far" & vbCrLf & _
                "If you are a thief you scan for objects automatically." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[MAP/MOB/AREA/BASIC COMMANDS/ADVANCED COMMANDS/TELNET/SLIST]", zPortID
        Case "WORM", "SHEL", "SIGN"
            'bHelpSystemOkay = True
            subSendMsg "&G~SIGNATURE~" & vbCrLf & "&g" & _
                "Signature is the distance to the other starship until they spot you." & vbCrLf & _
                "Even when you cloak you give off a signature. If an enemy starship sees this  " & vbCrLf & _
                "you could very well be attacked or chased." _
            , zPortID
            subSendMsg "&G~WORMHOLES~" & vbCrLf & "&g" & _
                "If your starship scanners are high, say over 1500 you will" & vbCrLf & _
                "see wormholes in many places around the Universe!" _
            , zPortID
            If (lImmortalLevel >= 88) Then
                subSendMsg "&G~SPACE COMMANDS~" & vbCrLf & "&g" & _
                    "WORM        - This will create a wormhole from your current" & vbCrLf & _
                    "              location to the x y z desination given." & vbCrLf & _
                    "Shell information and hints to build:" & vbCrLf & _
                    "RepairPort that are true will not show up on the viewer." & vbCrLf & _
                    "The Starship must be between the shell's xs xe ys ye zs ze" & vbCrLf & _
                    "ShellGroupCode will ignore matching shell ShellGroupCode values after the first shell qualifies." & vbCrLf & _
                    "ShellGroupCode will continue to show all other ShellGroupCode not repeating." & vbCrLf & _
                    "The ShellOrderFromSource closest to the destination point must be the" & vbCrLf & _
                    "      SMALLEST set shell value of the same ShellGroupCode." & vbCrLf & _
                    "Shell search order are: ShellGroupCode, ShellOrderFromSource" _
                , zPortID
                
                subSendMsg "&GSee Also: &gHELP[STARSHIP/SLIST/IMMORTAL/RC/MC/OC/FORGE].", zPortID
            End If
        Case "MESS"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MESSAGE BOARDS~" & vbCrLf & _
                gblzFNGRE & "MBC  - will create a message " & vbCrLf & "     ie. MBC Hello everyone!" & vbCrLf & "     will post a new message on the message board" & vbCrLf & _
                "MBD  - will delete a message from the board" & vbCrLf & "     ie. MBD 235" & vbCrLf & "     will delete note 235" & vbCrLf & _
                "MBV  - will view the message board" & vbCrLf & "     ie. MBV ALL will show them all" & vbCrLf & "     MBV 10 will show the top 10" & vbCrLf & "MBV alone will list the first few notes" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[MOB/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        Case "MERC"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MERCHANT~" & vbCrLf & "&g" & _
                "LIST        - shows what the merchant has for sale" & vbCrLf & _
                "SELL        - sell an item to a merchant, see also: AUCTION" & vbCrLf & _
                "BUY         - buy soemthing from a merchant" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[ROOM/MOB/AUCTION]", zPortID
        Case "PAGE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~PAGE REPORTS~" & vbCrLf & "&g" & _
                "Type PAGE alone for a list of page reports available to players.", zPortID
        Case "MORP", "REMO"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~MORPHING~" & vbCrLf & "&g" & _
                "There are two types of morphing at City of Ages:" & vbCrLf & _
                "        -     Class morphing and Organic morphing." & vbCrLf & _
                "Class morphing is similar to remorting." & vbCrLf & _
                "Organic morphing is similar to turning someone into a frog." & vbCrLf & _
                "At City of Ages both have their advantages and disadvantages." & vbCrLf & _
                "Being a certain morphs allows you in certain areas as well." _
            , zPortID
        Case "PLAG", "GUAR"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~PLAGUE COMMANDS~" & vbCrLf & "&g" & _
                "DREAM    - so you can pickup a guard duty right away" & vbCrLf & _
                "When you recieve a guard quest it is to test your prowlness." & vbCrLf & _
                "If you do not find the location or forget to, you become a LAZY GUARD." & vbCrLf & _
                "See Also: [ORACLE/MAP/PAGE QUEST]" _
            , zPortID
        Case "SPAC", "STAR", "SHIP", "SS", "PILO", "CHEV" 'chevrons
            bHelpSystemOkay = True
            subSendMsg "&G~REQUIRED WEEKLY COLONISTS~&A" & vbCrLf & "Planets: " & cstlRequiredTotalPlanets & " Colonists: " & cstlRequiredTotalColonists, zPortID
            subSendMsg vbCrLf & "&G~PILOT COMMANDS~" & vbCrLf & "&g" & _
                "STARGATE         - stargate chevrons will open the event horizon of a stargate" & vbCrLf & _
                "SS               - will show all the available commands" & vbCrLf & _
                "                 ie. STARGATE CHEVRONPATTERN to activate a stargate" & vbCrLf & _
                "                     STARGATE alone to enter an open stargate" _
            , zPortID
            
            subSendMsg vbCrLf & "&G~PILOT NAVIGATION~" & vbCrLf & "&g" & _
                "The use of warp technology works in a rubics cube 3D Matrix like environment." & vbCrLf & _
                "West is -X and East is X+" & vbCrLf & _
                "North is -Y and South is Y+" & vbCrLf & _
                "Up is -Z and Down is Z+" & vbCrLf & _
                "When you put in your coordinates you never include the X Y Z letters," & vbCrLf & "only the numbers." & vbCrLf & _
                "These are location examples:" & vbCrLf & _
                "SS NAVIGATION -2 3 -708 will take you to the Red Planets Docking Port" & vbCrLf & _
                "SS NAVIGATION 0 0 -110 will take you above High in the Clouds" & vbCrLf & _
                "SS NAVIGATION 0 0 -50 will take you above the Newbie Zone" & vbCrLf & _
                "SS NAVIGATION 0 0 -6 will take you above heaven," & vbCrLf & "beam down and then enter the " & gblzMUDName & vbCrLf & _
                "The centre of the " & gblzMUDName & " is located at 0 0 0" & vbCrLf & _
                "Your warpdrive capable ship can get damaged but repairs are free." & vbCrLf & _
                "Your warpdrive ship never blows up no matter how much damage" & vbCrLf & "is sustained to it." & vbCrLf & _
            gblzFBGRE & "See Also: HELP &g[ROOM/MOB/AUCTION/WORM] also type SS for the starport prices", zPortID
            If (lImmortalLevel > 2) Then
                subSendMsg "&G~ROOM COMMANDS~&g" & vbCrLf & _
                    "WORM        - immo worm x y z creates a worm hole to x y z" & vbCrLf & _
                    "NAVIG       - will randomly select a mobship and move it." & _
                    "See Also: [RC/IMMORTAL/OC/MC]" _
                , zPortID
            End If
        Case "SLIS", "PRAC", "LEAR", "COST", "AFK", "MODE", "QUIC", "FAST", "NOW", "GOGO", "GO", "DAMA", "BAN", "COMP"
            bHelpSystemOkay = True
            If lImmortalLevel >= 1 Then subSendMsg "&GIMMO COMPLETE LIST     IMMO SET <COMPLETEBANMAX>    IMMO SPAM (toggle)", zPortID
            subSendMsg vbCrLf & "&G~QUICK COMMANDS~" & vbCrLf & "&g" & _
                "SLIST       - SKILLS->This will list all of your natural spells/crafts/and skills." & vbCrLf & _
                "LEARN TREE  - SPELLS->This will list all of your possible s/c/and s." & vbCrLf & _
                "PRACTICE    - This will list all of your practiced s/c/and s." & vbCrLf & _
                "COST        - List of casting costs" & vbCrLf & _
                "DAMAGE      - List of heal and damage causing spells" & vbCrLf & _
                "USE         - USE LEVERS, USE KNOBS, USE KEYS, COMBINATION, USE PICKLOCK" & vbCrLf & _
                "LEARN       - Use at a teacher! LEARN (alone) to lists all s/c/&s there." & vbCrLf & _
                "REPORT      - tells everyone around your area your current status" _
            , zPortID
            subSendMsg gblzFNGRE & _
                "PAGE        - you can read over many system reports" & vbCrLf & _
                "IGNORE      - you can completely ignore a player" & vbCrLf & _
                "X or SCORE  - see your player stats and adjustments" & vbCrLf & _
                "REPEAT      - REPEAT or ! character will repeat your last command." & vbCrLf & _
                "KEEP        - KEEP and UNKEEP will toggle if you can sell your items or not" & vbCrLf & _
                "AFK         - toggle your away from keyboard status" & vbCrLf & _
                "PAGE COMP   - PAGE COMPONENTS lists your required spell components" & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[AREA/BASIC COMMANDS/ADVANCED COMMANDS/TELNET]", zPortID
        Case "TELN", "REPE"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GTelnet Commands:" & vbCrLf & "&g" & _
                "REPEAT      - REPEAT or ! character will repeat your last command." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[SLIST/FORGE/CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        Case "SQL", "TABL", "FIEL", "VARI" 'IMMO TABLE FIELDS TABLENAME
            bHelpSystemOkay = True
            If (lImmortalLevel > 90) Then
                subSendMsg vbCrLf & "&w" & "~SQL COMMANDS~" & "&a" & vbCrLf & _
                    "TABLES    - immo table list  or  immo table tablename" & vbCrLf & _
                    "FIELDS    - same as immo table fields tablename" & vbCrLf & _
                    "            LIST will list them all" & vbCrLf & _
                    gblzFBGRE & "See Also: HELP &g[IMMORTAL]", zPortID
            End If
        Case "EQUI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&GPlayer Equipment (worn):&g" & vbCrLf & _
                "EQUIP     - Will list all the equipment you are wearing." & vbCrLf & _
                "EMPTY     - Will list all the empty equipment slots." & vbCrLf & _
                "EQUIP     - EQ BACK or EQ MIDDLE or EQ HEAD   ..." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[CLAN/AREA/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        Case "STOC"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~STOCK MARKET~&g" & vbCrLf & _
                "STOCK     - this typed alone will show you the complete syntax of the command." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[INVESTMENTS]", zPortID
        Case "INVE", "VARI"
            bHelpSystemOkay = True
            subSendMsg vbCrLf & "&G~STOCK MARKET INVESTMENT VARIABLES~&g" & vbCrLf & _
                " VARIABLES:  A to M shows disruption in the stock index" & vbCrLf & _
                "             N to Z shows a positive fluxuation in the stock" & vbCrLf & _
                "             A - financial sheet did not balance" & vbCrLf & _
                "             B - there was a mismanagement of funds" & vbCrLf & _
                "             C - poor investments" & vbCrLf & _
                "             D - inventory did not balance (thieft?)" & vbCrLf & _
                "             W - fiscal sheet balanced" & vbCrLf & _
                "             X - there was a balance or profit" & vbCrLf & _
                "             Y - investment balance or profit" & vbCrLf & _
                "             Z - inventory balanced" & vbCrLf & _
                "EXAMPLE:     There are four checks as well ie. (A2ZZ)" & vbCrLf & _
                "             This example means," & vbCrLf & _
                "               the fiscal sheet did not balance" & vbCrLf & _
                "               any number ie. this 2 indicates a perfect balance" & vbCrLf & _
                "               and the inventory balanced" & vbCrLf & _
                "               and again the inventory balanced" & vbCrLf & _
                "NOTE:        The fall(3) and the winter(4) terms usually balance" & vbCrLf & _
                "             due to a slow peroid." & vbCrLf & _
                gblzFBGRE & "See Also: HELP &g[STOCK]", zPortID
    End Select
    
    If (Len(MyCStr(zFocusWord)) > 0) Then
        Set rsHelpSystem = MyDB.OpenRecordset("SELECT SystemHelpID, SystemHelpTitle, SystemHelpKeywords, SystemHelpDesc, ImmortalLevel FROM tblSystemHelp WHERE (ImmortalLevel Is Null or ImmortalLevel <= " & lImmortalLevel & ")  AND (SystemHelpKeywords Like '*" & zAntiSQLCrash(zFocusWord) & "*') ORDER BY ImmortalLevel, SystemHelpTitle;", dbOpenSnapshot)
        If (Not rsHelpSystem.EOF) Then
            bHelpSystemOkay = True
            rsHelpSystem.MoveLast
            lRecordCount = rsHelpSystem.RecordCount
            rsHelpSystem.MoveFirst
            
            If (lRecordCount < 9) Then
                Do While (Not rsHelpSystem.EOF)
                    If (MyCLng(rsHelpSystem!ImmortalLevel) > 0) Then
                        subSendMsg vbCrLf & "&r" & "(EYE)&r IMMORTAL HELP FILE (IL" & MyCLng(rsHelpSystem!ImmortalLevel) & "+) &w- HELPID#" & MyCLng(rsHelpSystem!SystemHelpID), zPortID
                    Else
                        If (lImmortalLevel > 3) Then subSendMsg vbCrLf & "&r" & "(EYE)&w HELPID#" & MyCLng(rsHelpSystem!SystemHelpID), zPortID
                    End If
                    subSendMsg "&G" & MyCStr(rsHelpSystem!SystemHelpTitle) & vbCrLf & "&g" & (MyCStr(rsHelpSystem!SystemHelpDesc)), zPortID
                    rsHelpSystem.MoveNext
                Loop
            Else
                subSendMsg "&GHelp System - " & lRecordCount & " matches found." & vbCrLf & "&gPlease try a more unique search word.", zPortID
            End If
        End If
        Set rsHelpSystem = Nothing
    End If
    
    If (Not bHelpSystemOkay) Then
        subSendMsg vbCrLf & "&G~HELP SYSTEM~" & vbCrLf & "&g" & _
            "|---------------|---------------|---------------|---------------|--------------|" & vbCrLf & _
            "|ADVANCED COMMAN|BASIC COMMANDS |LEARN TREE     |SLIST          |CHANNELS      |" & vbCrLf & _
            "|STATISTICS     |SCORE          |SCAN           |PAGE           |USE           |" & vbCrLf & _
            "|COLOR          |PROMPT         |CONFIG         |AUCTION        |TRAIN PETS    |" & vbCrLf & _
            "|TITLE          |DESCRIPTION    |CRAFTING       |MESSAGEBOARDS  |PETS          |" & vbCrLf & _
            "|WHOIS          |FORGE          |STARSHIPS      |QUEST COMMANDS |BANK          |" & vbCrLf & _
            "|PARTY          |RARES          |KEEP           |" & gblzFBMAG & "RULES          &g|&GNOOBIE        &g|" & vbCrLf & _
            "|---------------|---------------|---------------|---------------|--------------|" _
        , zPortID
    End If
    ''AbsorbsSameLeft Transmute
    Exit Sub
Err_Check:
    subWriteErrorFile "subHelpSystem," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSLIST(zPortID As String, zPlayerClassPass As String, lPlayerID As Long, lPlayerLevel As Long, zPlayerRacePass As String, lSlayChance As Long)
'REPORTING SYSTEM ONLY - no saved calculations here
On Error GoTo Err_Check 'math, see also: subRecalculatePlayerEquipment
    Dim lGetTranslateSpellFailValueByClass As Long
    Dim zColour As String
    Dim zSpecialMemo As String
    Dim rsSList As Recordset
    Dim bEnsnaringAbility As Boolean
    Dim lDummyTemp As Long
    Dim lNumAttRnd As Long
    Dim lNumAttRndClass As Long
    Dim lNumAttRndRace As Long
    Dim zMsg As String
    Dim bHoldCheckSM As String
    Dim zPlayerRace As String
    Dim zPlayerClass As String
    lGetTranslateSpellFailValueByClass = lTranslateSpellFailValueByClass(zPlayerClass)
    
    zPlayerRace = Mid(zPlayerRacePass, 1, 3)
    zPlayerClass = Mid(zPlayerClassPass, 1, 2)
    Select Case zPlayerClass 'works with zPlayerClass = Mid(zPlayerClassPass, 1, 2)
        Case "WI", "LO"
            zPlayerClass = "IO"
    End Select
    Set rsSList = MyDB.OpenRecordset("tblTEMPPlayerSList", dbOpenTable) 'rsSList!SpellName = "" '25 long max
    bHoldCheckSM = (zPlayerRace = "ELF" Or zPlayerClass = "CY" Or zPlayerClass = "CL" Or zPlayerClass = "PA")
    'SKILLS
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Job: Mortician! Kill, Wear, Donate, and Sell Corpses"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Job: Gold Miser, gold drop +" & lReturnTranslateGoldMiserRaceClass(zPlayerRace, zPlayerClass) & "%"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    Select Case lReturnTranslateDreamBonus(zPlayerRace, zPlayerClass)
        Case 0 To 10
            zMsg = "[STUPENDOUS]"
        Case 11 To 20
            zMsg = "[WONDERFUL]"
        Case 21 To 30
            zMsg = "[GOOD]"
        Case 31 To 40
            zMsg = "[GREAT]"
        Case 41 To 50
            zMsg = "[OKAY]"
        Case Else
            zMsg = "[GENERIC]"
    End Select
    rsSList!SpellName = "Dreamer Level [" & lReturnTranslateDreamBonus(zPlayerRace, zPlayerClass) & "] " & zMsg & ", lower the better"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Forger Max Percentage [" & lReturnTranslateForgerMaxPercent(zPlayerRace, zPlayerClass) & "]"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    If (bReturnAppraiserCheckRaceClass(zPlayerRace, zPlayerClass)) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Job: Appraiser!"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "HUM" Or zPlayerRace = "HAL" Or zPlayerRace = "ELF") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Job: LOAD missiles at reduced cost"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "DWA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Job: REPAIR items"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
        
    If (zPlayerRace = "PIX") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: Itzy Bitzy Flying dot [-hunt +dex20]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Spell Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "IO") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: Crazy Fighting Wacko [+hunt +dex20]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Spell Colours
        rsSList.Update
    End If
        
    If (bHoldCheckSM) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: Senses [true sight area hidden objects]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "HUM" Or zPlayerRace = "HAL" Or zPlayerRace = "DWA" Or zPlayerRace = "FEL" Or zPlayerClass = "CY" Or zPlayerClass = "PA" Or zPlayerClass = "AS" Or zPlayerClass = "RA") Then 'see also: basSenseForTraps
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: Senses [traps / glory mobs&objs]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "ELF" Or zPlayerClass = "PA" Or zPlayerClass = "CL") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: Elvish mounted Berzerker"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (zPlayerClass = "KN" Or zPlayerClass = "PA" Or zPlayerClass = "CL") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Good Natured: VOTUM DEHONESTATIO"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "BODY: Can defeat " & lRaceClassAttackLevelMAX(zPlayerRace, zPlayerClass) & " mobs without rest [" & gbllAttackLevel(MyCLng(zPortID)) & "]"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
        
    If (zPlayerClass = "AS") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: PowerKick Clawhand Knifehand"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "DRA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: AntiPoisonScales DragonUppercut"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Durability Dodge [" & lTranslateDurabilityControlRaceClass(zPlayerRace, zPlayerClass) & "]"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update

    If (zPlayerRace = "ORC" Or zPlayerClass = "TH" Or zPlayerClass = "AS" Or zPlayerClass = "GY") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "MASTERSTAB: Short-circuits herd group quests"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (zPlayerClass = "BA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "GLOBAL Channel: MUSIC (roleplay enforced for hymn)"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "AS") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "MASTERHOPPER: SNEAK + BS = bonus[x3slay+9]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "TH") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "GRASSHOPPER: SNEAK + BS = bonus[x2slay+1]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    
    If (zPlayerClass = "BA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Mesmer Immunity (passive): Shed off STUN, and SNEEZE"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "BA") Then 'jester class basically
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Mesmer UpDaSleeve (passive): GRIP +9"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "UND") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Pandemic Immunity (passive): SNEEZE"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
       
    If (zPlayerRace = "DRA" Or zPlayerClass = "BA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "FORCE Immune/Gives Hallucinate 20% [-slay][*look*]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "PL" Or zPlayerClass = "VE" Or zPlayerClass = "IO") Then 'plant/vegitation same thing WitchWarloc
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "BEASTMASTER [15cha +300hr +half-attack] per pet"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "DR" Or zPlayerClass = "IO" Or zPlayerClass = "MA") Then 'plant/vegitation same thing WitchWarloc
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Job: SCRY command is used over last seen item on a mob"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    'If (zPlayerClass = "GY" And zPlayerClass = "TH" And zPlayerRace = "TRO" And zPlayerRace = "OGR") Then
    '    rsSList.AddNew
    '    rsSList!PlayerID = lPlayerID
    '    rsSList!SpellName = "Skill: GYs+THIEFS+TROLLs+OGREs are Immune to mob-thieft"
    '    rsSList!SpellLevel = -1
    '    rsSList!Value = 1 'Skill Colours
    '    rsSList.Update
    'End If

    If (zPlayerClass = "MO" Or zPlayerClass = "IO") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: SUICIDE in the area to neutralize enemies."
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (zPlayerClass = "GY" Or zPlayerClass = "IO") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: SABOTAGE skills/shields in room"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "GY" Or zPlayerClass = "CL" Or zPlayerClass = "MO" Or zPlayerClass = "MA" Or zPlayerClass = "KN" Or zPlayerClass = "BA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: MAJIC unseal a door"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerClass = "CY") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: autotargeting EYEBEAMS on/off"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
        
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Maintenance: VENT trigger system (online/offline)"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (zPlayerClass = "WA" Or zPlayerClass = "IO") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID 'lCostMove = 1350      lCostSoul = 3700
        rsSList!SpellName = "Skill: STOMP command m1350 s3700"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    If (zPlayerClass = "WA" Or zPlayerClass = "GL") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: Every 50 levels ++ HR+250 DR+150"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (zPlayerClass = "VA" Or zPlayerClass = "KN" Or zPlayerClass = "GL" Or zPlayerClass = "RA" Or zPlayerClass = "GY" Or zPlayerClass = "IO") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: HITALL command (weapon req/mount does bonus dmg)"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (zPlayerRace = "CL" Or zPlayerClass = "PA" Or zPlayerRace = "DRA" Or zPlayerRace = "UND") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Cleric Paladin Drac Undead all Ignore atmoz-boltz" 'make any changes also in this sub is a must! subLightningBoltARandomPlayer
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (gbllWearItemMAX <> gbllWearItemMAXLimit) Then
    'lTranslateWearMAXRC(zRaceType As String, zClassType As String, zType As String)
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Natural: WEAR Limit R[" & lTranslateWearMAXRC(zPlayerRace, zPlayerClass, "R") & "] C[" & lTranslateWearMAXRC(zPlayerRace, zPlayerClass, "C") & "] BASE[" & gbllWearItemMAX & "]"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Spell Colours
    rsSList.Update
    End If

    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Natural: Armour Absorption :: Class(" & lClassArmourAbsorbtionChance(zPlayerClass) & ") + Race(" & lRaceArmourAbsorbtionChance(zPlayerRace) & ") %" & lClassArmourAbsorbtionChance(zPlayerClass) + lRaceArmourAbsorbtionChance(zPlayerRace)
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Natural: Ensnare Delay (" & MyCStr(lTranslateEnsnareNetInterruption(zPlayerClass)) & ")"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    Select Case lReturnClassSavingthrows(zPlayerClass)
        Case 1 To 2
            rsSList!SpellName = "Natural: Class Saving Throw [" & lReturnClassSavingthrows(zPlayerClass) & "] *GREAT anti-Interrupt*"
        Case 3
            rsSList!SpellName = "Natural: Class Saving Throw [" & lReturnClassSavingthrows(zPlayerClass) & "] *NORMAL anti-Interrupt*"
        Case Else
            rsSList!SpellName = "Natural: Class Saving Throw [" & lReturnClassSavingthrows(zPlayerClass) & "] *POOR anti-Interrupt*"
    End Select
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Spell Colours
    rsSList.Update
    
    
    Select Case zPlayerClass
        Case "KN"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural: bowslay/meleeslay(" & MyCStr(lSlayChance * 2) & ")"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
        Case "RA"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural: bowslay(" & MyCStr(lSlayChance * 2) & ")"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select

    Select Case zPlayerClass
        Case "KN"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural: Force protects you! Immune to radiation."
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select

    Select Case zPlayerClass
        Case "MO" 'waterloo and chiotru
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "IB Stance: Aggro" & lTranslateInitiativeChance(1) & ", Def" & lTranslateInitiativeChance(2) & ", Waterloo" & lTranslateInitiativeChance(4) & ", Chiotru" & lTranslateInitiativeChance(5)
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
        Case "AS"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "IB Stance: Aggro" & lTranslateInitiativeChance(1) & ", Def" & lTranslateInitiativeChance(2)
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
        Case "WA", "GL", "GY"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "IB Stance: Aggro" & lTranslateInitiativeChance(1) & ", Def" & lTranslateInitiativeChance(2) & ", Slay" & lTranslateInitiativeChance(3)
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
        
    Select Case zPlayerRace
        Case "UND"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural AC Skill: -=Undeadian Moon Bonus=-"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerRace
        Case "DRA"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural AC Skill: -=Scales Moon Bonus=-"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerRace
        Case "ORC", "TRO", "OGR"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural AC Skill: -=Hide Moon Bonus=-"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "VA", "WE"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural AC Skill: -=Full Moon Bonus=-"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    If (bCanUseTheForce(zPlayerClass, "")) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "FORCED INTERRUPT by Class"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    If (bCanUseTheForce("", zPlayerRace)) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "FORCED INTERRUPT by Race"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (lReturnTranslateCharismaticBonus(zPlayerRace, zPlayerClass) > 2) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Charismatic (race+class=" & lReturnTranslateCharismaticBonus(zPlayerRace, zPlayerClass) & ") ie. guarding/better thief"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If

    If (lInvHoldRaceBonus(zPlayerRace) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: race bonus of +" & lInvHoldRaceBonus(zPlayerRace) & " inventory items."
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Natural: Initiative Bonus C(" & lTranslateInitiativeBonus(zPlayerClass, zPlayerRace, "C") & ")+R(" & lTranslateInitiativeBonus(zPlayerClass, zPlayerRace, "R") & ") = +" & lTranslateInitiativeBonus(zPlayerClass, zPlayerRace, "B")
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    Select Case zPlayerClass
        Case "AS", "WA", "GL", "GY"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: can JUMP areas with a pole vault"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
        
    Select Case zPlayerClass
        Case "GY", "TH"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: MAGIC FIND hunter (+playerlevel)"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    lNumAttRnd = 0
    Select Case zPlayerClass
        Case "WA", "GL", "AS", "GY"
            lNumAttRnd = lNumAttRnd + 1
            lNumAttRndClass = 1
    End Select
    Select Case zPlayerRace
        Case "ORC", "TRO", "OGR", "OGR", "DWA", "MIN"
            lNumAttRnd = lNumAttRnd + 1
            lNumAttRndRace = lNumAttRndRace + 1
    End Select
    
    If (lNumAttRnd > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "BONUS ATTACKS: class[" & lNumAttRndClass & "]+race[" & lNumAttRndRace & "] = " & lNumAttRndClass + lNumAttRndRace
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    Select Case zPlayerClass
        Case "AS", "WE", "IO"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: DEAD raising command!"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    If zPlayerClass = "AS" Or zPlayerClass = "IO" Or zPlayerRace = "ORC" Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: CHAIN leecher command!"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    Select Case zPlayerClass
        Case "GY", "WA", "KN", "PA", "AS", "PL", "BA"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: can BREAK entanglement"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "MA", "IO", "PA", "CL", "DR"
            Select Case zPlayerClass
                Case "MA", "CL", "DR"
                    lDummyTemp = 1
                Case "PA"
                    lDummyTemp = 5
                Case Else
                    lDummyTemp = 3
            End Select
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "NOTE: ARCANE BOLTS COST " & MyCStr(lDummyTemp) & " CROWNS + M400 S250"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "MA", "IO"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "ARCANE <target> command, race+class speed[" & lSpeedShootingArcaneBolt(zPlayerRace, zPlayerClass) & "]"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass 'bolt requires empty hands
        Case "DR", "CL", "PA"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "KENETIC <target> command, race+class speed[" & lSpeedShootingArcaneBolt(zPlayerRace, zPlayerClass) & "]"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "ARCANE <target> command, BoGuS-chance[" & lReturnTranslateAimlevel(zPlayerRace, zPlayerClass) & "%]"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    If (zPlayerRace = "FEL") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: infravision (sensitive to light)"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "IAS+" & lTranslatePlayerRaceClassIAS(zPlayerRace, zPlayerClass)
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
        
    Select Case zPlayerClass
        Case "WA", "GL", "KN", "PL", "VE"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: resists netting"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "WA", "GL"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: resists stun"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "RA", "TH", "AS", "DR"
            Select Case zPlayerClass
                Case "RA"
                    lDummyTemp = cstlDisarmTrapChanceRA
                Case "TH"
                    lDummyTemp = cstlDisarmTrapChanceTH
                Case "AS"
                    lDummyTemp = cstlDisarmTrapChanceAS
                Case "DR"
                    lDummyTemp = cstlDisarmTrapChanceDR
                Case Else
                    lDummyTemp = cstlDisarmTrapChanceOption
            End Select
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: " & lDummyTemp & "% chance to disarm traps"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
        
    Select Case zPlayerClass
        Case "CL", "PA", "BA", "DR", "MO"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: resists blind"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "MO", "BA", "VA", "WE"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: bare handed martial arts"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
 
    If (zPlayerRace = "TRO" Or zPlayerRace = "OGR" Or zPlayerClass = "GY" Or zPlayerClass = "TH") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: Pirate Thief Criminal immunity from creatures!"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (cstbGlobalThiveryAllowed) Then
        Select Case zPlayerClass 'Everyone can: Steal Disarm and Stun but the costs vary dramatically
            Case "TH", "BA", "GY", "AS" 'old concept that only certain classes could steal items
                rsSList.AddNew
                rsSList!PlayerID = lPlayerID
                rsSList!SpellName = "Skill: STEAL ITEMS from creatures!"
                rsSList!SpellLevel = -1
                rsSList!Value = 1 'Skill Colours
                rsSList.Update
        End Select
    End If
    
    Select Case zPlayerClass
        Case "TH", "BA", "GY"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: SCAN OBJECTS command"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "TH"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: haggle for gold"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    Select Case zPlayerClass
        Case "WA", "GL", "KN", "PA", "TH", "RA"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Skill: weapon block"
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Skill: Dual Weapon Wield lv"
    rsSList!SpellLevel = lTranslateDualWeildValueByClass(zPlayerClass)
    rsSList!Value = 2 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Skill: Blind Fight lv"
    rsSList!SpellLevel = lTranslateBlindFightValueByClass(zPlayerClass)
    rsSList!Value = 2 'Skill Colours
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Skill: Stun Fight lv"
    rsSList!SpellLevel = lTranslateStunFightValueByClass(zPlayerClass)
    rsSList!Value = 2 'Skill Colours
    rsSList.Update
    
    'COST (level is not level but cost amount)
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Scan Cost - Soul"
    rsSList!SpellLevel = lTranslateSkillScanSoulCost(zPlayerClass)
    rsSList!Value = 4 'Skill Cost
    rsSList.Update
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Scan Cost - Move"
    rsSList!SpellLevel = lTranslateSkillScanMoveCost(zPlayerClass)
    rsSList!Value = 4 'Skill Cost
    rsSList.Update
    
    bEnsnaringAbility = (bCanClassWearWeaponType(zPlayerClass, "NET"))
    If (bEnsnaringAbility) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Ensnare Cost (requires a net) - Soul"
        rsSList!SpellLevel = cstlEnsnareSoulCost * lTranslateSkillEnsnareCost(zPlayerClass)
        rsSList!Value = 5 'Skill Cost
        rsSList.Update
    End If
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    Select Case zPlayerClass
        Case "AS"
            rsSList!SpellName = "BackStab/Stun[weapons master] Cost - Soul"
            rsSList!SpellLevel = cstlStunSoulCost * lTranslateSkillStunCost(zPlayerClass)
            rsSList!Value = 6 'Skill Cost color
        Case Else
            Select Case zPlayerClass
                Case "MA", "IO", "DR", "PA"
                    rsSList!SpellName = "BackStab Cost - Soul"
                    rsSList!SpellLevel = cstlStunSoulCost * lTranslateSkillStunCost(zPlayerClass)
                    rsSList!Value = 6 'Skill Cost color
                Case Else
                    rsSList!SpellName = "BackStab/Stun[dagger talonous] Cost - Soul"
                    rsSList!SpellLevel = cstlStunSoulCost * lTranslateSkillStunCost(zPlayerClass)
                    rsSList!Value = 6 'Skill Cost color
            End Select
    End Select
    rsSList.Update
    
    If (zPlayerClass <> "MA" And zPlayerClass <> "IO" And zPlayerClass <> "DR" And zPlayerClass <> "PA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Disarm Cost - Soul"
        rsSList!SpellLevel = cstlDisarmSoulCost / lTranslateDisarmCost(zPlayerClass)
        rsSList!Value = 7 'Skill Cost
        rsSList.Update
    End If
    
    If (zPlayerClass = "TH" Or zPlayerClass = "AS" Or zPlayerClass = "RA") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Disarm Cost - Soul"
        rsSList!SpellLevel = cstlDisarmTrapSoulCost
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    If (zPlayerClass <> "IO") Then 'Witchlockes cannot steal
        If (cstbGlobalThiveryAllowed) Or (zPlayerClass = "TH" Or zPlayerClass = "BA" Or zPlayerClass = "GY" Or zPlayerClass = "AS") Then
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            If (cstbGlobalThiveryAllowed) Then
                rsSList!SpellName = "Steal Cost * Soul"
            Else
                rsSList!SpellName = "Steal Cost - Soul"
            End If
            rsSList!SpellLevel = lTranslateSoulStealCost(zPlayerClass)
            rsSList!Value = 3 'Skill Cost
            rsSList.Update
            
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            If (cstbGlobalThiveryAllowed) Then
                rsSList!SpellName = "Steal Cost * Move"
            Else
                rsSList!SpellName = "Steal Cost - Move"
            End If
            rsSList!SpellLevel = lTranslateMoveStealCost(zPlayerClass)
            rsSList!Value = 3 'Skill Cost
            rsSList.Update
        End If
    End If 'Witchlocke cannot steal
    
    'Available Weapons
    zSpecialMemo = ""
    If (bCanClassWearWeaponType(zPlayerClass, "LANC")) Then
        zSpecialMemo = zSpecialMemo & "Lance "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "POLE")) Then
        zSpecialMemo = zSpecialMemo & "Polearms "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "JAVI")) Then
        zSpecialMemo = zSpecialMemo & "Javelins "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "SPEA")) Then
        zSpecialMemo = zSpecialMemo & "Spear    "
    End If
    If (Len(zSpecialMemo) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Weapons: " & zSpecialMemo
        rsSList!SpellLevel = -4
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
        zSpecialMemo = ""
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "LBLA")) Then
        zSpecialMemo = zSpecialMemo & "Long-Blades "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "SBLA")) Then
        zSpecialMemo = zSpecialMemo & "Short-Blades "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "PUGI")) Then
        zSpecialMemo = zSpecialMemo & "Pugilism "
    End If
    If (Len(zSpecialMemo) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Weapons: " & zSpecialMemo
        rsSList!SpellLevel = -4
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
        zSpecialMemo = ""
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "BLUD")) Then
        zSpecialMemo = zSpecialMemo & "Bludgeons "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "FLEX")) Then
        zSpecialMemo = zSpecialMemo & "Flexible "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "TALO")) Then
        zSpecialMemo = zSpecialMemo & "Talonous "
    End If
    If (Len(zSpecialMemo) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Weapons: " & zSpecialMemo
        rsSList!SpellLevel = -4
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
        zSpecialMemo = ""
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "SAXE")) Then
        zSpecialMemo = zSpecialMemo & "Small-Axe "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "GAXE")) Then
        zSpecialMemo = zSpecialMemo & "Great-Axe "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "SSTA")) Then
        zSpecialMemo = zSpecialMemo & "S-Staff   "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "LSTA")) Then
        zSpecialMemo = zSpecialMemo & "L-Staff   "
    End If
    If (Len(zSpecialMemo) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Weapons: " & zSpecialMemo
        rsSList!SpellLevel = -4
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
        zSpecialMemo = ""
    End If
    'End Available Weapons
    
    'Missile Weapons
    zSpecialMemo = ""
    If (bCanClassWearWeaponType(zPlayerClass, "MGUN")) Then
        zSpecialMemo = zSpecialMemo & "MachineGun "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "PHAS")) Then
        zSpecialMemo = zSpecialMemo & "Phaser "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "BOW")) Then
        zSpecialMemo = zSpecialMemo & "Bows "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "XBOW")) Then
        zSpecialMemo = zSpecialMemo & "Crossbow "
    End If
    If (bCanClassWearWeaponType(zPlayerClass, "SLIN")) Then
        zSpecialMemo = zSpecialMemo & "Slings "
    End If
    If (bEnsnaringAbility) Then
        zSpecialMemo = zSpecialMemo & "Nets "
    End If
    If (Len(zSpecialMemo) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Missile Weapons: " & zSpecialMemo
        rsSList!SpellLevel = -3
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
        zSpecialMemo = ""
    End If
    'End Missile Weapons
    
    If (zPlayerClass = "TH" Or zPlayerClass = "AS") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Soul: Each Sneaking Cost"
        rsSList!SpellLevel = cstlSneakSoulCost
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    If (zPlayerRace = "GNO") Or (zPlayerClass = "ORC") Or (zPlayerClass = "MIN") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        Select Case zPlayerRace
            Case "GNO"
                rsSList!SpellName = "You can enchant 20% better."
            Case "ORC"
                rsSList!SpellName = "You can enchant 15% better."
            Case "MIN"
                rsSList!SpellName = "You can enchant 10% better."
        End Select
        rsSList!SpellLevel = -1
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Passive skills, base chance to use: " & lTranslateClassLearnPointPercentChance(zPlayerClass)
    rsSList!SpellLevel = -1
    rsSList!Value = 3
    rsSList.Update
    
    If (zPlayerRace = "TRO" Or zPlayerRace = "OGR" Or zPlayerClass = "WE") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "You can eat corpses to regain hitpoints."
        rsSList!SpellLevel = -1
        rsSList!Value = 3
        rsSList.Update
    End If
    
    If (lTranslateRegenerationLevelRaceBonus(zPlayerRace) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural regeneration level " & lTranslateRegenerationLevelRaceBonus(zPlayerRace)
        rsSList!SpellLevel = -2
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    If (lTranslateRaceCraftBonus(zPlayerRace) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Race crafting bonus " & lTranslateRaceCraftBonus(zPlayerRace) & "%"
        rsSList!SpellLevel = -1
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    If (zPlayerClass = "TH" Or zPlayerRace = "FEL") Then
        Dim zWhatAllowedIt As String
        zWhatAllowedIt = ""
        If (zPlayerClass = "TH") Then zWhatAllowedIt = zWhatAllowedIt & "T"
        If (zPlayerRace = "FEL") Then zWhatAllowedIt = zWhatAllowedIt & "F"
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: scan for hidden objects [" & zWhatAllowedIt & "]"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "HAL") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: +40DEX +5WIS +300MOVE"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    If (zPlayerRace = "HUM") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Natural: +33INT +10WIS +200MOVE"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
        
    If (lTranslateClassScanArea(zPlayerClass) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "You can scan " & lTranslateClassScanArea(zPlayerClass) & " area(s)."
        rsSList!SpellLevel = -1
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
        
    If (lTranslateForgeFreeGloryChance(zPlayerRace, zPlayerClass) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "You have a race+class " & lTranslateForgeFreeGloryChance(zPlayerRace, zPlayerClass) & "% forge skill!"
        rsSList!SpellLevel = -2
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    If (lTranslateClassPlayerPetsAllowed(zPlayerClass) > 0) Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "You can train " & lTranslateClassPlayerPetsAllowed(zPlayerClass) & " pet(s)."
        rsSList!SpellLevel = -2
        rsSList!Value = 3 'Skill Cost
        rsSList.Update
    End If
    
    Select Case zPlayerClass
        Case "KN"
            rsSList.AddNew
            rsSList!PlayerID = lPlayerID
            rsSList!SpellName = "Natural: Pets can ::FORCE ASCEND:: before death."
            rsSList!SpellLevel = -1
            rsSList!Value = 1 'Skill Colours
            rsSList.Update
    End Select
    
    'everyone can mount a pet
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "Skill: can MOUNT a pet"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update

    If (zPlayerClass = "PA" Or zPlayerClass = "DR" Or zPlayerClass = "RA" Or zPlayerClass = "PL" Or zPlayerClass = "VE") Then
        rsSList.AddNew
        rsSList!PlayerID = lPlayerID
        rsSList!SpellName = "Skill: can HP (heal own pets in area)"
        rsSList!SpellLevel = -1
        rsSList!Value = 1 'Skill Colours
        rsSList.Update
    End If
    
    rsSList.AddNew
    rsSList!PlayerID = lPlayerID
    rsSList!SpellName = "(special): DodgeMAX[" & iTranslateClassDodgeTimes(zPlayerClass, zPlayerRace) & "] PARRY[" & iTranslateClassParryTimes(zPlayerClass, zPlayerRace) & "]"
    rsSList!SpellLevel = -1
    rsSList!Value = 1 'Skill Colours
    rsSList.Update
    
    Set rsSList = Nothing
    If (gblbClientMode(MyCLng(zPortID))) Then
        subSendMsg "&g<++=<SKILL LIST>=++>  [" & zTranslateClass(zPlayerClass) & " " & zTranslateRace(zPlayerRace) & "]         LEVEL / COST", zPortID '"<+<+============+>+>"
    Else
        subSendMsg "&gSKILL LIST"
    End If
    Set rsSList = MyDB.OpenRecordset("SELECT Value, SpellLevel, SpellName FROM tblTEMPPlayerSList WHERE (PlayerID=" & lPlayerID & ") ORDER BY Value, SpellLevel, SpellName;", dbOpenSnapshot) 'rsSList!SpellName = "" '25 long max
    Do While (Not rsSList.EOF)
        If (lPlayerLevel < MyCLng(rsSList!SpellLevel)) Then
            Select Case (MyCLng(rsSList!Value))
                Case 1
                    zColour = gblzFNGRE
                Case 2
                    zColour = gblzFNMAG
                Case 3
                    zColour = gblzFBRED
            End Select
        Else
            Select Case (MyCLng(rsSList!Value))
                Case 1
                    zColour = gblzFBGRE
                Case 2
                    zColour = gblzFBMAG
                Case 3
                    zColour = gblzFBRED
            End Select
        End If
        
        If (MyCLng(rsSList!SpellLevel) < 1) Then
            subSendMsg "&y" & strForceSize(MyCStr(rsSList!SpellName), 55, " ", "A") & "     (special)", zPortID
        Else
            subSendMsg zColour & strForceSize(MyCStr(rsSList!SpellName), 55, " ", "A") & "     " & MyCStr(rsSList!SpellLevel), zPortID
        End If
        rsSList.MoveNext
    Loop
    Set rsSList = Nothing
    
    If (gblbClientMode(MyCLng(zPortID))) Then
    If (lPlayerLevel < 15) Then
        subSendMsg "&yYou will only see the below message till level 15,", zPortID
        subSendMsg "&yFilter mode is available type FM ON/OFF", zPortID
        subSendMsg "&MSLIST " & gblzFNMAG & "is your short list and natural list of skills and " & vbCrLf & gblzFBMAG & "LEARN TREE " & gblzFNMAG & "is for your guild list. &y(HELP TEACHERS)", zPortID
        subSendMsg "&GAdditionally: HELP &g[SLIST/LEARN TREE/DAMAGE/COST/PRACTICE]", zPortID
        subSendMsg "&G              HELP &g[ROOM/BASIC COMMANDS/ADVANCED COMMANDS]", zPortID
        subSendMsg "&g              Type SS for a list of your starship and pilot commands.", zPortID
        subSendMsg "&g You can also use the above commands to peek other classes.", zPortID
        subSendMsg "&g ie. SLIST CLASSNAME RACENAME    or    LEARN CLASSNAME RACENAME", zPortID
        subSendMsg "&g     COST CLASSNAME RACENAME     or    DAMAGE CLASSNAME RACENAME       etc...", zPortID
        subSendMsg "&gYou can learn skills around the realm." & vbCrLf & "Skills are also available on items that your class is permitted to wear." & vbCrLf & gblzFNMAG & "LEARN TREE &glists the skills you can learn by class, race, and level." & vbCrLf & "PRACTICE will show you what you have learnt." & vbCrLf & "You also get bonus built in commands under" & vbCrLf & "HELP ROOM and HELP BASIC COMMANDS and HELP ADVANCED COMMANDS" & vbCrLf & "Your pilot commands are under SS and these do not require learn points.", zPortID
        subSendMsg "&gYou can also look at other classes and race skills." & vbCrLf & "LEARN CLASSNAME RACENAME or SLIST CLASSNAME RACENAME" & vbCrLf & gblzFNMAG & "     ie. LEARN MAGE ELF       SLIST ASSASSIN DWARF", zPortID
    End If
    subSendMsg "&g<++==--*--==++>", zPortID
    End If
    MyDB.Execute "DELETE PlayerID FROM tblTEMPPlayerSList WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subSLIST," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subReconnectPlayer(zPortID As String)
On Error GoTo Err_Check
    Dim zPlayerName As String
    Dim rsData As Recordset
    
    zPlayerName = ""
    
    'We get the logged in player name
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zPlayerName = MyCStr(rsData!PlayerName)
    End If
    Set rsData = Nothing
    
    If (Len(zPlayerName) > 0) Then
        Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayerLoggedIn WHERE (PlayerName='" & zPlayerName & "' AND PortID<>'" & zPortID & "');", dbOpenSnapshot) 'we group all the ports with the same player name so we can shut down those ports.
        Do While (Not rsData.EOF) 'we close down all the open ports except the new one the player is online with
            subSendMsg "&G" & vbCrLf & "Disconnecting your old port " & MyCStr(rsData!PortID), zPortID
            'closing port
            subShutdownPorts MyCStr(rsData!PortID)
            rsData.MoveNext
        Loop
        Set rsData = Nothing
        subSendMsg "&G" & vbCrLf & "Reconnecting . . .", zPortID
    End If
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subReconnectPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subClearCreatePlayerLoggedInPort(zPortID As String)
On Error GoTo Err_Check
    MyDB.Execute "DELETE PortID FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subClearCreatePlayerLoggedInPort," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zHTML(iShowPage As Integer) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = ""
    Select Case iShowPage
        Case Else 'this is the base page to get them started
            zReturn = zReturn & "<html>"
            zReturn = zReturn & "<head>"
            zReturn = zReturn & "<meta http-equiv=""Content-Language"" content=""en-us"">"
            zReturn = zReturn & "<meta http-equiv=""Content-Type"" content=""text/html; charset=windows-1252"">"
            zReturn = zReturn & "<meta name=""GENERATOR"" content=""Microsoft FrontPage 6.0"">"
            zReturn = zReturn & "<meta name=""ProgId"" content=""FrontPage.Editor.Document"">"
            'zReturn = zReturn & "<meta name=""description"" content=""FREE! " & gblzMUDName & " ( telnet://coa.servegame.com ) is a colorful text multiplayer universe online-game for the visually impaired and their family and friends that are fully sited. Learn more about Achelon Stargate City of Ages at " & zSystemConfig(20) & """>"
            'zReturn = zReturn & "<meta name=""keywords"" content=""Achelon Stargate City of Ages,stargateatlantisgame, stargate sg-1 game, stargate atlantis game, visually impaired. impaired visually, game for the visually impaired, entertainment for the blind,blind entertainment,games for the blind,blind people,kids blind,blind kids,blind children,accessible games,teaching blind,teaching the blind,blind game,blind games,games disabled,games for the disabled,cannot see games"">"
            'gblzMUDName lTotalPlayerOnline()
            zReturn = zReturn & "<title>Redirecting to " & gblzMUDName & " http://" & gblzMUDHomePageURL & "</title>"
            zReturn = zReturn & "</head>"
            zReturn = zReturn & "<body>"
            zReturn = zReturn & "<p>&nbsp;</p>"
            zReturn = zReturn & "<p><b><font color=""#800000"">Shortly you will be redirected to our homepage."
            zReturn = zReturn & "<p>&nbsp;</p>"
            zReturn = zReturn & "<p>~ACHELON STARGATE CITY OF AGES~</p>"
            zReturn = zReturn & "<p>" & gblzMUDName & " currently has " & lTotalPlayersOnline() & " players online.</p>"
            zReturn = zReturn & "<a href=""http://" & gblzMUDHomePageURL & """>http://" & gblzMUDHomePageURL & "</a></font></b></p>"
            zReturn = zReturn & "<script LANGUAGE=""JavaScript1.2"">"
            zReturn = zReturn & "window.location.href= ""http://" & gblzMUDHomePageURL & """;"
            zReturn = zReturn & "</script>"
            zReturn = zReturn & "</body>"
            zReturn = zReturn & "</html>"
    End Select
    zHTML = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zHTML," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bIPHeader(zUserData As String, iPortID As Integer) As Boolean
On Error Resume Next
    'if zUserData shows these lines of info we send them html back
        'GET / HTTP/1.1
        'Accept: */*
        'Accept-Language: en -us
        'Accept-Encoding: gzip , deflate
        'User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)
        'Host: 198.53.108.148:23
        'Connection: Keep-Alive
    Dim bHeader As Boolean
    Dim bTelnetMode As Boolean
    
    bTelnetMode = (gbliFlow(iPortID) > 11) 'The player has logged in because only a player can get past the first name
    If (Not bTelnetMode) Then
        'We check the header to see if its a HTTP request
        bHeader = (Mid(zUserData, 1, Len(gblcstzDetectCode)) = gblcstzDetectCode)
    Else
        bHeader = False
    End If
    bIPHeader = bHeader
End Function
Public Function bHTTPHeader(zUserData As String, iPortID As Integer) As Boolean
On Error Resume Next
    'if zUserData shows these lines of info we send them html back
        'GET / HTTP/1.1
        'Accept: */*
        'Accept-Language: en -us
        'Accept-Encoding: gzip , deflate
        'User-Agent: Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1)
        'Host: 198.53.108.148:23
        'Connection: Keep-Alive
    Dim bHeader As Boolean
    Dim bTelnetMode As Boolean
    
    bTelnetMode = (gbliFlow(iPortID) > 11) 'The player has logged in because only a player can get past the first name
    If (Not bTelnetMode) Then
        'We check the header to see if its a HTTP request
        bHeader = (Mid(zUserData, 1, 10) = "GET / HTTP")
        If (Not bHeader) Then bHeader = (Mid(zUserData, 1, 7) = "Accept:")
        If (Not bHeader) Then bHeader = (Mid(zUserData, 1, 7) = "Accept-")
        If (Not bHeader) Then bHeader = (Mid(zUserData, 1, 5) = "User-")
        If (Not bHeader) Then bHeader = (Mid(zUserData, 1, 5) = "Host:")
        If (Not bHeader) Then bHeader = (Mid(zUserData, 1, 11) = "Connection:")
    Else
        bHeader = False
    End If
    bHTTPHeader = bHeader
End Function
Public Sub subIfRequiredCrownTheNewAdministrator()
On Error GoTo Err_Check 'make the 1st player in the system and crown the player KING ADMIN
    Dim rsPlayer As Recordset
    Dim lTotalPlayers As Long
    Dim zLine As String
    
    lTotalPlayers = lngSQLRecordCount("SELECT PlayerID FROM tblPlayer;")
    If (lTotalPlayers < 1) Then 'not a single player in the system?
        MyDB.Execute "UPDATE tblPlayer SET ImmortalLevel=100, ImmortalSupervisor=True;", dbFailOnError
        subSendMsgInfoChannel "&wALL HAIL THE NEWEST &YKING &wof &PCity of Ages&w! Thats YOU btw :)"
    End If
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subIfRequiredCrownTheNewAdministrator," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSetEntireMUDAreasToEitherStaticOrDynamic(zMode As String)
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim rsArea As Recordset
    
    Set rsArea = MyDB.OpenRecordset("SELECT X,Y,Z FROM tblArea;", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        Do While (Not rsArea.EOF)
            lOX = MyCLng(rsArea!x): lOY = MyCLng(rsArea!y): lOZ = MyCLng(rsArea!z)
            Select Case UCase(zMode) 'This doesnt modify anything other than to calculate EXITS (player commands 'TWIST' and 'TUG' and those ones will fix the area now - so static might be the way to go now
                Case "S"
                    subAreaSetExitsDynamicStaticToggle "S", "", lOX, lOY, lOZ, False
                Case Else 'dynamic - slower but assures the mud is in good order
                    subAreaSetExitsDynamicStaticToggle "D", "", lOX, lOY, lOZ, False
            End Select
            rsArea.MoveNext
        Loop
    End If
    Set rsArea = Nothing
End Sub
Public Function lReturnTranslateAimlevel(zRaceType As String, zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Dim lRace As Long
    Dim lClass As Long
    
    lReturn = 0
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 15
        Case "CL"
            lReturn = 5
        Case "DR"
            lReturn = 4
        Case "BA"
            lReturn = 5
        Case "MO"
            lReturn = 30
        Case "AS"
            lReturn = 1
        Case "GY"
            lReturn = 1
        Case "TH"
            lReturn = 12
        Case "WA"
            lReturn = 4
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 0
        Case "KN"
            lReturn = 7
        Case "PA"
            lReturn = 1
        Case "WE"
            lReturn = 50
        Case "VA"
            lReturn = 50
        Case "PL", "VE"
            lReturn = 15
        Case "CY"
            lReturn = 0
    End Select
    lClass = lReturn
    
    lReturn = 0
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 1
        Case "HAL"
            lReturn = 1
        Case "OGE"
            lReturn = 10
        Case "ELF"
            lReturn = 0
        Case "ORC"
            lReturn = 5
        Case "FEL"
            lReturn = 5
        Case "PIX"
            lReturn = 1
        Case "HUM"
            lReturn = 5
        Case "MIN"
            lReturn = 15
        Case "DWA"
            lReturn = 12
        Case "TRO"
            lReturn = 15
        Case "DRA"
            lReturn = 3
        Case "UND"
            lReturn = 4
    End Select
    lRace = lReturn
    
    lReturnTranslateAimlevel = lClass + lRace 'chrisma test charisma
End Function
Public Function lReturnTranslateCharismaticBonus(zRaceType As String, zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Dim lRace As Long
    Dim lClass As Long
    
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 99
        Case "CL"
            lReturn = 98
        Case "DR"
            lReturn = 50
        Case "BA"
            lReturn = 45
        Case "MO"
            lReturn = 13
        Case "AS"
            lReturn = 7
        Case "GY"
            lReturn = 41
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 4
        Case "GL"
            lReturn = 8
        Case "RA"
            lReturn = 31
        Case "KN"
            lReturn = 89
        Case "PA"
            lReturn = 97
        Case "WE"
            lReturn = 8
        Case "VA"
            lReturn = 91
        Case "PL", "VE"
            lReturn = 29
        Case "CY"
            lReturn = 53
    End Select
    lClass = lReturn
    
    lReturn = 20
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 30
        Case "HAL"
            lReturn = 65
        Case "OGE"
            lReturn = 5
        Case "ELF"
            lReturn = 99
        Case "ORC"
            lReturn = 11
        Case "FEL"
            lReturn = 98
        Case "HUM"
            lReturn = 98
        Case "MIN"
            lReturn = 19
        Case "DWA"
            lReturn = 49
        Case "TRO"
            lReturn = 4
        Case "DRA"
            lReturn = 33
        Case "PIX"
            lReturn = 84
        Case "UND"
            lReturn = 1
    End Select
    lRace = lReturn
    
    lReturnTranslateCharismaticBonus = lClass + lRace 'chrisma test charisma
End Function
Public Function lReturnTranslateGoldMiserRaceClass(zRaceType As String, zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Dim lRace As Long
    Dim lClass As Long
    
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 5
        Case "CL"
            lReturn = 10
        Case "DR"
            lReturn = 6
        Case "BA"
            lReturn = 12
        Case "MO"
            lReturn = 1
        Case "AS"
            lReturn = 3
        Case "GY"
            lReturn = 8
        Case "TH"
            lReturn = 14
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 5
        Case "KN"
            lReturn = 1
        Case "PA"
            lReturn = 14
        Case "WE"
            lReturn = 5
        Case "VA"
            lReturn = 5
        Case "PL", "VE"
            lReturn = 5
        Case "CY"
            lReturn = 15
    End Select
    lClass = lReturn
    
    lReturn = 4
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 5
        Case "HAL"
            lReturn = 5
        Case "OGE"
            lReturn = 12
        Case "ELF"
            lReturn = 2
        Case "ORC"
            lReturn = 15
        Case "FEL"
            lReturn = 15
        Case "PIX"
            lReturn = 18
        Case "HUM"
            lReturn = 7
        Case "MIN"
            lReturn = 8
        Case "DWA"
            lReturn = 6
        Case "TRO"
            lReturn = 16
        Case "DRA"
            lReturn = 16
        Case "UND"
            lReturn = 1
    End Select
    lRace = lReturn
    
    lReturnTranslateGoldMiserRaceClass = lClass + lRace 'chrisma test charisma
End Function
Public Function lReturnTranslateForgerMaxPercent(zRaceType As String, zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Dim lRace As Long
    Dim lClass As Long
    
    lReturn = 0
    'lower the value the better
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 5
        Case "CL"
            lReturn = 30
        Case "DR"
            lReturn = 5
        Case "BA"
            lReturn = 10
        Case "MO"
            lReturn = 13
        Case "AS"
            lReturn = 10
        Case "GY"
            lReturn = 7
        Case "TH"
            lReturn = 7
        Case "WA"
            lReturn = 20
        Case "GL"
            lReturn = 24
        Case "RA"
            lReturn = 16
        Case "KN"
            lReturn = 20
        Case "PA"
            lReturn = 30
        Case "WE"
            lReturn = 0
        Case "VA"
            lReturn = 13
        Case "PL", "VE"
            lReturn = 15
        Case "CY"
            lReturn = 16
    End Select
    lClass = lReturn
    
    lReturn = 4
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 10
        Case "HAL"
            lReturn = 10
        Case "OGE"
            lReturn = 2
        Case "ELF"
            lReturn = 8
        Case "ORC"
            lReturn = 9
        Case "FEL"
            lReturn = 1
        Case "PIX"
            lReturn = 3
        Case "HUM"
            lReturn = 12
        Case "MIN"
            lReturn = 20
        Case "DWA"
            lReturn = 20
        Case "TRO"
            lReturn = 25
        Case "DRA"
            lReturn = 12
        Case "UND"
            lReturn = 3
    End Select
    lRace = lReturn
    
    lReturnTranslateForgerMaxPercent = lClass + lRace 'the lower the better
End Function
Public Function lReturnTranslateDreamBonus(zRaceType As String, zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Dim lRace As Long
    Dim lClass As Long
    
    lReturn = 4
    'lower the value the better
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 3
        Case "CL"
            lReturn = 4
        Case "DR"
            lReturn = 5
        Case "BA"
            lReturn = 10
        Case "MO"
            lReturn = 13
        Case "AS"
            lReturn = 1
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 4
        Case "GL"
            lReturn = 8
        Case "RA"
            lReturn = 3
        Case "KN"
            lReturn = 4
        Case "PA"
            lReturn = 3
        Case "WE"
            lReturn = 20
        Case "VA"
            lReturn = 18
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 2
    End Select
    lClass = lReturn
    
    lReturn = 4
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 10
        Case "HAL"
            lReturn = 10
        Case "OGE"
            lReturn = 2
        Case "ELF"
            lReturn = 8
        Case "ORC"
            lReturn = 1
        Case "FEL"
            lReturn = 2
        Case "PIX"
            lReturn = 1
        Case "HUM"
            lReturn = 10
        Case "MIN"
            lReturn = 1
        Case "DWA"
            lReturn = 10
        Case "TRO"
            lReturn = 4
        Case "DRA"
            lReturn = 3
        Case "PIX"
            lReturn = 1
        Case "UND"
            lReturn = 3
    End Select
    lRace = lReturn
    
    lReturnTranslateDreamBonus = lClass + lRace 'the lower the better
End Function
