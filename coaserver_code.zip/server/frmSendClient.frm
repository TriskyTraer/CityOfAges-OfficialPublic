VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmSendDataBase 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "TFTPClient"
   ClientHeight    =   2265
   ClientLeft      =   285
   ClientTop       =   570
   ClientWidth     =   4695
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2265
   ScaleWidth      =   4695
   ShowInTaskbar   =   0   'False
   Begin VB.DirListBox Dir1 
      BackColor       =   &H00EFF7F7&
      Height          =   1890
      Left            =   240
      TabIndex        =   6
      Top             =   3960
      Visible         =   0   'False
      Width           =   2115
   End
   Begin VB.Timer ctlTimerChecksSend 
      Left            =   4200
      Top             =   360
   End
   Begin VB.TextBox txtIP 
      Enabled         =   0   'False
      Height          =   285
      Left            =   1680
      TabIndex        =   11
      Top             =   720
      Width           =   2775
   End
   Begin VB.TextBox Text1 
      Height          =   315
      Left            =   180
      TabIndex        =   9
      Text            =   "C:\CoASent.dnl"
      Top             =   4080
      Visible         =   0   'False
      Width           =   4335
   End
   Begin VB.DriveListBox Drive1 
      BackColor       =   &H00EFF7F7&
      Height          =   315
      Left            =   180
      TabIndex        =   5
      Top             =   2760
      Visible         =   0   'False
      Width           =   4335
   End
   Begin VB.CommandButton Command3 
      BackColor       =   &H00DEE7EF&
      Caption         =   "Send File To Server"
      Height          =   795
      Left            =   2400
      Picture         =   "frmSendClient.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   3120
      Visible         =   0   'False
      Width           =   2115
   End
   Begin VB.CommandButton Command1 
      BackColor       =   &H00DEE7EF&
      Caption         =   "Connect To Server"
      Height          =   795
      Left            =   180
      Picture         =   "frmSendClient.frx":0442
      Style           =   1  'Graphical
      TabIndex        =   2
      Top             =   3120
      Visible         =   0   'False
      Width           =   2115
   End
   Begin MSWinsockLib.Winsock WskClient 
      Left            =   4200
      Top             =   0
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin VB.FileListBox File1 
      BackColor       =   &H00EFF7F7&
      Height          =   1650
      Left            =   2280
      TabIndex        =   7
      Top             =   4080
      Visible         =   0   'False
      Width           =   2115
   End
   Begin VB.Label lbFileSend 
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "File Sent:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000080&
      Height          =   675
      Left            =   120
      TabIndex        =   1
      Top             =   1440
      Width           =   4335
   End
   Begin VB.Label Label4 
      BackStyle       =   0  'Transparent
      Caption         =   "Remote Destination"
      ForeColor       =   &H00000080&
      Height          =   255
      Left            =   180
      TabIndex        =   10
      Top             =   780
      Width           =   1635
   End
   Begin VB.Label lblInfo 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Not Connected"
      BeginProperty Font 
         Name            =   "Courier"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   240
      TabIndex        =   8
      Top             =   240
      Width           =   3975
   End
   Begin VB.Label Label3 
      BackColor       =   &H00000000&
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Label3"
      Height          =   555
      Left            =   180
      TabIndex        =   4
      Top             =   120
      Width           =   4215
   End
   Begin VB.Label lbByteSend 
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Bytes Sent:"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000080&
      Height          =   315
      Left            =   120
      TabIndex        =   0
      Top             =   1080
      Width           =   4335
   End
End
Attribute VB_Name = "frmSendDataBase"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Const cstzDestinationFile = "c:\coasent.mdb"
'we remotely activate the timer
'the timer goes off after 15 seconds
'when the timer goes off it looks at the txtIP.text
'if the IP is valid enough then we send the file
Const cstlImmortalLevelView = 99
Dim SrcPath As String
Dim DstPath As String
Dim IsReceived As Boolean
Private Sub subSendFile()
On Error GoTo Err_Check:
    Dim BufFile As String
    Dim LnFile As Long
    Dim nLoop As Long
    Dim nRemain As Long
    Dim Cn As Long
    
    ctlTimerChecksSend.Interval = 0
    LnFile = MyFileLen(SrcPath)
    
    If (LnFile > 8192) Then
        nLoop = Fix(LnFile / 8192)
        nRemain = LnFile Mod 8192
    Else
        nLoop = 0
        nRemain = LnFile
    End If
    
    If (LnFile = 0) Then
        subSystemMessageToImmortals gblzFBRED & "Send Database: Invalid Source File", cstlImmortalLevelView
    Else
        Open SrcPath For Binary As #1
        If (nLoop > 0) Then
            For Cn = 1 To nLoop
                BufFile = String(8192, " ")
                Get #1, , BufFile
                WskClient.SendData BufFile
                IsReceived = False
                'If (lRandom(20) = 1) Then subSystemMessageToImmortals gblzFBRED & "Looping: Bytes Sent: " & Cn * 81092 & " Of " & LnFile, cstlImmortalLevelView
                lbByteSend.Caption = "Bytes Sent: " & Cn * 81092 & " Of " & LnFile
                lbByteSend.Refresh
                While IsReceived = False
                    DoEvents
                Wend
            Next
            If nRemain > 0 Then
                BufFile = String(nRemain, " ")
                Get #1, , BufFile
                WskClient.SendData BufFile
                IsReceived = False
                'If (lRandom(20) = 1) Then subSystemMessageToImmortals gblzFBRED & "Remaining: Bytes Sent: " & Cn * 81092 & " Of " & LnFile, cstlImmortalLevelView
                lbByteSend.Refresh
                While IsReceived = False
                    DoEvents
                Wend
            End If
        Else
            BufFile = String(nRemain, " ")
            Get #1, , BufFile
            WskClient.SendData BufFile
            IsReceived = False
            While IsReceived = False
                DoEvents
            Wend
        End If
        WskClient.SendData "Msg_Eof_"    'end of file tag
        Close #1
        txtIP.Text = ""
        subSystemMessageToImmortals gblzFBRED & "File transmitted.", cstlImmortalLevelView
    End If
    'ctlTimerChecksSend.Interval = 30000
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendFile," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
    txtIP.Text = ""
    'ctlTimerChecksSend.Interval = 30000
    frmSendDataBase.Hide
End Sub

'Private Sub Command1_Click()
'On Error Resume Next
'    ConnectToServer
'End Sub
Private Sub ctlTimerChecksSend_Timer()
On Error Resume Next
    Dim bOkay As Boolean
    ctlTimerChecksSend.Interval = 0 'we turn off the timer trigger we are done with it
    WskClient.Protocol = sckTCPProtocol 'we make sure the protocol is correct
    
    bOkay = False
    If (Len(txtIP.Text) > 0) Then
        If (InStr(txtIP.Text, ".") > 0) Then
            bOkay = True
        End If
    End If
    
    If (bOkay) Then
        subSendDatabaseToServer
    Else
        subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "The Internet Protocol you entered [" & MyCStr(txtIP.Text) & " ] is invalid.", cstlImmortalLevelView
        txtIP.Text = ""
        'ctlTimerChecksSend.Interval = 30000
    End If
End Sub
Private Sub Dir1_Change()
On Error Resume Next
    File1.Path = Dir1.Path
End Sub
'Private Sub Drive1_Change()
'On Error Resume Next
'    Dir1.Path = Left(Drive1.Drive, 2) & "\"
'End Sub
'Private Sub File1_Click()
'On Error Resume Next
'    SrcPath = File1.Path
'    If Right(SrcPath, 1) <> "\" Then
'        SrcPath = SrcPath & "\"
'    End If
'    SrcPath = SrcPath & File1.FileName
'    'default destination path
'    'if client and server are running on
'    'the same machine
'    Text1.Text = "C:\" & File1.FileName
'    'to prevent overwrite source destination file
'    'when client and server are running on
'    'the same machine
'    If Text1.Text = SrcPath Then
'        Text1.Text = "C:\file." & Right(File1.FileName, 3)
'    End If
'    lbFileSend.Caption = SrcPath
'End Sub
Private Sub Form_Load()
On Error Resume Next
    WskClient.Protocol = sckTCPProtocol
End Sub
'Private Sub Text1_Change()
'On Error Resume Next
'    DstPath = Text1.Text
'End Sub
Private Sub WskClient_Close()
On Error Resume Next
    lblInfo.Caption = "~Connection Closed~"
    subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Connection Closed,  and no longer connected", cstlImmortalLevelView
    WskClient.Close
    frmSendDataBase.Hide
End Sub
Private Sub WskClient_Connect()
On Error Resume Next
    lblInfo.Caption = "*Connected*"
    subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Connected", cstlImmortalLevelView
End Sub
Private Sub WskClient_DataArrival(ByVal lBytesTotal As Long)
On Error Resume Next
    Dim recBuffer As String
    WskClient.GetData recBuffer
    Select Case Left(recBuffer, 7)
    Case "Msg_Rec"  'Block Received
        IsReceived = True
        subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Complete! Transmission recieved, bytes at: " & lBytesTotal & ".", cstlImmortalLevelView
        frmSendDataBase.Hide
    Case "Msg_OkS"  'Ok you can begin to send file
        subSendFile
    Case "Msg_Res"  'bad block
        subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Transmission Error. Bad block, bytes at: " & lBytesTotal & ".", cstlImmortalLevelView
        frmSendDataBase.Hide
        'implement this case
    Case "Msg_Err"  'error
        subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Transmission Error. Bytes at: " & lBytesTotal & ".", cstlImmortalLevelView
        frmSendDataBase.Hide
        'implement this case
    End Select
End Sub
Private Sub WskClient_Error(ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
On Error Resume Next
    If (Number <> 0) Then
        lblInfo.Caption = "Not Connected"
        subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Not Connected", cstlImmortalLevelView
    End If
End Sub
Private Sub WskClient_SendComplete()
On Error Resume Next
    WskClient.SendData "Msg_Eof_"    'end of file tag
End Sub
Private Sub WskClient_SendProgress(ByVal BytesSent As Long, ByVal BytesRemaining As Long)
On Error Resume Next
    lbByteSend.Caption = "Bytes Sent: " & BytesSent * 81092 & " Of " & BytesRemaining
    lbByteSend.Refresh
    'If (lRandom(20) = 1) Then subSystemMessageToImmortals gblzFBRED & "Sending data: Bytes Sent: " & BytesSent * 81092 & " Of " & BytesRemaining, cstlImmortalLevelView
    'DoEvents
End Sub
Private Function bConnectToServer() As Boolean
On Error Resume Next
    Dim lError As Long
    WskClient.Connect MyCStr(txtIP.Text), 1001
    lError = Err
    If (lError <> 0) Then WskClient.Close
    bConnectToServer = (lError = 0)
End Function
Private Sub subSendDatabaseToServer()
On Error GoTo Err_Check
    Dim lSearchName As Long
    subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Connecting to the server...", cstlImmortalLevelView
    If (bConnectToServer()) Then
        basDelay 3000
        lSearchName = 0
        SrcPath = "C:\COA" & MyCStr(lRandom(cstlTotalCoaBackupsPossible)) & ".MDB"
        Do While (lSearchName <= cstlTotalCoaBackupsPossible And MyFileLen(SrcPath) = 0)
            lSearchName = lSearchName + 1
            SrcPath = "C:\COA" & MyCStr(lSearchName) & ".MDB"
        Loop
        If (MyFileLen(SrcPath) <> 0) Then 'double check
            subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Sending file " & SrcPath & " and will arrive as " & cstzDestinationFile, cstlImmortalLevelView
            lbFileSend.Caption = SrcPath
            'send to server the path and file name to save this file as
            WskClient.SendData "Msg_Dst_" & cstzDestinationFile
        Else
            subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Files COA1, COA2, COA3(.MDB) not found, use IMMO BACKUP first...Last file checked " & SrcPath, cstlImmortalLevelView
            txtIP.Text = ""
            lbFileSend.Caption = ""
        End If
    Else
        subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "subSendDatabaseToServer," & vbCrLf & "Could not connect to the server.", cstlImmortalLevelView
    End If
    Exit Sub
Err_Check:
    subSystemMessageToImmortals gblzFNRED & "(immortal ear) " & gblzFNBLA & "Failed last attempt: subSendDatabaseToServer," & vbCrLf & "You need to use IMMO BACKUP first so there is a file to download." & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description & vbCrLf & "Source file: " & SrcPath, cstlImmortalLevelView
    txtIP.Text = ""
    'ctlTimerChecksSend.Interval = 30000
    frmSendDataBase.Hide
End Sub
