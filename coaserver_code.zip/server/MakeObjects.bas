Attribute VB_Name = "modMakeObjects"
Option Explicit
Public Function lDuplicateObject(lObjectID As Long, lPlayerID As Long, lPlayerLevel As Long, bWorstMobRoll As Boolean, bBestPlayerRoll As Boolean, bStolen As Boolean, lHoldDevalueDivider As Long) As Long 'lDuplicateItem < just a keyword to help find this place :)
On Error GoTo Err_Check
'THIS WILL INSERT THE ITEM INTO THE PLAYERIDs INVENTORY when PLAYERIDs<>0
'NOTE:  Unless the player is over level 19 we do not treasure or rare items
'We dont copy the  VisibleLevel object field EVER!
'See Also: subMakeCorpse                      subCorpseRottingRounds       and
'          subPutTogetherTwoObjects
'The object will appear in the player's  inventory.
'THIS MUST BE rsCopyObject!Status = 2 'with player!
    Const cstlRarePlayerLevel = 19
    Const lCX = 0
    Const lCY = -1
    Const lCZ = -1000
    Dim bTest As Boolean
    Dim lPlayerStockID As Long
    Dim lHoldLevelRequirement As Long
    Dim rsCopyObject As Recordset
    Dim rsCorpse As Recordset
    Dim lTreasureLevel As Long
    Dim lRareLevel As Long
    Dim lNewObjectID As Long
    Dim lInitativeChance As Long
    'Modified Variables to load with
    Dim lWarmthLevel As Long
    Dim lThickness As Long
    Dim lPokerCardType As Long
    Dim zWeaponType As String
    Dim lStr As Long
    Dim lInt As Long
    Dim lWis As Long
    Dim lDex As Long
    Dim lCon As Long
    Dim lCHA As Long
    Dim lLUC As Long
    Dim lHP As Long
    Dim lAC As Long
    Dim lPAC As Long
    Dim lPACMax As Long
    Dim lDamageReduction As Long
    Dim lOriginalMobID As Long
    Dim lRottingRounds As Long
    Dim lEssence As Long
    Dim lMana As Long
    Dim lSoul As Long
    Dim lMove As Long
    Dim lRegenerationLevel As Long
    Dim lSSRepairLevel As Long
    Dim iCraftingPreserveYN As Integer
    Dim lMagicFind As Long
    Dim lMagicFindBase As Long
    Dim lEdibleSpellNo As Long
    Dim lCriticalHR As Long
    Dim lCriticalHRChance As Long
    Dim lCriticalDR As Long
    Dim lCriticalDRChance As Long
    Dim lNumAttRnd As Long
    Dim lCHITROLL As Long
    Dim lAverageDamage As Long
    Dim lIndestructibleMobLv As Long
    Dim lCriticalBlindChance As Long
    Dim lObjectActivateSpellNo As Long
    Dim lObjectActivateSkillNo As Long
    Dim lLanguageCell As Long
    Dim lSlayChance As Long
    Dim lIASChance As Long
    Dim lWeaponBlockPercent As Long
    Dim zAllAttributes As String
    Dim lWeightMax As Long
    Dim lMoveReductionInertialInhibitor As Long
    
    Dim lAbsorbsSameLeft As Long
    Dim lTotalElementalEnchants As Long
    Dim lFireElementalDamageMAX As Long
    Dim lLightningElementalDamageMAX  As Long
    Dim lPoisonElementalDamageMAX  As Long
    Dim lColdElementalDamageMAX  As Long
    Dim lFireElementalDamage As Long
    Dim lLightningElementalDamage As Long
    Dim lColdElementalDamage As Long
    Dim lPoisonElementalDamage As Long
    
    Dim lMissileAverageDamage As Long
    Dim lMissileGroupAmount As Long
    Dim lMagazineMAX As Long
    
    Dim lQuaffable As Long
    Dim lQuaffLiquorLevel As Long
    Dim lQuaffSpellNo As Long
    Dim lScrollNo As Long
    
    Dim lPhaserLevel As Long
    Dim lPhaserInvokes As Long
    
    Dim lWearReqStr As Long
    Dim lWearReqInt As Long
    Dim lWearReqWis As Long
    Dim lWearReqDex As Long
    Dim lWearReqCon As Long
    Dim lWearReqCha As Long
    Dim lWearReqLuc As Long
    Dim lWearReqHP As Long
    Dim lWearReqAC As Long
    Dim lWearReqEssence As Long
    Dim lWearReqMana As Long
    Dim lWearReqSoul As Long
    Dim lWearReqMove As Long
    Dim lKeyRing As Long
    Dim lKey As Long
    Dim zWeaponSkillBackStabClass As String
    Dim zColourGlowing As String
    Dim zMarkingRune As String
    Dim zMarkingGlowing As String
    Dim zMarkingHumming As String
    Dim lIncreasesHPPercent As Long
    Dim lIncreasesACPercent As Long
    Dim lIncreasesHRPercent As Long
    Dim lIncreasesDRPercent As Long
        
    Dim lLeechingHP As Long
    Dim lLeechingEssence As Long
    Dim lLeechingSoul As Long
    Dim lLeechingMana As Long
    Dim lLeechingMove As Long
    
    Dim lDurabilityMAX As Long
    Dim lLevelRequirement As Long
    Dim lDevalueDivider As Long
    
    Dim lHeightRequirement As Long
    Dim lHeight As Long
    Dim lWidth As Long
    Dim lWeight As Long
    Dim lLength As Long
    
    Dim lGoldDropChance As Long
    Dim lArmourAbsorbtionChance As Long
    
    Dim lFishingRodLevel As Long
    Dim lLiquidType As Long
    Dim lSolidType As Long
    Dim lFishType As Long
    Dim lMeatType As Long
    Dim lVeggyType As Long
    Dim lFruitType As Long
    Dim lAnimalMineralVegitableFruitID As Long
    Dim lAnimalMineralVegitableFruitGroupNumber As Long
    Dim lQuaffMorphLaster As Long
    
    Dim lGraphicsID As Long
    lNewObjectID = 0
    If (Not bStolenItembyObjectID(lObjectID)) Then
    MyDB.Execute "UPDATE tblObject SET Duplicated = [Duplicated] + 1, DuplicatedDate = Now() WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
    If (lRandom(2300) = 1) Then MyDB.Execute "UPDATE tblObject SET Duplicated = CLng([Duplicated] / 4) WHERE (Duplicated>9999999);", dbFailOnError  'this just keeps things in check, we dont want an Overflow error because "long" only counts so far.
    
    Set rsCorpse = MyDB.OpenRecordset("SELECT * FROM tblObject WHERE (ObjectID=" & lObjectID & " AND PlayerID=0 AND ReturnPlayerID=0 AND Burried=False);", dbOpenDynaset)
    If (Not rsCorpse.EOF) Then 'OBJECT COPY FOR PLAYER
        If (bStolen Or lRandom(50) = 1) Then
            lDevalueDivider = lRandom(3) + lHoldDevalueDivider + 1 'stolen items are worth less gold because thats kinda an exploit
        Else
            lDevalueDivider = lHoldDevalueDivider
        End If
        lPhaserLevel = 0
        lPhaserInvokes = 0
        
        lLevelRequirement = 0
        lRareLevel = 0
        lTreasureLevel = 0
        lStr = 0
        lWeight = 0
        lWeightMax = 0
        lInt = 0
        lWis = 0
        lAbsorbsSameLeft = 0
        lDex = 0
        lCon = 0
        lCHA = 0
        lLUC = 0
        lHP = 0
        lAC = 0
        lPAC = 0
        lPACMax = 0
        lDamageReduction = 0
        lEssence = 0
        lMana = 0
        lSoul = 0
        lMove = 0
        lPokerCardType = 0
        lRegenerationLevel = 0
        iCraftingPreserveYN = 0
        lMagicFind = 0
        lMagicFindBase = 0
        lCriticalHR = 0
        lCriticalHRChance = 0
        lCriticalDR = 0
        lCriticalDRChance = 0
        lIncreasesHPPercent = 0
        lIncreasesACPercent = 0
        lIncreasesHRPercent = 0
        lIncreasesDRPercent = 0
        lWarmthLevel = 0
        lKeyRing = 0
        lKey = 0
        lLeechingHP = 0
        lLeechingEssence = 0
        lLeechingSoul = 0
        lLeechingMana = 0
        lLeechingMove = 0
        lGoldDropChance = 0
        lArmourAbsorbtionChance = 0
        
        lSSRepairLevel = 0
        lNumAttRnd = 0
        lCHITROLL = 0
        lAverageDamage = 0
        lIndestructibleMobLv = 0
        lCriticalBlindChance = 0
        lObjectActivateSpellNo = 0
        lObjectActivateSkillNo = 0
        lLanguageCell = 0
        lSlayChance = 0
        lIASChance = 0
        lWeaponBlockPercent = 0
        zWeaponSkillBackStabClass = ""
        lMoveReductionInertialInhibitor = 0
        
        lDurabilityMAX = 0
        lEdibleSpellNo = 0
        lWearReqStr = 0
        lWearReqInt = 0
        lWearReqWis = 0
        lWearReqDex = 0
        lWearReqCon = 0
        lWearReqCha = 0
        lWearReqLuc = 0
        lWearReqHP = 0
        lWearReqAC = 0
        lWearReqEssence = 0
        lWearReqMana = 0
        lWearReqSoul = 0
        lWearReqMove = 0
        
        lScrollNo = 0
        lQuaffSpellNo = 0
        lQuaffMorphLaster = 0
        lQuaffLiquorLevel = 0
        lQuaffable = 0
        
        lTotalElementalEnchants = 0
        lFireElementalDamage = 0
        lLightningElementalDamage = 0
        lColdElementalDamage = 0
        lPoisonElementalDamage = 0
        lFireElementalDamageMAX = 0
        lLightningElementalDamageMAX = 0
        lPoisonElementalDamageMAX = 0
        lColdElementalDamageMAX = 0
        
        zColourGlowing = ""
        zMarkingRune = ""
        zMarkingGlowing = ""
        zMarkingHumming = ""
        zWeaponType = ""
        zAllAttributes = ""
        
        lHeightRequirement = 0
        lHeight = 0
        lWidth = 0
        lLength = 0
        
        lFishingRodLevel = 0
        lLiquidType = 0
        lSolidType = 0
        lFishType = 0
        lMeatType = 0
        lVeggyType = 0
        lFruitType = 0
        lAnimalMineralVegitableFruitID = 0
        lAnimalMineralVegitableFruitGroupNumber = 0
        lGraphicsID = 0
        
        'START
        lPlayerStockID = MyCLng(rsCorpse!PlayerStockID)
        lWarmthLevel = MyCLng(rsCorpse!WarmthLevel)
        lKeyRing = MyCLng(rsCorpse!KeyRing)
        lKey = MyCLng(rsCorpse!Key)
        zWeaponType = MyCStr(rsCorpse!WeaponType)
        lInitativeChance = MyCLng(rsCorpse!InitativeChance)
        lLevelRequirement = MyCLng(rsCorpse!LevelRequirement)
        lEdibleSpellNo = MyCLng(rsCorpse!EdibleSpellNo)
        lDurabilityMAX = MyCLng(rsCorpse!DurabilityMAX)
        lNumAttRnd = MyCLng(rsCorpse!NumAttRnd) 'if this was random that would be HARD so dont do it :)
        lWearReqStr = MyCLng(rsCorpse!WearReqSTR)
        lWearReqInt = MyCLng(rsCorpse!WearReqINT)
        lWearReqWis = MyCLng(rsCorpse!WearReqWIS)
        lWearReqDex = MyCLng(rsCorpse!WearReqDEX)
        lWearReqCon = MyCLng(rsCorpse!WearReqCON)
        lWearReqCha = MyCLng(rsCorpse!WearReqCHA)
        lWearReqLuc = MyCLng(rsCorpse!WearReqLUC)
        lWearReqAC = MyCLng(rsCorpse!WearReqAC)
        lWearReqHP = MyCLng(rsCorpse!WearReqHP)
        lWearReqEssence = MyCLng(rsCorpse!WearReqEssence)
        lWearReqMana = MyCLng(rsCorpse!WearReqMana)
        lWearReqSoul = MyCLng(rsCorpse!WearReqSoul)
        lWearReqMove = MyCLng(rsCorpse!WearReqMove)
        lRottingRounds = MyCLng(rsCorpse!RottingRounds)
        lOriginalMobID = MyCLng(rsCorpse!OriginalMobID)
        lQuaffable = MyCLng(rsCorpse!Quaffable)
        lQuaffSpellNo = MyCLng(rsCorpse!QuaffSpellNo)
        lQuaffLiquorLevel = MyCLng(rsCorpse!QuaffLiquorLevel)
        lQuaffMorphLaster = MyCLng(rsCorpse!QuaffMorphLaster)
        lScrollNo = MyCLng(rsCorpse!ScrollNo)
        lThickness = MyCLng(rsCorpse!Thickness)
        lCHITROLL = MyCLng(rsCorpse!CHITROLL)
        
        lGoldDropChance = MyCLng(rsCorpse!GoldDropChance)
        lArmourAbsorbtionChance = MyCLng(rsCorpse!ArmourAbsorbtionChance)
        
        lAverageDamage = MyCLng(rsCorpse!AverageDamage)
        
        zColourGlowing = MyCStr(rsCorpse!ColourGlowing)
        zMarkingRune = MyCStr(rsCorpse!MarkingRune)
        zMarkingGlowing = MyCStr(rsCorpse!MarkingGlowing)
        zMarkingHumming = MyCStr(rsCorpse!MarkingHumming)
        
        lMissileAverageDamage = MyCLng(rsCorpse!MissileAverageDamage)
        lMissileGroupAmount = MyCLng(rsCorpse!MissileGroupAmount)
        lMagazineMAX = MyCLng(rsCorpse!MagazineMAX)
        If (lMagazineMAX < lMissileGroupAmount) Then lMagazineMAX = lMissileGroupAmount
        
        lFireElementalDamage = lRandom(MyCLng(rsCorpse!FireElementalDamage))
        lLightningElementalDamage = lRandom(MyCLng(rsCorpse!LightningElementalDamage))
        lPoisonElementalDamage = lRandom(MyCLng(rsCorpse!PoisonElementalDamage))
        lColdElementalDamage = lRandom(MyCLng(rsCorpse!ColdElementalDamage))
        
        zWeaponSkillBackStabClass = MyCStr(rsCorpse!WeaponSkillBackStabClass)
        lAbsorbsSameLeft = MyCLng(rsCorpse!AbsorbsSameLeft)
        lLanguageCell = MyCLng(rsCorpse!LanguageCell)
        lMagicFind = lRandom(MyCLng(rsCorpse!MagicFind))
        lMagicFindBase = lRandom(MyCLng(rsCorpse!MagicFindBase))
        lRegenerationLevel = MyCLng(rsCorpse!RegenerationLevel)
        iCraftingPreserveYN = MyCInt(rsCorpse!CraftingPreserveYN)
        lSlayChance = lRandom(MyCLng(rsCorpse!SlayChance))
        lIASChance = lRandom(MyCLng(rsCorpse!IASChance))
        lSSRepairLevel = MyCLng(rsCorpse!SSRepairLevel)
        lObjectActivateSpellNo = MyCLng(rsCorpse!ObjectActivateSpellNo)
        lObjectActivateSkillNo = MyCLng(rsCorpse!ObjectActivateSkillNo)
        lMoveReductionInertialInhibitor = lRandom(MyCLng(rsCorpse!MoveReductionInertialInhibitor))
        lWeaponBlockPercent = lRandom(MyCLng(rsCorpse!WeaponBlockPercent))
        lPokerCardType = MyCLng(rsCorpse!PokerCardType)
        lWeight = MyCLng(rsCorpse!Weight)
        lWeightMax = MyCLng(rsCorpse!WeightMax)
        lStr = lRandom(MyCLng(rsCorpse!Str))
        lInt = lRandom(MyCLng(rsCorpse!Int))
        lWis = lRandom(MyCLng(rsCorpse!Wis))
        lDex = lRandom(MyCLng(rsCorpse!Dex))
        lCon = lRandom(MyCLng(rsCorpse!Con))
        lCHA = lRandom(MyCLng(rsCorpse!Cha))
        lLUC = lRandom(MyCLng(rsCorpse!Luc))
        lHP = lRandom(MyCLng(rsCorpse!HP))
        lAC = MyCLng(MyCLng(rsCorpse!AC) / 2) + lRandom(MyCLng(MyCLng(rsCorpse!AC) / 4)) + lRandom(MyCLng(MyCLng(rsCorpse!AC) / 4))
        lPACMax = MyCLng(MyCLng(rsCorpse!PACMax) / 2) + lRandom(MyCLng(MyCLng(rsCorpse!PACMax) / 4)) + lRandom(MyCLng(MyCLng(rsCorpse!PACMax) / 4))
        lPAC = lPACMax
        lDamageReduction = lRandom(MyCLng(rsCorpse!DamageReduction))
        
        lEssence = lRandom(MyCLng(rsCorpse!essence))
        lMana = lRandom(MyCLng(rsCorpse!mana))
        lSoul = lRandom(MyCLng(rsCorpse!soul))
        lMove = lRandom(MyCLng(rsCorpse!Move))
        lPhaserLevel = MyCLng(rsCorpse!PhaserLevel)
        lPhaserInvokes = MyCLng(rsCorpse!PhaserInvokes)
        
        lHeightRequirement = MyCLng(rsCorpse!HeightRequirement)
        lHeight = MyCLng(rsCorpse!Height)
        lWidth = MyCLng(rsCorpse!Width)
        lLength = MyCLng(rsCorpse!Length)
        lFishingRodLevel = MyCLng(rsCorpse!FishingRodLevel)
        lLiquidType = MyCLng(rsCorpse!LiquidType)
        lSolidType = MyCLng(rsCorpse!SolidType)
        lFishType = MyCLng(rsCorpse!FishType)
        lMeatType = MyCLng(rsCorpse!MeatType)
        lVeggyType = MyCLng(rsCorpse!VeggyType)
        lFruitType = MyCLng(rsCorpse!FruitType)
        lAnimalMineralVegitableFruitID = MyCLng(rsCorpse!AnimalMineralVegitableFruitID)
        lAnimalMineralVegitableFruitGroupNumber = MyCLng(rsCorpse!AnimalMineralVegitableFruitGroupNumber)
        lGraphicsID = MyCLng(rsCorpse!GraphicsID)
        
        If (lPlayerLevel > cstlRarePlayerLevel) Then 'unless the player is over level 19 we do not treasure or rare items
            'We now have the duplicate item to modify
            'Begin Treasure and Rares
            '==============================================================================
            'GOLD
            Select Case lRandom(300)
                Case 1 To 5
                    lTreasureLevel = lTreasureLevel + 1
                    lWearReqLuc = lWearReqLuc + 15 + lRandom(15) + lRandom(15)
                    lGoldDropChance = lGoldDropChance + lRandom(5)
                    zAllAttributes = zAllAttributes & " GoldenRune"
                Case 50
                    lRareLevel = lRareLevel + 1
                    lWearReqLuc = lWearReqLuc + 25 + lRandom(50) + lRandom(35) + lRandom(45)
                    lGoldDropChance = lGoldDropChance + lRandom(10)
                    zAllAttributes = zAllAttributes & " DiamondRune"
            End Select
            
            'STATS
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lStr = lStr + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "power"
                    zAllAttributes = zAllAttributes & " Power"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lStr = lStr + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "strength"
                    zAllAttributes = zAllAttributes & " Strength"
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lInt = lInt + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "bright"
                    zAllAttributes = zAllAttributes & " Bright"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lInt = lInt + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "genius"
                    zAllAttributes = zAllAttributes & " Genius"
            End Select
            
            Select Case lRandom(1000)
                Case 1 Or 2
                    lRareLevel = lRareLevel + 1
                    lStr = lStr + 1 + lRandom(3)
                    lCon = lCon + 1 + lRandom(3)
                    lDurabilityMAX = lDurabilityMAX + 1 + lRandom(2)
                    zAllAttributes = zAllAttributes & " Steadfast"
                    lWearReqStr = lWearReqStr + lRandom(12) + lRandom(5) + lCon + lStr + lDurabilityMAX
                Case 3
                    lRareLevel = lRareLevel + 1
                    lStr = lStr + 2 + lRandom(3)
                    lCon = lCon + 2 + lRandom(3)
                    lDurabilityMAX = lDurabilityMAX + 2 + lRandom(3)
                    zAllAttributes = zAllAttributes & " Tenacity"
                    lWearReqStr = lWearReqStr + lRandom(14) + lRandom(10) + lCon + lStr + lDurabilityMAX
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lWis = lWis + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "acumen"
                    zAllAttributes = zAllAttributes & " Acumen"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lWis = lWis + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "sagacity"
                    zAllAttributes = zAllAttributes & " Sagacity"
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lDex = lDex + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "forte"
                    zAllAttributes = zAllAttributes & " Forte"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lDex = lDex + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "adept"
                    zAllAttributes = zAllAttributes & " Adept"
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lCon = lCon + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "endurance"
                    zAllAttributes = zAllAttributes & " Endurance"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lCon = lCon + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "physique"
                    zAllAttributes = zAllAttributes & " Physique"
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lCHA = lCHA + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "decorated"
                    zAllAttributes = zAllAttributes & " Decorated"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lCHA = lCHA + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "exquisite"
                    zAllAttributes = zAllAttributes & " Exquisite"
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lLUC = lLUC + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "chance"
                    zAllAttributes = zAllAttributes & " Chance"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lLUC = lLUC + 3 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "fortune"
                    zAllAttributes = zAllAttributes & " Fortune"
            End Select
            
            Select Case lRandom(100)
                Case 1
                    lEssence = lEssence + 50 + lRandom(250)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "nature"
                    zAllAttributes = zAllAttributes & " Nature"
            End Select
            Select Case lRandom(100)
                Case 1
                    lMana = lMana + 50 + lRandom(250)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "mana"
                    zAllAttributes = zAllAttributes & " Mana"
            End Select
            Select Case lRandom(100)
                Case 1
                    lSoul = lSoul + 50 + lRandom(250)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "soul"
                    zAllAttributes = zAllAttributes & " Soul"
            End Select
            Select Case lRandom(100)
                Case 1
                    lMove = lMove + 50 + lRandom(250)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "stamina"
                    zAllAttributes = zAllAttributes & " Stamina"
            End Select
            Select Case lRandom(100)
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lHP = lHP + 20 + lRandom(30)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "vigor"
                    zAllAttributes = zAllAttributes & " Vigor"
                Case 2
                    lTreasureLevel = lTreasureLevel + 1
                    lHP = lHP + 40 + lRandom(30)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "muscle"
                    zAllAttributes = zAllAttributes & " Muscle"
            End Select
            
            'GENERIC STUFF
            Select Case lRandom(7200) 'Magic Find Base
                Case 1
                    lRareLevel = lRareLevel + 1
                    lLUC = lLUC + 1 + lRandom(3)
                    lMagicFindBase = lMagicFindBase + 1 + lRandom(5)
                    lWearReqInt = lWearReqInt + lMagicFindBase + lRandom(10) + lRandom(10)
                    lWearReqWis = lWearReqWis + lMagicFindBase + 10 + lRandom(10) + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "ethereal"
                    zAllAttributes = zAllAttributes & " EtherealMFBase"
                    lLevelRequirement = lLevelRequirement + 10
                Case 2
                    lRareLevel = lRareLevel + 1
                    lLUC = lLUC + 4 + lRandom(3)
                    lMagicFindBase = lMagicFindBase + 3 + lRandom(6)
                    lWearReqInt = lWearReqInt + lMagicFindBase + lRandom(10) + lRandom(10)
                    lWearReqWis = lWearReqWis + lMagicFindBase + 10 + lRandom(10) + lRandom(5)
                    lWearReqLuc = lWearReqLuc + lMagicFindBase + 20 + lRandom(10) + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "divine"
                    zAllAttributes = zAllAttributes & " DivineMFBase"
                    lLevelRequirement = lLevelRequirement + 20
            End Select
            
            Select Case lRandom(4000) 'Magic Find
                Case 1
                    lTreasureLevel = lTreasureLevel + 1
                    lLUC = lLUC + 1 + lRandom(4)
                    lMagicFind = lMagicFind + 1 + lRandom(3)
                    lWearReqInt = lWearReqInt + lMagicFind + 5 + lRandom(5) + lRandom(5)
                    lWearReqWis = lWearReqWis + lLUC + lRandom(10) + lRandom(5)
                    lWearReqLuc = lWearReqLuc + lMagicFind + 5 + lRandom(5) + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "mineral"
                    zAllAttributes = zAllAttributes & " mineral"
                    lLevelRequirement = lLevelRequirement + 15
                Case 2
                    lRareLevel = lRareLevel + 1
                    lLUC = lLUC + 2 + lRandom(3)
                    lMagicFind = lMagicFind + 2 + lRandom(2) + lRandom(2)
                    lWearReqInt = lWearReqInt + lMagicFind + 15 + lRandom(10) + lRandom(10) + lMagicFind
                    lWearReqWis = lWearReqWis + 10 + lLUC + lRandom(10) + lRandom(5)
                    lWearReqLuc = lWearReqLuc + lMagicFind + 20 + lRandom(10) + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "clover"
                    zAllAttributes = zAllAttributes & " CloverMF"
                    lLevelRequirement = lLevelRequirement + 25
                Case 3
                    lRareLevel = lRareLevel + 1
                    lLUC = lLUC + 5 + lRandom(3)
                    lMagicFind = lMagicFind + 6 + lRandom(2) + lRandom(2)
                    lWearReqInt = lWearReqInt + lLUC + lMagicFind + 15 + lRandom(10) + lRandom(10) + lMagicFind
                    lWearReqWis = lWearReqWis + 10 + lLUC + lRandom(10) + lRandom(5)
                    lWearReqLuc = lWearReqLuc + lMagicFind + 30 + lRandom(10) + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "horseshoe"
                    zAllAttributes = zAllAttributes & " HorseshoeMF"
                    lLevelRequirement = lLevelRequirement + 40
            End Select

            Select Case (lMagicFind + lMagicFindBase > 0)
                Case True
                    Select Case lRandom(8000)
                        Case 1
                            lRareLevel = lRareLevel + 3
                            lMagicFind = lMagicFind + 15 + lRandom(5) + lRandom(5)
                            lMagicFindBase = lMagicFindBase + 8 + lRandom(4) + lRandom(3)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "godly"
                            zAllAttributes = zAllAttributes & " GodlyMF"
                            lWearReqInt = lWearReqInt + 30 + lRandom(30) + lRandom(10)
                            lWearReqWis = lWearReqWis + 30 + lRandom(20) + lRandom(20)
                            lWearReqLuc = lWearReqLuc + 10 + lRandom(20) + lRandom(20)
                            lWearReqCha = lWearReqCha + 10 + lRandom(20) + lRandom(20)
                            lLevelRequirement = lLevelRequirement + lRareLevel + lTreasureLevel + lMagicFind + lMagicFindBase
                    End Select
            End Select
            
            If (lPokerCardType = 0 And lRottingRounds = 0) Then 'just makes sure that certain items cannot get Ankh'ed
                If (lRandom(500000) = 1) Then
                    lRareLevel = lRareLevel + 4
                    lAbsorbsSameLeft = lAbsorbsSameLeft + lRandom(3) 'this allowes the item to absorb ALL the stats from another item, the other item cannot be another AbsorbsSameLeft.
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "<>Ankh<>"
                    zAllAttributes = zAllAttributes & " <>Ankh<>"
                    lWearReqInt = lWearReqInt + 30 + lRandom(30) + lRandom(10)
                    lWearReqWis = lWearReqWis + 30 + lRandom(20) + lRandom(20)
                    lWearReqLuc = lWearReqLuc + 10 + lRandom(20) + lRandom(20)
                    lWearReqCha = lWearReqCha + 50 + lRandom(30) + lRandom(30)
                    lLevelRequirement = lLevelRequirement + 125 + lRandom(15) + lRareLevel + lTreasureLevel + lAbsorbsSameLeft
                End If
            End If
            
            Select Case lRandom(15000) 'Regenerate
                Case 1
                    lRareLevel = lRareLevel + 1
                    
                    lRegenerationLevel = lRegenerationLevel + 1
                    lWearReqStr = lWearReqStr + 15 + lRandom(15) + lRandom(10)
                    lWearReqCon = lWearReqCon + (15 + lRandom(15) + lRandom(10)) * lRegenerationLevel
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "revival"
                    zAllAttributes = zAllAttributes & " Revival"
                    lLevelRequirement = lLevelRequirement + 10
                Case 2
                    lRareLevel = lRareLevel + 1
                    lRegenerationLevel = lRegenerationLevel + 2
                    lWearReqStr = lWearReqStr + 25 + lRandom(15) + lRandom(10)
                    lWearReqCon = lWearReqCon + (25 + lRandom(15) + lRandom(10)) * lRegenerationLevel
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "rejuvenation"
                    zAllAttributes = zAllAttributes & " Rejuv"
                    lLevelRequirement = lLevelRequirement + 20
            End Select
            Select Case lRandom(85000) 'Godly Regenerate
                Case 1
                    lRareLevel = lRareLevel + 2
                    
                    lRegenerationLevel = lRegenerationLevel + 10
                    lWearReqStr = lWearReqStr + 15 + lRandom(15) + lRandom(10)
                    lWearReqCon = lWearReqCon + (15 + lRandom(15) + lRandom(10)) * lRegenerationLevel
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "revival"
                    zAllAttributes = zAllAttributes & " GodRevival"
                    lLevelRequirement = lLevelRequirement + 10
                Case 2
                    lRareLevel = lRareLevel + 2
                    lRegenerationLevel = lRegenerationLevel + 25
                    lWearReqStr = lWearReqStr + 25 + lRandom(15) + lRandom(10)
                    lWearReqCon = lWearReqCon + (25 + lRandom(15) + lRandom(10)) * lRegenerationLevel
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "rejuvenation"
                    zAllAttributes = zAllAttributes & " GodRejuv"
                    lLevelRequirement = lLevelRequirement + 20
            End Select
            'Elemental
            Select Case lRandom(100)
                Case 1
                    lFireElementalDamage = lFireElementalDamage + 50 + lRandom(50)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "burn"
                    zAllAttributes = zAllAttributes & " Burn"
            End Select
            Select Case lRandom(100)
                Case 1
                    lLightningElementalDamage = lLightningElementalDamage + 50 + lRandom(50)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "shock"
                    zAllAttributes = zAllAttributes & " Shock"
            End Select
            Select Case lRandom(100)
                Case 1
                    lPoisonElementalDamage = lPoisonElementalDamage + 50 + lRandom(50)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "scorpian"
                    zAllAttributes = zAllAttributes & " Scorpian"
            End Select
            Select Case lRandom(100)
                Case 1
                    lColdElementalDamage = lColdElementalDamage + 50 + lRandom(50)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "cold"
                    zAllAttributes = zAllAttributes & " Cold"
            End Select
            
            'HIGH LEVEL TECH
            Select Case lRandom(3900)
                Case 1
                    lPhaserLevel = lRandom(99)
                    lPhaserInvokes = lRandom(9)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "]OO["
                    zAllAttributes = zAllAttributes & " ]OO["
            End Select
            Select Case lRandom(900)
                Case 1
                    lSSRepairLevel = lSSRepairLevel + lRandom(8) + 1
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "]oO["
                    zAllAttributes = zAllAttributes & " ]oO["
            End Select
            
            If (lWeightMax > 0 And lPokerCardType = 0) Then
                Select Case lRandom(1250)
                    Case 1
                        lTreasureLevel = lTreasureLevel + 1
                        lWeightMax = lWeightMax + lRandom(200) + 200
                        zAllAttributes = zAllAttributes & " SmallPocket"
                        lLevelRequirement = lLevelRequirement + 1
                    Case 2
                        lTreasureLevel = lTreasureLevel + 1
                        lWeightMax = lWeightMax + lRandom(200) + 400
                        zAllAttributes = zAllAttributes & " MediumPocket"
                        lLevelRequirement = lLevelRequirement + 5
                    Case 3
                        lTreasureLevel = lTreasureLevel + 2
                        lWeightMax = lWeightMax + lRandom(300) + 600
                        zAllAttributes = zAllAttributes & " LargePocket"
                        lLevelRequirement = lLevelRequirement + 15
                    Case 4
                        lTreasureLevel = lTreasureLevel + 1
                        lRareLevel = lRareLevel + 1
                        lWeightMax = (lWeightMax * 2) + lRandom(300) + 900
                        zAllAttributes = zAllAttributes & " ZipperDesign"
                        lLevelRequirement = lLevelRequirement + 25
                    Case 5
                        lTreasureLevel = lTreasureLevel + 2
                        lRareLevel = lRareLevel + 1
                        lWeightMax = (lWeightMax * 3) + lRandom(600) + 1200
                        zAllAttributes = zAllAttributes & " Dimension"
                        lLevelRequirement = lLevelRequirement + 35
                End Select
            End If
            
            'PERCENT BONUSES
            Select Case lRandom(5000)
                Case 1
                    lRareLevel = lRareLevel + 3
                    lIncreasesHPPercent = 1 + lRandom(3)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "-)o(-"
                    zAllAttributes = zAllAttributes & " -)o(-"
                Case 2
                    lRareLevel = lRareLevel + 3
                    lIncreasesACPercent = 1 + lRandom(3)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "-)x(-"
                    zAllAttributes = zAllAttributes & " -)x(-"
                Case 3
                    lRareLevel = lRareLevel + 3
                    lIncreasesHRPercent = 1 + lRandom(3)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "}{"
                    zAllAttributes = zAllAttributes & " }{"
                Case 4
                    lRareLevel = lRareLevel + 3
                    lIncreasesDRPercent = 1 + lRandom(3)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "]["
                    zAllAttributes = zAllAttributes & " ]["
            End Select
            
            If (lWeaponBlockPercent <> 0 Or Len(zWeaponType) <> 0) Then
                Select Case lRandom(300)
                    Case 1 To 3
                        lTreasureLevel = lTreasureLevel + 1
                        lWeaponBlockPercent = lWeaponBlockPercent + 5 + lRandom(5)
                        lWearReqStr = lWearReqStr + 5 + lRandom(5)
                        lWearReqCon = lWearReqCon + 5 + lRandom(5)
                        lWearReqDex = lWearReqDex + 5 + lRandom(5)
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "armament"
                        zAllAttributes = zAllAttributes & " Armament"
                    Case 4 To 5
                        lTreasureLevel = lTreasureLevel + 2
                        lWeaponBlockPercent = lWeaponBlockPercent + 5 + lRandom(10)
                        lWearReqStr = lWearReqStr + 5 + lRandom(5)
                        lWearReqCon = lWearReqCon + 5 + lRandom(5)
                        lWearReqDex = lWearReqDex + 5 + lRandom(5)
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "defense"
                        zAllAttributes = zAllAttributes & " Defense"
                    Case 6
                        lRareLevel = lRareLevel + 1
                        lWeaponBlockPercent = lWeaponBlockPercent + 10 + lRandom(10)
                        lWearReqStr = lWearReqStr + 5 + lRandom(5)
                        lWearReqCon = lWearReqCon + 5 + lRandom(5)
                        lWearReqDex = lWearReqDex + 5 + lRandom(5)
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "mithril"
                        zAllAttributes = zAllAttributes & " Mithril"
                End Select
            End If
            
            'ARMOUR STUFF
            Select Case lRandom(300) 'Indestructable level
                Case 1
                    lWearReqStr = lWearReqStr + 15 + lRandom(20) + lRandom(15) + lRandom(5)
                    lWearReqCon = lWearReqCon + 15 + lRandom(20) + lRandom(15) + lRandom(5)
                    lWearReqDex = lWearReqDex + 15 + lRandom(20) + lRandom(15) + lRandom(5)
                    lTreasureLevel = lTreasureLevel + 1
                    lIndestructibleMobLv = lIndestructibleMobLv + ((lWearReqStr + lWearReqCon + lWearReqDex) * lRandom(3)) + lRandom(100) + lRandom(100) + lRandom(100) + lRandom(100) + lRandom(100)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "eternal"
                    zAllAttributes = zAllAttributes & " Eternal"
            End Select
                       
            Select Case (lAC > 0)
                Case True
                    Select Case lRandom(300)
                        Case 1 To 5
                            lTreasureLevel = lTreasureLevel + 1
                            lWearReqDex = lWearReqDex + 15 + lRandom(15) + lRandom(15)
                            lArmourAbsorbtionChance = lArmourAbsorbtionChance + lRandom(5)
                            zAllAttributes = zAllAttributes & " ForgedArmour"
                        Case 6 To 9
                            lTreasureLevel = lTreasureLevel + 1
                            lDamageReduction = lDamageReduction + 10 + lRandom(20)
                            zAllAttributes = zAllAttributes & " DRArmour"
                            lWearReqCha = lWearReqCha + 15 + lRandom(20) + lRandom(15) + lRandom(5)
                        Case 50
                            lRareLevel = lRareLevel + 1
                            lWearReqDex = lWearReqDex + 25 + lRandom(50) + lRandom(35) + lRandom(45)
                            lArmourAbsorbtionChance = lArmourAbsorbtionChance + lRandom(10) 'lGoldDropChance
                            zAllAttributes = zAllAttributes & " BlessedArmour"
                    End Select

                    Select Case lRandom(5000)
                        Case 1
                            lTreasureLevel = lTreasureLevel + 1
                            lAC = lAC + 50 + lRandom(25)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "enchanted"
                            zAllAttributes = zAllAttributes & " EnchantedAC"
                            lPACMax = lPACMax + lRandom(20)
                            lWearReqStr = lWearReqStr + 10 + lRandom(20) + lRandom(15)
                            lWearReqCon = lWearReqCon + 10 + lRandom(20) + lRandom(15)
                        Case 2
                            lTreasureLevel = lTreasureLevel + 1
                            lAC = lAC + 100 + lRandom(50)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "charmed"
                            zAllAttributes = zAllAttributes & " CharmedAC"
                            lPACMax = lPACMax + lRandom(20)
                            lWearReqStr = lWearReqStr + 10 + lRandom(20) + lRandom(15)
                            lWearReqCon = lWearReqCon + 10 + lRandom(20) + lRandom(15)
                        Case 3
                            lRareLevel = lRareLevel + 1
                            lWearReqStr = lWearReqStr + 15 + lRandom(5) + lRandom(10)
                            lWearReqDex = lWearReqDex + 15 + lRandom(5) + lRandom(10)
                            lAC = lAC + 100 + lRandom(50)
                            lPACMax = lPACMax + lRandom(100)
                            lWearReqStr = lWearReqStr + MyCLng(lAC / 3)
                            lWearReqDex = lWearReqDex + MyCLng(lAC / 3)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "milled"
                            zAllAttributes = zAllAttributes & " MilledAC"
                        Case 4
                            lRareLevel = lRareLevel + 2
                            lWearReqStr = lWearReqStr + 25 + lRandom(5) + lRandom(10)
                            lWearReqDex = lWearReqDex + 25 + lRandom(5) + lRandom(10)
                            lAC = lAC + 150 + lRandom(250)
                            lPACMax = lPACMax + lRandom(100)
                            lWearReqStr = lWearReqStr + MyCLng(lAC / 3)
                            lWearReqDex = lWearReqDex + MyCLng(lAC / 3)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "forged"
                            zAllAttributes = zAllAttributes & " ForgedAC"
                        Case 5
                            lRareLevel = lRareLevel + 1
                            lDamageReduction = lDamageReduction + 60 + lRandom(30)
                            zAllAttributes = zAllAttributes & " DRArmourPlus"
                            lWearReqCha = lWearReqCha + 15 + lRandom(20) + lRandom(15) + lRandom(5)
                    End Select
            End Select
            
            Select Case (lAC > 0)
                Case True
                    Select Case lRandom(8000)
                        Case 1
                            lRareLevel = lRareLevel + 3
                            lAC = lAC + 500 + lRandom(25) + lRandom(25) + lRandom(25) + lRandom(25) + lRandom(66)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "godly"
                            zAllAttributes = zAllAttributes & " GodlyAC"
                            lWearReqStr = lWearReqStr + 30 + lRandom(20) + lRandom(15)
                            lWearReqInt = lWearReqInt + 30 + lRandom(30) + lRandom(20)
                            lWearReqCon = lWearReqCon + 10 + lRandom(20) + lRandom(15)
                            lLevelRequirement = lLevelRequirement + MyCLng(lAC / 30)
                    End Select
            End Select
            
            'WEAPON STUFF
            Select Case lRandom(500) 'Leeching
                Case 1
                    lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqCha = lWearReqCha + 15 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lLeechingHP = lLeechingHP + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "b"
                    zAllAttributes = zAllAttributes & " BloodHP"
            End Select
            
            Select Case lRandom(150) 'Leeching
                Case 1
                    lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqCha = lWearReqCha + 15 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lLeechingEssence = lLeechingEssence + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "b"
                    zAllAttributes = zAllAttributes & " BloodEssence"
            End Select
            
            Select Case lRandom(200) 'Leeching
                Case 1
                    lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqCha = lWearReqCha + 15 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lLeechingSoul = lLeechingSoul + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "b"
                    zAllAttributes = zAllAttributes & " BloodSoul"
            End Select
            
            Select Case lRandom(150) 'Leeching
                Case 1
                    lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqCha = lWearReqCha + 15 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lLeechingMana = lLeechingMana + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "b"
                    zAllAttributes = zAllAttributes & " BloodMana"
                    
            End Select
            
            Select Case lRandom(75) 'Leeching
                Case 1
                    lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqCha = lWearReqCha + 15 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lLeechingMove = lLeechingMove + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "b"
                    zAllAttributes = zAllAttributes & " BloodMove"
            End Select
            
            Select Case lRandom(125) 'Add backstab
                Case 1
                    lRareLevel = lRareLevel + 1
                    lWearReqStr = lWearReqStr + 15 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqDex = lWearReqDex + 35 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    lWearReqCha = lWearReqCha + 9 + lRandom(10) + lRandom(10) + lRandom(10) + lRandom(10)
                    zWeaponSkillBackStabClass = zRandomClass(True)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "BS"
            End Select
                        
            Select Case (Len(zWeaponType) <> 0)
                Case True
                    'Critical Levels
                    Select Case lRandom(400)
                        Case 1 To 3
                            lRareLevel = lRareLevel + 1
                            lCriticalHR = 10 + lRandom(35) 'this is the percent more hitroll chance done to the mob
                            lCriticalHRChance = 10 + lRandom(50) 'out of 100%
                            lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(5)
                            lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(5)
                            zAllAttributes = zAllAttributes & " CriticalHR"
                        Case 4 To 5
                            lRareLevel = lRareLevel + 1
                            lCriticalDR = 5 + lRandom(25) 'percent more dmg
                            lCriticalDRChance = 10 + lRandom(50) 'out of 100%
                            lWearReqStr = lWearReqStr + 10 + lRandom(10) + lRandom(5)
                            lWearReqDex = lWearReqDex + 10 + lRandom(10) + lRandom(5)
                            zAllAttributes = zAllAttributes & " CriticalDR"
                        Case 6
                            lRareLevel = lRareLevel + 1
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "garnet orb"
                            zAllAttributes = zAllAttributes & " Garnet Orb"
                            lCriticalHR = 10 + lRandom(20) 'this is the percent more hitroll chance done to the mob
                            lCriticalHRChance = 30 + lRandom(50) 'out of 100%
                            lCriticalDR = 5 + lRandom(20) 'percent more dmg
                            lCriticalDRChance = 30 + lRandom(50) 'out of 100%
                            lWearReqStr = lWearReqStr + 20 + lRandom(20) + lRandom(15)
                            lWearReqDex = lWearReqDex + 20 + lRandom(20) + lRandom(15)
                            zAllAttributes = zAllAttributes & " CriticalHRDR"
                        Case 7
                            lRareLevel = lRareLevel + 2
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "diamond orb"
                            zAllAttributes = zAllAttributes & " Diamond Orb"
                            lCriticalHR = 20 + lRandom(35) 'this is the percent more hitroll chance done to the mob
                            lCriticalHRChance = 20 + lRandom(50) 'out of 100%
                            lCriticalDR = 15 + lRandom(25) 'percent more dmg
                            lCriticalDRChance = 20 + lRandom(50) 'out of 100%
                            lWearReqStr = lWearReqStr + 20 + lRandom(20) + lRandom(15)
                            lWearReqDex = lWearReqDex + 20 + lRandom(20) + lRandom(15)
                            zAllAttributes = zAllAttributes & " CriticalHRDR"
                        Case 8
                            lRareLevel = lRareLevel + 2
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "obsidian orb"
                            zAllAttributes = zAllAttributes & " Obsidian Orb"
                            lCriticalHR = 30 + lRandom(35) 'this is the percent more hitroll chance done to the mob
                            lCriticalHRChance = 40 + lRandom(35) 'out of 100%
                            lCriticalDR = 30 + lRandom(35) 'percent more dmg
                            lCriticalDRChance = 40 + lRandom(35) 'out of 100%
                            lWearReqStr = lWearReqStr + 20 + lRandom(20) + lRandom(15)
                            lWearReqDex = lWearReqDex + 20 + lRandom(20) + lRandom(15)
                            zAllAttributes = zAllAttributes & " CriticalHRDR"
                    End Select
                    
                    Select Case lRandom(600)
                        Case 1
                            lRareLevel = lRareLevel + 1
                            lWearReqDex = lWearReqDex + 15 + lRandom(5) + lRandom(10)
                            lCriticalBlindChance = lCriticalBlindChance + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "polarized"
                            zAllAttributes = zAllAttributes & " Polarized"
                        Case 2
                            lRareLevel = lRareLevel + 2
                            lWearReqDex = lWearReqDex + 15 + lRandom(15) + lRandom(15)
                            lCriticalBlindChance = lCriticalBlindChance + 10 + lRandom(15)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "myoptic"
                            zAllAttributes = zAllAttributes & " Myoptic"
                    End Select
            End Select
            
            Select Case (lCHITROLL > 0)
                Case True
                    Select Case lRandom(10000)
                        Case 1 To 15
                            lTreasureLevel = lTreasureLevel + 1
                            lWearReqDex = lWearReqDex + 5 + lRandom(5) + lRandom(10)
                            lCHITROLL = lCHITROLL + 75 + lRandom(50)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "enchanted"
                            zAllAttributes = zAllAttributes & " EnchantedHR"
                        Case 16
                            lTreasureLevel = lTreasureLevel + 1
                            lRareLevel = lRareLevel + 2
                            lWearReqDex = lWearReqDex + 15 + lRandom(10) + lRandom(20)
                            lNumAttRnd = lNumAttRnd + 1
                            lCHITROLL = lCHITROLL + 125 + lRandom(75)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "blessed"
                            zAllAttributes = zAllAttributes & " BlessedHRAttack"
                    End Select
            End Select
            
            Select Case (lCHITROLL > 0)
                Case True
                    Select Case lRandom(8000)
                        Case 1
                            lRareLevel = lRareLevel + 3
                            lCHITROLL = lCHITROLL + 500 + lRandom(25) + lRandom(25) + lRandom(25) + lRandom(25) + lRandom(66)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "godly"
                            zAllAttributes = zAllAttributes & " GodlyHR"
                            lWearReqStr = lWearReqStr + 30 + lRandom(20) + lRandom(15)
                            lWearReqDex = lWearReqDex + 30 + lRandom(30) + lRandom(20)
                            lWearReqCon = lWearReqCon + 10 + lRandom(20) + lRandom(15)
                            lLevelRequirement = lLevelRequirement + MyCLng(lCHITROLL / 30)
                    End Select
            End Select
            
            If (bReturnWeaponTypeAmmunition(zWeaponType)) Then
                If (lMagazineMAX > 0) Then
                    If (lRandom(500) < 10) Then
                        lRareLevel = lRareLevel + 1
                        lMagazineMAX = lMagazineMAX + 5
                        Select Case zWeaponType
                            Case "STON"
                                lMagazineMAX = lMagazineMAX + 25 + lRandom(15)
                            Case "ARRO"
                                lMagazineMAX = lMagazineMAX + 10 + lRandom(5)
                            Case "BOLT"
                                lMagazineMAX = lMagazineMAX + 15 + lRandom(5)
                            Case "AMMO", "CLIP"
                                lMagazineMAX = lMagazineMAX + 10 + lRandom(5)
                            Case "BLAS", "ENER"
                                lMagazineMAX = lMagazineMAX + 5 + lRandom(5)
                        End Select
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "missile-sideclip"
                        zAllAttributes = zAllAttributes & " MagazineSideClip"
                    End If
                End If
                
                If (lMissileAverageDamage > 0) Then
                    If (lRandom(200) = 1) Then
                        lTreasureLevel = lTreasureLevel + 1
                        lMissileAverageDamage = lMissileAverageDamage + lRandom(20)
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "missile-bane"
                        zAllAttributes = zAllAttributes & " MissileBaneDR"
                    End If
                End If
            End If 'Got Ammunition?
            
            Select Case (lAverageDamage > 0)
                Case True
                    Select Case lRandom(100)
                        Case 1 To 3
                            lTreasureLevel = lTreasureLevel + 1
                            lAverageDamage = lAverageDamage + lRandom(20)
                            lWearReqStr = lWearReqStr + 5 + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "bane"
                            zAllAttributes = zAllAttributes & " BaneDR"
                        Case 4 To 5
                            lTreasureLevel = lTreasureLevel + 1
                            lAverageDamage = lAverageDamage + 20 + lRandom(20)
                            lWearReqStr = lWearReqStr + 5 + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "lesion"
                            zAllAttributes = zAllAttributes & " LesionDR"
                        Case 6
                            lTreasureLevel = lTreasureLevel + 2
                            lAverageDamage = lAverageDamage + 40 + lRandom(20) + lRandom(20)
                            lWearReqStr = lWearReqStr + 5 + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "ravage"
                            zAllAttributes = zAllAttributes & " RavageDR"
                    End Select
            End Select
            
            Select Case (lAverageDamage > 0)
                Case True
                    Select Case lRandom(8000)
                        Case 1
                            lRareLevel = lRareLevel + 3
                            lAverageDamage = lAverageDamage + 500 + lRandom(25) + lRandom(25) + lRandom(25) + lRandom(25) + lRandom(66)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "godly"
                            zAllAttributes = zAllAttributes & " GodlyDR"
                            lWearReqStr = lWearReqStr + 30 + lRandom(20) + lRandom(15)
                            lWearReqWis = lWearReqWis + 30 + lRandom(30) + lRandom(20)
                            lWearReqCon = lWearReqCon + 10 + lRandom(20) + lRandom(15)
                            lLevelRequirement = lLevelRequirement + MyCLng(lAverageDamage / 30)
                    End Select
            End Select
            
            Select Case (lRandom(20) = 1 Or lIASChance > 0)
                Case True
                    Select Case lRandom(260)
                        Case 1, 250
                            lTreasureLevel = lTreasureLevel + 1
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            lWearReqCha = lWearReqCha + 15 + lRandom(15) + lRandom(15)
                            lInitativeChance = lInitativeChance + lRandom(5)
                            zAllAttributes = zAllAttributes & " ReducedInitiativeChance"
                        Case 150
                            lRareLevel = lRareLevel + 1
                            lIASChance = lIASChance + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            lWearReqCha = lWearReqCha + 25 + lRandom(15) + lRandom(15)
                            lInitativeChance = lInitativeChance + lRandom(5) + 5
                            zAllAttributes = zAllAttributes & " IASReducedInitiativeChance"
                    End Select
                    
                    Select Case lRandom(50)
                        Case 1 To 3
                            lTreasureLevel = lTreasureLevel + 1
                            lIASChance = lIASChance + lRandom(10)
                            lWearReqCon = lWearReqCon + 5 + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "brisk"
                            zAllAttributes = zAllAttributes & " Brisk"
                        Case 4 To 5
                            lTreasureLevel = lTreasureLevel + 1
                            lIASChance = lIASChance + 5 + lRandom(10)
                            lWearReqCon = lWearReqCon + 5 + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "swift"
                            zAllAttributes = zAllAttributes & " Swift"
                        Case 6
                            lTreasureLevel = lTreasureLevel + 2
                            lIASChance = lIASChance + 15 + lRandom(5) + lRandom(5)
                            lWearReqCon = lWearReqCon + 5 + lRandom(10)
                            lWearReqDex = lWearReqDex + 5 + lRandom(10)
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "rapid"
                            zAllAttributes = zAllAttributes & " Rapid"
                    End Select
            End Select
            
            Select Case (lRandom(300) = 1 Or lSlayChance > 4) 'high slay items make more slay items
                Case True
                    Select Case lRandom(125)
                        Case 1 To 4
                            lTreasureLevel = lTreasureLevel + 1
                            lSlayChance = lSlayChance + 4 + lRandom(3)
                            lWearReqStr = lWearReqStr + 5 + lRandom(5) + lSlayChance
                            lWearReqCon = lWearReqCon + 4 + lRandom(5) + lSlayChance
                            lWearReqDex = lWearReqDex + 1 + lRandom(5) + lSlayChance
                            lWearReqWis = lWearReqWis + 2 + lRandom(5) + lSlayChance
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "strike"
                            zAllAttributes = zAllAttributes & " Strike"
                        Case 5
                            lTreasureLevel = lTreasureLevel + 2
                            lSlayChance = lSlayChance + 8 + lRandom(6)
                            lWearReqStr = lWearReqStr + 6 + lRandom(5) + lSlayChance
                            lWearReqCon = lWearReqCon + 5 + lRandom(5) + lSlayChance
                            lWearReqDex = lWearReqDex + 2 + lRandom(5) + lSlayChance
                            lWearReqWis = lWearReqWis + 3 + lRandom(5) + lSlayChance
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "carnage"
                            zAllAttributes = zAllAttributes & " Carnage"
                        Case 6
                            lRareLevel = lRareLevel + 1
                            lSlayChance = lSlayChance + 12 + lRandom(4) + lRandom(4)
                            lWearReqStr = lWearReqStr + 7 + lRandom(5) + lSlayChance
                            lWearReqCon = lWearReqCon + 6 + lRandom(5) + lSlayChance
                            lWearReqDex = lWearReqDex + 3 + lRandom(5) + lSlayChance
                            lWearReqWis = lWearReqWis + 4 + lRandom(5) + lSlayChance
                            subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "slay"
                            zAllAttributes = zAllAttributes & " Slay"
                    End Select
            End Select
            
            Select Case lRandom(50)
                Case 1
                    'lTreasureLevel = lTreasureLevel + 1
                    lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 1
                    lWearReqStr = lWearReqStr + lRandom(5)
                    lWearReqCon = lWearReqCon + lRandom(5)
                    lWearReqDex = lWearReqDex + 1 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "Ri1"
                    zAllAttributes = zAllAttributes & " Ri1"
                Case 2
                    'lTreasureLevel = lTreasureLevel + 1
                    lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 2
                    lWearReqStr = lWearReqStr + lRandom(5)
                    lWearReqCon = lWearReqCon + 5 + lRandom(5)
                    lWearReqDex = lWearReqDex + 1 + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "Ri2"
                    zAllAttributes = zAllAttributes & " Ri2"
                Case 3
                    lTreasureLevel = lTreasureLevel + 1
                    lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 2 + lRandom(3)
                    lWearReqStr = lWearReqStr + lRandom(25)
                    lWearReqCon = lWearReqCon + 10 + lRandom(5)
                    lWearReqDex = lWearReqDex + lRandom(25)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "Ri3"
                    zAllAttributes = zAllAttributes & " Ri3"
                Case 4
                    lRareLevel = lRareLevel + 1
                    lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 5 + lRandom(5)
                    lWearReqStr = lWearReqStr + 10 + lRandom(15)
                    lWearReqCon = lWearReqCon + 10 + lRandom(15)
                    lWearReqDex = lWearReqDex + 10 + lRandom(15)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "Ri4"
                    zAllAttributes = zAllAttributes & " Ri4"
            End Select
            
            'MAGIC
            If (lObjectActivateSpellNo = 0 And lRandom(3500) = 1) Then 'some items can have may get a bonus spell on it
                lWearReqInt = lWearReqInt + 10 + lRandom(5)
                lWearReqWis = lWearReqWis + 10 + lRandom(5)
                lWearReqDex = lWearReqDex + 10 + lRandom(10)
                
                Select Case lRandom(9)
                    Case 1
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSpellNo = 20 'Invisibility
                        lWearReqInt = lWearReqInt + lRandom(5)
                        lWearReqWis = lWearReqWis + lRandom(5)
                        zAllAttributes = zAllAttributes & " Invisibility"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "}={"
                    Case 2
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSpellNo = 80 'Barkskin
                        lWearReqInt = lWearReqInt + lRandom(10)
                        lWearReqWis = lWearReqWis + lRandom(5)
                        zAllAttributes = zAllAttributes & " Barkskin"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "[x]"
                    Case 3
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSpellNo = 81 'Stoneskin
                        lWearReqInt = lWearReqInt + lRandom(10)
                        lWearReqWis = lWearReqWis + lRandom(10)
                        zAllAttributes = zAllAttributes & " Stoneskin"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "(x)"
                    Case 4
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSpellNo = 82 'Dragonskin
                        lWearReqInt = lWearReqInt + lRandom(10)
                        lWearReqWis = lWearReqWis + lRandom(10)
                        zAllAttributes = zAllAttributes & " Dragonskin"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "[DrS]"
                    Case 5
                        lRareLevel = lRareLevel + 2
                        lObjectActivateSpellNo = 83 'Demonskin
                        lWearReqInt = lWearReqInt + lRandom(10)
                        lWearReqWis = lWearReqWis + lRandom(10)
                        zAllAttributes = zAllAttributes & " Demonskin"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "{DeS}"
                    Case 6
                        lRareLevel = lRareLevel + 2
                        lObjectActivateSpellNo = 30 'fireshield
                        lWearReqInt = lWearReqInt + lRandom(20)
                        lWearReqWis = lWearReqWis + lRandom(20)
                        zAllAttributes = zAllAttributes & " -FIRESHIELD-"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "-!-" 'meaningless rune
                    Case 7
                        lRareLevel = lRareLevel + 2
                        lObjectActivateSpellNo = 40 'iceshield
                        lWearReqInt = lWearReqInt + lRandom(20)
                        lWearReqWis = lWearReqWis + lRandom(20)
                        zAllAttributes = zAllAttributes & " -ICESHIELD-"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "-+-" 'meaningless rune
                    Case 8
                        lLevelRequirement = lLevelRequirement + 15
                        lRareLevel = lRareLevel + 2
                        lObjectActivateSpellNo = 99 'shadowcloak
                        lAC = lAC + lRandom(50) + 50
                        lCHITROLL = lCHITROLL + lRandom(50) + 100
                        lAverageDamage = lAverageDamage + lRandom(50) + 50
                        lIASChance = lIASChance + lRandom(10) + 5
                        lSlayChance = lSlayChance + 5 + lRandom(10)
                        lWearReqCha = lWearReqCha + 25 + lRandom(15) + lRandom(15)
                        lWearReqInt = lWearReqInt + 15 + lRandom(20)
                        lWearReqWis = lWearReqWis + 10 + lRandom(20)
                        zAllAttributes = zAllAttributes & " ~BATS~"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "~ShCb~" 'meaningless rune
                    Case 9
                        lLevelRequirement = lLevelRequirement + 25
                        lRareLevel = lRareLevel + 3
                        lObjectActivateSpellNo = 99 'shadowcloak
                        lAC = lAC + lRandom(75) + 100
                        lCHITROLL = lCHITROLL + lRandom(250) + 100
                        lAverageDamage = lAverageDamage + lRandom(150) + 50
                        lIASChance = lIASChance + lRandom(10) + 10
                        lSlayChance = lSlayChance + 10 + lRandom(20)
                        lWearReqCha = lWearReqCha + 35 + lRandom(25) + lRandom(15)
                        lWearReqInt = lWearReqInt + 20 + lRandom(20)
                        lWearReqWis = lWearReqWis + 20 + lRandom(20)
                        zAllAttributes = zAllAttributes & " ~SHADOWS~"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "~ShCs~" 'meaningless rune
                End Select 'SELECT NOTE: if you add one here make sure the wear procedure matches the spell number above.
            End If
            
            If (lObjectActivateSkillNo = 0 And lRandom(5000) = 1) Then 'some items can have may get a bonus spell on it
                lWearReqCon = lWearReqCon + 10 + lRandom(5)
                lWearReqStr = lWearReqStr + 10 + lRandom(5)
                lWearReqDex = lWearReqDex + 10 + lRandom(10)
                lTreasureLevel = lTreasureLevel + 1
                lRareLevel = lRareLevel + 1
                Select Case lRandom(12)
                    Case 1
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 10 'Berserk
                        lWearReqCon = lWearReqCon + lRandom(40)
                        lWearReqStr = lWearReqStr + lRandom(40)
                        zAllAttributes = zAllAttributes & " Berserk"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "<%>"
                    Case 2
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 20 'Double Punch
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Double Punch"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "<O>"
                    Case 3
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 30 'Drop kick
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Drop Kick"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "<X>"
                    Case 4
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 40 'Meditate
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Meditate"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, ">-<"
                    Case 5
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 50 'HeadButt
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Headbutt"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "<!>"
                    Case 6
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 60 'Elbow
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Elbow"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "}+{"
                    Case 7
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 70 'Knee
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Knee"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "=O="
                    Case 8
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 80 'Claw Hand
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Claw Hand"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "=+="
                    Case 9
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 90 'Knife Hand
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Knife Hand"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "+-+"
                    Case 10
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 100 'Dragon Uppercut
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Dragon Uppercut"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "+X+"
                    Case 11
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 110 'Power Kick
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Power Kick"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "O-O"
                    Case 12
                        lRareLevel = lRareLevel + 1
                        lObjectActivateSkillNo = 120 'Hurricane Kick
                        lWearReqCon = lWearReqCon + lRandom(20)
                        lWearReqStr = lWearReqStr + lRandom(20)
                        zAllAttributes = zAllAttributes & " Hurricane Kick"
                        subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, "X=X"
                End Select 'SELECT NOTE: if you add one here make sure the wear procedure matches the spell number above.
            End If
            
            Select Case lRandom(10) 'a random language
                Case 1
                    lLanguageCell = lRandom(13) + 1 'we ignore common
                    lWearReqWis = lWearReqWis + 10 + lRandom(10) + lRandom(5)
                    subObjectBraces zColourGlowing, zMarkingRune, zMarkingGlowing, zMarkingHumming, Mid(LCase(zTranslateLanguage(lLanguageCell)), 1, 4)
                    zAllAttributes = zAllAttributes & " " & zTranslateLanguage(lLanguageCell)
            End Select

            'we attempt to reduce requirements
            If (lPlayerLevel > 11 Or lPlayerLevel < 1) Then
                lLevelRequirement = lLevelRequirement + (lRareLevel * 8) + (lTreasureLevel * 4)
                If (lLevelRequirement + lWearReqStr + lWearReqInt + lWearReqWis + lWearReqDex + lWearReqCon + lWearReqCha + lWearReqLuc + lWearReqAC + lWearReqHP + lWearReqEssence + lWearReqMana + lWearReqSoul + lWearReqMove > 11) Then
                    If (lRandom(60) < 9) Then
                        'help control level req on objects
                        lHoldLevelRequirement = lLevelRequirement 'was level a req, then handle this
                        If (lHoldLevelRequirement > 49) Then
                            Select Case lRandom(7) '7 no change
                                Case 1, 4, 5, 6
                                    lLevelRequirement = MyCLng(lLevelRequirement / (1 + lRandom(3))) + 6
                                Case 2
                                    lLevelRequirement = MyCLng(lLevelRequirement / (2 + lRandom(4))) + 12
                                Case 3
                                    lLevelRequirement = MyCLng(lLevelRequirement / (3 + lRandom(5))) + 24
                            End Select
                        End If
                        If (lLevelRequirement > lHoldLevelRequirement) Then lLevelRequirement = lHoldLevelRequirement 'something messed up so leave it
                        If (lLevelRequirement < 12) Then lLevelRequirement = 12
                        If (lLevelRequirement > 111) Then lLevelRequirement = 111
                        
                        lWearReqStr = 0
                        lWearReqInt = 0
                        lWearReqWis = 0
                        lWearReqDex = 0
                        lWearReqCon = 0
                        lWearReqCha = 0
                        lWearReqLuc = 0
                        lWearReqAC = 0
                        lWearReqHP = 0
                        lWearReqEssence = 0
                        lWearReqMana = 0
                        lWearReqSoul = 0
                        lWearReqMove = 0
                        bTest = False
                        If Len(zColourGlowing) = 0 And Not bTest Then
                            bTest = True
                            zColourGlowing = "Rr"
                        End If
                        If Len(zMarkingRune) = 0 And Not bTest Then
                            bTest = True
                            zMarkingRune = "Rr"
                        End If
                        If Len(zMarkingGlowing) = 0 And Not bTest Then
                            bTest = True
                            zMarkingGlowing = "Rr"
                        End If
                        If Len(zMarkingHumming) = 0 And Not bTest Then
                            bTest = True
                            zMarkingHumming = "Rr"
                        End If
                        zAllAttributes = zAllAttributes & " RedoRequ"
                    End If
                End If
            End If
            
            'Some if statements
            If (lIndestructibleMobLv >= 600) Then lRareLevel = lRareLevel + 1
            
            'Best rolls are just significiant - not useful without knowing the spread
            'If (bWorstMobRoll) Then
                'lLUC = lLUC + 1
                'lCHA = lCHA + 1
            '    zAllAttributes = zAllAttributes & " *MLR*"
            'End If
            'If (bBestPlayerRoll) Then
                'lLUC = lLUC + 1
                'lCHA = lCHA + 1
            '    zAllAttributes = zAllAttributes & " *BR*"
            'End If
            'dont do this, cauise everything in the newbie zone rares -> If (bWorstMobRoll And bBestPlayerRoll) Then lRareLevel = lRareLevel + 1
            
            'End Treasure and Rares
            '==========================================================================
        End If 'lPlayerLevel
        
        Set rsCopyObject = MyDB.OpenRecordset("tblObject", dbOpenDynaset)
        rsCopyObject.AddNew 'Copy Object
        lNewObjectID = MyCLng(rsCopyObject!ObjectID) 'Copy ObjectID
        
        'Never Modify
        rsCopyObject!PlayerID = lPlayerID
        rsCopyObject!x = lCX
        rsCopyObject!y = lCY
        rsCopyObject!z = lCZ
        If (lPlayerID = 0) Then
            rsCopyObject!Status = 3 'make corpse called here, container
        Else
            rsCopyObject!Status = 2 'goes to player inventory
        End If
        
        lFireElementalDamageMAX = lFireElementalDamageMAX + lFireElementalDamage
        lLightningElementalDamageMAX = lLightningElementalDamageMAX + lLightningElementalDamage
        lPoisonElementalDamageMAX = lPoisonElementalDamageMAX + lPoisonElementalDamage
        lColdElementalDamageMAX = lColdElementalDamageMAX + lColdElementalDamage
        If (Len(zWeaponType) > 0) Then 'we chance that weapons might have a enchanting value to it
            Do While (lRandom(2) = 1)
                Select Case (lRandom(5))
                    Case 1
                        lFireElementalDamageMAX = lFireElementalDamageMAX + 100 + lRandom(300) + lCHITROLL + lAverageDamage + (((lWis / 2) + lDex + (lCHA * 2) + lRandom(lLUC * 2)) * 2)
                    Case 2
                        lLightningElementalDamageMAX = lLightningElementalDamageMAX + 100 + lRandom(300) + lCHITROLL + lAverageDamage + (((lWis / 2) + lDex + (lCHA * 2) + lRandom(lLUC * 2)) * 2)
                    Case 3
                        lColdElementalDamageMAX = lColdElementalDamageMAX + 100 + lRandom(300) + lCHITROLL + lAverageDamage + (((lWis / 2) + lDex + (lCHA * 2) + lRandom(lLUC * 2)) * 2)
                    Case 4
                        lPoisonElementalDamageMAX = lPoisonElementalDamageMAX + 100 + lRandom(300) + lCHITROLL + lAverageDamage + (((lWis / 2) + lDex + (lCHA * 2) + lRandom(lLUC * 2)) * 2)
                End Select
            Loop
        End If
        
        'Unmodified
        rsCopyObject!ObjectName = MyCStr(rsCorpse!ObjectName)
        rsCopyObject!ObjectIDOriginal = MyCLng(rsCorpse!ObjectID)
        'ObjectDesc
        rsCopyObject!ObjectDesc = MyCStr(rsCorpse!ObjectDesc)
        rsCopyObject!AllAttributes = MyCStr(zAllAttributes)
        rsCopyObject!SSCryogenic = MyCLng(rsCorpse!SSCryogenic)
        rsCopyObject!GravityLevel = MyCLng(rsCorpse!GravityLevel)
        rsCopyObject!RadiatedAreaLevel = MyCLng(rsCorpse!RadiatedAreaLevel)
        rsCopyObject!HeatAreaLevel = MyCLng(rsCorpse!HeatAreaLevel)
        rsCopyObject!GasAreaLevel = MyCLng(rsCorpse!GasAreaLevel)
        rsCopyObject!Location = MyCLng(rsCorpse!Location)
        rsCopyObject!PeerX = MyCLng(rsCorpse!PeerX) 'allows a player to look at an object and peer into an x y z area
        rsCopyObject!PeerY = MyCLng(rsCorpse!PeerY)
        rsCopyObject!PeerZ = MyCLng(rsCorpse!PeerZ)
        rsCopyObject!PeerAllowed = MyCInt(rsCorpse!PeerAllowed)
        rsCopyObject!Gold = MyCLng(rsCorpse!Gold)
        rsCopyObject!BonusXP = MyCLng(rsCorpse!BonusXP)
        rsCopyObject!QuaffStrength = MyCLng(rsCorpse!QuaffStrength)
        rsCopyObject!QuaffSpellNo = lQuaffSpellNo
        rsCopyObject!ScrollNo = lScrollNo
        rsCopyObject!Thickness = lThickness
        rsCopyObject!Grip = lRandom(MyCLng(rsCorpse!Grip))
        rsCopyObject!Explode = (MyCInt(rsCorpse!Explode) <> 0)
        rsCopyObject!ExplodeLevel = MyCLng(rsCorpse!ExplodeLevel)
        rsCopyObject!LockPickToolBonus = lRandom(MyCLng(rsCorpse!LockPickToolBonus))
        rsCopyObject!ObjectActivateDesc = MyCStr(rsCorpse!ObjectActivateDesc)
        rsCopyObject!ObjectDeactivateDesc = MyCStr(rsCorpse!ObjectDeactivateDesc)
        rsCopyObject!DeactivateDuration = MyCLng(rsCorpse!DeactivateDuration)
        rsCopyObject!ObjectActivatePattern = MyCStr(rsCorpse!ObjectActivatePattern)
        rsCopyObject!AntiClass = MyCStr(rsCorpse!AntiClass)
        rsCopyObject!Alignment = MyCLng(rsCorpse!Alignment)
        rsCopyObject!LockStatus = MyCLng(rsCorpse!LockStatus)
        rsCopyObject!LockCombo = MyCStr(rsCorpse!LockCombo)
        rsCopyObject!LockKeyID = MyCLng(rsCorpse!LockKeyID)
        rsCopyObject!Cursed = MyCLng(rsCorpse!Cursed)
        rsCopyObject!VanishesTimer = MyCLng(rsCorpse!VanishesTimer)
        rsCopyObject!DuelWield = MyCInt(rsCorpse!DuelWield)
        rsCopyObject!OverrideColour = MyCStr(rsCorpse!OverrideColour)
        rsCopyObject!DurabilityBroken = MyCLng(rsCorpse!DurabilityBroken)
        rsCopyObject!LightProvider = (MyCInt(rsCorpse!LightProvider) <> 0)
        rsCopyObject!LightDuration = MyCLng(rsCorpse!LightDuration)
        rsCopyObject!LightRadius = MyCInt(rsCorpse!LightRadius)
        rsCopyObject!QuestForGlory = MyCLng(rsCorpse!QuestForGlory)
        rsCopyObject!SitMAX = MyCInt(rsCorpse!SitMAX)
        rsCopyObject!DoorID = MyCLng(rsCorpse!DoorID)
        rsCopyObject!SSFuel = MyCLng(rsCorpse!SSFuel)
        rsCopyObject!LanguageMessageID = MyCLng(rsCorpse!LanguageMessageID)
        rsCopyObject!RottingRounds = MyCLng(rsCorpse!RottingRounds)
        rsCopyObject!OriginalMobID = lOriginalMobID
        rsCopyObject!PokerCardType = lPokerCardType
        rsCopyObject!PokerCardMerge = MyCLng(rsCorpse!PokerCardMerge)
        rsCopyObject!WeaponSkillMissileRangeClass = MyCStr(rsCorpse!WeaponSkillMissileRangeClass)
        rsCopyObject!Quaffable = lQuaffable
        rsCopyObject!QuaffLiquorLevel = lQuaffLiquorLevel
        rsCopyObject!QuaffMorphLaster = lQuaffMorphLaster
        rsCopyObject!QuaffLiquorDuration = MyCLng(rsCorpse!QuaffLiquorDuration)
        rsCopyObject!QuaffLiquorQuantity = MyCLng(rsCorpse!QuaffLiquorQuantity)
        rsCopyObject!QuaffLiquorVolume = MyCLng(rsCorpse!QuaffLiquorVolume)
        
        'If (lQuaffSpellNo = 0 And lQuaffLiquorLevel = 0 And lScrollNo = 0) Then 'they can buy as many scrolls and things to drink and eat as they want
        '    If (lRandom(3) = 1) Then
        rsCopyObject!CanSellItemDuration = 0 'MyCLng(rsCorpse!CanSellItemDuration) + 1 'this is by a multiple of 8 minutes - THIS IS DISABLED TRISKER TOO LAGGY
        '    End If
        'End If
        
        'Modified Variables
        rsCopyObject!Treasure = lTreasureLevel
        rsCopyObject!Rare = lRareLevel
        
        rsCopyObject!Str = lStr
        rsCopyObject!Int = lInt
        rsCopyObject!Wis = lWis
        rsCopyObject!Dex = lDex
        rsCopyObject!Con = lCon
        rsCopyObject!Cha = lCHA
        rsCopyObject!Luc = lLUC
        rsCopyObject!AC = lAC
        rsCopyObject!PACMax = lPACMax
        rsCopyObject!PAC = lPACMax
        rsCopyObject!DamageReduction = lDamageReduction
        
        rsCopyObject!HP = lHP
        rsCopyObject!essence = lEssence
        rsCopyObject!mana = lMana
        rsCopyObject!soul = lSoul
        rsCopyObject!Move = lMove
        
        rsCopyObject!WearReqSTR = lWearReqStr
        rsCopyObject!WearReqINT = lWearReqInt
        rsCopyObject!WearReqWIS = lWearReqWis
        rsCopyObject!WearReqDEX = lWearReqDex
        rsCopyObject!WearReqCON = lWearReqCon
        rsCopyObject!WearReqCHA = lWearReqCha
        rsCopyObject!WearReqLUC = lWearReqLuc
        rsCopyObject!WearReqAC = lWearReqAC
        rsCopyObject!WearReqHP = lWearReqHP
        rsCopyObject!WearReqEssence = lWearReqEssence
        rsCopyObject!WearReqMana = lWearReqMana
        rsCopyObject!WearReqSoul = lWearReqSoul
        rsCopyObject!WearReqMove = lWearReqMove
        
        rsCopyObject!NumAttRnd = lNumAttRnd
        rsCopyObject!CHITROLL = lCHITROLL
        rsCopyObject!AverageDamage = lAverageDamage
        rsCopyObject!IASChance = lIASChance
        rsCopyObject!SlayChance = lSlayChance
        
        rsCopyObject!Weight = lWeight + lRandom(50) 'just makes things a little different
        rsCopyObject!WeightMax = lWeightMax 'deepens containers
        rsCopyObject!HeightRequirement = lHeightRequirement
        rsCopyObject!Height = lHeight
        rsCopyObject!Width = lWidth
        rsCopyObject!Length = lLength

        rsCopyObject!RegenerationLevel = lRegenerationLevel
        
        rsCopyObject!ColourGlowing = zColourGlowing
        rsCopyObject!MarkingRune = zMarkingRune
        rsCopyObject!MarkingGlowing = zMarkingGlowing
        rsCopyObject!MarkingHumming = zMarkingHumming
        
        'Elemental
        rsCopyObject!TotalElementalEnchants = lTotalElementalEnchants
        rsCopyObject!FireElementalDamageMAX = lFireElementalDamageMAX
        rsCopyObject!LightningElementalDamageMAX = lLightningElementalDamageMAX
        rsCopyObject!ColdElementalDamageMAX = lColdElementalDamageMAX
        rsCopyObject!PoisonElementalDamageMAX = lPoisonElementalDamageMAX
        rsCopyObject!FireElementalDamage = lFireElementalDamage
        rsCopyObject!LightningElementalDamage = lLightningElementalDamage
        rsCopyObject!ColdElementalDamage = lColdElementalDamage
        rsCopyObject!PoisonElementalDamage = lPoisonElementalDamage
        
        'Ammo
        rsCopyObject!MissileAverageDamage = lMissileAverageDamage
        rsCopyObject!MissileGroupAmount = lMissileGroupAmount
        rsCopyObject!MagazineMAX = lMagazineMAX
        'Weapon
        rsCopyObject!WeaponBlockPercent = lWeaponBlockPercent
        
        'Special
        rsCopyObject!IncreasesHPPercent = lIncreasesHPPercent
        rsCopyObject!IncreasesACPercent = lIncreasesACPercent
        rsCopyObject!IncreasesHRPercent = lIncreasesHRPercent
        rsCopyObject!IncreasesDRPercent = lIncreasesDRPercent
        
        rsCopyObject!CriticalHR = lCriticalHR
        rsCopyObject!CriticalHRChance = lCriticalHRChance
        rsCopyObject!CriticalDR = lCriticalDR
        rsCopyObject!CriticalDRChance = lCriticalDRChance
        rsCopyObject!CriticalBlindChance = lCriticalBlindChance
        rsCopyObject!IndestructibleMobLv = lIndestructibleMobLv
        rsCopyObject!ObjectActivateSpellNo = lObjectActivateSpellNo
        rsCopyObject!ObjectActivateSkillNo = lObjectActivateSkillNo
        rsCopyObject!MoveReductionInertialInhibitor = lMoveReductionInertialInhibitor
        rsCopyObject!MagicFind = lMagicFind
        rsCopyObject!MagicFindBase = lMagicFindBase
        rsCopyObject!LanguageCell = lLanguageCell
        If (Len(zWeaponSkillBackStabClass) > 0) Then
            If (lRandom(6) > 2) Then zWeaponSkillBackStabClass = zReturnPlayerClass(lPlayerID) 'if pain back stab is on the item try to push it to be on the CURRENT player class
            zAllAttributes = zAllAttributes & " bs[" & zWeaponSkillBackStabClass & "]"
        End If
        rsCopyObject!WeaponSkillBackStabClass = zWeaponSkillBackStabClass
        rsCopyObject!WeaponType = zWeaponType
        rsCopyObject!WarmthLevel = lWarmthLevel
        rsCopyObject!PlayerStockID = lPlayerStockID
        rsCopyObject!KeyRing = lKeyRing
        rsCopyObject!Key = lKey
        rsCopyObject!LeechingHP = lLeechingHP
        rsCopyObject!LeechingEssence = lLeechingEssence
        rsCopyObject!LeechingSoul = lLeechingSoul
        rsCopyObject!LeechingMana = lLeechingMana
        rsCopyObject!LeechingMove = lLeechingMove
        
        rsCopyObject!PhaserLevel = lPhaserLevel
        rsCopyObject!PhaserInvokes = lPhaserInvokes
        rsCopyObject!InitativeChance = lInitativeChance
        rsCopyObject!SSRepairLevel = lSSRepairLevel
        rsCopyObject!GoldDropChance = lGoldDropChance
        rsCopyObject!ArmourAbsorbtionChance = lArmourAbsorbtionChance
        rsCopyObject!CraftingPreserveYN = iCraftingPreserveYN
        rsCopyObject!EdibleSpellNo = lEdibleSpellNo
        rsCopyObject!DevalueDivider = lDevalueDivider
        rsCopyObject!DurabilityMAX = lDurabilityMAX
        If (lPlayerLevel > cstlRarePlayerLevel) Then
            If lLevelRequirement < 8 + (lRareLevel * 5) + (lTreasureLevel * 3) Then
                lLevelRequirement = 8 + (lRareLevel * 5) + (lTreasureLevel * 3)
            End If
        End If
        Select Case lRandom(9)
            Case 1
                If (lLevelRequirement > 199) Then lLevelRequirement = 150 + lRandom(45)
            Case 2
                lLevelRequirement = MyCLng(lLevelRequirement / 2) + 1
        End Select
        Select Case lRandom(9)
            Case 1
                If (lLevelRequirement > 149) Then lLevelRequirement = 55 + lRandom(65)
            Case 2
                lLevelRequirement = MyCLng(lLevelRequirement / 2) + 1
        End Select
        Select Case lRandom(9)
            Case 1
                If (lLevelRequirement > 49) Then lLevelRequirement = 35 + lRandom(35)
            Case 2
                lLevelRequirement = MyCLng(lLevelRequirement / 2) + 1
        End Select
        rsCopyObject!LevelRequirement = lLevelRequirement
        rsCopyObject!AbsorbsSameLeft = lAbsorbsSameLeft
        rsCopyObject!FishingRodLevel = lFishingRodLevel
        rsCopyObject!LiquidType = lLiquidType
        rsCopyObject!SolidType = lSolidType
        rsCopyObject!FishType = lFishType
        rsCopyObject!MeatType = lMeatType
        rsCopyObject!VeggyType = lVeggyType
        rsCopyObject!FruitType = lFruitType
        rsCopyObject!AnimalMineralVegitableFruitID = lAnimalMineralVegitableFruitID
        rsCopyObject!AnimalMineralVegitableFruitGroupNumber = lAnimalMineralVegitableFruitGroupNumber
        rsCopyObject!GraphicsID = lGraphicsID
        
        'rsCopyObject!ClassGlowing = zTranslateMultiClassStats(lStr, lInt, lWis, lDex, lCon, lCHA, lLUC)
        
        rsCopyObject.Update
        Set rsCopyObject = Nothing
        'END
        If (lPlayerID <> 0) Then MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & lPlayerID & ", " & lNewObjectID & ";", dbFailOnError
    End If
    Set rsCorpse = Nothing
    End If
    lDuplicateObject = lNewObjectID
    Exit Function
Err_Check:
    subWriteErrorFile "lDuplicateObject," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subMakeCorpse(zPortID As String, lPlayerID As Long, lPlayerLevel As Long, lTypeID As Long, zType As String, lCMagicFind As Long, lCMagicFindBase As Long, lCLuc As Long)
'This will make a corpse for a mob or player.
'See Also: subCorpseRottingRounds and lDuplicateObject
'Search this function: chipped
'THIS MUST BE rsCopyObject!Status = 3 'in a container, which is the corpse
'This is the master I use for the lDuplicateObject
'we also use zTranslateMultiClassStats(MyCLng(rsPlayer!CStr), MyCLng(rsPlayer!CInt), MyCLng(rsPlayer!CWIS), MyCLng(rsPlayer!CDEX), MyCLng(rsPlayer!CCON), MyCLng(rsPlayer!CCHA), MyCLng(rsPlayer!CLUC))
'I alsways worked on this one before moving it to lDuplicateObject
On Error GoTo Err_Check
    Const cstlStatus = 3 'in a container
    Dim lObjectID As Long
    Dim iStolenItem As Integer
    Dim rsCopyObject As Recordset
    Dim rsCorpse As Recordset
    Dim zCorpseName As String
    Dim lCX As Long 'Corpse X
    Dim lCY As Long
    Dim lCZ As Long
    Dim lNewCorpseID As Long
    Dim lNewObjectID As Long
    Dim lLucMagicFind As Long
    Dim lPlayerRoll As Long
    Dim lHoldRareRandom As Long
    Dim lMobRoll As Long
    Dim lACLevel As Long
    Dim zObjectName As String
    Dim zStatus As String
    Dim lGivesObjectID As Long
    Dim lCountofStolenItems As Long
    lLucMagicFind = lRandom(lCLuc / 5)
    
    lNewObjectID = 0
    zCorpseName = ""
    lGivesObjectID = 0
    Select Case zType
        Case "M"
            Set rsCorpse = MyDB.OpenRecordset("SELECT GivesObjectID, MobName, X, Y, Z, MobLevel FROM tblMob WHERE (MobID=" & lTypeID & ");", dbOpenSnapshot)
            If (Not rsCorpse.EOF) Then
                lGivesObjectID = MyCLng(rsCorpse!GivesObjectID)
                subGivesObjectID lPlayerID, lGivesObjectID, lPlayerLevel, zPortID
                zCorpseName = zShortstop(MyCStr(rsCorpse!MobName))
                lCX = MyCLng(rsCorpse!x)
                lCY = MyCLng(rsCorpse!y)
                lCZ = MyCLng(rsCorpse!z)
                lACLevel = MyCLng(rsCorpse!MobLevel)
            End If
            Set rsCorpse = Nothing
        Case "P"
            Set rsCorpse = MyDB.OpenRecordset("SELECT PlayerName, X, Y, Z, PlayerLevel FROM tblPlayer WHERE (PlayerID=" & lTypeID & ");", dbOpenSnapshot)
            If (Not rsCorpse.EOF) Then
                zCorpseName = zShortstop(MyCStr(rsCorpse!PlayerName))
                lCX = MyCLng(rsCorpse!x)
                lCY = MyCLng(rsCorpse!y)
                lCZ = MyCLng(rsCorpse!z)
                lACLevel = MyCLng(rsCorpse!PlayerLevel)
            End If
            Set rsCorpse = Nothing
    End Select
    
    If (Len(zCorpseName) > 0) Then 'We make the corpse container object
        zCorpseName = Mid("corpse of " & zAdverb(MyCStr(zCorpseName), 1) & MyCStr(zCorpseName), 1, 100)
        'We create the corpse at the location where the mob was.
        Set rsCorpse = MyDB.OpenRecordset("tblObject", dbOpenTable)
        rsCorpse.AddNew
        lNewCorpseID = MyCLng(rsCorpse!ObjectID) 'Corpse ID
        If (zType = "M") Then 'we make corpses easier to locate for delete
            MyDB.Execute "INSERT INTO tblMobCorpses(ObjectID) SELECT " & lNewCorpseID & ";", dbFailOnError
        End If
        
        rsCorpse!ObjectName = zCorpseName
        Select Case lRandom(10)
            Case 1
                rsCorpse!ObjectDesc = "The eyes of the corpse are wide open."
            Case 2
                rsCorpse!ObjectDesc = "One of the eyes of the corpse is open."
            Case 3
                rsCorpse!ObjectDesc = "Both eyes of the corpse are closed tight."
            Case 4
                rsCorpse!ObjectDesc = "Both eyes of the corpse are peeking open."
            Case 5
                rsCorpse!ObjectDesc = "One eye of the corpse is dangling out of the socket while the other is closed."
            Case 6
                rsCorpse!ObjectDesc = "One eye of the corpse is dangling out of the socket while the other is relaxed and open."
            Case 7
                rsCorpse!ObjectDesc = "One eye of the corpse is dangling out of the socket while the other is wide open."
            Case 8
                rsCorpse!ObjectDesc = "How odd, both eyes of the corpse are missing."
            Case 9
                rsCorpse!ObjectDesc = "How odd, one eye of the corpse is missing."
            Case Else
                rsCorpse!ObjectDesc = "There is nothing special about this corpse."
        End Select
        rsCorpse!x = lCX
        rsCorpse!y = lCY
        rsCorpse!z = lCZ
        rsCorpse!AC = MyCLng(lACLevel / 6) + lRandom(MyCLng(lACLevel / 6)) 'just to keep it profitable
        rsCorpse!Weight = 2500 + lRandom(1000) + (lACLevel * 4)
        
        If (lRandom(5) = 1) Then rsCorpse!Str = lRandom(2)
        If (lRandom(5) = 1) Then rsCorpse!Int = lRandom(2)
        If (lRandom(5) = 1) Then rsCorpse!Wis = lRandom(2)
        If (lRandom(5) = 1) Then rsCorpse!Dex = lRandom(2)
        If (lRandom(5) = 1) Then rsCorpse!Con = lRandom(2)
        If (lRandom(5) = 1) Then rsCorpse!Cha = lRandom(2)
        If (lRandom(5) = 1) Then rsCorpse!Luc = lRandom(2)
        If (lRandom(3) = 1) Then rsCorpse!CHITROLL = lRandom(MyCLng(lACLevel / 4))
        If (lRandom(3) = 1) Then rsCorpse!AverageDamage = lRandom(MyCLng(lACLevel / 4))
        
        rsCorpse!DurabilityBroken = lRandom(9) + 1
        rsCorpse!DurabilityMAX = 10
        rsCorpse!Status = 0 'on ground
        rsCorpse!PlayerID = 0 'corpse doesnt belong to a player unless picked up
        rsCorpse!Burried = 0 'not burried
        rsCorpse!LockStatus = 10 'open and unlocked
        rsCorpse!RottingRounds = gblcstlRottingRounds
        rsCorpse!Location = 85 'All corpses go over a shoulder.
        rsCorpse.Update
        Set rsCorpse = Nothing
        
        lNewObjectID = 0: lCountofStolenItems = 0
        Select Case zType
            Case "M"
                'We also need to copy the contents of the player or mob to the corpse container.
                Set rsCorpse = MyDB.OpenRecordset("SELECT tblMobEquipmentItems.RareRandom, tblMobEquipmentItems.StolenItem, tblMobEquipmentItems.ObjectID, tblObject.ObjectName FROM tblMobEquipmentItems INNER JOIN tblObject ON tblMobEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblMobEquipmentItems.MobID)=" & lTypeID & "));", dbOpenSnapshot)
                Do While (Not rsCorpse.EOF)
                    lObjectID = MyCLng(rsCorpse!ObjectID)
                    subDeleteObjectIDLostItemsReport lObjectID
                    zObjectName = MyCStr(rsCorpse!ObjectName) ' DO NOT PARSE zObjectName
                    iStolenItem = MyCInt(rsCorpse!StolenItem) 'stolen when <>0 [true]
                    'OBJECT COPY FOR PLAYER
                    'Did the mob drop anything by chance? DO NOT PARSE zObjectName here
                    If (Not bObjectInAreaByName(zObjectName, lCX, lCY, lCZ) Or iStolenItem <> 0) Then 'We dont drop more than one object in one area until its picked up.
                        lHoldRareRandom = MyCLng(rsCorpse!RareRandom)
                        lPlayerRoll = lRandom(lCMagicFind) + lCMagicFindBase
                        If (lPlayerRoll >= lCMagicFind) Then lPlayerRoll = lCMagicFind
                        lMobRoll = lRandom(lHoldRareRandom)
                        zStatus = ""
                        If (iStolenItem <> 0) Then 'YES? detach from mob equipment inventory give to player inv
                            lCountofStolenItems = lCountofStolenItems + 1
                            MyDB.Execute "DELETE FROM tblMobEquipmentItems WHERE (MobID=" & lTypeID & " AND ObjectID=" & lObjectID & ");", dbFailOnError
                            MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & lPlayerID & ", " & lObjectID & ";", dbFailOnError
                            MyDB.Execute "UPDATE tblObject SET Status = 2, PlayerID = " & lPlayerID & " WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                            subSendMsg "&Athe " & zShortstop(zObjectName) & " was retrieved from the thief/outlaw/pirate.", zPortID
                        Else 'no so we mf for the item
                            If (lPlayerRoll >= lMobRoll And lObjectID <> 0) Then
                                zStatus = "&WYOU GOT THE ITEM!"
                                If ((gblbAutoloot(MyCLng(zPortID))) And (lPlayerID <> 0)) Then
                                    'We give the player the item instead of making a corpse and placing the item in the corpse
                                    lNewObjectID = lDuplicateObject(MyCLng(rsCorpse!ObjectID), lPlayerID, lPlayerLevel, (lMobRoll < 3), ((lCMagicFind - lPlayerRoll) < 2), False, 0)
                                Else
                                    lNewObjectID = lDuplicateObject(MyCLng(rsCorpse!ObjectID), 0, lPlayerLevel, (lMobRoll < 3), ((lCMagicFind - lPlayerRoll) < 2), False, 0)
                                    'We put the copied object into the container aka Corpse.
                                    If (lNewObjectID <> 0) Then MyDB.Execute "INSERT INTO tblPlayerContainer ( ContainerObjectID, ObjectID ) SELECT " & lNewCorpseID & ", " & lNewObjectID & ";", dbFailOnError
                                End If
                            Else
                                zStatus = "&aNot this time..."
                            End If
                            subSendMsg "&y** You try for the " & zShortstop(zObjectName) & vbCrLf & "   " & strForceSize("CHANCE{" & lCMagicFindBase & "|" & lCMagicFind & " vs " & lHoldRareRandom & "(" & zPercentChance(lCMagicFind, lHoldRareRandom) & ") rolls are[" & lPlayerRoll & " vs " & lMobRoll & "]} ", 60, " ", "A") & zStatus, zPortID
                        End If
                    Else
                        subSendMsg "&ythe " & zShortstop(zObjectName) & " is already on the ground.", zPortID
                    End If
                    rsCorpse.MoveNext
                Loop
                Set rsCorpse = Nothing
                If (lCountofStolenItems > 0) Then
                    subSendMsg "&yYou found " & lCountofStolenItems & " stolen items.", zPortID
                    basRecalculateMobEquipment lTypeID
                End If
                If (lNewObjectID <> 0) Then subObjectContents zPortID, lNewCorpseID, UCase(zCorpseName) & " contents,"
            Case "P" 'take stuff from the player corpse
        End Select
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMakeCorpse," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDropObject(zPortID As String, zOObjectName As String)
On Error GoTo Err_Check
    Dim bSuccess As Boolean
    Dim rsPlayer As Recordset
    Dim rsData As Recordset
    Dim zObjectName As String
    Dim zSQL As String
    Dim lGettableLevel As Long
    Dim zGettableName As String
    Dim zCount As String
    Dim lPortID As Long
    Dim zSearchObjectName As String
    Dim lTopObject As Long
    Dim lObjectID As Long
    Dim lAllowedObjectsInArea As Long
    Dim bDropAllowed As Boolean
    Dim bPlayerOnShip As Boolean
    Dim bPlayerInHouse As Boolean
    Dim bPlayerInClanHall As Boolean
    Dim iGetLocationValue As Integer
    Dim bTooManyContainers As Boolean
    Dim bPermissionsToDrop As Boolean
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lDisarmedDuration As Long
    Dim zGender As String
    Dim zGenderVerbose As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim lInvisibilityDuration As Long
    Dim lImmortalLevel As Long
    Dim lPlayerLevel As Long
    
    'subDropObject zPortID, zPlayerName, lPlayerID, lX, lY, lZ, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5)), lStatus, lInvisibilityDuration
    'subDropObject(zPortID As String, zPlayerName As String, lPlayerID As Long, lngX As Long, lngY As Long, lngZ As Long, zOObjectName As String, lStatus As Long, lInvisibilityDuration As Long)
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, ImmortalLevel, InvisibilityDuration, Gender, Status, X, Y, Z, PlayerName, DisarmedDuration, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lDisarmedDuration = MyCLng(rsPlayer!DisarmedDuration)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lStatus = MyCLng(rsPlayer!Status)
        zGender = MyCStr(rsPlayer!Gender)
        zGenderVerbose = LCase(zTranslateGender(zGender, 2))
    End If
    Set rsPlayer = Nothing
    
    bPlayerInHouse = False
    bPlayerOnShip = False
    bPlayerInClanHall = False
    iGetLocationValue = iPlayerLocationValue(lPlayerID)
    Select Case (iGetLocationValue)
        Case 0, 10, 11, 12, 13
            bPlayerInHouse = (iGetLocationValue = 10 Or iGetLocationValue = 12)
            bPlayerOnShip = (iGetLocationValue = 11)
            bPlayerInClanHall = (iGetLocationValue = 13)
            bDropAllowed = True
        Case Else
            bDropAllowed = False
    End Select
    
    If (bPlayerOnShip) Then
        lAllowedObjectsInArea = 3
    Else
        If (bPlayerInHouse) Then
            lAllowedObjectsInArea = 9
        Else
            lAllowedObjectsInArea = gblcstlMaxAreaObjects
        End If
    End If
    
    If (bDropAllowed Or lImmortalLevel > 0) Then
        If (lTotalObjectsInArea(lX, lY, lZ) < lAllowedObjectsInArea Or lImmortalLevel > 0) Then
            'If (lInvisibilityDuration = 0) Then
                If (lStatus <> 50) Then
                    zSearchObjectName = zAntiSQLCrash(zOObjectName)
                    lTopObject = lTop(zSearchObjectName)
                    bSuccess = False
                    
                    If (bCheckAreaExists(zPortID, lX, lY, lZ, False)) Then
                        If (Len(zSearchObjectName) <> 0) Then
                            'Check to see if drop is allowed.
                            bPermissionsToDrop = (zAreaRules(10, lX, lY, lZ) = "1" Or lImmortalLevel > 0)
                            Select Case bPermissionsToDrop
                                Case False
                                    subSendMsg "&gThis is a no littering zone - you may donate the item if you like.", zPortID
                                Case True 'Allowed
                                    Select Case UCase(zSearchObjectName)
                                        Case "ALL" 'cannot drop containers with the ALL command
                                            If (bPlayerOnShip Or bPlayerInHouse Or bPlayerInClanHall) Then
                                                bDropAllowed = False
                                                subSendMsg "&RYou are in a specialized area and are unable to group drop here." & vbCrLf & "Instead try dropping only one item at a time.", zPortID
                                            Else
                                                If (lngSQLRecordCount("SELECT tblObject.ObjectID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.ReturnPlayerID)=0) AND ((tblObject.Cursed)=False) AND ((tblObject.CaptureFlagClanID)=0) AND ((tblObject.BonusXP)=0) AND ((tblObject.Gold)=0) AND ((tblObject.WeightMAX)=0) AND ((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & "));") <> 0) Then
                                                    bSuccess = True
                                                    MyDB.Execute "UPDATE tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID SET tblObject.X = " & lX & ", tblObject.Y = " & lY & ", tblObject.Z = " & lZ & ", tblObject.PlayerID = 0, tblObject.Status = 0, tblObject.GroundTimer = 0, tblObject.GroundTimerNotAvailable = " & (bPlayerInHouse Or bPlayerOnShip Or bPlayerInClanHall) & " WHERE (((tblObject.ReturnPlayerID)=0) AND ((tblObject.WeightMAX)=0) AND ((tblObject.Cursed)=False) AND ((tblObject.CaptureFlagClanID)=0) AND ((tblObject.BonusXP)=0) AND ((tblObject.Gold)=0) AND ((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & "));", dbFailOnError
                                                    MyDB.Execute "DELETE tblPlayerInventoryItems.* FROM tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID WHERE (((tblObject.ReturnPlayerID)=0) AND ((tblObject.Cursed)=False) AND ((tblObject.CaptureFlagClanID)=0) AND ((tblObject.WeightMAX)=0) AND ((tblObject.BonusXP)=0) AND ((tblObject.Gold)=0) AND ((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & "));", dbFailOnError
                                                    'subSendMsg "&cYou drop as much as you can.", zPortID
                                                    'subSendMsgAreaExcept2 gblzFNCYA & zPlayerName & " drops stuff on the ground.", lX, lY, lZ, zPortID, ""
                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "You drop as much as you can.", "", "%s1 drops some stuff on the ground.", lX, lY, lZ
                                                Else
                                                    subSendMsg "&cYou do not have anything that can group drop.", zPortID
                                                End If
                                            End If
                                        Case Else
                                            zSQL = "SELECT TOP " & lTopObject & " tblObject.ObjectID, tblObject.ObjectName, tblObject.WeightMax, tblObject.X, tblObject.Y, tblObject.Z, tblObject.Status, tblObject.PlayerID, tblObject.Cursed, tblObject.CaptureFlagClanID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.ReturnPlayerID)=0) AND ((tblObject.ObjectName) Like ""*" & zSearchObjectName & "*"") AND ((tblObject.PlayerID)=" & lPlayerID & ") AND ((tblObject.CaptureFlagClanID)=0)) ORDER BY tblObject.ObjectID;"
                                            Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                            If (Not rsData.EOF) Then
                                                bTooManyContainers = False
                                                
                                                rsData.MoveLast
                                                lObjectID = MyCLng(rsData!ObjectID)
                                                zObjectName = zAdverb(MyCStr(rsData!ObjectName), 2) & zShortstop(MyCStr(rsData!ObjectName)) & zCount
                                                If (bPlayerOnShip) Then
                                                    If (MyCLng(rsData!WeightMax) <> 0) Then
                                                        If (lngSQLRecordCount("SELECT ObjectID, X, Y, Z, WeightMax FROM tblObject WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND WeightMax>0 AND Status=0);") > 2) Then
                                                            bTooManyContainers = True
                                                        End If
                                                    End If
                                                End If
                                                
                                                If (Not bTooManyContainers) Then
                                                    bSuccess = True
                                                    If (MyCInt(rsData!Cursed) <> 0) Then
                                                        subSendMsgAreaAllDISmart "&r", zPlayerName, "%s1 cannot let go of " & zObjectName & ".", "", "%s1 cannot let go of " & zObjectName & ".", lX, lY, lZ
                                                        'subSendMsg "&RYou cannot let go of " & zObjectName & "!", zPortID
                                                        'subSendMsgAreaExcept2 gblzFBRED & zPlayerName & " cannot let go of " & zObjectName & "!", lX, lY, lZ, zPortID, ""
                                                    Else
                                                        MyDB.Execute "UPDATE tblObject SET X = " & lX & ", Y = " & lY & ", Z = " & lZ & ", GroundTimer = 0, Status = 0, PlayerID = 0, GroundTimerNotAvailable = " & (bPlayerInHouse Or bPlayerOnShip Or bPlayerInClanHall) & " WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                                                        MyDB.Execute "DELETE ObjectID FROM tblPlayerInventoryItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                                                        subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 place " & zObjectName & " on the ground.", "", "%s1 places " & zObjectName & " on the ground.", lX, lY, lZ
                                                        'subSendMsg "&cYou place " & (zObjectName) & " on the ground.", zPortID
                                                        'subSendMsgAreaExcept2 gblzFNCYA & zPlayerName & " places " & (zObjectName) & " on the ground.", lX, lY, lZ, zPortID, ""
                                                        If (lImmortalLevel > 0) Then 'if an immortal is at a Pond and the pond does not have the special objectID set - this will cause the pool to take the item as the special item and mark it as status=1
                                                            If (bPlayerAtPoolWithNoSpecialObjectYetSet(lX, lY, lZ)) Then
                                                                subSendMsg "&cThe Pool absorbs " & (zObjectName) & " into its Special Object's Davey-jones locker.", zPortID
                                                                MyDB.Execute "UPDATE tblObject SET Status = 1 WHERE (ObjectID=" & lObjectID & ");", dbFailOnError 'makes it dissappear into the ground
                                                                subImmortalAtPoolSetSpecialObject lX, lY, lZ, lObjectID
                                                            End If
                                                        End If
                                                    End If
                                                Else
                                                    subSendMsg "&GDonate for a HOUSE if you need more container space.", zPortID
                                                End If
                                            Else
                                                subSendMsg "&gYou cannot drop what you do not have in your inventory." & vbCrLf & "NOTE: You cannot drop a clan flag once you have picked it up." & vbCrLf & "      You cannot drop stamped items.", zPortID  '& vbCrLf & "      You cannot drop containers: pouches, backpacks, etc...", zPortID
                                            End If
                                    End Select
                                    Set rsData = Nothing
                                    lPortID = MyCLng(zPortID)
                                    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                                        gbllRecalculatedDelay(lPortID) = -2 'we force the recalculate before we present SCORE values
                                        subRecalculatePlayerEquipment lReturnPlayerIDPortID(zPortID), zPortID
                                    End If
                            End Select
                        Else
                            subSendMsg "&GDrop what?", zPortID
                        End If
                    Else
                        subSendMsg "&GYou cannot drop something in the void." & vbCrLf & "Use the RC (room name) command first then drop your object.", zPortID
                    End If
                    
                    If (bSuccess) Then
                        subWeaponsActivateGernadesArea lX, lY, lZ, zPortID
                        subActiveGettablesInArea lPlayerLevel, lX, lY, lZ, zPortID
                        subRecalculatePlayerEquipment lPlayerID, zPortID
                    End If
                Else
                    subSendMsg "&GYou are asleep you cannot move.", zPortID
                End If
            'Else
                'subSendMsg "&gToo much movement would break your invisibility.", zPortID
            'End If
        Else
            If (bPlayerOnShip) Then
                subSendMsg "&GThe starship is at full capacity!" & vbCrLf & "&gDonate for a house for more storage area. (help paypal)", zPortID
            Else
                If (bPlayerInHouse) Then
                    subSendMsg "&GYour house is at full capacity!" & vbCrLf & "&gDonate for another house at a reduced cost for more storage area. (help paypal)", zPortID  '& vbCrLf & "Bags and cargo pods are available which" & vbCrLf & "will extend the room within your house."
                Else
                    subSendMsg "&gThere is too much stuff in this room to drop anything else.", zPortID
                End If
            End If
        End If
    Else
        subSendMsg "&RA magical barrier prevents you from littering here.", zPortID
    End If
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subDropObject," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subActiveGettablesInArea(lPlayerLevel As Long, lngX As Long, lngY As Long, lngZ As Long, zPortID As String)
On Error GoTo Err_Check
    Const cstMultiplier = 4 'MUST BE LARGER VALUE THAN 1
    Dim rsMob As Recordset
    Dim rsObject As Recordset
    Dim lOriginalMobID As Long
    Dim lObjectID As Long
    Dim zMobName As String
    Dim lMobLevel As Long
    Dim lMaxMHP As Long
    Dim lAC As Long
    Dim lGivesObjectID As Long 'when you kill a mimic you can get a special item
    
    If (Abs(gbllMoon) <> 5) Then 'gbllMoon As Long '-5 skullmoon // +5 eclipse
        lOriginalMobID = 0
        Set rsObject = MyDB.OpenRecordset("SELECT tblObject.OriginalMobID, tblObject.ObjectID, tblObject.X, tblObject.Y, tblObject.Z, tblObject.Status FROM tblObject WHERE (((tblObject.OriginalMobID)<>0) AND ((tblObject.X)=" & lngX & ") AND ((tblObject.Y)=" & lngY & ") AND ((tblObject.Z)=" & lngZ & ") AND ((tblObject.Status)=0));", dbOpenSnapshot)
        Do While (Not rsObject.EOF)
            lObjectID = MyCLng(rsObject!ObjectID)
            lOriginalMobID = MyCLng(rsObject!OriginalMobID)
            Set rsMob = MyDB.OpenRecordset("SELECT MobName, MobLevel, Gender FROM tblMob WHERE (MobID=" & lOriginalMobID & ");", dbOpenSnapshot)
            If (Not rsMob.EOF) Then
                zMobName = zShortstop(rsMob!MobName)
                lMobLevel = MyCLng(rsMob!MobLevel)
                If lMobLevel < 29 Then lMobLevel = 29
                lMaxMHP = ((lMobLevel * (cstMultiplier - 1)) * cstMobHPRespawn)
                If (lMaxMHP < 999) Then lMaxMHP = 999 'prevents div by 0 error
                lGivesObjectID = lRandomObjectIDbyMob() 'TRISKER WORK
                lAC = lRandom(333) + MyCLng(lMaxMHP / 10)
                MyDB.Execute "INSERT INTO tblMob ( CHITROLLBase, CDAMROLLBase, CHITROLLBonus, CDAMROLLBonus, MAC, GivesObjectID, ImmunitySlayLevel, Gender, NumAttRnd, MoveAllowed, MHP, MAXMHP, MobDesc, MobLevel, MobName, SpecialSelfDeleting, X, Y, Z, MobAutoAttacks, MobAutoAttacksDuration ) SELECT 2000, 200, 200, 200, " & lAC & ", " & lGivesObjectID & ", 5, '" & MyCStr(rsMob!Gender) & "', 4, True, " & lMaxMHP & ", " & lMaxMHP & ", 'I  AM  M I M I C ! ! ! Hear me roar !', " & (lMobLevel * cstMultiplier) & ", 'Mimic " & LCase(zMobName) & "', True, " & lngX & ", " & lngY & ", " & lngZ & ", True, 30+" & (lMobLevel * 2) & ";", dbFailOnError
                MyDB.Execute "UPDATE tblObject SET OriginalMobID=0 WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                If (lContainerItemContentTotal(lObjectID) = 0) Then MyDB.Execute "DELETE ObjectID FROM tblObject WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
            End If
            Set rsMob = Nothing
            rsObject.MoveNext
        Loop
        Set rsObject = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subActiveGettablesInArea::subDropObject," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subGetObjectGround(zPortID As String, zOObjectName As String)
On Error GoTo Err_Check
    Dim iSuccess As Integer
    Dim lObjectID As Long
    Dim zObjectName As String
    Dim rsPlayer As Recordset
    Dim rsData As Recordset
    Dim lPortID As Long
    Dim zMsg As String
    Dim zSQL As String
    Dim lDummy As Long
    Dim rsClanFlag As Recordset
    Dim lTopObject As Long
    Dim zSearchName As String
    Dim bGetAllowed As Boolean
    Dim bNoGetNoPickUpZone As Boolean
    Dim bJediGet As Boolean
    'Dim bTired As Boolean 'bTired = (lRandom(lReturnClassTiredRandom(zClass)) = 1)
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lDisarmedDuration As Long
    Dim lPlayerLevel As Long
    Dim zGender As String
    Dim zGenderVerbose As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim lInvisibilityDuration As Long
    Dim zRace As String
    Dim lImmortalLevel As Long
    Dim lPlayerSTR As Long
    Dim lPlayerWeight As Long
    Dim lClanID As Long
    Dim zClass As String
    Dim zSpecialMsg As String
    'subGetObjectGround(zPortID As String, zPlayerName As String, lPlayerLevel As Long, lImmortalLevel As Long, lPlayerID As Long, lngX As Long, lngY As Long, lngZ As Long, zOObjectName As String, lPlayerWeight As Long, lPlayerSTR As Long, lClanID As Long, zRace As String)
    'subGetObjectGround zPortID, zPlayerName, lPlayerLevel, lImmortalLevel, lPlayerID, lX, lY, lZ, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5)), lWeight, lCStr, lClanID, zRace
    
    zSpecialMsg = ""
    lObjectID = 0
    bJediGet = False
    bNoGetNoPickUpZone = False
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT Class, PlayerLevel, ClanID, Weight, CStr, ImmortalLevel, Race, InvisibilityDuration, Gender, Status, X, Y, Z, PlayerName, DisarmedDuration, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zClass = MyCStr(rsPlayer!Class)
        lDisarmedDuration = MyCLng(rsPlayer!DisarmedDuration)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lClanID = MyCLng(rsPlayer!ClanID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lPlayerSTR = MyCLng(rsPlayer!CStr)
        lStatus = MyCLng(rsPlayer!Status)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        zRace = MyCStr(rsPlayer!Race)
        zGender = MyCStr(rsPlayer!Gender)
        zGenderVerbose = LCase(zTranslateGender(zGender, 2))
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lPlayerWeight = MyCLng(rsPlayer!Weight)
    End If
    Set rsPlayer = Nothing
    
    If (lStatus <> 50) Then
        'bTired = False
        zMsg = ""
        bJediGet = (zClass = "KN")
        bNoGetNoPickUpZone = (zAreaRules(11, lX, lY, lZ) = "0")
        If (Not bJediGet And bNoGetNoPickUpZone) Then
            subSendMsg "&RThis is a no pick up or get zone.", zPortID
        Else
            If (bJediGet And bNoGetNoPickUpZone) Then 'Jedi Knights can pick up from any area
                subSendMsg "&AYou use your powers of the force and betray the area rules of the area.", zPortID
                subSendMsgAreaExcept2 gblzFNBLA & zPlayerName & " calls upon the force to break the area rules.", lX, lY, lZ, zPortID, ""
            End If
        
            If (lTotalObjectsPlayerInv(lPlayerID) <= cstlBaseItemsHeld + lInvHoldRaceBonus(zRace)) Then
                iSuccess = 0
            
                zObjectName = "Phasing" 'this means an error occured.
                zSearchName = zAntiSQLCrash(zOObjectName)
                
                Select Case (iPlayerLocationValue(lPlayerID))
                    Case 0, 10, 11, 12, 13
                        bGetAllowed = True
                    Case Else
                        bGetAllowed = False
                End Select
                
                If (bGetAllowed) Then
                    If (lTotalObjectsPlayerInv(lPlayerID) <= cstlBaseItemsHeld + lInvHoldRaceBonus(zRace)) Then
                        Select Case UCase(zSearchName)
                            Case "ALL"
                                If (lTotalObjectsPlayerInv(lPlayerID) + lTotalObjectsInArea(lX, lY, lZ) <= cstlBaseItemsHeld + lInvHoldRaceBonus(zRace)) Then
                                    If (lngSQLRecordCount("SELECT X, Y, Z, ExplodeDuration, PlayerID, Location, Status, BonusXP, Gold, CaptureFlagClanID FROM tblObject GROUP BY X, Y, Z, SpecialSelfDeletingDelay, ExplodeDuration, PlayerID, Location, Cursed, Status, BonusXP, Gold, CaptureFlagClanID, Burried HAVING (Burried=False AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND ExplodeDuration=0 AND Location<>0 AND Status=0 AND BonusXP=0 AND Gold=0 AND CaptureFlagClanID=0 AND SpecialSelfDeletingDelay=0 AND PlayerID=0);") <> 0) Then
                                        MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & lPlayerID & " AS AppendPlayerID, ObjectID FROM tblObject WHERE (Burried=False AND ExplodeDuration=0 AND Status=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Location<>0 AND BonusXP=0 AND Gold=0 AND (ReturnPlayerID=0 Or ReturnPlayerID=" & lPlayerID & ") AND PlayerID=0 AND SpecialSelfDeletingDelay=0 AND CaptureFlagClanID=0);", dbFailOnError
                                        MyDB.Execute "UPDATE tblObject SET PlayerID = " & lPlayerID & ", Status = 2, GroundTimer = 0, GroundTimerNotAvailable = True WHERE (Burried=False AND ExplodeDuration=0 AND Status=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Location<>0 AND BonusXP=0 AND Gold=0 AND (ReturnPlayerID=0 Or ReturnPlayerID=" & lPlayerID & ") AND PlayerID=0 AND SpecialSelfDeletingDelay=0 AND CaptureFlagClanID=0);", dbFailOnError
                                        subSendMsgAreaAllDISmart "&y", zPlayerName, "You grab as much as you can off the ground.", "", "%s1 grabs as much as possible from the ground.", lX, lY, lZ
                                        'subSendMsg "&cYou get as much as you can.", zPortID
                                        'subSendMsgAreaExcept2 gblzFNCYA & zPlayerName & " gets stuff from the ground.", lX, lY, lZ, zPortID, ""
                                        subRecalculatePlayerEquipment lPlayerID, zPortID
                                        'CaptureFlagClanID
                                    Else
                                        subSendMsg "&cThere is nothing here you can grab all at the same time.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYou would be overloaded if you got all of that.", zPortID
                                End If
                            Case Else
                                lTopObject = lTop(zSearchName)
                                zSQL = "SELECT TOP " & lTopObject & " SpecialSelfDeletingDelay, BonusXP, ObjectID, Gold, CaptureFlagClanID, SitMAX, ObjectName, GroundTimer, GroundTimerNotAvailable, Location, Weight, X, Y, Z, PlayerID, QuestRespawnX, QuestRespawnY, QuestRespawnZ, Status, ReturnPlayerID, QuestForGlory FROM tblObject WHERE (SpecialSelfDeletingDelay=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND PlayerID=0 AND Status=0 AND Burried=0 AND ExplodeDuration=0 AND ObjectName Like ""*" & zSearchName & "*"") ORDER BY ObjectID;"
                                zMsg = "[ground]"
                                Set rsData = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                                If (Not rsData.EOF) Then
                                    rsData.MoveLast
                                    lObjectID = MyCLng(rsData!ObjectID)
                                    zObjectName = zShortstop(MyCStr(rsData!ObjectName))
                                    If (MyCLng(rsData!SitMAX) = 0 Or lImmortalLevel > 96) Then
                                        If (MyCLng(rsData!ReturnPlayerID) = lPlayerID Or MyCLng(rsData!ReturnPlayerID) = 0) Then
                                            If (MyCInt(rsData!QuestForGlory) <> 0 And (lImmortalLevel <= 90)) Then 'This is a special Quest item - when a player picks it up they get glory automatically for it.
                                                iSuccess = 3 'Get glory item.
                                                'subDeleteObjectIDLostItemsReport lObjectID 'MyDB.Execute "INSERT INTO tblPlayerLostItem ( PlayerID, ObjectID, X, Y, Z, LostMsg ) SELECT " & lPlayerID & ", " & lObjectID & ", " & lX & ", " & lY & ", " & lZ & ", 'TS';", dbFailOnError
                                                MyDB.Execute "UPDATE tblPlayer SET tblPlayer.Crown = [tblPlayer].[Crown] + " & MyCLng(rsData!QuestForGlory) & " WHERE (((tblPlayer.PlayerID)=" & lPlayerID & "));", dbFailOnError 'Give Player the Glory.
                                                'subSendMsgInfoChannel "[" & zWhereName(lX, lY, lZ) & "&g] &w" & zPlayerName & " found the " & zObjectName & " and recieved " & (MyCLng(rsData!QuestForGlory)) & " glory!"
                                                subSendMsgInfoChannel "[" & zWhereName(lX, lY, lZ) & "&g] &w" & zPlayerName & " &a[found] &g[" & zObjectName & "] " & zFormatGoldCofGLearnpts(MyCLng(rsData!BonusXP), "X", True) & zFormatGoldCofGLearnpts(MyCLng(rsData!Gold), "G", True) & zFormatGoldCofGLearnpts(MyCLng(rsData!QuestForGlory), "C", True)
                                                
                                                'subSendMsgAreaAll gblzFBWHI & "The voices of &Btime &Wand &Benergy &Wbring forth " & gblzFBBLU & zAdverb(zObjectName, 4) & zObjectName & "&W!", MyCLng(rsData!QuestRespawnX), MyCLng(rsData!QuestRespawnY), MyCLng(rsData!QuestRespawnZ)
                                                'subImmortalPrayChannel zPlayerName, gblzFBGRE & " QUEST FOR " & UCase(zObjectName) & " SOLVED! &YPlayer recieved " & (MyCInt(rsData!QuestForGlory)) & " crown(s)!", zPortID 'space in front of quest is required!
                                                rsData.Edit 'The item goes back to the gods for a new placement for it.
                                                rsData!x = MyCLng(rsData!QuestRespawnX) 'It goes back to the gods.
                                                rsData!y = MyCLng(rsData!QuestRespawnY)
                                                rsData!z = MyCLng(rsData!QuestRespawnZ)
                                                rsData!GroundTimer = 0
                                                rsData!SpecialSelfDeletingDelay = 0
                                                'rsData!GroundTimerNotAvailable = True
                                                rsData!PlayerID = 0 'Mark object as glory
                                                rsData!Status = 0 'Mark object as glory
                                                'rsData!GroundTimer = 0 not needed here sice its prevented from the counting group
                                                rsData.Update
                                            Else
                                                If (MyCLng(rsData!Location) <> 0 Or lImmortalLevel >= 40) Then 'Immortals can pick up non movable items that have the location of 0
                                                    If (MyCInt(rsData!QuestForGlory) <> 0 And lImmortalLevel >= 40) Then
                                                        subSendMsg "&WTHIS IS A QUEST ITEM!" & vbCrLf & "Drop this item somewhere in the realm and ramble to all players" & vbCrLf & "that this item is to be found for crowns." & vbCrLf & "You may also put this item down again.", zPortID
                                                    End If
                                                    
                                                    If (rsData!Location = 0 And lImmortalLevel >= 99) Then
                                                        subSendMsg "&RWARNING OBJECT LOCATION IS NOT SET SO ONLY POWERFUL" & vbCrLf & "IMMORTALS CAN PICK THIS ITEM UP AS THE ITEM IS!", zPortID
                                                    End If
                                                    
                                                    iSuccess = 1
                                                    If (MyCLng(rsData!Location) = 120 Or MyCLng(rsData!Location) = 121) Then 'is it gold or a chunk of extra experience?
                                                    Else
                                                        If (rsData!Location <> 0 Or lImmortalLevel >= 99) Then
                                                            If (lPlayerSTR * gbllPlayerWeightMultiplierInGrams >= lPlayerWeight + MyCLng(rsData!Weight)) Then
                                                                rsData.Edit
                                                                If (MyCLng(rsData!CaptureFlagClanID) <> 0) Then
                                                                    If (lPlayerLevel > 29) Then
                                                                        If (Not bReturnOutCastedPlayerID(lPlayerID)) Then
                                                                            If (lClanID <> 0) Then
                                                                                If (MyCLng(rsData!CaptureFlagClanID) = lClanID) Then
                                                                                    Set rsClanFlag = MyDB.OpenRecordset("SELECT ClanID, ClanFlagReturnX, ClanFlagReturnY, ClanFlagReturnZ FROM tblPlayerClan WHERE (ClanID=" & lClanID & ");", dbOpenSnapshot)
                                                                                    If (Not rsClanFlag.EOF) Then
                                                                                        If (MyCLng(rsClanFlag!ClanFlagReturnX) = lX And MyCLng(rsClanFlag!ClanFlagReturnY) = lY And MyCLng(rsClanFlag!ClanFlagReturnZ) = lZ) Then
                                                                                            iSuccess = 70
                                                                                            subSendMsg "&GYour clan flag is supposed to be here.", zPortID
                                                                                        Else 'Flag returned
                                                                                            iSuccess = 71
                                                                                            subSimpleEchoChannel "&G" & zPlayerName & " returns the " & zObjectName & "!"
                                                                                            rsData!x = MyCLng(rsClanFlag!ClanFlagReturnX)
                                                                                            rsData!y = MyCLng(rsClanFlag!ClanFlagReturnY)
                                                                                            rsData!z = MyCLng(rsClanFlag!ClanFlagReturnZ)
                                                                                            rsData!GroundTimer = 0
                                                                                            'rsData!GroundTimerNotAvailable = True
                                                                                            rsData!SpecialSelfDeletingDelay = 0
                                                                                            rsData!PlayerID = 0
                                                                                            rsData!Status = 0
                                                                                        End If
                                                                                    End If
                                                                                    Set rsClanFlag = Nothing
                                                                                Else
                                                                                    subSimpleEchoChannel "&C" & zPlayerName & " captures the " & zObjectName & "!"
                                                                                    rsData!PlayerID = lPlayerID 'Mark object as players
                                                                                    rsData!Status = 2 'Mark object as players
                                                                                    rsData!GroundTimer = 0
                                                                                    rsData!GroundTimerNotAvailable = True
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&RYou must be in a clan to play Capture the Flag!", zPortID
                                                                                iSuccess = 72
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&RYou are an outcasted player!" & vbCrLf & "You must prove yourself before being able to pick up a flag!", zPortID
                                                                            iSuccess = 73
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&RYou must be at least level 30 to play Capture the Flag!", zPortID
                                                                        iSuccess = 72
                                                                    End If
                                                                Else
                                                                    rsData!PlayerID = lPlayerID 'Mark object as players
                                                                    rsData!Status = 2 'Mark object as players
                                                                    rsData!GroundTimer = 0
                                                                End If
                                                                If (MyCLng(rsData!Status) = 2) Then
                                                                    MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & lPlayerID & ", " & MyCLng(rsData!ObjectID) & ";", dbFailOnError 'Give object to player
                                                                End If
                                                                rsData.Update
                                                            Else
                                                                iSuccess = 5
                                                            End If
                                                        Else
                                                            iSuccess = 2
                                                        End If
                                                    End If
                                                Else
                                                    iSuccess = 2
                                                End If
                                            End If
                                            
                                            'Add gold to player
                                            Select Case (MyCLng(rsData!Location))
                                                Case 120
                                                    lDummy = MyCLng(rsData!Gold)
                                                    MyDB.Execute "UPDATE tblPlayer SET tblPlayer.Gold = [tblPlayer].[Gold]+" & lDummy & " WHERE (((tblPlayer.PlayerID)=" & lPlayerID & "));", dbFailOnError
                                                    zSpecialMsg = zFormatGoldCofGLearnpts(lDummy, "g", True)
                                                    MyDB.Execute "DELETE tblObject.ObjectID, tblObject.Location FROM tblObject WHERE (((tblObject.ObjectID)=" & MyCLng(rsData!ObjectID) & ") AND ((tblObject.Location)=120)) OR (((tblObject.ObjectID)=" & MyCLng(rsData!ObjectID) & ") AND ((tblObject.Location)=121));", dbFailOnError 'Delete object
                                                Case 121
                                                    lDummy = MyCLng(rsData!BonusXP)
                                                    MyDB.Execute "UPDATE tblPlayer SET tblPlayer.XP = [tblPlayer].[XP]+" & lDummy & " WHERE (((tblPlayer.PlayerID)=" & lPlayerID & "));", dbFailOnError
                                                    zSpecialMsg = zFormatGoldCofGLearnpts(lDummy, "X", True)
                                                    MyDB.Execute "DELETE tblObject.ObjectID, tblObject.Location FROM tblObject WHERE (((tblObject.ObjectID)=" & MyCLng(rsData!ObjectID) & ") AND ((tblObject.Location)=120)) OR (((tblObject.ObjectID)=" & MyCLng(rsData!ObjectID) & ") AND ((tblObject.Location)=121));", dbFailOnError 'Delete object
                                            End Select
                                        Else
                                            iSuccess = 4
                                        End If
                                    Else
                                        iSuccess = 6
                                    End If
                                    
                                    Select Case iSuccess
                                        Case 1
                                            subDeleteObjectIDLostItemsReport lObjectID
                                            subRecalculatePlayerEquipment lPlayerID, zPortID
                                            subSendMsgAreaAllDISmart "&y", zPlayerName, "You pick up " & zMsg & " " & zAdverb(zObjectName, 2) & zObjectName & zSpecialMsg, "", "%s1 picks up " & zAdverb(zObjectName, 2) & zObjectName & zSpecialMsg, lX, lY, lZ
                                        Case 2
                                            subSendMsg "&gYou cannot pick that up.", zPortID
                                        Case 3
                                            subDeleteObjectIDLostItemsReport lObjectID
                                            'subSendMsg "&GThe &C" & zObjectName & zSpecialMsg & "&G vanishes in a puff of glitter and scatters to the winds.", zPortID
                                            gbllQuestGuardAreaID(lPortID) = 0 'clear lazyguard
                                            gblzQuestGuardAreaDesc(lPortID) = ""
                                            gbllQuestGuardFailCount(lPortID) = 0
                                        Case 4
                                            'subSendMsg "&cYou reach for " & zAdverb(zObjectName, 4) & zObjectName & "." & vbCrLf & "You are " & "&Rzapped " & "&cby " & zAdverb(zObjectName, 4) & zObjectName & vbCrLf & "and decide its best to just leave THAT alone.", zPortID
                                            'subSendMsgAreaExcept2 gblzFNRED & zPlayerName & " gets zapped by " & zAdverb(zObjectName, 2) & zObjectName & ".", lX, lY, lZ, zPortID, ""
                                            subSendMsgAreaAllDISmart "&R", zPlayerName, "ZAP! You fail to pick up " & zAdverb(zObjectName, 2) & (zObjectName) & ".", "", "ZAP! %s1 fails to pick up " & zAdverb(zObjectName, 2) & (zObjectName) & ".", lX, lY, lZ
                                        Case 5
                                            subSendMsg "&RYou cannot lift that much total weight.", zPortID
                                        Case 6
                                            subSendMsg "&GYou can sit on the " & zObjectName & " but not take it.", zPortID
                                        Case 70
                                            subSendMsg "&MYou happily gaze at your clan flag instead.", zPortID
                                        Case 71
                                            subSendMsg "&GWay to Go!", zPortID
                                        Case 72
                                            subSendMsg "&MYou happily gaze at the clan flag instead.", zPortID
                                        Case 73
                                            subSendMsg "&MYou are not pleased.", zPortID
                                        Case Else
                                            subSendMsg "&gI do not see that object around here.", zPortID
                                    End Select
                                Else
                                    subSendMsg "&gYou do not see anything you can pickup here.", zPortID
                                End If
                                Set rsData = Nothing
                        End Select
                    Else
                        subSendMsg "&cThere is too much stuff here, you would be overloaded.", zPortID
                    End If
                Else
                    subSendMsg "&RA magical barrier prevents you from stealing from here.", zPortID
                End If
            Else
                subSendMsg "&rIf you bent over to get that you would drop something from your inventory.", zPortID
            End If
        End If
    Else
        subSendMsg "&GYou dream of gathering treasures and rares.", lX, lY, lZ, zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subGetObjectGround," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subGivesObjectID(lPlayerID As Long, lPassObjectID As Long, lPlayerLevel As Long, zPortID As String)
On Error GoTo Err_Check
    Dim lNewObjectID As Long 'NOTE: GivesObjectID GivesObjectChance [future flexibility]
    If (lPassObjectID <> 0) Then
        lNewObjectID = lDuplicateObject(lPassObjectID, lPlayerID, lPlayerLevel, False, True, False, 0)
        If (lNewObjectID <> 0) Then
            subSendMsg "&W" & zShortstop(zReturnObjectName(lNewObjectID)) & " &Wis yours!", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subGivesObjectID," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
