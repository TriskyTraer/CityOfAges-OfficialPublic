Attribute VB_Name = "modClanModule"
Option Explicit
Public Function lTotalInductedOfficers(lClanID As Long) As Long
On Error GoTo Err_Check
    Dim rsOfficer As Recordset
    Dim lReturn As Long
    lReturn = 0
    Set rsOfficer = MyDB.OpenRecordset("SELECT ClanID, Count(ClanMemberLevel) AS CountOfClanMemberLevel FROM tblPlayer GROUP BY ClanID, ClanMemberLevel HAVING (ClanID=" & lClanID & " AND ClanMemberLevel>6 AND ClanMemberLevel<18);", dbOpenDynaset)
    Do While (Not rsOfficer.EOF)
        lReturn = lReturn + MyCLng(rsOfficer!CountOfClanMemberLevel)
        rsOfficer.MoveNext
    Loop
    Set rsOfficer = Nothing
    lTotalInductedOfficers = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTotalInductedOfficers," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subInductionSetClanMemberLevel(zTargetPlayer As String, zClanMemberLevel As String, lClanID As Long, zPortID As String, lLeaderClanMemberLevel As Long, lClanLeaderPlayerID As Long, lImmortalLevel As Long, zPlayerName As String)
On Error GoTo Err_Check
    Const cstlMaxOfficersClan = 6
    Dim rsPlayer As Recordset
    Dim lPlayerLevel As Long
    Dim lClanMemberLevel As Long
    Dim zTPortID As String
    
    lClanMemberLevel = lRankLevel(zClanMemberLevel)
    
    If (lImmortalLevel > 0) Then '  If (lLeaderClanMemberLevel > lClanMemberLevel Or lImmortalLevel <> 0) Then    a player can induct any player with a lower rank than their own
        Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, RecallX, RecallY, RecallZ, PlayerID, PortID, PlayerName, ClanID, ClanMemberLevel, PlayerLevel FROM tblPlayer WHERE (PlayerName='" & zKeepLettersOnly(zTargetPlayer) & "');", dbOpenDynaset)
        If (Not rsPlayer.EOF) Then
            zTPortID = MyCStr(rsPlayer!PortID)
            If (MyCLng(zTPortID) > 0) Then
                If (lLeaderClanMemberLevel > MyCLng(rsPlayer!ClanMemberLevel) Or lImmortalLevel <> 0) Then
                    If (lClanLeaderPlayerID <> MyCLng(rsPlayer!PlayerID)) Then
                        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
                        If (lPlayerLevel > 19) Then
                            'If (lPlayerLevel < 299) Then
                                If (lTotalInductedOfficers(lClanID) < cstlMaxOfficersClan Or lClanMemberLevel < 7) Then
                                    If (MyCLng(rsPlayer!ClanID) = 0 Or MyCLng(rsPlayer!ClanID) = lClanID) Then
                                        If (MyCLng(rsPlayer!ClanID) = 0) Then
                                            subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " was inducted into your clan!", zPortID
                                            subSendMsg "&GYou were inducted into a clan by " & zPlayerName & ".", zTPortID
                                        End If
                                        
                                        rsPlayer.Edit
                                        Select Case lClanMemberLevel
                                            Case 1 To 18
                                                rsPlayer!ClanID = lClanID
                                                rsPlayer!ClanMemberLevel = lClanMemberLevel
                                            Case Else
                                                lClanID = 0
                                                lClanMemberLevel = 0
                                                rsPlayer!ClanID = lClanID
                                                rsPlayer!ClanMemberLevel = lClanMemberLevel
                                                rsPlayer!x = 0
                                                rsPlayer!y = 0
                                                rsPlayer!z = 0
                                                rsPlayer!RecallX = 0
                                                rsPlayer!RecallY = 0
                                                rsPlayer!RecallZ = 0
                                                subSendMsg "&a" & MyCStr(rsPlayer!PlayerName) & " was removed from your clan!" & vbCrLf & "*POOF*", zPortID
                                                subSendMsg "&A*POOF*" & vbCrLf & "You are now at the centre of a city!" & vbCrLf & "&w(you were removed from the clan)", zTPortID
                                                'Delete messages from message boards
                                                MyDB.Execute "DELETE PlayerID FROM tblPlayerMessageBoard WHERE (PlayerID=" & MyCLng(rsPlayer!PlayerID) & ");", dbFailOnError
                                        End Select
                                        rsPlayer.Update
                                        
                                        subSendMsg "&AYour rank has been set to, &w" & zTranslateMortalClanRanks(lClanMemberLevel) & "&a by &w" & zPlayerName & "&a.", zTPortID
                                        subSendMsg "&w" & MyCStr(rsPlayer!PlayerName) & "&a is now rank &w" & zTranslateMortalClanRanks(lClanMemberLevel) & "&a.", zPortID
                                        
                                        subRecalculatePlayerEquipment MyCLng(rsPlayer!PlayerID), zPortID 'we add in or take off the clan item stats - this will also happen when the player removes and wears an item.
                                    Else
                                        subSendMsg "&RThe player is already in another clan.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou can only have " & cstlMaxOfficersClan & " officers in your clan!", zPortID
                                End If
                            'Else
                            '    subSendMsg "&RThe player requires an immortal to induct them now.", zPortID
                            'End If
                        Else
                            subSendMsg "&RThe player must be at least level twenty to be inducted.", zPortID
                        End If
                    Else
                        subSendMsg "&RYou cannot induct yourself.", zPortID
                    End If
                Else
                    subSendMsg "&RYou do not have the authority to play around with that member's rank.", zPortID
                End If
            Else
                subSendMsg "&RYou cannot induct a player that is not online!", zPortID
            End If
        Else
            subSendMsg "&RPlayer not found online.", zPortID
        End If
        Set rsPlayer = Nothing
    Else
        subSendMsg "&RImmortals only.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subInductionSetClanMemberLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSpeakerPhoneBookMute(zPortID As String, zTPlayerName As String, iMute As Integer)
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim rsPlayer As Recordset
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zPlayerName As String
    Dim lClanMemberLevel As Long
    Dim lPlayerID As Long
    Dim bPlayerFound As Boolean
    
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, PlayerLevel, ImmortalLevel, ClanMemberLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Level to receive
    bPlayerFound = (Not rsPlayer.EOF)
    If (bPlayerFound) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
    End If
    Set rsPlayer = Nothing
    
    If (Len(zTPlayerName) <> 0) Then
        Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (PlayerName='" & zTPlayerName & "');", dbOpenSnapshot)
        If (Not rsSpeakerPhone.EOF) Then
            If (lngSQLRecordCount("SELECT PlayerID FROM tblPlayerSpeakerphone WHERE (PhonedPlayerID=" & MyCLng(rsSpeakerPhone!PlayerID) & " AND PlayerID=" & lPlayerID & ");") <> 0) Then
                If (lngSQLRecordCount("SELECT PlayerID FROM tblPlayerSpeakerphone WHERE (Muted <> " & iMute & " AND PhonedPlayerID=" & MyCLng(rsSpeakerPhone!PlayerID) & " AND PlayerID=" & lPlayerID & ");") <> 0) Then
                    Select Case iMute
                        Case 0
                            subSendMsg "&G" & MyCStr(rsSpeakerPhone!PlayerName) & " was unmuted.", zPortID
                        Case Else
                            subSendMsg "&R" & MyCStr(rsSpeakerPhone!PlayerName) & " was muted." & vbCrLf & "&gEnjoy the peace and tranquility!", zPortID
                    End Select
                    MyDB.Execute "UPDATE tblPlayerSpeakerphone SET Muted = " & iMute & " WHERE (PhonedPlayerID=" & MyCLng(rsSpeakerPhone!PlayerID) & " AND PlayerID=" & lPlayerID & ");", dbFailOnError
                Else
                    Select Case iMute
                        Case 0
                            subSendMsg "&gThat person is already unmuted in your phone book list.", zPortID
                        Case Else
                            subSendMsg "&gThat person is already muted in your phone book list.", zPortID
                    End Select
                End If
            Else
                subSendMsg "&gThat person is not in your phone book list.", zPortID
            End If
        Else
            subSendMsg "&gThat person was not found in the realm.", zPortID
        End If
        Set rsSpeakerPhone = Nothing
    Else
        subSendMsg "&gSyntax: MUTE (player name)   or   UNMUTE (player name)", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpeakerPhoneBookMute," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSpeakerPhoneBookAdd(zPortID As String, zTPlayerName As String)
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim rsPlayer As Recordset
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zPlayerName As String
    Dim lClanMemberLevel As Long
    Dim lPlayerID As Long
    Dim bPlayerFound As Boolean
    
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, PlayerLevel, ImmortalLevel, ClanMemberLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Level to receive
    bPlayerFound = (Not rsPlayer.EOF)
    If (bPlayerFound) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
    End If
    Set rsPlayer = Nothing
    If (lngSQLRecordCount("SELECT PlayerID FROM tblPlayerSpeakerphone WHERE (PlayerID=" & lPlayerID & ");") < 100) Then
        Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (ImmortalLevel=0 AND PlayerName='" & zTPlayerName & "' AND PlayerID<>" & lPlayerID & ") ORDER BY PlayerName DESC;", dbOpenSnapshot)
        If (Not rsSpeakerPhone.EOF) Then
            subSendMsg "&G" & MyCStr(rsSpeakerPhone!PlayerName) & " was &Yadded&G to your mic-phone book.", zPortID
            MyDB.Execute "DELETE * FROM tblPlayerSpeakerphone WHERE (Muted=0 AND PlayerID=" & lPlayerID & " AND PhonedPlayerID=" & MyCLng(rsSpeakerPhone!PlayerID) & ");", dbFailOnError 'If it is already there we delete it.
            MyDB.Execute "INSERT INTO tblPlayerSpeakerphone ( CreationDate, PlayerID, PhonedPlayerID ) SELECT '" & Now() & "', " & lPlayerID & ", " & MyCLng(rsSpeakerPhone!PlayerID) & ";", dbFailOnError
        Else
            subSendMsg "&GPlayer not found in the realm. You cannot add immortals or yourself.", zPortID
        End If
        Set rsSpeakerPhone = Nothing
    Else
        subSendMsg "&gMICROPHONE ADD: You have over a hundred listings you will have to clear some first.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpeakerPhoneBookAdd," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSpeakerPhoneBookDelete(zPortID As String, zTPlayerName As String)
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim rsPlayer As Recordset
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zPlayerName As String
    Dim lClanMemberLevel As Long
    Dim lPlayerID As Long
    Dim bPlayerFound As Boolean
    
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, PlayerLevel, ImmortalLevel, ClanMemberLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Level to receive
    bPlayerFound = (Not rsPlayer.EOF)
    If (bPlayerFound) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
    End If
    Set rsPlayer = Nothing
    
    If (Len(zTPlayerName) > 0) Then
        Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (PlayerName Like ""*" & zTPlayerName & "*"") ORDER BY PlayerName DESC;", dbOpenSnapshot)
        If (Not rsSpeakerPhone.EOF) Then
            If (lngSQLRecordCount("SELECT PlayerID FROM tblPlayerSpeakerphone WHERE (PhonedPlayerID=" & MyCLng(rsSpeakerPhone!PlayerID) & " AND PlayerID=" & lPlayerID & ");") <> 0) Then
                subSendMsg "&R" & MyCStr(rsSpeakerPhone!PlayerName) & " was deleted from your mic-phone book.", zPortID
                MyDB.Execute "DELETE * FROM tblPlayerSpeakerphone WHERE (PlayerID=" & lPlayerID & " AND PhonedPlayerID=" & MyCLng(rsSpeakerPhone!PlayerID) & ");", dbFailOnError
            Else
                subSendMsg "&gThat person is not in your phone book list.", zPortID
            End If
        Else
            subSendMsg "&GPerson not found in the realm.", zPortID
        End If
        Set rsSpeakerPhone = Nothing
    Else
        subSendMsg "&gSyntax: ERASE (delete player name from your mic-phone book)", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpeakerPhoneBookDelete," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zDropFirstWordCleanLine(zLine As String) As String
On Error GoTo Err_Check
    Dim lPos As Long
    Dim zReturn As String
    If (InStr(zLine, " ")) Then
        zReturn = Mid(zLine, InStr(zLine, " ") + 1, Len(zLine) - InStr(zLine, " "))
    Else
        zReturn = zLine
    End If
    zDropFirstWordCleanLine = MyCStr(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zDropFirstWordCleanLine," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subClanSpeak(zPortID As String, zPromptOriginal As String)
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim zMsg As String
    Dim zMsg1 As String
    Dim zMsg2 As String
    Dim zMethod As String
    Dim rsPlayer As Recordset
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zPlayerName As String
    Dim lClanID As Long
    Dim lClanMemberLevel As Long
    Dim lPlayerID As Long
    Dim bPlayerFound As Boolean
    
    'subClanSpeak(zPortID As String, lOPlayerID As Long, zOPlayerName As String, zPromptOriginal As String, lClanID As Long)
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, PlayerLevel, ImmortalLevel, ClanMemberLevel, ClanID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Level to receive
    bPlayerFound = (Not rsPlayer.EOF)
    If (bPlayerFound) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
        lClanID = MyCLng(rsPlayer!ClanID)
    End If
    Set rsPlayer = Nothing
    
    Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT tblPlayer.PlayerName, tblPlayer.ClanID, tblPlayer.PortID, tblPlayer.PlayerID FROM tblPlayer  WHERE (((tblPlayer.ClanID)=" & lClanID & ") AND ((tblPlayer.PortID) Is Not Null And (tblPlayer.PortID)<>'' And (tblPlayer.PortID)<>'0') AND ((tblPlayer.PlayerID)<>" & lPlayerID & ")) ORDER BY tblPlayer.PlayerName;", dbOpenSnapshot)
    If (Not rsSpeakerPhone.EOF) Then
        zMsg = zDropFirstWordCleanLine(zPromptOriginal)
        zMethod = "clan"
        
        'basAdminFollowText zPlayerName & " clans, '" & zMsg & "'"
        
        Select Case Mid(zMsg, Len(zMsg), 1)
            Case "!"
                zMethod = "exclaim"
            Case "?"
                zMethod = "ask"
        End Select
        zMsg1 = ("You " & zMethod & ", '" & "&W" & zMsg) '95 for the white 5 long ansi colour
        zMsg2 = (zPlayerName & " " & zMethod & "s, '" & "&W" & zMsg)
        
        subSendMsg "&R" & zMsg1 & "&R'", zPortID
        Do While (Not rsSpeakerPhone.EOF)
            If (gbliClanChannelStatus(MyCInt(rsSpeakerPhone!PortID))) Then
                subSendMsg "&R" & gblzFBRED & zMsg2 & "&R'", MyCStr(rsSpeakerPhone!PortID)
            'Else
            '    subSendMsg "&R" & MyCStr(rsSpeakerPhone!PlayerName) & " has this channel off.", zPortID
            End If
            rsSpeakerPhone.MoveNext
        Loop
    Else
        subSendMsg "&GNo one hears you over clan.", zPortID
    End If
    Set rsSpeakerPhone = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subClanSpeak," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lMicMutedStatus(zPortID As String, lPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim lReturn As Long
    lReturn = 0
    Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT tblPlayerSpeakerphone.PhonedPlayerID, tblPlayer.PortID, tblPlayer.PlayerName, tblPlayerSpeakerphone.Muted FROM tblPlayer INNER JOIN tblPlayerSpeakerphone ON tblPlayer.PlayerID = tblPlayerSpeakerphone.PlayerID WHERE (((tblPlayerSpeakerphone.PhonedPlayerID)=" & lPlayerID & ") AND ((tblPlayer.PortID)='" & zPortID & "')) ORDER BY tblPlayer.PlayerName;", dbOpenSnapshot)
    If (Not rsSpeakerPhone.EOF) Then
        lReturn = MyCLng(rsSpeakerPhone!Muted)
    End If
    Set rsSpeakerPhone = Nothing
    lMicMutedStatus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPersonMicMuted," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subSpeakerPhoneMic(zPortID As String, zPromptOriginal As String)
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim zMsg As String
    Dim zMethod As String
    Dim rsPlayer As Recordset
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zPlayerName As String
    Dim lClanMemberLevel As Long
    Dim lPlayerID As Long
    Dim bPlayerFound As Boolean
    Dim bMicMutedThatPlayer As Boolean
    Dim bMicMutedThisPlayer As Boolean
    
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, PlayerLevel, ImmortalLevel, ClanMemberLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Level to receive
    bPlayerFound = (Not rsPlayer.EOF)
    If (bPlayerFound) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
    End If
    Set rsPlayer = Nothing
    
    Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT tblPlayer.PlayerID, tblPlayer.PortID, tblPlayer.PlayerName, tblPlayerSpeakerphone.Muted FROM tblPlayer INNER JOIN tblPlayerSpeakerphone ON tblPlayer.PlayerID = tblPlayerSpeakerphone.PhonedPlayerID WHERE (((tblPlayer.PortID)<>'0' And (tblPlayer.PortID) Is Not Null) AND ((tblPlayerSpeakerphone.PlayerID)=" & lPlayerID & ")) ORDER BY tblPlayer.PlayerName;", dbOpenSnapshot)
    If (Not rsSpeakerPhone.EOF) Then
        If (lPortID <> 0 And lRandom(9) < 2) Then gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1 'They are still controled from switching from mic to a global channel
        zMsg = (zDropFirstWordCleanLine(zPromptOriginal))
        zMethod = "mic"
        
        'basAdminFollowText zPlayerName & " mics, '" & zMsg & "'"
        
        Select Case Mid(zMsg, Len(zMsg), 1)
            Case "!"
                zMethod = "exclaim"
                If (lPortID <> 0) Then gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1
            Case "?"
                zMethod = "ask"
        End Select
        
        subSendMsg "&GYou " & zMethod & ", '&g" & zMsg & "&G'", zPortID
        Do While (Not rsSpeakerPhone.EOF)
            bMicMutedThatPlayer = (lMicMutedStatus(MyCStr(rsSpeakerPhone!PortID), lPlayerID)) 'recieving player
            bMicMutedThisPlayer = (lMicMutedStatus(zPortID, MyCLng(rsSpeakerPhone!PlayerID)))  'it doesnt matter which is which really
            If (bMicMutedThatPlayer) Then
                If (Not bMicMutedThisPlayer) Then
                    If (gbliClanChannelStatus(MyCInt(rsSpeakerPhone!PortID))) Then
                        subSendMsg "&R" & MyCStr(rsSpeakerPhone!PlayerName) & " has you on mute.", zPortID
                    End If
                End If
            Else
                If (Not bMicMutedThisPlayer) Then
                    If (gbliClanChannelStatus(MyCInt(rsSpeakerPhone!PortID))) Then 'is the person's clan channel on?
                        subSendMsg "&G" & zPlayerName & " " & zMethod & "s, '&g" & zMsg & "&G'", MyCStr(rsSpeakerPhone!PortID)
                    End If
                End If
            End If
            rsSpeakerPhone.MoveNext
        Loop
    Else
        subSendMsg "&GNo one hears you over clan mic.", zPortID
    End If
    Set rsSpeakerPhone = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpeakerPhoneMic," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSpeakerPhoneMicList(zPortID As String)
On Error GoTo Err_Check
    Dim rsSpeakerPhone As Recordset
    Dim zMuted As String
    Dim lPeopleTotal As Long
    Dim lTruePeopleTotal As Long
    Dim rsPlayer As Recordset
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim zPlayerName As String
    Dim lClanMemberLevel As Long
    Dim lPlayerID As Long
    Dim bPlayerFound As Boolean
    Dim zLoadData As String
    Dim lLoadData As Long
    Dim zFinishLoadData As String
    
    lPortID = MyCLng(zPortID)
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, PlayerLevel, ImmortalLevel, ClanMemberLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Level to receive
    bPlayerFound = (Not rsPlayer.EOF)
    If (bPlayerFound) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
    End If
    Set rsPlayer = Nothing
    
    lTruePeopleTotal = 0: lPeopleTotal = 0
    lLoadData = 0
    zFinishLoadData = ""
    subSendMsg "&A-----------------------------&w{&WF R I E N D  L I S T&w}&a-----------------------------", zPortID
    Set rsSpeakerPhone = MyDB.OpenRecordset("SELECT tblPlayer.PlayerName, tblPlayerSpeakerphone.Muted, tblPlayerSpeakerphone.CreationDate FROM tblPlayer INNER JOIN tblPlayerSpeakerphone ON tblPlayer.PlayerID = tblPlayerSpeakerphone.PhonedPlayerID WHERE (tblPlayerSpeakerphone.PlayerID=" & lPlayerID & ") ORDER BY tblPlayerSpeakerphone.Muted DESC, tblPlayer.PlayerName;", dbOpenSnapshot)
    Do While (Not rsSpeakerPhone.EOF)
        lPeopleTotal = lPeopleTotal + 1
        zMuted = MyCStr(Format(rsSpeakerPhone!CreationDate, "mmm dd, yyyy"))
        
        If (MyCInt(rsSpeakerPhone!Muted) <> 0) Then
            zMuted = zMuted & " (muted)"
        Else
            lTruePeopleTotal = lTruePeopleTotal + 1
        End If
        zLoadData = gblzFNWHI & strForceSize(strForceSize(MyCStr(rsSpeakerPhone!PlayerName), 15, " ", "A") & " " & zMuted, 39, " ", "A")
        zFinishLoadData = zFinishLoadData & zLoadData
        lLoadData = lLoadData + 1
        If (lLoadData > 1) Then
            subSendMsg zFinishLoadData, zPortID
            lLoadData = 0
            zFinishLoadData = ""
        End If
        rsSpeakerPhone.MoveNext
    Loop
    Set rsSpeakerPhone = Nothing
    If (lLoadData > 0) Then subSendMsg zFinishLoadData, zPortID
    
    Select Case (lPeopleTotal = 0)
        Case True
            subSendMsg "&ASYNTAX: ADD PLAYERNAME      then      MIC YOURMESSAGEHERE", zPortID
        Case False
            subSendMsg "&a" & lTruePeopleTotal & " friends and " & (lPeopleTotal - lTruePeopleTotal) & " are muted.", zPortID
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpeakerPhoneMicList," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

