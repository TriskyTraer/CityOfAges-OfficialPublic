Attribute VB_Name = "modLagMonsterLand"
Option Explicit
Public Sub subCheckLostItemClear() 'each 3 hours
On Error GoTo Err_Check
    MyDB.Execute "DELETE DateDiff('n',Now(),[LostDateTime]) AS LDTTest, tblPlayerLostItem.LostDateTime FROM tblPlayerLostItem WHERE (((DateDiff('n',Now(),[LostDateTime]))<-240));", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckLostItemClear," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCheckPlayerIGNOREDClear() 'each 3 hours
On Error GoTo Err_Check
    MyDB.Execute "DELETE DateDiff('n',Now(),[IgnoredDateTime]) AS IDTTest, tblPlayerIgnoreCommand.IgnoredDateTime FROM tblPlayerIgnoreCommand WHERE (((DateDiff('n',Now(),[IgnoredDateTime]))<-14));", dbFailOnError 'the entire realm can vote to boot someone and when thet return can get randomly kicked
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckPlayerIGNOREDClear," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lTranslateDurabilityControlRaceClass(zPlayerRace As String, zPlayerClass As String) As Long
On Error Resume Next
    Dim lReturn As Long 'see also subCombatPlayerDurabilityLoss
    Dim lResult As Long
    lResult = 0 'the lower the worse never set below 2
    
    lReturn = 2
    Select Case zPlayerClass
        Case "MA"
            lReturn = 2
        Case "CL"
            lReturn = 6
        Case "DR"
            lReturn = 5
        Case "BA"
            lReturn = 8
        Case "MO"
            lReturn = 12
        Case "AS"
            lReturn = 16
        Case "GY"
            lReturn = 8
        Case "TH"
            lReturn = 3
        Case "WA"
            lReturn = 15
        Case "GL"
            lReturn = 20
        Case "RA"
            lReturn = 50
        Case "KN"
            lReturn = 3
        Case "PA"
            lReturn = 1
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 100
        Case "VA"
            lReturn = 2
        Case "WE"
            lReturn = 2
    End Select
    lResult = lResult + lReturn

    lReturn = 2
    Select Case zPlayerRace
        Case "PIX"
            lReturn = 100
        Case "DWA"
            lReturn = 6
        Case "HUM"
            lReturn = 5
        Case "OGR"
            lReturn = 9
        Case "ORC"
            lReturn = 6
        Case "GNO"
            lReturn = 3
        Case "TRO"
            lReturn = 9
        Case "ELF"
            lReturn = 4
        Case "MIN"
            lReturn = 11
        Case "DRA"
            lReturn = 15
        Case "HAL"
            lReturn = 9
        Case "UND"
            lReturn = 1
        Case "FEL"
            lReturn = 2
    End Select
    lResult = lResult + lReturn
    
    lTranslateDurabilityControlRaceClass = 1 + lReturn
End Function
Public Sub subCombatPlayerDurabilityLoss(zPortID As String, lPlayerID As Long, lDamage As Long, lAlignment As Long, lX As Long, lY As Long, lZ As Long, lDamageLevel As Long, lMobLevel As Long)
On Error GoTo Err_Check 'see also lReturnDurabilityControlRaceClass(zRace,zClass)
    Const cstlChanceForBreak = 15
    Dim rsPlrEq As Recordset
    Dim rsObject As Recordset
    Dim lThickness As Long
    Dim lExtraLoss As Long
    Dim bAligns As Boolean
    Dim iExitLoop As Integer '0=nothing, 1=smash, 2=dropped
    Dim lObjectID As Long
    Dim lTotalItems As Long
    Dim zSQL As String
    Dim lObjectAlignment As Long
    Dim lDamagedCount As Long
    Dim zZap As String
    Dim zEnd As String
    Dim zObjectID As String
    
    If (lRandom((lDamage + 5) * 2) >= lRandom((lDamageLevel + 5) * 4)) Then 'chance nothing was harmed unless the dmg was over 70
        iExitLoop = 0
        'containers dont explode and we check weapon indest lv
        lTotalItems = lngSQLRecordCount("SELECT tblPlayerEquipmentItems.ObjectID FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblObject.IndestructibleMobLv)<=" & lMobLevel & ") AND ((tblObject.ReturnPlayerID)=0) AND ((tblObject.LockStatus)=0) AND ((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));")
        If (lTotalItems > 3) Then 'if a person doesnt wear a lot of items then they arent greedy so they dont ever lose to durability
            Set rsPlrEq = MyDB.OpenRecordset("SELECT TOP " & MyCStr(lRandom(lTotalItems)) & " tblPlayerEquipmentItems.ObjectID FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblObject.IndestructibleMobLv)<=" & lMobLevel & ") AND ((tblObject.ReturnPlayerID)=0) AND ((tblObject.LockStatus)=0) AND ((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));", dbOpenSnapshot) 'containers cannot break but if you want them to then you have to code drop objects or delete objects from the objectid.container
            If (Not rsPlrEq.EOF) Then
                rsPlrEq.MoveLast
                lObjectID = MyCLng(rsPlrEq!ObjectID)
                zObjectID = MyCStr(lObjectID)
                Set rsObject = MyDB.OpenRecordset("SELECT Thickness, PlayerID, Alignment, ObjectName, DurabilityBroken FROM tblObject WHERE (ObjectID=" & zObjectID & " AND DurabilityBroken>0 AND CaptureFlagClanID=0);", dbOpenSnapshot)
                If (Not rsObject.EOF) Then
                    bAligns = True
                    lThickness = MyCLng(rsObject!Thickness)
                    lExtraLoss = 1
                    If (lRandom(lThickness * 10) <= lRandom(10)) Then lExtraLoss = lRandom(2) 'double chance at extra loss odds
                    If (lRandom(lThickness * 10) <= lRandom(10)) Then lExtraLoss = lRandom(2)
                    MyDB.Execute "UPDATE tblObject SET DurabilityBroken=[DurabilityBroken]-" & lExtraLoss & " WHERE (ObjectID=" & zObjectID & ");", dbFailOnError
                    MyDB.Execute "UPDATE tblObject SET DurabilityBroken=0 WHERE (ObjectID=" & zObjectID & " AND DurabilityBroken<0);", dbFailOnError
                    If (MyCLng(rsObject!DurabilityBroken) - lExtraLoss < 1) Then
                        subSendMsg "&y*DENT* Your " & zShortstop(MyCStr(rsObject!ObjectName)) & " is DISABLED", zPortID
                        iExitLoop = 100 'we used to use code 1 here we now just go recalculate
                    Else
                        subSendMsg "&yWHACK! Your " & zShortstop(MyCStr(rsObject!ObjectName)) & " takes some damage", zPortID
                        lObjectAlignment = MyCLng(rsObject!Alignment)
                        If (lObjectAlignment < 0 And lAlignment > 0) Or (lObjectAlignment > 0 And lAlignment < 0) Then
                            bAligns = False
                        End If
                    
                        If (Not bAligns) Then  'Does the item align with the player alignment?
                            Select Case lRandom(9)
                                Case 1
                                    zZap = "~Z~A~P~"
                                Case 2
                                    zZap = "~Z*A*P~"
                                Case 3
                                    zZap = "~Z-A-P~"
                                Case 4
                                    zZap = "~Z+A+P~"
                                Case Else
                                    zZap = "~ZAP~"
                            End Select
                            
                            Select Case lRandom(9)
                                Case 1
                                    zEnd = "all of a sudden drops to the ground!"
                                Case 2
                                    zEnd = "unlinks from your equipment and jumps away from your body!"
                                Case 3
                                    zEnd = "makes a crackling sound and drops off your equipment!"
                                Case 4
                                    zEnd = "teleports from you and onto the floor!"
                                Case Else
                                    zEnd = "is not aligned to you and drops to the ground!"
                            End Select
                            
                            subSendMsg gblzFBRED & zZap & "&r" & " [track with PAGE LOST for 3 hours] Your " & zShortstop(MyCStr(rsObject!ObjectName)) & " " & zEnd, zPortID
                            MyDB.Execute "INSERT INTO tblPlayerLostItem ( PlayerID, ObjectID, X, Y, Z, LostMsg ) SELECT " & lPlayerID & ", " & lObjectID & ", " & lX & ", " & lY & ", " & lZ & ", 'ZAPed';", dbFailOnError
                            iExitLoop = 2 'we stop looping to drop off this item to the ground and we make a report on it
                        End If
                    End If
                End If
                Set rsObject = Nothing
            End If
            Set rsPlrEq = Nothing
            
            Select Case iExitLoop
                Case 1 'Smash
                    MyDB.Execute "DELETE ObjectID FROM tblPlayerEquipmentItems WHERE (ObjectID=" & zObjectID & ");", dbFailOnError
                    MyDB.Execute "DELETE ObjectID FROM tblObject WHERE (ObjectID=" & zObjectID & ");", dbFailOnError
                Case 2 'Zap
                    MyDB.Execute "DELETE ObjectID FROM tblPlayerEquipmentItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                    MyDB.Execute "UPDATE tblObject SET X = " & lX & ", Y = " & lY & ", Z = " & lZ & ", PlayerID = 0, Status = 0, Burried=False, GroundTimer=0, GroundTimerNotAvailable=False WHERE (ObjectID=" & zObjectID & ");", dbFailOnError 'we want to ground timer zapped items, especially stamped ones
            End Select
            
            If (iExitLoop <> 0) Then subRecalculatePlayerEquipment lPlayerID, zPortID 'When the battle is done and all the calculations are in we update the player tables.
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatPlayerDurabilityLoss," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRunMobFacings(lChance As Long)
On Error GoTo Err_Check 'this wont blind mode as its area all
    Dim rsGroupPlayer As Recordset
    Dim iRnd As Integer
    Dim lTotal As Long
    Dim lCount As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lMobID As Long
    Dim lFacingDegrees As Long
    Dim lRoomX As Long
    Dim lRoomY As Long
    Dim lRoomZ As Long
    Dim zMsg As String
    Dim lHeight As Long
    Dim lDeg As Long
    Dim iDir As Integer
    Dim bFlys As Integer
    Dim zMN As String
    Dim zFlys As String
    If lRandom(lChance) = 1 Then
    'we grab all the mobs where online players are matching their x y z groupfn
    Set rsGroupPlayer = MyDB.OpenRecordset("SELECT Count(tblPlayer.PlayerID) AS CountOfPlayerID, tblMob.Flys, tblMob.FlyHeight, tblMob.MobName, tblMob.FacingDegrees, tblMob.RoomX, tblMob.RoomY, tblMob.RoomZ, tblMob.MobID, tblMob.FacingDegrees, tblMob.RoomX, tblMob.RoomY, tblMob.RoomZ, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, Len([PortID]) AS LenPort, tblMob.RespawnDelay, tblMob.Invisible FROM tblPlayer INNER JOIN tblMob ON (tblPlayer.X = tblMob.X) AND (tblPlayer.Y = tblMob.Y) AND (tblPlayer.Z = tblMob.Z) GROUP BY tblMob.Flys, tblMob.FlyHeight, tblMob.MobName, tblMob.FacingDegrees, tblMob.RoomX, tblMob.RoomY, tblMob.RoomZ, tblMob.MobID, tblMob.FacingDegrees, tblMob.RoomX, tblMob.RoomY, tblMob.RoomZ, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, Len([PortID]), tblMob.RespawnDelay, tblMob.Invisible HAVING (((Len([PortID]))>1) AND ((tblMob.RespawnDelay)=0) AND ((tblMob.Invisible)=False));", dbOpenSnapshot)
    If (Not rsGroupPlayer.EOF) Then
        rsGroupPlayer.MoveLast 'this is a different way to grab a random mob name
        lTotal = lRandom(rsGroupPlayer.RecordCount)
        rsGroupPlayer.MoveFirst
        For lCount = 1 To lTotal
            rsGroupPlayer.MoveNext
        Next lCount
        'end of different random mob data piece
        
        If (Not rsGroupPlayer.EOF) Then
            lMobID = MyCLng(rsGroupPlayer!MobID)
            lHeight = MyCLng(rsGroupPlayer!FlyHeight)
            bFlys = (MyCLng(rsGroupPlayer!Flys) <> 0)
            If (bFlys) Then
                zFlys = " (flying)"
            Else
                zFlys = ""
            End If
            lFacingDegrees = MyCLng(rsGroupPlayer!FacingDegrees) 'lRandom(10) 'can move up to 10 degrees
            zMN = MyCStr(rsGroupPlayer!MobName)
            zMsg = ""
            zMsg = zMsg & "Face {" & lFacingDegrees & "deg} "
            lDeg = lRandom(16)
            If (lRandom(10) > 5) Then
                iDir = -1
                lFacingDegrees = lFacingDegrees - lDeg
            Else
                iDir = 1
                lFacingDegrees = lFacingDegrees + lDeg
            End If
            If lFacingDegrees < 1 Then lFacingDegrees = lFacingDegrees + 360
            If lFacingDegrees > 360 Then lFacingDegrees = lFacingDegrees - 360
            zMsg = zMsg & "turns"
            If (iDir = -1) Then
                zMsg = zMsg & "left"
            Else
                zMsg = zMsg & "rite"
            End If
            zMsg = zMsg & "{" & lDeg & "deg} to [" & lFacingDegrees & "deg] "
            
            lRoomX = MyCLng(rsGroupPlayer!RoomX)
            lRoomY = MyCLng(rsGroupPlayer!RoomY)
            lRoomZ = MyCLng(rsGroupPlayer!RoomZ)
            zMsg = zMsg & vbCrLf & "old {rx" & lRoomX & " ry" & lRoomY & " rz" & lRoomZ & "}"
            
            If (lRandom(10) > 5) Then
                lRoomX = lRoomX - 1
            Else
                lRoomX = lRoomX + 1
            End If
            If (lRandom(10) > 5) Then
                lRoomY = lRoomY - 1
            Else
                lRoomY = lRoomY + 1
            End If
            If (lRandom(10) > 5) Then
                lRoomZ = lRoomZ - 1
            Else
                lRoomZ = lRoomZ + 1
            End If
            
            If lRoomX < cstgblRoomX1 Then lRoomX = cstgblRoomX1
            If lRoomX > cstgblRoomX2 Then lRoomX = cstgblRoomX2
            If lRoomY < cstgblRoomY1 Then lRoomY = cstgblRoomY1
            If lRoomY > cstgblRoomY2 Then lRoomY = cstgblRoomY2
            If lRoomZ < cstgblRoomZ1 Then lRoomZ = cstgblRoomZ1
            If lRoomZ > cstgblRoomZ2 Then lRoomZ = cstgblRoomZ2
            
            'positive is underground minus means lighter
            iRnd = lRandom(12)
            If (bFlys And lRandom(2) = 1) Then iRnd = 7
            Select Case iRnd
                Case 1, 2, 3
                    lRoomZ = lRoomZ - 1 'up into the sky
                Case 4, 5, 6
                    lRoomZ = lRoomZ + 1 'down into the earth
                Case 7, 8, 9 'jump way up
                    If (lRoomZ < 0 And lRandom(3) = 1) Or (lRandom(5) = 1) Then lRoomZ = ((lRandom(6) - 1) * -1) 'jump waay up from underground - or floating
            End Select
            If lRoomZ = 1 Then lRoomZ = 0 'back on surface
            If lRoomZ = 2 Then lRoomZ = 1 'positive values mean underground
            If lRoomZ = 3 Then lRoomZ = 2
            If lRoomZ = 4 Then lRoomZ = 3
            If lRoomZ = 5 Then lRoomZ = 4
            If lRoomZ > 5 Then lRoomZ = 5
            If lRoomZ < -5 Then lRoomZ = -5 'we control z here as well so thats twice
            If (lRandom(100) < 6) Then lRoomZ = 0 'override: we try to remain not jumping in the room
            lOX = MyCLng(rsGroupPlayer!x)
            lOY = MyCLng(rsGroupPlayer!y)
            lOZ = MyCLng(rsGroupPlayer!z)
            zMsg = zMsg & " moved [rx" & lRoomX & " ry" & lRoomY & " rz" & lRoomZ & "]"
            subSendMsgAreaAllNotBM gblzFBMAG & zMN & "&a [" & lHeight & "h" & zFlys & " id" & lMobID & "]" & vbCrLf & gblzFNMAG & zMsg, lOX, lOY, lOZ
            MyDB.Execute "UPDATE tblMob SET FacingDegrees=" & lFacingDegrees & ", RoomX=" & lRoomX & ", RoomY=" & lRoomY & ", RoomZ=" & lRoomZ & " WHERE (MobID=" & lMobID & ");", dbFailOnError
        End If
    End If
    Set rsGroupPlayer = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subRunMobFacings," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRotateAreaTransit()
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim zMsg As String
    Dim zTransit As String
    Dim lAttempt As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long 'MOB PATHING
    Dim zPortID As String
    
    lAttempt = lRandom(2) 'This causes the game to delay for 30 seconds if it fails
    
    Select Case lAttempt
        Case 1
            zTransit = "tblAreaTransit"
        Case 2
            zTransit = "tblAreaTransitForkInPath" 'This is just a duplicate of tblAreaTransit. Accept there is a random description and may put a mob out ther in the space to be caught for fighting.
    End Select
    
    'We now print the area transit emotes after the areas move.
    Set rsArea = MyDB.OpenRecordset("SELECT " & zTransit & ".*, PortID FROM " & zTransit & " INNER JOIN tblPlayer ON (" & zTransit & ".Z = tblPlayer.Z) AND (tblPlayer.Y = " & zTransit & ".Y) AND (" & zTransit & ".X = tblPlayer.X) WHERE (Len(tblPlayer.PortID)>3);", dbOpenSnapshot) 'Is there at least one player somewhere in the game (looged on or logged off - WE WANT BOTH or the player will be left in the void :) ) that is on a move spot?
    If (rsArea.EOF) Then 'The random worked out!
        Select Case lAttempt 'We try the other table so we dont skip a beat
            Case 2 'reversed on purpose!
                zTransit = "tblAreaTransit"
            Case 1
                zTransit = "tblAreaTransitForkInPath" 'This is just a duplicate of tblAreaTransit. Accept there is a random description and may put a mob out ther in the space to be caught for fighting.
        End Select
        Set rsArea = Nothing
        Set rsArea = MyDB.OpenRecordset("SELECT " & zTransit & ".*, tblPlayer.PortID, CHP, OHP, CMana, OMana, CEssence, OEssence FROM " & zTransit & " INNER JOIN tblPlayer ON (" & zTransit & ".Z = tblPlayer.Z) AND (tblPlayer.Y = " & zTransit & ".Y) AND (" & zTransit & ".X = tblPlayer.X) WHERE (Len(tblPlayer.PortID)>3);", dbOpenSnapshot) 'Is there at least one player somewhere in the game (looged on or logged off - WE WANT BOTH or the player will be left in the void :) ) that is on a move spot?
    End If
    
    If (Not rsArea.EOF) Then
        Do While (Not rsArea.EOF)  'If there is at least one person in the area we send an area message to all there.
            zPortID = MyCStr(rsArea!PortID)
            zMsg = (MyCStr(rsArea!ArrivalViewMsg))
            If (Len(zMsg) > 0) Then subSendMsg "&B" & zMsg, zPortID
            zMsg = (MyCStr(rsArea!ArrivalMobileSpeak))
            If (Len(zMsg) > 0) Then subSendMsg gblzFNYEL & zMsg, zPortID
            zMsg = (MyCStr(rsArea!ArrivalMobileAction))
            If (Len(zMsg) > 0) Then subSendMsg "&M" & zMsg, zPortID
            rsArea.MoveNext
        Loop
    End If
    Set rsArea = Nothing
    
    'We always move the transit areas/doors and their mobs or any left behind objects.
    'We move the objects in transit - only objects that get captured in transit by the area - same effect for mobs.
    MyDB.Execute "UPDATE (" & zTransit & " INNER JOIN tblObject ON (" & zTransit & ".X = tblObject.X) AND (" & zTransit & ".Y = tblObject.Y) AND (" & zTransit & ".Z = tblObject.Z)) INNER JOIN tblArea ON (tblObject.Z = tblArea.Z) AND (tblObject.Y = tblArea.Y) AND (tblObject.X = tblArea.X) SET tblObject.X = [" & zTransit & "].[DX], tblObject.Y = [" & zTransit & "].[DY], tblObject.Z = [" & zTransit & "].[DZ];", dbFailOnError
    'We move all mobs that are actually in the area - this gives the nice feature of mobs being picked up in the moving areas.
    MyDB.Execute "UPDATE (" & zTransit & " INNER JOIN tblMob ON (" & zTransit & ".X = tblMob.X) AND (" & zTransit & ".Y = tblMob.Y) AND (" & zTransit & ".Z = tblMob.Z)) INNER JOIN tblArea ON (tblMob.Z = tblArea.Z) AND (tblMob.Y = tblArea.Y) AND (tblMob.X = tblArea.X) SET tblMob.X = [" & zTransit & "].[DX], tblMob.Y = [" & zTransit & "].[DY], tblMob.Z = [" & zTransit & "].[DZ];", dbFailOnError
    'We move the Players in transit even the ones offline
    MyDB.Execute "UPDATE (" & zTransit & " INNER JOIN tblPlayer ON (" & zTransit & ".X = tblPlayer.X) AND (" & zTransit & ".Y = tblPlayer.Y) AND (" & zTransit & ".Z = tblPlayer.Z)) INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblPlayer.Y = tblArea.Y) AND (tblPlayer.X = tblArea.X) SET tblPlayer.X = [" & zTransit & "].[DX], tblPlayer.Y = [" & zTransit & "].[DY], tblPlayer.Z = [" & zTransit & "].[DZ];", dbFailOnError
    'This HAS to be LAST, after players, mobs and objects! We move the Area that match the transit paths.
    MyDB.Execute "UPDATE " & zTransit & " INNER JOIN tblArea ON (" & zTransit & ".X = tblArea.X) AND (" & zTransit & ".Y = tblArea.Y) AND (" & zTransit & ".Z = tblArea.Z) SET tblArea.X = [" & zTransit & "].[DX], tblArea.Y = [" & zTransit & "].[DY], tblArea.Z = [" & zTransit & "].[DZ];", dbFailOnError
    
    'We now print Surrounding Emotes for the new area we went to
    Set rsArea = MyDB.OpenRecordset("SELECT " & zTransit & ".X, " & zTransit & ".Y, " & zTransit & ".Z, " & zTransit & ".SurroundingEmoteMsg, " & zTransit & ".SurroundingEmoteDir, Len([SurroundingEmoteDir])>0 AS TestEmoteDirEnabled FROM tblArea INNER JOIN " & zTransit & " ON (tblArea.X = " & zTransit & ".X) AND (tblArea.Y = " & zTransit & ".Y) AND (tblArea.Z = " & zTransit & ".Z) WHERE (((Len([SurroundingEmoteDir])>0)=True));", dbOpenSnapshot)
    Do While (Not rsArea.EOF)
        zMsg = MyCStr(rsArea!SurroundingEmoteMsg)
        If (Len(zMsg) > 0) Then
            subDirectionControl lTX, lTY, lTZ, MyCLng(rsArea!x), MyCLng(rsArea!y), MyCLng(rsArea!z), MyCStr(rsArea!SurroundingEmoteDir)
            subSendMsgAreaAll gblzFBMAG & zMsg, lTX, lTY, lTZ
        End If
        rsArea.MoveNext
    Loop
    Set rsArea = Nothing
    'iTotalPlayers
    Exit Sub
Err_Check:
    subWriteErrorFile "subRotateAreaTransit," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRotateObjectTransit()
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim zMsg As String
    Dim iTotalPlayers As Integer
    Dim zTransit As String
    Dim lAttempt As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lPrintObjectID As Long
    
    lAttempt = lRandom(2)  'This causes the game to delay for 30 seconds if it fails
    
    Select Case lAttempt
        Case 1
            zTransit = "tblObjectTransit"
        Case 2
            zTransit = "tblObjectTransitForkInPath" 'This is just a duplicate of tblObjectTransit. Accept there is a random description and may put a mob out ther in the space to be caught for fighting.
    End Select
    
    'We show leaving and arriving emote of the bus
    Set rsArea = MyDB.OpenRecordset("SELECT " & zTransit & ".ObjectID, " & zTransit & ".X, " & zTransit & ".Y, " & zTransit & ".Z, SurroundingEmoteDir, ObjectNameLeaves, ObjectNameArrives FROM " & zTransit & " INNER JOIN tblObject ON (" & zTransit & ".ObjectID = tblObject.ObjectID) AND (" & zTransit & ".Z = tblObject.Z) AND (tblObject.Y = " & zTransit & ".Y) AND (" & zTransit & ".X = tblObject.X) ORDER BY " & zTransit & ".ObjectID;", dbOpenSnapshot)
    If (Not rsArea.EOF) Then 'We select a path if it exists - its possible the above step will not happen if the player lands in a deadzone - one of the tables MUST connect to an object path in at least ONE of the tables or the moveing object will stop.
        lPrintObjectID = 0
        Do While (Not rsArea.EOF)
            If (MyCLng(rsArea!ObjectID) <> lPrintObjectID) Then
                lPrintObjectID = MyCLng(rsArea!ObjectID)
                zMsg = MyCStr(rsArea!ObjectNameLeaves)
                subSendMsgAreaAll gblzFBMAG & zMsg, MyCLng(rsArea!x), MyCLng(rsArea!y), MyCLng(rsArea!z)
                
                subDirectionControl lTX, lTY, lTZ, MyCLng(rsArea!x), MyCLng(rsArea!y), MyCLng(rsArea!z), MyCStr(rsArea!SurroundingEmoteDir)
                zMsg = MyCStr(rsArea!ObjectNameArrives)
                subSendMsgAreaAll gblzFBMAG & zMsg, lTX, lTY, lTZ
            End If
            rsArea.MoveNext
        Loop
    End If
    Set rsArea = Nothing
    
    'All players sitting on the object will show their name as the object arrives.
    Set rsArea = MyDB.OpenRecordset("SELECT " & zTransit & ".*, PlayerName FROM " & zTransit & " INNER JOIN tblPlayer ON (" & zTransit & ".ObjectID = tblPlayer.SitObjectID) AND (" & zTransit & ".Z = tblPlayer.Z) AND (tblPlayer.Y = " & zTransit & ".Y) AND (" & zTransit & ".X = tblPlayer.X);", dbOpenSnapshot) 'Is there at least one player somewhere in the game (looged on or logged off - WE WANT BOTH or the player will be left in the void :) ) that is on a move spot?
    If (Not rsArea.EOF) Then 'We select a path if it exists - its possible the above step will not happen if the player lands in a deadzone - one of the tables MUST connect to an object path in at least ONE of the tables or the moveing object will stop.
        Do While (Not rsArea.EOF)
            zMsg = MyCStr(rsArea!PlayerNameLeaves) & " [on board " & MyCStr(rsArea!PlayerName) & "]"
            subSendMsgAreaAll gblzFBMAG & zMsg, MyCLng(rsArea!x), MyCLng(rsArea!y), MyCLng(rsArea!z)
            
            subDirectionControl lTX, lTY, lTZ, MyCLng(rsArea!x), MyCLng(rsArea!y), MyCLng(rsArea!z), MyCStr(rsArea!SurroundingEmoteDir)
            zMsg = MyCStr(rsArea!PlayerNameArrives) & " [on board " & MyCStr(rsArea!PlayerName) & "]"
            subSendMsgAreaAll gblzFBMAG & zMsg, lTX, lTY, lTZ
            rsArea.MoveNext
        Loop
        'We move the Players sitting on the object
        MyDB.Execute "UPDATE (" & zTransit & " INNER JOIN tblPlayer ON (" & zTransit & ".ObjectID = tblPlayer.SitObjectID) AND (" & zTransit & ".X = tblPlayer.X) AND (" & zTransit & ".Y = tblPlayer.Y) AND (" & zTransit & ".Z = tblPlayer.Z)) SET tblPlayer.X = [" & zTransit & "].[DX], tblPlayer.Y = [" & zTransit & "].[DY], tblPlayer.Z = [" & zTransit & "].[DZ];", dbFailOnError
    End If
    Set rsArea = Nothing
    
    'We move all objects that can be moved
    MyDB.Execute "UPDATE (" & zTransit & " INNER JOIN tblObject ON (" & zTransit & ".ObjectID = tblObject.ObjectID) AND (" & zTransit & ".X = tblObject.X) AND (" & zTransit & ".Y = tblObject.Y) AND (" & zTransit & ".Z = tblObject.Z)) SET tblObject.X = [" & zTransit & "].[DX], tblObject.Y = [" & zTransit & "].[DY], tblObject.Z = [" & zTransit & "].[DZ];", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subRotateObjectTransit," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Function lReturnStockIntelligenceBonus(lReportCountOfPlayerStockID As Long) As Long
    Dim rsRnd As Recordset
    Dim lIndexMODE As Long
    lIndexMODE = 0
    Set rsRnd = MyDB.OpenRecordset("SELECT ReportCountOfPlayerStockID FROM tblPlayerStock;", dbOpenSnapshot)
    Do While (Not rsRnd.EOF)
        If (MyCLng(rsRnd!ReportCountOfPlayerStockID) < lReportCountOfPlayerStockID) Then
            lIndexMODE = lIndexMODE + 1
        End If
        rsRnd.MoveNext
    Loop
    Set rsRnd = Nothing
    lReturnStockIntelligenceBonus = lIndexMODE
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnStockIntelligenceBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Sub subRotateTheWorldLessOften()
On Error GoTo Err_Check
'This is where you would reset all the doors, move the mobs.
    Const cstlStockModification = 20
    Dim lMobID As Long
    Dim lDummy As Long
    Dim lReportCountOfPlayerStockID As Long
    Dim lHoldMobID As Long
    Dim lTZ As Long
    Dim rsRandomPlayer As Recordset
    Dim rsRealestate As Recordset
    Dim lColonistsAboard As Long
    Dim lColonistsNumber As Long
    Dim lColonistsPlayerID As Long
    Dim lPlayerCount As Long
    Dim bChanged As Boolean
    Dim zFinishedMsg As String
    Dim lRealestateCount As Long
    Dim rsMobList As Recordset
    Dim rsMob As Recordset
    Dim rsMobPath As Recordset
    Dim lRealestateSSPlayerID As Long
    Dim lMobType As Long
    Dim zMobName As String
    Dim rsArea As Recordset
    Dim rsAreaBlockedPath As Recordset
    Dim rsWhereMob As Recordset
    Dim lWhereMobID As Long
    Dim rsPlayer As Recordset
    Dim iLoc As Integer
    Dim zBlockedExits As String
    Dim rsObject As Recordset
    Dim zObjectName As String
    Dim zSQL As String
    Dim bMobPath As Boolean
    Dim lMvMMobID As Long
    Dim lMobPathRecordCount As Long
    Dim lMobPathRecordCountMAX As Long
    Dim lMobsMoved As Long
    Dim lMobsMovedMAX As Long
    
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMPathX As Long
    Dim lMPathY As Long
    Dim lMPathZ As Long
    
    Dim rsStockMarket As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lPositionFromCenter As Long
    Dim lValue As Long
    Dim lChange As Long
    Dim lChangeSummary As Long
    Dim lStartTimer As Long
    Dim lPlayerStockID As Long
    Dim bChange As Boolean
    Dim zChangeMod As String
    Dim zChangeModPrint As String
    Dim zLagTimerA As String
    Dim zLagTimerB As String
    Dim lSignal As Long
    zLagTimerA = Format(Now(), "mmm dd, yyyy hh:nn:ss") 'lag timer
    
    'If there is a mobile stuck on a player starship we could run the following code - MOB CLEARED FROM STARSHIPS - returned back to the realm - or just respawndelay=2 all mobs now and then works too
    'If (lRandom(99) = 1) Then MyDB.Execute "UPDATE tblMob INNER JOIN tblArea ON (tblMob.Z = tblArea.Z) AND (tblMob.Y = tblArea.Y) AND (tblMob.X = tblArea.X) SET tblMob.RespawnDelay = 2 WHERE (((tblArea.PlayerType)=2));", dbFailOnError
    If (gblbMOBINTELLIGENCEMODE) Then 'new method for speed
        lSignal = 3
    Else
        lSignal = 33
        'subMobPathingFAST bugged with a visual error and oracle moving angles dec 2022 the time to run was just as bad as below so just keep it or keep trying whoever you are TRISKER WORK HERE
    End If
    If (lRandom(lSignal) = 1) Then
    'MOB PATH MOVEMENT and moves only those mobs in the same WhereID as a player.
    Set rsWhereMob = MyDB.OpenRecordset("SELECT tblPlayer.WhereID FROM tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PortID = tblPlayerLoggedIn.PortID GROUP BY tblPlayer.WhereID;", dbOpenSnapshot)
    Do While (Not rsWhereMob.EOF)
        lWhereMobID = rsWhereMob!WhereID
        If (gblbServerSteroid) Then DoEvents 'SUBLOOPSystem-Tick[
        Set rsMobList = MyDB.OpenRecordset("SELECT tblMobPath.MobID FROM (tblArea INNER JOIN tblMobPath ON (tblArea.Z = tblMobPath.Z) AND (tblArea.Y = tblMobPath.Y) AND (tblArea.X = tblMobPath.X)) INNER JOIN tblMob ON tblMobPath.MobID = tblMob.MobID GROUP BY tblArea.WhereID, tblMobPath.MobID, tblMob.RespawnDelay HAVING (((tblArea.WhereID)=" & lWhereMobID & ") AND ((tblMob.RespawnDelay)=0)) ORDER BY tblMobPath.MobID;", dbOpenSnapshot)
        If (Not rsMobList.EOF) Then
            lMobsMoved = 0
            lMobsMovedMAX = 0
            lHoldMobID = 0
            Do While (Not rsMobList.EOF)  'We now have all the mobs that need to be moved
                lMobID = rsMobList!MobID
                If (lMobID <> lHoldMobID) Then
                    lHoldMobID = lMobID
                    Set rsMob = MyDB.OpenRecordset("SELECT MobType, MvMMobID, StreetSweeper, Invisible, Flys, MobName, X, Y, Z, WalkEnterMsg, WalkExitMsg, FlyEnterMsg, FlyExitMsg FROM tblMob WHERE (MobID=" & lMobID & " AND RespawnDelay=0);", dbOpenSnapshot) 'move only alive mobs
                    If (Not rsMob.EOF) Then 'We now get the mob's data, we also have a 33% chance not to move this mob
                        lMobsMovedMAX = lMobsMovedMAX + 1
                        bMobPath = False 'no path found yet
                        zMobName = zShortstop(MyCStr(rsMob!MobName))
                        lMvMMobID = MyCLng(rsMob!MvMMobID)
                        lMX = MyCLng(rsMob!x)
                        lMY = MyCLng(rsMob!y)
                        lMZ = MyCLng(rsMob!z)
                        lMobType = MyCLng(rsMob!MobType)
                        
                        If (MyCInt(rsMob!StreetSweeper) <> 0) Then 'We clean up the city streets
                            Set rsObject = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, RottingRounds, Location, ReturnPlayerID FROM tblObject WHERE (X=" & lMX & " AND Y=" & lMY & " AND Z=" & lMZ & ") AND (Status=0) AND (Burried=No) AND (PlayerID=0) AND (VisibleLevel=0);", dbOpenDynaset)
                            If (Not rsObject.EOF) Then
                                Do While (Not rsObject.EOF)
                                    zObjectName = zShortstop(MyCStr(rsObject!ObjectName))
                                    If (lContainerItemContentTotal(MyCLng(rsObject!ObjectID)) = 0) Then
                                        If (MyCLng(rsObject!Location) = 0 Or MyCLng(rsObject!ReturnPlayerID) <> 0) Then
                                            Select Case lRandom(15) 'street sweeper work emotes - and we dont always want to see him working either.
                                                Case 1
                                                    subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " takes out a rag and polishes " & zAdverb(zObjectName, 2) & zObjectName & "."), lMX, lMY, lMZ
                                                Case 2
                                                    subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " ignores " & zAdverb(zObjectName, 2) & zObjectName & "."), lMX, lMY, lMZ
                                                Case 3
                                                    subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " wipes off some dirt and stops and admires " & zAdverb(zObjectName, 2) & zObjectName & " for a moment."), lMX, lMY, lMZ
                                            End Select
                                        Else
                                            subSendMsgAreaAll gblzFNGRE & (zAdverb(zMobName, 2) & zMobName & " disposes of " & zAdverb(zObjectName, 2) & zObjectName & "."), lMX, lMY, lMZ
                                            rsObject.Delete
                                        End If
                                    Else
                                        subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " notices items in the " & zObjectName & " and leaves it alone."), lMX, lMY, lMZ
                                    End If
                                    rsObject.MoveNext
                                Loop
                            End If
                            Set rsObject = Nothing
                        End If
                                                
                        zSQL = "SELECT tblMobPath.X, tblMobPath.Y, tblMobPath.Z FROM tblMobPath "
                        zSQL = zSQL & "WHERE (((tblMobPath.X)=" & lMX - 1 & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX + 1 & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY - 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY + 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX - 1 & ") AND ((tblMobPath.Y)=" & lMY - 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX + 1 & ") AND ((tblMobPath.Y)=" & lMY + 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX + 1 & ") AND ((tblMobPath.Y)=" & lMY - 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ - 1 & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ + 1 & ") AND ((tblMobPath.MobID)=" & lMobID & "));"
                        Set rsMobPath = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                        If (Not rsMobPath.EOF) Then
                            rsMobPath.MoveLast
                            lMobPathRecordCount = rsMobPath.RecordCount
                            lMobPathRecordCountMAX = lMobPathRecordCount
                            rsMobPath.MoveFirst
                            Do While (Not rsMobPath.EOF And Not bMobPath) 'We now have all of this mob's paths, we must choose one or not move this mob
                                lMPathX = MyCLng(rsMobPath!x)
                                lMPathY = MyCLng(rsMobPath!y)
                                lMPathZ = MyCLng(rsMobPath!z)
                                'Debug.Print zMobName
                                If (lRandom(2) = 1 Or lMobPathRecordCount = 1) Then 'we select a valid path for this mob, randomly
                                    If (bAreaMovementAllowedBLOCKEDONLY(lMPathX, lMPathY, lMPathZ, lMX, lMY, lMZ, lMobType)) Then 'We move the mob but we dont want the mob to cut corners so we have to check for blocks. This is like a filter.
                                    
                                        'We show the mob move out of one place to the new location
                                        If (Not bMobActivatlyInCombat(lMobID)) Then
                                            bMobPath = True 'we assume everything will be fine and set to skip this loop
                                            lMobsMoved = lMobsMoved + 1
                                            lTZ = lMZ
                                            If (bOdd(lMPathZ)) Then
                                                'We jump the Z odd layer position.
                                                If (lTZ < lMPathZ) Then
                                                    lTZ = lMPathZ + 1 'skip an area and go down
                                                Else
                                                    lTZ = lMPathZ - 1 'skip an area and go up
                                                End If
                                            Else
                                                lTZ = lMPathZ
                                            End If
                                            
                                            If (MyCInt(rsMob!Flys) = 0) Then
                                                subSendMsgAreaAllDetectInvisibility gblzFBMAG, 0, _
                                                    "Someone " & MyCStr(rsMob!WalkExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!WalkExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    "", _
                                                    "", _
                                                    lMX, lMY, lMZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                                
                                                subSendMsgAreaAllDetectInvisibility gblzFBMAG, 0, _
                                                    "Someone " & MyCStr(rsMob!WalkEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!WalkEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    "", _
                                                    "", _
                                                    lMPathX, lMPathY, lTZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                            Else
                                                'subSendMsgAreaAllDISmart "&M", "", "", zMobName, "%s1 leaves to the " & zTranslateMatrixDirection(lTX, lTY, lTZ, lMobHuntX, lMobHuntY, lMobHuntZ, 1), lMobHuntX, lMobHuntY, lMobHuntZ, "", MyCInt(bMobInvisible)
                                                'TRISKER SMART MOVE HERE
                                                subSendMsgAreaAllDetectInvisibility gblzFBMAG, 0, _
                                                    "Someone " & MyCStr(rsMob!FlyExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!FlyExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    "", _
                                                    "", _
                                                    lMX, lMY, lMZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                                subSendMsgAreaAllDetectInvisibility gblzFBMAG, 0, _
                                                    "Someone " & MyCStr(rsMob!FlyEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!FlyEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    "", _
                                                    "", _
                                                    lMPathX, lMPathY, lTZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                            End If
                                            'We now move the mob to this path
                                            MyDB.Execute "UPDATE tblMob SET X=" & lMPathX & ", Y=" & lMPathY & ", Z=" & lTZ & " WHERE (MobID=" & lMobID & ");", dbFailOnError 'We move the mob to the location
                                            
                                            basMobVsTargetSpeak lMobID, lMPathX, lMPathY, lMPathZ
                                            
                                            If (lMvMMobID <> 0 And lRandom(9) = 1) Then subSeeIfAMobThumpsANewDefeatedMobDesc lMobID, lMvMMobID 'Mobs hunt certain mobs
                                        End If
                                    End If
                                End If
                                lMobPathRecordCount = lMobPathRecordCount - 1
                                rsMobPath.MoveNext
                            Loop
                        End If
                        Set rsMobPath = Nothing
                    End If
                    Set rsMob = Nothing
                End If
                rsMobList.MoveNext
            Loop
        End If
        Set rsMobList = Nothing
        rsWhereMob.MoveNext
    Loop
    Set rsWhereMob = Nothing
    End If
    
    zLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
    If Len(zLagTimerA) > 0 And Len(zLagTimerB) > 0 Then
        If (DateDiff("s", zLagTimerA, zLagTimerB) > 2) Then
            subSystemMessageToImmortals gblzFNRED & "(EAR) " & gblzFBRED & "N2a mobpathing completed [" & DateDiff("s", zLagTimerA, zLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1
            If (gblbServerSteroid) Then DoEvents 'SUBLOOPSystem-Tick[
        End If
    End If
    
    If lRandom(10) = 1 Then
    'STOCK MARKET
    lX = 0
    lY = 0
    lZ = 0
    lChangeSummary = 0
    bChange = False
    Set rsStockMarket = MyDB.OpenRecordset("SELECT * FROM tblPlayerStock WHERE (PlayerID=0) ORDER BY Z, X, Y, StockName;", dbOpenDynaset)
    If (Not rsStockMarket.EOF) Then
        Do While (Not rsStockMarket.EOF)
            lPlayerStockID = MyCLng(rsStockMarket!PlayerStockID)
            lReportCountOfPlayerStockID = MyCLng(rsStockMarket!ReportCountOfPlayerStockID)
            lPositionFromCenter = MyCLng(rsStockMarket!PositionFromCenter)
            lValue = MyCLng(rsStockMarket!Value)
            
            lChange = 0
            
            zChangeModPrint = ""
            
            zChangeMod = "1"
            Select Case lRandom(30 + cstlStockModification)
                Case 1
                    lChange = lChange - 1
                    zChangeMod = "A"
                Case 3
                    lChange = lChange - lRandom(2)
                    zChangeMod = "B"
                Case 5
                    lChange = lChange - (2 + lRandom(2))
                    zChangeMod = "C"
                Case 7
                    lChange = lChange - (3 + lRandom(2))
                    zChangeMod = "D"
                Case 24
                    lChange = lChange + 1
                    zChangeMod = "W"
                Case 26
                    lChange = lChange + lRandom(2)
                    zChangeMod = "X"
                Case 28
                    lChange = lChange + (2 + lRandom(2))
                    zChangeMod = "Y"
                Case 30
                    lChange = lChange + (3 + lRandom(2))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            zChangeMod = "2"
            Select Case lRandom(60 + cstlStockModification) 'just to make it juggle a bit more
                Case 1
                    lChange = lChange - 1
                    zChangeMod = "A"
                Case 3
                    lChange = lChange - 2
                    zChangeMod = "B"
                Case 5
                    lChange = lChange - (4 + lRandom(3))
                    zChangeMod = "C"
                Case 56
                    lChange = lChange + 1
                    zChangeMod = "X"
                Case 58
                    lChange = lChange + 2
                    zChangeMod = "Y"
                Case 60
                    lChange = lChange + (4 + lRandom(3))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            zChangeMod = "3"
            Select Case lRandom(80 + cstlStockModification) 'just to make it juggle even a bit more
                Case 10
                    lChange = lChange - lRandom(2)
                    zChangeMod = "A"
                Case 30
                    lChange = lChange - (3 + lRandom(3))
                    zChangeMod = "B"
                Case 78
                    lChange = lChange + lRandom(2)
                    zChangeMod = "Y"
                Case 80
                    lChange = lChange + (3 + lRandom(3))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            zChangeMod = "4"
            Select Case lRandom(90 + cstlStockModification) 'just to make it juggle even a bit more
                Case 10
                    lChange = lChange - lRandom(5)
                    zChangeMod = "A"
                Case 30
                    lChange = lChange - (4 + lRandom(4))
                    zChangeMod = "B"
                Case 88
                    lChange = lChange + lRandom(5)
                    zChangeMod = "Y"
                Case 90
                    lChange = lChange + (4 + lRandom(4))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            If (Not bChange) Then
                If (zChangeModPrint <> "1234") Then
                    bChange = True 'this means one of them did change
                End If
            End If
            
            If (lChange <> 0) Then
                lChangeSummary = lChangeSummary + lChange 'this is just a total of changes
                lPositionFromCenter = lPositionFromCenter + lChange
                If (gblConstructorlMode <> 2) Then
                    If (lChange > 0 And lRandom(9) = 1) Then 'add in what the most worn objects are tagged to
                        lDummy = lReturnStockIntelligenceBonus(lReportCountOfPlayerStockID)
                        If (lDummy > 0) Then
                            If (lRandom(3) = 1) Then
                                lDummy = 0
                            Else
                                lDummy = lRandom(3)
                                subSendMsgInfoChannel "&WStock Market NEWS - &G" & MyCStr(rsStockMarket!StockName) & " got a BONUS INDEX of +" & lDummy
                            End If
                        End If
                        lChange = lChange + lDummy
                    End If
                End If
                'We make a record of this index - for a cool gantt chart of its growth
                MyDB.Execute "INSERT INTO tblPlayerStockGantt ( PlayerStockID, Growth, PurchaseValue ) SELECT " & lPlayerStockID & ", " & lChange & ", " & lPositionFromCenter & ";", dbFailOnError
                subStockMarketGanttArchiveCleanUp lPlayerStockID
                
                rsStockMarket.Edit
                rsStockMarket!PositionFromCenter = lPositionFromCenter
                rsStockMarket.Update
            End If
            
            If (lValue + lPositionFromCenter <= 0) Then
                'Company went bankrupt
                'delete all player stocks
                MyDB.Execute "DELETE tblPlayerStock.PlayerStockID FROM tblPlayerStock WHERE (((tblPlayerStock.PlayerStockChildID)=" & MyCLng(rsStockMarket!PlayerStockID) & ") AND ((tblPlayerStock.PlayerID)<>0));", dbFailOnError
                
                'Set the main stock
                rsStockMarket.Edit
                rsStockMarket!Value = MyCLng(rsStockMarket!CreationValueBonus) + 247 + lRandom(250) + lRandom(250) + lRandom(250)
                rsStockMarket!PositionFromCenter = 0
                rsStockMarket!NumberOfBankrupts = MyCLng(rsStockMarket!NumberOfBankrupts) + 1
                rsStockMarket!LastBankruptDateTime = Now()
                rsStockMarket.Update
                subSendMsgInfoChannel "&WStock Market NEWS - &R" & MyCStr(rsStockMarket!StockName) & " went BANKRUPT!!!"
            Else
                If (lRandom(25000) = 1) Then
                    'Company split money to reduce the value being so high, or sometimes to bring it closer to bankrupt in a gamble
                    'double all player stocks
                    MyDB.Execute "UPDATE tblPlayerStock SET tblPlayerStock.Shares = [Shares] * 2 WHERE (((tblPlayerStock.PlayerStockChildID)=" & MyCLng(rsStockMarket!PlayerStockID) & ") AND ((tblPlayerStock.PlayerID)<>0));", dbFailOnError
                    
                    rsStockMarket.Edit
                    rsStockMarket!Value = Abs(lValue + lPositionFromCenter)
                    rsStockMarket!PositionFromCenter = 0
                    rsStockMarket!NumberOFSplits = MyCLng(rsStockMarket!NumberOFSplits) + 1
                    rsStockMarket!LastSplitDateTime = Now()
                    rsStockMarket.Update
                    subSendMsgInfoChannel "&WStock Market NEWS - &G" & MyCStr(rsStockMarket!StockName) & " has SPLIT SHARES!!!"
                Else
                    If (lRandom(50000) = 1) Then 'Instant HOAX the company, this should be rare
                        'Company was a HOAX
                        'delete all player stocks
                        MyDB.Execute "DELETE tblPlayerStock.PlayerStockID FROM tblPlayerStock WHERE (((tblPlayerStock.PlayerStockChildID)=" & MyCLng(rsStockMarket!PlayerStockID) & ") AND ((tblPlayerStock.PlayerID)<>0));", dbFailOnError
                        
                        'Set the main stock
                        rsStockMarket.Edit
                        rsStockMarket!Value = MyCLng(rsStockMarket!CreationValueBonus) + 247 + lRandom(250) + lRandom(250) + lRandom(250)
                        rsStockMarket!PositionFromCenter = 0
                        rsStockMarket!NumberOfFakes = MyCLng(rsStockMarket!NumberOfFakes) + 1
                        rsStockMarket!LastHoaxDateTime = Now()
                        rsStockMarket.Update
                        subSendMsgInfoChannel "&WStock Market NEWS - &R" & MyCStr(rsStockMarket!StockName) & " was a SCAM and was DISOLVED!!!"
                    End If
                End If
            End If
            
            If (lX <> MyCLng(rsStockMarket!x) Or lY <> MyCLng(rsStockMarket!y) Or lZ <> MyCLng(rsStockMarket!z)) Then
                lX = MyCLng(rsStockMarket!x)
                lY = MyCLng(rsStockMarket!y)
                lZ = MyCLng(rsStockMarket!z)
                If (lngSQLRecordCount("SELECT tblPlayer.PlayerID FROM tblPlayer WHERE (((tblPlayer.X)=" & lX & ") AND ((tblPlayer.Y)=" & lY & ") AND ((tblPlayer.Z)=" & lZ & ") AND ((tblPlayer.PortID)<>'0' And (tblPlayer.PortID) Is Not Null));") <> 0) Then
                    'subPlayerStockShow "", lX, lY, lZ, "A", "- END OF DAY"
                    subSendMsgAreaAll "&g--------------------------------------------------------------------------------", lX, lY, lZ
                End If
            End If
            
            If (lChange > 0) Then
                subSendMsgAreaAll "&G" & strForceSize(MyCStr(rsStockMarket!StockName), 45, " ", "A") & "(" & zChangeModPrint & ") " & lChange, lX, lY, lZ
            Else
                If (lChange < 0) Then
                    subSendMsgAreaAll "&a" & strForceSize(MyCStr(rsStockMarket!StockName), 45, " ", "A") & "(" & zChangeModPrint & ") " & lChange, lX, lY, lZ
                Else
                    subSendMsgAreaAll "&g" & strForceSize(MyCStr(rsStockMarket!StockName), 45, " ", "A") & "(" & zChangeModPrint & ") " & lChange, lX, lY, lZ
                End If
            End If
            
            rsStockMarket.MoveNext
        Loop
        
        If (lChangeSummary > 0) Then 'STOCK MARKET
            subSendMsgAreaAll "&G                                             INDEX: " & lChangeSummary, lX, lY, lZ
            If (lChangeSummary > 49) Then
                subSendMsgInfoChannel "&WStock Market NEWS - &YINDEX: " & lChangeSummary & " *CHEER* All Stocks +2% in value!"
                MyDB.Execute "UPDATE tblPlayerStock SET PositionFromCenter = ([PositionFromCenter])+Abs(([PositionFromCenter]*0.02)) WHERE (PlayerID=0);", dbFailOnError
            End If
        Else
            If (lChangeSummary < 0) Then
                subSendMsgAreaAll "&a                                             INDEX: " & lChangeSummary, lX, lY, lZ
                If (lChangeSummary < -49) Then
                    subSendMsgInfoChannel "&WStock Market NEWS - &aINDEX: " & lChangeSummary & " *PaNiC* All Stocks -2% in value!"
                    MyDB.Execute "UPDATE tblPlayerStock SET PositionFromCenter = ([PositionFromCenter])+(-1*([PositionFromCenter]*0.02)) WHERE (PlayerID=0);", dbFailOnError
                End If
            Else
                subSendMsgAreaAll "&g                                             INDEX: Balanced", lX, lY, lZ
                If (Not bChange) Then subSendMsgInfoChannel "&WStock Market NEWS - &aINDEX: *No Change* All stocks simmer in their current investments."
            End If
        End If
    End If
    Set rsStockMarket = Nothing
    End If
    
    'Realestate Market - this can LAG with lots of starships
    If (lRandom(100) = 1) Then
        lRealestateCount = 0
        lRealestateSSPlayerID = 0
        Set rsRealestate = MyDB.OpenRecordset("SELECT PlayerID, ColonistsPlayerID, AreaName, ColonistsAboard, ColonistsNumber FROM tblArea WHERE (ColonistsPlayerID<>0) ORDER BY AreaName;", dbOpenDynaset)
        If (Not rsRealestate.EOF) Then
            Do While (Not rsRealestate.EOF)
                lRealestateCount = lRealestateCount + 1
                bChanged = False
                lRealestateSSPlayerID = MyCLng(rsRealestate!PlayerID) 'starship playerid
                lColonistsPlayerID = MyCLng(rsRealestate!ColonistsPlayerID) 'owner of the colonists
                lColonistsNumber = MyCLng(rsRealestate!ColonistsNumber)
                lColonistsAboard = MyCLng(rsRealestate!ColonistsAboard)
                
                If (lRandom(1000) = 1) Then
                    lChange = 0
                    Select Case lRandom(20)
                        Case 1
                            lChange = 350 + lRandom(150)
                            bChanged = True
                        Case 2
                            lChange = -1 * (350 + lRandom(150))
                            bChanged = True
                    End Select
                    
                    lColonistsNumber = lColonistsNumber + lChange
                    If (lChange > 0) Then
                        subSendMsgInfoChannel "&y" & MyCStr(rsRealestate!AreaName) & " grows " & lChange & " extra colonists!"
                    Else
                        If (lChange <> 0) Then subSendMsgInfoChannel "&RCIVIL UNREST: " & MyCStr(rsRealestate!AreaName) & " looses " & Abs(lChange) & " colonists!"
                    End If
                End If
                
                If (lColonistsNumber > 0) Then
                    If (lRandom(5000) = 1) Then
                        If (lColonistsAboard = 0) Then 'starships are protected unless their aboard amount is zero
                            lPlayerCount = lngSQLRecordCount("SELECT PlayerID, PortID FROM tblPlayer WHERE (Len([PortID])>1);")
                            If (lPlayerCount < 1) Then lPlayerCount = 1
                            
                            Set rsRandomPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lPlayerCount) & " PlayerName, PlayerID, PortID FROM tblPlayer WHERE (PortID IS Not Null AND PortID <> '' AND PortID <> '0');", dbOpenSnapshot)
                            If (Not rsRandomPlayer.EOF) Then
                                If (lRealestateSSPlayerID <> MyCLng(rsRandomPlayer!PlayerID)) Then
                                    If (lColonistsPlayerID <> MyCLng(rsRandomPlayer!PlayerID)) Then
                                        bChanged = True
                                        rsRandomPlayer.MoveLast
                                        lColonistsPlayerID = MyCLng(rsRandomPlayer!PlayerID) 'random player to take over the colonist base
                                        subSendMsgInfoChannel "&ROVERTHROWN! " & MyCStr(rsRealestate!AreaName) & " falls to " & MyCStr(rsRandomPlayer!PlayerName) & "'s rebel colonist force!"
                                        lColonistsNumber = MyCLng(lColonistsNumber / 4)
                                        lColonistsAboard = MyCLng(lColonistsAboard / 4)
                                    Else
                                        subSendMsgInfoChannel "&YPARTY! " & MyCStr(rsRealestate!AreaName) & " throws a party for Systemlord " & MyCStr(rsRandomPlayer!PlayerName) & "!"
                                    End If
                                Else
                                    subSendMsgInfoChannel "&YSTARSHIP PARTY! " & MyCStr(rsRealestate!AreaName) & " throws a party for Systemlord " & MyCStr(rsRandomPlayer!PlayerName) & "!"
                                End If
                            End If
                            Set rsRandomPlayer = Nothing
                        End If
                    End If
                End If
                
                If (bChanged) Then
                    If (lColonistsNumber < 0) Then lColonistsNumber = 0
                    If (lColonistsAboard < 0) Then lColonistsAboard = 0
                    rsRealestate.Edit
                    rsRealestate!ColonistsNumber = lColonistsNumber
                    rsRealestate!ColonistsAboard = lColonistsAboard
                    rsRealestate!ColonistsPlayerID = lColonistsPlayerID
                    rsRealestate.Update
                End If
                rsRealestate.MoveNext
            Loop
        End If
        Set rsRealestate = Nothing
    End If
    
    zLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
    If Len(zLagTimerA) > 0 And Len(zLagTimerB) > 0 Then
        If (DateDiff("s", zLagTimerA, zLagTimerB) > 8) Then subSystemMessageToImmortals gblzFNRED & "(EAR) " & gblzFBRED & "N2a stocks/colonists calculated [" & DateDiff("s", zLagTimerA, zLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1
    End If
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subRotateTheWorldLessOften," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRotateTheWorld() 'see also subRotateTheWorldEverything
On Error GoTo Err_Check
'This is where you would reset all the doors, move the mobs.
    Dim lMobID As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim rsMoveMob As Recordset
    
    Dim rsMobList As Recordset
    Dim rsMob As Recordset
    Dim rsMobPath As Recordset
    
    Dim zMobName As String
    Dim rsArea As Recordset
    Dim rsAreaBlockedPath As Recordset
    Dim rsPlayer As Recordset
    Dim iLoc As Integer
    Dim zBlockedExits As String
    Dim rsObject As Recordset
    Dim zObjectName As String
    Dim zSQL As String
    Dim bMobPath As Boolean
    Dim lMvMMobID As Long
    
    Dim lAreaID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    
    Dim rsAreaBridge As Recordset
    Dim lAreaBridgeID As Long
    
    'Working Visible Version: the below is to see the mob respawn if you want to activate it - it adds to lag a bit.
    'Set rsMoveMob = MyDB.OpenRecordset("SELECT CHITROLLBase, CDAMROLLBase, ShockshieldDuration, PlayerID, X, Y, Z, MHPBonus, MACBonus, CHITROLLBonus, CDAMROLLBonus, MobName, RespawnDelay, StunDuration, RespawnX, RespawnY, RespawnZ, MHP, MAC, MobLevel FROM tblMob WHERE (RespawnDelay>0);", dbOpenDynaset)
    'Do While (Not rsMoveMob.EOF)
    '    zMobName = zShortstop(MyCStr(rsMoveMob!MobName))
    '    rsMoveMob.Edit
    '    rsMoveMob!RespawnDelay = MyCLng(rsMoveMob!RespawnDelay) - 1 'Now subtract 1 from RespawnDelay on all dead mobs.
    '    'Set the X Y Z to Respawn X Y Z when the RespawnDelay is on its last go.
    '    If (MyCLng(rsMoveMob!RespawnDelay) = 0) Then
    '        rsMoveMob!CHITROLLBase = (MyCLng(rsMoveMob!MobLevel) * cstMobHRRespawn) + MyCLng(rsMoveMob!CHITROLLBonus)
    '        rsMoveMob!CDAMROLLBase = (MyCLng(rsMoveMob!MobLevel) * cstMobDRRespawn) + MyCLng(rsMoveMob!CDAMROLLBonus)
    '        rsMoveMob!MHP = (MyCLng(rsMoveMob!MobLevel) * cstMobHPRespawn) + MyCLng(rsMoveMob!MHPBonus)
    '        rsMoveMob!Mac = (MyCLng(rsMoveMob!MobLevel) * cstMobACRespawn) + MyCLng(rsMoveMob!MACBonus)
    '        rsMoveMob!PlayerID = 0
    '        rsMoveMob!StunDuration = 0
    '        rsMoveMob!X = MyCLng(rsMoveMob!RespawnX)
    '        rsMoveMob!Y = MyCLng(rsMoveMob!RespawnY)
    '        rsMoveMob!Z = MyCLng(rsMoveMob!RespawnZ)
    '        rsMoveMob!ShockshieldDuration = 0
    '        subSendMsgAreaAll "&BThere is a flash of light as " & zMobName & " appears before you!", MyCLng(rsMoveMob!RespawnX), MyCLng(rsMoveMob!RespawnY), MyCLng(rsMoveMob!RespawnZ)
    '    End If
    '    rsMoveMob.Update
    '    rsMoveMob.MoveNext
    'Loop
    'Set rsMoveMob = nothing
    
    'RESET CHEST LOCATIONS
    If (lRandom(675) = 1) Then
        If (lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (ThiefChestOfGlory=0);") > 0) Then
            MyDB.Execute "UPDATE tblArea SET ThiefMobID=0, ThiefChestOfGlory=0;", dbFailOnError
            subSendMsgInfoChannel "&wAll the Thieves pack up their chests and leave the realm."
        End If
    End If
    
    'DOOR LEVER DURATIONS:
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, ResetDuration, Status, DoorID FROM tblDoorLever WHERE ResetDuration > 0;", dbOpenDynaset)
    Do While (Not rsPlayer.EOF)
        rsPlayer.Edit
        If (MyCLng(rsPlayer!ResetDuration) > 0) Then
            rsPlayer!ResetDuration = MyCLng(rsPlayer!ResetDuration) - 1
            If (MyCLng(rsPlayer!ResetDuration) = 0) Then
                rsPlayer!Status = 0 'Reset lever
                'Since the lever got reset it only takes one lever to be out of order for a open door so now we lock the door automatically.
                MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 2, tblDoor.ResetTimer = 0 WHERE (((tblDoor.DoorID)=" & MyCLng(rsPlayer!DoorID) & "));", dbFailOnError
                subSendMsgAreaAll "&yYou hear chains running through the walls a moment before it stopped.", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z)
            End If
        End If
        rsPlayer.Update
        rsPlayer.MoveNext
    Loop
    Set rsPlayer = Nothing
    
    'Some doors you can Pick and/or Key unlock, or bashable (magic can open bashable doors too)
    'Resets Doors back to locked and/or closed!
    'We set the value 1 or 3 becomes 2
    MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 2 WHERE (((tblDoor.ResetTimer)=1) AND ((tblDoor.Status)=1 Or (tblDoor.Status)=3));", dbFailOnError
    'We set the value 0 becomes 6 - always open gets closed
    MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 6 WHERE (((tblDoor.ResetTimer)=1) AND ((tblDoor.Status)=0));", dbFailOnError
    'We set the value 8 becomes 4
    MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 4 WHERE (((tblDoor.ResetTimer)=1) AND ((tblDoor.Status)=8));", dbFailOnError
    'We set the bashed value 5 (bashed open), 7 (bashed closed) becomes 8 (bashable)
    MyDB.Execute "UPDATE tblDoor SET BashDoorTries=0, Status=8 WHERE ((ResetTimer=1) AND (Status=5 OR Status=7));"
    'magically sealed doors
    MyDB.Execute "UPDATE tblDoor SET MagicDoorTries=0, Status=12 WHERE ((ResetTimer=1) AND (Status=10 OR Status=11));"
    'Now subtract 1 from ResetTimer on all open doors to finish up the reset on them
    MyDB.Execute "UPDATE tblDoor SET tblDoor.ResetTimer = [tblDoor].[ResetTimer]-1 WHERE (((tblDoor.ResetTimer)>0));", dbFailOnError
    'Reset Draw Bridges - Move Players and Mobs to the Trigger location - objects can stay in no mans land
    Set rsAreaBridge = MyDB.OpenRecordset("SELECT * FROM tblAreaBridge WHERE AreaBridgeTimer=1;", dbOpenSnapshot)
    If (Not rsAreaBridge.EOF) Then
        Do While (Not rsAreaBridge.EOF)
            lAreaBridgeID = MyCLng(rsAreaBridge!AreaBridgeID)
            lAreaID = MyCLng(rsAreaBridge!AreaID)
            lX = MyCLng(rsAreaBridge!AreaBridgeTriggerX)
            lY = MyCLng(rsAreaBridge!AreaBridgeTriggerY)
            lZ = MyCLng(rsAreaBridge!AreaBridgeTriggerZ)
            lTX = MyCLng(rsAreaBridge!AreaBridgeDX)
            lTY = MyCLng(rsAreaBridge!AreaBridgeDY)
            lTZ = MyCLng(rsAreaBridge!AreaBridgeDZ)
            lOX = MyCLng(rsAreaBridge!AreaBridgeOX)
            lOY = MyCLng(rsAreaBridge!AreaBridgeOY)
            lOZ = MyCLng(rsAreaBridge!AreaBridgeOZ)
            
            'Move all the players, and mobs, not objects off the moving bridge
            MyDB.Execute "UPDATE tblPlayer SET X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ";", dbFailOnError
            MyDB.Execute "UPDATE tblMob SET X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ";", dbFailOnError
            'Reset the timer for the bridge
            MyDB.Execute "UPDATE tblArea SET X=" & lOX & ", Y=" & lOY & ", Z=" & lOZ & " WHERE AreaID=" & lAreaID & ";", dbFailOnError
            MyDB.Execute "UPDATE tblAreaBridge SET AreaBridgeTimer=0 WHERE AreaBridgeID=" & lAreaBridgeID & ";", dbFailOnError
            rsAreaBridge.MoveNext
        Loop
    End If
    Set rsAreaBridge = Nothing
    MyDB.Execute "UPDATE tblAreaBridge SET AreaBridgeTimer=[AreaBridgeTimer]-1 WHERE (AreaBridgeTimer>1);"
    
    'Reset all areas that have tblArea traps - ie. Underwater
    MyDB.Execute "UPDATE tblArea SET Underwater=UnderwaterOriginal WHERE UnderwaterDuration=1;", dbFailOnError
    MyDB.Execute "UPDATE tblArea SET UnderwaterDuration=UnderwaterDuration-1 WHERE UnderwaterDuration>0;", dbFailOnError
    
    'Reset all search areas RBCBlocked ExitBlocked
    Set rsArea = MyDB.OpenRecordset("SELECT * FROM tblAreaBlockedPath WHERE Used=True;", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        Do While (Not rsArea.EOF)
            lAreaID = 0
            lX = MyCLng(rsArea!x)
            lY = MyCLng(rsArea!y)
            lZ = MyCLng(rsArea!z)
            Set rsAreaBlockedPath = MyDB.OpenRecordset("SELECT Exits, AreaID, BlockedExits FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
            If (Not rsAreaBlockedPath.EOF) Then
                lAreaID = MyCLng(rsAreaBlockedPath!AreaID)
                zBlockedExits = MyCStr(rsAreaBlockedPath!BlockedExits)
                iLoc = iDirectionSwitchCode(MyCStr(rsArea!AreaRBDir))
                If (iLoc > 0) Then MyDB.Execute "UPDATE tblArea SET BlockedExits='" & (Mid(zBlockedExits, 1, iLoc - 1) & "1" & Mid(zBlockedExits, iLoc + 1)) & "' WHERE (AreaID=" & lAreaID & ");", dbFailOnError 'rsAreaBlockedPath!BlockedExits = Mid(zBlockedExits, 1, iLoc - 1) & "1" & Mid(zBlockedExits, iLoc + 1) 'Put the block back up
            End If
            Set rsAreaBlockedPath = Nothing
            
            If (lAreaID <> 0) Then
                MyDB.Execute "UPDATE tblArea SET Exits='" & zShowExits(lX, lY, lZ) & "' WHERE (AreaID=" & lAreaID & ");", dbFailOnError
            End If
            
            rsArea.MoveNext
        Loop
        MyDB.Execute "UPDATE tblAreaBlockedPath SET Used=False;", dbFailOnError
    End If
    Set rsArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subRotateTheWorld," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRotateTheWorldEverything()
On Error Resume Next
    'Rotate the world
    DoEvents
    subRotateTheWorld
    subRotateAreaTransit
    subRotateObjectTransit
    subRotateMobSpeak 0, 0, 0, False
    subRotateObjectContainerRespawn
    subAddMenToColonizies
    gbllSystemTick = 0
    frmTelnetServerEngine!lblMsg.Caption = "world rotated"
End Sub
Public Function lMerchantType(zPortID As String) As Long
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lReturn As Long
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lWhereID As Long
    Dim bNewbie As Boolean
    Dim bBlackMarket As Boolean
    Dim bBlackMarketSpot As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    
    lReturn = 0 'no merchant here
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, WhereID, PlayerLevel, Status, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lWhereID = MyCLng(rsPlayer!WhereID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        bNewbie = (bNewbieArea(lPlayerLevel, lWhereID)) Or (gblConstructorlMode = 2)  'newbie shops are always open
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        bBlackMarketSpot = (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (BlackMarketLevel>0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") > 0)
        bBlackMarket = (bBlackMarketTime() And bBlackMarketSpot)
        
        If ((bWhenIsIt("", False) And Not bBlackMarketSpot) Or (lPlayerLevel < 50) Or (bBlackMarket) Or (bNewbie)) Then
            lReturn = 1 'regular shop is open during the day
        End If
    End If
    Set rsPlayer = Nothing
    lMerchantType = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lMerchantType," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subMerchantInAreaPurchase(zPortID As String, zWord2 As String)
On Error GoTo Err_Check
    Dim lCostMultiplier As Long
    Dim rsPlayer As Recordset
    Dim rsMob As Recordset
    Dim bOffHourSales As Boolean
    Dim lPlayerWeight As Long
    Dim lMobWeight As Long
    Dim lMobPrice As Long 'lMobPrice = MyCLng(rsMob!Price)
    Dim lMerchantCost As Long
    Dim zReturn As String
    Dim zBuyObjectName As String
    Dim lPlayerID As Long
    Dim lPlayerGold As Long
    Dim lObjectID As Long
    Dim zPlayerName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lBuyDuration As Long
    Dim lPlayerLevel As Long
    Dim zRace As String
    Dim bBlackMarketSpot As Boolean
    Dim bBlackMarket As Boolean
    Dim zObjectName As String
    Dim lBuyDelay As Long
    Dim lQuaffSpellNo As Long
    Dim lWhereID As Long
    Dim bNewbie As Boolean 'in newbie zone?
    Dim lDetectInvisibilityDuration As Long
    Dim lPortID As Long
        
    'BuyDuration is being used for BuyQuestDuration until I can rename the field.
    zReturn = ""
    If (Len(zWord2) <> 0) Then
        lPortID = MyCLng(zPortID)
        Set rsPlayer = MyDB.OpenRecordset("SELECT DetectInvisibilityDuration, WhereID, Race, PlayerLevel, Status, BuyDuration, X, Y, Z, PlayerName, PlayerID, Gold, Weight, CSTR FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lWhereID = MyCLng(rsPlayer!WhereID)
            lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
            bNewbie = (bNewbieArea(lPlayerLevel, lWhereID)) Or (gblConstructorlMode = 2)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            If (lPortID >= cstlMinPort And lPortID <= cstlMinPort) Then
                If (Not gblbFilterMode(lPortID)) Then
                    If (Not lngSQLRecordCount("SELECT Count(tblMerchandise.MerchandiseID) AS CountOfMerchandiseID FROM tblMerchandise INNER JOIN tblMob ON tblMerchandise.MobID = tblMob.MobID GROUP BY tblMob.X, tblMob.Y, tblMob.Z HAVING (((tblMob.X)=" & lX & ") AND ((tblMob.Y)=" & lY & ") AND ((tblMob.Z)=" & lZ & "));") > 0) Then
                        subSendMsg "&gThere is no merchant here.", zPortID
                    End If
                End If
            End If
            lPlayerWeight = MyCLng(rsPlayer!Weight)
            lCostMultiplier = 1
            bBlackMarketSpot = (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (BlackMarketLevel>0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") > 0)
            bBlackMarket = (bBlackMarketTime() And bBlackMarketSpot)
            bOffHourSales = ((Not bWhenIsIt("", False)))
            If ((Not bOffHourSales And Not bBlackMarketSpot) Or (lPlayerLevel <= cstMerchantPlayerLevel) Or (bBlackMarket) Or (bNewbie)) Then
                If (bOffHourSales And lPlayerLevel > 19) Then
                    subSendMsg "&BExtra price on off-hour sales!", zPortID
                    lCostMultiplier = lCostMultiplier * 3
                End If
                
                zRace = MyCStr(rsPlayer!Race)
                If (lTotalObjectsPlayerInv(lPlayerID) <= cstlBaseItemsHeld + lInvHoldRaceBonus(zRace)) Then
                    lBuyDuration = MyCLng(rsPlayer!BuyDuration)
                    lPlayerID = MyCLng(rsPlayer!PlayerID)
                    
                    zPlayerName = MyCStr(rsPlayer!PlayerName)
                    If (MyCLng(rsPlayer!Status) <> 50) Then
                        If (lBuyDuration = 0 Or bNewbie) Then
                            If (lTotalObjectsPlayerInv(lPlayerID) < 11) Then
                                zBuyObjectName = zKeepLettersOnly(zWord2)
                                Set rsMob = MyDB.OpenRecordset("SELECT tblMob.Invisible, tblMerchandise.Price, tblObject.QuaffSpellNo, tblObject.ObjectID, tblObject.ObjectName, tblObject.Weight FROM (tblMob INNER JOIN tblMerchandise ON tblMob.MobID = tblMerchandise.MobID) INNER JOIN tblObject ON tblMerchandise.ObjectID = tblObject.ObjectID WHERE (tblMob.RespawnDelay=0 AND tblMob.X=" & lX & " AND tblMob.Y=" & lY & " AND tblMob.Z=" & lZ & " AND ObjectName Like '*" & zBuyObjectName & "*');", dbOpenSnapshot) 'We want the double ** so that the player can type in lots of coner cutting letters!
                                If (Not rsMob.EOF) Then
                                    If (lDetectInvisibilityDuration > 0 Or MyCLng(rsMob!Invisible) = 0) Then
                                        lObjectID = MyCLng(rsMob!ObjectID)
                                        lQuaffSpellNo = MyCLng(rsMob!QuaffSpellNo)
                                        zObjectName = MyCStr(rsMob!ObjectName)
                                        zObjectName = zAdverb(zObjectName, 3) & zShortstop(zObjectName)
                                        lMobPrice = MyCLng(rsMob!Price)
                                        If (lMobPrice > 0) Then subSendMsg "&wREGULAR COST - &y" & lMobPrice & "&Yg", zPortID
                                        lMobWeight = MyCLng(rsMob!Weight)
                                        lMerchantCost = (MyCLng(vReturnObjectValue(lObjectID, 2)) * lCostMultiplier)
                                        If (lMerchantCost > 0) Then subSendMsg "&wWORTH[" & MyCLng(vReturnObjectValue(lObjectID, 2)) & "&Yg&w] [&Rx&w" & lCostMultiplier & "] &RTOTAL[&y" & lMerchantCost & "&Yg&R]", zPortID
                                        lMerchantCost = lMerchantCost + lMobPrice 'we can inflate the price with price command
                                        lPlayerGold = MyCLng(rsPlayer!Gold)
                                        If (MyCLng(rsPlayer!CStr) * gbllPlayerWeightMultiplierInGrams >= lPlayerWeight + lMobWeight) Then
                                            If (lPlayerGold >= lMerchantCost) Then
                                                If (lDuplicateObject(lObjectID, lPlayerID, lPlayerLevel, False, False, False, 0) <> 0) Then
                                                    If (lPlayerLevel > 19 And Not bNewbie) Then
                                                        'BuyDuration is just the duration before they can buy again now
                                                        'we have to becareful of purchase for raring. We use lBuyDelay for this.
                                                        If (lQuaffSpellNo <> 0) Then
                                                            lBuyDelay = lRandom(2) 'potions buy faster
                                                        Else
                                                            If (lPlayerGold > (lMerchantCost * 9) + 2123) Then 'if players have a lot of gold on them they might be buy lagging the system
                                                                lBuyDelay = (lRandom(4) + 5) 'this play is power buying so delay them a bit more
                                                            Else
                                                                lBuyDelay = lRandom(3) + 1
                                                            End If
                                                        End If
                                                        MyDB.Execute "UPDATE tblPlayer SET BuyDuration=" & lBuyDelay & ", Gold=[Gold]-" & lMerchantCost & ", Weight=[Weight]+" & lMobWeight & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                    Else
                                                        MyDB.Execute "UPDATE tblPlayer SET Gold=[Gold]-" & lMerchantCost & ", Weight=[Weight]+" & lMobWeight & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                    End If
                                                    'zReturn = "&YYou purchase " & zObjectName & " for " & lGold & " gold."
                                                    'subSendMsgAreaExcept2 gblzFNWHI & zPlayerName & " buys a " & zShortstop(MyCStr(rsMob!ObjectName)) & ".", lX, lY, lZ, zPortID, ""
                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "You purchase " & zObjectName & " for " & lMerchantCost & " gold.", "", "%s1 bought " & zObjectName & ".", lX, lY, lZ
                                                End If
                                            Else
                                                zReturn = "&YYou cannot afford " & zAdverb(MyCStr(rsMob!ObjectName), 4) & zShortstop(MyCStr(rsMob!ObjectName)) & " for " & lMerchantCost & " gold."
                                            End If
                                        Else
                                            zReturn = gblzFNGRE & "You are carrying too much weight to purchase " & zAdverb(MyCStr(rsMob!ObjectName), 4) & zShortstop(MyCStr(rsMob!ObjectName)) & "."
                                        End If
                                    Else
                                        zReturn = gblzFNGRE & "Do what now?"
                                    End If
                                    rsMob.MoveNext
                                Else
                                    zReturn = gblzFNGRE & "You cannot purchase that here, type LIST to see what a merchant sells."
                                End If
                                Set rsMob = Nothing
                            Else
                                zReturn = gblzFBRED & zVariableMessage("You can only have ten items in inventory before you make another purchase.")
                            End If
                        Else
                            Select Case lBuyDuration
                                Case 1
                                    Select Case lPlayerLevel
                                        Case 1 To 19
                                            zReturn = gblzFBRED & "You will have to wait one more round before purchasing something else." & gblzFBMAG & vbCrLf & "NOTE: When you purchase an item it has the possibility to rare." & vbCrLf & "      The purpose of the delay is to slow down the purchases of rich players." & vbCrLf & "      Give it a minute or two then try your purchase again." & vbCrLf & "&g      You will receive this training notice until you achieve level 20."
                                        Case Else
                                            zReturn = gblzFBRED & "You will have to wait one more round before purchasing something else."
                                    End Select
                                Case Else
                                    Select Case lPlayerLevel
                                        Case 1 To 19
                                            zReturn = gblzFBRED & "You will have to wait " & lBuyDuration & " rounds before purchasing something else." & gblzFBMAG & vbCrLf & "NOTE: When you purchase an item it has the possibility to rare." & vbCrLf & "      The purpose of the delay is to slow down the purchases of rich players." & vbCrLf & "      Give it a minute or two then try your purchase again." & vbCrLf & "&g      You will receive this training notice until you achieve level 20."
                                        Case Else
                                            zReturn = gblzFBRED & "You will have to wait " & lBuyDuration & " rounds before purchasing something else."
                                    End Select
                            End Select
                        End If
                    Else
                        zReturn = gblzFBGRE & "You dream about buying and selling equipment."
                    End If
                Else
                    zReturn = gblzFNRED & "If you bent over to get that you would drop something from your inventory."
                End If
            Else
                If (bBlackMarketSpot And bWhenIsIt("", False)) Then
                    zReturn = "&aThe black market is closed during the day."
                Else
                    If (bBlackMarketSpot) Then
                        zReturn = "&a(pssssst, the black markets are open from midnight to 3am)"
                    Else
                        zReturn = "&BThe shops are closed during the night."
                    End If
                End If
            End If
        End If
        Set rsPlayer = Nothing
        If (bBlackMarket) Then zReturn = "&a(pssssst, there is a black market running here!)" & vbCrLf & zReturn
        If (Len(zReturn) > 0) Then subSendMsg zReturn, zPortID
    Else
        subSendMsg "&GSyntax: BUY (merchant item)", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMerchantInAreaPurchase," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subIndicateGameEnterExit(zPortID As String, zType As String)
On Error GoTo Err_Check
    Const bStatusBM = False
    Const bStatusGUID = False
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerLevel As Long
    Dim lImmortalLevel As Long
    Dim lPlayerID As Long
    Dim lHold As Long
    Dim lPortID As Long
    Dim lStance As Long
    
    lPlayerLevel = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT Stance, PlayerFleeDuration, ImmortalLevel, ColorAreaDesc, PlayerName, BlindDuration, StunDuration, PlayerID, PlayerLevel, X,Y,Z, RecallX, RecallY, RecallZ FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        lPortID = MyCLng(zPortID)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        If (bPlayerOnAnyStarship(zPortID)) Then subSendMsgNoPortCheck "&W" & gblzMAPPEROFFCODE & " You are on a starship - 'Welcome aboard captain!'", zPortID
        lStance = MyCLng(rsPlayer!stance)
        lHold = lCalculateArmourAbsorbtionChance(lPlayerID, zPortID)
        lHold = lCalculateGoldDropChance(lPlayerID, zPortID)
        lHold = lCalculateInitativeChance(lPlayerID, zPortID, lStance)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        basCaptureTheFlag zPortID
        If (lPortID >= cstlMinPort And lPortID <= cstlMinPort) Then
            gblbInterruptPlayer(lPortID) = False
            gbllFishing(lPortID) = 0
            gbltArcadePlayer(lPortID).lGame = 0
            gbltArcadePlayer(lPortID).lPoints = 0
            gbltArcadePlayer(lPortID).zJoystick = ""
        End If
        If (Not bAreaExists(MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z))) Then
            rsPlayer.Edit
            rsPlayer!x = 0
            rsPlayer!y = 0
            rsPlayer!z = 0
            rsPlayer!RecallX = 0
            rsPlayer!RecallY = 0
            rsPlayer!RecallZ = 0
            rsPlayer.Update
        End If
        
        Select Case zAreaRules(9, MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z))
            Case "0"
                rsPlayer.Edit
                rsPlayer!PlayerFleeDuration = 3
                rsPlayer!RecallX = 0
                rsPlayer!RecallY = 0
                rsPlayer!RecallZ = 0
                rsPlayer.Update
                subSendMsgNoPortCheck "&Ra demon tells you, ""This is a no quit zone! Now I curse thee as a coward for a few moments!""", zPortID
        End Select
        
        Select Case Mid(zType, 1, 2)
             Case "EN"
                If (Len(zSystemConfig(5)) > 0) Then subSendMsgNoPortCheck "&w" & zSystemConfig(5), zPortID
                If (Len(zSystemConfig(6)) > 0) Then subSendMsgNoPortCheck "&w" & zSystemConfig(6), zPortID
                If (Len(zSystemConfig(7)) > 0) Then subSendMsgNoPortCheck "&w" & zSystemConfig(7), zPortID
                If (Len(zSystemConfig(8)) > 0) Then subSendMsgNoPortCheck "&w" & zSystemConfig(8), zPortID
                If (Len(zSystemConfig(9)) > 0) Then subSendMsgNoPortCheck "&w" & zSystemConfig(9), zPortID
                If (Len(zSystemConfig(10)) > 0) Then subSendMsgNoPortCheck "&w" & zSystemConfig(10), zPortID
                'subSendMsg "&yType PAGE LAST to see the login times of other players.", zPortID
                'If (MyCLng(rsPlayer!BlindDuration) = 0 And MyCLng(rsPlayer!StunDuration) = 0) Then
                '    subAreaDesc 0, 0, zPortID, MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), MyCLng(rsPlayer!PlayerLevel), MyCLng(rsPlayer!PlayerID), 0, MyCLng(rsPlayer!ColorAreaDesc), "", "11111", 0, 1, bStatusBM, bStatusGUID, ""
                'Else
                    If MyCLng(rsPlayer!BlindDuration) <> 0 Then subSendMsgNoPortCheck "&GYou are blind!", zPortID
                    If MyCLng(rsPlayer!StunDuration) <> 0 Then subSendMsgNoPortCheck "&RYou are stunned!", zPortID
                'End If
                subSendMsgAreaExcept2 "&g" & MyCStr(rsPlayer!PlayerName) & " enters the realm.", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, ""
                                
                If (gblbPageLastOkay) Then
                    If (lPlayerLevel < 13) Then
                        'subPlayerReports zPortID, "LAST", 1, True ' is a basic page last call
                        subSendMsgNoPortCheck "&Wtype PAGE LAST to see whom was on last." & vbCrLf & "&w" & "We are a new concept, totally customized." & vbCrLf & "&aWe have item randomization and customization! Forge, Rares, Uniques, MORE!" & vbCrLf & "type HELP QUESTS for all our quest designs, hundreds of them!" & vbCrLf & "&c" & "We are proud to be the first FULLY functional Visual Basic MUD!" & vbCrLf & "&gYou will only receive this message till level 13.", zPortID
                    End If
                End If
                
                If (lImmortalLevel = 0) Then
                    subShowMatchingPlayerNames zPlayerName, zPortID
                Else
                    'All immortals get to see the status of the system
                    subSystemReportBackUpAndErrorStatus (zPortID)
                End If
                
                If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                    If (lImmortalLevel > 79) Then
                        gblbImmortalWHODisplayed(lPortID) = False
                    End If
                End If
             Case "EX"
                subSendMsgAreaExcept2 "&g" & MyCStr(rsPlayer!PlayerName) & " exits the realm.", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, ""
         End Select
    End If
    Set rsPlayer = Nothing
    DoEvents
    Exit Sub
Err_Check:
    subWriteErrorFile "subIndicateGameEnterExit," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRecalculatePlayerEquipment(lOPlayerID As Long, zPortID As String)
On Error GoTo Err_Check 'see also subSLIST subCombatPlayerDurabilityLoss
'WARNING! Be very careful not to open the player table as a dynaset and then call this procedure - you will get a 3709 search string not found error on update!
    Const cstlMaxAtributes = 999
    Dim rsData As Recordset
    Dim rsCTF As Recordset
    Dim lReturnPetCount As Long
    Dim rsDataInv As Recordset
    Dim rsClanItem As Recordset
    Dim rsLearnSkills As Recordset
    Dim rsItemLevels As Recordset
    Dim rsPlayer As Recordset
    Dim lWeaponSkillBackStabClassLevel As Long
    Dim lWeaponSkillMissileRangeClassLevel As Long
    Dim zSQL As String
    Dim bOkay As Boolean
    Dim lWeight As Long
    Dim lStance As Long
    Dim lMagicFind As Long
    Dim lRegenerationLevel As Long
    Dim lLockPickToolBonus As Long
    Dim lSlayChance As Long
    Dim lIASChance As Long
    Dim zBittenReservedOriginalClass As String
    Dim zClass As String
    Dim zRace As String
    Dim lPlayerLevel As Long
    Dim lHP As Long
    Dim lAC As Long
    Dim lStr As Long
    Dim lInt As Long
    Dim lWis As Long
    Dim lDex As Long
    Dim lCon As Long
    Dim lCHA As Long
    Dim lLUC As Long
    Dim lDAMROLL As Long
    Dim lHITROLL As Long
    Dim lDamageReduction As Long
    Dim lSoul As Long
    Dim lMove As Long
    Dim lGrip As Long
    Dim lMana As Long
    Dim lEssence As Long
    Dim rsLanguages As Recordset
    Dim lLanguages As Long
    Dim zLanguages As String
    Dim lAverageDamage As Long
    Dim lFireElementalDamage As Long
    Dim lColdElementalDamage As Long
    Dim lLightningElementalDamage As Long
    Dim lPoisonElementalDamage As Long
    Dim lNumAttRnd As Long
    Dim bCalcu As Boolean
    Dim lGravityLevel As Long
    Dim lRadiatedAreaLevel As Long
    Dim lHeatAreaLevel As Long
    Dim lGasAreaLevel As Long
    Dim lMoveReductionInertialInhibitor As Long
    Dim lShadowCloakDuration As Long
    Dim lMagicFindBase As Long
    Dim lTreasure  As Long
    Dim lRare As Long
    Dim lIncreasesHPPercent As Long
    Dim lIncreasesACPercent As Long
    Dim lIncreasesHRPercent As Long
    Dim lIncreasesDRPercent As Long
    Dim lGHP As Long
    Dim lGEssence As Long
    Dim lGMana As Long
    Dim lGSoul As Long
    Dim lGMove As Long
    Dim lOStr  As Long
    Dim lOInt  As Long
    Dim lOWIS  As Long
    Dim lODEX  As Long
    Dim lOCON  As Long
    Dim lOCHA  As Long
    Dim lOLuc  As Long
    Dim lLeechingHP As Long
    Dim lLeechingEssence As Long
    Dim lLeechingSoul As Long
    Dim lLeechingMana As Long
    Dim lLeechingMove As Long
    Dim lManashieldDuration As Long
    Dim lEssenceshieldDuration As Long
    Dim lSoulshieldDuration As Long
    Dim lBarkskinDuration As Long
    Dim lStoneskinDuration As Long
    Dim lDragonskinDuration As Long
    Dim lDemonskinDuration As Long
    Dim lFireshieldDuration As Long
    Dim lIceshieldDuration As Long
    Dim lChaosshieldDuration As Long
    Dim lStaticshieldDuration As Long
    Dim lImaginaryDuration As Long
    Dim lPortID As Long
    Dim bCheckpoint As Boolean
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
    If (gbllRecalculatedDelay(lPortID) < 0) Then
        Select Case gbllRecalculatedDelay(lPortID)
            Case -2
                gbllRecalculatedDelay(lPortID) = -1 'Ready for next time
                bCheckpoint = True
            Case Else
                gbllRecalculatedDelay(lPortID) = 6
                bCheckpoint = False
        End Select
        
        Select Case bCheckpoint
            Case True
                'Debug.Print "gbllRecalculatedDelay(lPortID) " & gbllRecalculatedDelay(lPortID)
                lLeechingHP = 0
                lLeechingEssence = 0
                lLeechingSoul = 0
                lLeechingMana = 0
                lLeechingMove = 0
                
                lGHP = 0
                lGEssence = 0
                lGMana = 0
                lGSoul = 0
                lGMove = 0
                
                lRare = 0
                lTreasure = 0
                lShadowCloakDuration = 0
                lPlayerLevel = 0
                lNumAttRnd = 1 'everyone gets one.
                lMagicFind = 0
                lMagicFindBase = 0
                lWeight = 0
                lRegenerationLevel = 0
                lLockPickToolBonus = 0
                lSlayChance = 0
                lIASChance = 0
                lAC = 0
                lStr = 0
                lInt = 0
                lWis = 0
                lDex = 0
                lCon = 0
                lCHA = 0
                lLUC = 0
                lDAMROLL = 0
                lHITROLL = 0
                lGrip = 0
                lHP = 0
                lMana = 0
                lSoul = 0
                lEssence = 0
                lMove = 0
                lDamageReduction = 0
                lAverageDamage = 0
                lFireElementalDamage = 0
                lColdElementalDamage = 0
                lPoisonElementalDamage = 0
                lLightningElementalDamage = 0
                lGravityLevel = 0
                lRadiatedAreaLevel = 0
                lHeatAreaLevel = 0
                lGasAreaLevel = 0
                lMoveReductionInertialInhibitor = 0
                lIncreasesHPPercent = 0
                lIncreasesACPercent = 0
                lIncreasesHRPercent = 0
                lIncreasesDRPercent = 0
                lImaginaryDuration = 0
            
                zLanguages = "100000000000000" '0,1 are Common and given here, 2 to 15 are other languages
                'Collect all the language objects and adjust the LanguagesKnow variable an object with languagecell 99 means you speak them all because of that item.
                zSQL = "SELECT tblPlayerEquipmentItems.PlayerID, tblObject.LanguageCell FROM tblObject INNER JOIN tblPlayerEquipmentItems ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lOPlayerID & ") AND ((tblObject.LanguageCell)>0));"
                Set rsLanguages = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                Do While (Not rsLanguages.EOF)
                    lLanguages = MyCLng(rsLanguages!LanguageCell)
                    If (lLanguages < 17) Then
                        zLanguages = Mid(zLanguages, 1, lLanguages - 1) & "1" & Mid(zLanguages, lLanguages + 1)
                    Else
                        zLanguages = "1111111111111111" 'an item has language cell 99 means you speak all languages from that item
                    End If
                    rsLanguages.MoveNext
                Loop
                Set rsLanguages = Nothing
                
                'mounted statusd
                MyDB.Execute "UPDATE tblPlayer SET StatusMounted=" & bPlayerMounted(lOPlayerID) & " WHERE (PlayerID=" & lOPlayerID & ");", dbFailOnError 'StatusMounted
                
                'equipment
                zSQL = "SELECT tblPlayerEquipmentItems.PlayerID, Sum(tblObject.InitativeChance) AS SumOfInitativeChance, Sum(tblObject.GoldDropChance) AS SumOfGoldDropChance, Sum(tblObject.ArmourAbsorbtionChance) AS SumOfArmourAbsorbtionChance, Sum(tblObject.IncreasesHPPercent) AS SumOfIncreasesHPPercent, Sum(tblObject.IncreasesACPercent) AS SumOfIncreasesACPercent, "
                zSQL = zSQL & "Sum(tblObject.IncreasesHRPercent) AS SumOfIncreasesHRPercent, Sum(tblObject.IncreasesDRPercent) AS SumOfIncreasesDRPercent, Sum(tblObject.MoveReductionInertialInhibitor) AS SumOfMoveReductionInertialInhibitor, Sum(tblObject.GravityLevel) AS SumOfGravityLevel, Sum(tblObject.RadiatedAreaLevel) AS SumOfRadiatedAreaLevel, Sum(tblObject.HeatAreaLevel) AS SumOfHeatAreaLevel, "
                zSQL = zSQL & "Sum(tblObject.GasAreaLevel) AS SumOfGasAreaLevel, Sum(tblObject.Weight) AS SumOfWeight, Sum(tblObject.PoisonElementalDamage) AS SumOfPoisonElementalDamage, Sum(tblObject.FireElementalDamage) AS SumOfFireElementalDamage, Sum(tblObject.LightningElementalDamage) AS SumOfLightningElementalDamage, Sum(tblObject.ColdElementalDamage) AS SumOfColdElementalDamage, "
                zSQL = zSQL & "Sum(tblObject.MagicFind) AS SumOfMagicFind, Sum(tblObject.MagicFindBase) AS SumOfMagicFindBase, Sum(tblObject.Rare) AS SumOfRare, Sum(tblObject.Treasure) AS SumOfTreasure, Sum(tblObject.RegenerationLevel) AS SumOfRegenerationLevel, Sum(tblObject.LockPickToolBonus) AS SumOfLockPickToolBonus, "
                zSQL = zSQL & "Sum(tblObject.SlayChance) AS SumOfSlayChance, Sum(tblObject.Grip) AS SumOfGrip, Sum(tblObject.AverageDamage) AS SumOfAverageDamage, Sum(tblObject.STR) AS SumOfSTR, Sum(tblObject.INT) AS SumOfINT, Sum(tblObject.WIS) AS SumOfWIS, Sum(tblObject.DEX) AS SumOfDEX, Sum(tblObject.CON) AS SumOfCON, Sum(tblObject.CHA) AS SumOfCHA, "
                zSQL = zSQL & "Sum(tblObject.LUC) AS SumOfLUC, Sum(tblObject.AC) AS SumOfAC, Sum(tblObject.HP) AS SumOfHP, Sum(tblObject.Essence) AS SumOfEssence, Sum(tblObject.NumAttRnd) AS SumOfNumAttRnd, Sum(tblObject.CHITROLL) AS SumOfCHITROLL, Sum(tblObject.Mana) AS SumOfMana, Sum(tblObject.Soul) AS SumOfSoul, "
                zSQL = zSQL & "Sum(tblObject.Move) AS SumOfMove, Sum(tblObject.IASChance) AS SumOfIASChance, Sum(tblObject.LeechingHP) AS SumOfLeechingHP, Sum(tblObject.LeechingEssence) AS SumOfLeechingEssence, Sum(tblObject.LeechingMove) AS SumOfLeechingMove, Sum(tblObject.LeechingMana) AS SumOfLeechingMana, Sum(tblObject.LeechingSoul) AS SumOfLeechingSoul, "
                zSQL = zSQL & "Sum(tblObject.DamageReduction) As SumOfDamageReduction "
                zSQL = zSQL & "FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID "
                zSQL = zSQL & "WHERE (((tblObject.DurabilityBroken) > 0)) "
                zSQL = zSQL & "GROUP BY tblPlayerEquipmentItems.PlayerID "
                zSQL = zSQL & "HAVING (((tblPlayerEquipmentItems.PlayerID)=" & lOPlayerID & "));"
                
                Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsData.EOF) Then
                    bCalcu = True
                    gbllInitativeChance(lPortID) = MyCLng(rsData!SumOfInitativeChance)
                    gbllGoldDropChance(lPortID) = MyCLng(rsData!SumOfGoldDropChance)
                    gbllArmourAbsorbtionChance(lPortID) = MyCLng(rsData!SumOfArmourAbsorbtionChance)
                    lDamageReduction = lDamageReduction + MyCLng(rsData!SumOfDamageReduction)
                    lTreasure = MyCLng(rsData!SumOfTreasure)
                    lRare = MyCLng(rsData!SumOfRare)
                    lMoveReductionInertialInhibitor = MyCLng(rsData!SumOfMoveReductionInertialInhibitor)
                    lGravityLevel = lGravityLevel + MyCLng(rsData!SumOfGravityLevel)
                    lRadiatedAreaLevel = lRadiatedAreaLevel + MyCLng(rsData!SumOfRadiatedAreaLevel)
                    lHeatAreaLevel = lHeatAreaLevel + MyCLng(rsData!SumOfHeatAreaLevel)
                    lGasAreaLevel = lGasAreaLevel + MyCLng(rsData!SumOfGasAreaLevel)
                    
                    lLeechingHP = lLeechingHP + MyCLng(rsData!SumOfLeechingHP)
                    lLeechingEssence = lLeechingEssence + MyCLng(rsData!SumOfLeechingEssence)
                    lLeechingSoul = lLeechingSoul + MyCLng(rsData!SumOfLeechingSoul)
                    lLeechingMana = lLeechingMana + MyCLng(rsData!SumOfLeechingMana)
                    lLeechingMove = lLeechingMove + MyCLng(rsData!SumOfLeechingMove)
                    
                    lIncreasesHPPercent = MyCLng(rsData!SumOfIncreasesHPPercent)
                    lIncreasesACPercent = MyCLng(rsData!SumOfIncreasesACPercent)
                    lIncreasesHRPercent = MyCLng(rsData!SumOfIncreasesHRPercent)
                    lIncreasesDRPercent = MyCLng(rsData!SumOfIncreasesDRPercent)
                    lHP = lHP + MyCLng(rsData!SumOfHP)
                    lWeight = lWeight + MyCLng(rsData!SumOfWeight)
                    lRegenerationLevel = lRegenerationLevel + MyCLng(rsData!SumOfRegenerationLevel)
                    lLockPickToolBonus = lLockPickToolBonus + MyCLng(rsData!SumOfLockPickToolBonus)
                    lSlayChance = lSlayChance + MyCLng(rsData!SumOfSlayChance)
                    lIASChance = lIASChance + MyCLng(rsData!SumOfIASChance)
                    lNumAttRnd = lNumAttRnd + MyCLng(rsData!SumOfNumAttRnd)
                    lStr = lStr + MyCLng(rsData!SumOfSTR)
                    lInt = lInt + MyCLng(rsData!SumOfINT)
                    lWis = lWis + MyCLng(rsData!SumOfWIS)
                    lDex = lDex + MyCLng(rsData!SumOfDEX)
                    lCon = lCon + MyCLng(rsData!SumOfCON)
                    lCHA = lCHA + MyCLng(rsData!SumOfCHA)
                    lLUC = lLUC + MyCLng(rsData!SumOfLUC)
                    lMagicFind = lMagicFind + MyCLng(rsData!SumOfMagicFind)
                    lMagicFindBase = lMagicFindBase + MyCLng(rsData!SumOfMagicFindBase)
                    lMana = lMana + MyCLng(rsData!SumOfMana)
                    lMove = lMove + MyCLng(rsData!SumOfMove)
                    lSoul = lSoul + MyCLng(rsData!SumOfSoul)
                    lEssence = lEssence + MyCLng(rsData!SumOfEssence)
                    lGrip = lGrip + MyCLng(rsData!SumOfGrip)
                    lAC = lAC + MyCLng(rsData!SumOfAC)
                    lHITROLL = lHITROLL + MyCLng(rsData!SumOfCHITROLL)
                    lAverageDamage = lAverageDamage + MyCLng(rsData!SumOfAverageDamage)
                    lFireElementalDamage = lFireElementalDamage + MyCLng(rsData!SumOfFireElementalDamage)
                    lColdElementalDamage = lColdElementalDamage + MyCLng(rsData!SumOfColdElementalDamage)
                    lLightningElementalDamage = lLightningElementalDamage + MyCLng(rsData!SumOfLightningElementalDamage)
                    lPoisonElementalDamage = lPoisonElementalDamage + MyCLng(rsData!SumOfPoisonElementalDamage)
                End If
                Set rsData = Nothing
                   
                'inventory (just used for weight but we add most parts up)
                zSQL = "SELECT Sum(tblObject.Weight) AS SumOfWeight FROM tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID GROUP BY tblPlayerInventoryItems.PlayerID HAVING (tblPlayerInventoryItems.PlayerID=" & lOPlayerID & ");"
                Set rsDataInv = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsDataInv.EOF) Then
                    bCalcu = True
                    lWeight = lWeight + MyCLng(rsDataInv!SumOfWeight)
                End If
                Set rsDataInv = Nothing
                
                'Clan item
                zSQL = "SELECT tblPlayer.PlayerID, tblPlayerClan.ClanID, tblPlayerClan.HP, tblPlayerClan.AC, tblPlayerClan.STR, tblPlayerClan.INT, tblPlayerClan.WIS, tblPlayerClan.DEX, tblPlayerClan.CON, tblPlayerClan.CHA, tblPlayerClan.LUC, tblPlayerClan.DAMROLL, tblPlayerClan.HITROLL, tblPlayerClan.Grip, tblPlayerClan.Mana, tblPlayerClan.Essence FROM tblPlayer INNER JOIN tblPlayerClan ON tblPlayer.ClanID = tblPlayerClan.ClanID WHERE (((tblPlayer.PlayerID)=" & lOPlayerID & "));"
                Set rsClanItem = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsClanItem.EOF) Then
                    bCalcu = True
                    lHP = lHP + MyCLng(rsClanItem!HP)
                    lAC = lAC + MyCLng(rsClanItem!AC)
                    lStr = lStr + MyCLng(rsClanItem!Str)
                    lInt = lInt + MyCLng(rsClanItem!Int)
                    lWis = lWis + MyCLng(rsClanItem!Wis)
                    lDex = lDex + MyCLng(rsClanItem!Dex)
                    lCon = lCon + MyCLng(rsClanItem!Con)
                    lCHA = lCHA + MyCLng(rsClanItem!Cha)
                    lLUC = lLUC + MyCLng(rsClanItem!Luc)
                    lDAMROLL = lDAMROLL + MyCLng(rsClanItem!DAMROLL)
                    lHITROLL = lHITROLL + MyCLng(rsClanItem!HITROLL)
                    lGrip = lGrip + MyCLng(rsClanItem!Grip)
                    lMana = lMana + MyCLng(rsClanItem!mana)
                    lEssence = lEssence + MyCLng(rsClanItem!essence)
                End If
                Set rsClanItem = Nothing
                
                'Learn Skills
                zSQL = "SELECT * FROM tblPlayerLearn WHERE (TargetID=" & lOPlayerID & " AND LearnStatus=2 AND ActivateCommand>0 AND ActivateDuration>0);"
                Set rsLearnSkills = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsLearnSkills.EOF) Then
                    bCalcu = True
                    Do While (Not rsLearnSkills.EOF)
                        lHP = lHP + MyCLng(rsLearnSkills!HP)
                        lAC = lAC + MyCLng(rsLearnSkills!AC)
                        lStr = lStr + MyCLng(rsLearnSkills!Str)
                        lInt = lInt + MyCLng(rsLearnSkills!Int)
                        lWis = lWis + MyCLng(rsLearnSkills!Wis)
                        lDex = lDex + MyCLng(rsLearnSkills!Dex)
                        lCon = lCon + MyCLng(rsLearnSkills!Con)
                        lCHA = lCHA + MyCLng(rsLearnSkills!Cha)
                        lLUC = lLUC + MyCLng(rsLearnSkills!Luc)
                        lDAMROLL = lDAMROLL + MyCLng(rsLearnSkills!DAMROLL)
                        lHITROLL = lHITROLL + MyCLng(rsLearnSkills!HITROLL)
                        lGrip = lGrip + MyCLng(rsLearnSkills!Grip)
                        lMana = lMana + MyCLng(rsLearnSkills!mana)
                        lEssence = lEssence + MyCLng(rsLearnSkills!essence)
                        rsLearnSkills.MoveNext
                    Loop
                End If
                Set rsLearnSkills = Nothing
                
                zSQL = "SELECT tblPlayerInventoryItems.PlayerID, tblObject.CaptureFlagClanID FROM tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lOPlayerID & ") AND ((tblObject.CaptureFlagClanID)<>0));"
                Set rsCTF = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsCTF.EOF) Then
                    bCalcu = True
                    Do While (Not rsCTF.EOF)
                        lStr = lStr + 3
                        lInt = lInt + 3
                        lWis = lWis + 3
                        lDex = lDex + 3
                        lCon = lCon + 3
                        lCHA = lCHA + 3
                        lLUC = lLUC + 3
                        lMana = lMana + 50
                        lEssence = lEssence + 50
                        lSoul = lSoul + 50
                        rsCTF.MoveNext
                    Loop
                End If
                Set rsCTF = Nothing
                
                bOkay = False
                If (bCalcu) Then 'player table grab
                    Set rsPlayer = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PlayerID=" & lOPlayerID & ");", dbOpenSnapshot)
                    If (Not rsPlayer.EOF) Then
                        bOkay = True
                        zBittenReservedOriginalClass = MyCStr(rsPlayer!BittenReservedOriginalClass)
                        zClass = MyCStr(rsPlayer!Class)
                        If zBittenReservedOriginalClass = "BA" Then lGrip = lGrip + 9
                        If (gbllWITCHLOCKDuration > 0) Then 'there can only be ONE WITCHLOCK AT A TIME! HIGHLANDER MODE!
                            If (gbllWITCHLOCKPlayerID = lOPlayerID) Then
                                zClass = "IO"
                            End If
                        End If
                        zRace = MyCStr(rsPlayer!Race)
                        lOStr = MyCLng(rsPlayer!OSTR)
                        lOInt = MyCLng(rsPlayer!OINT)
                        lOWIS = MyCLng(rsPlayer!OWIS)
                        lODEX = MyCLng(rsPlayer!ODEX)
                        lOCON = MyCLng(rsPlayer!OCON)
                        lOCHA = MyCLng(rsPlayer!OCHA)
                        lOLuc = MyCLng(rsPlayer!OLUC)
                        If (zClass = "IO" Or zRace = "PIX") Then lODEX = lODEX + 20
                        
                        If (zClass = "PL" Or zClass = "VE" Or zClass = "IO") Then 'IO is WitchWarloc MORPH coming soon PL and VE are the same so far everywhere
                            lReturnPetCount = lReturnPlayerPetCount(lOPlayerID)
                            If (zClass = "IO") Then
                                lNumAttRnd = lNumAttRnd + lReturnPetCount
                                If (lNumAttRnd > 8) Then lNumAttRnd = 8
                            Else
                                lNumAttRnd = lNumAttRnd + MyCLng(lReturnPetCount / 2) + 1
                            End If
                            lHITROLL = lHITROLL + (300 * lReturnPetCount) 'pretty much dont miss
                            lOCHA = lOCHA + (lReturnPetCount * 15) '15 charisma a pet
                        End If
                        
                        lGHP = MyCLng(rsPlayer!GHP)
                        lGEssence = MyCLng(rsPlayer!GEssence)
                        lGMana = MyCLng(rsPlayer!GMana)
                        lGSoul = MyCLng(rsPlayer!GSoul)
                        lGMove = MyCLng(rsPlayer!GMove)
                        
                        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            
                        Select Case zClass
                            Case "WA", "GL"
                                lDAMROLL = lDAMROLL + (MyCLng(lPlayerLevel / 50) * 150) + 1
                                lHITROLL = lHITROLL + (MyCLng(lPlayerLevel / 50) * 250) + 1
                        End Select
                        Select Case zClass
                            Case "WA", "GL", "GY", "AS"
                                lNumAttRnd = lNumAttRnd + 1
                        End Select
                        If (zClass = "TH" Or zClass = "GY") Then
                            lMagicFind = lMagicFind + 5 + MyCLng(lPlayerLevel / 5)
                            lMagicFindBase = lMagicFindBase + 5 + MyCLng(lPlayerLevel / 12)
                        End If
                                    
                        Select Case zRace
                            Case "HAL"
                                lDex = lDex + 40
                                lWis = lWis + 5
                                lMove = lMove + 300
                            Case "HUM"
                                lInt = lInt + 33
                                lWis = lWis + 10
                                lMove = lMove + 200
                        End Select
                        Select Case zRace
                            Case "ORC", "TRO", "OGR", "OGR", "DWA", "MIN"
                                lNumAttRnd = lNumAttRnd + 1
                        End Select
                        lNumAttRnd = lNumAttRnd + lTotalPlayerLevelFreeNumAttRnd(lPlayerLevel)
                        
                        lIASChance = lIASChance + lTranslatePlayerRaceClassIAS(zRace, zClass)
                        lStance = MyCLng(rsPlayer!stance)
                        
                        lRegenerationLevel = lRegenerationLevel + lTranslateRegenerationLevelRaceBonus(zRace)
                        
                        lManashieldDuration = MyCLng(rsPlayer!ManashieldDuration)
                        lEssenceshieldDuration = MyCLng(rsPlayer!EssenceshieldDuration)
                        lSoulshieldDuration = MyCLng(rsPlayer!SoulshieldDuration)
                        lBarkskinDuration = MyCLng(rsPlayer!BarkskinDuration)
                        lStoneskinDuration = MyCLng(rsPlayer!StoneskinDuration)
                        lDragonskinDuration = MyCLng(rsPlayer!DragonskinDuration)
                        lDemonskinDuration = MyCLng(rsPlayer!DemonskinDuration)
                        lFireshieldDuration = MyCLng(rsPlayer!FireshieldDuration)
                        lIceshieldDuration = MyCLng(rsPlayer!IceshieldDuration)
                        lChaosshieldDuration = MyCLng(rsPlayer!ChaosshieldDuration)
                        lStaticshieldDuration = MyCLng(rsPlayer!StaticshieldDuration)
                        lImaginaryDuration = MyCLng(rsPlayer!ImaginaryDuration) 'gives the player imaginationary stat bowl
                        If (lImaginaryDuration > 0) Then
                            lGHP = lGHP + 800
                            lGEssence = lGEssence + 800
                            lGMana = lGMana + 800
                            lGSoul = lGSoul + 800
                            lGMove = lGMove + 800
                        End If
                        
                        If (MyCLng(rsPlayer!ShadowCloakDuration) > 0) Then lIASChance = lIASChance + MyCLng(lPlayerLevel / 4)
                        If (MyCLng(rsPlayer!STRDuration) > 1) Then lStr = lStr + MyCLng(rsPlayer!STRStrength)
                        If (MyCLng(rsPlayer!INTDuration) > 1) Then lInt = lInt + MyCLng(rsPlayer!INTStrength)
                        If (MyCLng(rsPlayer!WISDuration) > 1) Then lWis = lWis + MyCLng(rsPlayer!WISStrength)
                        If (MyCLng(rsPlayer!DEXDuration) > 1) Then lDex = lDex + MyCLng(rsPlayer!DEXStrength)
                        If (MyCLng(rsPlayer!CONDuration) > 1) Then lCon = lCon + MyCLng(rsPlayer!CONStrength)
                        If (MyCLng(rsPlayer!CHADuration) > 1) Then lCHA = lCHA + MyCLng(rsPlayer!CHAStrength)
                        If (MyCLng(rsPlayer!LUCDuration) > 1) Then lLUC = lLUC + MyCLng(rsPlayer!LUCStrength)
                        If (MyCLng(rsPlayer!BLESSDuration) > 1) Then lHITROLL = lHITROLL + MyCLng(rsPlayer!BLESSStrength)
                        
                        Select Case zRace 'a person's race determins their language
                            Case "DRA"
                                zLanguages = Mid(zLanguages, 1, 1) & "1" & Mid(zLanguages, 3)
                            Case "DWA"
                                zLanguages = Mid(zLanguages, 1, 2) & "1" & Mid(zLanguages, 4)
                            Case "ELF"
                                zLanguages = Mid(zLanguages, 1, 3) & "1" & Mid(zLanguages, 5)
                            Case "FEL"
                                zLanguages = Mid(zLanguages, 1, 14) & "1"
                            Case "GNO"
                                zLanguages = Mid(zLanguages, 1, 4) & "1" & Mid(zLanguages, 6)
                            Case "HAL"
                                zLanguages = Mid(zLanguages, 1, 5) & "1" & Mid(zLanguages, 7)
                            Case "HUM"
                                zLanguages = Mid(zLanguages, 1, 6) & "1" & Mid(zLanguages, 8)
                            Case "MIN"
                                zLanguages = Mid(zLanguages, 1, 7) & "1" & Mid(zLanguages, 9)
                            Case "OGR"
                                zLanguages = Mid(zLanguages, 1, 8) & "1" & Mid(zLanguages, 10)
                            Case "ORC"
                                zLanguages = Mid(zLanguages, 1, 9) & "1" & Mid(zLanguages, 11)
                            Case "PIX"
                                zLanguages = Mid(zLanguages, 1, 10) & "1" & Mid(zLanguages, 12)
                            Case "TRO"
                                zLanguages = Mid(zLanguages, 1, 11) & "1" & Mid(zLanguages, 13)
                            Case "UND"
                                zLanguages = Mid(zLanguages, 1, 12) & "1" & Mid(zLanguages, 14)
                            Case "VAM"
                                zLanguages = Mid(zLanguages, 1, 13) & "1" & Mid(zLanguages, 15)
                        End Select
                        'Weapon Skill Levels ie. tblPlayer.WeaponSkillBackStabClassLevel tblObject.WeaponSkillBackStabClass
                        'WeaponSkillBackStabClass
                        lWeaponSkillBackStabClassLevel = 0
                        zSQL = "SELECT Count(tblObject.WeaponSkillBackStabClass) AS CountOfWeaponSkillBackStabClass FROM tblObject INNER JOIN (tblPlayer INNER JOIN tblPlayerEquipmentItems ON tblPlayer.PlayerID = tblPlayerEquipmentItems.PlayerID) ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID GROUP BY tblPlayer.PlayerID, tblObject.WeaponSkillBackStabClass HAVING (((tblPlayer.PlayerID)=" & lOPlayerID & ") AND ((tblObject.WeaponSkillBackStabClass)='" & zClass & "'));"
                        Set rsItemLevels = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                        If (Not rsItemLevels.EOF) Then
                            lWeaponSkillBackStabClassLevel = MyCLng(rsItemLevels!CountOfWeaponSkillBackStabClass)
                        End If
                        Set rsItemLevels = Nothing
                        
                        'WeaponSkillMissileRangeClass
                        lWeaponSkillMissileRangeClassLevel = 0
                        zSQL = "SELECT Count(tblObject.WeaponSkillMissileRangeClass) AS CountOfWeaponSkillMissileRangeClass FROM tblObject INNER JOIN (tblPlayer INNER JOIN tblPlayerEquipmentItems ON tblPlayer.PlayerID = tblPlayerEquipmentItems.PlayerID) ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID GROUP BY tblPlayer.PlayerID, tblObject.WeaponSkillMissileRangeClass HAVING (((tblPlayer.PlayerID)=" & lOPlayerID & ") AND ((tblObject.WeaponSkillMissileRangeClass)='" & zClass & "'));"
                        'Debug.Print zSQL
                        Set rsItemLevels = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                        If (Not rsItemLevels.EOF) Then
                            lWeaponSkillMissileRangeClassLevel = MyCLng(rsItemLevels!CountOfWeaponSkillMissileRangeClass)
                        End If
                        Set rsItemLevels = Nothing
                        
                        'We use zClass to rank up hr and dr for the class times level
                        lDAMROLL = lDAMROLL + ((lStr + lOStr) * 3) + lDex + lAverageDamage + (lPlayerLevel * lTranslateClassDamRoll(zClass, zRace))
                        lHITROLL = lHITROLL + lStr + lOStr + lDex + (lPlayerLevel * lTranslateClassHitRoll(zClass, zRace))
                        
                        lMagicFind = (lMagicFind + MyCLng(lLUC / 6))
                        
                        'This goes last
                        Select Case lStance
                            Case 1 'Agressive
                                lHITROLL = MyCLng(lHITROLL * 2) + 50
                                lDAMROLL = MyCLng(lDAMROLL * 1.5) + 50
                                lAC = MyCLng(lAC / 3)
                            Case 2 'Defensive
                                lIASChance = lIASChance + (lPlayerLevel / 10) + 10
                                lHITROLL = MyCLng(lHITROLL / 2)
                                lDAMROLL = MyCLng(lDAMROLL / 2)
                                lAC = MyCLng(lAC * 2) + 50
                            Case 3 'Slaying
                                lIASChance = lIASChance + (lPlayerLevel / 10)
                                lSlayChance = lSlayChance + (lPlayerLevel) + 10
                                lHITROLL = lHITROLL * 2
                                lDAMROLL = MyCLng(lDAMROLL / 2)
                                lAC = MyCLng(lAC / 3)
                                lMagicFind = lMagicFind + 5
                            Case 4 'Waterloo
                                lIASChance = lIASChance + (lPlayerLevel)
                                lHITROLL = (lHITROLL * 2) + 100
                                lDAMROLL = MyCLng(lDAMROLL / 2)
                                lAC = (MyCLng(lAC / 3)) + 100
                            Case 5 'Chiotru
                                lSlayChance = lSlayChance + (lPlayerLevel)
                                lHITROLL = lHITROLL * 2
                                lDAMROLL = (MyCLng(lDAMROLL / 2)) + 200
                                lAC = MyCLng(lAC / 3)
                        End Select
            
                        'lMagicFindBase = (lMagicFindBase + lTreasure + (lRare * 2))
                        'lMagicFindBase = (lMagicFindBase)
                        
                        If (lMagicFind < 5) Then lMagicFind = 5
                        If (lMagicFind < lMagicFindBase) Then lMagicFind = lMagicFindBase
                    End If
                    Set rsPlayer = Nothing
                    
                    If (bOkay) Then 'We use SQL to finish - its super fast and efficient for this
                        'Debug.Print lAC & " " & lStance
                        If (lBarkskinDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "BARKS") + lPlayerLevel
                        If (lStoneskinDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "STONE") + lPlayerLevel
                        If (lDragonskinDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "DRAGO") + lPlayerLevel
                        If (lDemonskinDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "DEMON") + lPlayerLevel
                        
                        If (lFireshieldDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "FIRES") + lPlayerLevel
                        If (lIceshieldDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "ICESH") + lPlayerLevel
                        If (lChaosshieldDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "CHAOS") + lPlayerLevel
                        If (lStaticshieldDuration > 0) Then lAC = lAC + lTranslateCastSkinsClassValue(zClass, "STATI") + lPlayerLevel
                                    
                        If (lManashieldDuration > 0) Then lAC = lAC + lPercentBonus(lAC, cstlManashieldDuration, False)
                        If (lEssenceshieldDuration > 0) Then lAC = lAC + lPercentBonus(lAC, cstlEssenceshieldDuration, False)
                        If (lSoulshieldDuration > 0) Then lAC = lAC + lPercentBonus(lAC, cstlSoulshieldDuration, False)
                        If (lIncreasesACPercent > 0) Then lAC = lPercentBonus(lAC + lDex + lODEX + lCon + lOCON + lPlayerLevel, lIncreasesACPercent, True)
                        'Debug.Print lAC & " " & lStance
                        
                        If (lStr + lOStr > cstlMaxAtributes) Then lStr = cstlMaxAtributes - lOStr
                        If (lInt + lOInt > cstlMaxAtributes) Then lInt = cstlMaxAtributes - lOInt
                        If (lWis + lOWIS > cstlMaxAtributes) Then lWis = cstlMaxAtributes - lOWIS
                        If (lDex + lODEX > cstlMaxAtributes) Then lDex = cstlMaxAtributes - lODEX
                        If (lCon + lOCON > cstlMaxAtributes) Then lCon = cstlMaxAtributes - lOCON
                        If (lCHA + lOCHA > cstlMaxAtributes) Then lCHA = cstlMaxAtributes - lOCHA
                        If (lLUC + lOLuc > cstlMaxAtributes) Then lLUC = cstlMaxAtributes - lOLuc
                        
                        zSQL = "UPDATE tblPlayer SET "
                        zSQL = zSQL & "IncreasesHPPercent=" & lIncreasesHPPercent & ", IncreasesACPercent=" & lIncreasesACPercent & ", IncreasesHRPercent=" & lIncreasesHRPercent & ", IncreasesDRPercent=" & lIncreasesDRPercent & ", "
                        zSQL = zSQL & "GravityLevel=" & lGravityLevel & ", RadiatedAreaLevel=" & lRadiatedAreaLevel & ", HeatAreaLevel=" & lHeatAreaLevel & ", GasAreaLevel=" & lGasAreaLevel & ", "
                        zSQL = zSQL & "WeaponSkillBackStabClassLevel=" & lWeaponSkillBackStabClassLevel & ", WeaponSkillMissileRangeClassLevel=" & lWeaponSkillMissileRangeClassLevel & ", "
                        zSQL = zSQL & "LanguagesKnown='" & zLanguages & "', RegenerationLevel=" & lRegenerationLevel & ", LockPickToolBonus=" & lLockPickToolBonus & ", "
                        zSQL = zSQL & "SlayChance=" & lSlayChance & ", IASChance=" & lIASChance & ", Grip=" & lGrip & ", "
                        zSQL = zSQL & "NumAttRnd=" & lNumAttRnd & ", Weight=" & lWeight & ", CHITROLL=" & lPercentBonus(lHITROLL, lIncreasesHRPercent, True) & ", CDAMROLL=" & lPercentBonus(lDAMROLL, lIncreasesDRPercent, True) & ", "
                        zSQL = zSQL & "CSTR=" & (lStr + lOStr) & ", CINT=" & (lInt + lOInt) & ", CWIS=" & (lWis + lOWIS) & ", CDEX=" & (lDex + lODEX) & ", CCON=" & (lCon + lOCON) & ", CCHA=" & (lCHA + lOCHA) & ", CLUC=" & (lLUC + lOLuc) & ", "
                        zSQL = zSQL & "OEssence=" & (lEssence + lGEssence) & ", OMana=" & (lMana + lGMana) & ", OSoul=" & (lSoul + lGSoul) & ", OMove=" & (lMove + lGMove) & ", CAC=" & lAC & ", OHP=" & lPercentBonus(lHP + lGHP, lIncreasesHPPercent, True) & ", "
                        zSQL = zSQL & "LeechingEssence=" & lLeechingEssence & ", LeechingHP=" & lLeechingHP & ", LeechingSoul=" & lLeechingSoul & ", LeechingMana=" & lLeechingMana & ", LeechingMove=" & lLeechingMove & ", "
                        zSQL = zSQL & "PoisonElementalDamage=" & lPoisonElementalDamage & ", FireElementalDamage=" & lFireElementalDamage & ", LightningElementalDamage=" & lLightningElementalDamage & ", ColdElementalDamage=" & lColdElementalDamage & ", MoveReductionInertialInhibitor=" & lMoveReductionInertialInhibitor & ", MagicFindBase=" & lMagicFindBase & ", MagicFind=" & lMagicFind & ", "
                        zSQL = zSQL & "DamageReduction= " & lDamageReduction & " "
                        zSQL = zSQL & "WHERE (PlayerID=" & lOPlayerID & ");"
                        MyDB.Execute zSQL, dbFailOnError
                    End If
                    gbllInitativeChance(lPortID) = gbllInitativeChance(lPortID) + lTranslateInitiativeChance(lStance)
                End If
        End Select
    End If 'gbllRecalculatedDelay (lPortID)
    End If '(lPortID >= cstlMinPort And lPortID <= cstlMaxPort)
    Exit Sub
Err_Check:
    subWriteErrorFile "subRecalculatePlayerEquipment," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCorpseRottingRounds() 'See Also: subSpecialSelfDeletingObject, subMakeCorpse, lDuplicateObject
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim zObjectName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lObjectID As Long
    Dim lObjectPlayerID As Long
    'Countdown corpses and rotting objects
    MyDB.Execute "UPDATE tblObject INNER JOIN tblMobCorpses ON tblObject.ObjectID = tblMobCorpses.ObjectID SET tblObject.RottingRounds = [RottingRounds]-1 WHERE (((tblObject.RottingRounds)>1) AND ((tblObject.Status)<>1));", dbFailOnError
    'Move objects to ground and out of corpse. Corpses dont get an item if the item is on the ground already.
    'Remove rotted corpse and show emote of it turning to dust and blows away
    
    Set rsObject = MyDB.OpenRecordset("SELECT tblObject.Weight, tblObject.ObjectName, tblObject.X, tblObject.Y, tblObject.Z, tblObject.ObjectID, tblObject.PlayerID FROM tblObject INNER JOIN tblMobCorpses ON tblObject.ObjectID = tblMobCorpses.ObjectID WHERE (((tblObject.RottingRounds)=1) AND ((tblObject.Status)<>1));", dbOpenSnapshot)
    Do While (Not rsObject.EOF)
        zObjectName = MyCStr(rsObject!ObjectName)
        lX = MyCLng(rsObject!x)
        lY = MyCLng(rsObject!y)
        lZ = MyCLng(rsObject!z)
        lObjectID = MyCLng(rsObject!ObjectID)
        lObjectPlayerID = MyCLng(rsObject!PlayerID)
        subSendMsgAreaAll gblzFNYEL & zAdverb(zObjectName, 4) & zShortstop(zObjectName) & " dries up and disappears!", lX, lY, lZ
        'Put all the rotting container's objects (if any) to the ground. Update the object to be at this x y z
        MyDB.Execute "UPDATE tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ObjectID SET tblObject.Status = 0, tblObject.X=" & MyCLng(rsObject!x) & ", tblObject.Y=" & MyCLng(rsObject!y) & ", tblObject.Z=" & MyCLng(rsObject!z) & " WHERE (((tblPlayerContainer.ContainerObjectID)=" & lObjectID & "));", dbFailOnError
        'We remove the weight of this corpse from the container the corpse may be in. (this is here just in case you want to allow corpses in containers)
        MyDB.Execute "UPDATE tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ContainerObjectID SET tblObject.WeightMax=[WeightMax]-" & MyCLng(rsObject!Weight) & " WHERE (((tblPlayerContainer.ObjectID)=" & lObjectID & "));", dbFailOnError
        'We remove the container and object link.
        MyDB.Execute "DELETE ContainerObjectID FROM tblPlayerContainer WHERE (ContainerObjectID=" & lObjectID & ");", dbFailOnError
        'We allow players to carry corpses so remove any links to inventory
        MyDB.Execute "DELETE ObjectID FROM tblPlayerEquipmentItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
        'remove link to equipment
        MyDB.Execute "DELETE ObjectID FROM tblPlayerInventoryItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
        If (lObjectPlayerID <> 0) Then 'if this rotting corpse is being carried or is bagged.
            subRecalculatePlayerEquipment lObjectPlayerID, ""
        End If
        MyDB.Execute "DELETE ObjectID FROM tblMobCorpses WHERE ObjectID=" & lObjectID & ";"
        MyDB.Execute "DELETE ObjectID FROM tblObject WHERE ObjectID=" & lObjectID & ";" ''we delete the rotting container
        rsObject.MoveNext
    Loop
    Set rsObject = Nothing
    
    MyDB.Execute "DELETE tblMobCorpses.* FROM tblObject RIGHT JOIN tblMobCorpses ON tblObject.ObjectID = tblMobCorpses.ObjectID WHERE (((tblObject.ObjectID) Is Null));", dbFailOnError 'we clean up dead links - this shouldnt happen since SACRIFICE command and other commands just move container objects to the Morgue for this PROC to clean them up and unload their equipment
    Exit Sub
Err_Check:
    subWriteErrorFile "subCorpseRottingRounds," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subStargateDurations()
On Error GoTo Err_Check
    'this leaves 10 - the system will subtract StargateEnergyCharge < 11 by 1 until StargateEnergyCharge = 1 in which case it resets to 11, StargateEnergyCharge increases if it is > 10
    'these take 2 seconds each to complete
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectStargate ON tblObject.ObjectID = tblObjectStargate.ObjectID SET tblObject.StargateEnergyCharge = [StargateEnergyCharge]-1 WHERE (((tblObject.StargateEnergyCharge)>0 And (tblObject.StargateEnergyCharge)<11) AND ((tblObject.StargateStatus)=1));", dbFailOnError
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectStargate ON tblObject.ObjectID = tblObjectStargate.ObjectID SET tblObject.StargateStatus = 2, tblObject.StargateEnergyCharge = 11 WHERE (((tblObject.StargateStatus)=1) AND ((tblObject.StargateEnergyCharge)=0));", dbFailOnError
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectStargate ON tblObject.ObjectID = tblObjectStargate.ObjectID SET tblObject.StargateEnergyCharge = [StargateEnergyCharge]+1 WHERE (((tblObject.StargateEnergyCharge)>10 And (tblObject.StargateEnergyCharge)<100) AND ((tblObject.StargateStatus)=2));", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subStargateDurations," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
