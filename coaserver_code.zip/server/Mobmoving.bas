Attribute VB_Name = "modMobmoving"
Option Explicit
'mob movement goes here as it can be complicated
Public Sub subRotateTheWorldLessOften()
On Error GoTo Err_Check
'This is where you would reset all the doors, move the mobs.
    Const cstlStockModification = 20
    Dim lMobID As Long
    Dim lDummy As Long
    Dim lReportCountOfPlayerStockID As Long
    Dim lHoldMobID As Long
    Dim lTZ As Long
    Dim rsRandomPlayer As Recordset
    Dim rsRealestate As Recordset
    Dim lColonistsAboard As Long
    Dim lColonistsNumber As Long
    Dim lColonistsPlayerID As Long
    Dim lPlayerCount As Long
    Dim bChanged As Boolean
    Dim zFinishedMsg As String
    Dim lRealestateCount As Long
    Dim rsMobList As Recordset
    Dim rsMob As Recordset
    Dim rsMobPath As Recordset
    Dim lRealestateSSPlayerID As Long
    Dim lMobType As Long
    Dim zMobName As String
    Dim rsArea As Recordset
    Dim rsAreaBlockedPath As Recordset
    Dim rsWhereMob As Recordset
    Dim lWhereMobID As Long
    Dim rsPlayer As Recordset
    Dim iLoc As Integer
    Dim zBlockedExits As String
    Dim rsObject As Recordset
    Dim zObjectName As String
    Dim zSQL As String
    Dim bMobPath As Boolean
    Dim lMvMMobID As Long
    Dim lMobPathRecordCount As Long
    Dim lMobPathRecordCountMAX As Long
    Dim lMobsMoved As Long
    Dim lMobsMovedMAX As Long
    
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMPathX As Long
    Dim lMPathY As Long
    Dim lMPathZ As Long
    
    Dim rsStockMarket As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lPositionFromCenter As Long
    Dim lValue As Long
    Dim lChange As Long
    Dim lChangeSummary As Long
    Dim lStartTimer As Long
    Dim lPlayerStockID As Long
    Dim bChange As Boolean
    Dim zChangeMod As String
    Dim zChangeModPrint As String
    Dim zLagTimerA As String
    Dim zLagTimerB As String
    Dim lSignal As Long
    zLagTimerA = Format(Now(), "mmm dd, yyyy hh:nn:ss") 'lag timer
    
    'If there is a mobile stuck on a player starship we could run the following code - MOB CLEARED FROM STARSHIPS - returned back to the realm - or just respawndelay=2 all mobs now and then works too
    'If (lRandom(99) = 1) Then MyDB.Execute "UPDATE tblMob INNER JOIN tblArea ON (tblMob.Z = tblArea.Z) AND (tblMob.Y = tblArea.Y) AND (tblMob.X = tblArea.X) SET tblMob.RespawnDelay = 2 WHERE (((tblArea.PlayerType)=2));", dbFailOnError
    If (gblbMOBINTELLIGENCEMODE) Then 'new method for speed
        lSignal = 3
    Else
        lSignal = 33
        'subMobPathingFAST bugged with a visual error and oracle moving angles dec 2022 the time to run was just as bad as below so just keep it or keep trying whoever you are TRISKER WORK HERE
    End If
    If (lRandom(lSignal) = 1) Then
    'MOB PATH MOVEMENT and moves only those mobs in the same WhereID as a player.
    Set rsWhereMob = MyDB.OpenRecordset("SELECT tblPlayer.WhereID FROM tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PortID = tblPlayerLoggedIn.PortID GROUP BY tblPlayer.WhereID;", dbOpenSnapshot)
    Do While (Not rsWhereMob.EOF)
        lWhereMobID = rsWhereMob!WhereID
        If (gblbServerSteroid) Then DoEvents 'SUBLOOPSystem-Tick[
        Set rsMobList = MyDB.OpenRecordset("SELECT tblMobPath.MobID FROM (tblArea INNER JOIN tblMobPath ON (tblArea.Z = tblMobPath.Z) AND (tblArea.Y = tblMobPath.Y) AND (tblArea.X = tblMobPath.X)) INNER JOIN tblMob ON tblMobPath.MobID = tblMob.MobID GROUP BY tblArea.WhereID, tblMobPath.MobID, tblMob.RespawnDelay HAVING (((tblArea.WhereID)=" & lWhereMobID & ") AND ((tblMob.RespawnDelay)=0)) ORDER BY tblMobPath.MobID;", dbOpenSnapshot)
        If (Not rsMobList.EOF) Then
            lMobsMoved = 0
            lMobsMovedMAX = 0
            lHoldMobID = 0
            Do While (Not rsMobList.EOF)  'We now have all the mobs that need to be moved
                lMobID = rsMobList!MobID
                If (lMobID <> lHoldMobID) Then
                    lHoldMobID = lMobID
                    Set rsMob = MyDB.OpenRecordset("SELECT MobType, MvMMobID, StreetSweeper, Invisible, Flys, MobName, X, Y, Z, WalkEnterMsg, WalkExitMsg, FlyEnterMsg, FlyExitMsg FROM tblMob WHERE (MobID=" & lMobID & " AND RespawnDelay=0);", dbOpenSnapshot) 'move only alive mobs
                    If (Not rsMob.EOF) Then 'We now get the mob's data, we also have a 33% chance not to move this mob
                        lMobsMovedMAX = lMobsMovedMAX + 1
                        bMobPath = False 'no path found yet
                        zMobName = zShortstop(MyCStr(rsMob!MobName))
                        lMvMMobID = MyCLng(rsMob!MvMMobID)
                        lMX = MyCLng(rsMob!x)
                        lMY = MyCLng(rsMob!y)
                        lMZ = MyCLng(rsMob!z)
                        lMobType = MyCLng(rsMob!MobType)
                        
                        If (MyCInt(rsMob!StreetSweeper) <> 0) Then 'We clean up the city streets
                            Set rsObject = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, RottingRounds, Location, ReturnPlayerID FROM tblObject WHERE (X=" & lMX & " AND Y=" & lMY & " AND Z=" & lMZ & ") AND (Status=0) AND (Burried=No) AND (PlayerID=0) AND (VisibleLevel=0);", dbOpenDynaset)
                            If (Not rsObject.EOF) Then
                                Do While (Not rsObject.EOF)
                                    zObjectName = zShortstop(MyCStr(rsObject!ObjectName))
                                    If (lContainerItemContentTotal(MyCLng(rsObject!ObjectID)) = 0) Then
                                        If (MyCLng(rsObject!Location) = 0 Or MyCLng(rsObject!ReturnPlayerID) <> 0) Then
                                            Select Case lRandom(15) 'street sweeper work emotes - and we dont always want to see him working either.
                                                Case 1
                                                    subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " takes out a rag and polishes " & zAdverb(zObjectName, 2) & zObjectName & "."), lMX, lMY, lMZ
                                                Case 2
                                                    subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " ignores " & zAdverb(zObjectName, 2) & zObjectName & "."), lMX, lMY, lMZ
                                                Case 3
                                                    subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " wipes off some dirt and stops and admires " & zAdverb(zObjectName, 2) & zObjectName & " for a moment."), lMX, lMY, lMZ
                                            End Select
                                        Else
                                            subSendMsgAreaAll gblzFNGRE & (zAdverb(zMobName, 2) & zMobName & " disposes of " & zAdverb(zObjectName, 2) & zObjectName & "."), lMX, lMY, lMZ
                                            rsObject.Delete
                                        End If
                                    Else
                                        subSendMsgAreaAll gblzFBMAG & (zAdverb(zMobName, 2) & zMobName & " notices items in the " & zObjectName & " and leaves it alone."), lMX, lMY, lMZ
                                    End If
                                    rsObject.MoveNext
                                Loop
                            End If
                            Set rsObject = Nothing
                        End If
                                                
                        zSQL = "SELECT tblMobPath.X, tblMobPath.Y, tblMobPath.Z FROM tblMobPath "
                        zSQL = zSQL & "WHERE (((tblMobPath.X)=" & lMX - 1 & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX + 1 & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY - 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY + 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX - 1 & ") AND ((tblMobPath.Y)=" & lMY - 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX + 1 & ") AND ((tblMobPath.Y)=" & lMY + 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX + 1 & ") AND ((tblMobPath.Y)=" & lMY - 1 & ") AND ((tblMobPath.Z)=" & lMZ & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ - 1 & ") AND ((tblMobPath.MobID)=" & lMobID & ")) OR "
                        zSQL = zSQL & "(((tblMobPath.X)=" & lMX & ") AND ((tblMobPath.Y)=" & lMY & ") AND ((tblMobPath.Z)=" & lMZ + 1 & ") AND ((tblMobPath.MobID)=" & lMobID & "));"
                        Set rsMobPath = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                        If (Not rsMobPath.EOF) Then
                            rsMobPath.MoveLast
                            lMobPathRecordCount = rsMobPath.RecordCount
                            lMobPathRecordCountMAX = lMobPathRecordCount
                            rsMobPath.MoveFirst
                            Do While (Not rsMobPath.EOF And Not bMobPath) 'We now have all of this mob's paths, we must choose one or not move this mob
                                lMPathX = MyCLng(rsMobPath!x)
                                lMPathY = MyCLng(rsMobPath!y)
                                lMPathZ = MyCLng(rsMobPath!z)
                                'Debug.Print zMobName
                                If (lRandom(2) = 1 Or lMobPathRecordCount = 1) Then 'we select a valid path for this mob, randomly
                                    If (bAreaMovementAllowedBLOCKEDONLY(lMPathX, lMPathY, lMPathZ, lMX, lMY, lMZ, lMobType)) Then 'We move the mob but we dont want the mob to cut corners so we have to check for blocks. This is like a filter.
                                    
                                        'We show the mob move out of one place to the new location
                                        If (Not bMobActivatlyInCombat(lMobID)) Then
                                            bMobPath = True 'we assume everything will be fine and set to skip this loop
                                            lMobsMoved = lMobsMoved + 1
                                            lTZ = lMZ
                                            If (bOdd(lMPathZ)) Then
                                                'We jump the Z odd layer position.
                                                If (lTZ < lMPathZ) Then
                                                    lTZ = lMPathZ + 1 'skip an area and go down
                                                Else
                                                    lTZ = lMPathZ - 1 'skip an area and go up
                                                End If
                                            Else
                                                lTZ = lMPathZ
                                            End If
                                            'Tasmia leave to the (Someone isnt showing or should it, Tasmia is a thief)
                                            If (MyCInt(rsMob!Flys) = 0) Then
                                                subSendMsgAreaAllDetectInvisibility "&M", 0, _
                                                    "Someone " & MyCStr(rsMob!WalkExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!WalkExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    "", _
                                                    "", _
                                                    lMX, lMY, lMZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                                
                                                subSendMsgAreaAllDetectInvisibility "&M", 0, _
                                                    "Someone " & MyCStr(rsMob!WalkEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!WalkEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    "", _
                                                    "", _
                                                    lMPathX, lMPathY, lTZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                            Else
                                                'subSendMsgAreaAllDISmart "&M", "", "", zMobName, "%s1 leaves to the " & zTranslateMatrixDirection(lTX, lTY, lTZ, lMobHuntX, lMobHuntY, lMobHuntZ, 1), lMobHuntX, lMobHuntY, lMobHuntZ, "", MyCInt(bMobInvisible)
                                                'TRISKER SMART MOVE HERE
                                                subSendMsgAreaAllDetectInvisibility "&M", 0, _
                                                    "Someone " & MyCStr(rsMob!FlyExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!FlyExitMsg) & " to the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 1), _
                                                    "", _
                                                    "", _
                                                    lMX, lMY, lMZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                                subSendMsgAreaAllDetectInvisibility "&M", 0, _
                                                    "Someone " & MyCStr(rsMob!FlyEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    zAdverb(zMobName, 2) & zMobName & " " & MyCStr(rsMob!FlyEnterMsg) & " the " & zTranslateMatrixDirection(lMPathX, lMPathY, lTZ, lMX, lMY, lMZ, 2), _
                                                    "", _
                                                    "", _
                                                    lMPathX, lMPathY, lTZ, (MyCInt(rsMob!Invisible) <> 0), ""
                                            End If
                                            'We now move the mob to this path
                                            MyDB.Execute "UPDATE tblMob SET X=" & lMPathX & ", Y=" & lMPathY & ", Z=" & lTZ & " WHERE (MobID=" & lMobID & ");", dbFailOnError 'We move the mob to the location
                                            
                                            basMobVsTargetSpeak lMobID, lMPathX, lMPathY, lMPathZ
                                            
                                            If (lMvMMobID <> 0 And lRandom(9) = 1) Then subSeeIfAMobThumpsANewDefeatedMobDesc lMobID, lMvMMobID 'Mobs hunt certain mobs
                                        End If
                                    End If
                                End If
                                lMobPathRecordCount = lMobPathRecordCount - 1
                                rsMobPath.MoveNext
                            Loop
                        End If
                        Set rsMobPath = Nothing
                    End If
                    Set rsMob = Nothing
                End If
                rsMobList.MoveNext
            Loop
        End If
        Set rsMobList = Nothing
        rsWhereMob.MoveNext
    Loop
    Set rsWhereMob = Nothing
    End If
    
    zLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
    If Len(zLagTimerA) > 0 And Len(zLagTimerB) > 0 Then
        If (DateDiff("s", zLagTimerA, zLagTimerB) > 2) Then
            subSystemMessageToImmortals "&r(EAR) &RN2a mobpathing completed [" & DateDiff("s", zLagTimerA, zLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1
            If (gblbServerSteroid) Then DoEvents 'SUBLOOPSystem-Tick[
        End If
    End If
    
    If lRandom(10) = 1 Then
    'STOCK MARKET
    lX = 0
    lY = 0
    lZ = 0
    lChangeSummary = 0
    bChange = False
    Set rsStockMarket = MyDB.OpenRecordset("SELECT * FROM tblPlayerStock WHERE (PlayerID=0) ORDER BY Z, X, Y, StockName;", dbOpenDynaset)
    If (Not rsStockMarket.EOF) Then
        Do While (Not rsStockMarket.EOF)
            lPlayerStockID = MyCLng(rsStockMarket!PlayerStockID)
            lReportCountOfPlayerStockID = MyCLng(rsStockMarket!ReportCountOfPlayerStockID)
            lPositionFromCenter = MyCLng(rsStockMarket!PositionFromCenter)
            lValue = MyCLng(rsStockMarket!Value)
            
            lChange = 0
            
            zChangeModPrint = ""
            
            zChangeMod = "1"
            Select Case lRandom(30 + cstlStockModification)
                Case 1
                    lChange = lChange - 1
                    zChangeMod = "A"
                Case 3
                    lChange = lChange - lRandom(2)
                    zChangeMod = "B"
                Case 5
                    lChange = lChange - (2 + lRandom(2))
                    zChangeMod = "C"
                Case 7
                    lChange = lChange - (3 + lRandom(2))
                    zChangeMod = "D"
                Case 24
                    lChange = lChange + 1
                    zChangeMod = "W"
                Case 26
                    lChange = lChange + lRandom(2)
                    zChangeMod = "X"
                Case 28
                    lChange = lChange + (2 + lRandom(2))
                    zChangeMod = "Y"
                Case 30
                    lChange = lChange + (3 + lRandom(2))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            zChangeMod = "2"
            Select Case lRandom(60 + cstlStockModification) 'just to make it juggle a bit more
                Case 1
                    lChange = lChange - 1
                    zChangeMod = "A"
                Case 3
                    lChange = lChange - 2
                    zChangeMod = "B"
                Case 5
                    lChange = lChange - (4 + lRandom(3))
                    zChangeMod = "C"
                Case 56
                    lChange = lChange + 1
                    zChangeMod = "X"
                Case 58
                    lChange = lChange + 2
                    zChangeMod = "Y"
                Case 60
                    lChange = lChange + (4 + lRandom(3))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            zChangeMod = "3"
            Select Case lRandom(80 + cstlStockModification) 'just to make it juggle even a bit more
                Case 10
                    lChange = lChange - lRandom(2)
                    zChangeMod = "A"
                Case 30
                    lChange = lChange - (3 + lRandom(3))
                    zChangeMod = "B"
                Case 78
                    lChange = lChange + lRandom(2)
                    zChangeMod = "Y"
                Case 80
                    lChange = lChange + (3 + lRandom(3))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            zChangeMod = "4"
            Select Case lRandom(90 + cstlStockModification) 'just to make it juggle even a bit more
                Case 10
                    lChange = lChange - lRandom(5)
                    zChangeMod = "A"
                Case 30
                    lChange = lChange - (4 + lRandom(4))
                    zChangeMod = "B"
                Case 88
                    lChange = lChange + lRandom(5)
                    zChangeMod = "Y"
                Case 90
                    lChange = lChange + (4 + lRandom(4))
                    zChangeMod = "Z"
            End Select
            zChangeModPrint = zChangeModPrint & zChangeMod
            
            If (Not bChange) Then
                If (zChangeModPrint <> "1234") Then
                    bChange = True 'this means one of them did change
                End If
            End If
            
            If (lChange <> 0) Then
                lChangeSummary = lChangeSummary + lChange 'this is just a total of changes
                lPositionFromCenter = lPositionFromCenter + lChange
                If (gblConstructorlMode <> 2) Then
                    If (lChange > 0 And lRandom(9) = 1) Then 'add in what the most worn objects are tagged to
                        lDummy = lReturnStockIntelligenceBonus(lReportCountOfPlayerStockID)
                        If (lDummy > 0) Then
                            If (lRandom(3) = 1) Then
                                lDummy = 0
                            Else
                                lDummy = lRandom(3)
                                subSendMsgInfoChannel "&WStock Market NEWS - &G" & MyCStr(rsStockMarket!StockName) & " got a BONUS INDEX of +" & lDummy
                            End If
                        End If
                        lChange = lChange + lDummy
                    End If
                End If
                'We make a record of this index - for a cool gantt chart of its growth
                MyDB.Execute "INSERT INTO tblPlayerStockGantt ( PlayerStockID, Growth, PurchaseValue ) SELECT " & lPlayerStockID & ", " & lChange & ", " & lPositionFromCenter & ";", dbFailOnError
                subStockMarketGanttArchiveCleanUp lPlayerStockID
                
                rsStockMarket.Edit
                rsStockMarket!PositionFromCenter = lPositionFromCenter
                rsStockMarket.Update
            End If
            
            If (lValue + lPositionFromCenter <= 0) Then
                'Company went bankrupt
                'delete all player stocks
                MyDB.Execute "DELETE tblPlayerStock.PlayerStockID FROM tblPlayerStock WHERE (((tblPlayerStock.PlayerStockChildID)=" & MyCLng(rsStockMarket!PlayerStockID) & ") AND ((tblPlayerStock.PlayerID)<>0));", dbFailOnError
                
                'Set the main stock
                rsStockMarket.Edit
                rsStockMarket!Value = MyCLng(rsStockMarket!CreationValueBonus) + 247 + lRandom(250) + lRandom(250) + lRandom(250)
                rsStockMarket!PositionFromCenter = 0
                rsStockMarket!NumberOfBankrupts = MyCLng(rsStockMarket!NumberOfBankrupts) + 1
                rsStockMarket!LastBankruptDateTime = Now()
                rsStockMarket.Update
                subSendMsgInfoChannel "&WStock Market NEWS - &R" & MyCStr(rsStockMarket!StockName) & " went BANKRUPT!!!"
            Else
                If (lRandom(25000) = 1) Then
                    'Company split money to reduce the value being so high, or sometimes to bring it closer to bankrupt in a gamble
                    'double all player stocks
                    MyDB.Execute "UPDATE tblPlayerStock SET tblPlayerStock.Shares = [Shares] * 2 WHERE (((tblPlayerStock.PlayerStockChildID)=" & MyCLng(rsStockMarket!PlayerStockID) & ") AND ((tblPlayerStock.PlayerID)<>0));", dbFailOnError
                    
                    rsStockMarket.Edit
                    rsStockMarket!Value = Abs(lValue + lPositionFromCenter)
                    rsStockMarket!PositionFromCenter = 0
                    rsStockMarket!NumberOFSplits = MyCLng(rsStockMarket!NumberOFSplits) + 1
                    rsStockMarket!LastSplitDateTime = Now()
                    rsStockMarket.Update
                    subSendMsgInfoChannel "&WStock Market NEWS - &G" & MyCStr(rsStockMarket!StockName) & " has SPLIT SHARES!!!"
                Else
                    If (lRandom(50000) = 1) Then 'Instant HOAX the company, this should be rare
                        'Company was a HOAX
                        'delete all player stocks
                        MyDB.Execute "DELETE tblPlayerStock.PlayerStockID FROM tblPlayerStock WHERE (((tblPlayerStock.PlayerStockChildID)=" & MyCLng(rsStockMarket!PlayerStockID) & ") AND ((tblPlayerStock.PlayerID)<>0));", dbFailOnError
                        
                        'Set the main stock
                        rsStockMarket.Edit
                        rsStockMarket!Value = MyCLng(rsStockMarket!CreationValueBonus) + 247 + lRandom(250) + lRandom(250) + lRandom(250)
                        rsStockMarket!PositionFromCenter = 0
                        rsStockMarket!NumberOfFakes = MyCLng(rsStockMarket!NumberOfFakes) + 1
                        rsStockMarket!LastHoaxDateTime = Now()
                        rsStockMarket.Update
                        subSendMsgInfoChannel "&WStock Market NEWS - &R" & MyCStr(rsStockMarket!StockName) & " was a SCAM and was DISOLVED!!!"
                    End If
                End If
            End If
            
            If (lX <> MyCLng(rsStockMarket!x) Or lY <> MyCLng(rsStockMarket!y) Or lZ <> MyCLng(rsStockMarket!z)) Then
                lX = MyCLng(rsStockMarket!x)
                lY = MyCLng(rsStockMarket!y)
                lZ = MyCLng(rsStockMarket!z)
                If (lngSQLRecordCount("SELECT tblPlayer.PlayerID FROM tblPlayer WHERE (((tblPlayer.X)=" & lX & ") AND ((tblPlayer.Y)=" & lY & ") AND ((tblPlayer.Z)=" & lZ & ") AND ((tblPlayer.PortID)<>'0' And (tblPlayer.PortID) Is Not Null));") <> 0) Then
                    'subPlayerStockShow "", lX, lY, lZ, "A", "- END OF DAY"
                    subSendMsgAreaAll "&g--------------------------------------------------------------------------------", lX, lY, lZ
                End If
            End If
            
            If (lChange > 0) Then
                subSendMsgAreaAll "&G" & strForceSize(MyCStr(rsStockMarket!StockName), 45, " ", "A") & "(" & zChangeModPrint & ") " & lChange, lX, lY, lZ
            Else
                If (lChange < 0) Then
                    subSendMsgAreaAll "&a" & strForceSize(MyCStr(rsStockMarket!StockName), 45, " ", "A") & "(" & zChangeModPrint & ") " & lChange, lX, lY, lZ
                Else
                    subSendMsgAreaAll "&g" & strForceSize(MyCStr(rsStockMarket!StockName), 45, " ", "A") & "(" & zChangeModPrint & ") " & lChange, lX, lY, lZ
                End If
            End If
            
            rsStockMarket.MoveNext
        Loop
        
        If (lChangeSummary > 0) Then 'STOCK MARKET
            subSendMsgAreaAll "&G                                             INDEX: " & lChangeSummary, lX, lY, lZ
            If (lChangeSummary > 49) Then
                subSendMsgInfoChannel "&WStock Market NEWS - &YINDEX: " & lChangeSummary & " *CHEER* All Stocks +2% in value!"
                MyDB.Execute "UPDATE tblPlayerStock SET PositionFromCenter = ([PositionFromCenter])+Abs(([PositionFromCenter]*0.02)) WHERE (PlayerID=0);", dbFailOnError
            End If
        Else
            If (lChangeSummary < 0) Then
                subSendMsgAreaAll "&a                                             INDEX: " & lChangeSummary, lX, lY, lZ
                If (lChangeSummary < -49) Then
                    subSendMsgInfoChannel "&WStock Market NEWS - &aINDEX: " & lChangeSummary & " *PaNiC* All Stocks -2% in value!"
                    MyDB.Execute "UPDATE tblPlayerStock SET PositionFromCenter = ([PositionFromCenter])+(-1*([PositionFromCenter]*0.02)) WHERE (PlayerID=0);", dbFailOnError
                End If
            Else
                subSendMsgAreaAll "&g                                             INDEX: Balanced", lX, lY, lZ
                If (Not bChange) Then subSendMsgInfoChannel "&WStock Market NEWS - &aINDEX: *No Change* All stocks simmer in their current investments."
            End If
        End If
    End If
    Set rsStockMarket = Nothing
    End If
    
    'Realestate Market - this can LAG with lots of starships
    If (lRandom(100) = 1) Then
        lRealestateCount = 0
        lRealestateSSPlayerID = 0
        Set rsRealestate = MyDB.OpenRecordset("SELECT PlayerID, ColonistsPlayerID, AreaName, ColonistsAboard, ColonistsNumber FROM tblArea WHERE (ColonistsPlayerID<>0) ORDER BY AreaName;", dbOpenDynaset)
        If (Not rsRealestate.EOF) Then
            Do While (Not rsRealestate.EOF)
                lRealestateCount = lRealestateCount + 1
                bChanged = False
                lRealestateSSPlayerID = MyCLng(rsRealestate!PlayerID) 'starship playerid
                lColonistsPlayerID = MyCLng(rsRealestate!ColonistsPlayerID) 'owner of the colonists
                lColonistsNumber = MyCLng(rsRealestate!ColonistsNumber)
                lColonistsAboard = MyCLng(rsRealestate!ColonistsAboard)
                
                If (lRandom(1000) = 1) Then
                    lChange = 0
                    Select Case lRandom(20)
                        Case 1
                            lChange = 350 + lRandom(150)
                            bChanged = True
                        Case 2
                            lChange = -1 * (350 + lRandom(150))
                            bChanged = True
                    End Select
                    
                    lColonistsNumber = lColonistsNumber + lChange
                    If (lChange > 0) Then
                        subSendMsgInfoChannel "&y" & MyCStr(rsRealestate!AreaName) & " grows " & lChange & " extra colonists!"
                    Else
                        If (lChange <> 0) Then subSendMsgInfoChannel "&RCIVIL UNREST: " & MyCStr(rsRealestate!AreaName) & " looses " & Abs(lChange) & " colonists!"
                    End If
                End If
                
                If (lColonistsNumber > 0) Then
                    If (lRandom(5000) = 1) Then
                        If (lColonistsAboard = 0) Then 'starships are protected unless their aboard amount is zero
                            lPlayerCount = lngSQLRecordCount("SELECT PlayerID, PortID FROM tblPlayer WHERE (Len([PortID])>1);")
                            If (lPlayerCount < 1) Then lPlayerCount = 1
                            
                            Set rsRandomPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lPlayerCount) & " PlayerName, PlayerID, PortID FROM tblPlayer WHERE (PortID IS Not Null AND PortID <> '' AND PortID <> '0');", dbOpenSnapshot)
                            If (Not rsRandomPlayer.EOF) Then
                                If (lRealestateSSPlayerID <> MyCLng(rsRandomPlayer!PlayerID)) Then
                                    If (lColonistsPlayerID <> MyCLng(rsRandomPlayer!PlayerID)) Then
                                        bChanged = True
                                        rsRandomPlayer.MoveLast
                                        lColonistsPlayerID = MyCLng(rsRandomPlayer!PlayerID) 'random player to take over the colonist base
                                        subSendMsgInfoChannel "&ROVERTHROWN! " & MyCStr(rsRealestate!AreaName) & " falls to " & MyCStr(rsRandomPlayer!PlayerName) & "'s rebel colonist force!"
                                        lColonistsNumber = MyCLng(lColonistsNumber / 4)
                                        lColonistsAboard = MyCLng(lColonistsAboard / 4)
                                    Else
                                        subSendMsgInfoChannel "&YPARTY! " & MyCStr(rsRealestate!AreaName) & " throws a party for Systemlord " & MyCStr(rsRandomPlayer!PlayerName) & "!"
                                    End If
                                Else
                                    subSendMsgInfoChannel "&YSTARSHIP PARTY! " & MyCStr(rsRealestate!AreaName) & " throws a party for Systemlord " & MyCStr(rsRandomPlayer!PlayerName) & "!"
                                End If
                            End If
                            Set rsRandomPlayer = Nothing
                        End If
                    End If
                End If
                
                If (bChanged) Then
                    If (lColonistsNumber < 0) Then lColonistsNumber = 0
                    If (lColonistsAboard < 0) Then lColonistsAboard = 0
                    rsRealestate.Edit
                    rsRealestate!ColonistsNumber = lColonistsNumber
                    rsRealestate!ColonistsAboard = lColonistsAboard
                    rsRealestate!ColonistsPlayerID = lColonistsPlayerID
                    rsRealestate.Update
                End If
                rsRealestate.MoveNext
            Loop
        End If
        Set rsRealestate = Nothing
    End If
    
    zLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
    If Len(zLagTimerA) > 0 And Len(zLagTimerB) > 0 Then
        If (DateDiff("s", zLagTimerA, zLagTimerB) > 8) Then subSystemMessageToImmortals "&r(EAR) &RN2a stocks/colonists calculated [" & DateDiff("s", zLagTimerA, zLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1
    End If
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subRotateTheWorldLessOften," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRotateTheWorld() 'see also subRotateTheWorldEverything
On Error GoTo Err_Check
'This is where you would reset all the doors, move the mobs.
    Dim lMobID As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim rsMoveMob As Recordset
    
    Dim rsMobList As Recordset
    Dim rsMob As Recordset
    Dim rsMobPath As Recordset
    
    Dim zMobName As String
    Dim rsArea As Recordset
    Dim rsAreaBlockedPath As Recordset
    Dim rsPlayer As Recordset
    Dim iLoc As Integer
    Dim zBlockedExits As String
    Dim rsObject As Recordset
    Dim zObjectName As String
    Dim zSQL As String
    Dim bMobPath As Boolean
    Dim lMvMMobID As Long
    
    Dim lAreaID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    
    Dim rsAreaBridge As Recordset
    Dim lAreaBridgeID As Long
    
    'Working Visible Version: the below is to see the mob respawn if you want to activate it - it adds to lag a bit.
    'Set rsMoveMob = MyDB.OpenRecordset("SELECT CHITROLLBase, CDAMROLLBase, ShockshieldDuration, PlayerID, X, Y, Z, MHPBonus, MACBonus, CHITROLLBonus, CDAMROLLBonus, MobName, RespawnDelay, StunDuration, RespawnX, RespawnY, RespawnZ, MHP, MAC, MobLevel FROM tblMob WHERE (RespawnDelay>0);", dbOpenDynaset)
    'Do While (Not rsMoveMob.EOF)
    '    zMobName = zShortstop(MyCStr(rsMoveMob!MobName))
    '    rsMoveMob.Edit
    '    rsMoveMob!RespawnDelay = MyCLng(rsMoveMob!RespawnDelay) - 1 'Now subtract 1 from RespawnDelay on all dead mobs.
    '    'Set the X Y Z to Respawn X Y Z when the RespawnDelay is on its last go.
    '    If (MyCLng(rsMoveMob!RespawnDelay) = 0) Then
    '        rsMoveMob!CHITROLLBase = (MyCLng(rsMoveMob!MobLevel) * cstMobHRRespawn) + MyCLng(rsMoveMob!CHITROLLBonus)
    '        rsMoveMob!CDAMROLLBase = (MyCLng(rsMoveMob!MobLevel) * cstMobDRRespawn) + MyCLng(rsMoveMob!CDAMROLLBonus)
    '        rsMoveMob!MHP = (MyCLng(rsMoveMob!MobLevel) * cstMobHPRespawn) + MyCLng(rsMoveMob!MHPBonus)
    '        rsMoveMob!Mac = (MyCLng(rsMoveMob!MobLevel) * cstMobACRespawn) + MyCLng(rsMoveMob!MACBonus)
    '        rsMoveMob!PlayerID = 0
    '        rsMoveMob!StunDuration = 0
    '        rsMoveMob!X = MyCLng(rsMoveMob!RespawnX)
    '        rsMoveMob!Y = MyCLng(rsMoveMob!RespawnY)
    '        rsMoveMob!Z = MyCLng(rsMoveMob!RespawnZ)
    '        rsMoveMob!ShockshieldDuration = 0
    '        subSendMsgAreaAll "&BThere is a flash of light as " & zMobName & " appears before you!", MyCLng(rsMoveMob!RespawnX), MyCLng(rsMoveMob!RespawnY), MyCLng(rsMoveMob!RespawnZ)
    '    End If
    '    rsMoveMob.Update
    '    rsMoveMob.MoveNext
    'Loop
    'Set rsMoveMob = nothing
    
    'RESET CHEST LOCATIONS
    If (lRandom(675) = 1) Then
        If (lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (ThiefChestOfGlory=0);") > 0) Then
            MyDB.Execute "UPDATE tblArea SET ThiefMobID=0, ThiefChestOfGlory=0;", dbFailOnError
            subSendMsgInfoChannel "&wAll the Thieves pack up their chests and leave the realm."
        End If
    End If
    
    'DOOR LEVER DURATIONS:
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, ResetDuration, Status, DoorID FROM tblDoorLever WHERE ResetDuration > 0;", dbOpenDynaset)
    Do While (Not rsPlayer.EOF)
        rsPlayer.Edit
        If (MyCLng(rsPlayer!ResetDuration) > 0) Then
            rsPlayer!ResetDuration = MyCLng(rsPlayer!ResetDuration) - 1
            If (MyCLng(rsPlayer!ResetDuration) = 0) Then
                rsPlayer!Status = 0 'Reset lever
                'Since the lever got reset it only takes one lever to be out of order for a open door so now we lock the door automatically.
                MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 2, tblDoor.ResetTimer = 0 WHERE (((tblDoor.DoorID)=" & MyCLng(rsPlayer!DoorID) & "));", dbFailOnError
                subSendMsgAreaAll "&yYou hear chains running through the walls a moment before it stopped.", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z)
            End If
        End If
        rsPlayer.Update
        rsPlayer.MoveNext
    Loop
    Set rsPlayer = Nothing
    
    'Some doors you can Pick and/or Key unlock, or bashable (magic can open bashable doors too)
    'Resets Doors back to locked and/or closed!
    'We set the value 1 or 3 becomes 2
    MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 2 WHERE (((tblDoor.ResetTimer)=1) AND ((tblDoor.Status)=1 Or (tblDoor.Status)=3));", dbFailOnError
    'We set the value 0 becomes 6 - always open gets closed
    MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 6 WHERE (((tblDoor.ResetTimer)=1) AND ((tblDoor.Status)=0));", dbFailOnError
    'We set the value 8 becomes 4
    MyDB.Execute "UPDATE tblDoor SET tblDoor.Status = 4 WHERE (((tblDoor.ResetTimer)=1) AND ((tblDoor.Status)=8));", dbFailOnError
    'We set the bashed value 5 (bashed open), 7 (bashed closed) becomes 8 (bashable)
    MyDB.Execute "UPDATE tblDoor SET BashDoorTries=0, Status=8 WHERE ((ResetTimer=1) AND (Status=5 OR Status=7));"
    'magically sealed doors
    MyDB.Execute "UPDATE tblDoor SET MagicDoorTries=0, Status=12 WHERE ((ResetTimer=1) AND (Status=10 OR Status=11));"
    'Now subtract 1 from ResetTimer on all open doors to finish up the reset on them
    MyDB.Execute "UPDATE tblDoor SET tblDoor.ResetTimer = [tblDoor].[ResetTimer]-1 WHERE (((tblDoor.ResetTimer)>0));", dbFailOnError
    'Reset Draw Bridges - Move Players and Mobs to the Trigger location - objects can stay in no mans land
    Set rsAreaBridge = MyDB.OpenRecordset("SELECT * FROM tblAreaBridge WHERE AreaBridgeTimer=1;", dbOpenSnapshot)
    If (Not rsAreaBridge.EOF) Then
        Do While (Not rsAreaBridge.EOF)
            lAreaBridgeID = MyCLng(rsAreaBridge!AreaBridgeID)
            lAreaID = MyCLng(rsAreaBridge!AreaID)
            lX = MyCLng(rsAreaBridge!AreaBridgeTriggerX)
            lY = MyCLng(rsAreaBridge!AreaBridgeTriggerY)
            lZ = MyCLng(rsAreaBridge!AreaBridgeTriggerZ)
            lTX = MyCLng(rsAreaBridge!AreaBridgeDX)
            lTY = MyCLng(rsAreaBridge!AreaBridgeDY)
            lTZ = MyCLng(rsAreaBridge!AreaBridgeDZ)
            lOX = MyCLng(rsAreaBridge!AreaBridgeOX)
            lOY = MyCLng(rsAreaBridge!AreaBridgeOY)
            lOZ = MyCLng(rsAreaBridge!AreaBridgeOZ)
            
            'Move all the players, and mobs, not objects off the moving bridge
            MyDB.Execute "UPDATE tblPlayer SET X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ";", dbFailOnError
            MyDB.Execute "UPDATE tblMob SET X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ";", dbFailOnError
            'Reset the timer for the bridge
            MyDB.Execute "UPDATE tblArea SET X=" & lOX & ", Y=" & lOY & ", Z=" & lOZ & " WHERE AreaID=" & lAreaID & ";", dbFailOnError
            MyDB.Execute "UPDATE tblAreaBridge SET AreaBridgeTimer=0 WHERE AreaBridgeID=" & lAreaBridgeID & ";", dbFailOnError
            rsAreaBridge.MoveNext
        Loop
    End If
    Set rsAreaBridge = Nothing
    MyDB.Execute "UPDATE tblAreaBridge SET AreaBridgeTimer=[AreaBridgeTimer]-1 WHERE (AreaBridgeTimer>1);"
    
    'Reset all areas that have tblArea traps - ie. Underwater
    MyDB.Execute "UPDATE tblArea SET Underwater=UnderwaterOriginal WHERE UnderwaterDuration=1;", dbFailOnError
    MyDB.Execute "UPDATE tblArea SET UnderwaterDuration=UnderwaterDuration-1 WHERE UnderwaterDuration>0;", dbFailOnError
    
    'Reset all search areas RBCBlocked ExitBlocked
    Set rsArea = MyDB.OpenRecordset("SELECT * FROM tblAreaBlockedPath WHERE Used=True;", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        Do While (Not rsArea.EOF)
            lAreaID = 0
            lX = MyCLng(rsArea!x)
            lY = MyCLng(rsArea!y)
            lZ = MyCLng(rsArea!z)
            Set rsAreaBlockedPath = MyDB.OpenRecordset("SELECT Exits, AreaID, BlockedExits FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
            If (Not rsAreaBlockedPath.EOF) Then
                lAreaID = MyCLng(rsAreaBlockedPath!AreaID)
                zBlockedExits = MyCStr(rsAreaBlockedPath!BlockedExits)
                iLoc = iDirectionSwitchCode(MyCStr(rsArea!AreaRBDir))
                If (iLoc > 0) Then MyDB.Execute "UPDATE tblArea SET BlockedExits='" & (Mid(zBlockedExits, 1, iLoc - 1) & "1" & Mid(zBlockedExits, iLoc + 1)) & "' WHERE (AreaID=" & lAreaID & ");", dbFailOnError 'rsAreaBlockedPath!BlockedExits = Mid(zBlockedExits, 1, iLoc - 1) & "1" & Mid(zBlockedExits, iLoc + 1) 'Put the block back up
            End If
            Set rsAreaBlockedPath = Nothing
            
            If (lAreaID <> 0) Then
                MyDB.Execute "UPDATE tblArea SET Exits='" & zShowExits(lX, lY, lZ) & "' WHERE (AreaID=" & lAreaID & ");", dbFailOnError
            End If
            
            rsArea.MoveNext
        Loop
        MyDB.Execute "UPDATE tblAreaBlockedPath SET Used=False;", dbFailOnError
    End If
    Set rsArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subRotateTheWorld," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subRotateTheWorldEverything()
On Error Resume Next
    'Rotate the world
    DoEvents
    subRotateTheWorld
    subRotateAreaTransit
    subRotateObjectTransit
    subRotateMobSpeak 0, 0, 0, False
    subRotateObjectContainerRespawn
    subAddMenToColonizies
    gbllSystemTick = 0
    frmTelnetServerEngine!lblMsg.Caption = "world rotated"
End Sub

Public Sub subMissileFlight() 'See also: zTranslatePlayerType()
On Error GoTo Err_Check
    Dim bMaxMissilesAllowed As Boolean
    Dim rsScan As Recordset
    Dim i As Long
    Dim lCell As Long
    Dim lDistance As Long
    Dim lRanVal As Long
    
    'this will also pick our own starship up which is good
    If (lRandom(999999) = 1) Then
        lCell = -1
        'find a missile cell available
        If (lRandom(99) = 1) Then
            i = -1
            Do While (i < cstlMaxMissilesAllowed And lCell = -1)
                i = i + 1
                If (gbltNukeMissile(i).lFuel = 0) Then
                    lCell = i
                End If
            Loop
        End If
        
        If (lCell <> -1) Then
            gbltNukeMissile(lCell).lFuel = 0 '0 means the rocket is dead not active
            gbltNukeMissile(lCell).zCName = ""
            gbltNukeMissile(lCell).zDName = ""
            gbltNukeMissile(lCell).lDX = 0
            gbltNukeMissile(lCell).lDY = 0
            gbltNukeMissile(lCell).lDZ = 0
            
            'Attacker
            lRanVal = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (PlayerType=4 AND ColonistAllowed=True);")
            bMaxMissilesAllowed = False
            Set rsScan = MyDB.OpenRecordset("SELECT TOP " & lRandom(lRanVal) & " AreaName, X, Y, Z FROM tblArea WHERE (PlayerType=4 AND ColonistAllowed=True);", dbOpenSnapshot) 'military bases
            If (Not rsScan.EOF) Then 'this is the ship that caused the signature, the main ship
                rsScan.MoveLast
                bMaxMissilesAllowed = True
                gbltNukeMissile(lCell).zCName = MyCStr(rsScan!AreaName)
                gbltNukeMissile(lCell).lCX = MyCLng(rsScan!x)
                gbltNukeMissile(lCell).lCY = MyCLng(rsScan!y)
                gbltNukeMissile(lCell).lCZ = MyCLng(rsScan!z)
                gbltNukeMissile(lCell).lRadius = lRandom(100) + 40
                gbltNukeMissile(lCell).lDamage = lRandom(100) + 40
            End If
            Set rsScan = Nothing
            
            If (bMaxMissilesAllowed) Then
                'Defender and Destination of missile
                lRanVal = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (PlayerType>2 AND ColonistAllowed=True);")
                
                Set rsScan = MyDB.OpenRecordset("SELECT TOP " & lRandom(lRanVal) & " AreaName, X, Y, Z FROM tblArea WHERE (PlayerType>2 AND ColonistAllowed=True);", dbOpenSnapshot)  'player and all colony bases even other military bases - we dont care if the missile might run out of fuel
                If (Not rsScan.EOF) Then 'this is the ship that caused the signature, the main ship
                    rsScan.MoveLast
                    gbltNukeMissile(lCell).zDName = MyCStr(rsScan!AreaName)
                    gbltNukeMissile(lCell).lFuel = lRandom(401) + 99 'its possible there isnt enough fuel, a range failure
                    gbltNukeMissile(lCell).lDX = MyCLng(rsScan!x)
                    gbltNukeMissile(lCell).lDY = MyCLng(rsScan!y)
                    gbltNukeMissile(lCell).lDZ = MyCLng(rsScan!z)
                    subSendMsgInfoChannel "&YNuclear Missile &R-=&rLAUNCHED&R=- &a[from] &w[" & gbltNukeMissile(lCell).zCName & "]"
                End If
                Set rsScan = Nothing
            End If
        End If
    End If
    
    'Tracking missiles
    lCell = -1
    Do While (lCell < cstlMaxMissilesAllowed)
        lCell = lCell + 1
        If (gbltNukeMissile(lCell).lFuel <> 0) Then 'alive missile?
            gbltNukeMissile(lCell).lFuel = gbltNukeMissile(lCell).lFuel - lRandom(4)
            If (gbltNukeMissile(lCell).lCX < gbltNukeMissile(lCell).lDX) Then
                gbltNukeMissile(lCell).lCX = gbltNukeMissile(lCell).lCX + 1
            End If
            If (gbltNukeMissile(lCell).lCX > gbltNukeMissile(lCell).lDX) Then
                gbltNukeMissile(lCell).lCX = gbltNukeMissile(lCell).lCX - 1
            End If
            If (gbltNukeMissile(lCell).lCY < gbltNukeMissile(lCell).lDY) Then
                gbltNukeMissile(lCell).lCY = gbltNukeMissile(lCell).lCY + 1
            End If
            If (gbltNukeMissile(lCell).lCY > gbltNukeMissile(lCell).lDY) Then
                gbltNukeMissile(lCell).lCY = gbltNukeMissile(lCell).lCY - 1
            End If
            If (gbltNukeMissile(lCell).lCZ < gbltNukeMissile(lCell).lDZ) Then
                gbltNukeMissile(lCell).lCZ = gbltNukeMissile(lCell).lCZ + 1
            End If
            If (gbltNukeMissile(lCell).lCZ > gbltNukeMissile(lCell).lDZ) Then
                gbltNukeMissile(lCell).lCZ = gbltNukeMissile(lCell).lCZ - 1
            End If
            lDistance = (Abs(gbltNukeMissile(lCell).lCX - gbltNukeMissile(lCell).lDX) + Abs(gbltNukeMissile(lCell).lCY - gbltNukeMissile(lCell).lDY) + Abs(gbltNukeMissile(lCell).lCZ - gbltNukeMissile(lCell).lDZ))
            If (lRandom(20) = 1 Or lDistance < 29) Then 'report movement of the missile
                subSendMsgInfoChannel "&wNuclear Missile &a{" & gbltNukeMissile(lCell).zCName & "} &a[x" & gbltNukeMissile(lCell).lCX & " y" & gbltNukeMissile(lCell).lCY & " z" & gbltNukeMissile(lCell).lCZ & "] &R[&atracking&R &yd[" & lDistance & "]&R] &a[" & gbltNukeMissile(lCell).zDName & "]"
            End If
            If (lRandom(999) = 1 Or lDistance < 13 Or gbltNukeMissile(lCell).lFuel < 13) Then 'report movement of the missile, lFuel < 13 is a must as we subtrack up to 4 at a time
                gbltNukeMissile(lCell).lFuel = 0
                subSendMsgInfoChannel "&wNuclear Missile &a{" & gbltNukeMissile(lCell).zCName & "} &a[x" & gbltNukeMissile(lCell).lCX & " y" & gbltNukeMissile(lCell).lCY & " z" & gbltNukeMissile(lCell).lCZ & "] &R[&aexplodes&R &yd[" & lDistance & "]&R] &a[" & gbltNukeMissile(lCell).zDName & "]"
                gbltNukeMissile(lCell).zCName = ""
                gbltNukeMissile(lCell).zDName = ""
                'we would do the nuclear radioactivity to playerships for healing
                'areas would have half colonies there in the area off effect of the radius
            End If
        End If
    Loop
    Exit Sub
Err_Check:
    subWriteErrorFile "subMissileFlight," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
