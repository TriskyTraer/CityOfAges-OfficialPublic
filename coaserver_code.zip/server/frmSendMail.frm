VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form frmSendMail 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Send Message to all Players"
   ClientHeight    =   6330
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   9285
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   9.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmSendMail.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6330
   ScaleWidth      =   9285
   StartUpPosition =   2  'CenterScreen
   Begin VB.ListBox lstSentMail 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   6120
      Left            =   5760
      TabIndex        =   20
      TabStop         =   0   'False
      Top             =   120
      Width           =   3495
   End
   Begin VB.TextBox txtToFullName 
      Height          =   330
      Left            =   2520
      TabIndex        =   2
      Top             =   960
      Width           =   3135
   End
   Begin VB.CommandButton cmdSTOP 
      Caption         =   "Stop!"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   14.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   495
      Left            =   120
      TabIndex        =   6
      Top             =   5760
      Visible         =   0   'False
      Width           =   855
   End
   Begin MSComDlg.CommonDialog cmdDialog 
      Left            =   120
      Top             =   120
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton cmdSelect 
      Caption         =   "..."
      BeginProperty Font 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   18
      Top             =   1560
      Visible         =   0   'False
      Width           =   375
   End
   Begin RichTextLib.RichTextBox rtfAttach 
      Height          =   495
      Left            =   1080
      TabIndex        =   17
      Top             =   5760
      Visible         =   0   'False
      Width           =   1695
      _ExtentX        =   2990
      _ExtentY        =   873
      _Version        =   393217
      Appearance      =   0
      TextRTF         =   $"frmSendMail.frx":0442
   End
   Begin VB.CommandButton cmdSend 
      Caption         =   "Send"
      Height          =   495
      Left            =   2880
      TabIndex        =   7
      Top             =   5760
      Width           =   1455
   End
   Begin VB.CommandButton cmdClose 
      Caption         =   "Close"
      Height          =   495
      Left            =   4560
      TabIndex        =   8
      Top             =   5760
      Width           =   975
   End
   Begin MSWinsockLib.Winsock ctlMailServer 
      Left            =   120
      Top             =   1080
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin VB.TextBox txtBody 
      Height          =   2655
      Left            =   120
      MultiLine       =   -1  'True
      TabIndex        =   5
      Top             =   2400
      Width           =   5535
   End
   Begin VB.TextBox txtAttach 
      Height          =   285
      Left            =   120
      TabIndex        =   13
      Top             =   1560
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.TextBox txtSubject 
      Height          =   285
      Left            =   2520
      TabIndex        =   4
      Text            =   "NOTIFICATION: City of Ages"
      Top             =   1680
      Width           =   3135
   End
   Begin VB.TextBox txtToAddress 
      Height          =   285
      Left            =   2520
      TabIndex        =   3
      Text            =   "trisker@powersurfr.com"
      Top             =   1320
      Width           =   3135
   End
   Begin VB.TextBox txtFromAddress 
      Height          =   285
      Left            =   2520
      TabIndex        =   1
      Text            =   "trisker@powersurfr.com"
      Top             =   600
      Width           =   3135
   End
   Begin VB.TextBox txtServer 
      Height          =   285
      Left            =   2520
      TabIndex        =   0
      Text            =   "smtp.powersurfr.com"
      Top             =   240
      Width           =   3135
   End
   Begin VB.TextBox txtOutput 
      Height          =   495
      Left            =   1080
      TabIndex        =   19
      Top             =   5760
      Visible         =   0   'False
      Width           =   1695
   End
   Begin VB.Label lblStatus 
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Status:"
      Height          =   375
      Left            =   120
      TabIndex        =   16
      Top             =   5160
      Width           =   5505
   End
   Begin VB.Label lblBody 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      Caption         =   "Message"
      Height          =   360
      Left            =   90
      TabIndex        =   15
      Top             =   2040
      Width           =   5505
   End
   Begin VB.Label lblAttach 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Attachment file name:"
      Height          =   240
      Left            =   120
      TabIndex        =   14
      Top             =   1560
      Visible         =   0   'False
      Width           =   705
   End
   Begin VB.Label lblSubject 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "Subject:"
      Height          =   240
      Left            =   720
      TabIndex        =   12
      Top             =   1680
      Width           =   1680
   End
   Begin VB.Label lblToAddress 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "To Address:"
      Height          =   240
      Left            =   765
      TabIndex        =   11
      Top             =   1320
      Width           =   1650
   End
   Begin VB.Label lblFrom 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "From Address:"
      Height          =   240
      Left            =   840
      TabIndex        =   10
      Top             =   600
      Width           =   1530
   End
   Begin VB.Label lblServer 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      Caption         =   "SMTP/POP Server:"
      Height          =   240
      Left            =   405
      TabIndex        =   9
      Top             =   240
      Width           =   2040
   End
End
Attribute VB_Name = "frmSendMail"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public Function Base64Encode(strOriginal As String)
' Base64Encode(strOriginal)
' Base64Encode("the") would return "dGjl"
' You can only pass three letters as the arguement
On Error GoTo Err_Check
    Dim intCount As Integer
    Dim strBinary As String
    Dim intDecimal As Integer
    Dim strTemp As String
    
    intDecimal = Asc(Left$(strOriginal, 1))
    
    For intCount = 7 To 0 Step -1
        If (2 ^ intCount) <= intDecimal Then
            strBinary = strBinary & "1"
            intDecimal = intDecimal - (2 ^ intCount)
        Else
            strBinary = strBinary & "0"
        End If
    Next
    
    If Len(strOriginal) < 3 Then GoTo unfpassone
    
    intDecimal = Asc(Mid$(strOriginal, 2, 1))
    
    For intCount = 7 To 0 Step -1
        If (2 ^ intCount) <= intDecimal Then
            strBinary = strBinary & "1"
            intDecimal = intDecimal - (2 ^ intCount)
        Else
            strBinary = strBinary & "0"
        End If
    Next
    
    If Len(strOriginal) < 3 Then GoTo unfpassone
    
    intDecimal = Asc(Right$(strOriginal, 1))
    
    For intCount = 7 To 0 Step -1
        If (2 ^ intCount) <= intDecimal Then
            strBinary = strBinary & "1"
            intDecimal = intDecimal - (2 ^ intCount)
        Else
            strBinary = strBinary & "0"
        End If
    Next
    
unfpassone:
    For intCount = 1 To 19 Step 6
        Select Case Val(Mid$(strBinary, intCount, 6))
            Case 0
                strTemp = strTemp & "A"
            Case 1
                strTemp = strTemp & "B"
            Case 10
                strTemp = strTemp & "C"
            Case 11
                strTemp = strTemp & "D"
            Case 100
                strTemp = strTemp & "E"
            Case 101
                strTemp = strTemp & "F"
            Case 110
                strTemp = strTemp & "G"
            Case 111
                strTemp = strTemp & "H"
            Case 1000
                strTemp = strTemp & "I"
            Case 1001
                strTemp = strTemp & "J"
            Case 1010
                strTemp = strTemp & "K"
            Case 1011
                strTemp = strTemp & "L"
            Case 1100
                strTemp = strTemp & "M"
            Case 1101
                strTemp = strTemp & "N"
            Case 1110
                strTemp = strTemp & "O"
            Case 1111
                strTemp = strTemp & "P"
            Case 10000
                strTemp = strTemp & "Q"
            Case 10001
                strTemp = strTemp & "R"
            Case 10010
                strTemp = strTemp & "S"
            Case 10011
                strTemp = strTemp & "T"
            Case 10100
                strTemp = strTemp & "U"
            Case 10101
                strTemp = strTemp & "V"
            Case 10110
                strTemp = strTemp & "W"
            Case 10111
                strTemp = strTemp & "X"
            Case 11000
                strTemp = strTemp & "Y"
            Case 11001
                strTemp = strTemp & "Z"
            Case 11010
                strTemp = strTemp & "a"
            Case 11011
                strTemp = strTemp & "b"
            Case 11100
                strTemp = strTemp & "c"
            Case 11101
                strTemp = strTemp & "d"
            Case 11110
                strTemp = strTemp & "e"
            Case 11111
                strTemp = strTemp & "f"
            Case 100000
                strTemp = strTemp & "g"
            Case 100001
                strTemp = strTemp & "h"
            Case 100010
                strTemp = strTemp & "i"
            Case 100011
                strTemp = strTemp & "j"
            Case 100100
                strTemp = strTemp & "k"
            Case 100101
                strTemp = strTemp & "l"
            Case 100110
                strTemp = strTemp & "m"
            Case 100111
                strTemp = strTemp & "n"
            Case 101000
                strTemp = strTemp & "o"
            Case 101001
                strTemp = strTemp & "p"
            Case 101010
                strTemp = strTemp & "q"
            Case 101011
                strTemp = strTemp & "r"
            Case 101100
                strTemp = strTemp & "s"
            Case 101101
                strTemp = strTemp & "t"
            Case 101110
                strTemp = strTemp & "u"
            Case 101111
                strTemp = strTemp & "v"
            Case 110000
                strTemp = strTemp & "w"
            Case 110001
                strTemp = strTemp & "x"
            Case 110010
                strTemp = strTemp & "y"
            Case 110011
                strTemp = strTemp & "z"
            Case 110100
                strTemp = strTemp & "0"
            Case 110101
                strTemp = strTemp & "1"
            Case 110110
                strTemp = strTemp & "2"
            Case 110111
                strTemp = strTemp & "3"
            Case 111000
                strTemp = strTemp & "4"
            Case 111001
                strTemp = strTemp & "5"
            Case 111010
                strTemp = strTemp & "6"
            Case 111011
                strTemp = strTemp & "7"
            Case 111100
                strTemp = strTemp & "8"
            Case 111101
                strTemp = strTemp & "9"
            Case 111110
                strTemp = strTemp & "+"
            Case 111111
                strTemp = strTemp & "/"
        End Select
    Next
    
    Base64Encode = strTemp
    Exit Function
Err_Check:
    MsgBox "Base64Encode Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Function
Public Sub Base64EncodeFile(strFile As String, rtfTemp As RichTextBox, txtOutput As TextBox)
' Base64EncodeFile(strFile,rtfTemp,txtOutput)
' Base64EncodeFile "c:\windows\autoexec.bat",rtfBox,txtBox
' The second parameter must be a rtf box or a control that supports the
' LoadFile command
On Error GoTo Err_Check
    Dim intCount As Integer
    Dim strTemp As String
    Dim lngMax As Long

    lngMax = 0
    txtOutput.Text = ""
    rtfTemp.LoadFile strFile
    
    For intCount = 1 To Len(rtfTemp.Text) Step 3
    
        strTemp = Mid(rtfTemp.Text, intCount, 3)
        txtOutput.Text = txtOutput.Text & Base64Encode(strTemp)
        lngMax = lngMax + 4
        
        If lngMax = 72 Then
            lngMax = 0
            txtOutput.Text = txtOutput.Text & vbCrLf
        End If
        
        DoEvents
    Next intCount
    Exit Sub
Err_Check:
    MsgBox "Base64EncodeFile Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Public Sub subConnectToServer(strServer As String, wsk As Winsock, Optional strSrvPort As String)
' ConnectToServer(strServer, wsk, strSrvPort)
' ConnectToServer "pop.microsoft.com", ctlMailServer, 25
' Normally leave out the last arguement and let the Winsock control use
' the default port.
On Error GoTo Err_Check
    'DoEvents
    If (wsk.State <> 0) Then
        lstSentMail.AddItem "Connect Server Illegal State " & wsk.State
        wsk.Close
    End If
    wsk.RemoteHost = strServer
    If strSrvPort = "" Then
        wsk.RemotePort = 25 '25 is the standard email port
    Else
        wsk.RemotePort = Val(strSrvPort)
    End If
    wsk.Connect
    Exit Sub
Err_Check:
    MsgBox "subConnectToServer Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Function ExtractArgument(ArgNum As Integer, srchstr As String, Delim As String) As String
' ExtractArgument(ArgNum, srchstr, Delim)
' ExtractArgument(3, "No 1, No 2, No 3", ",") Would return No 3
' I did not have time to sort out the variable names in this function,
' so if you can be bothered to, please send it to me at sam@vbsquare.com
On Error GoTo Err_Check
    Dim ArgCount As Integer
    Dim LastPos As Integer
    Dim Pos As Integer
    Dim Arg As String
    
    Arg = ""
    LastPos = 1
    If ArgNum = 1 Then Arg = srchstr
    Do While InStr(srchstr, Delim) > 0
        Pos = InStr(LastPos, srchstr, Delim)
        If Pos = 0 Then
            If ArgCount = ArgNum - 1 Then Arg = Mid(srchstr, LastPos)
            Exit Do
        Else
            ArgCount = ArgCount + 1
            If ArgCount = ArgNum Then
                Arg = Mid(srchstr, LastPos, Pos - LastPos)
                Exit Do
            End If
        End If
        LastPos = Pos + 1
    Loop
    ExtractArgument = Arg
    
    Exit Function
Err_Check:
    MsgBox "ExtractArgument Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Function
Public Sub Wait(WaitTime)
' Wait(WaitTime)
' Wait 0.5
On Error GoTo Err_Check
    Dim StartTime As Double
    
    StartTime = Timer()
    
    Do While Timer < StartTime + WaitTime
        If Timer > 86395 Or Timer = 0 Then Exit Do
        DoEvents
    Loop
    Exit Sub
Err_Check:
    MsgBox "Wait Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub cmdSelect_Click()
'This module was designed so that you can rip out and use: frmSendMail and modSendMail
On Error GoTo Err_Check
    cmdDialog.ShowOpen
    txtAttach = cmdDialog.FileName
    Exit Sub
Err_Check:
    MsgBox "cmdSelect_Click Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub cmdSTOP_Click()
On Error GoTo Err_Check
    cmdSTOP.Visible = False
    cmdSend.Enabled = True
    lblStatus.Caption = "Status:"
    Me.ctlMailServer.Close
    Exit Sub
Err_Check:
    MsgBox "cmdSTOP_Click Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub ctlMailServer_Close()
On Error Resume Next
    'lblStatus.Caption = "Connection Ready"
End Sub
Private Sub ctlMailServer_Connect()
On Error GoTo Err_Check
    'lblStatus.Caption = "Connected to POP Server"
    'Wait 0.5
    'lblStatus.Caption = "Sending mail"
    If (txtAttach.Text = "") Then
        subSendMail txtFromAddress, txtToAddress, txtSubject, txtToFullName, txtBody, ctlMailServer
    Else
        subSendMail txtFromAddress, txtToAddress, txtSubject, txtToFullName, txtBody, ctlMailServer, txtAttach, txtOutput
    End If
    Exit Sub
Err_Check:
    MsgBox "ctlMailServer_Connect Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub ctlMailServer_Error(ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)
On Error Resume Next
    MsgBox "ctlMailServer_Error Error Number: " & Number & vbCrLf & Description & vbCrLf & Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Function bValidateEntry() As Boolean
On Error GoTo Err_Check
    bValidateEntry = True
    If txtServer.Text = "" Or txtToAddress = "" Then bValidateEntry = False
    Exit Function
Err_Check:
    MsgBox "bValidateEntry Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Function
Private Sub ctlMailServer_SendComplete()
On Error Resume Next
    'lblStatus.Caption = "Message Sent!"
End Sub
Private Sub Form_Load()
On Error GoTo Err_Check
    Dim rsSystemConfig As Recordset
    Set rsSystemConfig = MyDB.OpenRecordset("tblSystemConfig", dbOpenSnapshot)
    If (Not rsSystemConfig.EOF) Then
        txtServer.Text = MyCStr(rsSystemConfig!MailSMTPServer)
        txtFromAddress.Text = MyCStr(rsSystemConfig!MailFromAddy)
        txtToFullName.Text = MyCStr(rsSystemConfig!MailToFullName)
        txtToAddress.Text = MyCStr(rsSystemConfig!MailToAddy)
        txtSubject.Text = MyCStr(rsSystemConfig!MailSubject)
        If (Len(MyCStr(rsSystemConfig!MailBody)) = 0) Then
            txtBody.Text = "Your character is available at our new IP address at the (YOUR MUD NAME HERE):" & vbCrLf & "Our New IP is " & ctlMailServer.LocalIP & " as always port 23" & vbCrLf & "(YOUR SITE URL HERE)" & vbCrLf & "(YOUR IMMORTAL LEVEL 99 ALIAS HERE)"
        Else
            txtBody.Text = MyCStr(rsSystemConfig!MailBody)
        End If
    End If
    Set rsSystemConfig = Nothing
    Exit Sub
Err_Check:
    MsgBox "Form_Load Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error GoTo Err_Check
    Dim rsSystemConfig As Recordset
    Set rsSystemConfig = MyDB.OpenRecordset("tblSystemConfig", dbOpenTable)
    If (Not rsSystemConfig.EOF) Then
        rsSystemConfig.Edit
        rsSystemConfig!MailSMTPServer = MyCStr(txtServer.Text)
        rsSystemConfig!MailFromAddy = MyCStr(txtFromAddress.Text)
        rsSystemConfig!MailSubject = MyCStr(txtSubject.Text)
        rsSystemConfig!MailBody = MyCStr(txtBody.Text)
        rsSystemConfig.Update
    Else
        rsSystemConfig.AddNew
        rsSystemConfig!MailSMTPServer = MyCStr(txtServer.Text)
        rsSystemConfig!MailFromAddy = MyCStr(txtFromAddress.Text)
        rsSystemConfig!MailSubject = MyCStr(txtSubject.Text)
        rsSystemConfig!MailBody = MyCStr(txtBody.Text)
        rsSystemConfig.Update
    End If
    Set rsSystemConfig = Nothing
    cmdSTOP_Click
    Unload Me
    Exit Sub
Err_Check:
    MsgBox "Form_Unload Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub cmdClose_Click()
On Error GoTo Err_Check
    Unload Me
    Exit Sub
Err_Check:
    MsgBox "cmdClose_Click Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Public Sub subSendMail(strFrom As String, strTo As String, strSubject As String, strFullName As String, strBody As String, wsk As Winsock, Optional strAttachName As String, Optional txtEncodedFile As Control)
' SendMail(strFrom, strTo, strSubject, strBody, wsk, strAttachName, txtEncodedFile)
' SendMail "me@mymail.com", "you@yourmail.com", "Test Message", "Body", ctlMailServer, "myfile.ext", txtEncodedFile
' If you omit the last two arguements then no file is attached
' Before attaching a file, you must first encode it using the Base64EncodeFile function
On Error GoTo Err_Check
    Dim intCount As Integer
    
    DoEvents
    
    Wait 0.5
    
    wsk.SendData "EHLO " & wsk.LocalIP & vbCrLf
    wsk.SendData "MAIL FROM:" & strFrom & vbCrLf
    
    Wait 0.5
    
    wsk.SendData "RCPT TO:" & strTo & vbCrLf
    wsk.SendData "DATA" & vbCrLf
    
    Wait 0.5
    
    frmSendMail.lstSentMail.AddItem strFullName & " " & strTo
    
    wsk.SendData "MIME-Version: 1.0" & vbCrLf
    wsk.SendData "From: " & ExtractArgument(1, strFrom, "@") & " <" & strFrom & ">" & vbCrLf
    wsk.SendData "To: <" & strTo & ">" & vbCrLf
    wsk.SendData "Subject: " & strSubject & vbCrLf
    wsk.SendData "Content-Type: multipart/mixed;" & vbCrLf
    wsk.SendData "              boundary=Unique-Boundary" & vbCrLf & vbCrLf
    wsk.SendData " [ smile and be happy cause tomorrow comes till it cannot no more ]" & vbCrLf & vbCrLf
    wsk.SendData vbCrLf & "--Unique-Boundary" & vbCrLf
    wsk.SendData "Content-type: text/plain; charset=US-ASCII" & vbCrLf & vbCrLf
    wsk.SendData strFullName & vbCrLf & strBody & vbCrLf & vbCrLf
    
    If (LTrim(RTrim(strAttachName)) <> "") Then
        For intCount = Len(strAttachName) To 1 Step -1
            If (Mid(strAttachName, intCount, 1) = "\") Then
                strAttachName = Mid(strAttachName, intCount + 1)
                Exit For
            End If
        Next intCount
        
        wsk.SendData "--Unique-Boundary" & vbCrLf
        wsk.SendData "Content-Type: multipart/parallel; boundary=Unique-Boundary-2" & vbCrLf & vbCrLf
        wsk.SendData "--Unique-Boundary-2" & vbCrLf
        wsk.SendData "Content-Type: application/octet-stream;" & vbCrLf
        wsk.SendData " name=" & strAttachName & vbCrLf
        wsk.SendData "Content-Transfer-Encoding: base64" & vbCrLf
        wsk.SendData "Content-Disposition: inline;" & vbCrLf
        wsk.SendData " filename=" & strAttachName & vbCrLf & vbCrLf
        wsk.SendData txtEncodedFile.Text & "==" & vbCrLf
        wsk.SendData "--Unique-Boundary-2----Unique-Boundary--"
    End If
    
    wsk.SendData vbCrLf & "." & vbCrLf
    
    Wait 0.5
    
    wsk.SendData "QUIT" & vbCrLf
    
    Wait 0.5
    
    basDelay 2000
    
    wsk.Close
    Exit Sub
Err_Check:
    MsgBox "subSendMail Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
Private Sub cmdSend_Click()
On Error GoTo Err_Check
'Calls winsock control event subSendMail
    Dim lCountMsg As Long
    Dim lMAXCountMsg As Long
    Dim rsPlayer As Recordset
    
    If (txtServer.Text = "") Then
        MsgBox "A server name is required.", vbCritical + vbOKOnly, Me.Caption
    Else
        lstSentMail.Clear
        DoEvents
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, EMailAddy FROM tblPlayer WHERE (EMailAddy <> '' AND EMailAddy Is Not Null AND InStr(EMailAddy, '@') > 0) ORDER BY PlayerName;", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lCountMsg = 0
            cmdSTOP.Visible = True
            cmdSend.Enabled = False
            rsPlayer.MoveLast
            lMAXCountMsg = rsPlayer.RecordCount
            rsPlayer.MoveFirst
            DoEvents
            Do While (Not rsPlayer.EOF And cmdSTOP.Visible = True)
                lCountMsg = lCountMsg + 1
                lblStatus.Caption = MyCStr(rsPlayer!PlayerName) & " " & lCountMsg & "/" & lMAXCountMsg
                txtToFullName.Text = ""
                DoEvents
                txtToFullName.Text = "Greetings " & MyCStr(rsPlayer!PlayerName) & "!"
                txtToAddress.Text = MyCStr(rsPlayer!EMailAddy)
                'txtToAddress.Text = "yourname@whereever.com"
                DoEvents
                DoEvents
                basDelay 2000
                
                If (txtAttach.Text <> "") Then
                    lblStatus.Caption = "Encoding file attachment"
                    Base64EncodeFile txtAttach.Text, rtfAttach, txtOutput
                End If
                
                lblStatus.Caption = "Connecting to POP Server"
                basDelay 1000
                
                subConnectToServer txtServer.Text, ctlMailServer
                
                'DoEvents
                'Do While (lblStatus.Caption <> "Message Sent" And cmdSTOP.Visible = True)
                '    DoEvents
                'Loop
                
                rsPlayer.MoveNext
            Loop
        Else
            lblStatus.Caption = "No Email addresses were found."
            basDelay 3000
        End If
        
        Set rsPlayer = Nothing
    End If
    
    cmdSTOP.Visible = False
    cmdSend.Enabled = True
    lblStatus.Caption = "Status:"
    Exit Sub
Err_Check:
    MsgBox "cmdSend_Click Error Number: " & Err.Number & vbCrLf & Err.Description & vbCrLf & Err.Source, vbCritical + vbOKOnly, Me.Caption
End Sub
