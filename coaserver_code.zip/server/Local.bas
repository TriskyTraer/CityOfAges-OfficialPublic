Attribute VB_Name = "modLocal"
Option Explicit
Public Const gblcstbAntiPiracy = False 'This will activate anti-piracy through code in the registry. You must modify gblstrApplicationModifiedDate too set somewhere in this code to the compile date !!!
Public gblstrApplicationModifiedDate As String ' RELEASE DATE Use the format MMM DD, YYYY
Public gblbDemoCopy As Boolean ' DEMONSTRATION FLAG
'OTHER VARIABLES
Public cstREPORT_PATH As String
Public Sub basPopulateSpecialVariables()
    gblstrApplicationModifiedDate = "MAR 01, 2000" 'RELEASE DATE (this must be modified before the lastest compilation and EXE release) Use the format MMM DD, YYYY
    
    strProgramVersion = "Version 1.00"
    
    'We track our versions here.
    '00000111301999ADS Fish Creek Serial Number
    strProgramSerialNumber = basConvertStringToHex("00000211301999ADS") 'First 6 digit is to record number of copies of this program, Date Issued and Company
    
    'System Install Path
    REG_PATHALL = "SOFTWARE\ADSTELNETMISC\SETTINGS" 'Install Date
    
    'Piracy checks
    REG_PATHID = "SOFTWARE\ADSTELNETCOID\SETTINGS" 'Install Date
    REG_PATHMD = "SOFTWARE\ADSTELNETCOMD\SETTINGS" 'Modification Date
End Sub
Public Sub basPopulateGlobalVariablesWithValues()
On Error Resume Next
    'DO NOT CHANGE THE FOLLOWING FIVE LINES:
    cstFileNameMDB = App.Path & "\FINDMDB.INI"
    cstFileNameRPT = App.Path & "\FINDRPT.INI"
    cstFileNameImport = App.Path & "\FINDIMPT.INI"
    cstFileNameExport = App.Path & "\FINDEXPT.INI"
    cstFileNameBackUp = App.Path & "\FINDBAK.INI"

    cstREPORT_PATH = App.Path & "\LOCAL.ADS"
    
    If (gblcstbAntiPiracy) Then
        If (Not gblbDemoCopy) Then
            booCommitSystemInstall
            If (Not booPiracyCheck()) Then
                If (Not booCommitRegistryKey()) Then
                    MsgBox "W E L C O M E..." & vbCr & vbCr & "Consult the following System House for your Upgrade Registration Key, today !" & vbCr & vbCr & "Join the experience and leisure of book tracking with hundreds of others around the Globe!" & vbCr & vbCr & "Advanced Database Solutions Ltd." & vbCr & "(780) 451 - 0020" & vbCr & vbCr & "Call now to purchase the latest upgrade or full version !", 64, "NEW Check Out Assistant UPGRADE AVAILABLE NOW!"
                    End
                Else
                    basMessage64 "Registration Successful !"
                End If
            End If
        End If
    End If
End Sub

Public Sub subDisplayAreaDesc(strPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    Set rsData = MyDB.OpenRecordset("SELECT tblPlayer.PortID, tblArea.AreaName, tblArea.AreaDescDay, tblArea.AreaDescNight FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblPlayer.Y = tblArea.Y) AND (tblPlayer.X = tblArea.X) WHERE (((tblPlayer.PortID)=" & strPortID & "));", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        
    End If
    
    Set rsData = Nothing
    Exit Sub
Err_Check:
    basMessage64 "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

