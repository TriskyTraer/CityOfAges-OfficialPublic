VERSION 5.00
Begin VB.Form frmDTPortChanges 
   Appearance      =   0  'Flat
   BackColor       =   &H000080FF&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Change Dynamic Port Values"
   ClientHeight    =   2370
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   1545
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   12
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmDTPortChanges.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2370
   ScaleWidth      =   1545
   Begin VB.CheckBox optDisablePort23 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      Caption         =   "Disable Port 23"
      DisabledPicture =   "frmDTPortChanges.frx":058A
      DownPicture     =   "frmDTPortChanges.frx":0B14
      ForeColor       =   &H80000008&
      Height          =   615
      Left            =   120
      TabIndex        =   3
      Top             =   1080
      Width           =   1335
   End
   Begin VB.CommandButton cmdSave 
      Appearance      =   0  'Flat
      Caption         =   "&Save"
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   1920
      Width           =   1335
   End
   Begin VB.TextBox txtPortB 
      Appearance      =   0  'Flat
      Height          =   390
      Left            =   120
      TabIndex        =   1
      Top             =   600
      Width           =   1335
   End
   Begin VB.TextBox txtPortA 
      Appearance      =   0  'Flat
      Height          =   390
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1335
   End
End
Attribute VB_Name = "frmDTPortChanges"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Form_Load()
    txtPortA.Text = gbllDynamicPortID1 '101
    txtPortB.Text = gbllDynamicPortID2 '102
    Select Case (gblbConfig103 <> 0)
        Case True
            optDisablePort23.Value = 1 'disabled
        Case Else
            optDisablePort23.Value = 0 'working port
    End Select
End Sub

Private Sub cmdSave_Click()
    gbllDynamicPortID1 = MyCLng(txtPortA.Text)
    gbllDynamicPortID2 = MyCLng(txtPortB.Text)
    
    If (Not frmDTPortAlternate1.bUnload) Then
        'Save here
        frmDTPortAlternate1.lblMsg.Caption = gbllDynamicPortID1
        MyDB.Execute "UPDATE tblSystemConfig SET DynamicTelnetPort1=" & gbllDynamicPortID1 & ";", dbFailOnError
    End If
    
    If (Not frmDTPortAlternate2.bUnload) Then
        'Save here
        frmDTPortAlternate2.lblMsg.Caption = gbllDynamicPortID2
        MyDB.Execute "UPDATE tblSystemConfig SET DynamicTelnetPort2=" & gbllDynamicPortID2 & ";", dbFailOnError
    End If
    
    Select Case (optDisablePort23.Value <> 0)
        Case True 'disabled
            gblbConfig103 = 1
            Unload frmPort23 'must be in this order to take the new value
            MyDB.Execute "UPDATE tblSystemConfig SET DisablePort23=-1;", dbFailOnError
        Case Else 'working port
            gblbConfig103 = 0
            frmPort23.Show 'must be in this order to take the new value
            MyDB.Execute "UPDATE tblSystemConfig SET DisablePort23=0;", dbFailOnError
    End Select
    
    'If (Not frmPort23.bUnload) Then
    'Else
    'End If
End Sub

