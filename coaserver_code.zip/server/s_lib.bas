Attribute VB_Name = "modExternalSharedLibrary"
Option Explicit 'if you add global port variables add them to subClearLoginPort(zPortID As String)
'FORM INVISIBLE
Private Const GWL_EXSTYLE = (-20)
Private Const WS_EX_TRANSPARENT = &H20
Private Const SWP_FRAMECHANGED = &H20
Private Const SWP_NOMOVE = &H2
Private Const SWP_NOSIZE = &H1
Private Const SWP_SHOWME = SWP_FRAMECHANGED Or SWP_NOMOVE Or SWP_NOSIZE
Private Const HWND_NOTOPMOST = -2
Private Declare Function SetWindowLong Lib "user32" Alias "SetWindowLongA" (ByVal hWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
Private Declare Function SetWindowPos Lib "user32" (ByVal hWnd As Long, ByVal hWndInsertAfter As Long, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Public Const cststrDateFormat = "mmm dd, yyyy"
Public Const cststrMDBINIInitMessage = "INI Preparation STAGE--LOCATING YOUR DATABASE"
Public Const cstbGlobalThiveryAllowed = True 'cstbGlobalThiveryAllowed Or zClass = "TH" Or zClass = "BA" Or zClass = "GY" Or zClass = "AS"
'THE FOLLOWING VARIABLES HAVE TO BE DEFINED IN THE PROGRAM'S
'PERSONAL basPopulateGlobalVariablesWithValues module.
'ALL PROGRAMS MUST HAVE THEIR PERSONAL basPopulateGlobalVariablesWithValues module.
' put App.Path & <then the file> for the next 5 files
'Make sure the next 5 variables are set or you will get file/path access errors.
Public cstFileNameMDB As String
Public gblbArenaOnOff As Long
Public gblvarReturnCallForm As Variant
Public gbllngSendBack(1 To 2) As Long  'cell 1 is the calling form that wants to change its relationship autonumber, cell 2 is the value that is requested to show up if this is 0 then the called form will not default a existing value

Public gblConstructorlMode As Long
Public intPurgeData As Integer 'Works as a return variable for s_pgedata.frm
Public intBrowseImport As Integer ' Used to tell form frmBrowseImport where to get its information.
Public intBrowseExport As Integer ' Used to tell form frmBrowseExport where to get its information.
Public intLoadingFormForActualDateEntry As Integer
Public strProgramVersion As String ' Main Menu of each program loads this value in.
Public strProgramSerialNumber As String ' Main Menu of each program loads this value in.
Public strfrmPopUpMsg As String
Public strNull As Variant
Public lgblCompletelyBannedMAX As Long '30 is the usual value
'Module variable.
Public gblDB As Database
Public gblSmartTimer As Double
'API Variables
'These are for function SetWindowPos, this allows a VB form to be modal over other applications.
'replaced Public Const SWP_NOMOVE = &H2
'replacedPublic Const SWP_NOSIZE = &H1
Public Const HWND_TOPMOST = -1
'replacedPublic Const HWND_NOTOPMOST = -2
'For ShellExecute (opening a URL by a click event)
Public Const SW_SHOWNORMAL = 1
'For LoadCursorFromFile and SetClassLong.
Public Const GCL_HCURSOR = (-12)
'API Functions or Procedures

'Control the computer
Public Const EWX_LOGOFF = 0
Public Const EWX_SHUTDOWN = 1
Public Const EWX_REBOOT = 2
Public Const EWX_FORCE = 4
'Declare Function ExitWindows Lib "user32" (ByVal uFlags As Long, ByVal dwReserved As Long) As Long 'ExitWindowsEx Ewx_logoff, 0& ExitWindowsEx Ewx_Shutdown, 0&, ExitWindows(EWX_REBOOT, 0&)
'Private Declare Function gethostname Lib "wsock32.dll" (ByVal szHost As String, ByVal dwHostLen As Long) As Long
'MIDI
Private Declare Function lngPlayMIDI Lib "winmm.dll" Alias "mciSendStringA" (ByVal lpstrCommand As String, ByVal lpstrReturnString As Any, ByVal uReturnLength As Long, ByVal hwndCallback As Long) As Long
'Private Sub Command1_Click()
'   Dim ret As Integer
   ' The following will open the sequencer with the C:WIN31CANYON.MID
   ' file. Canyon is the device_id.
'   ret = mciSendString("open c:windowsCANYON.MID type sequencer alias canyon", 0&, 0, 0)
   ' The wait tells the MCI command to complete before returning control
   ' to the application.
'   ret = mciSendString("play canyon wait", 0&, 0, 0)
   ' Close CANYON.MID file and sequencer device
'   ret = mciSendString("close canyon", 0&, 0, 0)
'End Sub
'OLD replaced above Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal hWndInsertAfter As Long, ByVal x As Long, ByVal y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
'How to make a form stay on top.
'There may be times when you would like a form to stay visible on top of all other forms.
'Visual Basic does not provide a way for this functionality but lucky for us the Win API does (and easily too).
'Go ahead and create a module and insert the following code:
'Place this in the Form Load:
'SetWindowPos hwnd, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE + SWP_NOSIZE
'Place this in the Form Unload:
'SetWindowPos hwnd, HWND_NOTOPMOST, 0, 0, 0, 0, SWP_NOMOVE + SWP_NOSIZE
Declare Function ShellExecute Lib "shell32.dll" Alias "ShellExecuteA" (ByVal hWnd As Long, ByVal lpOperation As String, ByVal lpFile As String, ByVal lpParameters As String, ByVal lpDirectory As String, ByVal nShowCmd As Long) As Long
'This isalso used for the Sleep command below.
'By using the ShellExecute API you can open web sites just as easily as double clicking an HTML file in explorer.
'To create a hyperlink you need only one API call, one constant, and one line of code.
'Put these declarations in a module:
'Here is an example for a button called cmdGOURL.
'Private Sub cmdGOURL_Click()
'XOn Error Resume Next
'    Dim lReturn As Long
'    If (instr(<txtURL>, "http://") > 0) Then
'        lReturn = ShellExecute(hwnd, "open", txtVendorURL, vbNull, vbNull, SW_SHOWNORMAL)
'    Else
'        lReturn = ShellExecute(hwnd, "open", "http://" & txtVendorURL, vbNull, vbNull, SW_SHOWNORMAL)
'    End If
'End Sub 'Note: where <txtURL> is the name of your text object.
Declare Function LoadCursorFromFile Lib "user32" Alias "LoadCursorFromFileA" (ByVal lpFileName As String) As Long
Declare Function SetClassLong Lib "user32" Alias "SetClassLongA" (ByVal hWnd As Long, ByVal nIndex As Long, ByVal dwNewLong As Long) As Long
'Visual Basic does not allow you to load animated cursors, but the API does.   Animated cursors are very usefull.  They let the user know that the computer hasn't locked up. I highly recommend using animated cursors over the regular hourglass.
'To display an animated cursor requires only two API declarations and one constant.
'To show the cursor you first need to call the LoadCursorFromFile API.  This will open the .ANI file and return a handle to the cursor.  After that we call the SetClassLong API to assign the new cursor to a Window.  The SetClassLong function returns the handle of the current cursor.  We want to store that so we can restore the old cursor later.
'Here is the code to do this:
'Dim sCursorFile As String
'Dim hCursor As Long
'Dim hOldCursor As Long
'Dim lReturn As Long
'sCursorFile = App.Path & "\Globe.ani"
'hCursor = LoadCursorFromFile(sCursorFile)
'hOldCursor = SetClassLong(Form1.hwnd, GCL_HCURSOR, hCursor)
'To restore the cursor just call the SetClassLong again, this time setting it to the value in hOldCursor.
'lReturn = SetClassLong(Form1.hwnd, GCL_HCURSOR, hOldCursor)
'Thats all there is to ANI cursors this.
'PLAY A WAV
Declare Function lngPlayWAVE Lib "winmm" Alias "sndPlaySoundA" (ByVal lpSound As String, ByVal flag As Long) As Long
'See: basPlayWave(strFileName As String)
Declare Function waveOutGetNumDevs Lib "winmm.dll" () As Long
'Useage:
'Private Sub cmdCheck_Click()
'    Dim rtn As Integer 'declare the needed variables
'    rtn = lngSystemHasSoundCard() 'check for a sound card
'    If rtn = 1 Then 'if returned is greater than 1 then a sound card exists
'        MsgBox "Your system supports a sound card."
'    Else 'otherwise no sound card found
'        MsgBox "Your system cannot play Sound Files."
'    End If
'End Sub
Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
'INTERNET API
Private Const INTERNET_CONNECTION_MODEM = 1
Private Const INTERNET_CONNECTION_LAN = 2
Private Const INTERNET_CONNECTION_PROXY = 4
Private Const INTERNET_CONNECTION_MODEM_BUSY = 8
Private Enum InetConnectionStates 'Connection States.
    InternetConnectionModem = INTERNET_CONNECTION_MODEM
    InternetConnectionLan = INTERNET_CONNECTION_LAN
    InternetConnectionProxy = INTERNET_CONNECTION_PROXY
    InternetConnectionModemBusy = INTERNET_CONNECTION_MODEM_BUSY
End Enum
Public gblstrInternetConnectionDesc As String
'Private Declare Function InternetGetConnectedState Lib "wininet.dll" (lpdwFlags As Long, ByVal dwReserved As Long) As Long
'Example call: Sleep <value> * 1000 see also basDelay()
'HORIZONTAL LIST BOX DECLARATIONS
Private Declare Function lngSendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Private Const LB_SETHORIZONTALEXTENT = &H194
'Networking calls
Private Declare Function GetComputerName Lib "kernel32" Alias "GetComputerNameA" (ByVal lpBuffer As String, nSize As Long) As Long
Private Declare Function GetUserName Lib "advapi32.dll" Alias "GetUserNameA" (ByVal lpBuffer As String, nSize As Long) As Long
'End API functions.
'SQL HINTS NOT SHOWN BUT SUPPORTED BY ACCESS:
'       ADD FIELDS: ALTER TABLE [Location Labels] ADD COLUMN QTY Currency
'       UNION (nested SQLing) : SELECT * FROM PortableUploadAssetsNotInDBQSel UNION SELECT * FROM PortableAssetDBLocDiffQSel UNION SELECT * FROM PortableDBAssetsNotInUpload;
Public Function MyDB() As Database  'Resource DAO 2.5+ is a required DLL plug in.
On Error GoTo Err_MyDB
'Original concept: Mark Southron
'Modified for full flexibility: Darren N. Lory
'See also, basCloseMyDB(), basResetMyDB()
'This code removes the need for these each time in every module.:
'               Dim MyDB As Database
'               Set MyDB = Workspaces(0).OpenDatabase(basStoreMDBLocationToMemory())
'Syntax examples:   MyDB.Execute "DELETE * from tblEMPLOYEE;"
'                   Set MyRS = MyDB.(etc...)
' Static gblDB As Database is defined at the top of this module.
'     At the top it is defined at PUBLIC not static because static can only exist within a procedure/function.
    If (gblDB Is Nothing) Then
        Set gblDB = Workspaces(0).OpenDatabase(basStoreMDBLocationToMemory()) ' Set gblDB = Workspaces(0).OpenDatabase(basStoreMDBLocationToMemory(), True) 'True means its exclusive - remove True and the comma for shared.
        'Did the object get loaded properly?
        If (gblDB Is Nothing) Then
            'No...
            basPrintMessage64 "MyDB (field gblDB) Error #001," & vbCrLf & vbCr & "Could not set the MyDB Object. The database object could not be registered to memory." & vbCrLf & vbCr & "Is the given path set to a valid MDB? (" & basStoreMDBLocationToMemory() & ")" & vbCrLf & vbCr & "The System is about to Shutdown, please click okay to continue."
            End
        End If
    End If
    
    Set MyDB = gblDB
    If (MyDB Is Nothing) Then
        basPrintMessage64 "MyDB (field MyDB) Error #002," & vbCrLf & vbCr & "Could not set the MyDB Object. The database object could not be registered to memory." & vbCrLf & vbCr & "Is the given path set to a valid MDB? (" & basStoreMDBLocationToMemory() & ")" & vbCrLf & vbCr & "The System is about to Shutdown, please click okay to continue."
        End
    End If
    
    Exit Function
Err_MyDB:
    basPrintMessage64 "MyDB ERROR," & vbCrLf & "Error #, " & Err.Number & vbCrLf & Err.Description
    End
End Function
Public Function basMyDBJetInformation()
On Error GoTo Err_basMyDBJetInformation
    Dim strReturn As String
    strReturn = "No information provided--please location your database."
    If (Not (MyDB Is Nothing)) Then
        With MyDB
            strReturn = "Microsoft Jet Engine Information" & vbCrLf & "=================================" & vbCrLf & "Name " & .Name & vbCrLf & "Engine Version " & .Version & vbCrLf & "Collating Order " & .CollatingOrder
        End With
    End If
    basMyDBJetInformation = strReturn
    Exit Function
Err_basMyDBJetInformation:
    basMyDBJetInformation = Err.Description
End Function
Public Sub basCloseMyDB()
On Error GoTo Err_basCloseMyDB
'See Also, MyDB() As Database
'Event Location Use: Form_Unload(Cancel As Integer)
    If Not (MyDB Is Nothing) Then
        Set gblDB = Nothing
        'Never use MyDB.Close, if you do you may not be able to access data properly until the application is shutdown.
    End If
    Exit Sub
Err_basCloseMyDB:
    basPrintMessage64 Err.Description
End Sub
'Public Function bActiveConnection() As Boolean
'    Dim bInternetConnectionState As Boolean
'    Dim lngFlags As Long
'    Dim enumModeConnection As InetConnectionStates
'
'    gblstrInternetConnectionDesc = ""
'
'    bInternetConnectionState = InternetGetConnectedState(lngFlags, 0&)
'
'    enumModeConnection = lngFlags
'
'    If (lngFlags And INTERNET_CONNECTION_MODEM) Then
'        gblstrInternetConnectionDesc = "Modem"
'        If (lngFlags And INTERNET_CONNECTION_MODEM_BUSY) Then
'           gblstrInternetConnectionDesc = "Modem (Busy)"
'           'bInternetConnectionState = bInternetTryTheWire()
'        End If
'    ElseIf (lngFlags And INTERNET_CONNECTION_LAN) Then
'        gblstrInternetConnectionDesc = "LAN"
'        'bInternetConnectionState = bInternetTryTheWire()
'    ElseIf (lngFlags And INTERNET_CONNECTION_PROXY) Then
'        gblstrInternetConnectionDesc = "Proxy Server"
'        'bInternetConnectionState = bInternetTryTheWire()
'    End If
'
'    bActiveConnection = bInternetConnectionState
'End Function
Public Sub basSetListboxScrollBar(lstObject As ListBox)
On Error GoTo Err_Check
'Call this function after you AddItem or RemoveItem or anything else with a ListBox to enabled Horz - Scrolling.
'HORIZONTAL LIST BOX DECLARATIONS (already set above)
'Private Declare Function lngSendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
'Private Const LB_SETHORIZONTALEXTENT = &H194

'USAGE: basSetListboxScrollBar Me.lstList

    Dim intScan As Integer
    Dim lngNewLen As Long
    Dim lngMaxLen As Long
    
    lngMaxLen = 0
    
    intScan = lstObject.ListCount - 1
    
    If (intScan > 50) Then 'We do not want to search through to large of a list of Added Items.
        intScan = 50
    End If
    
    'Now we look at a few lines from the list box and try to guess how long to allow the listbox to scroll.
    Do While (intScan > 0)
        lngNewLen = Len(lstObject.List(intScan)) * 9
        If (lngMaxLen < lngNewLen) Then
            lngMaxLen = lngNewLen
        End If
        intScan = intScan - 1
    Loop
    
    DoEvents
    
    lngSendMessage lstObject.hWnd, LB_SETHORIZONTALEXTENT, lngMaxLen, 0
    
    DoEvents
    Exit Sub
Err_Check:
    basPrintMessage64 "basSetListboxScrollBar," & vbCrLf & vbCr & "ERROR #" & vbCrLf & Err.Number & vbCrLf & vbCr & Err.Description
End Sub
Public Function strComputerName() As String
On Error Resume Next
  Dim lsBuffer As String
  Dim llReturn As Long
  Dim lsName As String
 
  lsName = ""
  lsBuffer = Space$(255)
  llReturn = GetComputerName(lsBuffer, 255) 'Call API
  
  If (llReturn) Then
        lsName = Left$(lsBuffer, InStr(lsBuffer, Chr(0)) - 1)
  End If
  
  strComputerName = lsName
End Function
Public Function strUserName() As String
On Error Resume Next
    Dim llReturn As Long
    Dim lsUserName As String
    Dim lsBuffer As String
    
    lsUserName = ""
    lsBuffer = Space$(255)
    llReturn = GetUserName(lsBuffer, 255)
    
    If (llReturn) Then
       lsUserName = Left$(lsBuffer, InStr(lsBuffer, Chr(0)) - 1)
    End If
    
    strUserName = lsUserName
End Function
Public Function basCheckDigit(strLine As String) As Variant
On Error Resume Next
    Dim intResult As Integer
    Dim intLoop As Integer
    Dim intPartA As Integer
    Dim intPartB As Integer
    Dim intPartC As Integer
    
    'if strLine part a or part b is null then part a or part b is zero.
    'the On Error resume next is required to zero these two variables.
    'this also applies to part c
    
    intPartA = 0
    intPartB = 0
    
    If (Len(Mid(strLine, 1, 1)) > 0) Then
        intPartA = Asc(Mid(strLine, 1, 1))
        
        If (Len(Mid(strLine, 2, 1)) > 0) Then
            intPartB = Asc(Mid(strLine, 2, 1))
        End If
    End If
    
    intResult = intPartA Xor intPartB
    
    For intLoop = 3 To Len(strLine)
        intPartC = 0
        intPartC = Asc(Mid(strLine, intLoop, 1))
        intResult = intResult Xor intPartC
    Next intLoop
    
    basCheckDigit = basConvertStringToHex(Chr(intResult))
End Function
Public Function basRound(dblValue As Double, strType As String) As Long
On Error Resume Next
    Dim lngReturn As Long
    Dim strPrefix As String
    Dim strSuffix As String
    Dim intPosDecimal As Integer

    strPrefix = MyCStr(dblValue)
    strSuffix = "00"

    intPosDecimal = InStr(strPrefix, ".")
    If (intPosDecimal > 0) Then
        strSuffix = Mid(strPrefix, intPosDecimal + 1, 2) 'Max 2 places
        strPrefix = Mid(strPrefix, 1, intPosDecimal - 1)
    End If

    Do While Len(strSuffix) < 2
        strSuffix = strSuffix & "0"
    Loop

    Select Case strType
        Case "+" ' round up
            If (MyCLng(strSuffix) >= 50) Then
                lngReturn = MyCLng(strPrefix) + 1
            Else
                lngReturn = MyCLng(strPrefix)
            End If
        Case "-" ' round down
            lngReturn = MyCLng(strPrefix)
    End Select
    
    basRound = lngReturn
End Function
Public Function bAmong(varTarget As Variant, ParamArray varList() As Variant) As Boolean
' If bAmong(ch, "a", "f", "g") then...
' "ParamArray varList() As Variant" can be anything at all, it needs to be variant in this case to make this function more flexible, the "bAmong() As Integer" is returns a boolean value though Integer.
On Error Resume Next
    Dim bReturn As Integer
    Dim vEachChar As Variant
    
    bReturn = False
    
    For Each vEachChar In varList()
        If (vEachChar = varTarget) Then
            bReturn = True
            Exit For
        End If
    Next
    
    bAmong = bReturn
End Function
Public Function basConvertStringToHex(strLine As String) As String
On Error Resume Next
'The reverse function is available.
'Pass: the word 'PROGRAMMER'
'Returns: the HEX "50524F4752414D4D4552"
    Dim intLoop As Integer
    Dim strReturn As String
    Dim strHex As String
    
    For intLoop = 1 To Len(strLine)
        strHex = Hex(Asc(Mid(strLine, intLoop, 1)))
        
        If (Len(strHex) < 2) Then
            strHex = "0" & strHex
        End If
        
        strReturn = strReturn & strHex
    Next intLoop
    
    basConvertStringToHex = strReturn
End Function
Public Function basConvertHexToString(strLine As String) As String
On Error Resume Next
'The reverse function is available.
'Pass: the HEX "50524F4752414D4D4552"
'Returns: the word 'PROGRAMMER'

    Dim intLoop As Integer
    Dim strReturn As String
    Dim strChar As String
    Dim intFindHex As Integer
    Dim intOkay As Integer
    
    For intLoop = 1 To Len(strLine) Step 2
        strChar = Chr(32) 'init. as a space
        intFindHex = 0: intOkay = False
        Do Until (intOkay)
            If (Mid(strLine, intLoop, 2) = Hex(intFindHex)) Then
                intOkay = True
                strChar = Chr(intFindHex)
            End If
            
            intFindHex = intFindHex + 1
            
            If (intFindHex > 255) Then
                intOkay = True
            End If
        Loop
        
        strReturn = strReturn & strChar
    Next intLoop
    
    basConvertHexToString = strReturn
End Function
Public Function basGetScreenMode(lngW As Long, lngH As Long) As Integer
On Error Resume Next
    Dim intMode As Integer
' Returns:  1 = 800x600
'           2 = 640 x 480

    intMode = 0 'Not known

    If (lngW = 9000) And (lngH = 12000) Then '800 x 600
        intMode = 1
    End If
    
    If (lngW = 7200) And (lngH = 9600) Then '640 x 480
        intMode = 2
    End If
    
    basGetScreenMode = intMode
End Function
Public Sub basFormEnabled(frmObject As Form, booType As Boolean)
'Will en/disable and lock or unlock all controls on a form.
'Syntax:
'   basGlobalFormLock frmTest, true
On Error GoTo Err_HideAll
    Dim ctlObject As Control
    Dim strErrorName As String
    
    For Each ctlObject In frmObject.Controls
        With ctlObject
            .Enabled = booType
            
            If TypeOf ctlObject Is TextBox Then
                .Locked = Not booType
            End If
        End With
    Next ctlObject
    Exit Sub
Err_HideAll:
    basPrintMessage64 "basFormEnabled," & vbCrLf & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCr & strErrorName
End Sub
Public Sub basFormClearTXT(frmObject As Form) 'Clear all TextBoxes
On Error GoTo Err_ClearForm
    Dim ctlObject As Control
    Dim strErrorName As String
    
    For Each ctlObject In frmObject.Controls
        With ctlObject
            strErrorName = .Name
            .Enabled = True
            Select Case UCase(Mid(.Name, 1, 3))
                Case "TXT" 'Hungerian notation for text boxes. You can only lock text boxes.
                    .Locked = False
                    .Text = "" 'this works it is reversed logic from enabled.
            End Select
        End With
    Next ctlObject
    Exit Sub
Err_ClearForm:
    basPrintMessage64 "basFormClearTXT" & vbCrLf & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCr & strErrorName
End Sub
Public Sub basFormClearLST(frmObject As Form) 'Clear all ListBoxes
On Error GoTo Err_ClearForm
    Dim ctlObject As Control
    Dim strErrorName As String
    
    For Each ctlObject In frmObject.Controls
        With ctlObject
            strErrorName = .Name
            .Enabled = True
            Select Case UCase(Mid(.Name, 1, 3))
                Case "LST" 'List boxes
                    .Clear
            End Select
        End With
    Next ctlObject
    Exit Sub
Err_ClearForm:
    basPrintMessage64 "basFormClearLST" & vbCrLf & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCr & strErrorName
End Sub
Public Sub basFormClearCBX(frmObject As Form) 'Clear all ComboBoxes
On Error GoTo Err_ClearForm
    Dim ctlObject As Control
    Dim strErrorName As String
    
    For Each ctlObject In frmObject.Controls
        With ctlObject
            strErrorName = .Name
            .Enabled = True
            Select Case UCase(Mid(.Name, 1, 3))
                Case "CBX" 'combo boxes
                    .Clear
            End Select
        End With
    Next ctlObject
    Exit Sub
Err_ClearForm:
    basPrintMessage64 "basFormClearCBX" & vbCrLf & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCr & strErrorName
End Sub
Public Function MyFileLen(zPath As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = FileLen(zPath)
    MyFileLen = lReturn
    Exit Function
Err_Check:
    MyFileLen = 0
End Function
Public Sub basDelay(lngMiliSeconds As Long)
On Error Resume Next
' 1000 = 1 second
'basDelay does not work well if a modal form is executed during a DoEvents.
'See also: Sleep <value> * 1000
    Dim lngEnd As Double

    lngEnd = Timer + (lngMiliSeconds / 1000)
    
    Do Until (Timer > lngEnd)
        DoEvents
    Loop
End Sub
Public Sub basDelaySmartTimerStart()
On Error Resume Next
'1000 = 1 second
'basDelay does not work well if a modal form is executed during a DoEvents.
'EXAMPLE:
'    basDelaySmartTimerStart
'    MsgBox "WAITING..."
'    MsgBox "You waited " & Timer - gblSmartTimer & " seconds / 10 seconds" & vbcrlf & vbCr & "If there is time left we will now wait for the delay to finish up."
'    basDelaySmartTimerEnd 10000
'    MsgBox gblSmartTimer & vbcrlf & Timer
'This procedure is designed for label messages, ie. lblMsg.caption = "HELLO!".
'For instance if you are filling a listbox with data and you want to clear the lable afterwards
'but you want the user to see the message then this dealy is for you.
'EXAMPLE:
'   basDelaySmartTimerStart
'   lblMsg.caption = "Filling Country combo box"
'   basFillCountryCombobox
'   basDelaySmartTimerEnd 5000
' If it actually takes 5 seconds to fill then the user had enough time to read the message.
' If not then the user has what ever time is left over to read the message.
    gblSmartTimer = Timer
End Sub
Public Sub basDelaySmartTimerEnd(lngMiliSeconds As Long)
On Error Resume Next
'1000 = 1 second
'basDelay does not work well if a modal form is executed during a DoEvents.
'EXAMPLE:
'    basDelaySmartTimerStart
'    MsgBox "WAITING..."
'    MsgBox "You waited " & Timer - gblSmartTimer & " seconds / 10 seconds" & vbcrlf & vbCr & "If there is time left we will now wait for the delay to finish up."
'    basDelaySmartTimerEnd 10000
'    MsgBox gblSmartTimer & vbcrlf & Timer
'This procedure is designed for label messages, ie. lblMsg.caption = "HELLO!".
'For instance if you are filling a listbox with data and you want to clear the lable afterwards
'but you want the user to see the message then this dealy is for you.
'EXAMPLE:
'   basDelaySmartTimerStart
'   lblMsg.caption = "Filling Country combo box"
'   basFillCountryCombobox
'   basDelaySmartTimerEnd 5000
' If it actually takes 5 seconds to fill then the user had enough time to read the message.
' If not then the user has what ever time is left over to read the message.

    Dim lngEnd As Double

    lngEnd = gblSmartTimer + (lngMiliSeconds / 1000)
    
    Do Until (Timer > lngEnd)
        DoEvents
    Loop
End Sub
Public Function basDoesDirectoryExist(strPath As String) As Integer
On Error Resume Next
    Dim lngError As Long
    Dim intReturn As Integer
    
    intReturn = False ' Path does not exist
    
    If (Mid(strPath, Len(strPath), 1) = "\") Then
        strPath = (Mid(strPath, 1, Len(strPath) - 1))
    End If
    
    intReturn = (GetAttr(strPath) > 0) ' This will be skipped if GetAttr errors out at level 76 'path not found'
    
    basDoesDirectoryExist = intReturn
End Function
Public Function basDoesFileExist(strPathAndFile As String) As Integer
On Error Resume Next
    Dim lngError As Long
    Dim intReturn As Integer
    
    intReturn = False ' File does not exist
    
    intReturn = (GetAttr(strPathAndFile) > 0) ' This will be skipped if GetAttr errors out at level 76 'path not found'

    basDoesFileExist = intReturn
End Function
Public Function basAddCharacters(intNumberOf As Integer, strChar As String) As String
On Error Resume Next
' Returns the number of the character type the programmer wishs.
    Dim strReturn As String
    Dim intCount As Integer
        
    For intCount = 1 To intNumberOf  ' Set up 10 repetitions.
        strReturn = strReturn & strChar ' Append number to string.
    Next intCount
    
    basAddCharacters = strReturn
End Function
Public Sub basCannotDeleteMessage()
On Error Resume Next
    basPrintMessage64 "You may not have permission to delete this piece of data or the data cannot be deleted or modified because this data is used by the system."
End Sub
Public Function lFileLen(strFilename As String) As Long
On Error GoTo Err_basFileLen
    Dim lngReturn As Long
    lngReturn = 0
    If (FileLen(strFilename) > 0) Then
        lngReturn = FileLen(strFilename)
    End If
Exit_basFileLen:
    lFileLen = lngReturn
    Exit Function
Err_basFileLen:
    'basPrintMessage64 "lFileLen," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
    Resume Exit_basFileLen
End Function
Public Function basPreceedSize(strOriginal As String, strItem As String, intSize As Integer) As String
'ie. basPreceedSize("2", "0", 5) returns 00002
'See also: strForceSize (more advanced version)
On Error Resume Next
    Dim strReturn As String
    
    strReturn = strOriginal
    
    Do While (Len(strReturn) < intSize)
        strReturn = strItem & strReturn
    Loop
    
    basPreceedSize = strReturn
End Function
Public Function strForceSize(strInfo As Variant, intLen As Integer, strChar As String, strType As String) As String
'Pass:  strInfo for the string to be parsed
'       intLen for length
'       strChar for the character to add to the string if it is less than length.
'       strChar can be of any length or pattern of characters!
'       No trim is used if strChar is a SPACE, in case spaces are required.
'       strType add the character 'B'efore the string or 'A'fter the string.
'See also: basPreceedSize basPreceedSize
On Error Resume Next
    Dim strReturn As String
    
    If (InStr(strChar, " ") > 0) Then
        strReturn = Mid(MyCStr(strInfo), 1, intLen) ' cut from the first position to the forced length position
    Else
        strReturn = Mid(MyCStr(strInfo), 1, intLen) ' trim then cut from the first position to the forced length position
    End If
    
    'If the forced length position is greater than the length of the line then add strChar 'B' or 'A'.
    Do While (Len(strReturn) < intLen)
        Select Case strType
            Case "B" 'Add before the string
                strReturn = strChar & strReturn
            Case Else 'Add after the string
                strReturn = strReturn & strChar
        End Select
    Loop
    
    strForceSize = strReturn
End Function
Public Function basConvertCanadianPhoneNoFormat(strLine As String) As String
On Error Resume Next
' Convert from: 403 488 - 1054 to (403)488-1054
    Dim strWork As String
    strWork = zStripChars(strLine)
    If (Len(strWork) < 7) Then
        strWork = ""
    Else
        strWork = MyCStr("(" & Mid(strWork, 1, 3) & ")" & Mid(strWork, 4, 3) & "-" & Mid(strWork, 7, 4) & " " & Mid(strWork, 11, Len(strWork)))
    End If

    basConvertCanadianPhoneNoFormat = strWork
End Function
Public Function basChar(strLine As String, intPosition As Integer) As String
On Error Resume Next
    basChar = Mid(strLine, intPosition, 1)
End Function
Public Sub basHourglass(intState As Integer)
On Error Resume Next
'intState can be True (on) or False (off).
    If (intState) Then
        Screen.MousePointer = 11 ' Hourglass
    Else
        Screen.MousePointer = 0 ' Normal
    End If
    DoEvents
End Sub
'Public Sub basImportExportWarning()
'On Error Resume Next
'    basPrintMessage64 "JUST A NOTE" & vbCrLf & "==============" & vbCrLf & "The Import directory and the Export Directory MUST be separate directories for the system to automate certain Import/Export processes." & vbCrLf & vbCr & "CURRENT PATHS" & vbCrLf & "===================" & vbCrLf & "EXPORT(" & basStoreExportLocationToMemory(True) & ")" & vbCrLf & "IMPORT(" & basStoreImportLocationToMemory(True) & ")"
'End Sub
'Public Sub basLocateExport()
'On Error Resume Next
'    Dim strGetLine As String
'
'    'This INI holds the location of the Export files. The INI should be'
'    'located in the same directory as the Visual Basic EXE application.''
'
'    'Test Location of the Export INI File. If it doesn't exist create it.
'    If (lFileLen(cstFileNameExport) < 1) Then
'        Open cstFileNameExport For Output As #1
'        Write #1, cststrExportINIInitMessage    ' Write data to file.
'        Write #1, "DO NOT EDIT THIS FILE"    ' Write data to file.
'        Close #1
'    End If
'
'    'Look into cstFileNameExport read the first line and see if the Export Files are there if it isnot then run frmLocateExport
'    'This file exists for sure now since it was just created or is already there.
'    'In the cstFileNameExport the path is in quotes, when it is input #1 the brackets are auto-removed.
'    Open cstFileNameExport For Input As #1
'    Input #1, strGetLine
'    Close #1
'
'    If (Not basDoesDirectoryExist(strGetLine)) Then
'        basPrintMessage64 "Your Export Directory could not be found. Please use the Find Backup Search Form (behind the Main Menu Screen) to locate your Export directory."
'        frmLocateExport.Show 1
'    Else
'        basStoreExportLocationToMemory True
'    End If
'End Sub
'Public Sub basLocateImport()
'On Error Resume Next
'    Dim strGetLine As String
'
'    'This INI holds the location of the Import Files. The INI should be
'    'located in the same directory as the Visual Basic EXE application.
'
'    'Test Location of the Import INI File. If it doesn't exist create it.
'    If (lFileLen(cstFileNameImport) < 1) Then
'        Open cstFileNameImport For Output As #1
'        Write #1, cststrImportINIInitMessage    ' Write data to file.
'        Write #1, "DO NOT EDIT THIS FILE"    ' Write data to file.
'        Close #1
'    End If
'
'    'Look into cstFileNameImport read the first line and see if the Import Files are there if it isnot then run frmLocateImport
'    'This file exists for sure now since it was just created or is already there.
'    'In the cstFileNameImport the path is in quotes, when it is input #1 the brackets are auto-removed.
'    Open cstFileNameImport For Input As #1
'    Input #1, strGetLine
'    Close #1
'
'    If (Not basDoesDirectoryExist(strGetLine)) Then
'        basPrintMessage64 "Your Import Directory could not be found please locate your Import directory."
'        frmLocateImport.Show 1
'    Else
'        basStoreImportLocationToMemory True
'    End If
'End Sub
Public Function instrChop(ByRef strLine As String, strChar As String) As String
On Error Resume Next
    Dim strWork As String
    
    strWork = strLine
    
    strLine = Mid(strWork, InStr(strWork, strChar) + 1, Len(strWork)) ' Chop out
    
    instrChop = Mid(strWork, 1, InStr(strWork, strChar) - 1) ' Pass chopped out part.
End Function
Public Function lInStrIterations(strLine As String, strChar As String) As Integer
On Error Resume Next
    Dim intScan As Integer
    Dim intReturn As Integer
    
    intReturn = 0
    
    For intScan = 1 To Len(strLine)
        If (Mid(strLine, intScan, 1) = strChar) Then
            intReturn = intReturn + 1
        End If
    Next intScan
    
    lInStrIterations = intReturn
End Function
Public Function lInStrOccurance(strOriginal As String, strSearch As String, intOccurance As Integer) As Long
'Pass the Entire string and the Part of the String to be matched.
'This function returns the occurance defined position where strSearch next occurs.
'Use instr to find the first occurance.
'   ie. instr("HELLOALLOLO...","L") returns 3
'       lInStrOccurance("HELLOALLOLO...","L", 4) returns 8
'This is a NON SENSITIVE search. Everything is tested to match at an uppercase level.
'If intOccurance is 1 or less this function behaves the same as instr.
'If the value is not found before intWhereOccurance is done, then ZERO is returned.
'strSearch can be more than just a single letter.
On Error Resume Next
    Dim lngCounter As Long
    Dim lngOriginalLen As Long
    Dim lngSearchLen  As Long
    Dim lngReturn As Long
    Dim strUpperOriginal As String
    Dim strSearchStartLetter As String
    Dim strUpperSearch As String
    Dim intFound As Integer
    Dim intWhereOccurance As Integer 'Works to countdown from intOccurance
    
    intWhereOccurance = intOccurance
    
    lngReturn = 0 ' Init. as String is void of information.
    If (MyCStr(strSearch) <> "?") Then
        strUpperOriginal = UCase(strOriginal)
        strSearchStartLetter = UCase(Mid(strSearch, 1, 1))
        strUpperSearch = UCase(strSearch)
        lngSearchLen = Len(strSearch)
        
        intFound = False
        lngCounter = 1
        lngOriginalLen = Len(strOriginal)
        Do While (lngCounter <= lngOriginalLen) And (intFound = False)
            If ((Mid(strUpperOriginal, lngCounter, 1)) = strSearchStartLetter) Then 'First letter matched!
                If (Mid(strUpperOriginal, lngCounter, lngSearchLen) = strUpperSearch) Then
                    intWhereOccurance = intWhereOccurance - 1
                    If (intWhereOccurance <= 0) Then
                        intFound = True
                        lngReturn = lngCounter ' Lock the position in.
                    End If
                End If
            End If
            
            lngCounter = lngCounter + 1
        Loop
    End If
    lInStrOccurance = lngReturn
End Function
Public Function basRemoveChr1310(strLine As String) As String
On Error Resume Next
    Dim intScan As Integer
    Dim strReturn As String
    Dim strChar As String
    
    For intScan = 1 To Len(strLine)
        strChar = (Mid(strLine, intScan, 1))
        
        If (strChar = vbCr) Then
            strChar = Chr(32)
        End If
        
        If (strChar = vbLf) Then
            strChar = Chr(32)
        End If

        If (strChar <> vbLf) Then 'double checking ;)
            strReturn = strReturn & strChar
        End If
    Next intScan
    
    basRemoveChr1310 = strReturn
End Function
Public Function basRemoveChr10(strLine As String) As String
On Error Resume Next
    Dim intScan As Integer
    Dim strReturn As String
    Dim strChar As String
    
    For intScan = 1 To Len(strLine)
        strChar = (Mid(strLine, intScan, 1))
        
        If (strChar <> Chr(10)) Then
            strReturn = strReturn & strChar
        End If
    Next intScan
    
    basRemoveChr10 = strReturn
End Function
Public Function strRemoveCharacterFromLine(strLine As String, strRemoveThisChar As String) As String
On Error Resume Next
    Dim intScan As Integer
    Dim strReturn As String
    Dim strChar As String
    
    strReturn = ""
    For intScan = 1 To Len(strLine)
        strChar = (Mid(strLine, intScan, 1))
        
        If (strChar <> strRemoveThisChar) Then
            strReturn = strReturn & strChar
        End If
    Next intScan
    
    strRemoveCharacterFromLine = strReturn
End Function
Public Function basRetrieveFilenameFromPath(strPathFileName As String) As String
'Supports 32 bit file lengths
'Pass: C:\WHERE\WOW\HELLO THERE.TXT
'Returns: HELLO THERE.TXT
On Error Resume Next
    Dim strFilename As String
    Dim intScan As Integer
    Dim intPos As Integer
    
    intPos = 1
    strFilename = strPathFileName
    
    For intScan = 1 To Len(strFilename)
        If (Mid(strFilename, intScan, 1) = "\") Then
            intPos = intScan + 1
        End If
    Next intScan
    
    basRetrieveFilenameFromPath = Mid(strFilename, intPos, Len(strFilename))
End Function

Public Function basReturnInDays(strDate As String) As Long
On Error Resume Next
    Dim strHold As String
    Dim lngReturn As Long
    
    strHold = MyCDateMonth(strDate)
    
    lngReturn = (MyCLng(Format(strHold, "dd"))) + (31 * MyCLng(Format(strHold, "mm"))) + (365 * MyCLng(Format(strHold, "yyyy")))
    
    basReturnInDays = lngReturn
End Function
Public Function MyCDateMonth(strValue As String) As String
On Error Resume Next
'ie. 9OCT 97 comes in 9-10-97 goes out
    Dim strReturn As String
    
    strReturn = strValue
    
    strReturn = basReplaceCharWithThisWord(strReturn, " ", "-")
    strReturn = basReplaceCharWithThisWord(strReturn, "/", "-")
    strReturn = strReplaceWordWithThisWord(strReturn, "JAN", "-AAA-")
    strReturn = strReplaceWordWithThisWord(strReturn, "AAA", "-Jan-")
    strReturn = strReplaceWordWithThisWord(strReturn, "FEB", "-BBB-")
    strReturn = strReplaceWordWithThisWord(strReturn, "BBB", "-Feb-")
    strReturn = strReplaceWordWithThisWord(strReturn, "MAR", "-CCC-")
    strReturn = strReplaceWordWithThisWord(strReturn, "CCC", "-Mar-")
    strReturn = strReplaceWordWithThisWord(strReturn, "APR", "-DDD-")
    strReturn = strReplaceWordWithThisWord(strReturn, "DDD", "-Apr-")
    strReturn = strReplaceWordWithThisWord(strReturn, "MAY", "-EEE-")
    strReturn = strReplaceWordWithThisWord(strReturn, "EEE", "-May-")
    strReturn = strReplaceWordWithThisWord(strReturn, "JUN", "-FFF-")
    strReturn = strReplaceWordWithThisWord(strReturn, "FFF", "-Jun-")
    strReturn = strReplaceWordWithThisWord(strReturn, "JUL", "-GGG-")
    strReturn = strReplaceWordWithThisWord(strReturn, "GGG", "-Jul-")
    strReturn = strReplaceWordWithThisWord(strReturn, "AUG", "-HHH-")
    strReturn = strReplaceWordWithThisWord(strReturn, "HHH", "-Aug-")
    strReturn = strReplaceWordWithThisWord(strReturn, "SEP", "-III-")
    strReturn = strReplaceWordWithThisWord(strReturn, "III", "-Sep-")
    strReturn = strReplaceWordWithThisWord(strReturn, "OCT", "-JJJ-")
    strReturn = strReplaceWordWithThisWord(strReturn, "JJJ", "-Oct-")
    strReturn = strReplaceWordWithThisWord(strReturn, "NOV", "-KKK-")
    strReturn = strReplaceWordWithThisWord(strReturn, "KKK", "-Nov-")
    strReturn = strReplaceWordWithThisWord(strReturn, "DEC", "-LLL-")
    strReturn = strReplaceWordWithThisWord(strReturn, "LLL", "-Dec-")
    strReturn = strReplaceWordWithThisWord(strReturn, "--", "-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-1-", "-Jan-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-2-", "-Feb-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-3-", "-Mar-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-4-", "-Apr-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-5-", "-May-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-6-", "-Jun-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-7-", "-Jul-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-8-", "-Aug-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-9-", "-Sep-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-01-", "-Jan-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-02-", "-Feb-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-03-", "-Mar-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-04-", "-Apr-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-05-", "-May-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-06-", "-Jun-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-07-", "-Jul-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-08-", "-Aug-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-09-", "-Sep-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-10-", "-Oct-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-11-", "-Nov-")
    strReturn = strReplaceWordWithThisWord(strReturn, "-12-", "-Dec-")
    
    If (Len(strReturn) < 4) Then
        strReturn = " "
    End If
    
    MyCDateMonth = Trim(strReturn)
End Function
Public Function MyCStrTBD(varValue As Variant) As String
On Error Resume Next
    Dim strReturn As String
    strReturn = MyCStr(Trim(MyCStr(varValue))) ' This can be as length as 15 characters.
    If (strReturn = "?") Then
        strReturn = "TBD"
    End If
    MyCStrTBD = strReturn
End Function
Public Function lCountOfChar(zLine As String, zChar As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Dim lCount As Long
    lReturn = 0
    For lCount = 1 To Len(zLine)
        If (Mid(zLine, lCount, 1) = zChar) Then
            lReturn = lReturn + 1
        End If
    Next lCount
    lCountOfChar = lReturn
End Function
Public Function basReturnQuarter(strMonthOrFullDate As String) As String
On Error Resume Next
' Returns the Quarter of the year as 'First', 'Second', 'Third', 'Fourth'...
    Dim intQuarter As Integer
    Dim strReturn As String

    intQuarter = Format(strMonthOrFullDate, "q")
    
    ' These below were just tests.
'    If (instr(strMonthOrFullDate, "Jan") > 0) Then
'        intQuarter = 1
'    End If
    
'    If (instr(strMonthOrFullDate, "Feb") > 0) Then
'        intQuarter = 1
'    End If
    
'    If (instr(strMonthOrFullDate, "Mar") > 0) Then
'        intQuarter = 1
'    End If
    
'    If (instr(strMonthOrFullDate, "Apr") > 0) Then
'        intQuarter = 2
'    End If
    
'    If (instr(strMonthOrFullDate, "May") > 0) Then
'        intQuarter = 2
'    End If
    
'    If (instr(strMonthOrFullDate, "Jun") > 0) Then
'        intQuarter = 2
'    End If
    
'    If (instr(strMonthOrFullDate, "Jul") > 0) Then
'        intQuarter = 3
'    End If
    
'    If (instr(strMonthOrFullDate, "Aug") > 0) Then
'        intQuarter = 3
'    End If
    
'    If (instr(strMonthOrFullDate, "Sep") > 0) Then
'        intQuarter = 3
'    End If
    
'    If (instr(strMonthOrFullDate, "Oct") > 0) Then
'        intQuarter = 4
'    End If
    
'    If (instr(strMonthOrFullDate, "Nov") > 0) Then
'        intQuarter = 4
'    End If
    
'    If (instr(strMonthOrFullDate, "Dec") > 0) Then
'        intQuarter = 4
'    End If
    
    Select Case intQuarter
        Case 1
            strReturn = "First"
        Case 2
            strReturn = "Second"
        Case 3
            strReturn = "Third"
        Case 4
            strReturn = "Fourth"
    End Select
    
    basReturnQuarter = strReturn
End Function
Public Function zStripDesignatedChars(strLine As String, zRemoveTheseChars As String) As String
On Error Resume Next
' Pass: ("BECAUSE!!!", "SUCA!") will return 'BEE'
' Order of these letters does not matter.
    Dim intLength As Integer
    Dim intPosition As Integer
    Dim strWork As String
    
    strWork = strLine
    intLength = Len(strWork)
    intPosition = 1
    
    Do While (intPosition <= intLength)
        If (InStr(zRemoveTheseChars, basChar(strWork, intPosition)) > 0) Then
            strWork = Mid(strWork, 1, intPosition - 1) & Mid(strWork, intPosition + 1, intLength)
            intPosition = 1: intLength = Len(strWork)
        Else
            intPosition = intPosition + 1
        End If
    Loop
    zStripDesignatedChars = strWork
End Function
Public Function basReplaceCharWithThisWord(strLine As String, strRemoveThisChar As String, strReplaceWithThisWord As String) As String
On Error Resume Next
' Pass: ("HELLO & THERE", "&", "AND") will return 'HELLO AND THERE'
' Pass your entire phrase you want to find and replace from.
' A word CAN be just a single character too.
    Dim intLength As Integer
    Dim intPosition As Integer
    Dim strWork As String
    
    strWork = strLine
    intLength = Len(strWork)
    intPosition = 1
    
    If (strRemoveThisChar <> strReplaceWithThisWord) Then
        Do While (intPosition <= intLength And InStr(strWork, strRemoveThisChar) > 0)
            If (InStr(strWork, strRemoveThisChar) > 0) Then
                intPosition = InStr(strWork, strRemoveThisChar)
                If (intPosition > 0) Then
                    strWork = Mid(strWork, 1, intPosition - 1) & Mid(strWork, intPosition + Len(strRemoveThisChar)) 'delete out the word marked to be replaced.
                    strWork = Mid(strWork, 1, intPosition - 1) & strReplaceWithThisWord & Mid(strWork, intPosition, intLength)
                End If
                intLength = Len(strWork)
            Else
                intPosition = intPosition + 1
            End If
        Loop
    End If
    
    basReplaceCharWithThisWord = strWork
End Function
Public Function strReplaceWordWithThisWord(strLine As String, strRemoveThisWord As String, strReplaceWithThisWord As String, Optional bCaseSensitive As Boolean) As String
On Error Resume Next
' Pass: ("HELLO & THERE", "&", "AND") will return 'HELLO AND THERE'
' Pass your entire phrase you want to find and replace from.
' A word CAN be just a single character too.
    Dim lLength As Long
    Dim lPos As Long
    Dim lPosStart As Long
    Dim lPosEnd As Long
    Dim zOriginal As String
    Dim zWork As String
    Dim zCaseSensitive As String
    
    zOriginal = strLine
    Select Case (bCaseSensitive)
        Case True
            zCaseSensitive = strRemoveThisWord
            zWork = zOriginal
        Case Else
            zWork = UCase(zOriginal)
            zCaseSensitive = UCase(strRemoveThisWord)
    End Select
    
    If (strReplaceWithThisWord = "") Or (InStr(zCaseSensitive, strReplaceWithThisWord) = 0 And InStr(strReplaceWithThisWord, zCaseSensitive) = 0) Then
        If (InStr(zWork, zCaseSensitive) > 0 And Len(zCaseSensitive) > 0) Then
            lLength = Len(zWork)
            Do While (InStr(zWork, zCaseSensitive) > 0)
                lPos = InStr(zWork, zCaseSensitive)
                lPosStart = (lPos - 1): If (lPosStart < 0) Then lPosStart = 1
                lPosEnd = (lPos + Len(strRemoveThisWord))
                
                zWork = Mid(zWork, 1, lPosStart) & strReplaceWithThisWord & Mid(zWork, lPosEnd)
                zOriginal = Mid(zOriginal, 1, lPosStart) & strReplaceWithThisWord & Mid(zOriginal, lPosEnd)
                lLength = Len(zWork)
            Loop
        End If
    End If
    strReplaceWordWithThisWord = zOriginal
End Function
Public Function strTrimEOLMatching(strLine As String, strPassEOLChopOut As String, strReplaceWithThisWord As String, Optional bCaseSensitive As Boolean) As String
On Error Resume Next
' Pass: ("HELLO & THERE", "&", "AND") will return 'HELLO AND THERE'
' Pass your entire phrase you want to find and replace from.
' A word CAN be just a single character too.
    Dim lLength As Long
    Dim lPos As Long
    Dim lPosStart As Long
    Dim lPosEnd As Long
    Dim zOriginal As String
    Dim zWork As String
    Dim zCaseSensitive As String
    Dim strEOLChopOut As String
    
    strEOLChopOut = Trim(strPassEOLChopOut) & "  "
    
    zOriginal = Trim(strLine) & "  "
    Select Case (bCaseSensitive)
        Case True
            zCaseSensitive = strEOLChopOut
            zWork = zOriginal
        Case Else
            zWork = UCase(zOriginal)
            zCaseSensitive = UCase(strEOLChopOut)
    End Select
    
    If (strReplaceWithThisWord = "") Or (InStr(zCaseSensitive, strReplaceWithThisWord) = 0 And InStr(strReplaceWithThisWord, zCaseSensitive) = 0) Then
        If (InStr(zWork, zCaseSensitive) > 0 And Len(zCaseSensitive) > 0) Then
            lLength = Len(zWork)
            Do While (InStr(zWork, zCaseSensitive) > 0)
                lPos = InStr(zWork, zCaseSensitive)
                lPosStart = (lPos - 1): If (lPosStart < 0) Then lPosStart = 1
                lPosEnd = (lPos + Len(strEOLChopOut))
                
                zWork = Mid(zWork, 1, lPosStart) & strReplaceWithThisWord & Mid(zWork, lPosEnd)
                zOriginal = Mid(zOriginal, 1, lPosStart) & strReplaceWithThisWord & Mid(zOriginal, lPosEnd)
                lLength = Len(zWork)
            Loop
        End If
    End If
    strTrimEOLMatching = zOriginal
End Function
Public Function zStripChars(strValue As String) As String
On Error Resume Next
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    
    strHoldValue = MyCStr(strValue)
    
    intLen = Len(Trim(strHoldValue))
    strStore = ""
    For lngCounter = 1 To intLen
        If (IsNumeric(Mid(strHoldValue, lngCounter, 1))) Then
            strStore = strStore & Mid(strHoldValue, lngCounter, 1)
        End If
    Next lngCounter
    zStripChars = strStore
End Function
Public Function zKeepNumbersOnly(strValue As String) As String
On Error Resume Next
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    
    strHoldValue = MyCStr(strValue)
    intLen = Len(Trim(strHoldValue))
    strStore = ""
    For lngCounter = 1 To intLen
        Select Case UCase(Mid(strHoldValue, lngCounter, 1))
            Case "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "-"
                strStore = strStore & Mid(strHoldValue, lngCounter, 1)
        End Select
    Next lngCounter
    zKeepNumbersOnly = strStore
End Function
Public Function zKeepRealNumbersOnly(strValue As String) As String
On Error Resume Next
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    
    strHoldValue = MyCStr(strValue)
    intLen = Len(Trim(strHoldValue))
    strStore = ""
    For lngCounter = 1 To intLen
        Select Case UCase(Mid(strHoldValue, lngCounter, 1))
            Case "1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "."
                strStore = strStore & Mid(strHoldValue, lngCounter, 1)
        End Select
    Next lngCounter
    zKeepRealNumbersOnly = strStore
End Function
Public Function zKeepRandomSentence(strValue As String) As String
On Error Resume Next
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim zReturn As String
    Dim iCounter As Integer
    Dim iLen As Integer
    Dim iTotalSpaces As Integer
    Dim iSelected As Integer
    Dim iStart As Integer
    Dim iStop As Integer
    Dim zMsg As String
    
    
    zReturn = MyCStr(strValue)
    
    If (InStr(zReturn, ".") > 0 Or InStr(zReturn, "!") > 0) Then
        iTotalSpaces = 0
        
        iLen = Len(zReturn)
        
        'We count up the total amount of sentences
        For iCounter = 1 To iLen
            If (Mid(zReturn, iCounter, 1) = "." Or Mid(zReturn, iCounter, 1) = "!") Then
                iTotalSpaces = iTotalSpaces + 1
            End If
        Next iCounter
        
        Select Case iTotalSpaces
            Case 0
            Case Else
                iStart = 1
                iStop = 0
                iSelected = lRandom(MyCLng(iTotalSpaces - 1))
                If (iSelected < 1) Then iSelected = 1
                
                'Find the first position
                For iCounter = 2 To iLen
                    If (iSelected > 0) Then
                        If (Mid(zReturn, iCounter, 1) = "." Or Mid(zReturn, iCounter, 1) = "!") Then
                            iSelected = iSelected - 1
                            If (lRandom(5) > 3) Then iStart = iCounter
                        End If
                    End If
                Next iCounter
                
                'Find the second position - first space after the starting space at start
                iStop = iLen
                For iCounter = iStart + 1 To iLen
                    If (Mid(zReturn, iCounter, 1) = "." Or Mid(zReturn, iCounter, 1) = "!") Then
                        If (iStop = iLen) Then iStop = (iCounter - iStart)
                    End If
                Next iCounter
                
                zMsg = Mid(zReturn, iStart, iStop + 1)
                If (Len(zMsg) > 0) Then
                    If (Mid(zMsg, 1, 2) = ". ") Then
                        zMsg = Mid(zMsg, 3)
                    End If
                    zReturn = zMsg
                End If
        End Select
    End If
    zKeepRandomSentence = zReturn
End Function
Public Function strAllowOnlyOneSpace(strValue As String) As String
On Error Resume Next 'see also zKeepLettersOnly
' What this code does is removes double spaces to single spacing, ie. h e  ll    o = h e ll o
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    Dim iSpace As Integer
    
    strHoldValue = MyCStr(strValue)
    intLen = Len(strHoldValue)
    strStore = "": iSpace = 0
    For lngCounter = 1 To intLen
        Select Case Mid(strHoldValue, lngCounter, 1)
            Case " "
                iSpace = iSpace + 1
            Case Else
                iSpace = 0
        End Select
        If (iSpace < 2) Then strStore = strStore & Mid(strHoldValue, lngCounter, 1)
    Next lngCounter
    strAllowOnlyOneSpace = strStore
End Function
Public Function zKeepLettersOnly(strValue As String, Optional zOptionalChar As String) As String
On Error Resume Next 'see also strAllowOnlyOneSpace
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    
    strHoldValue = MyCStr(strValue)
    intLen = Len(strHoldValue)
    strStore = ""
    For lngCounter = 1 To intLen
        Select Case UCase(Mid(strHoldValue, lngCounter, 1))
            Case "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", zOptionalChar
                strStore = strStore & Mid(strHoldValue, lngCounter, 1)
        End Select
    Next lngCounter
    zKeepLettersOnly = strStore
End Function
Public Function zKeepLettersLightAscii(strValue As String) As String
On Error Resume Next
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    
    strHoldValue = MyCStr(strValue)
    intLen = Len(Trim(strHoldValue))
    strStore = ""
    For lngCounter = 1 To intLen
        Select Case UCase(Mid(strHoldValue, lngCounter, 1))
            Case " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "!", ".", "*", "%", "#", "@", ".", "?", "<", ">", "[", "]", "|", ":", ",", ";", "(", ")"
                strStore = strStore & Mid(strHoldValue, lngCounter, 1)
        End Select
    Next lngCounter
    zKeepLettersLightAscii = strStore
End Function
Public Function zKeepLettersNumbersAscii(strValue As String) As String
On Error Resume Next
' What this code does is removes all the letters from strValue
' leaving only the numbers.
    Dim strHoldValue As String
    Dim strStore As String
    Dim lngCounter As Long
    Dim intLen As Integer
    
    strHoldValue = MyCStr(strValue)
    intLen = Len(Trim(strHoldValue))
    strStore = ""
    For lngCounter = 1 To intLen
        Select Case UCase(Mid(strHoldValue, lngCounter, 1))
            Case "-", " ", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
                strStore = strStore & Mid(strHoldValue, lngCounter, 1)
        End Select
    Next lngCounter
    zKeepLettersNumbersAscii = strStore
End Function
Public Function MyCInt(varValue As Variant) As Integer
'CInt by itself is not reliable when dealing with NULL values. So here is my version.
On Error Resume Next
    Dim intValue As Long

    intValue = 0
    If (IsNumeric(varValue) And (Len(varValue) > 0)) Then ' Numbers only! IsNumeric Covers Nulls and all String Text (mixed with #'s too).
        intValue = CInt(varValue)
    End If
    MyCInt = intValue
End Function
Public Function MyCLng(varValue As Variant) As Long
' CLng by itself is not reliable when dealing with NULL values. So here is my version.
'This routien will handle any leading or ending spaces! We do not need to remove any weird spaces, cool!
On Error GoTo Err_MyCLng
    Dim zValue As String
    Dim lngValue As Long

    'MsgBox "IsNumeric = " & IsNumeric(varValue) & " Length = " & Len(varValue) & " Value = " & varValue

    lngValue = 0
    
    If (IsNumeric(varValue) And (Len(varValue) > 0)) Then ' Numbers only! IsNumeric Covers Nulls and all String Text (mixed with #'s too). Len(varValue) < 11 prevents a number overflow
        zValue = MyCStr(varValue)
        'If InStr(zValue, ".") Then zValue = Mid(zValue, 1, InStr(zValue, ".") - 1)
        Select Case UCase(zValue)
            Case "FALSE"
                zValue = 0
            Case "TRUE"
                zValue = -1
        End Select
        'If (Len(zValue) < 10 Or InStr(zValue, "-")) Then lngValue = CLng(zValue)
        lngValue = CLng(zValue)
    End If
    MyCLng = lngValue
Exit_Err_MyCLng:
    Exit Function
Err_MyCLng:
    MyCLng = 0
    Resume Exit_Err_MyCLng
End Function
Public Function MyCStr(varValue As Variant) As String
' CStr by itself is not reliable when dealing with NULL values. So here is my version.
On Error GoTo Err_MyCStr
    Dim strValue As String

    strValue = ""
    If (Not (IsNull(varValue))) Then 'If you get a no record error then you need on error in this function
        If (Len(varValue) > 0) Then
            strValue = CStr(Trim(varValue))
        End If
    End If
    MyCStr = strValue
Exit_Err_MyCStr:
    Exit Function
Err_MyCStr:
    Resume Exit_Err_MyCStr
End Function
Public Function MyCSng2D(varValue As Variant) As String
' CSng by itself is not reliable when dealing with NULL values. So here is my version.
' Consider using Format(MyCSng(<varValue>), "###0.00") to control the output for currency.
'Returns a string wuth a two decimal format.
    Dim strReturn  As String
    
    strReturn = MyCStr(Format(MyCSng(varValue), "###0.00"))
        
    MyCSng2D = strReturn
End Function
Public Function MyCSng(varValue As Variant) As Single
' CSng by itself is not reliable when dealing with NULL values. So here is my version.
' Consider using Format(MyCSng(<varValue>), "###0.00") to control the output for currency.
On Error GoTo Err_MyCSng
    Dim sngValue As Single

    sngValue = 0
    If (IsNumeric(varValue) And (Len(varValue) > 0)) Then ' Numbers only! IsNumeric Covers Nulls and all String Text (mixed with #'s too).
        sngValue = CSng(varValue)
    End If
    MyCSng = sngValue
Exit_Err_MyCSng:
    Exit Function
Err_MyCSng:
    Resume Exit_Err_MyCSng
End Function
Public Function MyCDbl(varValue As Variant) As Double
' CDbl by itself is not reliable when dealing with NULL values. So here is my version.
On Error GoTo Err_MyCDbl
    Dim dblValue As Double
    dblValue = 0
    If (IsNumeric(varValue) And (Len(varValue) > 0)) Then ' Numbers only! IsNumeric Covers Nulls and all String Text (mixed with #'s too).
        dblValue = CDbl(varValue)
    End If
    MyCDbl = dblValue
Exit_Err_MyCDbl:
    Exit Function
Err_MyCDbl:
    Resume Exit_Err_MyCDbl
End Function
Public Function basConvertRate(sngRate As Double) As String
' CSng by itself is not reliable when dealing with NULL values. So here is my version.
On Error GoTo Err_MyCSng
    Const constMaxDecimalPlaces = 5
    Dim strValue As String
    Dim intLen As Integer
    strValue = "0.00"
    strValue = Format(sngRate)
    If (InStr(strValue, ".") > 0) Then
        Do While Len(Mid(strValue, InStr(strValue, ".") + 1, Len(strValue))) < 2
            strValue = strValue & "0"
        Loop
        Do While Len(Mid(strValue, InStr(strValue, ".") + 1, Len(strValue))) > constMaxDecimalPlaces
            strValue = Mid(strValue, 1, Len(strValue) - 1)
        Loop
    Else
        strValue = strValue & ".00"
    End If
    basConvertRate = strValue
Exit_Err_MyCSng:
    Exit Function
Err_MyCSng:
    Resume Exit_Err_MyCSng
End Function
Public Function MyCTimeSimply(strValue As String) As Variant
On Error Resume Next
'Pass: strValue as hh:nn (24 hour hour and 2 digit minute)
'           but strValue must have 4 numbers in it.
'See Also, basStructureDate(), MyCDate(), MyCDateSimply()
    Dim intCount As Integer
    Dim strProcess As String

    strProcess = ""
    
    'strp out everything but keep the numbers
    For intCount = 1 To Len(strValue)
        If (IsNumeric(Mid(strValue, intCount, 1))) Then
            strProcess = strProcess & Mid(strValue, intCount, 1)
        End If
    Next intCount
    
    'Handle over hour
    If (MyCLng(Mid(strProcess, 1, 2)) > 23) Then
        strProcess = "00" & Mid(strProcess, 3, 2)
    End If
    
    'Handle over minute
    If (MyCLng(Mid(strProcess, 3, 2)) > 59) Then
        strProcess = Mid(strProcess, 1, 2) & "00"
    End If
    
    'Show any date errors
    Do While Len(strProcess) < 4
        strProcess = "0" & strProcess
    Loop
    
    strProcess = Mid(strProcess, 1, 2) & ":" & Mid(strProcess, 3, 2)
    
    MyCTimeSimply = strProcess
End Function
Public Function MyCDateSimply(strValue As String) As Variant
On Error Resume Next
'Pass: strValue as mm-dd-yyyy or dd-mm-yyyy or even mm/dd/yyyy or dd/mm/yyyy
'           but strValue must have 8 numbers in it.
'See Also, basStructureDate(), MyCDate()
    Dim intCount As Integer
    Dim strProcess As String
    Dim intOkay As Integer
 
    strProcess = ""
    
    If (Len(MyCStr(strValue)) > 0) Then
        'strip out everything but keep the numbers
        For intCount = 1 To Len(strValue)
            If (IsNumeric(Mid(MyCStr(strValue), intCount, 1))) Then
                strProcess = strProcess & Mid(MyCStr(strValue), intCount, 1)
            End If
        Next intCount
        
        strProcess = Mid(strProcess, 1, 10)
        intOkay = False
        
        Select Case Len(strProcess)
        Case 6
            strProcess = Mid(strProcess, 1, 4) & Mid(Format(Date, "yyyy"), 1, 2) & Mid(strProcess, 5, 2)
            intOkay = True
        Case 8
            intOkay = True
        Case Else
            strProcess = ""
        End Select
        
        If (intOkay) Then
            If (MyCInt(Mid(strProcess, 1, 2)) < 1) Or (MyCInt(Mid(strProcess, 1, 2)) > 12) Then
                strProcess = "01" & Mid(strProcess, 3, 2) & Mid(strProcess, 5, 4)
            End If
            
            If (MyCInt(Mid(strProcess, 3, 2)) < 1) Or (MyCInt(Mid(strProcess, 3, 2)) > 31) Then
                strProcess = Mid(strProcess, 1, 2) & "01" & Mid(strProcess, 5, 4)
            End If
            
            If (MyCLng(Trim(Mid(strProcess, 5, 4))) < 1000) Then
                strProcess = Mid(strProcess, 1, 2) & Mid(strProcess, 3, 2) & Format(Date, "yyyy")
            End If
            
            strProcess = Mid(strProcess, 1, 2) & "-" & Mid(strProcess, 3, 2) & "-" & Mid(strProcess, 5, 4)
        End If
    End If
    
    If (Not IsDate(strProcess)) Then
        strProcess = ""
    End If
    
    MyCDateSimply = strProcess
End Function
Public Function MyCDate(strValue As Variant) As Variant
' Date by itself is not reliable when dealing with NULL values. So here is my version.
' This routien is used for reports, MyCDateTextBox is used for users.
' The only difference between the two is that MyCDateTextBox returns
' "Invalid Date" for the user to see, which would be annoying if dates
' were invalid when creating reports.
'See Also, basStructureDate() and basMyCDateSimply()
On Error Resume Next
    Dim strReturn As String
    Dim DD As String
    Dim MM As String
    Dim YYYY As String
    Dim intOkay As Integer
    
    strReturn = MyCStr(strValue)
    intOkay = 1
    If (Not IsNumeric(Mid(strReturn, 1, 1))) Or (Not IsNumeric(Mid(strReturn, Len(strReturn) - 1, 1))) Then
        intOkay = 2
    End If
    
    If (Len(strReturn) < 3) Then
        intOkay = 2
    End If
    
    If (intOkay = 1) Then
        strReturn = MyCDateMonth(strReturn)
        
        DD = Mid(strReturn, 1, lInStrOccurance(strReturn, "-", 1) - 1)
        MM = Mid(strReturn, lInStrOccurance(strReturn, "-", 1) + 1, (lInStrOccurance(strReturn, "-", 2)) - (lInStrOccurance(strReturn, "-", 1) + 1))
        YYYY = Mid(strReturn, lInStrOccurance(strReturn, "-", 2) + 1, Len(strReturn))
        
        'MsgBox "DD(" & DD & ") MM(" & MM & ") YY(" & YYYY & ")"
        
        If (MyCStr(DD) = "?") Then
            DD = "01"
        End If
        
        If (MyCStr(MM) = "?") Then
            MM = "01"
        End If
        
        If (MyCStr(YYYY) = "?") Then
            YYYY = "2000"
        End If

        'Support year 2000 method, in an advanced method!
        If (Len(YYYY) <= 2) Then
            If (Mid(Format(Date, "YYYY"), 1, 2) = "19") Then
                If (MyCLng(YYYY) < 50) Then
                    YYYY = "20" & YYYY
                Else
                    YYYY = "19" & YYYY
                End If
            Else
                YYYY = Mid(Format(Date, "YYYY"), 1, 2) & YYYY
            End If
        End If
        
        Do While (Len(YYYY) < 4)
            YYYY = YYYY & "0"
        Loop
        
        Do While (Len(DD) < 2)
            DD = "0" & DD
        Loop
        
        strReturn = DD & " " & MM & " " & YYYY ' Format Preparation.
    End If
    
    If (strReturn = "1Jan 1900") And (Len(Trim(strReturn)) < 4) Then
        strReturn = ""
    End If
    
    If (Not IsDate(Format(MyCDateMonth(strReturn), "dd-mm-yyyy"))) Then
        'MsgBox "Converted(" & strReturn & ") = Formatted(" & Format(MyCDateMonth(strReturn), "dd-mm-yyyy") & ") IsDate = " & IsDate(Format(MyCDateMonth(strReturn), "dd-mm-yyyy"))
        strReturn = ""
    End If
    
    MyCDate = strReturn
End Function
Public Function basStructureDate(strValue As String) As String
On Error Resume Next
'See also, MyCDate()
'                 MyCDateSimply()
    Dim strReturn As Variant
    
    strReturn = zStripChars(strValue)
    
    Select Case Len(strReturn)
        Case 6
            strReturn = "0" & Mid(strReturn, 1, 1) & "-0" & Mid(strReturn, 2, 1) & "-" & Mid(strReturn, 3)
        Case 7
            strReturn = "0" & Mid(strReturn, 1, 1) & "-" & Mid(strReturn, 2, 2) & "-" & Mid(strReturn, 4)
        Case 8
            strReturn = Mid(strReturn, 1, 2) & "-" & Mid(strReturn, 3, 2) & "-" & Mid(strReturn, 5)
    End Select
    
    basStructureDate = strReturn
End Function
Public Function MyCDateTextBox(strValue As String) As Variant
' Date by itself is not reliable when dealing with NULL values. So here is my version.
' This routien is used for reports, MyCDateTextBox is used for users.
' The only difference between the two is that MyCDateTextBox returns
' "Invalid Date" for the user to see, which would be annoying if dates
' were invalid when creating reports.
On Error Resume Next
    Dim strReturn As String
    Dim DD As String
    Dim MM As String
    Dim YYYY As String
    Dim intOkay As Integer
    
    strReturn = MyCStr(strValue)
    
    If (strReturn <> "") Then
        intOkay = 1
        If (Not IsNumeric(Mid(strReturn, 1, 1))) Or (Not IsNumeric(Mid(strReturn, Len(strReturn) - 1, 1))) Then
            intOkay = 2
        End If
        
        If (Len(strReturn) < 3) Then
            intOkay = 2
        End If
        
        If (intOkay = 1) Then
            strReturn = MyCDateMonth(strReturn)
            
            DD = Mid(strReturn, 1, lInStrOccurance(strReturn, "-", 1) - 1)
            MM = Mid(strReturn, lInStrOccurance(strReturn, "-", 1) + 1, (lInStrOccurance(strReturn, "-", 2)) - (lInStrOccurance(strReturn, "-", 1) + 1))
            YYYY = Mid(strReturn, lInStrOccurance(strReturn, "-", 2) + 1, Len(strReturn))
            
            'MsgBox "DD(" & DD & ") MM(" & MM & ") YY(" & YYYY & ")"
            
            If (MyCStr(DD) = "?") Then
                DD = "01"
            End If
            
            If (MyCStr(MM) = "?") Then
                MM = "01"
            End If
            
            If (MyCStr(YYYY) = "?") Then
                YYYY = "2000"
            End If
            
            'Support year 2000 method, in an advanced method!
            If (Len(YYYY) <= 2) Then
                If (Mid(Format(Date, "YYYY"), 1, 2) = "19") Then
                    If (MyCLng(YYYY) < 50) Then
                        YYYY = "20" & YYYY
                    Else
                        YYYY = "19" & YYYY
                    End If
                Else
                    YYYY = Mid(Format(Date, "YYYY"), 1, 2) & YYYY
                End If
            End If
            
            Do While (Len(YYYY) < 4)
                YYYY = YYYY & "0"
            Loop
            
            Do While (Len(DD) < 2)
                DD = "0" & DD
            Loop
            
            strReturn = DD & " " & MM & " " & YYYY ' Format Preparation.
        End If
        
        If (strReturn = "01-01-1900") And (Len(Trim(strReturn)) < 4) Then
            strReturn = ""
        End If
        
        If (Not IsDate(Format(MyCDateMonth(strReturn), "dd-mm-yyyy"))) Then
            basPrintMessage64 "Invalid Date, please use the Day, Month, 4 digit Year Format."
            strReturn = ""
        End If
    End If
    MyCDateTextBox = strReturn
End Function
Public Function MyCTime(varValue As Variant) As Variant
'Time by itself is not reliable when dealing with NULL values. So here is my version.
On Error GoTo Err_MyCTime
    Dim varVal As Variant

    varVal = Format("0:0", "hh:nn") ' Just to make sure it is formatted by other versions of Access Properly.
    If (Not (IsNull(varValue))) Then
        varVal = Format(varValue, "hh:nn")
        Do While (Len(varVal) > 0 And Not IsNumeric(Mid(varVal, 1, 1)))
            varVal = Mid(varVal, 2)
        Loop
        
        Do While (Len(varVal) > 0 And Not IsNumeric(Mid(varVal, Len(varVal), 1)))
            varVal = Mid(varVal, 1, Len(varVal) - 1)
        Loop
        
        If (Len(varVal) <= 0) Then
            varVal = Format("0:0", "hh:nn")
        End If
        
        If (MyCInt(Mid(MyCStr(varVal), 1, 2)) > 23) Then
            varVal = "23:" & Mid(MyCStr(varVal), 4, 2)
        End If
        
        If (MyCInt(Mid(MyCStr(varVal), 4, 2)) > 59) Then
            varVal = Mid(MyCStr(varVal), 1, 2) & ":59"
        End If
    End If
    MyCTime = MyCStr(varVal)
Exit_Err_MyCTime:
    Exit Function
Err_MyCTime:
    Resume Exit_Err_MyCTime
End Function
Public Sub basRetrieveFilenameAndPath(strFileBoth As String, ByRef strFilename As String, ByRef strFilePath As String)
On Error GoTo Err_basRetrieveFilenameAndPath
' Send through: strFileBoth as "C:\TEMP1\TEMP2\FILENAME.EXE
' Returns: strFileName as FILENAME.EXE
' Returns: strFilePath as C:\TEMP1\TEMP2
    Dim intNotFound As Integer
    Dim lngEnd As Long
    
    strFileBoth = strFileBoth
    lngEnd = Len(strFileBoth)
    intNotFound = True
    Do While (lngEnd > 0 And intNotFound)
        If (Mid(strFileBoth, lngEnd, 1) = "\") Then
            intNotFound = False
        Else
            lngEnd = lngEnd - 1
        End If
    Loop
    
    strFilename = UCase(Mid(strFileBoth, lngEnd + 1, Len(strFileBoth)))
    strFilePath = UCase(Mid(strFileBoth, 1, lngEnd - 1))
    Exit Sub
Err_basRetrieveFilenameAndPath:
    Resume Next
End Sub
Public Sub basGenericError(lngErr As Long, strError As String)
On Error Resume Next
    Select Case lngErr
        Case 3022
            basPrintMessage64 "Please fill out all areas of this form, try placing a nonsence value in some text boxes just to give the field a value."
        Case 3421
            basPrintMessage64 "One of the values that you entered into a field does not correspond to its format. This usually happens when a string is entered into a numbers only field."
        Case Else
            basPrintMessage64 "MISCELLANEOUS ERROR " & strError & " (" & lngErr & ")"
    End Select
End Sub
'Public Sub basLocateDatabase()
'On Error Resume Next
'    Dim strGetLine As String
'
'    'This INI holds the location of the Access database. The INI should be
'    'located in the same directory as the Visual Basic EXE application.
'
'    'Test Location of MDB Location File. If it doesn't exist create it.
'    If (lFileLen(cstFileNameMDB) < 1) Then
'        Open cstFileNameMDB For Output As #1
'        Write #1, cststrMDBINIInitMessage    ' Write data to file.
'        Write #1, "DO NOT EDIT THIS FILE"    ' Write data to file.
'        Close #1
'    End If
'
'    'Look into cstFileName read the first line and see if the MDB is there if it isnot then run frmLocateMDB
'    'This file exists for sure now since it was just created or is already there.
'    ' In the cstFileName the path is in quotes, when it is input #1 the brackets are auto-removed.
'    Open cstFileNameMDB For Input As #1
'    Input #1, strGetLine
'    Close #1
'
'    If (lFileLen(strGetLine) < 1) Then
'        basPrintMessage64 "Your Access database could not be found. Please use the Find Database Search Form (behind the Main Menu Screen) to locate your database."
'        frmLocateMDB.Show 1 'basStoreMDBLocationToMemory() is on unload of this form.
'    Else
'        basStoreMDBLocationToMemory()
'    End If
'End Sub
'Public Sub basLocateReports()
'On Error Resume Next
'    Dim strGetLine As String
'
'    'This INI holds the location of the Reports. The INI should be
'    'located in the same directory as the Visual Basic EXE application.
'
'    'Test Location of the Report INI File. If it doesn't exist create it.
'    If (lFileLen(cstFileNameRPT) < 1) Then
'        Open cstFileNameRPT For Output As #1
'        Write #1, cststrRPTINIInitMessage    ' Write data to file.
'        Write #1, "DO NOT EDIT THIS FILE"    ' Write data to file.
'        Close #1
'    End If
'
'    'Look into cstFileNameRPT read the first line and see if the Reports are there if it isnot then run frmLocateRPT
'    'This file exists for sure now since it was just created or is already there.
'    'In the cstFileNameRPT the path is in quotes, when it is input #1 the brackets are auto-removed.
'    Open cstFileNameRPT For Input As #1
'    Input #1, strGetLine
'    Close #1
'
'    If (Not basDoesDirectoryExist(strGetLine)) Then
'        basPrintMessage64 "Your Reports Directory could not be found. Please use the Find Reports Search Form (behind the Main Menu Screen) to locate your report directory."
'        frmLocateRPT.Show 1
'    Else
'        basStoreRPTLocationToMemory True
'    End If
'End Sub
Public Sub basPrintMessage64(strMsg As String)
On Error Resume Next
    basHourglass False
    MsgBox strMsg, 64, "APPLICATION PAUSED"
End Sub
Public Sub basHelpMessage64(strMsg As String)
On Error Resume Next
    basHourglass False
    MsgBox strMsg, 64, "Quick Help"
End Sub
Public Function basMessage36(strMsg As String) As Integer
On Error Resume Next
    basHourglass False
    basMessage36 = (MsgBox(strMsg, 36, "Advanced Dungeon Solutions") = 6)
End Function
Public Function basStoreMDBLocationToMemory() As String
    basStoreMDBLocationToMemory = App.Path & "\coaserver.mdb"
End Function
Public Sub basRunSQL(strSQLLine As String)
On Error Resume Next
    MyDB.Execute strSQLLine
End Sub
Public Function strRemoveOperativeChars(strLine As String) As String
On Error Resume Next
    Dim intScan As Integer
    Dim strReturn As String
    Dim strChar As String
    
    strReturn = ""
    
    For intScan = 1 To Len(strLine)
        strChar = Mid(strLine, intScan, 1)
        If (Not bAmong(strChar, "`", "'", """", "~", "_", "+", "-", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", ".")) Then
            strReturn = strReturn & strChar
        End If
    Next intScan
    
    strRemoveOperativeChars = strReturn
End Function
Public Function lRandomHalf(lngRandomNumberHalf As Long) As Long
'Randomizes from 1 to up to only half of lngRandomNumber then adds the other half in as a base value
On Error Resume Next
    Dim lCalcu As Long
    lCalcu = MyCLng(lngRandomNumberHalf / 2)
    lRandomHalf = lRandom(lCalcu) + MyCLng(lCalcu)
End Function
Public Function lRandom(lngRandomNumber As Long) As Long
'Randomizes from 1 to lngRandomNumber
'Random allows negative numbers to work as well and 0 (zero) is skipped
On Error GoTo Err_Trap
    Dim lReturn As Long
    Dim lCheck As Long 'in case the computer's randomizer timer fails

    If (lngRandomNumber <> 0) Then
        Randomize ' Initialize random-number generator.
        lCheck = 0
        Do While (lReturn = 0 And lCheck < 19)
            lCheck = lCheck + 1
            lReturn = (lngRandomNumber * Rnd) ' Compute random value
        Loop
        If (lCheck > 18) Then lReturn = 1
    Else
        lReturn = 0
    End If
    
    lRandom = lReturn
    Exit Function
Err_Trap:
    lRandom = 1
End Function
Public Function lAvgRandom(lngRandomNumber As Long) As Long
'Randomizes from 1 to lngRandomNumber
On Error Resume Next
    Dim lAvgNumber As Long
    lAvgNumber = MyCLng(lngRandomNumber / 2)
    lAvgRandom = lRandom(lAvgNumber) + lAvgNumber
End Function
Public Function basChopToASlash(strPath As String) As String
On Error Resume Next
'pass: "\\servername\where\printer1"
'or pass: "//servername/where/printer1"
'returns: printer1
    Dim intScan As Integer
    Dim intMark As Integer
    Dim strReturn As String
    
    intMark = 0
    
    For intScan = 1 To Len(strPath)
        If (Mid(strPath, intScan, 1) = "\") Or (Mid(strPath, intScan, 1) = "/") Then 'Find last \ or /
            intMark = intScan
        End If
    Next intScan
    
    strReturn = Mid(strPath, intMark + 1) 'Trim from \ on
    
    basChopToASlash = strReturn
End Function
Public Function basBoolean(intValue As Integer) As String
On Error Resume Next
' 0 = false anything else is true
    Dim strReturn As String
    
    Select Case intValue
        Case 0
            strReturn = "No"
        Case Else
            strReturn = "Yes"
    End Select
    
    basBoolean = strReturn
End Function
Public Function basWorldDay(varDate As Variant) As Long
' varDate must be mm-dd-yyyy, if varDate = null then todays date is returned.
'Returns the day we are at.
On Error Resume Next
    Dim lngMM As Long
    Dim lngDD As Long
    Dim lngYYYY As Long
    
    If (Len(varDate) = 0) Then
        varDate = Format(Date, "mm-dd-yyyy")
    End If
    
    lngMM = MyCLng(Mid(varDate, 1, 2) * 30) + 4
    lngDD = MyCLng(Mid(varDate, 4, 2))
    lngYYYY = MyCLng(Mid(varDate, 7, 4)) * 364
    basWorldDay = (lngMM + lngDD + lngYYYY)
End Function
Public Sub basCloseAllForms()
On Error Resume Next
    Dim lngCountForms As Long
    
    'Close all forms.
    For lngCountForms = Forms.Count - 1 To 1 Step -1
        Unload Forms(lngCountForms)
    Next
    mdiMainMenu.Show
End Sub
Public Function lngSQLRecordCount(strSQL As String) As Long
On Error GoTo Err_Check
    Dim MyRS As Recordset
    Dim lngReturn As Long
    
    'DoEvents
    
    lngReturn = 0
    
    Set MyRS = MyDB.OpenRecordset(strSQL, dbOpenSnapshot)
    If (Not MyRS.EOF) Then
        MyRS.MoveLast
        lngReturn = MyRS.RecordCount
    End If
    Set MyRS = Nothing
    
    lngSQLRecordCount = lngReturn
    Exit Function
Err_Check:
    basPrintMessage64 "COASERVER: lngSQLRecordCount," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description & vbCrLf & "SQL:" & vbCrLf & strSQL
End Function
Public Sub basActiveControlHighlight(frmObject As Form)
On Error Resume Next
'Works only with Textboxes.
'The control must have the focus to be the ActiveObject.
'The best place to use this is on your mdiFORM where a Timer Control
'calls: basActiveControlHighlight Screen.ActiveForm
'Then all your forms have this ability on TAB. You have to add an on click event for each object if you want TAB and ON CLICK.
    frmObject.ActiveControl.SelLength = Len(frmObject.ActiveControl.Text)
End Sub
Public Function basConvertToProperDigitScan(strValue As String, strStartSyntax As String) As String
'Correct Examples,
'Pass:      basConvertToProperDigitScan("W000001123", "W")
'Returns:   W1123
'Pass:      basConvertToProperDigitScan("WEW000056789", "WEW")
'Returns:   56789
'Pass:      basConvertToProperDigitScan("123AW0004000", "W")
'Returns:   123AW1234
'
'Error Example,
'Pass:      basConvertToProperDigitScan("WEW000056789", "W")
'Returns:   0 (because the first W is found and EW000056789 is not a digit)
On Error Resume Next
    Dim intPos As Integer
    
    intPos = InStr(strValue, strStartSyntax) + Len(strStartSyntax) + 1
    
    basConvertToProperDigitScan = Mid(strValue, 1, InStr(strValue, strStartSyntax)) & MyCStr(MyCLng(Mid(strValue, intPos)))
End Function
Public Function ynNetworkPath(strPath As String) As Boolean
On Error Resume Next
    ynNetworkPath = (InStr(strPath, "[\\"))
End Function
Public Function strReturnNetworkPath(strUNC As String, strPath As String) As String
'ynNetworkPath should be called first to verify that a network path can be returned.
On Error Resume Next
    Dim strReturn As String
    
    strReturn = MyCStr(strReturn)
    
    'Get the UNC path.
    strReturn = basCompletePath(Mid(strUNC, InStr(strUNC, "[\\")))
    
    strReturn = Mid(strReturn, 2, Len(strReturn) - 3) 'remove the "[\\COMPUTER\C\FOLDER]" square brackets.
    
    'Attach the folders after the UNC.
    strReturn = strReturn & basCompletePath(Mid(strPath, InStr(strPath, ":") + 1))
    
    strReturnNetworkPath = strReturn
End Function
Public Function basCompletePath(varPath As Variant) As String
'Pass: basCompletePath("C:\WINDOWS\TEMP")
'Returns: "C:\WINDOWS\TEMP\"
On Error Resume Next
    Dim strPath As String

    strPath = MyCStr(varPath)
    If (Len(strPath) > 0) Then
        strPath = UCase(strPath)
        If (Mid(strPath, Len(strPath), 1) <> "\") Then
            strPath = UCase(strPath & "\")
        End If
    End If
    
    basCompletePath = strPath
End Function
Public Function basReturnMonthShort(intMonth As Integer) As String
On Error Resume Next
    Dim strReturn As String
    Select Case intMonth
        Case 1
            strReturn = "Jan"
        Case 2
            strReturn = "Feb"
        Case 3
            strReturn = "Mar"
        Case 4
            strReturn = "Apr"
        Case 5
            strReturn = "May"
        Case 6
            strReturn = "Jun"
        Case 7
            strReturn = "Jul"
        Case 8
            strReturn = "Aug"
        Case 9
            strReturn = "Sep"
        Case 10
            strReturn = "Oct"
        Case 11
            strReturn = "Nov"
        Case 12
            strReturn = "Dec"
        Case Else
            strReturn = ""
    End Select
    basReturnMonthShort = strReturn
End Function
Public Function basReturnMonthLong(intMonth As Integer) As String
On Error Resume Next
    Dim strReturn As String
    Select Case intMonth
        Case 1
            strReturn = "January"
        Case 2
            strReturn = "Feburary"
        Case 3
            strReturn = "March"
        Case 4
            strReturn = "April"
        Case 5
            strReturn = "May"
        Case 6
            strReturn = "June"
        Case 7
            strReturn = "July"
        Case 8
            strReturn = "August"
        Case 9
            strReturn = "September"
        Case 10
            strReturn = "October"
        Case 11
            strReturn = "November"
        Case 12
            strReturn = "December"
        Case Else
            strReturn = ""
    End Select
    basReturnMonthLong = strReturn
End Function
Public Function lngReturnDecimal(sngNumber As Single) As Long
On Error Resume Next
    Dim strReturn As String
    Dim strNumber As String
    
    strNumber = MyCStr(Format(sngNumber, "###0.00"))

    strReturn = Mid(strNumber, InStr(strNumber, ".") + 1)
    
    lngReturnDecimal = MyCLng(strReturn)
End Function
Public Function sngDivide(sngNumerator As Single, sngDenominator As Single) As Single
'sngReturn = (sngNumerator / sngDenominator)
    Dim sngReturn As Single
    Dim sngDenominatorHold As Single
    
    sngDenominatorHold = sngDenominator
    
    If (sngDenominatorHold = 0) Then
        sngDenominatorHold = 1
    End If
    
    sngReturn = (sngNumerator / sngDenominatorHold)
    
    sngDivide = sngReturn
End Function
Public Sub basDropTable(strTableName As String)
On Error GoTo Err_DropTable
    Dim lngErrNumber As Long
    Dim strError As String

    MyDB.Execute "DROP TABLE " & strTableName & ";"
    Exit Sub
Err_DropTable:
    lngErrNumber = Err.Number: strError = Err.Description
    If (lngErrNumber <> 3376) Then 'We only care about errors that do not read, "Could not find table to drop."
        basPrintMessage64 "Error #" & lngErrNumber & vbCrLf & strError
    End If
End Sub
Public Sub basRightClickClosesForm(frmObject As Form, intButton As Integer)
'Just use: basRightClickClosesForm Me, Button
'      OR: basRightClickClosesForm frmStudent, Button
'Must be used on MouseDown event and just copy the above into the event.
On Error Resume Next
    If (intButton = 2) Then
        Unload frmObject
    End If
End Sub
Public Function booPlaySound(strFilename As String) As Boolean
'Example1: booPlaySound "C:\WINDOWS\TADA.WAV"
'Example2: booPlaySound "C:\WINDOWS\CANYON.MID"
On Error GoTo Play_Err
    Dim iReturn As Integer
    
'Private Sub Command1_Click()
'   Dim ret As Integer
   ' The following will open the sequencer with the C:WIN31CANYON.MID
   ' file. Canyon is the device_id.
'   ret = mciSendString("open c:windowsCANYON.MID type sequencer alias canyon", 0&, 0, 0)
   ' The wait tells the MCI command to complete before returning control
   ' to the application.
'   ret = mciSendString("play canyon wait", 0&, 0, 0)
   ' Close CANYON.MID file and sequencer device
'   ret = mciSendString("close canyon", 0&, 0, 0)
'End Sub
    
    DoEvents
    'Make sure something was passed to the Play Function
    If (Len(strFilename) > 0) Then
        'Now verify that the WAV filename was passed.
        Select Case (UCase$(Right$(strFilename, 4)))
            Case ".WAV"
                'Make sure the file exists
                If (Dir(strFilename) > "") Then
                    If (waveOutGetNumDevs() = 1) Then 'Test to make sure the system has a sound card. 1 = it exists, anything else does not.
                        iReturn = lngPlayWAVE(strFilename, 0)
                    End If
                End If
            Case ".MID"
                'Make sure the file exists
                If (Dir(strFilename) > "") Then
                    If (waveOutGetNumDevs() = 1) Then 'Test to make sure the system has a sound card. 1 = it exists, anything else does not.
                        iReturn = lngPlayMIDI("open " & strFilename & " type sequencer alias booplaymidisound", 0&, 0, 0)
                        'The wait tells the MCI command to complete before returning control to the application.
                        iReturn = lngPlayMIDI("play booplaymidisound", 0&, 0, 0)
                        'iReturn = lngPlayMIDI("play booplaymidisound wait", 0&, 0, 0)
                        'Close CANYON.MID file and sequencer device
                        'iReturn = lngPlayMIDI("close booplaymidisound", 0&, 0, 0)
                    End If
                End If
        End Select
    End If
    
    'Sound file play successful
    booPlaySound = True
    Exit Function
Play_Err:
    basPrintMessage64 "booPlaySound," & vbCrLf & Err.Description
End Function
Public Function ynCompareDates(strDateOne As String, strDateTwo As String) As Boolean
On Error Resume Next
'GREATER THAN OR EQUAL TO
' This is a simple function that compares two dates.  It is passed two dates as strings,
' strDateOne and strDateTwo.  If strDateOne >= strDateTwo the function returns TRUE else
' the function returns false.
'  * NOTE: The format of the passed in string must be mm-dd-yyyy
    Dim lngDay1 As Long
    Dim lngMonth1 As Long
    Dim lngYear1 As Long
    Dim lngDay2 As Long
    Dim lngMonth2 As Long
    Dim lngYear2 As Long
    Dim lngDateOneValue As Long
    Dim lngDateTwoValue As Long
    Dim ynReturn As Boolean

    ynReturn = False ' Init. as String is void of information.
    If (Len(strDateOne) > 0) Then
        If (lngMMDDYYYY2Days(strDateOne) >= lngMMDDYYYY2Days(strDateTwo)) Then 'Compares
            ynReturn = True
        End If
    End If
    ynCompareDates = ynReturn  'Returns result
End Function
Public Function ynCompareDatesEQUALTO(strDateOne As String, strDateTwo As String) As Boolean
On Error Resume Next
'EQUAL TO ONLY
' This is a simple function that compares two dates.  It is passed two dates as strings,
' strDateOne and strDateTwo.  If strDateOne = strDateTwo the function returns TRUE else
' the function returns false.
'  * NOTE: The format of the passed in string must be mm-dd-yyyy
    Dim lngDay1 As Long
    Dim lngMonth1 As Long
    Dim lngYear1 As Long
    Dim lngDay2 As Long
    Dim lngMonth2 As Long
    Dim lngYear2 As Long
    Dim lngDateOneValue As Long
    Dim lngDateTwoValue As Long
    Dim ynReturn As Boolean

    ynReturn = False ' Init. as String is void of information.
    If (Len(strDateOne) > 0) Then
        If (lngMMDDYYYY2Days(strDateOne) = lngMMDDYYYY2Days(strDateTwo)) Then 'Compares
            ynReturn = True
        End If
    End If
    
    ynCompareDatesEQUALTO = ynReturn  'Returns result
End Function
Public Function ynCompareDatesGREATER(strDateOne As String, strDateTwo As String) As Boolean
On Error Resume Next
'EQUAL TO ONLY
' This is a simple function that compares two dates.  It is passed two dates as strings,
' strDateOne and strDateTwo.  If strDateOne = strDateTwo the function returns TRUE else
' the function returns false.
'  * NOTE: The format of the passed in string must be mm-dd-yyyy
    Dim lngDay1 As Long
    Dim lngMonth1 As Long
    Dim lngYear1 As Long
    Dim lngDay2 As Long
    Dim lngMonth2 As Long
    Dim lngYear2 As Long
    Dim lngDateOneValue As Long
    Dim lngDateTwoValue As Long
    Dim ynReturn As Boolean

    ynReturn = False ' Init. as String is void of information.
    If (Len(strDateOne) > 0) Then
        If (lngMMDDYYYY2Days(strDateOne) > lngMMDDYYYY2Days(strDateTwo)) Then 'Compares
            ynReturn = True
        End If
    End If
    
    ynCompareDatesGREATER = ynReturn  'Returns result
End Function
Public Function lngMMDDYYYY2Days(strMMDDYYYY As String) As Long
'Function returns the number of elapsed days since the beggining of the year
On Error Resume Next
    Dim lngDay As Long
    Dim lngMonth As Long
    Dim lngYear As Long

    lngDay = MyCLng(Mid(strMMDDYYYY, 4, 2))
    lngMonth = MyCLng(Mid(strMMDDYYYY, 1, 2)) * 31
    lngYear = MyCLng(Mid(strMMDDYYYY, 7, 4)) * 365
    
    lngMMDDYYYY2Days = lngDay + lngMonth + lngYear
End Function
Public Function lngProperBaudRate(lngBaudRate As Long) As Long
On Error Resume Next
    Dim lngReturn As Long

    lngReturn = lngBaudRate

    Select Case lngBaudRate
        Case 300, 1200, 4800, 9600, 14400, 19200, 33600, 57600, 115200
        Case Else
            lngReturn = 9600
    End Select
    
    lngProperBaudRate = lngReturn
End Function
Public Function varCallForm(frmObject As Form) As Variant
'Usage: varCallForm(frmName)
'The form will use one global variable to return a value: gblvarReturnCallForm.
'This variable can be true or fale or a string, or a number.
On Error Resume Next
    frmObject.Show 1
    varCallForm = gblvarReturnCallForm
End Function
Public Function varTimeDifference(time1, time2 As Variant) As Integer
'Usage: varTimeDifference(time1, time2 As Variant)
' This function gets passed in two times as variants and returns
' the difference between the two
On Error Resume Next
    Dim intDifference As Integer
    intDifference = 0
    intDifference = intConvertTimeToMinutes(time1) - intConvertTimeToMinutes(time2)
    varTimeDifference = intDifference
End Function
Public Function intConvertTimeToSeconds(intTime As String) As Integer
'Usage: intConvertTimeToSeconds(intTime As Integer) As Integer
' This function converts any time that is passed in into seconds
' ex. 1:07:45 becomes 4065 seconds
    Dim intHours As Integer
    Dim intMinutes As Integer
    Dim intSeconds As Integer
    intHours = MyCInt(Mid(Format(intTime, "hh:mm:ss"), 1, 2)) * 3600
    intMinutes = MyCInt(Mid(Format(intTime, "hh:mm:ss"), 4, 2)) * 60
    intSeconds = MyCInt(Mid(Format(intTime, "hh:mm:ss"), 7, 2))
    intConvertTimeToSeconds = intMinutes + intHours + intSeconds
End Function
Public Function intConvertTimeToMinutes(intTime As Variant) As Integer
'Usage: intConvertTimeToMinutes(intTime As Integer) As Integer
' This function converts any time that is passed in into minutes
' ex. 1:07 becomes 67 minutes
    Dim intHours As Integer
    Dim intMinutes As Integer
    intHours = MyCInt(Mid(Format(intTime, "hh:mm:ss"), 1, 2)) * 60
    intMinutes = MyCInt(Mid(Format(intTime, "hh:mm:ss"), 4, 2))
    intConvertTimeToMinutes = intMinutes + intHours
End Function
Public Function intConvertTimeToHours(intMinutes As Long) As Variant
'Usage: intConvertTimeToMinutes(intTime As Variant) As variant
' This function is passed a number of minutes and returns time in "Hours : Minutes" format
' ex. 67 becomes 1:07    ex. 47 returns 0:47    ex. 3 returns 0:03
On Error Resume Next
    Dim intHours As Integer
    Dim strMinutes As String
    Dim bChanged As Boolean

    intHours = 0
    
    If (intMinutes >= 0) Then
        If (intMinutes >= 60) Then
            Do While (intMinutes >= 60)
                intMinutes = intMinutes - 60
                intHours = intHours + 1
            Loop
        End If
    Else
        intMinutes = 0
    End If
    If intMinutes < 10 Then
        strMinutes = Format(MyCStr(intMinutes), "0#")
    Else
        strMinutes = MyCStr(intMinutes)
    End If
    intConvertTimeToHours = MyCStr(intHours) & ":" & strMinutes
End Function
Public Function ynIsLeapYear() As Boolean
'Simple function that check whether the current year is a leap year
'Returns: TRUE or FALSE
On Error Resume Next
    Dim bLeap As Boolean
    bLeap = False
    If MyCLng(Format(Date, "yy")) = 0 Then
        bLeap = True
    Else
        If (MyCLng(Format(Date, "yy")) Mod 4) = 0 Then
            bLeap = True
        End If
    End If
    'Debug.Print bLeap
    ynIsLeapYear = bLeap
End Function
Public Function ynLeapYear(strYear As String) As Boolean
'Simple function that check whether a passed in date is in a leap year
'Returns: TRUE or FALSE
On Error Resume Next
    Dim bLeap As Boolean
    Dim bNumericDate

    bLeap = False
    bNumericDate = zStripDesignatedChars(strYear, "/-abcdefghijklmonpqrstuvwxyz~`!@#$%^&*()_-++{[}]:;'''<,>.?/|\")
    If IsNumeric(bNumericDate) Then
        strYear = MyCStr(bNumericDate)
        If (strYear = "") Or IsNull(strYear) Then  'IsNull(strYear) Or
        Else
            If MyCLng(Format(MyCDateSimply(strYear), "yy")) = 0 Then
                bLeap = True
            Else
                If (MyCLng(Format(MyCDateSimply(strYear), "yy")) Mod 4) = 0 Then
                    bLeap = True
                End If
            End If
        End If
    End If
   'Debug.Print bLeap
    ynLeapYear = bLeap
End Function
Public Sub basAppendFileToFile(strSource1 As String, strSource2 As String, strDestination As String)
'This works only with text files.
On Error GoTo Err_FileToFile
    Const cststrWorkFile = "APPENDWK.TXT"
    
    Dim strLine As String
    Dim F1 As Integer
    Dim F2 As Integer
    Dim F3 As Integer
    
    F1 = FreeFile ' get a filenumber not used currently
    Open strSource1 For Input As F1 ' open new file for write - use As Append to append to an existing file
    F2 = FreeFile ' get a filenumber not used currently
    Open strSource2 For Input As F2 ' open new file for write - use As Append to append to an existing file
    F3 = FreeFile ' get a filenumber not used currently
    Open App.Path & cststrWorkFile For Output As F3 ' open new file for write - use As Append to append to an existing file
    
    Do While Not EOF(F1)
        Line Input #(F1), strLine
        Print #(F3), strLine
    Loop
    
    DoEvents
    
    Do While Not EOF(F2)
        Line Input #(F2), strLine
        Print #(F3), strLine
    Loop
    
    Close F1
    Close F2
    Close F3
Err_FileToFile:
On Error Resume Next 'No error checking from here on.
    If (basDoesFileExist(strDestination)) Then
        Kill strDestination
    End If
    
    FileCopy App.Path & cststrWorkFile, strDestination
    
    If (basDoesFileExist(App.Path & cststrWorkFile)) Then
        Kill App.Path & cststrWorkFile
    End If
End Sub
Public Sub basSwapDatesVAR(ByRef varDateFrom As Variant, ByRef varDateTo As Variant)
'If varDateFrom is less than varDateTo then there is no swapping.
'varDateFrom and varDateTo must be in the mm-dd-yyyy format !
On Error Resume Next
    Dim varDateSwap As Variant
    
    If (ynCompareDates(MyCStr(varDateFrom), MyCStr(varDateTo))) Then
        varDateSwap = varDateFrom
        varDateFrom = varDateTo
        varDateTo = varDateSwap
    End If
End Sub
Public Sub basSwapDatesSTR(ByRef strDateFrom As String, ByRef strDateTo As String)
'If varDateFrom is less than varDateTo then there is no swapping.
'varDateFrom and varDateTo must be in the mm-dd-yyyy format !
On Error Resume Next
    Dim strDateSwap As String
    
    If (ynCompareDates(strDateFrom, strDateTo)) Then
        strDateSwap = strDateFrom
        strDateFrom = strDateTo
        strDateTo = strDateSwap
    End If
End Sub
Public Function ynValidPattern(strScanBarCode As String, strPattern As String) As Boolean
'A is for number or letter allowed at this spot.
'N is number allowed at this spot only.
'L letter is only allowed in this spot.
'    MsgBox ynValidPattern("1234567", "NNNNNNN") & " returns TRUE"
'    MsgBox ynValidPattern("1234567", "LNNNNNN") & " returns FALSE"
'    MsgBox ynValidPattern("1234567", "ANNNNNN") & " returns TRUE"
'    MsgBox ynValidPattern("1234567", "AAAAAAA") & " returns TRUE"
'    MsgBox ynValidPattern("E234567", "AAAAAAA") & " returns TRUE"
'    MsgBox ynValidPattern("E234567", "LAAANAN") & " returns TRUE"
'    MsgBox ynValidPattern("E234567", "NNNNNNN") & " returns FALSE"
'    MsgBox ynValidPattern("1A3G5xZ", "NLNLAAL") & " returns TRUE"
'SPECIAL PATTERNS:
'We only match up to the length of shortest passed value, of strScanBarCode or strPattern.
'    MsgBox ynValidPattern("1HI", "NAANNNNNNNNNNNNN") & " returns TRUE"

On Error Resume Next
    Dim intLength As Integer
    Dim intScan As Integer
    Dim ynReturn As Boolean
    
    ynReturn = True
    
    intScan = 1
    
    If (Len(strScanBarCode) >= Len(strPattern)) Then
        intLength = Len(strPattern)
    Else
        intLength = Len(strScanBarCode)
    End If
    
    Do While (intScan <= intLength And ynReturn)
        Select Case IsNumeric(Mid(strScanBarCode, intScan, 1))
            Case True
                Select Case Mid(strPattern, intScan, 1)
                    Case "L"
                        ynReturn = False
                End Select
            Case False
                Select Case Mid(strPattern, intScan, 1)
                    Case "N"
                        ynReturn = False
                End Select
        End Select
        
        intScan = intScan + 1
    Loop
    
    ynValidPattern = ynReturn
End Function
Function strApplicationModifiedDate() As String
On Error Resume Next
'Execute: msgbox strApplicationModifiedDate()
    Dim strFilePath As String
    Dim strReturn As String
    
    strReturn = varSystemDateFormat(Date, True)
    
    strFilePath = App.Path & "\" & App.EXEName & ".EXE"
    
    strReturn = varSystemDateFormat(FileDateTime(strFilePath), True)
    
    strApplicationModifiedDate = strReturn
End Function
Public Sub basGOTOADSURL()
On Error GoTo Err_Check
    Dim hWnd As Long
    
    hWnd = 0

    ShellExecute hWnd, "open", "http://www.adsolutions.ab.ca", vbNull, vbNull, SW_SHOWNORMAL
    Exit Sub
Err_Check:
    basPrintMessage64 "GOTO URL ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function booSystemDateStatus()
On Error Resume Next
    Dim booReturn As Boolean
    
    booReturn = (Format("12 01 1999", "mmm dd, yyyy") = "Dec 01, 1999")
    
    booSystemDateStatus = booReturn
End Function
Function booLoadRegionalSettings() As Boolean
On Error Resume Next
  Dim booReturn As Boolean
  
  booReturn = True
  
  Dim varGetShell As Variant
  varGetShell = Shell("rundll32.exe shell32.dll,Control_RunDLL Intl.cpl", vbNormalFocus)
  DoEvents
  AppActivate varGetShell, True
  DoEvents
  
  booLoadRegionalSettings = booReturn
End Function
Public Function booRegionalSettingsTest()
On Error Resume Next
    Dim booReturn As Boolean

    booReturn = True

    If (Not booSystemDateStatus()) Then
        basPrintMessage64 "Your system regional setting is reading the format Dec 01, 1999 as Jan 12, 1999. This program will try to automatically activate your" & vbCrLf & "Control Panel's -> Regional Settings Form for you. You will then need to manually modify your Short Date field to" & vbCrLf & "MMM/DD/YYYY." & vbCrLf & vbCr & "HINT: You need to start by clicking on the Date Tab once the Regional Settings Properties Form pops up." & vbCrLf & vbCr & "Thank you."
        booLoadRegionalSettings
        basPrintMessage64 "The system will now shutdown - you will need to execute the system once again." & vbCrLf & vbCr & "NOTE: Your Regional Settings will be tested each time the system loads so you and this application knows your Regional Settings are always correct."
        
        booReturn = False
        End
    End If
    
    booRegionalSettingsTest = booReturn
End Function
Public Function strTakeCapsAddSpaces(strLine As String) As String
On Error GoTo Err_Check
'Pass: strTakeCapsAddSpaces("HelloThereHowAreYou?")
'Returns: Hello There How Are You?
    Dim intPos As Integer
    Dim intScan As Integer
    Dim strReturn As String
    
    strReturn = ""
    intPos = 1
    For intScan = 1 To Len(strLine)
        If (bAmong(Asc(Mid(strLine, intScan, 1)), 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90)) Then
            strReturn = strReturn & Mid(strLine, intPos, intScan - intPos) & " "
            intPos = intScan
        End If
    Next intScan
    
    strReturn = strReturn & Mid(strLine, intPos, intScan - intPos) & " "
    
    strTakeCapsAddSpaces = strReturn
    
    Exit Function
Err_Check:
    strTakeCapsAddSpaces "varSystemDateFormat," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Function
Public Function varSystemDateFormat(varDate As Variant, Optional ynErrorTrap As Boolean) As Variant
On Error GoTo Err_Check
    Dim varReturn As Variant
    
    varReturn = strRemoveOperativeChars(MyCStr(varDate))
    
    If Not (IsDate(varReturn)) Then
        If (Mid(varReturn, 3, 1) <> " ") Then 'No space at the third location? Put one then...
            varReturn = Mid(varReturn, 1, 3) & " " & Mid(varReturn, 4)
        End If
    End If
    
    If (Len(MyCStr(varReturn)) = 0) Then
        varReturn = "" 'Just so the system desn't crash for no reason.
    Else
        varReturn = Format(CVDate(MyCStr(varReturn)), cststrDateFormat)
    End If
    
    varSystemDateFormat = varReturn
    
    Exit Function
Err_Check:
    If (ynErrorTrap) Then
        basPrintMessage64 "varSystemDateFormat," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description & vbCrLf & vbCr & vbCrLf & "You may have only entered an invalid date !" & vbCrLf & "SYNTAX (spaces are required): " & vbCrLf & "Use the format: " & cststrDateFormat & vbCrLf & vbCr & "EXAMPLE: " & Format(Date, cststrDateFormat)
    End If
    
    varSystemDateFormat = "Jan 01, 1899"
End Function
Public Sub basBringUpDesktopDisplaySettings()
On Error Resume Next
    Call Shell("rundll32.exe shell32.dll,Control_RunDLL desk.cpl,,3", 1)
End Sub
Public Function strFormatPostalCode(strPostalCode As String, intType As Integer) As String
On Error Resume Next
'intType is reserved if the postal code is canadian format or not.
'This function autodetects if it is canadian or ZIP but this fn was written for future flexibility.
    Dim strReturn As String
    
    strReturn = strRemoveCharacterFromLine(UCase(MyCStr(strPostalCode)), " ")
    
    If (Not IsNumeric(Mid(strReturn, 1, 1))) Then
        strReturn = Mid(strReturn, 1, 3) & " " & Mid(strReturn, 4)
    End If
    
    strFormatPostalCode = strReturn
End Function
Public Sub basMousePointer(intType As Integer)
On Error Resume Next
'0 is normal Hourglass
'11 is an Hourglass
    Screen.MousePointer = intType
    DoEvents
End Sub
Public Sub basOpenPrinterDialog()
On Error Resume Next
    mdiMainMenu.CDCommon.ShowPrinter
End Sub
Public Function strCapFirstLetter(strValue As String) As String
On Error Resume Next
    Dim strReturn As String
    strReturn = MyCStr(strValue)
    strReturn = UCase(Mid(strReturn, 1, 1)) & Mid(strReturn, 2, Len(strReturn))
    strCapFirstLetter = strReturn
End Function
Public Sub basCleargbllngSendBack()
On Error Resume Next
    gbllngSendBack(1) = 0
    gbllngSendBack(2) = 0
End Sub
Public Sub basDither(vForm As Form, intColour As Integer)
'This will colour the background of a form red or blue.
'This looks exactly like the setup backgrounds you find in programs.
'Looks AWESOME !
'THIS MUST BE UNDER THE EVENT Form_Activate !!!
On Error Resume Next
    Dim intLoop As Integer
    
    vForm.DrawStyle = vbInsideSolid
    vForm.DrawMode = vbCopyPen
    vForm.ScaleMode = vbPixels
    vForm.DrawWidth = 2
    vForm.ScaleHeight = 256
    For intLoop = 0 To 255
        Select Case intColour
            Case 1 'Red
                vForm.Line (0, intLoop)-(Screen.Width, intLoop - 1), RGB(255 - intLoop, 0, 0), B
            Case Else 'Blue
                vForm.Line (0, intLoop)-(Screen.Width, intLoop - 1), RGB(0, 0, 255 - intLoop), B
        End Select
    Next intLoop
End Sub
Public Sub basHandleFormKey(KeyCode As Integer, Optional Shift As Integer)
' if the user presses enter, treat it the same as if they hit tab.
On Error Resume Next
    Select Case KeyCode
        Case 13
            SendKeys "{tab}"
    End Select
End Sub
Public Function bVoul(zName As String) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    bReturn = False
    Select Case Mid(LCase(zName), 1, 1)
        Case "a", "e", "i", "o", "u"
            bReturn = True
    End Select
    bVoul = bReturn
End Function
Public Function bPlural(zName As String) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    bReturn = False
    Select Case Mid(LCase(zName), Len(zName), 1)
        Case "s"
            bReturn = True
    End Select
    bPlural = bReturn
End Function
Public Function bCapital(zName As String) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    bReturn = False
    Select Case Asc(Mid(zName, 1, 1)) 'Get the first letter we want to test if it is capital
        Case Asc("A") To Asc("Z")
            bReturn = True
    End Select
    bCapital = bReturn
End Function
Public Function bOdd(lValue As Long) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    bReturn = False
    'Debug.Print lValue & "Mod 2 = " & lValue Mod 2
    If (lValue Mod 2 <> 0) Then
        bReturn = True
    End If
    bOdd = bReturn
End Function
Public Function zTrimCrLf(zLine As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim lLenLine As Long
    
    zReturn = Trim(zLine)
    
    If (zReturn = vbCrLf) Then
        zReturn = ""
    Else
        lLenLine = Len(zReturn)
        If (lLenLine > 1) Then
            If (Mid(zReturn, lLenLine - 1) = vbCrLf) Then
                zReturn = Mid(zReturn, 1, lLenLine - 2)
            End If
        End If
    End If
    zTrimCrLf = MyCStr(zReturn)
End Function
Public Function bEven(lValue As Long) As Boolean
On Error Resume Next
    bEven = ((lValue Mod 2) = 0)
End Function

Public Function bFileExist(zFilename As String) As Boolean
On Error Resume Next
    Dim tmpRv As Long
    tmpRv = GetAttr(zFilename)
    bFileExist = Not Err And tmpRv <> 0
End Function

'Public Function GetIPHostName() As String
''Returns the current machine's name
'Dim sHostName As String * 256
'
'    If Not SocketsInitialize() Then
'        GetIPHostName = ""
'        Exit Function
'    End If
'
'    If gethostname(sHostName, 256) = SOCKET_ERROR Then
'        GetIPHostName = ""
'        MsgBox "Windows Sockets error " & Str$(WSAGetLastError()) & _
'                " has occurred.  Unable to successfully get Host Name."
'        SocketsCleanup
'        Exit Function
'    End If
'
'    GetIPHostName = Left$(sHostName, InStr(sHostName, Chr(0)) - 1)
'    SocketsCleanup
'End Function
'
'
Public Sub subCoAClientLoad()
On Error Resume Next
    Const cstFileName = "coaclient.exe"
    Dim zPathAndFileName As String
    Dim res As Integer
    If (bFileExist(cstFileName)) Then
        zPathAndFileName = cstFileName
        res = Shell(zPathAndFileName, vbNormalFocus)
    End If
End Sub
