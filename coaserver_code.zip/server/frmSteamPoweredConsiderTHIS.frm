VERSION 5.00
Begin VB.Form frmSteamPoweredConsiderTHIS 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "STEAM POWERED USERS - Consider These Settings - Thank you"
   ClientHeight    =   5910
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   9225
   Icon            =   "frmSteamPoweredConsiderTHIS.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "frmSteamPoweredConsiderTHIS.frx":058A
   ScaleHeight     =   5910
   ScaleWidth      =   9225
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox picFakeButton 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   7720
      Picture         =   "frmSteamPoweredConsiderTHIS.frx":B440C
      ScaleHeight     =   375
      ScaleWidth      =   1335
      TabIndex        =   0
      Top             =   5460
      Width           =   1335
   End
End
Attribute VB_Name = "frmSteamPoweredConsiderTHIS"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub picFakeButton_Click()
On Error Resume Next
    Unload frmSteamPoweredConsiderTHIS
End Sub
