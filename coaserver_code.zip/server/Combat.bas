Attribute VB_Name = "modCombat"
Option Explicit
'MOB TWEEKING - MOB TWEAKING
Public Const cstMobHRRespawn = 17 'mobile default 17 hitroll
Public Const cstMobDRRespawn = 6 'default 6 damage roll or average damage
Public Const cstMobHPRespawn = 90 'default 90 [MHP]=([MobLevel]*" & cstMobHPRespawn & ")+([MHPBonus])
Public Const cstMobACRespawn = 45 'default 45 this way magic arrow and other magic attacks are worth more
Public Const cstNewbieSafeLevel = 30
Public Const cstlMoveCostInertialInhibitor = 16 'this divides -into- the mob level - so if this was 1 it would cost 1-moblevel move to swing at it
Public Const cstMinAttackMobLen = 3
Public Const cstlGroundItemDeleteTimer = 3 'when a ground timer exceeds this value the object deletes. See Also: subHandleGroundObjects

Public Const cstiStatusNotInBattleMode = 0
Public Const cstiStatusPlayerVsMob = 10
Public Const cstiStatusPlayerIgnoredVsMob = 15
Public Const cstiStatusPlayerVsPlayer = 20
Public Type tCombatStatus
    iStatus As Integer '0=available battle cell 1=battle mode 2=Target fled, 3=Attacker fled.
End Type
Public Type tCombat
    Name As String 'player or mob name
    lID As Long 'Battle originator - attacker or defender
End Type
Public gblbEyeBeams(cstlMinPort To cstlMaxPort) As Boolean
Public gblbHint(cstlMinPort To cstlMaxPort) As Boolean
Public rPCombat(cstlMinPort To cstlMaxPort) As tCombat 'Player in fight
Public rMCombat(cstlMinPort To cstlMaxPort) As tCombat 'Mobile in fight
Public rSCombat(cstlMinPort To cstlMaxPort) As tCombatStatus 'This is the player fighting port. Status of the two other records, rPCombat and rMCombat
Public Sub subMessageDeathPlayer(zPortID As String, zKillerName As String, zXPLoss As String)
    subSendMsg "&R" & zKillerName & " &yended you, the &RR&wEAP&aE&rR &rtransported you elsewhere " & zFormatGoldCofGLearnpts(MyCLng(zXPLoss) * -1, "R", True), zPortID '&gxp&R[&c-" & zXPLoss & "&R]", zPortID
End Sub
Public Function iCombatPlayerStatus(zPortID As String) As Integer
On Error Resume Next
    Dim bReturn As Boolean
    Dim lPortID As Integer
    Dim iStatus As Integer
    
    iStatus = 0
    bReturn = False
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'protects rSCombat from crashing
        iStatus = rSCombat(lPortID).iStatus
    End If
    iCombatPlayerStatus = iStatus
End Function
Public Function bObjectInAreaByName(zObjectName As String, lX As Long, lY As Long, lZ As Long) As Boolean
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim bReturn As Boolean
    Set rsObject = MyDB.OpenRecordset("SELECT ObjectName, ObjectID, X, Y, Z FROM tblObject WHERE (ObjectName='" & zAntiSQLCrash(zObjectName) & "' AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Status=0 AND Burried=0 AND ReturnPlayerID=0);", dbOpenSnapshot)
    bReturn = (Not rsObject.EOF) 'bReturn = False 'no object in the area by that name go ahead and make another one for the player
    Set rsObject = Nothing
    bObjectInAreaByName = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bObjectInAreaByName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zMakeItemWord(iTemperature As Integer, zStats As String, zWeaponType As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    
    zReturn = ""
    
    Select Case iTemperature
        Case 1 'freezing
            zReturn = "ice"
            Select Case UCase(zStats)
                Case "STR"
                    Select Case UCase(zWeaponType)
                        Case "JAVI"
                        Case "SPEA"
                        Case "SAXE" 'small axe
                        Case "GAXE" 'great axe
                        Case "BLUD"
                            zReturn = zReturn & "ola"
                        Case "POLE"
                            zReturn = zReturn & "lance"
                        Case "FLEX"
                            zReturn = zReturn & "whip"
                        Case "LBLA"
                            zReturn = zReturn & "int"
                        Case "SBLA"
                            zReturn = zReturn & "int"
                        Case "PUGI"
                            zReturn = zReturn & "int"
                        Case "TALO"
                            zReturn = zReturn & "int"
                        Case "BOW"
                            zReturn = zReturn & "int"
                        Case "XBOW"
                            zReturn = zReturn & "int"
                        Case "SLIN"
                            zReturn = zReturn & "int"
                        Case "NET"
                            zReturn = zReturn & "int"
                        Case "ARRO"
                            zReturn = zReturn & "int"
                        Case "BOLT"
                            zReturn = zReturn & "int"
                        Case "STON"
                            zReturn = zReturn & "int"
                    End Select
            End Select
        Case 2 'cold
        Case 3 'cool
        Case 4 'rainforest
        Case 5 'jungle
        Case 6 'desert
        Case 7 'hot
    End Select

    zMakeItemWord = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zMakeItemWord," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subObjectBraces(ByRef zColourGlowing As String, ByRef zMarkingRune As String, ByRef zMarkingGlowing As String, ByRef zMarkingHumming As String, zPhrase As String)
On Error Resume Next
    Dim bColourGlowing As Boolean
    Dim bMarkingRune As Boolean
    Dim bMarkingGlowing As Boolean
    Dim bMarkingHumming As Boolean
    Dim bGodly As Boolean
    Dim bOkay As Boolean
    bColourGlowing = (Len(zColourGlowing) = 0)
    bMarkingRune = (Len(zMarkingRune) = 0)
    bMarkingGlowing = (Len(zMarkingGlowing) = 0)
    bMarkingHumming = (Len(zMarkingHumming) = 0)
    bGodly = (InStr(LCase(zPhrase), "godly") <> 0)
    bOkay = False
    If (bGodly) Or (bColourGlowing And bMarkingRune And bMarkingGlowing And bMarkingHumming) Then
        Select Case lRandom(4)
            Case 1
                zColourGlowing = zPhrase
                bOkay = True
            Case 2
                zMarkingRune = zPhrase
                bOkay = True
            Case 3
                zMarkingGlowing = zPhrase
                bOkay = True
            Case 4
                zMarkingHumming = zPhrase
                bOkay = True
        End Select
    Else
        If (Not bOkay And bColourGlowing) Then
            zColourGlowing = zPhrase
            bOkay = True
        End If
        If (Not bOkay And bMarkingRune) Then
            zMarkingRune = zPhrase
            bOkay = True
        End If
        If (Not bOkay And bMarkingGlowing) Then
            zMarkingGlowing = zPhrase
            bOkay = True
        End If
        If (Not bOkay And bMarkingHumming) Then
            zMarkingHumming = zPhrase
            bOkay = True
        End If
    End If
End Sub
Public Function zRandomClass(bIncludeMorph As Boolean) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    If (bIncludeMorph) Then 'IO?
        Select Case lRandom(16)
            Case 1
                zReturn = "VA"
            Case 2
                zReturn = "WE"
            Case 3
                zReturn = "PL"
            Case 4
                zReturn = "CY"
            Case 5
                zReturn = "AS"
            Case 6
                zReturn = "BA"
            Case 7
                zReturn = "CL"
            Case 8
                zReturn = "DR"
            Case 9
                zReturn = "GY"
            Case 10
                zReturn = "KN"
            Case 11
                zReturn = "MA"
            Case 12
                zReturn = "MO"
            Case 13
                zReturn = "PA"
            Case 14
                zReturn = "RA"
            Case 15
                zReturn = "TH"
            Case 16
                zReturn = "WA"
        End Select
    Else
        Select Case lRandom(12)
            Case 1
                zReturn = "AS"
            Case 2
                zReturn = "BA"
            Case 3
                zReturn = "CL"
            Case 4
                zReturn = "DR"
            Case 5
                zReturn = "GY"
            Case 6
                zReturn = "KN"
            Case 7
                zReturn = "MA"
            Case 8
                zReturn = "MO"
            Case 9
                zReturn = "PA"
            Case 10
                zReturn = "RA"
            Case 11
                zReturn = "TH"
            Case 12
                zReturn = "WA"
        End Select
    End If
    zRandomClass = zReturn
End Function
Public Sub subLoadRandomGivesObjectID() 'see also lCreateRandomObjectIDbyMob()
On Error GoTo Err_Check 'Trisker work here, this might need tweeking its new
    Dim rsQuestArea As Recordset
    Dim lngCountSQL As Long
    
    gbllLoadRandomGivesObjectID = 0
    gblzLoadRandomGivesObjectID = ""
    lngCountSQL = lngSQLRecordCount("SELECT tblObject.ObjectID FROM tblObject INNER JOIN tblMobEquipmentItems ON tblObject.ObjectID = tblMobEquipmentItems.ObjectID WHERE (((tblObject.WeaponType)<>'')) OR (((tblObject.AverageDamage)<>0)) OR (((tblObject.CHITROLL)<>0)) OR (((tblObject.AC)<>0)) OR (((tblObject.PAC)<>0)) OR (((tblObject.PACMax)<>0)) OR (((tblObject.NumAttRnd)<>0));")
    'Debug.Print "SELECT TOP " & lRandom(lngCountSQL) & " ObjectName, ObjectID, WeightMax, SystemObjectType, SystemProtected, ObjectIDOriginal, ObjectIDPandora, OriginalMobID FROM tblObject WHERE (" & zLoadSQL & ");"
    Set rsQuestArea = MyDB.OpenRecordset("SELECT TOP " & lRandom(lngCountSQL) & " tblObject.ObjectName, tblObject.ObjectID FROM tblObject INNER JOIN tblMobEquipmentItems ON tblObject.ObjectID = tblMobEquipmentItems.ObjectID WHERE (((tblObject.WeaponType)<>'')) OR (((tblObject.AverageDamage)<>0)) OR (((tblObject.CHITROLL)<>0)) OR (((tblObject.AC)<>0)) OR (((tblObject.PAC)<>0)) OR (((tblObject.PACMax)<>0)) OR (((tblObject.NumAttRnd)<>0));", dbOpenSnapshot)
    If (Not rsQuestArea.EOF) Then
        rsQuestArea.MoveLast
        gbllLoadRandomGivesObjectID = MyCLng(rsQuestArea!ObjectID)
        gblzLoadRandomGivesObjectID = MyCStr(rsQuestArea!ObjectName)
    End If
    Set rsQuestArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoadRandomGivesObjectID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lCreateRandomObjectIDbyMob() As Long 'see also: subLoadRandomGivesObjectID
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lCount As Long
    Dim lReturn As Long
    lReturn = 0
    lCount = lngSQLRecordCount("SELECT QuestObjectID FROM tblMobQuestObject;")
    If (lCount > 0) Then
    Set rsObject = MyDB.OpenRecordset("SELECT TOP " & lRandom(lCount) & " QuestObjectID FROM tblMobQuestObject;", dbOpenSnapshot)
    If (Not rsObject.EOF) Then
        rsObject.MoveLast
        lReturn = MyCLng(rsObject!QuestObjectID)
    End If
    Set rsObject = Nothing
    End If
    lCreateRandomObjectIDbyMob = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCreateRandomObjectIDbyMob," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lCreateRandomObjectID(lX As Long, lY As Long, lZ As Long) As Long
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lReturn As Long
    lReturn = 0
    Set rsObject = MyDB.OpenRecordset("tblObject", dbOpenDynaset)
    rsObject.AddNew
    rsObject!ObjectName = "Object ID" & MyCLng(rsObject!ObjectID) & " made, location " & lX & " " & lY & " " & lZ
    rsObject!Status = 0
    rsObject!x = lX
    rsObject!y = lY
    rsObject!z = lZ
    lReturn = MyCLng(rsObject!ObjectID)
    rsObject.Update
    Set rsObject = Nothing
    lCreateRandomObjectID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCreateRandomObjectID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bStolenItembyObjectID(lPassObjectID As Long) As Boolean 'true means stolen item
'tblMobEquipmentItems.StolenItem=0
On Error GoTo Err_Check
    Dim rsStolenItem As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    Set rsStolenItem = MyDB.OpenRecordset("SELECT StolenItem from tblMobEquipmentItems WHERE (ObjectID=" & lPassObjectID & ");", dbOpenSnapshot)
    If (Not rsStolenItem.EOF) Then
        bReturn = (MyCInt(rsStolenItem!StolenItem) <> 0)
    End If
    Set rsStolenItem = Nothing
    
    bStolenItembyObjectID = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bStolenItembyObjectID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Function lPlrWeaponDamage(lOPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim rsPlr As Recordset
    Dim lReturn As Long
    lReturn = 1 'We always do 1 pt of damage
    Set rsPlr = MyDB.OpenRecordset("SELECT Sum(tblObject.AverageDamage) AS SumOfAverageDamage FROM (tblPlayer INNER JOIN tblPlayerEquipmentItems ON tblPlayer.PlayerID = tblPlayerEquipmentItems.PlayerID) INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID GROUP BY tblPlayer.PlayerID HAVING (((tblPlayer.PlayerID)=" & lOPlayerID & ") AND ((Sum(tblObject.AverageDamage))<>0));", dbOpenSnapshot)
    If (Not rsPlr.EOF) Then
        lReturn = MyCLng(MyCLng(rsPlr!SumOfAverageDamage) / 2) + lRandom(MyCLng(MyCLng(rsPlr!SumOfAverageDamage) / 2))
    End If
    Set rsPlr = Nothing
    lPlrWeaponDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lPlrWeaponDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subDropGold(zGoldObjectName As String, lPlayerID As Long, lX As Long, lY As Long, lZ As Long, lGold As Long)
On Error GoTo Err_Check
    MyDB.Execute "INSERT INTO tblObject ( ObjectName, Gold, X, Y, Z, Status, Location, PlayerID ) SELECT """ & zGoldObjectName & """ , " & lGold & ", " & lX & ", " & lY & ", " & lZ & ", 0, 120, 0;", dbFailOnError
    MyDB.Execute "UPDATE tblPlayer SET tblPlayer.Gold = [Gold]-" & lGold & " WHERE (((tblPlayer.PlayerID)=" & lPlayerID & "));", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subDropGold," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatEndedInitializeCombatCellsPortID(lPortID As Long)
On Error Resume Next
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        subClearPortTotalXP lPortID
        'turn combat off
        rSCombat(lPortID).iStatus = cstiStatusNotInBattleMode
        
        'useful if the player dies
        MyDB.Execute "UPDATE tblMob SET PlayerID=0 WHERE (MobID=" & rMCombat(lPortID).lID & ");", dbFailOnError
        rMCombat(lPortID).Name = ""
        rMCombat(lPortID).lID = 0
        
        'Now we need reset all the players that are attacking this same mob.
        If (rPCombat(lPortID).lID <> 0) Then MyDB.Execute "UPDATE tblPlayer SET Status = 5 WHERE (PlayerID=" & rPCombat(lPortID).lID & ");", dbFailOnError
        rPCombat(lPortID).Name = ""
        rPCombat(lPortID).lID = 0
    End If
End Sub
Public Sub subCombatEndedInitializeCombatCellsMobID(lMobID As Long)
On Error Resume Next
    'useful when a mob is killed.
    Dim lCount As Long
    For lCount = cstlMinPort To cstlMaxPort
        If (rMCombat(lCount).lID = lMobID) Then 'Find the port to clear
            subClearPortTotalXP lCount
            'player port is attacking this lMobID
            rSCombat(lCount).iStatus = cstiStatusNotInBattleMode 'stop combat
            
            MyDB.Execute "UPDATE tblMob SET PlayerID=0 WHERE (MobID=" & rMCombat(lCount).lID & ");", dbFailOnError
            rMCombat(lCount).Name = "" 'clear mob
            rMCombat(lCount).lID = 0
            
            'clear this player attacking this mob
            If (rPCombat(lCount).lID <> 0) Then MyDB.Execute "UPDATE tblPlayer SET Status = 5 WHERE (PlayerID=" & rPCombat(lCount).lID & ");", dbFailOnError
            rPCombat(lCount).Name = ""
            rPCombat(lCount).lID = 0
        End If
    Next lCount
End Sub
Public Function zConvertHitPoints(lMHP As Long, lMHPBonus As Long, lMobLevel As Long, iType As Integer) As String
On Error Resume Next
    Const cstzBlockChar = "O"
    Dim lMaxMHP As Long
    Dim lRatio As Long
    Dim iCount As Integer
    Dim iColour As Integer
    Dim lCalcuHP As Long
    Dim zReturn As String
    
    lMaxMHP = (lMobLevel * cstMobHPRespawn)
    If (lMaxMHP < 1) Then lMaxMHP = 1 'prevents div by 0 error
    
    lCalcuHP = (lMHP - lMHPBonus) 'lMHPBonus will throw hitpoints off the screen
    If (lCalcuHP < 0) Then lCalcuHP = 0
    
    Select Case iType
        Case 1 'circles
            iColour = 0
            lRatio = ((lCalcuHP * 100) / lMaxMHP) / 4
            If (lRatio > 50) Then lRatio = 50
            For iCount = 0 To lRatio
                Select Case iCount
                    Case 0 To 3
                        If (iColour <> 1) Then
                            iColour = 1
                            zReturn = zReturn & gblzFBRED
                        End If
                    Case 4 To 9
                        If (iColour <> 2) Then
                            iColour = 2
                            zReturn = zReturn & "&r"
                        End If
                    Case 10 To 17
                        If (iColour <> 3) Then
                            iColour = 3
                            zReturn = zReturn & "&g"
                        End If
                    Case Else
                        If (iColour <> 4) Then
                            iColour = 4
                            zReturn = zReturn & gblzFBGRE
                        End If
                End Select
                zReturn = zReturn & cstzBlockChar
            Next iCount
            zReturn = zReturn & " HP"
        Case 2 'simple percent
            lRatio = ((lCalcuHP * 100) / lMaxMHP)
            Select Case lRatio
                Case 0 To 2
                    zReturn = "is nearly dead!"
                Case Else
                    zReturn = "has " & lRatio & "% health left"
            End Select
    End Select
    zConvertHitPoints = " " & zReturn
End Function
Public Function zCombatWeaponEmoteDesc(zWeaponType As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    
    Select Case Mid(UCase(zWeaponType), 1, 4)
        Case "NET"
            Select Case lRandom(2)
                Case 1
                    zReturn = "drag"
                Case 2
                    zReturn = "slap"
            End Select
        Case "POLE", "SPEA", "JAVI", "LANC"
            Select Case lRandom(5)
                Case 1
                    zReturn = "puncture"
                Case 2
                    zReturn = "poke"
                Case 3
                    zReturn = "jab"
                Case 4
                    zReturn = "stab"
                Case Else
                    zReturn = "stick"
            End Select
        Case "FLEX"
            Select Case lRandom(4)
                Case 1
                    zReturn = "whip"
                Case 2
                    zReturn = "lash"
                Case 3
                    zReturn = "strap"
                Case Else
                    zReturn = "hurt"
            End Select
        Case "TALO"
            Select Case lRandom(4)
                Case 1
                    zReturn = "claw"
                Case 2
                    zReturn = "rake"
                Case 3
                    zReturn = "scar"
                Case Else
                    zReturn = "injure"
            End Select
        Case "BLUD", "PUGI"
            Select Case lRandom(4)
                Case 1
                    zReturn = "pound"
                Case 2
                    zReturn = "bash"
                Case 3
                    zReturn = "pulverize"
                Case Else
                    zReturn = "crush"
            End Select
        Case "SSTA", "LSTA"
            Select Case lRandom(6)
                Case 1
                    zReturn = "longarm"
                Case 2
                    zReturn = "lunge-poke"
                Case 3
                    zReturn = "lunge"
                Case 4
                    zReturn = "club"
                Case 5
                    zReturn = "bat"
                Case Else
                    zReturn = "jab"
            End Select
        Case "SAXE", "GAXE"
            Select Case lRandom(4)
                Case 1
                    zReturn = "slice"
                Case 2
                    zReturn = "cut"
                Case 3
                    zReturn = "hack"
                Case Else
                    zReturn = "split"
            End Select
        Case "TALO"
            Select Case lRandom(3)
                Case 1
                    zReturn = "scratch"
                Case 2
                    zReturn = "scrape"
                Case Else
                    zReturn = "claw"
            End Select
        Case "SLIN", "NET"
            Select Case lRandom(3)
                Case 1
                    zReturn = "smack"
                Case 2
                    zReturn = "pommel"
                Case Else
                    zReturn = "whack"
            End Select
        Case "BOW", "XBOW"
            Select Case lRandom(6)
                Case 1
                    zReturn = "smack"
                Case 2
                    zReturn = "pommel"
                Case 3
                    zReturn = "poke"
                Case 4
                    zReturn = "tip"
                Case 5
                    zReturn = "jab"
                Case Else
                    zReturn = "whack"
            End Select
        Case Else 'slashing weapon LBLA SBLA and anything else
            Select Case lRandom(9)
                Case 1
                    zReturn = "slash"
                Case 2
                    zReturn = "strike"
                Case 3
                    zReturn = "slice"
                Case 4
                    zReturn = "cut"
                Case 5
                    zReturn = "stab"
                Case 6
                    zReturn = "lunge-stab"
                Case 7
                    zReturn = "poke"
                Case 8
                    zReturn = "jab"
                Case Else
                    zReturn = "hit"
            End Select
    End Select
    zCombatWeaponEmoteDesc = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zCombatWeaponEmoteDesc," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnAreaWhereName(lX As Long, lY As Long, lZ As Long) As String
On Error GoTo Err_Check
    Dim rsQM As Recordset
    Dim zWhere As String
    Dim zGetAWName As String
    
    zWhere = ""
    Set rsQM = MyDB.OpenRecordset("SELECT tblArea.AreaName, tblWhere.WhereTitle FROM tblArea INNER JOIN tblWhere ON tblArea.WhereID = tblWhere.WhereID WHERE (((tblArea.X)=" & lX & ") AND ((tblArea.Y)=" & lY & ") AND ((tblArea.Z)=" & lZ & "));", dbOpenSnapshot)
    If (Not rsQM.EOF) Then
        zGetAWName = MyCStr(rsQM!AreaName)
        If (Len(zGetAWName) > 0) Then zWhere = zWhere & zGetAWName
        
        zGetAWName = MyCStr(rsQM!WhereTitle)
        If (Len(zGetAWName) > 0) Then
            If (Len(zWhere) > 0) Then zWhere = zWhere & " - "
            zWhere = zWhere & (zGetAWName)
        End If
    End If
    Set rsQM = Nothing
    zReturnAreaWhereName = zWhere
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnAreaWhereName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPlayerDuelingWeapon(lPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsPlr As Recordset
    Dim zReturn As String
    zReturn = ""
    Set rsPlr = MyDB.OpenRecordset("SELECT tblObject.WeaponType, tblObject.ObjectName, tblPlayerEquipmentItems.PlayerID, tblPlayerEquipmentItems.LocationLR, tblPlayerEquipmentItems.Location FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerEquipmentItems.LocationLR)='R') AND ((tblPlayerEquipmentItems.Location)=20));", dbOpenDynaset)
    If (Not rsPlr.EOF) Then
        If (Len(MyCStr(rsPlr!WeaponType)) <> 0) Then
            zReturn = zShortstop(MyCStr(rsPlr!ObjectName))
            zReturn = zAdverb(zReturn, 4) & zReturn
        End If
    End If
    Set rsPlr = Nothing
    zReturnPlayerDuelingWeapon = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPlayerDuelingWeapon," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iReturnTotalWeaponsHeld(lPlayerID As Long) As Integer
On Error GoTo Err_Check
    Dim rsPlr As Recordset
    Dim iReturn As Integer
    iReturn = 0
    Set rsPlr = MyDB.OpenRecordset("SELECT tblObject.WeaponType, tblObject.ObjectName, tblPlayerEquipmentItems.PlayerID, tblPlayerEquipmentItems.LocationLR, tblPlayerEquipmentItems.Location FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerEquipmentItems.Location)=20));", dbOpenDynaset)
    If (Not rsPlr.EOF) Then
        rsPlr.MoveLast
        iReturn = rsPlr.RecordCount
    End If
    Set rsPlr = Nothing
    iReturnTotalWeaponsHeld = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iReturnTotalWeaponsHeld," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subCombatInitPlayersAttackingMob(lMobID As Long)
On Error GoTo Err_Check
    Dim lPortID As Long
    For lPortID = cstlMinPort To cstlMaxPort
        If (rMCombat(lPortID).lID = lMobID) Then
            subCombatInitPort MyCStr(lPortID)
        End If
    Next lPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatInitPlayersAttackingMob," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bMobActivatlyInCombat(lMobID As Long) As Long
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim lPortID As Long
    bReturn = False
    lPortID = cstlMinPort
    Do While (Not bReturn And lPortID <= cstlMaxPort)
        If (rMCombat(lPortID).lID = lMobID) Then
            bReturn = True
        End If
        lPortID = lPortID + 1
    Loop
    bMobActivatlyInCombat = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bMobActivatlyInCombat," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subCombatInitPort(zPortID As String)
On Error GoTo Err_Check
    Dim iPortID As Integer
    
    iPortID = MyCInt(zPortID)
    
    If (iPortID >= cstlMinPort And iPortID <= cstlMaxPort) Then
        rSCombat(iPortID).iStatus = cstiStatusNotInBattleMode 'Mob or player left the battle
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatInitPort," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatInTheRealm()
On Error GoTo Err_Check
'See also: iPlayerHitPointTest bCombatMvP subCombatPvM subCombatPvP
    Dim lPortID As Long
    
    Select Case lRandom(4)
        Case 1, 4
            For lPortID = cstlMinPort To cstlMaxPort 'We go through and do the battles for all of the ports
                Select Case rSCombat(lPortID).iStatus
                    Case cstiStatusPlayerVsMob, cstiStatusPlayerIgnoredVsMob
                        subCombatPvM lPortID 'this handles the player attack then the mob atack
                    Case cstiStatusPlayerVsPlayer
                        subCombatPvP lPortID 'this only does the atack on the player because their port is in the loop for them to attack back.
                End Select
            Next lPortID
        Case 2, 3
            For lPortID = cstlMaxPort To cstlMinPort Step -1 'We go through and do the battles for all of the ports
                Select Case rSCombat(lPortID).iStatus
                    Case cstiStatusPlayerVsMob, cstiStatusPlayerIgnoredVsMob
                        subCombatPvM lPortID 'this handles the player attack then the mob atack
                    Case cstiStatusPlayerVsPlayer
                        subCombatPvP lPortID 'this only does the atack on the player because their port is in the loop for them to attack back.
                End Select
            Next lPortID
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatInTheRealm," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lTotalPlayerPets(lPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim rsTotal As Recordset
    Dim lReturn As Long
    lReturn = 0
    Set rsTotal = MyDB.OpenRecordset("SELECT PlayerID FROM tblPlayerPet WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsTotal.EOF) Then
        rsTotal.MoveLast
        lReturn = rsTotal.RecordCount
    End If
    Set rsTotal = Nothing
    lTotalPlayerPets = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTotalPlayerPets," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zStripEvolveNames(zPassOriginalPetName As String) As String
    Dim zReturn As String 'we strip all possible other names before we give them a new Evolve name
    zReturn = zPassOriginalPetName
    zReturn = strReplaceWordWithThisWord(zReturn, "younger", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "young", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "older", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "old", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "immature", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "junior", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "pubescent", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "teenage", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "child", "")
    'Evolution names we use - we remove the old ones
    zReturn = strReplaceWordWithThisWord(zReturn, "baby", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "toddler", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "minor", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "puerile", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "juvenile", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "adolescent", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "teen", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "adult", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "mature", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "aged", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "wise", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "epic", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "antique", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "emeritus", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "seminal", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "epochal", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "iconic", "")
    zReturn = strReplaceWordWithThisWord(zReturn, "ancient", "")
    zStripEvolveNames = zReturn
    Exit Function
End Function
Public Function zTranslatePetEvolve(lPassPetEvolve As Long) As String
    Dim zReturn As String
    zReturn = "baby"
    Select Case lPassPetEvolve
        Case 2
            zReturn = "toddler"
        Case 3
            zReturn = "minor"
        Case 4
            zReturn = "puerile"
        Case 5
            zReturn = "juvenile"
        Case 6
            zReturn = "adolescent"
        Case 7
            zReturn = "teen"
        Case 8
            zReturn = "adult"
        Case 9
            zReturn = "mature"
        Case 10
            zReturn = "aged"
        Case 11
            zReturn = "wise"
        Case 12
            zReturn = "epic"
        Case 13
            zReturn = "antique"
        Case 14
            zReturn = "emeritus"
        Case 15
            zReturn = "seminal"
        Case 16
            zReturn = "epochal"
        Case 17
            zReturn = "iconic"
        Case 18
            zReturn = "ancient"
    End Select
    zTranslatePetEvolve = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslatePetEvolve," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Function lPetXPGainMath(lPlayerCHA As Long, lMobLevel As Long, lPetLevel As Long) As Long
    Dim lReturn As Long
    lReturn = (cstlPetLevelXP * lMobLevel * lPetLevel) - (lPlayerCHA * 8)
    If (lReturn < 1) Then lReturn = 1
    lPetXPGainMath = lReturn
End Function
Public Sub subPlayerLoad(zPortID As String, zSearchMissileContainerName As String)
On Error GoTo Err_Check 'This is ammo-reload
    Dim lBaseAmmoCost As Long

    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lGold As Long
    Dim zPlayerRace As String
    Dim zClass As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lInvisibilityDuration As Long
    
    Dim rsMissileContainer As Recordset
    Dim zMissileContainerName As String
    Dim lCopyMissileGroupAmount As Long
    Dim lCopyMagazineMAX As Long
    Dim lMissileContainerDmg As Long
    Dim lAmmoCost As Long
    Dim lTopObject As Long
    Dim zWeaponType As String
    Dim bSpotOn As Boolean
    
    lTopObject = lTop(zSearchMissileContainerName)
    
    If (Len(zSearchMissileContainerName) <> 0) Then
        lBaseAmmoCost = 7
        lPlayerID = 0
        Set rsPlayer = MyDB.OpenRecordset("SELECT Race, CamoflaguedDuration, InvisibilityDuration, PlayerName, X, Y, Z, PlayerID, Gold, Class FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            zPlayerRace = MyCStr(rsPlayer!Race)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lGold = MyCLng(rsPlayer!Gold)
            zClass = MyCStr(rsPlayer!Class)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration) + MyCLng(rsPlayer!CamoflaguedDuration)
        End If
        Set rsPlayer = Nothing
        
        If (lPlayerID <> 0) Then
            bSpotOn = (lngSQLRecordCount("SELECT CanRefil FROM tblMob WHERE (RespawnDelay=0 AND CanRefil>0 AND X=" & lX & " AND Y= " & lY & " AND Z=" & lZ & ");") > 0)
            If (zPlayerRace = "HUM" Or zPlayerRace = "HAL" Or zPlayerRace = "ELF" Or bSpotOn) Then
                If (Not bSpotOn) Then lBaseAmmoCost = lBaseAmmoCost * 7 'the race is loading not at a load site
                If (lInvisibilityDuration = 0) Then
                    If (lGold > 0) Then
                        'If (bWhenIsIt("", False)) Then 'unremark to make time a factor
                            Set rsMissileContainer = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " tblObject.WeaponType, tblObject.ObjectName, tblObject.MagazineMAX, tblObject.MissileGroupAmount FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE ( (tblPlayerInventoryItems.PlayerID=" & lPlayerID & ") AND (tblObject.ObjectName Like '*" & zSearchMissileContainerName & "*') AND (tblObject.WeaponType='ARRO' OR tblObject.WeaponType='BOLT' OR tblObject.WeaponType='AMMO' OR tblObject.WeaponType='CLIP' OR tblObject.WeaponType='ENER' OR tblObject.WeaponType='BLAS') );", dbOpenDynaset)
                            If (Not rsMissileContainer.EOF) Then
                                rsMissileContainer.MoveLast
                                zWeaponType = MyCStr(rsMissileContainer!WeaponType)
                                zMissileContainerName = rsMissileContainer!ObjectName
                                lCopyMissileGroupAmount = MyCLng(rsMissileContainer!MissileGroupAmount)
                                lCopyMagazineMAX = MyCLng(rsMissileContainer!MagazineMAX)
                                lMissileContainerDmg = lCopyMagazineMAX - lCopyMissileGroupAmount
                                If (lMissileContainerDmg > 0) Then
                                    lAmmoCost = lBaseAmmoCost + lMissileContainerDmg
                                    Select Case zWeaponType
                                        Case "STON"
                                            lAmmoCost = lAmmoCost + lMissileContainerDmg
                                        Case "ARRO"
                                            lAmmoCost = lAmmoCost + (lMissileContainerDmg * 2)
                                        Case "BOLT"
                                            lAmmoCost = lAmmoCost + (lMissileContainerDmg * 3)
                                        Case "AMMO", "CLIP"
                                            lAmmoCost = lAmmoCost + (lMissileContainerDmg * 7)
                                        Case "BLAS", "ENER"
                                            lAmmoCost = lAmmoCost + (lMissileContainerDmg * 12)
                                    End Select
                                    
                                    If (Not bWhenIsIt("", False)) Then
                                        subSendMsg "&BExtra price on off-hour sales!", zPortID
                                        lAmmoCost = lAmmoCost * 3
                                    End If
                                    If (Not bSpotOn) Then
                                        Select Case zPlayerRace
                                            Case "HUM"
                                                lAmmoCost = lAmmoCost + 2000
                                            Case "HAL"
                                                lAmmoCost = lAmmoCost + 4000
                                            Case "ELF"
                                                lAmmoCost = lAmmoCost + 900
                                            Case Else
                                                lAmmoCost = lAmmoCost + 5000
                                        End Select
                                    End If
                                    If (lAmmoCost <= lGold) Then
                                        rsMissileContainer.Edit
                                        rsMissileContainer!MissileGroupAmount = lCopyMagazineMAX
                                        rsMissileContainer.Update
                                        lGold = lGold - lAmmoCost
                                        
                                        MyDB.Execute "UPDATE tblPlayer SET Gold=" & lGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        subSendMsg "&yYour Missile Container " & zMissileContainerName & " is now loaded to its fullest capacity!" & vbCrLf & "The Ammo-specialist charged you " & lAmmoCost & " gold.", zPortID
                                        subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " has the Ammo-specialist fully fill " & zAdverb(zMissileContainerName, 2) & zMissileContainerName & ".", lX, lY, lZ, zPortID, ""
                                    Else
                                        subSendMsg "&gYou need " & lAmmoCost & " gold to fully load your Missile Container " & zMissileContainerName & "." & vbCrLf & "You are short " & (lAmmoCost - lGold) & " gold.", zPortID
                                    End If
                                Else
                                    subSendMsg "&GYe should know that " & zMissileContainerName & " does not require reloading.", zPortID
                                End If
                            Else
                                subSendMsg "&gThat Missile Container was not found in your group." & vbCrLf & "SYNTAX: LOAD MissileContainerNAME" & vbCrLf & "The container must be in your inventory.", zPortID
                            End If
                            Set rsMissileContainer = Nothing
                        'Else
                            'subSendMsg "&BThe Ammo specialist is closed at night!", zPortID
                        'End If
                    Else
                        subSendMsg "&gYou are not carrying any gold.", zPortID
                    End If
                Else
                    subSendMsgAreaAll "&yThe Ammo-specialist says, '" & zPlayerName & " is that you? You and your Missile Container are invisible!'", lX, lY, lZ
                End If
            Else
                subSendMsg "&gAn Ammo-specialist was not found here." & vbCrLf & "SYNTAX: LOAD MissileContainerNAME" & vbCrLf & "The container must be in your inventory.", zPortID
            End If
        End If
    Else
        subSendMsg "&gLOAD MissileContainer?" & vbCrLf & "Similar MissileContainer names?" & vbCrLf & " LOAD 1.MissileContainerNAME" & vbCrLf & " LOAD 2.MissileContainerNAME" & vbCrLf & " LOAD 3.MissileContainerNAME" & vbCrLf & " You can number select similar names.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerVet(zPortID As String, zSearchPetName As String)
On Error GoTo Err_Check
    Const cstlBaseVetCost = 50

    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lGold As Long
    Dim zClass As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lInvisibilityDuration As Long
    
    Dim rsPet As Recordset
    Dim zPetName As String
    Dim lCopyMobLevel As Long
    Dim lCopyPetLevel As Long
    Dim lCopyPetHitPointsCurrent As Long
    Dim lCopyPetHitPointsMax As Long
    Dim lTranslateCPPAllowed As Long
    Dim lPetDmg As Long
    Dim lVetCost As Long
    Dim lTopObject As Long
    Dim lPetHPBonus As Long
    Dim lCCHA As Long
    
    lTopObject = lTop(zSearchPetName)
    
    If (Len(zSearchPetName) <> 0) Then
        lPlayerID = 0
        Set rsPlayer = MyDB.OpenRecordset("SELECT CCHA, CamoflaguedDuration, InvisibilityDuration, PlayerName, X, Y, Z, PlayerID, Gold, Class FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lCCHA = MyCLng(rsPlayer!CCHA)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lGold = MyCLng(rsPlayer!Gold)
            zClass = MyCStr(rsPlayer!Class)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration) + MyCLng(rsPlayer!CamoflaguedDuration)
        End If
        Set rsPlayer = Nothing
        
        If (lPlayerID <> 0) Then
            If (lngSQLRecordCount("SELECT PetVeterinarianMaxLevel FROM tblMob WHERE (RespawnDelay=0 AND PetVeterinarianMaxLevel>0 AND X=" & lX & " AND Y= " & lY & " AND Z=" & lZ & ");") > 0) Then
                If (lInvisibilityDuration = 0) Then
                    If (lGold > 0) Then
                        'If (bWhenIsIt("", False)) Then
                            Set rsPet = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " * FROM tblPlayerPet WHERE (PlayerID=" & lPlayerID & " AND PetName Like '*" & zSearchPetName & "*');", dbOpenDynaset)
                            If (Not rsPet.EOF) Then
                                rsPet.MoveLast
                                lPetHPBonus = MyCLng(rsPet!PetHPBonus)
                                zPetName = rsPet!PetName
                                lCopyMobLevel = MyCLng(rsPet!MobLevel)
                                lCopyPetLevel = MyCLng(rsPet!PetLevel)
                                lTranslateCPPAllowed = lTranslateClassPlayerPetsAllowed(zClass)
                                lCopyPetHitPointsCurrent = MyCLng(rsPet!PetHitPoints)
                                lCopyPetHitPointsMax = (lCopyMobLevel * (MyCLng(cstlPetHPMultiplier / 2) + 1)) + (lCopyPetLevel * cstlPetHPMultiplier) + 1 + lTranslateCPPAllowed
                                lPetDmg = lCopyPetHitPointsMax - lCopyPetHitPointsCurrent
                                If (lPetDmg > 0) Then
                                    lVetCost = ((lCopyPetLevel * 5) + lPetDmg + cstlBaseVetCost)
                                    
                                    If (Not bWhenIsIt("", False)) Then
                                        If (zClass = "DR" Or lRandom(lCCHA) > lRandom(300)) Then
                                            If (zClass = "DR") Then
                                                subSendMsg "&y'A Druid! I shall help thee with no additional charge for night service!'", zPortID
                                            Else
                                                subSendMsg "&y'Oh I am all too happy to help such a charming person at no extra charge, even during my rest time!'", zPortID
                                            End If
                                        Else
                                            subSendMsg "&y'Emergency service at night is double the cost!'", zPortID
                                            lVetCost = (lVetCost * 2)
                                        End If
                                    Else
                                        If (zClass = "DR") Then
                                            subSendMsg "&y'A Druid! " & lVetCost & " gold is too much! I can cut that price by half!'", zPortID
                                            lVetCost = MyCLng(lVetCost / 2)
                                        End If
                                    End If
                                    
                                    If (lVetCost <= lGold) Then
                                        rsPet.Edit
                                        rsPet!PetHitPoints = lCopyPetHitPointsMax + lPetHPBonus
                                        rsPet.Update
                                        lGold = lGold - lVetCost
                                        MyDB.Execute "UPDATE tblPlayer SET Gold=" & lGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        subSendMsg "&yYour pet " & zPetName & " was fully healed!" & vbCrLf & "The Veterinarian charged you " & lVetCost & " gold.", zPortID
                                        subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " has the Veterinarian fully heal " & zAdverb(zPetName, 2) & zPetName & ".", lX, lY, lZ, zPortID, ""
                                    Else
                                        subSendMsg "&gYou need " & lVetCost & " gold to fully heal your pet " & zPetName & "." & vbCrLf & "You are short " & (lVetCost - lGold) & " gold.", zPortID
                                    End If
                                Else
                                    subSendMsg "&GYour pet " & zPetName & " does not require any healing.", zPortID
                                End If
                            Else
                                subSendMsg "&gThat pet was not found in your group." & vbCrLf & "SYNTAX: VET PETNAME", zPortID
                            End If
                            Set rsPet = Nothing
                        'Else
                            'subSendMsg "&BThe Veterinarians are closed at night." & vbCrLf & "SYNTAX: VET PETNAME", zPortID
                        'End If
                    Else
                        subSendMsg "&gYou are not carrying any gold.", zPortID
                    End If
                Else
                    subSendMsgAreaAll "&yThe Veterinarian says, '" & zPlayerName & " is that you? You and your pet are invisible!'", lX, lY, lZ
                End If
            Else
                subSendMsg "&gA Veterinarian was not found here." & vbCrLf & "SYNTAX: VET PETNAME", zPortID
            End If
        End If
    Else
        subSendMsg "&gVET Pet?" & vbCrLf & "Similar Pet names?" & vbCrLf & " VET 1.PETNAME" & vbCrLf & " VET 2.PETNAME" & vbCrLf & " VET 3.PETNAME" & vbCrLf & " You can number select similar names.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerVet," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerSkillsTrain(zPlayerName As String, lPlayerID As Long, lOX As Long, lOY As Long, lOZ As Long, zPortID As String, zWordCommandOrMobName As String, zWordMobName As String, lPlayerLevel As Long, zClass As String, lStatus As Long)
On Error GoTo Err_Check 'see also: zStripEvolveNames
    Dim rsTrainMob As Recordset
    Dim rsPlayerPet As Recordset
    Dim lPetTrainLevel As Long
    Dim zMobName As String
    Dim lCopyMobID As Long
    Dim lCopyMobLevel As Long
    Dim zCopyPetName As String
    Dim lCopyPetDamage As Long
    Dim lCopyPetHitPoints As Long
    Dim bCopyFlys As Boolean
    Dim lCopyMountableType As Long
    Dim lCopyPetEvolve As Long
    Dim lCopyPetHPBonus As Long
    Dim lCopyPetDRBonus As Long
    Dim lCopyPetHRBonus As Long
    Dim lCopyPetACBonus As Long
    Dim lCopyPetDisarmsTrapChance As Long
    Dim zCopyPetBreath As String
    Dim zCopyPetMountMsg As String
    Dim lCopyPetLevel As Long
    Dim zCopyPetClassSpecific As String
    Dim lGetTotalPlayerPets As Long
    Dim lTranslateCPPAllowed As Long
    Dim lTranslateCPPAllowedPL As Long
    
    If Len(MyCStr(zWordCommandOrMobName)) > 0 Then
    If (rSCombat(MyCLng(zPortID)).iStatus = 0) Then
        If (lStatus <> 50) Then
            lTranslateCPPAllowed = lTranslateClassPlayerPetsAllowed(zClass)
            lGetTotalPlayerPets = lTotalPlayerPets(lPlayerID)
            
            lCopyMobID = 0
            
            Select Case zWordCommandOrMobName
                Case "D", "DISB", "DISBAND" 'TRAIN DISBAND <PETname>
                    If Len(MyCStr(zWordMobName)) > 0 Then
                        Set rsTrainMob = MyDB.OpenRecordset("SELECT tblMob.MobID, tblPlayerPet.PlayerID, tblMob.MobName, tblMob.PetTrainLevel, tblMob.MobLevel FROM tblMob INNER JOIN tblPlayerPet ON tblMob.MobID = tblPlayerPet.MobID WHERE (((tblPlayerPet.PlayerID)=" & lPlayerID & ") AND ((tblMob.MobName) Like '*" & zKeepLettersOnly(zWordMobName) & "*') AND ((tblMob.PetTrainLevel)>0));", dbOpenSnapshot)
                        If (Not rsTrainMob.EOF) Then
                            lCopyMobID = MyCLng(rsTrainMob!MobID)
                            zMobName = MyCStr(rsTrainMob!MobName)
                            zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
                            lPetTrainLevel = MyCLng(rsTrainMob!PetTrainLevel)
                            zCopyPetName = MyCStr(rsTrainMob!MobName)
                            lCopyMobLevel = MyCLng(rsTrainMob!MobLevel)
                            lCopyPetLevel = 1
                            lCopyPetDamage = (MyCLng(lCopyMobLevel / 3) + 1) * lCopyPetLevel
                            If (lRandom(15) <= lTranslateCPPAllowed) Then
                                lTranslateCPPAllowedPL = lRandom(3)
                                lCopyPetLevel = lCopyPetLevel + lTranslateCPPAllowedPL
                                lCopyPetDamage = lCopyPetDamage * lTranslateCPPAllowedPL
                            End If
                            
                            Set rsTrainMob = Nothing
                            Set rsTrainMob = MyDB.OpenRecordset("SELECT MobID FROM tblPlayerPet WHERE (MobID=" & lCopyMobID & " AND PlayerID=" & lPlayerID & ");", dbOpenDynaset)
                            If (Not rsTrainMob.EOF) Then
                                rsTrainMob.Delete
                                subSendMsg "&gYou disband " & zMobName & " as a pet.", zPortID
                            Else
                                subSendMsg "&gYou do not have that pet trained to you.", zPortID
                            End If
                        Else
                            subSendMsg "&gYou may not have that pet trained to you. OR..." & vbCrLf & "Try to only use the pets real name," & vbCrLf & "do not include leading age titles." & vbCrLf & "Age-titles are word located right before their names.", zPortID
                            subSendMsg "&gWords not to use:" & vbCrLf & "younger young older old immature junior" & vbCrLf & "pubescent teenage child baby toddler minor" & vbCrLf & "puerile juvenile adolescent teen adult" & vbCrLf & "mature aged wise epic antique emeritus" & vbCrLf & "seminal epochal iconic ancient", zPortID
                        End If
                        Set rsTrainMob = Nothing
                    Else
                        subSendMsg "&gTRAIN DISBAND <single word of the PETname>", zPortID
                    End If
                Case Else
                    If (lGetTotalPlayerPets < lTranslateCPPAllowed) Then 'TRAIN <MobName>
                        zMobName = ""
                        Set rsTrainMob = MyDB.OpenRecordset("SELECT Flys, MountableType, PetMountMsg, PetClassSpecific, PetEvolve, PetHPBonus, PetDRBonus, PetHRBonus, PetACBonus, PetDisarmsTrapChance, PetBreath, MobID, MobName, PetTrainLevel, MobLevel FROM tblMob WHERE (RespawnDelay=0 AND MobName Like '*" & zKeepLettersOnly(zWordCommandOrMobName) & "*' AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND PetTrainLevel>0);", dbOpenSnapshot)
                        If (Not rsTrainMob.EOF) Then
                            lCopyMobID = MyCLng(rsTrainMob!MobID)
                            zMobName = MyCStr(rsTrainMob!MobName)
                            zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
                            lPetTrainLevel = MyCLng(rsTrainMob!PetTrainLevel)
                            zCopyPetName = MyCStr(rsTrainMob!MobName)
                            lCopyMobLevel = MyCLng(rsTrainMob!MobLevel)
                            lCopyPetEvolve = MyCLng(rsTrainMob!PetEvolve)
                            bCopyFlys = (MyCInt(rsTrainMob!Flys) <> 0)
                            lCopyMountableType = MyCLng(rsTrainMob!MountableType)
                            lCopyPetHPBonus = MyCLng(rsTrainMob!PetHPBonus)
                            lCopyPetDRBonus = MyCLng(rsTrainMob!PetDRBonus)
                            lCopyPetHRBonus = MyCLng(rsTrainMob!PetHRBonus)
                            lCopyPetACBonus = MyCLng(rsTrainMob!PetACBonus)
                            lCopyPetDisarmsTrapChance = MyCLng(rsTrainMob!PetDisarmsTrapChance)
                            zCopyPetBreath = MyCStr(rsTrainMob!PetBreath)
                            zCopyPetMountMsg = MyCStr(rsTrainMob!PetMountMsg)
                            zCopyPetClassSpecific = MyCStr(rsTrainMob!PetClassSpecific)
                        End If
                        Set rsTrainMob = Nothing
                        
                        If (Len(zMobName) > 0) Then
                            If ((zCopyPetClassSpecific = "") Or (UCase(zClass) = UCase(zCopyPetClassSpecific))) Then
                                Set rsTrainMob = MyDB.OpenRecordset("SELECT MobID FROM tblPlayerPet WHERE (MobID=" & lCopyMobID & " AND PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
                                If (rsTrainMob.EOF) Then
                                    If (lPetTrainLevel > 0) Then
                                        If (lPetTrainLevel <= lPlayerLevel) Then
                                            'We train the creature
                                            If (lRandom(9) <= lTranslateCPPAllowed) Then
                                                'We start the pets at a higher level sometimes
                                                lCopyPetLevel = lRandom(lTranslateCPPAllowedPL) + 2
                                            Else
                                                lCopyPetLevel = 1 'start the pet at level 1
                                            End If
                                            If (lCopyPetLevel = (lTranslateCPPAllowedPL + 2)) Then
                                                subSendMsg "&WGRATZ! " & gblzFBGRE & zMobName & " was *TRAINED* with maximum level!", zPortID
                                            Else
                                                subSendMsg "&G" & zMobName & " can be retrained, to level " & (lTranslateCPPAllowedPL + 2) & "." & vbCrLf & "&gTRAIN DISBAND <petname>", zPortID
                                            End If
                                            lCopyPetHitPoints = (lCopyMobLevel * (MyCLng(cstlPetHPMultiplier / 2) + 1)) + (lCopyPetLevel * cstlPetHPMultiplier) + 1 + lTranslateCPPAllowed
                                            lCopyPetDamage = (lCopyMobLevel) + (lCopyPetLevel * cstlPetDmgMultiplier) + 1 + lTranslateCPPAllowed
                                            
                                            MyDB.Execute "UPDATE tblMob SET RespawnDelay = " & cstlMobileRespawnDelay & " WHERE (MobID=" & lCopyMobID & ");", dbFailOnError 'mark mob as trained - trained mobs take longer to come back
                                            Set rsPlayerPet = MyDB.OpenRecordset("tblPlayerPet", dbOpenTable)
                                            rsPlayerPet.AddNew
                                            rsPlayerPet!MobID = lCopyMobID
                                            rsPlayerPet!PlayerID = lPlayerID
                                            rsPlayerPet!MobLevel = lCopyMobLevel
                                            rsPlayerPet!PetName = zShortstop(zCopyPetName)
                                            rsPlayerPet!PetDamage = lCopyPetDamage
                                            rsPlayerPet!PetLevel = lCopyPetLevel
                                            rsPlayerPet!PetHitPoints = lCopyPetHitPoints
                                            rsPlayerPet!PetEvolve = lCopyPetEvolve
                                            rsPlayerPet!Flys = bCopyFlys
                                            rsPlayerPet!MountableType = lCopyMountableType
                                            rsPlayerPet!PetHPBonus = lCopyPetHPBonus
                                            rsPlayerPet!PetDRBonus = lCopyPetDRBonus
                                            rsPlayerPet!PetHRBonus = lCopyPetHRBonus
                                            rsPlayerPet!PetACBonus = lCopyPetACBonus
                                            rsPlayerPet!PetDisarmsTrapChance = lCopyPetDisarmsTrapChance
                                            rsPlayerPet!PetBreath = zCopyPetBreath
                                            rsPlayerPet!PetMountMsg = zCopyPetMountMsg
                                            rsPlayerPet!PetClassSpecific = zCopyPetClassSpecific
                                            rsPlayerPet.Update
                                            Set rsPlayerPet = Nothing
                                            subSendMsg "&yYou successfully train " & zMobName & ".", zPortID
                                            subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " successfully trains " & zMobName & ".", lOX, lOY, lOZ, zPortID, ""
                                        Else
                                            subSendMsg "&gYou cannot train " & zMobName & " until you are level " & lPetTrainLevel & ".", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gThat is not here to train.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYou already have " & zMobName & " trained to you, seek out other trainable pets.", zPortID
                                End If
                                Set rsTrainMob = Nothing
                            Else
                                subSendMsg "&gPet is trainable only for a " & zTranslateClass(zCopyPetClassSpecific) & ".", zPortID
                            End If
                        Else
                            subSendMsg "&gThat trainable pet was not found here. OR..." & vbCrLf & "Try to only use the pets real name," & vbCrLf & "do not include leading age titles." & vbCrLf & "Age-titles are word located right before their names.", zPortID
                        End If
                    Else
                        subSendMsg "&gYou are not allowed more than " & lTranslateCPPAllowed & " pets." & vbCrLf & "See Also: TRAIN DISBAND <single word from PETname>", zPortID
                    End If
            End Select
        Else
            subSendMsg "&GYou dream of breading and training creatures of the realm.", zPortID
        End If
    Else
        subSendMsg "&gYou cannot do that while you are fighting! [try to FLEE]", zPortID
    End If
    Else
        subSendMsg "&gSYNTAX: TRAIN <one word from the MOBname>" & vbCrLf & "        TRAIN DISBAND [123]<PETname>", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerSkillsTrain," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatCreatePlayerHeartOnGround(zPlayerName As String, zObjectDesc As String, lOX As Long, lOY As Long, lOZ As Long)
On Error GoTo Err_Check
    Dim zObjectName As String
    'lPlayerID is the one who one the battle, they have dibs on the heart
    zObjectName = zPlayerName & "'s heart stopped on " & Format(Date, "mmm-dd-yyyy") & " at " & Format(Time(), "HH:NN")
    MyDB.Execute "INSERT INTO tblObject ( DurabilityBroken, DurabilityMAX, Weight, Location, ObjectName, ObjectDesc, MurderPlayerHeart, X, Y, Z ) SELECT 1, 1, 217, 20, """ & zObjectName & """, """ & zObjectDesc & """, Yes, " & lOX & ", " & lOY & ", " & lOZ & ";", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatCreatePlayerHeartOnGround," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatCreatePlayerCrossOnGround(zPlayerName As String, zMobName As String, lOX As Long, lOY As Long, lOZ As Long)
On Error GoTo Err_Check
    Const cstlRottingRounds = 20
    Dim zObjectName As String
    Dim zObjectDesc As String
    Dim lNewCorpseID As Long
    Dim rsCross As Recordset
    
    If (lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND Location=0 AND RottingRounds>0);") < 2) Then 'we dont want more than a few crosses in the area
        zObjectName = zPlayerName & "s Cross, is here with writing on it"
        zObjectDesc = "Epitaph reads: " & zPlayerName & " was killed in battle!" & vbCrLf & "On " & Format(Date, "mmm-dd-yyyy") & " at " & Format(Time(), "HH:NN") & vbCrLf & "By " & zMobName 'vbCrLf will not work here
        
        Set rsCross = MyDB.OpenRecordset("tblObject", dbOpenDynaset)
        rsCross.AddNew
        lNewCorpseID = rsCross!ObjectID
        rsCross!DurabilityBroken = 1
        rsCross!DurabilityMAX = 1
        rsCross!Weight = 417
        rsCross!Location = 0
        rsCross!ObjectName = zObjectName
        rsCross!ObjectDesc = zObjectDesc
        rsCross!RottingRounds = cstlRottingRounds
        rsCross!x = lOX
        rsCross!y = lOY
        rsCross!z = lOZ
        rsCross.Update
        Set rsCross = Nothing
        
        'MyDB.Execute "INSERT INTO tblObject ( DurabilityBroken, DurabilityMAX, Weight, Location, ObjectName, ObjectDesc, RottingRounds, X, Y, Z ) SELECT 1, 1, 217, 0, """ & zObjectName & """, """ & zObjectDesc & """, " & cstlRottingRounds & ", " & lOX & ", " & lOY & ", " & lOZ & ";", dbFailOnError
        MyDB.Execute "INSERT INTO tblMobCorpses(ObjectID) SELECT " & lNewCorpseID & ";", dbFailOnError
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatCreatePlayerCrossOnGround," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bAreaGloryChallengeZone(lPAX, lPAY, lPAZ) As Boolean
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim bReturn As Boolean
    Set rsArea = MyDB.OpenRecordset("SELECT AreaID FROM tblArea WHERE (X=" & lPAX & " AND Y=" & lPAY & " AND Z=" & lPAZ & " AND GloryChallengeZone=True);", dbOpenSnapshot)
    bReturn = (Not rsArea.EOF)
    Set rsArea = Nothing
    bAreaGloryChallengeZone = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaGloryChallengeZone," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub basCaptureTheFlag(zPortID As String)
On Error GoTo Err_Check
    Dim rsClan As Recordset
    Dim lCount As Long
    Dim rsCaptureFlagClan As Recordset
    Dim zObjectName As String
    Dim rsPlayer As Recordset
    Dim lLostFlagPlayerID As Long
    Dim zReturnedByPlayerName As String
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        lLostFlagPlayerID = MyCLng(rsPlayer!PlayerID)
        zReturnedByPlayerName = MyCStr(rsPlayer!PlayerName)
    End If
    Set rsPlayer = Nothing
        
    Set rsClan = MyDB.OpenRecordset("SELECT GroundTimerNotAvailable, GroundTimer, SpecialSelfDeletingDelay, CaptureFlagClanID, ObjectName, Status, PlayerID, X, Y, Z FROM tblObject WHERE (PlayerID=" & lLostFlagPlayerID & " AND CaptureFlagClanID<>0);", dbOpenDynaset)
    If (Not rsClan.EOF) Then
        lCount = 0
        zObjectName = (zShortstop(MyCStr(rsClan!ObjectName)))
        'There is at least one flag that player has that must be returned
        'Return all captured flags
        'Remove from equipment link
        MyDB.Execute "DELETE tblPlayerEquipmentItems.* FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lLostFlagPlayerID & ") AND ((tblObject.CaptureFlagClanID)<>0));", dbFailOnError
        'remove from inventory link
        MyDB.Execute "DELETE tblPlayerInventoryItems.* FROM tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lLostFlagPlayerID & ") AND ((tblObject.CaptureFlagClanID)<>0));", dbFailOnError
        'remove from containers link
        MyDB.Execute "DELETE tblPlayerContainer.* FROM tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ObjectID WHERE (((tblPlayerContainer.PlayerID)=" & lLostFlagPlayerID & ") AND ((tblObject.CaptureFlagClanID)<>0));", dbFailOnError
        'we now locate all the flags to the proper location
        Do While (Not rsClan.EOF)
            lCount = lCount + 1
            Set rsCaptureFlagClan = MyDB.OpenRecordset("SELECT ClanFlagReturnX, ClanFlagReturnY, ClanFlagReturnZ FROM tblPlayerClan WHERE (ClanID=" & MyCLng(rsClan!CaptureFlagClanID) & ");", dbOpenSnapshot)
            rsClan.Edit
            rsClan!Status = 0
            rsClan!PlayerID = 0
            rsClan!x = MyCLng(rsCaptureFlagClan!ClanFlagReturnX)
            rsClan!y = MyCLng(rsCaptureFlagClan!ClanFlagReturnY)
            rsClan!z = MyCLng(rsCaptureFlagClan!ClanFlagReturnZ)
            rsClan!GroundTimer = 0
            rsClan!GroundTimerNotAvailable = True
            rsClan!SpecialSelfDeletingDelay = 0
            rsClan.Update
            Set rsCaptureFlagClan = Nothing
            
            'subFlagReturned zObjectName, zReturnedByPlayerName
            rsClan.MoveNext
        Loop
        
        Select Case lCount
            Case 1
                subSimpleEchoChannel "&G" & zObjectName & " was returned by " & zReturnedByPlayerName & "!"
            Case 2
                subSimpleEchoChannel "&GTwo clan flags were returned by " & zReturnedByPlayerName & "!"
            Case 3
                subSimpleEchoChannel "&GThree clan flags were returned by " & zReturnedByPlayerName & "!"
            Case 4
                subSimpleEchoChannel "&GFour clan flags were returned by " & zReturnedByPlayerName & "!"
            Case 5
                subSimpleEchoChannel "&GFive clan flags were returned by " & zReturnedByPlayerName & "!"
            Case Else
                subSimpleEchoChannel "&G" & lCount & " clan flags were returned by " & zReturnedByPlayerName & "!"
        End Select
    End If
    Set rsClan = Nothing
    
    subRecalculatePlayerEquipment lLostFlagPlayerID, zPortID 'When the battle is done and all the calculations are in we update the player tables.
    Exit Sub
Err_Check:
    subWriteErrorFile "basCaptureTheFlag," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subCombatPvP(lPortID As Long)
On Error GoTo Err_Check 'See also: iPlayerHitPointTest bCombatMvP subCombatPvM subCombatPvP
'Called from subCombatInTheRealm
    Dim rsPlrAttacker As Recordset
    Dim rsPlrDefender As Recordset
    Dim bRecalculatePlayers As Boolean
    Dim zAttackRound As String
    
    Dim lCount As Long
    Dim lDamageXP As Long
    Dim bPlayerDied As Boolean
    Dim lPATotalHits As Long
    Dim lPAPlayerID As Long
    Dim lPACHITROLL As Long
    Dim lPACDAMROLL As Long
    Dim lPACAC As Long
    Dim lPACHR As Long 'Player Attacker Charisma helps pets a lot!
    Dim zPAPortID As String
    Dim lPAPortID As Long
    Dim zPAName As String
    Dim zPAClass As String
    Dim zPARace As String
    Dim lPAX As Long
    Dim lPAY As Long
    Dim lPAZ As Long
    Dim lPAScared As Long
    Dim lCountNumAttRnd As Long
    Dim lNumAttRnd As Long
    Dim lPABlindDuration As Long
    Dim lPAStunDuration As Long
    Dim lPASleepDuration As Long
    Dim lPAPlayerLevel As Long
    Dim lPAPetDamage As Long
    Dim bBlindFight As Boolean
    Dim bStunFight As Boolean
    Dim lPAGlory As Long
    Dim lPACleaveChance As Long
    
    Dim lPDPlayerID As Long
    Dim lPDCleaveDuration As Long
    Dim lPDCAC As Long
    Dim zPDPortID As String
    Dim lPDPortID As Long
    Dim zPDName As String
    Dim lPDPlayerLevel As Long
    Dim lPDGlory As Long
    Dim zPDClass As String
    Dim zPDRace As String
    Dim lPDCHitPoints As Long
    Dim lPACHitPoints As Long
    Dim lPACHitPointsMAX As Long
    Dim lPDImmortalLevel As Long
    Dim iLearnBlock As Integer
    Dim rsLearnBlock As Recordset
    Dim zLearn As String
    Dim rsLearn As Recordset
    Dim lPACTotalHPDmg As Long
    
    Dim lClanMemberLevel As Long
    
    Dim lPATotalMartialArts As Long
    Dim lPATotalMartialArtsUsed As Long
    Dim lPATotalMartialArtsMath As Long
    Dim lMartialArtsKungPowLevel As Long
    Dim lMartialArtsLungingElbowsLevel As Long
    Dim lMartialArtsTigerFistsLevel As Long
    Dim lMartialArtsTuskPunchLevel As Long
    Dim lPACHITROLLMArtsBonus As Long
    Dim lPACDAMROLLMArtsBonus As Long
    Dim lPAFlyDuration As Long
    Dim bSlayed As Boolean 'if the defender is slayed the battle should end
    Dim lPAIASChance As Long
    Dim lPATurnedIntoAnimalType As Long
    Dim lPDTurnedIntoAnimalType As Long
    Dim lPASlayChance As Long
    Dim lPDIASChance As Long
    Dim lCalcuIASChance As Long
    Dim lHallucinate As Long
    Dim bDay As Boolean
    
    bRecalculatePlayers = False
    
    bDay = bWhenIsIt("", False)
    
    bSlayed = False
    
    lPATotalHits = 0
    bPlayerDied = False
    
    lPACTotalHPDmg = 0
    lPAPortID = lPortID
    zPAPortID = MyCStr(lPortID)
    Set rsPlrAttacker = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PortID='" & zPAPortID & "');", dbOpenDynaset)
    If (Not rsPlrAttacker.EOF) Then
        lHallucinate = MyCLng(rsPlrAttacker!Hallucinate)
        lPACHitPoints = MyCLng(rsPlrAttacker!CHP)
        lPACHitPointsMAX = MyCLng(rsPlrAttacker!OHP)
        lPASlayChance = MyCLng(rsPlrAttacker!SlayChance)
        If (lHallucinate > 0) Then lPASlayChance = 1
        zPAName = MyCStr(rsPlrAttacker!PlayerName)
        lPACleaveChance = MyCLng(rsPlrAttacker!CleaveChance)
        zPARace = MyCStr(rsPlrAttacker!Race)
        zPAClass = MyCStr(rsPlrAttacker!Class)
        Select Case zPAClass
            Case "KN"
                lPASlayChance = lPASlayChance + lRandom(lPASlayChance / 2)
        End Select
        lPAIASChance = MyCLng(rsPlrAttacker!IASChance)
        lPATurnedIntoAnimalType = MyCLng(rsPlrAttacker!TurnedIntoAnimalType)
        lPAX = MyCLng(rsPlrAttacker!x)
        lPAY = MyCLng(rsPlrAttacker!y)
        lPAZ = MyCLng(rsPlrAttacker!z)
        If (lRandom(lTranslatePlayerRaceClassIAS(zPARace, zPAClass)) + lRandom(lPAIASChance) > lRandom(50)) Then
            lPAFlyDuration = MyCLng(rsPlrAttacker!FlyDuration)
            lMartialArtsKungPowLevel = MyCLng(rsPlrAttacker!MartialArtsKungPowLevel)
            lMartialArtsLungingElbowsLevel = MyCLng(rsPlrAttacker!MartialArtsLungingElbowsLevel)
            lMartialArtsTigerFistsLevel = MyCLng(rsPlrAttacker!MartialArtsTigerFistsLevel)
            lMartialArtsTuskPunchLevel = MyCLng(rsPlrAttacker!MartialArtsTuskPunchLevel)
            lPATotalMartialArts = lMartialArtsKungPowLevel + lMartialArtsLungingElbowsLevel + lMartialArtsTigerFistsLevel + lMartialArtsTuskPunchLevel
            lPAGlory = MyCLng(rsPlrAttacker!Crown)
            lPAPlayerID = MyCStr(rsPlrAttacker!PlayerID)
            lPACHITROLL = MyCLng(rsPlrAttacker!CHITROLL)
            lPACDAMROLL = MyCLng(rsPlrAttacker!CDAMROLL)
            
            If (lRandom(20) < 3) Then 'we make barehanded classes hit hard once in awhile
                Select Case zPAClass
                    Case "MO", "BA", "VA", "WE"
                        If (lngSQLRecordCount("SELECT tblPlayerEquipmentItems.PlayerID FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPAPlayerID & ") AND ((tblPlayerEquipmentItems.Location)=20) AND ((tblObject.WeaponType)<>'' And (tblObject.WeaponType) Is Not Null));") = 0) Then 'no weapons being used - good - they qualify for serious damage
                            Select Case zPAClass 'we make barehanded classes stronger
                                Case "MO"
                                    lPATotalMartialArtsMath = MyCLng(lPATotalMartialArts / 2) + lRandom(3) + 1
                                    lPATotalMartialArtsUsed = lPATotalMartialArtsMath + lRandom(lPATotalMartialArtsMath)
                                Case "BA"
                                    lPATotalMartialArtsMath = MyCLng(lPATotalMartialArts / 4) + lRandom(2) + 1
                                    lPATotalMartialArtsUsed = lPATotalMartialArtsMath + lRandom(lPATotalMartialArtsMath) + lRandom(lPATotalMartialArtsMath) + lRandom(lPATotalMartialArtsMath)
                                Case "VA"
                                    lPATotalMartialArtsMath = MyCLng(lPATotalMartialArts / 4) + 2
                                    lPATotalMartialArtsUsed = lRandom(lPATotalMartialArtsMath) + lRandom(lPATotalMartialArtsMath) + lRandom(lPATotalMartialArtsMath) + lRandom(lPATotalMartialArtsMath)
                            End Select
                            lPACHITROLLMArtsBonus = (lRandom(MyCLng(rsPlrAttacker!CDEX) * (lPATotalMartialArtsUsed))) / 2
                            lPACDAMROLLMArtsBonus = (lRandom((MyCLng(rsPlrAttacker!CStr) + MyCLng(rsPlrAttacker!CLuc)) * (lPATotalMartialArtsUsed))) / 2
                            lPACHITROLL = lPACHITROLL + lPACHITROLLMArtsBonus
                            lPACDAMROLL = lPACDAMROLL + lPACDAMROLLMArtsBonus
                            subSendMsgAreaAll gblzFNGRE & "[" & zPAName & "] ~Martial Arts Bonus~ [hr+" & lPACHITROLLMArtsBonus & "] [dr+" & lPACDAMROLLMArtsBonus & "] = [hr" & lPACHITROLL & "] [dr" & lPACDAMROLL & "]", lPAX, lPAY, lPAZ
                        End If
                End Select
    '        Else
    '            subSendMsgAreaAll gblzFNGRE & "[" & zPAName & "] ~Martial Arts Move~ [BLOCKED - NO BONUS] [hr" & lPACHITROLL & "] [dr" & lPACDAMROLL & "]", lPAX, lPAY, lPAZ
            End If
            bBlindFight = (MyCInt(rsPlrAttacker!BlindFight) <> 0)
            bStunFight = (MyCInt(rsPlrAttacker!StunFight) <> 0)
            
            lPACAC = MyCLng(rsPlrAttacker!CAC)

            If (lPATurnedIntoAnimalType > 0) Then 'all morphs are weak
                lPACDAMROLL = 10 * lPATurnedIntoAnimalType
                lPACHITROLL = 10 * lPATurnedIntoAnimalType
                lPACAC = 10 * lPATurnedIntoAnimalType
            End If

            lPAPlayerLevel = MyCLng(rsPlrAttacker!PlayerLevel)
            lNumAttRnd = MyCLng(rsPlrAttacker!NumAttRnd)
            If (lNumAttRnd < 1) Then lNumAttRnd = 1
            lPAStunDuration = MyCLng(rsPlrAttacker!StunDuration)
            lPABlindDuration = MyCLng(rsPlrAttacker!BlindDuration)
            lPASleepDuration = MyCLng(rsPlrAttacker!SleepDuration)
            lPACHR = MyCLng(rsPlrAttacker!CCHA)
            
            lPAScared = MyCLng(rsPlrAttacker!PlayerFleeDuration)
            If (lPAScared > 0) Then 'thieves and players fleeing cant flee
                subSendMsg "&RYou too scared to fight well!", zPAPortID
                lPACHITROLL = 1
                lPACDAMROLL = 1
                lPACAC = 1
            End If
            
            If (lPAStunDuration > 0 Or lPABlindDuration > 0) Then
                If (lPAStunDuration > 0) Then
                    If (Not bStunFight) Then
                        lPACHITROLL = lPACHITROLL - (lPACHITROLL / 4)
                        lPACDAMROLL = lPACDAMROLL - (lPACDAMROLL / 5)
                        'subSendMsg "&rYou are stunned and do the best you can!", zPAPortID
                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is stunned and is fighting as best as possible!", lPAX, lPAY, lPAZ, zPAPortID, ""
                    Else
                        lPACHITROLL = lPACHITROLL - (lPACHITROLL / 6)
                        lPACDAMROLL = lPACDAMROLL - (lPACDAMROLL / 7)
                        'subSendMsg "&rYou fight well although stunned!", zPAPortID
                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is fighting well although stunned!", lPAX, lPAY, lPAZ, zPAPortID, ""
                    End If
                End If
                If (lPABlindDuration > 0) Then
                    If (Not bBlindFight) Then
                        lPACHITROLL = lPACHITROLL - (lPACHITROLL / 5)
                        lPACDAMROLL = lPACDAMROLL - (lPACDAMROLL / 6)
                        'subSendMsg "&rYou are blind and do the best you can!", zPAPortID
                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is blind and is fighting as best as possible!", lPAX, lPAY, lPAZ, zPAPortID, ""
                    Else
                        lPACHITROLL = lPACHITROLL - (lPACHITROLL / 7)
                        lPACDAMROLL = lPACDAMROLL - (lPACDAMROLL / 8)
                        'subSendMsg "&rYou fight well although blind!", zPAPortID
                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is fighting well although blinded!", lPAX, lPAY, lPAZ, zPAPortID, ""
                    End If
                End If
            End If
            
            Set rsPlrDefender = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PlayerID=" & rPCombat(lPAPortID).lID & " AND X=" & lPAX & " AND Y=" & lPAY & " AND Z=" & lPAZ & ");", dbOpenDynaset) 'Len([PortID])>1 AND - Removed so the coward that leaves still fights
            If (Not rsPlrDefender.EOF) Then
                lPAPetDamage = lCombatPetsVsWorld(lPAPlayerID, lPACHR, zPAClass, 2, zPAName, MyCStr(rsPlrDefender!PlayerName), MyCStr(rsPlrDefender!PlayerLevel), lPAX, lPAY, lPAZ, False, True, MyCStr(lPortID), MyCStr(rsPlrDefender!PortID))
                lPACTotalHPDmg = lPACTotalHPDmg + lPAPetDamage 'pets cut though sanctuary
            End If
            Set rsPlrDefender = Nothing
            
            If (lPASleepDuration = 0) Then
                'If (lPAStunDuration = 0) Then
                    'If (lPABlindDuration = 0) Then
                        If (MyCLng(rsPlrAttacker!InvisibilityDuration) <> 0 Or MyCLng(rsPlrAttacker!HideDuration) <> 0 Or MyCLng(rsPlrAttacker!CamoflaguedDuration) <> 0) Then
                            rsPlrAttacker.Edit
                            rsPlrAttacker!InvisibilityDuration = 0 'remove invisible
                            rsPlrAttacker!HideDuration = 0 'remove hide
                            rsPlrAttacker!CamoflaguedDuration = 0 'remove camo
                            rsPlrAttacker!SneakingMovesLeft = 0 'remove camo
                            rsPlrAttacker.Update
                            subSendMsg "&BYou fade into existence!", zPAPortID
                            subSendMsgAreaExcept2 gblzFBMAG & zPAName & " fades into existence!", lPAX, lPAY, lPAZ, zPAPortID, ""
                        End If
                        
                        If (MyCLng(rsPlrAttacker!Status) <> 0) Then
                            rsPlrAttacker.Edit
                            rsPlrAttacker!Status = 0 'battle stance
                            rsPlrAttacker!SitObjectID = 0
                            rsPlrAttacker.Update
                            subSendMsg "&MYou go into a battle stance!", zPAPortID
                            subSendMsgAreaExcept2 gblzFBMAG & zPAName & " goes into a battle stance!", lPAX, lPAY, lPAZ, zPAPortID, ""
                        End If
                        
                        Set rsPlrDefender = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PlayerID=" & rPCombat(lPAPortID).lID & " AND X=" & lPAX & " AND Y=" & lPAY & " AND Z=" & lPAZ & ");", dbOpenDynaset)
                        If (Not rsPlrDefender.EOF) Then
                            lPDIASChance = MyCStr(rsPlrDefender!IASChance)
                            zPDRace = MyCStr(rsPlrDefender!Race)
                            zPDClass = MyCStr(rsPlrDefender!Class)
                            lPDTurnedIntoAnimalType = MyCLng(rsPlrDefender!TurnedIntoAnimalType)
                            lPDPlayerID = MyCLng(rsPlrDefender!PlayerID)
                            zPDName = MyCStr(rsPlrDefender!PlayerName)
                            If (lRandom(lPACleaveChance) = 1) Then
                                lPDCleaveDuration = (MyCLng(lPACleaveChance / 2) + MyCLng(lRandom(lPACleaveChance) / 2)) + 1
                                rsPlrDefender!CleaveDuration = lPDCleaveDuration
                            Else
                                lPDCleaveDuration = MyCLng(rsPlrDefender!CleaveDuration)
                            End If
                            zPDPortID = MyCStr(rsPlrDefender!PortID)
                            lPDPortID = MyCLng(zPDPortID)
                            'Sometimes people spam out during a battle - then when they come back they are a sitting duck - this enforces the combat if this happens
                            If (lPAPortID >= cstlMinPort And lPAPortID <= cstlMaxPort) Then
                                rSCombat(lPAPortID).iStatus = cstiStatusPlayerVsPlayer
                                rPCombat(lPAPortID).Name = zPDName 'this is the target information for this attacker
                                rPCombat(lPAPortID).lID = lPDPlayerID 'This port is attacking this person ID
                            End If
                            
                            If (lPDPortID >= cstlMinPort And lPDPortID <= cstlMaxPort) Then
                                rSCombat(lPDPortID).iStatus = cstiStatusPlayerVsPlayer
                                rPCombat(lPDPortID).Name = zPAName 'this is the target information for this attacker
                                rPCombat(lPDPortID).lID = lPAPlayerID 'This port is attacking this person ID
                            End If
                            'We can now determine if we hit or not.
                            lPDCAC = MyCLng(rsPlrDefender!CAC)
                            If (Not bDay) Then
                                If (gbllMoon < 4) Then
                                    Select Case zPDRace
                                        Case "UND"
                                            lPDCAC = lPDCAC + 300
                                    End Select
                                End If
                                If (gbllMoon = 3) Then
                                    Select Case zPDClass 'when full moon only
                                        Case "VA"
                                            lPDCAC = lPDCAC + 1200
                                        Case "WE"
                                            lPDCAC = lPDCAC + 1500
                                    End Select
                                End If
                                If (gbllMoon = 3 Or gbllMoon = 4 Or gbllMoon = 5) Then
                                    Select Case zPDRace
                                        Case "DRA"
                                            lPDCAC = lPDCAC + 3000
                                    End Select
                                End If
                                If (gbllMoon < 0 Or gbllMoon = 4 Or gbllMoon = 5) Then
                                    Select Case zPDRace
                                        Case "ORC"
                                            lPDCAC = lPDCAC + 1000
                                        Case "TRO"
                                            lPDCAC = lPDCAC + 2000
                                        Case "OGR"
                                            lPDCAC = lPDCAC + 1500
                                    End Select
                                End If
                            End If
                            If (lPDTurnedIntoAnimalType > 0) Then 'all morphs are weak
                                'lPDCDAMROLL = 10 * lPATurnedIntoAnimalType
                                'lPDCHITROLL = 10 * lPATurnedIntoAnimalType
                                lPDCAC = 10 * lPDTurnedIntoAnimalType
                            End If
                            lPDPlayerLevel = MyCLng(rsPlrDefender!PlayerLevel)
                            lPDImmortalLevel = MyCLng(rsPlrDefender!ImmortalLevel)
                            lPDGlory = MyCLng(rsPlrDefender!Crown)
                            lPDCHitPoints = MyCLng(rsPlrDefender!CHP)
                            For lCountNumAttRnd = 1 To lNumAttRnd
                                zAttackRound = "Attack round " & lCountNumAttRnd & ": "
                                If (lRandom(lPACHITROLL) > lRandom(lPDCAC)) Then
                                    lPACTotalHPDmg = lPACTotalHPDmg + lRandom(lPACDAMROLL / lCountNumAttRnd) 'the more attacks a player has the less damage is done - this simulates the player getting tired.
                                    If (lCountNumAttRnd = 1) Then 'the first attack we always reduce the dmg
                                        zAttackRound = zAttackRound & " ArmourReducedDmg(-" & lPDCAC & ")"
                                        If (lPACTotalHPDmg > lPDCAC) Then
                                            lPACTotalHPDmg = lPACTotalHPDmg - lPDCAC
                                        End If
                                    End If
                                    lPATotalHits = lPATotalHits + 1
                                    '*subSendMsg "&GATTACKING: " & zAttackRound & "You hit " & zPDName & "!", zPAPortID
                                    '*subSendMsg "&RDEFENDING: " & zAttackRound & zPAName & " hits you!", zPDPortID
                                    '*subSendMsgAreaExcept2 "&yFIGHTING: " & "&R" & zAttackRound & zPAName & " hits " & zPDName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                    
                                    If (lCountNumAttRnd = 1) Then
                                        'BEGIN LEARN SKILLS
                                        Set rsLearn = MyDB.OpenRecordset("SELECT LearnName, LearnDamage, LearnPercent FROM tblPlayerLearn WHERE (LearnDamage>0 AND TargetID=" & lPAPlayerID & " AND ActivateCommand=0 AND LearnStatus=2 AND (CounterLearnName='' OR CounterLearnName Is Null)) ORDER BY LearnName;", dbOpenSnapshot)
                                        If (Not rsLearn.EOF) Then
                                            zLearn = ""
                                            Do While (Not rsLearn.EOF)
                                                If (lRandom(MyCLng(rsLearn!LearnPercent)) > lRandom(100)) Then
                                                    iLearnBlock = 0 'defender doesnt have that block skill for this attack skill
                                                    Set rsLearnBlock = MyDB.OpenRecordset("SELECT LearnName, LearnDamage, LearnPercent FROM tblPlayerLearn WHERE (TargetID=" & lPDPlayerID & " AND CounterLearnName='" & zAntiSQLCrash(MyCStr(rsLearn!LearnName)) & "' AND LearnStatus=2) ORDER BY LearnName;", dbOpenSnapshot)
                                                    If (Not rsLearnBlock.EOF) Then
                                                        'Not blocked for sure yet but was attempted
                                                        If (lRandom(MyCLng(rsLearnBlock!LearnPercent)) > lRandom(100)) Then 'We now check the defender for a chance to block
                                                            'was blocked
                                                            iLearnBlock = 1
                                                        Else
                                                            'block attempted but failed
                                                            iLearnBlock = 2
                                                        End If
                                                    End If
                                                    
                                                    Select Case iLearnBlock
                                                        Case 1
                                                            'Show it was blocked.
                                                            zLearn = zLearn & UCase(MyCStr(rsLearn!LearnName)) & " was countered by " & UCase(MyCStr(rsLearnBlock!LearnName)) & " "
                                                        Case Else
                                                            zLearn = zLearn & UCase(MyCStr(rsLearn!LearnName))
                                                            If (iLearnBlock = 2) Then zLearn = zLearn & " counter attempted "
                                                            zLearn = zLearn & " (" & MyCLng(rsLearn!LearnDamage) + lPAPlayerLevel & ") "
                                                            lPACTotalHPDmg = lPACTotalHPDmg + MyCLng(rsLearn!LearnDamage) + lPAPlayerLevel
                                                    End Select
                                                    
                                                    Set rsLearnBlock = Nothing
                                                End If
                                                
                                                rsLearn.MoveNext
                                                
                                                zLearn = MyCStr(zLearn) 'trims spaces at the ends
                                                If (Len(zLearn) > 0) Then
                                                    subSendMsg "&gYou combination attack " & zPDName & ": " & zLearn & ".", zPAPortID
                                                    subSendMsg gblzFNGRE & zPAName & " combination attacks you: " & zLearn & ".", zPDPortID
                                                    subSendMsgAreaExcept2 gblzFNGRE & zPAName & " combination attacks " & zPDName & ": " & zLearn & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                    zLearn = ""
                                                End If
                                            Loop
                                        End If
                                        Set rsLearn = Nothing
                                    
                                        'BEGIN SKILLS
                                        If (MyCLng(rsPlrAttacker!FireElementalDamage) > 0) Then
                                            lPACTotalHPDmg = lPACTotalHPDmg + lRandom(MyCLng(rsPlrAttacker!FireElementalDamage))
                                        End If
                                        
                                        If (MyCLng(rsPlrAttacker!LightningElementalDamage) > 0) Then
                                            lPACTotalHPDmg = lPACTotalHPDmg + lRandom(MyCLng(rsPlrAttacker!LightningElementalDamage))
                                        End If
                                        
                                        If (MyCLng(rsPlrAttacker!ColdElementalDamage) > 0) Then
                                            lPACTotalHPDmg = lPACTotalHPDmg + lRandom(MyCLng(rsPlrAttacker!ColdElementalDamage))
                                        End If
                                        
                                        If (MyCLng(rsPlrAttacker!PoisonElementalDamage) > 0) Then
                                            Select Case zPDRace
                                                Case "DRA"
                                                    If (lRandom(60) < lRandom(100)) Then
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lRandom(MyCLng(rsPlrAttacker!PoisonElementalDamage))
                                                    End If
                                                Case Else
                                                    lPACTotalHPDmg = lPACTotalHPDmg + lRandom(MyCLng(rsPlrAttacker!PoisonElementalDamage))
                                            End Select
                                        End If
                                        
                                        If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                            If (MyCLng(rsPlrAttacker!BeserkDuration) <> 0) Then 'We never double skill damage we just add lots.
                                                lPACTotalHPDmg = lPACTotalHPDmg + (MyCLng(rsPlrAttacker!CDAMROLL) / 2)
                                            End If
                                        End If
                                        
                                        If (MyCLng(rsPlrAttacker!WeaponSkillBackStabClassLevel) > 0) Then 'Can player backstab?
                                            If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                                lPACTotalHPDmg = lPACTotalHPDmg + (MyCLng(rsPlrAttacker!WeaponSkillBackStabClassLevel) * lPAPlayerLevel)
                                            End If
                                        End If
                                        
                                        'WE LOOP PHYSICAL SKILLS HERE - the first attack includes all the physical attacks only
                                        lCount = (lNumAttRnd / 10) 'lots of attacks helps skill attacks alot in pvp
                                        Do While (lCount > 0) 'skills have multiple attacks
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                                    If (MyCLng(rsPlrAttacker!DoublePunchDuration) <> 0) Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lRandom(lTranslateSkillDoublePunchDamage(MyCStr(rsPlrAttacker!Class))))
                                                        'subSendMsg "&MYou double punch " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " double punches you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " delivers " & zPDName & " a double punch to the head.", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                                    If (MyCLng(rsPlrAttacker!HeadButtDuration) <> 0) Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lTranslateSkillHeadButtDamage(MyCStr(rsPlrAttacker!Class)))
                                                        'subSendMsg "&MYou head butt " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " head butts you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " head butts " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > (lRandom(lPDPlayerLevel) * 6)) Then
                                                    If (MyCLng(rsPlrAttacker!HurricaneKickDuration) <> 0) Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lTranslateSkillHurricaneKickDamage(MyCStr(rsPlrAttacker!Class)))
                                                        'subSendMsg "&MYou hurricane kick " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " hurricane kicks you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " hurricane kicks " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zPAClass) + lPAPlayerLevel) > (lRandom(lPDPlayerLevel * 5))) Then
                                                    If (MyCLng(rsPlrAttacker!DragonUppercutDuration) <> 0 Or zPARace = "DRA") Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lTranslateSkillDragonUppercutDamage(MyCStr(rsPlrAttacker!Class)))
                                                        'subSendMsg "&MYou dragon uppercut " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " dragon uppercuts you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " dragon uppercuts " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > (lRandom(lPDPlayerLevel) * 5)) Then
                                                    If (MyCLng(rsPlrAttacker!PowerKickDuration) <> 0 Or zPAClass = "AS") Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lTranslateSkillPowerKickDamage(MyCStr(rsPlrAttacker!Class)))
                                                        'subSendMsg "&MYou power kick " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " power kicks you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " power kicks " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > (lRandom(lPDPlayerLevel) * 3)) Then
                                                    If (MyCLng(rsPlrAttacker!ClawHandDuration) <> 0 Or zPAClass = "AS") Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lTranslateSkillClawHandDamage(MyCStr(rsPlrAttacker!Class)))
                                                        'subSendMsg "&MYou claw hand " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " claw hands you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " claw hands " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                                    If (MyCLng(rsPlrAttacker!ElbowDuration) <> 0) Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lRandom(lTranslateSkillElbowDamage(MyCStr(rsPlrAttacker!Class))))
                                                        'subSendMsg "&MYou elbow " & zPDName & " to the head.&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " elbows you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " elbows " & zPDName & " to the head.", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                                    If (MyCLng(rsPlrAttacker!KneeDuration) <> 0) Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lRandom(lTranslateSkillKneeDamage(MyCStr(rsPlrAttacker!Class))))
                                                        'subSendMsg "&MYou knee " & zPDName & " in the chest.&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " knees you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " knees " & zPDName & " in the chest.", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                'drop kick MUST be the last action for physical skills - so it look realistic
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > lRandom(lPDPlayerLevel)) Then
                                                    If (MyCLng(rsPlrAttacker!DropKickDuration) <> 0) Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lRandom(lTranslateSkillDropKickDamage(MyCStr(rsPlrAttacker!Class))))
                                                        'subSendMsg "&MYou drop kick " & zPDName & " in the chest.&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " drop kicks you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " delivers " & zPDName & " a drop kick to the chest.", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            
                                            If (lCount > 0) Then
                                                If (lRandom(lTranslateSkillPhysicalCombatHitBonus(MyCStr(rsPlrAttacker!Class)) + lPAPlayerLevel) > (lRandom(lPDPlayerLevel) * 2)) Then
                                                    If (MyCLng(rsPlrAttacker!KnifeHandDuration) <> 0 Or zPAClass = "AS") Then
                                                        lCount = lCount - 1
                                                        lDamageXP = (lRandom(lPAPlayerLevel) + lTranslateSkillKnifeHandDamage(MyCStr(rsPlrAttacker!Class)))
                                                        'subSendMsg "&MYou knife hand " & zPDName & ".&G (" & lDamageXP & ")", zPAPortID
                                                        'subSendMsg "&M"  & zPAName & " knife hands you.&G (" & lDamageXP & ")", zPDPortID
                                                        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " knife hands " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                        lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                                    End If
                                                End If
                                            End If
                                            lCount = lCount - 1
                                        Loop
                                        'END SKILLS
                                        
                                        If (lPDImmortalLevel < 4) Then
                                            If (lRandom(8) = 1 Or (zPAClass = "KN" And lRandom(3) = 1)) Then 'Some skills are harder to activate
                                                lCalcuIASChance = (lPDIASChance - lPAIASChance)
                                                If (lCalcuIASChance < 0) Then lCalcuIASChance = 0
                                                If (lRandom(lPASlayChance) >= lRandom(1000 + (lPDPlayerLevel * 2) + (lCalcuIASChance * 5))) Then
                                                    lCountNumAttRnd = lNumAttRnd 'we end the next statement
                                                    bSlayed = True
                                                    If (zPAClass = "KN") Then
                                                        subSendMsg "&MYou pull out your litesabre and -=S L A Y=- " & zPDName & ".", zPAPortID
                                                        subSendMsg "&M" & zPAName & " pulls out a litesabre and -=S L A Y S=- you!", zPDPortID
                                                        subSendMsgAreaExcept2 gblzFBMAG & zPAName & " pulls out a litesabre and -=S L A Y S=- " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                    Else
                                                        subSendMsg "&MYou -=S L A Y=- " & zPDName & ".", zPAPortID
                                                        subSendMsg "&M" & zPAName & " -=S L A Y S=- you!", zPDPortID
                                                        subSendMsgAreaExcept2 gblzFBMAG & zPAName & " -=S L A Y S=- " & zPDName & ".", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                                    End If
                                                    lPACTotalHPDmg = lPACTotalHPDmg + lPDCHitPoints 'we do lots of damage
                                                End If
                                            End If
                                        End If
                                    End If
                                    
                                    If (Not bSlayed) Then
                                        If (MyCLng(rsPlrDefender!SanctuaryDuration) > 0) Then
                                            'subSendMsg "&W"  & "You feel " & zPDName & "'s sanctuary aura absorb half of the damage!", zPAPortID
                                            'subSendMsg "&W"  & "Your sanctuary aura absorbs a third of the damage!", zPDPortID
                                            'subSendMsgAreaExcept2 gblzFBWHI & zPDName & "'s sanctuary aura absorbs a third of the damage!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                            lPACTotalHPDmg = lPACTotalHPDmg - MyCLng(lPACTotalHPDmg / 3) 'sanc only helps 33% not 50%
                                        End If
                                    
                                        If (MyCLng(rsPlrDefender!FireshieldDuration) > 0) Then
                                            'subSendMsg "&R" & zPDName & "'s fireshield burns you!", zPAPortID
                                            'subSendMsg "&RYour fireshield burns " & zPAName & "!", zPDPortID
                                            'subSendMsgAreaExcept2 "&R" & zPDName & "'s fireshield burns " & zPAName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                            lDamageXP = lRandom(MyCLng(rsPlrDefender!PlayerLevel))
                                            lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                        End If
                                        
                                        If (MyCLng(rsPlrDefender!ChaosshieldDuration) > 0) Then
                                            'subSendMsg "&R" & zPDName & "'s Chaosshield burns you!", zPAPortID
                                            'subSendMsg "&RYour Chaosshield burns " & zPAName & "!", zPDPortID
                                            'subSendMsgAreaExcept2 "&R" & zPDName & "'s Chaosshield burns " & zPAName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                            lDamageXP = lRandom(MyCLng(rsPlrDefender!PlayerLevel))
                                            lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                        End If
                                        
                                        If (MyCLng(rsPlrDefender!StaticshieldDuration) > 0) Then
                                            'subSendMsg "&R" & zPDName & "'s Staticshield burns you!", zPAPortID
                                            'subSendMsg "&RYour Staticshield burns " & zPAName & "!", zPDPortID
                                            'subSendMsgAreaExcept2 "&R" & zPDName & "'s Staticshield burns " & zPAName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                            lDamageXP = lRandom(MyCLng(rsPlrDefender!PlayerLevel))
                                            lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                        End If
                                        
                                        If (MyCLng(rsPlrDefender!IceshieldDuration) > 0) Then
                                            'subSendMsg gblzFBCYA & zPDName & "'s iceshield frost burns you!", zPAPortID
                                            'subSendMsg "&CYour iceshield frost burns " & zPAName & "!", zPDPortID
                                            'subSendMsgAreaExcept2 gblzFBCYA & zPDName & "'s iceshield frost burns " & zPAName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                            lDamageXP = lRandom(MyCLng(rsPlrDefender!PlayerLevel))
                                            lPACTotalHPDmg = lPACTotalHPDmg + lDamageXP
                                        End If
                                    End If
                                Else
                                    '*subSendMsg "&RATTACKING: " & zAttackRound & "You miss " & zPDName & "!", zPAPortID
                                    '*subSendMsg "&GDEFENDING: " & zAttackRound & zPAName & " misses you!", zPDPortID
                                    '*subSendMsgAreaExcept2 "&yFIGHTING: " & zAttackRound & gblzFBGRE & zPAName & " misses " & zPDName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                End If
                            Next lCountNumAttRnd
                        End If
                        Set rsPlrDefender = Nothing
                '    Else
                '        'subSendMsg "&gYou are blind and cannot see to fight!", zPAPortID
                '        'subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is blind and cannot see to attack!", lPAX, lPAY, lPAZ, zPAPortID, ""
                '    End If
                'Else
                '    'subSendMsg "&RYou are stunned and cannot move to fight!", zPAPortID
                '    'subSendMsgAreaExcept2 "&R" & zPAName & " is stunned and cannot move to attack!", lPAX, lPAY, lPAZ, zPAPortID, ""
                'End If
            Else
                'subSendMsg "&RYou are asleep and you cannot move to fight!", zPAPortID
                'subSendMsgAreaExcept2 "&R" & zPAName & " is asleep and cannot move to attack!", lPAX, lPAY, lPAZ, zPAPortID, ""
            End If
            
            If (lPATotalHits = 0) Then
                subSendMsg "&gYou MISS " & zPDName & "! *oops, nice try*", zPAPortID
                subSendMsg "&G" & zPAName & " misses you! *you can take him*", zPDPortID
                subSendMsgAreaExcept2 gblzFNYEL & zPAName & " MISSES " & zPDName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
            Else
                subSendMsg "&GYou HIT " & zPDName & " " & lPATotalHits & " time(s!", zPAPortID
                subSendMsg "&r" & zPAName & " hit YOU " & lPATotalHits & " time(s!", zPDPortID
                subSendMsgAreaExcept2 gblzFNYEL & zPAName & " hit " & zPDName & " " & lPATotalHits & " time(s!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
            End If
            
            If (lPACTotalHPDmg > 0) Then
                bPlayerDied = False
                Set rsPlrDefender = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PlayerID=" & rPCombat(lPortID).lID & " AND X=" & lPAX & " AND Y=" & lPAY & " AND Z=" & lPAZ & ");", dbOpenDynaset)
                If (Not rsPlrDefender.EOF) Then
                    rsPlrDefender.Edit
                    If (MyCStr(rsPlrAttacker!Class) = "BA" Or MyCStr(rsPlrAttacker!Race) = "DRA") Then
                        If (lRandom(9) = 1) Then
                            rsPlrDefender!Hallucinate = 6
                            subSendMsg "&wAPPLIED - &M*HALLUCINATIONS*", zPAPortID
                            subSendMsg "&wPvP DRAC/BARD - &M*HALLUCINATIONS*", zPDPortID
                        End If
                    End If
                    If (rsPlrDefender!Status <> 0) Then
                        'subSendMsg "&MYou go into a battle stance!", zPDPortID
                        'subSendMsgAreaExcept2 gblzFBMAG & zPDName & " goes into a battle stance!", lPAX, lPAY, lPAZ, zPDPortID, ""
                        rsPlrDefender!Status = 0 'battle stance
                        rsPlrDefender!SitObjectID = 0
                    End If
                    
                    rsPlrDefender!CHP = rsPlrDefender!CHP - lPACTotalHPDmg
                    If (rsPlrDefender!CHP < 1) Then
                        bPlayerDied = True
                        bRecalculatePlayers = True
                        subSendMsg "&GYou killed " & zPDName & "!", zPAPortID
                        subSendMsg "&R" & zPAName & " killed you!", zPDPortID
                        subSendMsgAreaExcept2 "&R" & zPAName & " killed " & zPDName & "!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                        rsPlrDefender!AreaTrapID = 0
                        rsPlrDefender!AreaTrapDuration = 0
                        rsPlrDefender!StunDuration = 0
                        rsPlrDefender!BlindDuration = 0
                        rsPlrDefender!CHP = 1
                        rsPlrDefender!x = 0
                        rsPlrDefender!y = 0
                        rsPlrDefender!z = -2
                        rsPlrDefender!Status = 5 'at ease
                        
                        subCombatInitPort zPAPortID
                        subCombatInitPort zPDPortID
                        
                        rsPlrAttacker.Edit
                        rsPlrAttacker!Status = 5 'at ease
                        'A player cannot kill himself for bonuses
                        If (lPAPlayerID = lPDPlayerID) Then
                            subSendMsg "&RYou killed yourself, it hurt a lot too!", zPAPortID
                            subSendMsgAreaExcept2 "&R" & zPAName & " falls on the ground dead.", lPAX, lPAY, lPAZ, zPAPortID, ""
                        Else
                            'We calculate bonuses except for people on the same ips they are considered friends
                            If (zReturnOnlineRemoteHostID(lPAPlayerID) <> zReturnOnlineRemoteHostID(lPDPlayerID)) Then
                                If (bAreaGloryChallengeZone(lPAX, lPAY, lPAZ)) Then
                                    If (MyCLng(rsPlrAttacker!ClanMemberLevel) < 10) And (MyCLng(rsPlrDefender!ClanMemberLevel) < 10) Then
                                        If (MyCLng(rsPlrAttacker!ClanID) = MyCLng(rsPlrDefender!ClanID)) Then
                                            If (MyCLng(rsPlrAttacker!ClanMemberLevel) < MyCLng(rsPlrDefender!ClanMemberLevel)) Then
                                                'We now switch ranks
                                                lClanMemberLevel = MyCLng(rsPlrAttacker!ClanMemberLevel)
                                                rsPlrAttacker!ClanMemberLevel = MyCLng(rsPlrDefender!ClanMemberLevel)
                                                rsPlrDefender!ClanMemberLevel = lClanMemberLevel
                                            End If
                                        End If
                                    End If
                                End If
                                
                                If (lPAPlayerLevel - lPDPlayerLevel <= 40) Then
                                    If (bAreaGloryChallengeZone(lPAX, lPAY, lPAZ)) Then
                                        If (lPAGlory >= 1 And lPDGlory >= 1) Then
                                            'We switch crowns
                                            rsPlrAttacker!Crown = MyCLng(rsPlrAttacker!Crown) + 1
                                            rsPlrDefender!Crown = MyCLng(rsPlrDefender!Crown) - 1
                                            
                                            subSendMsg "&WCongratulations! You killed " & zPDName & " and &Yreceived a glory!", zPAPortID
                                            subSendMsg "&RYou failed! " & zPAName & " earns a &Yglory from you as a &Greward!", zPDPortID
                                            subSendMsgAreaExcept2 "&R" & zPAName & " killed " & zPDName & " for a crown of glory!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                        Else
                                            If (lPAGlory < 1) Then
                                                subSendMsgAreaExcept2 "&Ra dooming voice bellows, '" & zPAName & " does not have at least one glory to battle for!'" & vbCrLf & "No one received any glory.", lPAX, lPAY, lPAZ, zPAPortID, ""
                                            End If
                                            If (lPDGlory < 1) Then
                                                subSendMsgAreaExcept2 "&Ra dooming voice bellows, '" & zPDName & " does not have at least one glory to battle for!'" & vbCrLf & "No one received any glory.", lPAX, lPAY, lPAZ, zPDPortID, ""
                                            End If
                                        End If
                                    End If
                                    subSendMsg "&RYou are awarded a player kill!", zPAPortID
                                    subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is awarded a player kill!", lPAX, lPAY, lPAZ, zPAPortID, ""
                                    rsPlrAttacker!MurderPKills = MyCLng(rsPlrAttacker!MurderPKills) + 1
                                Else
                                    subSendMsg "&RYou are disqualified for a player kill." & vbCrLf & "The levels must both be within fourty levels of eachother.", zPAPortID
                                    subSendMsgAreaExcept2 gblzFBMAG & zPAName & " is disqualified for a player kill for not being within fourty levels of the opponent!", lPAX, lPAY, lPAZ, zPAPortID, ""
                                    If (bAreaGloryChallengeZone(lPAX, lPAY, lPAZ)) Then
                                        subSendMsg "&RYou and your opponent were not within fourty levels, this imbalance does not earn you a glory point!", zPAPortID
                                        subSendMsg "&R" & zPAName & " fails to earn a glory because of the level imbalance!", zPDPortID
                                        subSendMsgAreaExcept2 "&R" & zPAName & " did not earn a glory from " & zPDName & " due to the level imbalance!", lPAX, lPAY, lPAZ, zPAPortID, zPDPortID
                                    End If
                                End If
                                
                                rsPlrAttacker.Update
                                If (lPAPlayerID <> lPDPlayerID) Then
                                    If (lPDImmortalLevel = 0) Then
                                        subCombatCreatePlayerHeartOnGround zPDName, zPAName & " [" & zPARace & " " & zPAClass & "] (level " & MyCStr(lPAPlayerLevel) & ") murdered " & zPDName & " [" & zPDRace & " " & zPDClass & "] (level " & MyCStr(lPDPlayerLevel) & ")", lPAX, lPAY, lPAZ
                                        subSendMsgAreaExcept2 "&RYou hear a splat as " & zPDName & "'s heart hits the floor!", lPAX, lPAY, lPAZ, zPDPortID, ""
                                    End If
                                    
                                    If (bSlayed) Then
                                        subSimpleEchoChannel "&w[ARENA BATTLE] &R" & zPAName & "(lv" & MyCStr(lPAPlayerLevel) & ") -=SLAYS=- " & zPDName & "(lv" & MyCStr(lPDPlayerLevel) & ")"
                                    Else
                                        subSimpleEchoChannel "&w[ARENA BATTLE] &W" & zPAName & "(lv" & MyCStr(lPAPlayerLevel) & ") murdered " & zPDName & "(lv" & MyCStr(lPDPlayerLevel) & ")"
                                    End If
                                End If
                            Else
                                subSendMsgAreaAll "&R" & zPAName & " combats his friend " & zPDName & " for only the pure fun of it!", lPAX, lPAY, lPAZ
                            End If
                        End If
                        basCaptureTheFlag zPDPortID
                    End If
                    rsPlrDefender.Update
                    
                    If (Not bPlayerDied) Then
                        subCombatWorldVsPets lPAPlayerID, 2, zPAName, MyCStr(rsPlrDefender!PlayerName), MyCStr(rsPlrDefender!PlayerLevel), lPAX, lPAY, lPAZ, zPAClass, zPARace, lPAFlyDuration, False, True, MyCStr(lPortID), MyCStr(rsPlrDefender!PortID)
                    End If
                End If
                Set rsPlrDefender = Nothing
            End If
        Else
            subSendMsg "&yYou swing at the air in anger!", zPAPortID
            'subSendMsg gblzFNYEL & zPAName & " swings at the air in anger!", zPDPortID
            subSendMsgAreaExcept2 gblzFNYEL & zPAName & " swings at the air in anger!", lPAX, lPAY, lPAZ, zPAPortID, ""
            
            If (lPAX = -1 And lPAY = -1 And Abs(lPAZ) < 9) Then  'Use this if the Challenge Zone ring side pvp battles at -1 -1 0
                Select Case lRandom(6)
                    Case 1
                        subSendMsgAreaAll "&y[NW] " & zPAName & " swings at the air in anger! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, 0, 0
                        subSendMsgAreaAll "&y[N] " & zPAName & " swings at the air in anger! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", -1, 0, 0
                        subSendMsgAreaAll "&y[W] " & zPAName & " swings at the air in anger! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, -1, 0
                    Case 2
                        subSendMsgAreaAll "&y[NW] " & zPAName & " clashes weapons with the enemy! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, 0, 0
                        subSendMsgAreaAll "&y[N] " & zPAName & " clashes weapons with the enemy! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", -1, 0, 0
                        subSendMsgAreaAll "&y[W] " & zPAName & " clashes weapons with the enemy! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, -1, 0
                    Case 3
                        subSendMsgAreaAll "&y[NW] " & zPAName & " crys out in anger! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, 0, 0
                        subSendMsgAreaAll "&y[N] " & zPAName & " crys out in anger! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", -1, 0, 0
                        subSendMsgAreaAll "&y[W] " & zPAName & " crys out in anger! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, -1, 0
                    Case 4
                        subSendMsgAreaAll "&y[NW] " & zPAName & " battles the opponent! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, 0, 0
                        subSendMsgAreaAll "&y[N] " & zPAName & " battles the opponent! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", -1, 0, 0
                        subSendMsgAreaAll "&y[W] " & zPAName & " battles the opponent! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, -1, 0
                    Case 5
                        subSendMsgAreaAll "&y[NW] " & zPAName & " stalks the opponent around the arena! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, 0, 0
                        subSendMsgAreaAll "&y[N] " & zPAName & " stalks the opponent around the arena! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", -1, 0, 0
                        subSendMsgAreaAll "&y[W] " & zPAName & " stalks the opponent around the arena! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, -1, 0
                    Case 6
                        subSendMsgAreaAll "&y[NW] " & zPAName & " clanks steel with mighty steel! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, 0, 0
                        subSendMsgAreaAll "&y[N] " & zPAName & " clanks steel with mighty steel! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", -1, 0, 0
                        subSendMsgAreaAll "&y[W] " & zPAName & " clanks steel with mighty steel! [" & lPACHitPoints & "/" & lPACHitPointsMAX & "]", 0, -1, 0
                End Select
            End If
        End If 'If (lRandom(lTranslatePlayerRaceClassIAS(zPARace, zPAClass)) + lRandom(lPAIASChance) > lRandom(50)) Then
    End If
    Set rsPlrAttacker = Nothing
    
    If (bRecalculatePlayers) Then
        subRecalculatePlayerEquipment lPAPlayerID, zPAPortID
        subRecalculatePlayerEquipment lPDPlayerID, zPDPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatPvP," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lGainBonusXPStartOff(lPlayerID As Long, zPortID As String) As Long
On Error GoTo Err_Check
    Dim rsPlr As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsPlr = MyDB.OpenRecordset("SELECT tblPlayerEquipmentItems.PlayerID, tblObject.Location, Sum(tblObject.BonusXP) AS SumOfBonusXP FROM tblObject INNER JOIN tblPlayerEquipmentItems ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID GROUP BY tblPlayerEquipmentItems.PlayerID, tblObject.Location HAVING (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.Location)=121));", dbOpenSnapshot)
    If (Not rsPlr.EOF) Then
        lReturn = MyCLng(rsPlr!SumOfBonusXP)
    End If
    Set rsPlr = Nothing
    
    If (Len(zPortID) <> 0 And lReturn > 0) Then
        subSendMsg "&YYou start off with a bonus experience of " & lReturn & " experience!", zPortID
    End If
    
    lGainBonusXPStartOff = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lGainBonusXPStartOff," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subAIMobGratzPlayerForTheirLevel(zPlayerName As String)
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim zMobName As String
    Dim zChannel As String
    Dim zMessage As String
    Dim lMobGratzTop As Long
    Dim zColour As String
    
    lMobGratzTop = lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (RespawnDelay=0);")
    
    Set rsMob = MyDB.OpenRecordset("SELECT TOP " & lRandom(lMobGratzTop) & " MobName FROM tblMob WHERE (RespawnDelay=0);", dbOpenSnapshot)
    If (Not rsMob.EOF) Then
        rsMob.MoveLast
        zMobName = zAdverb(MyCStr(rsMob!MobName), 2) & zShortstop(MyCStr(rsMob!MobName))
        zColour = "&W"
        Select Case lRandom(5)
            Case 1
                zChannel = "cheers"
                zColour = "&B"
            Case 2
                zChannel = "yells"
            Case 3
                zChannel = "rambles"
                zColour = "&C"
            Case 4
                zChannel = "quests"
            Case 5
                zChannel = "roars"
                zColour = "&R"
        End Select
        Select Case lRandom(6)
            Case 1
                zMessage = "way to go"
            Case 2
                zMessage = "you rock"
            Case 3
                zMessage = "congratulations"
            Case 4
                zMessage = "hail"
            Case 5
                zMessage = "impressive"
            Case 6
                zMessage = "good job"
        End Select
        subSimpleEchoChannel zColour & zMobName & " " & zChannel & ", '" & zMessage & " " & zPlayerName & "!'"
    End If
    Set rsMob = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subAIMobGratzPlayerForTheirLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerGains(lPlayerID As Long) 'GAINS ARE:
On Error GoTo Err_Check
'See also: zTranslateMultiClassStats
'Player gained a level! - You gained a level!
    Dim rsPlayer As Recordset
    'Dim zGetTranslateMultiClassStats As String
    Dim zPortID As String
    Dim lPlayerLucBonus As Long
    Dim zGain As String
    Dim lGain As Long
    Dim lGloryGain As Long
    Dim lMaxGain As Long
    Dim lXP As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lRecallX As Long
    Dim lRecallY As Long
    Dim lRecallZ As Long
    Dim lRemainingXP As Long
    Dim lPlayerLevel As Long 'MyCLng(rsPlayer!PlayerLevel)
    Dim zClass As String
    
    'Here we check the player for their XP bonus and if so give them a gain.
    Set rsPlayer = MyDB.OpenRecordset("SELECT QuestMissionLog, PlayerName, X, Y, Z, DuelWield, BlindFight, StunFight, Crown, RecallX, RecallY, RecallZ, LearnPoints, OHP, GHP, OEssence, GEssence, OMana, GMana, OMove, GMove, OSoul, GSoul, Config, PlayerID, Gender, RoomTitle, Class, Race, PortID, XP, PlayerLevel, CStr, CInt, CWis, CDex, CCon, CCha, CLuc FROM tblPlayer WHERE (PlayerID=" & lPlayerID & " AND Len([PortID])>1);", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lGloryGain = MyCLng(lPlayerLevel * 0.15) + 5
        If (lGloryGain > 50) Then lGloryGain = 50
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lRecallX = MyCLng(rsPlayer!RecallX)
        lRecallY = MyCLng(rsPlayer!RecallY)
        lRecallZ = MyCLng(rsPlayer!RecallZ)
        lXP = MyCLng(rsPlayer!XP)
        lRemainingXP = (lXP - lTranslateRequiredForNextLevel(lPlayerLevel))
        If (lRemainingXP >= 0) Then 'Player xp qualifier check
            zPortID = MyCStr(rsPlayer!PortID)
            If (lPlayerLevel < 999) Then 'who and page last max at showing room for 999
                zClass = MyCStr(rsPlayer!Class)
                
                rsPlayer.Edit
                rsPlayer!Crown = MyCLng(rsPlayer!Crown) + lGloryGain
                subSendMsg "&W+" & lGloryGain & " crowns of glory [for your level] to FORGE with!", zPortID
                rsPlayer!RoomTitle = zTranslateRoomTitle(MyCStr(rsPlayer!Gender), lPlayerLevel + 1)
                
                rsPlayer!XP = MyCLng(rsPlayer!XP) + lGainBonusXPStartOff(lPlayerID, zPortID)
                'zGetTranslateMultiClassStats = zTranslateMultiClassStats(MyCLng(rsPlayer!CStr), MyCLng(rsPlayer!CInt), MyCLng(rsPlayer!CWIS), MyCLng(rsPlayer!CDEX), MyCLng(rsPlayer!CCon), MyCLng(rsPlayer!CCHA), MyCLng(rsPlayer!CLuc))
                'Gain the level
                If (lPlayerLevel > 49) Then
                    rsPlayer!Config = Mid(MyCStr(rsPlayer!Config), 1, 1) & "0" & strForceSize(Mid(MyCStr(rsPlayer!Config), 3), 3, "0", "A") 'we auto turn off fight spam for them
                End If
                lPlayerLevel = lPlayerLevel + 1
                rsPlayer!PlayerLevel = lPlayerLevel
                'Depending how lucky and charming they are they get a maxgain variance
                'Gain HP
                lPlayerLucBonus = lRandom(MyCLng(MyCLng(rsPlayer!CLuc) / 5) + MyCLng(MyCLng(rsPlayer!CCHA) / 5))
                lMaxGain = (MyCLng(rsPlayer!CCon) / 2 + (MyCLng(MyCLng(rsPlayer!CCon) / 2))) + lPlayerLucBonus + lTranslateStatusGain("HP", zClass) '+ lTranslateStatusGain("HP", zGetTranslateMultiClassStats)
                lGain = (MyCLng(rsPlayer!CCon) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CCon) / 2))) + lPlayerLucBonus + lTranslateStatusGain("HP", zClass) '+ lTranslateStatusGain("HP", zGetTranslateMultiClassStats)
                zGain = zGain & " HP+" & MyCStr(lGain) & "/" & lMaxGain
                rsPlayer!OHP = MyCLng(rsPlayer!OHP) + lGain
                rsPlayer!GHP = MyCLng(rsPlayer!GHP) + lGain
                'Gain Mana
                lPlayerLucBonus = lRandom(MyCLng(MyCLng(rsPlayer!CLuc) / 5) + MyCLng(MyCLng(rsPlayer!CCHA) / 5))
                lMaxGain = (MyCLng(rsPlayer!CInt) / 2 + (MyCLng(MyCLng(rsPlayer!CInt) / 2))) + lPlayerLucBonus + lTranslateStatusGain("MANA", zClass) '+ lTranslateStatusGain("MANA", zGetTranslateMultiClassStats)
                lGain = (MyCLng(rsPlayer!CInt) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CInt) / 2))) + lPlayerLucBonus + lTranslateStatusGain("MANA", zClass) '+ lTranslateStatusGain("MANA", zGetTranslateMultiClassStats)
                zGain = zGain & " Mana+" & MyCStr(lGain) & "/" & lMaxGain
                rsPlayer!OMANA = MyCLng(rsPlayer!OMANA) + lGain
                rsPlayer!GMana = MyCLng(rsPlayer!GMana) + lGain
                'Gain Essence
                lPlayerLucBonus = lRandom(MyCLng(MyCLng(rsPlayer!CLuc) / 5) + MyCLng(MyCLng(rsPlayer!CCHA) / 5))
                lMaxGain = (MyCLng(rsPlayer!CWIS) / 2 + (MyCLng(MyCLng(rsPlayer!CWIS) / 2))) + lPlayerLucBonus + lTranslateStatusGain("ESSE", zClass) '+ lTranslateStatusGain("ESSE", zGetTranslateMultiClassStats)
                lGain = (MyCLng(rsPlayer!CWIS) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CWIS) / 2))) + lPlayerLucBonus + lTranslateStatusGain("ESSE", zClass) '+ lTranslateStatusGain("ESSE", zGetTranslateMultiClassStats)
                zGain = zGain & " Esse+" & MyCStr(lGain) & "/" & lMaxGain
                rsPlayer!OEssence = MyCLng(rsPlayer!OEssence) + lGain
                rsPlayer!GEssence = MyCLng(rsPlayer!GEssence) + lGain
                'Gain Soul
                lPlayerLucBonus = lRandom(MyCLng(MyCLng(rsPlayer!CLuc) / 5) + MyCLng(MyCLng(rsPlayer!CCHA) / 5))
                lMaxGain = (MyCLng(rsPlayer!CCon) / 2 + (MyCLng(MyCLng(rsPlayer!CCon) / 2))) + (MyCLng(rsPlayer!CDEX) / 2 + (MyCLng(MyCLng(rsPlayer!CDEX) / 2))) + lPlayerLucBonus '+ lTranslateStatusGain("SOUL", zClass) + lTranslateStatusGain("SOUL", zGetTranslateMultiClassStats)
                lGain = (MyCLng(rsPlayer!CCon) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CCon) / 2))) + (MyCLng(rsPlayer!CDEX) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CDEX) / 2))) + lPlayerLucBonus '+ lTranslateStatusGain("SOUL", zClass) + lTranslateStatusGain("SOUL", zGetTranslateMultiClassStats)
                zGain = zGain & " Soul+" & MyCStr(lGain) & "/" & lMaxGain
                rsPlayer!OSoul = MyCLng(rsPlayer!OSoul) + lGain
                rsPlayer!GSoul = MyCLng(rsPlayer!GSoul) + lGain
                'Gain Movement points
                lPlayerLucBonus = lRandom(MyCLng(MyCLng(rsPlayer!CLuc) / 5) + MyCLng(MyCLng(rsPlayer!CCHA) / 5))
                lMaxGain = (MyCLng(rsPlayer!CDEX) / 2 + (MyCLng(MyCLng(rsPlayer!CDEX) / 2))) + (MyCLng(rsPlayer!CCHA) / 2 + (MyCLng(MyCLng(rsPlayer!CCHA) / 2))) + lPlayerLucBonus '+ lTranslateStatusGain("MOVE", zClass) + lTranslateStatusGain("MOVE", zGetTranslateMultiClassStats)
                lGain = (MyCLng(rsPlayer!CDEX) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CDEX) / 2))) + (MyCLng(rsPlayer!CCHA) / 2 + lRandom(MyCLng(MyCLng(rsPlayer!CCHA) / 2))) + lPlayerLucBonus '+ lTranslateStatusGain("MOVE", zClass) + lTranslateStatusGain("MOVE", zGetTranslateMultiClassStats)
                zGain = zGain & " Move+" & MyCStr(lGain) & "/" & lMaxGain
                rsPlayer!OMove = MyCLng(rsPlayer!OMove) + lGain
                rsPlayer!GMove = MyCLng(rsPlayer!GMove) + lGain
                'Gain Learn Points
                lGain = lTranslateLearnPointsGains(zClass)
                lGain = ((MyCLng(lGain / 2) + lRandom(lGain / 2)) + ((MyCLng(rsPlayer!CCHA) / 10) + (MyCLng(rsPlayer!CInt) / 5) + (MyCLng(rsPlayer!CWIS) / 4)))
                lMaxGain = lGain
                lGain = MyCLng(lGain / 2) + lRandom(lGain / 2)
                If (lGain > lTranslateLearnPointsGains(zClass) * 5) Then
                    lGain = lTranslateLearnPointsGains(zClass) * 5
                    lMaxGain = lGain
                End If
                zGain = zGain & " lp[+" & lGain & "/" & lMaxGain & "|" & lTranslateLearnPointsGains(zClass) * 5 & "]"
                rsPlayer!LearnPoints = MyCLng(rsPlayer!LearnPoints) + lGain
                rsPlayer!XP = lRemainingXP
                'Send messages
                subSendMsg "&CGRATZ! YOU GAINED A LEVEL!" & vbCrLf & "&cGAIN:" & zGain, zPortID
                If (lRemainingXP > 0) Then subSendMsg gblzFNCYA & MyCStr(lRemainingXP) & "xp was carried over.", zPortID
                rsPlayer!XP = lRemainingXP
                
                
                'subSimpleEchoChannel "&W" & MyCStr(rsPlayer!PlayerName) & " &Cgained a level!"
                
                'Now give players their bonus skills
                If (MyCLng(rsPlayer!DuelWield) = 0) Then
                    If (MyCLng(rsPlayer!PlayerLevel) >= lTranslateDualWeildValueByClass(zClass)) Then
                        subSendMsg "&WYou are now &RDEADLY!&C You can now dual wield weapons!", zPortID
                        rsPlayer!DuelWield = True
                    End If
                End If
                
                If (MyCLng(rsPlayer!BlindFight) = 0) Then
                    If (MyCLng(rsPlayer!PlayerLevel) >= lTranslateBlindFightValueByClass(zClass)) Then
                        subSendMsg "&WYou can now blind fight!", zPortID
                        rsPlayer!BlindFight = True
                    End If
                End If
                
                If (MyCLng(rsPlayer!StunFight) = 0) Then
                    If (MyCLng(rsPlayer!PlayerLevel) >= lTranslateStunFightValueByClass(zClass)) Then
                        subSendMsg "&WYou can now stun fight!", zPortID
                        rsPlayer!StunFight = True
                    End If
                End If
                
                Select Case (lPlayerLevel)
                    Case 0, 1, 2, 3, 4, 6, 7
                        Select Case lRandom(4)
                            Case 1
                                subSendMsg "&AThe red creature has the letter that you give to the guard.", zPortID
                            Case 2
                                subSendMsg "&AThe guard requires the letter from the red creature.", zPortID
                            Case 3
                                subSendMsg "&ATouching the floor at the guard requires you to be level 10", zPortID
                            Case 4
                                subSendMsg "&AThe Guard and the letter are the keys to leaving the noobie area.", zPortID
                        End Select
                    Case 5
                        subSendMsg "&W[title command available]", zPortID
                    Case 8
                        rsPlayer!QuestMissionLog = "" 'we clear the message log for the red dummy
                    Case 9
                        subSendMsg "&W[description command available]", zPortID
                    Case 10 To 19
                    Case 20 'we dont let them stay in the noobie area too long
                        subSendMsg "&Y[magic word ability on] [rare item ability on] [training messages off]", zPortID
                        If (lZ = -10) Then
                            subCombatEndedInitializeCombatCellsPortID MyCLng(zPortID)
                            lX = 0
                            lY = 0
                            lZ = 0
                            lRecallX = 0
                            lRecallY = 0
                            lRecallZ = 0
                            rsPlayer!RecallX = lRecallX
                            rsPlayer!RecallY = lRecallY
                            rsPlayer!RecallZ = lRecallZ
                            rsPlayer!x = lX
                            rsPlayer!y = lY
                            rsPlayer!z = lZ
                            subSendMsg "&A* * * P O O F * * *" & vbCrLf & "&W[you are now at the city centre]", zPortID
                        End If
                    Case 60
                        subSendMsg "&W[you gained the Hero channel]", zPortID
                    Case 100
                        subSendMsg "&W[you gained the Lord channel]", zPortID
                    Case 175
                        subSendMsg "&W[you gained the Entity channel]", zPortID
                End Select
                rsPlayer.Update
            Else
                'In a way this is game end, the person has probably done everything by now - so we ASCEND them to the stars
                subSimpleEchoChannel "&W~ ~ ~ ~&Y" & strForceSize(MyCStr(rsPlayer!PlayerName), 15, " ", "B") & " &W-=ASCENDED=- &W[+99lps +99cofg]               &W~ ~ ~ ~"
                subSendMsg "&WGRATZ! &aYou have attained ~ascension~ or to most mortals" & vbCrLf & "as the maximum level in the realm!&W [+99lps +9cofg]", zPortID
                rsPlayer.Edit
                rsPlayer!RoomTitle = "ASCENDED"
                rsPlayer!XP = lRemainingXP
                rsPlayer!Crown = MyCLng(rsPlayer!Crown) + 99
                rsPlayer!LearnPoints = MyCLng(rsPlayer!LearnPoints) + 99
                rsPlayer.Update
            End If
            subShowNewSpells zPortID
        End If
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerGains," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subShowNewSpells(zPortID As String)
On Error GoTo Err_Check 'When the player levels they get to see if there was a spell update
    Dim rsPlayer As Recordset
    Dim zRace As String
    Dim zClass As String
    Dim lLevel As Long
    Dim bOkay As Boolean

    Set rsPlayer = MyDB.OpenRecordset("SELECT Race, Class, PlayerLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bOkay = True
        zRace = UCase(MyCStr(rsPlayer!Race))
        zClass = UCase(MyCStr(rsPlayer!Class))
        lLevel = MyCLng(rsPlayer!PlayerLevel)
    Else
        bOkay = False
    End If
    Set rsPlayer = Nothing

    If (bOkay) Then
        'SELECT LearnName FROM tblPlayerLearn WHERE (((RaceRestricted)='" & zRace & "' Or (RaceRestricted)='' Or (RaceRestricted) Is Null) AND ((TargetID)=0) AND ((LearnLevelRestricted)=" & lLevel & ") AND ((ClassNotPermitted)<>'" & zClass & "')) OR (((ClassRestricted)='" & zClass & "' Or (ClassRestricted)='' Or (ClassRestricted) Is Null) AND ((TargetID)=0) AND ((LearnLevelRestricted)=" & lLevel & ") AND ((ClassNotPermitted)<>'" & zClass & "')) ORDER BY LearnName;
        Set rsPlayer = MyDB.OpenRecordset("SELECT LearnName FROM tblPlayerLearn WHERE (LearnLevelRestricted=" & lLevel & ") AND (TargetID=0) AND (LearnStatus=0) AND (ClassRestricted='" & zClass & "' Or ClassRestricted Is Null Or ClassRestricted='') AND (RaceRestricted='" & zRace & "' Or RaceRestricted Is Null Or RaceRestricted='') AND (ClassNotPermitted<>'" & zClass & "' OR ClassNotPermitted Is Null OR ClassNotPermitted='') ORDER BY LearnName;", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            subSendMsg "&WN E W  S P E L L S  A V A I L A B L E !!" & vbCrLf & "&M" & "HELP TEACHER " & gblzFNMAG & "- to find the main teachers" & vbCrLf & "&M" & "LEARN TREE " & gblzFNMAG & "and " & "&M" & "SLIST " & gblzFNMAG & "to see your future list of spells and skills." & vbCrLf & "&w--------------------------------------------------------------------------------" & vbCrLf & "You can now learn at one of the realm teachers the following:&a", zPortID
            Do While (Not rsPlayer.EOF)
                subSendMsg "     " & MyCStr(rsPlayer!LearnName), zPortID
                rsPlayer.MoveNext
            Loop
        Else
            subSendMsg "&ANo new spells for this level.", zPortID
        End If
        Set rsPlayer = Nothing
    Else
        subSendMsg "&RReport to an immortal your entire screen log and this error message:" & vbCrLf & "subShowNewSpells, player file not found.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subShowNewSpells," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerQuest(zPlayerName As String, lPlayerID As Long, lPlayerLevel As Long, lQuestMobID As Long, zMobName As String, lMobID As Long, lMobLevel As Long, bBounty As Boolean, zPortID As String, lPX As Long, lPY As Long, lPZ As Long, ByRef lHoldGold As Long, lMMoveAllowed As Long) 'ByRef so we can pass back the value
On Error GoTo Err_Check 'we complete quests here bounty raids glory mobs
    Dim bGained As Boolean
    Dim lHP As Long
    Dim lSoul As Long
    Dim lEssence As Long
    Dim lMana As Long
    Dim lMove As Long
    Dim lGlory As Long
    Dim lCount As Long
    Dim lPortID As Long
    Dim lLearnPoint As Long
    
    If (lQuestMobID = lMobID Or lMMoveAllowed <> 0) Then 'quest mobs or raid mobs
        lPortID = MyCLng(zPortID)
        subSendMsg "&G[&gCongratulations&G] [&A" & zMobName & " defeated&G]", zPortID
        
        lSoul = 0
        lEssence = 0
        lMana = 0
        lMove = 0
        lGlory = 0
        lCount = lRandom(2)
        lLearnPoint = 0
        
        If (lMMoveAllowed = 0) Then
            lGlory = lGlory + 1 'raid mobs dont give glory by default like Oracle quests do
            lCount = lCount + lRandom(5) + 5 'raid mobs dont give extra rolls
        End If
        lHP = lHP + lRandom(2) 'start with bonus HPs for sure
        Do While (lCount > 0)
            Select Case lRandom(7)
                Case 1
                    lHP = lHP + lRandom(2)
                Case 2
                    lMana = lMana + lRandom(2)
                Case 3
                    lEssence = lEssence + lRandom(2)
                Case 4
                    lSoul = lSoul + lRandom(2)
                Case 5
                    lMove = lMove + lRandom(2)
                Case 6
                    If (lRandom(3) = 1) Then lLearnPoint = lLearnPoint + 1
                Case 7
                    If (lRandom(6) = 1) Then
                        If (lMMoveAllowed = 0) Then 'Not a raid mob, give glory for sure
                            lGlory = lGlory + 1
                        Else 'raid mobs by fluke can give glory
                            If (lRandom(20) = 1) Then lGlory = lGlory + 1
                        End If
                    End If
            End Select
            lCount = lCount - 1
        Loop
        
        If (lHP > 0) Then subSendMsg "&w+" & lHP & " health", zPortID
        If (lMana > 0) Then subSendMsg "&w+" & lMana & " mana", zPortID
        If (lEssence > 0) Then subSendMsg "&w+" & lEssence & " essence", zPortID
        If (lSoul > 0) Then subSendMsg "&w+" & lSoul & " soul", zPortID
        If (lMove > 0) Then subSendMsg "&w+" & lMove & " move", zPortID
        
        If (lLearnPoint > 0) Then subSendMsg "&W+" & lLearnPoint & " learn points!", zPortID
        
        If (lGlory > 0) Then
            gbllQuestGuardAreaID(lPortID) = 0 'clear lazyguard
            gblzQuestGuardAreaDesc(lPortID) = ""
            gblzQuestGuardAreaDescAt(lPortID) = ""
            gbllQuestGuardFailCount(lPortID) = 0
            If lPlayerLevel < 50 Then subSendMsg "[-PL50] &W+" & lGlory & "&w crowns of glory for this quest!", zPortID
            subSendMsgInfoChannel "[" & zWhereName(lPX, lPY, lPZ) & "&g] &w" & zPlayerName & " [defeated] [" & zMobName & "] &W[&Y+&W" & lGlory & "&wcofg&W]"
        End If
        
        'Add in the results
        MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]+" & lGlory & ", GHP=[GHP]+" & lHP & ", GMana=[GMana]+" & lMana & ", GEssence=[GEssence]+" & lEssence & ", GSoul=[GSoul]+" & lSoul & ", GMove=[GMove]+" & lMove & ", LearnPoints=[LearnPoints]+" & lLearnPoint & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
        
        subQuestWrapUp lPlayerID
        gbllRecalculatedDelay(lPortID) = -2
        subRecalculatePlayerEquipment lPlayerID, zPortID
    End If
    
    If (bBounty) Then
        lHoldGold = lHoldGold + (lMobLevel * 3) + 88 'byref
        'Debug.Print "ADDED GOLD: " & (lMobLevel * 3) + 88
        subSendMsg cstBountyTitle & " " & zFormatGoldCofGLearnpts(lHoldGold, "g", True), zPortID
        MyDB.Execute "UPDATE tblPlayer SET [Gold]=[Gold]+" & lHoldGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerQuest," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zLastHitPlayer(zClass As String, iType As Integer) As String
On Error Resume Next
    Dim zReturn As String
    Select Case zClass
        Case "DR"
            Select Case iType
                Case 1
                    zReturn = "BLUDGEON"
                Case Else
                    zReturn = "BLUDGEONS"
            End Select
        Case "DR"
            Select Case iType
                Case 1
                    zReturn = "SHILLELAGH"
                Case Else
                    zReturn = "SHILLELAGHS"
            End Select
        Case "MA"
            Select Case iType
                Case 1
                    zReturn = "IMPALE"
                Case Else
                    zReturn = "IMPALES"
            End Select
        Case "AS"
            Select Case iType
                Case 1
                    zReturn = "ASSASSINATE"
                Case Else
                    zReturn = "ASSASSINATES"
            End Select
        Case "RA"
            Select Case iType
                Case 1
                    zReturn = "ERADICATE"
                Case Else
                    zReturn = "ERADICATES"
            End Select
        Case "PA"
            Select Case iType
                Case 1
                    zReturn = "ENFORCE"
                Case Else
                    zReturn = "ENFORCES"
            End Select
        Case "WA"
            Select Case iType
                Case 1
                    zReturn = "VITIATE"
                Case Else
                    zReturn = "VITIATES"
            End Select
        Case "MO"
            Select Case iType
                Case 1
                    zReturn = "VIOLATE"
                Case Else
                    zReturn = "VIOLATES"
            End Select
        Case "GY"
            Select Case iType
                Case 1
                    zReturn = "EXECUTE"
                Case Else
                    zReturn = "EXECUTES"
            End Select
        Case "TH"
            Select Case iType
                Case 1
                    zReturn = "BACKSTAB"
                Case Else
                    zReturn = "BACKSTABS"
            End Select
        Case "GL"
            Select Case iType
                Case 1
                    zReturn = "ELIMINATE"
                Case Else
                    zReturn = "ELIMINATES"
            End Select
        Case "KN"
            Select Case iType
                Case 1
                    zReturn = "TERMINATE"
                Case Else
                    zReturn = "TERMINATES"
            End Select
        Case Else
            Select Case iType
                Case 1
                    zReturn = "BUTCHER" 'FINISH
                Case Else
                    zReturn = "BUTCHERS"
            End Select
    End Select
    zLastHitPlayer = zReturn
End Function
Public Sub subMobSpeakDeathScene(lMobID As Long)
On Error GoTo Err_Check
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim rsMob As Recordset
    
    Set rsMob = MyDB.OpenRecordset("SELECT tblMobSpeak.MobSpeakSortOrder, tblMob.MobID, tblMob.MobName, tblMobSpeak.MobSocial, tblMobSpeak.SpeakMessage, tblMob.X, tblMob.Y, tblMob.Z, tblMobSpeak.SpeakDeath FROM tblMob INNER JOIN tblMobSpeak ON tblMob.MobID = tblMobSpeak.MobID WHERE (((tblMob.MobID)=" & lMobID & ") AND ((tblMobSpeak.SpeakDeath)=Yes)) ORDER BY tblMobSpeak.MobSpeakSortOrder;", dbOpenSnapshot)
    If (Not rsMob.EOF) Then
        lX = MyCLng(rsMob!x)
        lY = MyCLng(rsMob!y)
        lZ = MyCLng(rsMob!z)
        Do While (Not rsMob.EOF)
            If (Len(MyCStr(rsMob!MobSocial)) > 0) Then subSendMsgAreaAll "&R" & MyCStr(rsMob!MobSocial), lX, lY, lZ  'We hard code the sound as someone arriving from death. This also tells immortals where playes die and arrive at.
            If (Len(MyCStr(rsMob!SpeakMessage)) > 0) Then subSendMsgAreaAll gblzFNYEL & MyCStr(rsMob!SpeakMessage), lX, lY, lZ 'We hard code the sound as someone arriving from death. This also tells immortals where playes die and arrive at.
            rsMob.MoveNext
        Loop
    End If
    Set rsMob = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobSpeakDeathScene," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lElementalResistance(lTotalDamage As Long, lHoldResistancePercent As Long) As Long
On Error GoTo Err_Check 'lElementalResistance(1000, 20) = 880
    Dim lReturn As Long
    Dim lResistancePercent As Long
    
    'the higher lResistancePercent is the lower the end value of lReturn will be
    'if lResistance = 99 then only 1 percent of lreturn will be left
    'if lResistance = 100 then lReturn will be 0
    lResistancePercent = lHoldResistancePercent
    If (lResistancePercent < 1) Then lResistancePercent = 1
    If (lResistancePercent > 100) Then lResistancePercent = 100
    lReturn = lTotalDamage - MyCLng(lTotalDamage * (lResistancePercent / 100))
    If (lReturn < 1) Then lReturn = 1
    lElementalResistance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lElementalResistance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subSystemMessageToHighImmortals(zMsg As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (ImmortalLevel>=99 AND Len([PortID])>1);", dbOpenSnapshot) 'Level to receive
    Do While (Not rsData.EOF)
        subSendMsg "&W[IL99]" & zMsg, MyCStr(rsData!PortID)
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSystemMessageToHighImmortals," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSystemMessageToImmortals(zMsg As String, lImmortalLevel As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (ImmortalLevel>=" & lImmortalLevel & " AND Len([PortID])>1);", dbOpenSnapshot) 'Level to receive
    Do While (Not rsData.EOF)
        subSendMsg "&w[IL" & lImmortalLevel & "]" & zMsg, MyCStr(rsData!PortID)
        rsData.MoveNext
    Loop
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSystemMessageToImmortals," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subQuestHerdMob(lHerdMobID As Long, zPlayerName As String, lPlayerID As Long, lMagicFind As Long, lBaseMagicFind As Long, lPlayerLevel As Long, bMasterstabber As Boolean, zPortID As String)
On Error GoTo Err_Check
    Dim rsHerdMob As Recordset
    Dim lHerdCountLeft As Long
    Dim lObjectID As Long
    Dim zMsgFailure As String
    Dim zMsgSuccess As String
    Dim lHoldRareRandom As Long
    Dim zHerdQuestTitle As String
    Dim rsData As Recordset
    Dim lPlayerRoll As Long
    Dim lMobRoll As Long
    Dim bMBSPass As Boolean
    
    'A quest herd mob has died, we now check to see if the rest are still alive!
    lHerdCountLeft = lngSQLRecordCount("SELECT HerdMobID FROM tblMob WHERE (HerdMobID=" & lHerdMobID & " AND RespawnDelay=0);")
    
    zHerdQuestTitle = ""
    lObjectID = 0
    Set rsHerdMob = MyDB.OpenRecordset("SELECT ObjectID, RareRandom, MsgFailure, MsgSuccess, HerdQuestTitle FROM tblMobQuestHerd WHERE (HerdMobID=" & lHerdMobID & ");", dbOpenSnapshot)
    Do While (Not rsHerdMob.EOF)  'get the next quest item for this heard id
        lObjectID = MyCLng(rsHerdMob!ObjectID)
        zHerdQuestTitle = (MyCStr(rsHerdMob!HerdQuestTitle))
        lHoldRareRandom = MyCLng(rsHerdMob!RareRandom)
        zMsgSuccess = MyCStr(rsHerdMob!MsgSuccess)
        zMsgFailure = MyCStr(rsHerdMob!MsgFailure)
        
        If (Len(zHerdQuestTitle) <> 0) Then subSendMsg gblzFBCYA & ((zHerdQuestTitle)), zPortID
        
        If (lObjectID <> 0) Then
            If (lHerdCountLeft = 0 Or bMasterstabber) Then
                'first we make the entire group come back all at the same time to prevent cheating
                If (lPlayerLevel > 9) Then MyDB.Execute "UPDATE tblMob SET RespawnDelay=10+" & lRandom(20) & " WHERE (HerdMobID=" & lHerdMobID & ");", dbFailOnError
                lPlayerRoll = lRandom(lMagicFind) + lBaseMagicFind
                lMobRoll = lRandom(lHoldRareRandom)
                If (lPlayerRoll > lMagicFind) Then lPlayerRoll = lMagicFind
                bMBSPass = (bMasterstabber And lRandom(9) > 2)
                If (Not bMBSPass) Then
                    subSendMsg "&yCHANCE: " & lBaseMagicFind & "|" & lMagicFind & " vs " & lHoldRareRandom & ", you have a " & zPercentChance(lMagicFind, lHoldRareRandom) & vbCrLf & "The rolls are: " & lPlayerRoll & " vs " & lMobRoll, zPortID
                Else
                    subSendMsg "&yMASTER: " & lBaseMagicFind & "|" & lMagicFind & " vs " & lHoldRareRandom & ", you have a " & zPercentChance(lMagicFind, lHoldRareRandom) & vbCrLf & "The rolls are: " & lPlayerRoll & " vs " & lMobRoll, zPortID
                End If
                If ((lPlayerRoll >= lMobRoll) Or (bMBSPass)) Then
                    lDuplicateObject lObjectID, lPlayerID, 99, (lMobRoll < 3), ((lMagicFind - lPlayerRoll) < 2), False, 0
                    If (Len(zMsgSuccess) <> 0) Then subSendMsg "&Y" & ((zMsgSuccess)), zPortID
                    'subImmortalOnlyChannel zPortID, zPlayerName, (("I have completed the " & zHerdQuestTitle)),  30
                    'Send to all immortals that the player completed a group/herd quest
                    subSystemMessageToImmortals "&r(EAR) " & gblzFBWHI & zPlayerName & "&w has completed group herd quest:" & vbCrLf & ((zHerdQuestTitle)), 1
                Else
                    If (Len(zMsgFailure) <> 0) Then subSendMsg "&r" & ((zMsgFailure)), zPortID
                End If
            Else
                If (Len(zHerdQuestTitle) <> 0) Then subSendMsg "&G" & lHerdCountLeft & "/" & lngSQLRecordCount("SELECT HerdMobID FROM tblMob WHERE (HerdMobID=" & lHerdMobID & ");") & " to go till the quest is completed.", zPortID
            End If
        Else
            subSendMsg "&RPlease inform an immortal to finish this quest.", zPortID
        End If
        rsHerdMob.MoveNext
    Loop
    Set rsHerdMob = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subQuestHerdMob," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bNewbieArea(lPlayerLevel As Long, lWhereID As Long) As Boolean
On Error GoTo Err_Check
    Dim bNewbie As Boolean
    If (lPlayerLevel < 21) Then 'low levels have the right to live though some things
        bNewbie = (lngSQLRecordCount("SELECT WhereID FROM tblWhere WHERE (WhereID=" & lWhereID & " AND NewbieArea=True);") > 0)
    Else
        bNewbie = False
    End If
    bNewbieArea = bNewbie
    Exit Function
Err_Check:
    subWriteErrorFile "bNewbieArea," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subVerifyMobEquipment() 'What this PROC does is counts for each mob the amt of carried Equipment
On Error GoTo Err_Check
'see also: basRecalculateMobEquipment
    Dim lMobID As Long
    Dim lCount As Long
    Dim rsMobEq As Recordset
    
    Set rsMobEq = MyDB.OpenRecordset("SELECT MobID, Count(ObjectID) AS CountOfObjectID FROM tblMobEquipmentItems GROUP BY MobID;", dbOpenSnapshot)
    Do While (Not rsMobEq.EOF)
        lMobID = MyCLng(rsMobEq!MobID)
        lCount = MyCLng(rsMobEq!CountOfObjectID)
        MyDB.Execute "UPDATE tblMob SET EquipmentTotal=" & lCount & " WHERE (MobID=" & lMobID & ");", dbFailOnError
        rsMobEq.MoveNext
    Loop
    Set rsMobEq = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subVerifyMobEquipment," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub basRecalculateMobEquipment(lPassMobID As Long) 'see also: subVerifyMobEquipment
On Error GoTo Err_Check
    Dim lValue As Long
    lValue = lngSQLRecordCount("SELECT ObjectID FROM tblMobEquipmentItems WHERE (StolenItem=False AND MobID=" & lPassMobID & ");")
    MyDB.Execute "UPDATE tblMob SET EquipmentTotal=" & lValue & " WHERE (MobID=" & lPassMobID & ");", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "basRecalculateMobEquipment," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobEquipmentStealsFromPlayerInventory(lChance As Long) 'See Also: subMoveMobsWhereID subMobEquipmentStolenReturned
On Error GoTo Err_Check
    Const cstTotalStolenInvItems = 15
    Dim rsGoose As Recordset
    Dim rsPlayer As Recordset
    Dim lSQLCount As Long
    Dim lTotalStolenInvItems As Long
    Dim bObjectFound As Boolean
    Dim rsMob As Recordset
    Dim bMobFound As Boolean
    Dim lMobLevel As Long
    Dim zMobName As String
    Dim lMobStealChance As Long
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCCHA As Long
    Dim lCDEX As Long
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lMobID As Long
    Dim lObjectID As Long
    Dim zPortID As String
    Dim bThiefNames As Boolean
    
    If (lRandom(lChance) = 1) Then
    Set rsGoose = MyDB.OpenRecordset("SELECT PlayerID, PortID, CCHA, CDEX, CINT, CWIS, Race, Class, X, Y, Z FROM tblPlayer WHERE (Len(PortID)>1 AND Class<>'GY' AND Class<>'TH' AND Race<>'TRO' AND Race<>'OGR');", dbOpenSnapshot) 'they pick from everyone in the room, 'mobs do not steal from GY TH or TRO or OGRE
    Do While (Not rsGoose.EOF) 'we get all the players that are online
        If lRandom(3) = 1 Then 'only 1/3 of the players in the system get an attempt
        lPlayerID = MyCLng(rsGoose!PlayerID)
        zPortID = MyCStr(rsGoose!PortID)
        
        bObjectFound = False
        lObjectID = 0
        lSQLCount = lngSQLRecordCount("SELECT ObjectID FROM tblPlayerInventoryItems WHERE (PlayerID=" & lPlayerID & ");")
        If (lSQLCount > 0) Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lSQLCount) & " ObjectID FROM tblPlayerInventoryItems WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            rsPlayer.MoveLast
            bObjectFound = True
            lObjectID = MyCLng(rsPlayer!ObjectID)
        End If
        Set rsPlayer = Nothing
        
        If (bObjectTrueWhenNotKeepNotStampedNorProtected(lObjectID)) Then
            'If (bObjectFound) Then
            bMobFound = False
            bThiefNames = False
            lX = MyCLng(rsGoose!x)
            lY = MyCLng(rsGoose!y)
            lZ = MyCLng(rsGoose!z)
        
            lSQLCount = lngSQLRecordCount("SELECT MobID, MobLevel, MobName FROM tblMob WHERE (SpecialSelfDeleting=0 AND RespawnDelay=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");")
            If (lSQLCount > 0) Then
                Set rsMob = MyDB.OpenRecordset("SELECT TOP " & lRandom(lSQLCount) & " MobID, MobLevel, MobName FROM tblMob WHERE (SpecialSelfDeleting=0 AND RespawnDelay=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
                If (Not rsMob.EOF) Then
                    rsMob.MoveLast
                    bMobFound = True
                    zMobName = LCase(zShortstop(MyCStr(rsMob!MobName))) 'lower case everything IS A MUST coding here
                    bThiefNames = (InStr(zMobName, "gnoll") > 0 Or InStr(zMobName, "goblin") > 0 Or InStr(zMobName, "alien") > 0 Or InStr(zMobName, "prostit") > 0 Or InStr(zMobName, "criminal") > 0 Or InStr(zMobName, "pirate") > 0 Or InStr(zMobName, "thief") > 0 Or InStr(zMobName, "outlaw") > 0 Or InStr(zMobName, "hood") > 0 Or InStr(zMobName, "mimic") > 0 Or InStr(zMobName, "cloak") > 0 Or InStr(zMobName, "shadow") > 0 Or InStr(zMobName, "prisoner") > 0)
                    lMobID = MyCLng(rsMob!MobID)
                    lMobLevel = MyCLng(rsMob!MobLevel)
                    lMobStealChance = lRandom(lMobLevel) + lRandom(50) + lRandom(lMobLevel) + MyCLng(lMobLevel / 4) + 15
                End If
                Set rsMob = Nothing
                
                If (bMobFound) Then
                If (bThiefNames) Then
                lTotalStolenInvItems = lngSQLRecordCount("SELECT ObjectID FROM tblMobEquipmentItems WHERE (StolenItem<>0 AND MobID=" & lMobID & ");")
                If (lTotalStolenInvItems <= cstTotalStolenInvItems) Then
                    If (lRandom(15) < 12) Then
                        lCCHA = MyCLng(rsGoose!CCHA)
                        lCDEX = MyCLng(rsGoose!CDEX)
                        lCINT = MyCLng(rsGoose!CInt)
                        lCWIS = MyCLng(rsGoose!CWIS)
                    
                        If (lRandom(lCCHA + lRandom((lCDEX * 2)) + lRandom(lCINT) + lRandom(lCWIS)) <= lMobStealChance) Then
                            MyDB.Execute "INSERT INTO tblMobEquipmentItems ( MobID, ObjectID, StolenItem ) SELECT " & lMobID & ", " & lObjectID & ", 1;", dbFailOnError
                            MyDB.Execute "DELETE FROM tblPlayerInventoryItems WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                            MyDB.Execute "UPDATE tblObject SET Status=2 WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                            
                            MyDB.Execute "INSERT INTO tblPlayerLostItem ( PlayerID, ObjectID, X, Y, Z, LostMsg ) SELECT " & lPlayerID & ", " & lObjectID & ", " & lX & ", " & lY & ", " & lZ & ", 'TS';", dbFailOnError
                        Else
                            subSendMsg "&M" & zMobName & " says to you, 'Ooops, my fault sir, my hands never left my side.'", zPortID
                        End If
                    Else
                        subSendMsg "&M" & zMobName & " says to you, 'Excuse me sir didn't mean to bump into you like that.'", zPortID
                    End If
                Else
                    Select Case lRandom(9)
                        Case 1
                            subSendMsg "&M" & zMobName & " mentions, 'its time to sell me goods...' [" & lTotalStolenInvItems & "]", zPortID
                        Case 2
                            subSendMsg "&M" & zMobName & " eggs-you-on, 'maybe some of this belong to you?!' [" & lTotalStolenInvItems & "]", zPortID
                        Case 3
                            subSendMsg "&M" & zMobName & " eggs-you-on, 'guess what? HAR HAR! Like I tell you!' [" & lTotalStolenInvItems & "]", zPortID
                    End Select
                End If
                End If
                End If
            End If 'If (lSQLCount > 0) Then
            'End If 'If (bObjectFound) Then
        End If
        End If
        End If
        rsGoose.MoveNext
    Loop
    Set rsGoose = Nothing
    End If 'rnd chance = 1
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobEquipmentStealsFromPlayerInventory," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMobEquipmentStolenReturned(lMobID As Long, zPortID As String) 'see also subMobEquipmentStealsFromPlayerInventory
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim bMobFound As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lReturned As Long
    Dim lMobEquipmentItemsID As Long
    Dim zMobName As String
    Dim lObjectID As Long
    
    bMobFound = False
    Set rsMob = MyDB.OpenRecordset("SELECT MobName, X, Y, Z FROM tblMob WHERE (MobID=" & lMobID & ");", dbOpenSnapshot)
    If (Not rsMob.EOF) Then
        bMobFound = True
        zMobName = zShortstop(MyCStr(rsMob!MobName))
        lX = MyCLng(rsMob!x)
        lY = MyCLng(rsMob!y)
        lZ = MyCLng(rsMob!z)
    End If
    Set rsMob = Nothing
    
    If (bMobFound) Then
        'if its a stolenitem delete it from the mobequipment list
        Set rsMob = MyDB.OpenRecordset("SELECT MobEquipmentItemsID, ObjectID, StolenItem FROM tblMobEquipmentItems WHERE (MobID=" & lMobID & " AND StolenItem<>0);", dbOpenSnapshot)
        Do While (Not rsMob.EOF)
            lMobEquipmentItemsID = MyCLng(rsMob!MobEquipmentItemsID)
            lObjectID = MyCLng(rsMob!ObjectID)
            'We place the object on the ground with the Mob X Y Z
            MyDB.Execute "UPDATE tblObject SET PlayerID=0, Status=0, VisibleLevel=0, X=" & lX & ", Y=" & lY & ", Z=" & lZ & " WHERE ObjectID=" & lObjectID & ";", dbFailOnError 'SystemObjectType=0 shouldnt be set just in case
            'We unhook the link
            MyDB.Execute "DELETE MobEquipmentItemsID FROM tblMobEquipmentItems WHERE (MobEquipmentItemsID=" & lMobEquipmentItemsID & " AND StolenItem<>0);", dbFailOnError
            subDeleteObjectIDLostItemsReport lObjectID
            lReturned = lReturned + 1
            rsMob.MoveNext
        Loop
        Set rsMob = Nothing
        If (lReturned > 0) Then
            subSendMsg "&G" & zMobName & " is a thief and was found to carry " & lReturned & " stolen goods!!", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobEquipmentStolenReturned," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subReturnPossibleSAFEArrivalLocations(ByRef zPassAreaName As String, ByRef lPassAreaID As Long, ByRef lQueryX As Long, ByRef lQueryY As Long, ByRef lQueryZ As Long, ByRef zType As String, ByRef zMessage As String) 'if zType returns "good" then the x y z returned is good too
On Error GoTo Err_Check
    Dim rsMessage As Recordset
    Dim zHoldMessage As String
    Dim lReturned As Long
    
    Dim zMsg As String
    
    Dim zObjectName As String
    Dim bObjectFound As Boolean
    Dim lQuestForGlory As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    
    Dim zMobName As String
    Dim bMobFound As Boolean
    Dim lMSpecialGloryPlayerAmt As Long
    Dim bMSpecialSelfDeleting As Boolean
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    
    Dim zAreaName As String
    Dim bAreaFound As Boolean
    Dim lAX As Long
    Dim lAY As Long
    Dim lAZ As Long
    
    'Dim lTotalOnline As Long    : lTotalOnline = lngSQLRecordCount("SELECT PortID FROM tblPlayer WHERE (Len(PortID)>1 AND Len([PortID])>1 AND PortID<>'' And PortID Is Not Null);")
    
    'This procedure returns a random x y z where the player can for sure move to
    
    lQueryX = 0
    lQueryY = 0
    lQueryZ = 0
    zHoldMessage = ""
    
    If (LCase(zType) = "mob" Or LCase(zType) = "both" Or zType = "") Then
        zMsg = ""
        bMobFound = False
        lReturned = lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (RespawnDelay=0);")
        Set rsMessage = MyDB.OpenRecordset("SELECT TOP " & lRandom(lReturned) & " MobID, MobName, X, Y, Z, SpecialGloryPlayerAmt, SpecialSelfDeleting FROM tblMob WHERE (RespawnDelay=0);", dbOpenSnapshot)
        If (Not rsMessage.EOF) Then
            rsMessage.MoveLast
            bMobFound = True
            lMSpecialGloryPlayerAmt = MyCLng(rsMessage!SpecialGloryPlayerAmt)
            bMSpecialSelfDeleting = (MyCInt(rsMessage!SpecialSelfDeleting) <> 0)
            If (lMSpecialGloryPlayerAmt > 0) Then zMsg = zMsg & zFormatGoldCofGLearnpts(lMSpecialGloryPlayerAmt, "c", False)
            If (bMSpecialSelfDeleting) Then zMsg = zMsg & "&w[&aD&w]"
            zMobName = zShortstop(MyCStr(rsMessage!MobName)) & " " & zMsg
            lMX = MyCLng(rsMessage!x)
            lMY = MyCLng(rsMessage!y)
            lMZ = MyCLng(rsMessage!z)
        End If
        Set rsMessage = Nothing
        
        If (bMobFound) Then
            zHoldMessage = zHoldMessage & "&g" & zMobName & "&A[x" & lMX & " y" & lMY & " z" & lMZ & "]" & vbCrLf
            lQueryX = lMX
            lQueryY = lMY
            lQueryZ = lMZ
        End If
    End If
        
    If (LCase(zType) = "object" Or LCase(zType) = "both" Or zType = "") Then
        zMsg = ""
        bObjectFound = False 'location=0 some need too
        lReturned = lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE (CaptureFlagClanID=0 AND Cursed=0 AND PlayerID=0 AND ReturnPlayerID=0 AND Status=0 AND ExplodeDuration=0);") 'note: we choose not to use SystemObjectType as a filter here
        Set rsMessage = MyDB.OpenRecordset("SELECT TOP " & lRandom(lReturned) & " QuestForGlory, ObjectID, ObjectName, X, Y, Z, Burried FROM tblObject WHERE (CaptureFlagClanID=0 AND Cursed=0 AND PlayerID=0 AND ReturnPlayerID=0 AND Status=0 AND ExplodeDuration=0);", dbOpenSnapshot)
        If (Not rsMessage.EOF) Then
            rsMessage.MoveLast
            bObjectFound = True
            lQuestForGlory = MyCLng(rsMessage!QuestForGlory)
            zMsg = ""
            If (MyCInt(rsMessage!Burried) = True) Then zMsg = zMsg & " {burried}"
            If (lQuestForGlory > 0) Then zMsg = zMsg & zFormatGoldCofGLearnpts(lQuestForGlory, "c", False) '" [" & lQuestForGlory & "cofg]"
            zObjectName = zShortstop(MyCStr(rsMessage!ObjectName)) & " " & zMsg
            lOX = MyCLng(rsMessage!x)
            lOY = MyCLng(rsMessage!y)
            lOZ = MyCLng(rsMessage!z)
        End If
        Set rsMessage = Nothing
        
        If (bObjectFound) Then
            zHoldMessage = zHoldMessage & "&g" & zObjectName & "&A[x" & lOX & " y" & lOY & " z" & lOZ & "]" & vbCrLf
            lQueryX = lOX
            lQueryY = lOY
            lQueryZ = lOZ
        End If
    End If

    If (LCase(zType) = "area" Or LCase(zType) = "both" Or zType = "") Then
        bAreaFound = False
        lReturned = lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (FallToDeathSpot=0 AND AreaEventZoneID=0 AND FlyLevel=0 AND AreaTrapID=0 AND PlayerID=0 AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0 AND MobSpaceShipLevel=0 AND Z mod 2 = 0);")
        Set rsMessage = MyDB.OpenRecordset("SELECT TOP " & lRandom(lReturned) & " AreaID, AreaName, X, Y, Z FROM tblArea WHERE (FallToDeathSpot=0 AND AreaEventZoneID=0 AND FlyLevel=0 AND AreaTrapID=0 AND PlayerID=0 AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0 AND MobSpaceShipLevel=0 AND Z mod 2 = 0);", dbOpenSnapshot)
        If (Not rsMessage.EOF) Then
            rsMessage.MoveLast
            bAreaFound = True
            lPassAreaID = MyCLng(rsMessage!AreaID)
            zAreaName = zShortstop(MyCStr(rsMessage!AreaName)) & " "
            zPassAreaName = zAreaName
            lAX = MyCLng(rsMessage!x)
            lAY = MyCLng(rsMessage!y)
            lAZ = MyCLng(rsMessage!z)
        End If
        Set rsMessage = Nothing
        
        If (bAreaFound) Then 'we would rather lock onto an area over mobs and objects
            zHoldMessage = zHoldMessage & "&g" & zAreaName & "&A[x" & lAX & " y" & lAY & " z" & lAZ & "]" & vbCrLf
            lQueryX = lAX
            lQueryY = lAY
            lQueryZ = lAZ
        End If
    End If
        
    zMessage = zHoldMessage
    Exit Sub
Err_Check:
    subWriteErrorFile "subReturnPossibleSAFEArrivalLocations," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description & vbCrLf & zHoldMessage
End Sub
Public Sub subDreamscape(zPortID As String) 'see also: subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 50, zPortID, lStatus, True, lInvisibilityDuration
On Error GoTo Err_Check
    Dim lMAreaID As Long
    Dim zPassAreaName As String
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim zMsg As String
    Dim zType As String
    Dim lCCHA As Long
    Dim bDreaming As Boolean
    Dim lPlayerID As Long
    Dim lStunDuration As Long
    Dim zRace As String
    Dim zClass As String
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lStatus As Long
    'Dim lX As Long
    'Dim lY As Long
    'Dim lZ As Long
    
    lPlayerID = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT Class, Race, CCHA, CMana, CEssence, CSoul, CMove, PlayerName, PlayerID, X, Y, Z, Status, StunDuration FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lStatus = MyCLng(rsPlayer!Status)
        lCCHA = MyCLng(rsPlayer!CCHA)
        zRace = MyCStr(rsPlayer!Race)
        zClass = MyCStr(rsPlayer!Class)
        'lX = MyCLng(rsPlayer!x)
        'lY = MyCLng(rsPlayer!y)
        'lZ = MyCLng(rsPlayer!Z)
    End If
    Set rsPlayer = Nothing
    
    If (lPlayerID <> 0) Then
        If (zClass <> "IO") Then 'witchlockes cannot dream
        If (lStunDuration = 0) Then
            If (lStatus = 50) Then
                subReturnPossibleSAFEArrivalLocations zPassAreaName, lMAreaID, lMX, lMY, lMZ, zType, zMsg
                If (lRandom(20) = 1) Then
                    If (lRandom(20) = 1) Then
                        bDreaming = True
                        subSendMsg "&MDREAMing! Keep it up to recieve your next guard quest!" & vbCrLf & zMsg, zPortID
                    Else
                        If (lRandom(lReturnTranslateCharismaticBonus(zRace, zClass) + lCCHA) < lRandom(15)) Then
                            MyDB.Execute "UPDATE tblPlayer SET SitObjectID=0, Status=50, StunDuration=1+" & lRandom(9) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            subSendMsg "&g*sleep-paralysis &RATTACK&g* &wKeep dreaming! You can do it! Get that Guard quest!" & vbCrLf & zMsg, zPortID
                            If (lRandom(5) = 1) Then
                                subSendMsg "&R*N I G H T M A R E &AATTACK&g* &wKeep dreaming! You can do it! Get that Guard quest!" & vbCrLf & zMsg, zPortID
                                MyDB.Execute "UPDATE tblPlayer SET SitObjectID=0, Status=50, PlayerFleeDuration=6+" & lRandom(9) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            End If
                        End If
                    End If
                End If
                If (lRandom(20 + lReturnTranslateDreamBonus(zRace, zClass)) = 1) Then bDreaming = True
                If (bDreaming) Then subQuestGuardAreaID 1, True, zPortID 'try to go guard
                
                If (lRandom(99) = 1) Then 'Call down the black plague on that random area, NIGHTMARE on this random area!
                    gbllDEATHX = lMX
                    'If (lRandom(2) = 1) Then gbllDEATHX = gbllDEATHX - lRandom(5)
                    'If (lRandom(2) = 1) Then gbllDEATHX = gbllDEATHX + lRandom(5)
                    gbllDEATHY = lMY
                    'If (lRandom(2) = 1) Then gbllDEATHY = gbllDEATHY - lRandom(5)
                    'If (lRandom(2) = 1) Then gbllDEATHY = gbllDEATHY + lRandom(5)
                    gbllDEATHZ = lMZ
                    'If (lRandom(2) = 1) Then gbllDEATHZ = gbllDEATHZ - lRandom(5)
                    'If (lRandom(2) = 1) Then gbllDEATHZ = gbllDEATHZ + lRandom(5)
                    'If (lRandom(5) > 2) Then gbllDEATHZ = 0
                    MyDB.Execute "UPDATE tblPlayer SET StunDuration=99, CHP=1, CESSENCE=1, CMANA=1, CSOUL=1, CMOVE=1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                    subSendMsg "&gthe &aPLAGUE&g spreads to the &Rarea&r!", zPortID
                End If
                subSendMsg "&MYou are having random thoughts," & vbCrLf & zMsg, zPortID
            Else
                subSendMsg "&gYou need to try to SLEEP first.", zPortID
            End If
        Else
            subSendMsg "&g*your sleep paralysis goes on*", zPortID
        End If
        Else
            subSendMsg "&gNuuuuuuuu! *cackles* FIGHT TORNADOES SCRYing not DREAM! *cackles*", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDreamscape," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSpellAngerMobileVSMobile(lChance As Long, Optional zSpellPortID As String, Optional bSpellForm As Boolean)
'Mobiles will attack other mobiles near you and set their MobRespawn to 3 this only happens if tblMob.Alignment = 0 to 1000 vs tblMob.Alignment = -1 to -1000 or vice versa
On Error GoTo Err_Check
    Const lcstEssenceCost = 160
    Dim rsPlayer As Recordset
    Dim bFound As Boolean
    Dim zPlayerName As String
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lPID As Long
    'Dim lCMana As Long
    Dim lCEssence As Long
    'Dim lCSoul As Long
    'Dim lCMove As Long
    Dim lCCHA As Long
    Dim zPortID As String
    Dim lPortID As Long
    Dim rsAMob As Recordset 'attacking
    Dim lAMobID As Long
    Dim zAMobName As String
    Dim lAMobLevel As Long
    Dim lAMX As Long
    Dim lAMY As Long
    Dim lAMZ As Long
    Dim rsDMob As Recordset 'defensive
    Dim zDMobName As String
    Dim lDMobLevel As Long
    Dim lDMobID As Long
    Dim lTotalOnline As Long
    
    If (lRandom(lChance) = 1) Then
        If (zSpellPortID <> "") Then
            zPortID = zSpellPortID 'player requested this Anger spell to run
            If (Len(zPortID) = 4) Then lTotalOnline = 1
        Else 'try a random player
            lTotalOnline = lngSQLRecordCount("SELECT PortID FROM tblPlayer WHERE (Len([PortID])>1);")
            If (lTotalOnline > 0) Then
                Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalOnline) & " PortID FROM tblPlayer WHERE (Len([PortID])>1);", dbOpenSnapshot)
                If (Not rsPlayer.EOF) Then
                    rsPlayer.MoveLast
                    zPortID = MyCStr(rsPlayer!PortID)
                End If
                Set rsPlayer = Nothing
            End If
        End If
        
        lPortID = MyCLng(zPortID)
        If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
            If (gbllAngryVentingSystem(lPortID) > 0) Then
                gbllAngryVentingSystem(lPortID) = gbllAngryVentingSystem(lPortID) - 1
            End If
        End If
        
        If (lTotalOnline <> 0) Then 'at least one person is online
            'Check this player connected
            lPID = 0
            Set rsPlayer = MyDB.OpenRecordset("SELECT CCHA, CMana, CEssence, CSoul, CMove, PlayerName, PlayerID, X, Y, Z, PortID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                'subSendMsg "&MYou concentrate in the area using telepathy to start a random mob fight!", zPortID
                lPID = MyCLng(rsPlayer!PlayerID)
                zPlayerName = MyCStr(rsPlayer!PlayerName)
                lPX = MyCLng(rsPlayer!x)
                lPY = MyCLng(rsPlayer!y)
                lPZ = MyCLng(rsPlayer!z)
                lCCHA = MyCLng(rsPlayer!CCHA)
                'lCMana = MyCLng(rsPlayer!CMana)
                lCEssence = MyCLng(rsPlayer!CEssence)
                'lCSoul = MyCLng(rsPlayer!CSoul)
                'lCMove = MyCLng(rsPlayer!CMove)
            End If
            Set rsPlayer = Nothing
            
            If (bSpellForm) Then subSendMsgAreaAllDISmart "&M", zPlayerName, "%s1 concentrate anger to the area.", "", "%s1 concentrates %g12 anger to the area.", lPX, lPY, lPZ
            
            If (lRandom(lCCHA) > lRandom(6)) Then 'this spell is more for noobies
                If (bSpellForm And lCEssence >= lcstEssenceCost) Then
                    'if the mob being attacked by a mobile dies while a player is attacking it we end the attack
                    lAMobID = 0 'Alignment is neutral or good
                    Set rsAMob = MyDB.OpenRecordset("SELECT PlayerID, MobID, MobAutoAttacks, MobName, MobLevel, Alignment, X, Y, Z FROM tblMob WHERE (Alignment>0 AND X>" & lPX - 3 & " AND X<" & lPX + 3 & " AND Y>" & lPY - 3 & " AND Y<" & lPY + 3 & " AND Z>" & lPZ - 3 & " AND Z<" & lPZ + 3 & ");", dbOpenSnapshot)
                    If (Not rsAMob.EOF) Then
                        lAMobID = MyCLng(rsAMob!MobID)
                        lAMobLevel = MyCLng(rsAMob!MobLevel)
                        lAMX = MyCLng(rsAMob!x)
                        lAMY = MyCLng(rsAMob!y)
                        lAMZ = MyCLng(rsAMob!z)
                        zAMobName = MyCStr(rsAMob!MobName)
                    End If
                    Set rsAMob = Nothing
                    
                    lDMobID = 0 'Alignment is evil for the defending evil mob
                    Set rsDMob = MyDB.OpenRecordset("SELECT PlayerID, MobID, MobAutoAttacks, MobName, MobLevel, Alignment, X, Y, Z FROM tblMob WHERE (Alignment<1 AND X=" & lAMX & " AND Y=" & lAMY & " AND Z=" & lAMZ & ");", dbOpenSnapshot)
                    If (Not rsDMob.EOF) Then
                        lDMobID = MyCLng(rsDMob!MobID)
                        zDMobName = MyCStr(rsDMob!MobName)
                        lDMobLevel = MyCLng(rsDMob!MobLevel)
                    End If
                    Set rsDMob = Nothing
                    
                    If (lAMobID <> 0 And lDMobID <> 0) Then 'We have a player in the area of an: attacking mob and a defensive mob, cont...
                        lPortID = MyCLng(zPortID)
                        If (rPCombat(lPortID).lID = lAMobID Or rPCombat(lPortID).lID = lDMobID) Then 'if the player is attacking the mob that died the player stops attacking [stop attacking ends attack]
                            rMCombat(lPortID).Name = ""
                            rPCombat(lPortID).Name = ""
                            rSCombat(lPortID).iStatus = cstiStatusNotInBattleMode
                            rMCombat(lPortID).lID = 0
                            rPCombat(lPortID).lID = 0
                            subSendMsg "&rYour target creature died you stop attacking.", zPortID
                        End If
                        
                        MyDB.Execute "UPDATE tblMob SET RespawnDelay=3 WHERE MobID=" & MyCStr(lDMobID) & ";", dbFailOnError
                        subSimpleEchoChannel "&gMOB FIGHT: &W" & zPlayerName & " &gwatches as &w" & zShortstop(zAMobName) & " &rhas &w" & zShortstop(zDMobName) & " &rassassinated!"
                        If (bSpellForm And lPID <> 0) Then MyDB.Execute "UPDATE tblPlayer SET CEssence=0 WHERE PlayerID=" & MyCStr(lPID) & ";", dbFailOnError
                        subSendMsg "&MThe spell costed " & lcstEssenceCost & " essence to preform and uses it all up to express your area Anger!", zPortID
                    End If
                Else
                    subSendMsg "&gYou require a minimum of " & lcstEssenceCost & " essence to cast that.", zPortID
                End If
            Else 'failed to anger the mobs
                If (bSpellForm And bFound And lPID <> 0) Then MyDB.Execute "UPDATE tblPlayer SET CEssence=0 WHERE PlayerID=" & MyCStr(lPID) & ";", dbFailOnError
                subSendMsg "&mYou stop concentration and look around...", zPortID
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpellAngerMobileVSMobile," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSetAreaUnderwaterDuration(lX As Long, lY As Long, lZ As Long, lUnderwaterDuration As Long)
On Error GoTo Err_Check:
    MyDB.Execute "UPDATE tblArea SET Underwater=999, UnderwaterDuration=" & lUnderwaterDuration & " WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetAreaUnderwaterDuration," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subClearPortTotalXP(lPortID As Long)
On Error Resume Next
    'Dim lPortID As Long
    'lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        gbllPortTotalXP(lPortID) = 0
    End If
End Sub

Public Sub subReducePortTotalXP(zPortID As String, lValue As Long)
On Error Resume Next
    Dim lPortID As Long
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        gbllPortTotalXP(lPortID) = gbllPortTotalXP(lPortID) - lValue
        If (gbllPortTotalXP(lPortID) < 0) Then gbllPortTotalXP(lPortID) = 0
    End If
End Sub
Public Sub subCombatPlayerDiedReset(zMobName As String, lPlayerID As Long)
'See Also: iPlayerHitPointTest
On Error GoTo Err_Check 'you died!
    Dim rsPlayer As Recordset
    Dim zPortID As String
    Dim lXP As Long
    Dim lPlayerLevel As Long
    Dim lXPLoss As Long
    Dim zXPLoss As String
    Dim zOPlayerName As String
    Dim lOPlayerID As Long
    Dim lFPlayerID As Long
    Dim zMsg As String
    
    'clear mobs hunting player
    MyDB.Execute "UPDATE tblMob SET PlayerID=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT FPlayerID, ShadowCloakDuration, PlayerID, PlayerLevel, PlayerName, SanctuaryDuration, BarkskinDuration, StoneskinDuration, DragonskinDuration, DemonskinDuration, StunDuration, BlindDuration, DetectInvisibilityDuration, NegateDuration, HideDuration, CamoflaguedDuration, FireshieldDuration, IceshieldDuration, ChaosshieldDuration, StaticshieldDuration, InvisibilityDuration, X, Y, Z, Alignment, Race, Class, CHP, PortID, XP, DeathsToMobs, Status, AreaTrapID, AreaTrapDuration, RecallX, RecallY, RecallZ FROM tblPlayer WHERE (PlayerID=" & lPlayerID & " AND Len([PortID])>1);", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        If (MyCLng(rsPlayer!CHP) < 1 Or zMobName = "~lightning~") Then 'Reset player to death x y z location.
            If (zMobName = "~lightning~") Then
                gbllAtmosphereStaticCharges = 0 'disarm the charges
                cstAtmozDefault = cstAtmozDefault * 2 'increase hardness
                If (cstAtmozDefault > 400) Then 'an override to prevent this from sticking is in colonists weekly win
                    cstAtmozDefault = 100 '3rd level completed
                    zMsg = vbCrLf & "&WLAST LEVEL FINISHED! WRAPPING to FIRST LEVEL atmoz[0/" & cstAtmozDefault & "]"
                End If
                subSendMsgSQRumorChannel "&CATMOz&R! &WLIGHT&YNI&yNG &RSTRIKE!!!" & zFormatGoldCofGLearnpts(99, "C", True) & zMsg
                MyDB.Execute "UPDATE tblPlayer SET [Crown]=[Crown]+99 WHERE (Len([PortID])>1);", dbFailOnError
            End If
            zPortID = MyCStr(rsPlayer!PortID)
            lXP = MyCLng(rsPlayer!XP)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            Select Case lPlayerLevel
                Case 0 To 30
                    lXPLoss = 500
                    lXP = lXP - lXPLoss
                Case 31 To 99
                    lXPLoss = MyCLng(lXP * 0.2)
                    lXP = lXP - lXPLoss
                Case 100 To 150
                    lXPLoss = MyCLng(lXP * 0.3)
                    lXP = lXP - lXPLoss
                Case 151 To 200
                    lXPLoss = MyCLng(lXP * 0.4)
                    lXP = lXP - lXPLoss
                Case 201 To 250
                    lXPLoss = MyCLng(lXP * 0.5)
                    lXP = lXP - lXPLoss
                Case 251 To 350
                    lXPLoss = MyCLng(lXP * 0.6)
                    lXP = lXP - lXPLoss
                Case Else
                    lXPLoss = MyCLng(lXP * 0.7)
                    lXP = lXP - lXPLoss
            End Select
            zXPLoss = MyCStr(lXPLoss)
            If (lXP < 0) Then lXP = 0
            rsPlayer.Edit
            rsPlayer!XP = lXP
            rsPlayer!CHP = 1 'punishment is low hitpoints - you have to sleep now.
            rsPlayer!DeathsToMobs = MyCLng(rsPlayer!DeathsToMobs) + 1
            rsPlayer!Status = 5
            rsPlayer!AreaTrapID = 0
            rsPlayer!AreaTrapDuration = 0
            rsPlayer!x = 0
            rsPlayer!y = 0 'heaven z-2 and hell z10 are stacked over eachother, newbie zone is at z-10 as well
            rsPlayer!RecallX = 0
            rsPlayer!RecallY = 0
            If (lPlayerLevel > 10) Then
                If ((rsPlayer!Race = "UND" Or MyCLng(rsPlayer!Alignment) < -500) And MyCLng(lRandom(10) = 1)) Then  'the undead can be sent to the undead realm
                    rsPlayer!RecallZ = 10 'hell
                    rsPlayer!z = 10
                Else
                    rsPlayer!RecallZ = -2 'heaven
                    rsPlayer!z = -2
                End If
            Else 'new person under level 11
                rsPlayer!RecallZ = -10
                rsPlayer!z = -10 'noobie area
            End If
            'we sent the durations on the player
            rsPlayer!InvisibilityDuration = 0
            rsPlayer!HideDuration = 0
            rsPlayer!CamoflaguedDuration = 0
            rsPlayer!FireshieldDuration = 0
            rsPlayer!IceshieldDuration = 0
            rsPlayer!ChaosshieldDuration = 0
            rsPlayer!StaticshieldDuration = 0
            rsPlayer!SanctuaryDuration = 0
            rsPlayer!BarkskinDuration = 0
            rsPlayer!StoneskinDuration = 0
            rsPlayer!DragonskinDuration = 0
            rsPlayer!DemonskinDuration = 0
            rsPlayer!StunDuration = 0
            rsPlayer!BlindDuration = 0
            rsPlayer!DetectInvisibilityDuration = 0
            rsPlayer!ShadowCloakDuration = 0
            rsPlayer!NegateDuration = lcstNegateDuration
            rsPlayer.Update
            subMessageDeathPlayer zPortID, zMobName, zXPLoss
            subSendMsgAreaExcept2 "&R" & MyCStr(rsPlayer!PlayerName) & " died!", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, ""
            subSendMsgAreaAll "&BYou see &Wlightning &Yflash &Ba moment in the &Wclouds &Babove you but there is no sound!", 0, 0, 0 'We hard code the sound as someone arriving from death. This also tells immortals where playes die and arrive at.
            subClearPortTotalXP MyCLng(zPortID)
            zOPlayerName = MyCStr(rsPlayer!PlayerName)
            lOPlayerID = MyCLng(rsPlayer!PlayerID)
            lFPlayerID = MyCLng(rsPlayer!FPlayerID)
            subFollowSelf zOPlayerName, lOPlayerID, lFPlayerID, False, zPortID
        End If
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatPlayerDiedReset," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bMobInBattle(lMobID As Long)
On Error GoTo Err_Check
    Dim lPortID As Long
    Dim bReturn As Boolean
    bReturn = False
    For lPortID = cstlMinPort To cstlMaxPort
        If (rSCombat(lPortID).iStatus = cstiStatusPlayerVsMob) Then 'if there is a leader assigned to this mob then the mob is in battle
            If (rMCombat(lPortID).lID = lMobID) Then
                bReturn = True
                Exit For
            End If
        End If
    Next lPortID
    bMobInBattle = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bMobInBattle," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lPlayerFightingMobID(zPortID As String)
On Error Resume Next
    lPlayerFightingMobID = rMCombat(MyCLng(zPortID)).lID
End Function
Public Sub basTriggerGuardsArea(lPassPlayerID As Long, lPassX As Long, lPassY As Long, lPassZ As Long)
    MyDB.Execute "UPDATE tblMob SET PlayerID=" & lPassPlayerID & " WHERE (X=" & lPassX & " AND Y=" & lPassY & " AND Z=" & lPassZ & " AND MobName LIKE '*guard*');", dbFailOnError 'guards can be dead to remember players attacking at their spot
End Sub
Public Function bPlayerVsMobCombatSetUp(zRace As String, zClass As String, lFlyDuration As Long, lPlayerHeight As Long, lFPlayerGroupStatus As Long, lDetectInvisibilityDuration As Long, zPortID As String, zTargetName As String, lOX As Long, lOY As Long, lOZ As Long, lOPlayerID As Long, zOPlayerName As String, zOGender As String, lStatus As Long, lBlindDuration As Long, lStunDuration As Long, bShowErrorMsg As Boolean, bCasting As Boolean) As Boolean
On Error GoTo Err_Check
'Here we mark the mob with the atacking player.
'When there is battle the system looks at the right hand and determines if the object there can be dual wielded if it can it can be used in the battle and there is a dual wield emote for it
    Dim rsMob As Recordset
    Dim zMobName As String
    Dim lBeconPlayerID As String
    Dim rsProtectedMob As Recordset
    Dim bInvisible As Boolean
    Dim lPortID As Long
    Dim zSQL As String
    Dim lTargetID As Long
    Dim lMobID As Long
    Dim rsFollow As Recordset
    Dim lFollowPortID As Long
    Dim lFlyHeight As Long
    Dim bReach As Boolean
    Dim sTotalReach As Single
    Dim bReturn As Boolean

    bReturn = False
    If (zAreaRules(1, lOX, lOY, lOZ) = "1") Then
        lTargetID = lPlayerFightingMobID(zPortID)
        If (Len(zTargetName) >= cstMinAttackMobLen Or lTargetID <> 0) Then
            If (lStunDuration = 0) Then
                If (lBlindDuration = 0) Then
                    If (lStatus <> 15) Then 'is player resting?
                        If (lStatus <> 20) Then 'is player sitting?
                            If (lStatus <> 50) Then 'is player asleep?
                                lPortID = MyCLng(zPortID)
                                subAddPortIDsCyborgVentingSystem lPortID, 1
                                If (iCombatPlayerStatus(zPortID) = cstiStatusNotInBattleMode) Then '0=available battle cell 10=battle mode mob, 15=battlemode player
                                    basTriggerGuardsArea lOPlayerID, lOX, lOY, lOZ
                                    Select Case (lTargetID = 0)
                                        Case True
                                            Select Case (lDetectInvisibilityDuration <> 0)
                                                Case True
                                                    'player can see invis and normal mobs
                                                    zSQL = "SELECT BeconPlayerID, Flys, FlyHeight, Invisible, MobName, MobID, PlayerID, MHP, RespawnDelay FROM tblMob WHERE (MobName Like ""*" & zTargetName & "*"" AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND RespawnDelay=0);"
                                                Case False
                                                    'can only see normal mobs
                                                    zSQL = "SELECT BeconPlayerID, Flys, FlyHeight, Invisible, MobName, MobID, PlayerID, MHP, RespawnDelay FROM tblMob WHERE (MobName Like ""*" & zTargetName & "*"" AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND RespawnDelay=0 AND Invisible=0);"
                                            End Select
                                        Case False
                                            Select Case (lDetectInvisibilityDuration <> 0)
                                                Case True
                                                    'player can see invis and normal mobs
                                                    zSQL = "SELECT BeconPlayerID, Flys, FlyHeight, Invisible, MobName, MobID, PlayerID, MHP, RespawnDelay FROM tblMob WHERE (MobID=" & lTargetID & " AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND RespawnDelay=0);"
                                                Case False
                                                    'can only see normal mobs
                                                    zSQL = "SELECT BeconPlayerID, Flys, FlyHeight, Invisible, MobName, MobID, PlayerID, MHP, RespawnDelay FROM tblMob WHERE (MobID=" & lTargetID & " AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND RespawnDelay=0 AND Invisible=0);"
                                            End Select
                                    End Select
                                    'Trisker: make mob use the 1. 2. 3. select ability with kill
                                    Set rsMob = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                    If (Not rsMob.EOF) Then
                                        zMobName = MyCStr(rsMob!MobName)
                                        
                                        subCheckMobnameMimic zMobName, zPortID
                                        subCheckMobnameGhost zMobName, zPortID 'we want the ORIGNAL WHOLE name, geist ghost wraith spect phantom banshe
                                        zMobName = zShortstop(zMobName) 'we trim the mobname now
                                        zMobName = zAdverb(zMobName, 1) & zMobName
                                        
                                        lBeconPlayerID = MyCLng(rsMob!BeconPlayerID)
                                        
                                        'we have flying height on mobs
                                        lFlyHeight = MyCLng(rsMob!FlyHeight)
                                        'If (lFlyDuration > 0 Or lFlyHeight < 30) Then
                                        '    bReach = True
                                        'Else
                                        '    bReach = False
                                        'End If
                                        
                                        bReach = (zRace = "PIX") Or (lFlyDuration > 0 Or lFlyHeight < 10 Or bCasting Or bPlayerMountedOnFlyingPet(lOPlayerID))
                                        If (Not bReach) Then 'we add in the weapons length and see what happens
                                            sTotalReach = sPlayerReach(lOPlayerID)
                                            bReach = (sTotalReach >= lFlyHeight)
                                        End If
                                        
                                        If (bReach) Then
                                            lMobID = MyCLng(rsMob!MobID)
                                            bInvisible = (MyCInt(rsMob!Invisible) <> 0 And lDetectInvisibilityDuration = 0)
                                            If (Not bInvisible) Then
                                                If (MyCLng(rsMob!RespawnDelay) = 0) Then
                                                    bReturn = True 'we are attacking
                                                    'we load the attack variables
                                                    If (bMobInBattle(lMobID)) Then
                                                        rSCombat(lPortID).iStatus = cstiStatusPlayerIgnoredVsMob
                                                    Else
                                                        rSCombat(lPortID).iStatus = cstiStatusPlayerVsMob
                                                    End If
                                                    
                                                    rMCombat(lPortID).Name = zMobName
                                                    rMCombat(lPortID).lID = lMobID
                                                    
                                                    rPCombat(lPortID).Name = zOPlayerName
                                                    rPCombat(lPortID).lID = lOPlayerID
                                                    
                                                    'Everyone that is following this player and is grouped attacks too
                                                    If (lFPlayerGroupStatus = 1) Then 'Am I the leader?
                                                        Set rsFollow = MyDB.OpenRecordset("SELECT FPlayerGroupStatus, PlayerName, PortID, PlayerID FROM tblPlayer WHERE (FPlayerGroupStatus=3 AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND FPlayerID=" & lOPlayerID & " AND BlindDuration=0 AND StunDuration=0 AND EntanglementDuration=0 AND Status=5 AND PortID<>'" & zPortID & "');", dbOpenSnapshot) 'FPlayerGroupStatus 1 is leader, FPlayerGroupStatus 3 is grouped follower
                                                        Do While (Not rsFollow.EOF)
                                                            lFollowPortID = MyCLng(rsFollow!PortID)
                                                            If (rSCombat(lFollowPortID).iStatus = cstiStatusNotInBattleMode) Then
    
                                                                rMCombat(lFollowPortID).Name = zMobName
                                                                rMCombat(lFollowPortID).lID = lMobID
                                                                
                                                                rPCombat(lFollowPortID).Name = MyCLng(rsFollow!PlayerName)
                                                                rPCombat(lFollowPortID).lID = MyCLng(rsFollow!PlayerID)
                                                                If (bMobInBattle(lMobID)) Then
                                                                    rSCombat(lFollowPortID).iStatus = cstiStatusPlayerIgnoredVsMob
                                                                Else
                                                                    rSCombat(lFollowPortID).iStatus = cstiStatusPlayerVsMob
                                                                End If
                                                                subSendMsg "&g[group] You help to defend the group from " & zMobName & "!!", MyCStr(lFollowPortID)
                                                                subSendMsgAreaExcept2 "&g[group] " & MyCStr(rsFollow!PlayerName) & " WARCRY n Attacks " & zMobName & "!!", lOX, lOY, lOZ, MyCStr(lFollowPortID), ""
                                                            End If
                                                            rsFollow.MoveNext
                                                        Loop
                                                        Set rsFollow = Nothing
                                                    End If
                                                    
                                                    'Mobs are linked to protect other mobs - all the link does is allows other mobs to engage in battle against the player.
                                                    Set rsProtectedMob = MyDB.OpenRecordset("SELECT MobID FROM tblMobProtected WHERE (((tblMobProtected.ProtectedMobID)=" & MyCLng(rsMob!MobID) & "));", dbOpenSnapshot)
                                                    If (Not rsProtectedMob.EOF) Then
                                                        subSendMsg "&W" & zMobName & " screams loudly for help!" & vbCrLf & "&RYou feel as if you may of caused more trouble than it was worth!", zPortID
                                                        Do While (Not rsProtectedMob.EOF)
                                                            MyDB.Execute "UPDATE tblMob SET PlayerID = " & lOPlayerID & " WHERE (RespawnDelay=0 AND MobID=" & MyCLng(rsProtectedMob!MobID) & ");", dbFailOnError 'we now include another mobile into the battle.
                                                            rsProtectedMob.MoveNext
                                                        Loop
                                                    End If
                                                    Set rsProtectedMob = Nothing
                                                    
                                                    If (lBeconPlayerID <> 0) Then
                                                        MyDB.Execute "UPDATE tblMob SET PlayerID = " & lOPlayerID & " WHERE (RespawnDelay=0 AND MobID=" & MyCLng(rsMob!MobID) & ");", dbFailOnError 'the mob remember who attacked them and retains the beconned person the mob is verbally distracting already
                                                    Else
                                                        MyDB.Execute "UPDATE tblMob SET BeconPlayerID=" & lOPlayerID & ", PlayerID = " & lOPlayerID & " WHERE (RespawnDelay=0 AND MobID=" & MyCLng(rsMob!MobID) & ");", dbFailOnError 'the mob remember who attacked them, becon the attacker
                                                    End If
                                                    'subSendMsg "&R<<WARCRY n Attack " & zMobName & ">>", zPortID
                                                    'subSendMsgAreaExcept2 "&R<<" & zOPlayerName & " WARCRY n Attacks " & zMobName & ">>", lOX, lOY, lOZ, zPortID, ""
                                                Else
                                                    If (bShowErrorMsg) Then subSendMsg "&gThat is not here to kill.", zPortID
                                                End If
                                            Else
                                                If (bShowErrorMsg) Then subSendMsg "&gThat is not here to kill.", zPortID
                                            End If
                                        Else
                                            subSendMsgAreaAllDISmart "&y", zOPlayerName, "&g*Out of Reach* &mYou look up " & Format((lFlyHeight / glblCentimetreToFeetConverter), "FIXED") & "feet at " & zMobName, "", "&g*Out of Reach* &m%s1 looks up " & Format((lFlyHeight / glblCentimetreToFeetConverter), "FIXED") & "feet at " & zMobName, lOX, lOY, lOZ
                                        End If
                                    Else
                                        If (bShowErrorMsg) Then subSendMsg "&gThat is not here to kill.", zPortID
                                    End If
                                    Set rsMob = Nothing
                                Else
                                    If (bShowErrorMsg) Then subSendMsg "&rYou are fighting as hard as you can!", zPortID
                                End If
                            Else
                                If (bShowErrorMsg) Then subSendMsg "&GYou dream of great battles and valour.", zPortID
                            End If
                        Else
                            If (bShowErrorMsg) Then subSendMsg "&GYou sit and think about great battles and valour.", zPortID
                        End If
                    Else
                        If (bShowErrorMsg) Then subSendMsg "&GYou rest and think about great battles and valour.", zPortID
                    End If
                Else
                    If (bShowErrorMsg) Then subSendMsg "&RYou are blind and cannot see to initiate an attack.", zPortID
                End If
            Else
                If (bShowErrorMsg) Then subSendMsg "&RYou are stunned and cannot see to initiate an attack.", zPortID
            End If
        Else
            If (bShowErrorMsg) Then subSendMsg "&gYour target name must be at least " & cstMinAttackMobLen & " characters in length.", zPortID
        End If
    Else
        subSendMsg "&BA magical barrier prevents you from attacking.", zPortID
    End If
    bPlayerVsMobCombatSetUp = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPlayerVsMobCombatSetUp," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subCheckMobnameGhost(zMobName As String, zReturnPortID As String)
On Error GoTo Err_Check
    'geist ghost wraith spect phantom banshe
    Dim rsPlayer As Recordset
    Dim zSearch As String
    Dim bOkay As Boolean
    
    If (lRandom(3) = 1) Then
    zSearch = UCase(zMobName)
    bOkay = (InStr(zSearch, "MIMIC") Or InStr(zSearch, "GEIST") Or InStr(zSearch, "GHOST") Or InStr(zSearch, "WRAITH") Or InStr(zSearch, "SPECT") Or InStr(zSearch, "PHANTOM") Or InStr(zSearch, "BANSHE"))
    If (bOkay) Then
        If (gbllServerGhostPlayerID = 0 And lRandom(3) = 1) Then
            Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName,PortID,PlayerID,X,Y,Z FROM tblPlayer WHERE ([PortID]='" & zReturnPortID & "');", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                gblzServerGhostPortID = MyCStr(rsPlayer!PortID)
                gbllServerGhostPlayerID = MyCLng(rsPlayer!PlayerID)
                gblzServerGhostPlayerName = MyCStr(rsPlayer!PlayerName)
                gbllServerGhostX = MyCLng(rsPlayer!x)
                gbllServerGhostY = MyCLng(rsPlayer!y)
                gbllServerGhostZ = MyCLng(rsPlayer!z)
                gbllServerGhostAX = gbllServerGhostX
                gbllServerGhostAY = gbllServerGhostY
                gbllServerGhostAZ = gbllServerGhostZ
                
                If (gbllServerCemeteryLocDX1 <= gbllServerGhostAX And gbllServerCemeteryLocDX2 >= gbllServerGhostAX) And (gbllServerCemeteryLocDY1 <= gbllServerGhostAY And gbllServerCemeteryLocDY2 >= gbllServerGhostAY) Then
                    gblbRealmGhostCemetaryAwake = (gbllServerGhostAZ > -5 And gbllServerGhostAZ < 5)
                    If (gblbRealmGhostCemetaryAwake) Then
                        subSendMsg "&BYou have woken " & gblzAsciiPoltergeist & " &WR&aealm &WG&ahost&B!", gblzServerGhostPortID
                        subSendMsgInfoChannel "&W" & gblzServerGhostPlayerName & " &ahas unfortunately ventured into the Cemetary!"
                    End If
                Else
                    subSendMsg "&BThe " & gblzAsciiRealmGhost & "&B knows of your existance!", gblzServerGhostPortID
                End If
                
                subSendMsgAreaAll "&GS&atrange &GG&aoo is showing up on the &gwalls &aaround you.", gbllServerGhostX, gbllServerGhostY, gbllServerGhostZ 'this message must go here unchanged
                'randomly place the Ghost of DEATH nearby the player
                gbllServerGhostX = gbllServerGhostX - (lRandom(8) - 1)
                gbllServerGhostX = gbllServerGhostX + (lRandom(8) - 1)
                gbllServerGhostY = gbllServerGhostY - (lRandom(8) - 1)
                gbllServerGhostY = gbllServerGhostY + (lRandom(8) - 1)
                gbllServerGhostZ = gbllServerGhostZ - (lRandom(8) - 1)
                gbllServerGhostZ = gbllServerGhostZ + (lRandom(8) - 1)
            End If
            Set rsPlayer = Nothing
        End If
    End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckMobnameGhost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCheckMobnameMimic(zPassMobName As String, zReturnPortID As String)
On Error GoTo Err_Check
    Dim lPortID As Long
    Dim zMobName As String
    lPortID = MyCLng(zReturnPortID)
    If (gbllMimicLevel(lPortID) > 0) Then
        zMobName = UCase(zPassMobName)
        If (InStr(zMobName, "POSER") <> 0 Or InStr(zMobName, "MIMIC") <> 0 Or lRandom((300 / gbllMimicLevel(lPortID)) + 10) = 1) Then
            If (lRandom(3) = 1) Then
                gbllMimicLevel(lPortID) = gbllMimicLevel(lPortID) + 1
                If (gbllMimicLevel(lPortID) > 30) Then gbllMimicLevel(lPortID) = 30 'the mimic mob begins to form against the botter
                subSendMsg "&mThe &RM&ri&RM&ri&RC&m growls at you!", zReturnPortID
            End If
            MyDB.Execute "UPDATE tblPlayer SET CleaveDuration=12, PlayerFleeDuration=2, CHP=[CHP]/8 WHERE ([PortID]='" & zReturnPortID & "');", dbFailOnError
            subSendMsg "&RCLEAVED&r! &mby a &RM&ri&RM&ri&RC&r!", zReturnPortID
        End If
    End If
    Exit Sub
Err_Check:
   subWriteErrorFile "subCheckMobnameMimic," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoadPlayerOwnsStarshipDetails(lPortID As Long, lPlayerID As Long)
On Error GoTo Err_Check
'If a person is Never Banned that means they can get past a ban marked in the tblPlayerRemoteHostIP with the Banned Flag true
'that only a Complete Ban tblPlayerRemoteHostCompleteBan will keep them out or taking them off the never ban list
    Dim rsPlayer As Recordset
    Dim bReturn As Boolean
    
    gblbStarshipTested(lPortID) = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT X,Y,Z,PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bReturn = True
        gblbStarshipTested(lPortID) = True
        gblStarshipX(lPortID) = MyCLng(rsPlayer!x)
        gblStarshipY(lPortID) = MyCLng(rsPlayer!y)
        gblStarshipZ(lPortID) = MyCLng(rsPlayer!z)
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoadPlayerOwnsStarshipDetails," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bReturnPlayerNeverBanned(zPlayerName As String) As Boolean
On Error GoTo Err_Check
'If a person is Never Banned that means they can get past a ban marked in the tblPlayerRemoteHostIP with the Banned Flag true
'that only a Complete Ban tblPlayerRemoteHostCompleteBan will keep them out or taking them off the never ban list
    Dim rsPlayer As Recordset
    Dim bReturn As Boolean
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT tblPlayerNeverBan.PlayerID FROM tblPlayerNeverBan INNER JOIN tblPlayer ON tblPlayerNeverBan.PlayerID = tblPlayer.PlayerID WHERE (((tblPlayer.PlayerName)='" & zPlayerName & "'));", dbOpenSnapshot)
    bReturn = (Not rsPlayer.EOF)
    Set rsPlayer = Nothing
    
    bReturnPlayerNeverBanned = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bReturnPlayerNeverBanned," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnOnlineRemoteHostID(lPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zReturn As String
    zReturn = ""
    Set rsPlayer = MyDB.OpenRecordset("SELECT tblPlayer.PlayerID, tblPlayerLoggedIn.RemoteHostID FROM tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PortID = tblPlayerLoggedIn.PortID WHERE (((tblPlayer.PlayerID)=" & lPlayerID & "));", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zReturn = MyCStr(rsPlayer!RemoteHostID)
    End If
    Set rsPlayer = Nothing
    
    zReturnOnlineRemoteHostID = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnOnlineRemoteHostID," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subPlayerVsPlayerCombatSetUpLoad(zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zRace As String
    Dim zGender As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCCHA As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lTurnedIntoAnimalType As Long
    Dim lStatus As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, Gender,Race,X,Y,Z,PlayerName,PlayerLevel,CCHA,Status,DetectInvisibilityDuration,TurnedIntoAnimalType FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zRace = MyCStr(rsPlayer!Race)
        zGender = MyCStr(rsPlayer!Gender)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        lStatus = MyCLng(rsPlayer!Status)
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        If (Len(zWord2) > 0) Then
            subPlayerVsPlayerCombatSetUp lCCHA, lDetectInvisibilityDuration, zPortID, zWord2, lX, lY, lZ, lPlayerID, zPlayerName, zGender, True, zRace, lStatus, lPlayerLevel, lTurnedIntoAnimalType
        Else
            subSendMsg "&GCOMMAND: MURDER (player name)", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subPlayerVsPlayerCombatSetUpLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerVsPlayerCombatSetUpLoad," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerVsPlayerCombatSetUp(lCHA As Long, lDetectInvisibilityDuration As Long, zPortID As String, zTargetName As String, lOX As Long, lOY As Long, lOZ As Long, lOPlayerID As Long, zOPlayerName As String, zOGender As String, bShowErrorMsg As Boolean, zRace As String, lStatus As Long, lPlayerLevel As Long, lTurnedIntoAnimalType As Long)
On Error GoTo Err_Check
'Here we mark the mob with the atacking player.
'When there is battle the system looks at the right hand and determines if the object there can be dual wielded if it can it can be used in the battle and there is a dual wield emote for it
    Dim rsPlayer As Recordset
    Dim zClass As String
    Dim zPlayerName As String
    Dim rsProtectedPlayer As Recordset
    Dim bInvisible As Boolean
    Dim lPortID As Integer
    Dim bLoseAlignment As Boolean
    
    bLoseAlignment = False
    If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then 'the morphed bull can fight
        If (lStatus <> 15) Then 'is player resting?
            If (lStatus <> 20) Then 'is player sitting?
                If (lStatus <> 50) Then 'is player asleep?
                    If (Len(zTargetName) > 0) Then
                        lPortID = MyCLng(zPortID)
                        If (iCombatPlayerStatus(zPortID) = cstiStatusNotInBattleMode) Then '0=available battle cell 10=battle mode Player, 15=battlemode player
                            Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerFleeDuration, PortID, InvisibilityDuration, Race, Class, PlayerName, PlayerID, CHP, PlayerLevel FROM tblPlayer WHERE (PlayerName Like ""*" & zTargetName & "*"" AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND CHP>0 AND Len([PortID])>1);", dbOpenSnapshot)
                            If (Not rsPlayer.EOF) Then
                                zClass = MyCStr(rsPlayer!Class)
                                zPlayerName = zShortstop(MyCStr(rsPlayer!PlayerName))
                                zPlayerName = zAdverb(zPlayerName, 1) & zPlayerName
                            
                                If (zClass = "IO") Or (Not bPlayerIgnoredCommand(zOPlayerName, MyCLng(rsPlayer!PortID))) Then
                                    If (zClass = "IO") Or ((MyCLng(rsPlayer!PlayerFleeDuration) <> 0 Or gblbArenaOnOff = 1 Or bAreaGloryChallengeZone(lOX, lOY, lOZ) Or gbllMoon = 5 Or gbllMoon = -5)) Then 'attackign a witchlocke or we also allow it so they can fight during a eclipse or skull moon
                                        If (zClass = "IO") Or ((MyCLng(rsPlayer!PlayerFleeDuration) <> 0 Or zAreaRules(1, lOX, lOY, lOZ) = "1")) Then
                                            If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                                                If (rSCombat(MyCLng(rsPlayer!PortID)).iStatus = cstiStatusNotInBattleMode) Then
                                                    If ((MyCLng(rsPlayer!PlayerFleeDuration) <> 0) Or (lPlayerLevel / 4 < MyCLng(rsPlayer!PlayerLevel))) Then
                                                        bInvisible = (MyCInt(rsPlayer!InvisibilityDuration) > 0 And lDetectInvisibilityDuration = 0)
                                                        If (Not bInvisible) Then
                                                            'the attacker aims at player
                                                            rSCombat(lPortID).iStatus = cstiStatusPlayerVsPlayer
                                                            rPCombat(lPortID).Name = MyCStr(rsPlayer!PlayerName) 'this is the target information for this attacker
                                                            rPCombat(lPortID).lID = MyCLng(rsPlayer!PlayerID) 'This port is attacking this person ID
                                                            
                                                            'the defender remember who attacked them
                                                            rSCombat(MyCLng(rsPlayer!PortID)).iStatus = cstiStatusPlayerVsPlayer
                                                            rPCombat(MyCLng(rsPlayer!PortID)).Name = zOPlayerName 'this is the target information for this defender
                                                            rPCombat(MyCLng(rsPlayer!PortID)).lID = lOPlayerID 'This port is attacking this person ID
                                                            
                                                            subSendMsg "&RYou throw yourself against " & zPlayerName & ".", zPortID
                                                            subSendMsg "&R" & zOPlayerName & " attacks you!", MyCStr(rsPlayer!PortID)
                                                            subSendMsgAreaExcept2 "&R" & zOPlayerName & " throws " & zTranslateGender(zOGender, 40) & " against " & zPlayerName & ".", lOX, lOY, lOZ, zPortID, MyCStr(rsPlayer!PortID)
                                                            'NOTE: We dont throw grouped members into the battle I never did like that feature of other muds. If you want to put it here.
                                                            bLoseAlignment = (zRace <> "UND") 'undeadians cannot have alignment changes
                                                        Else
                                                            subSendMsg "&gThat person is not here to kill.", zPortID
                                                        End If
                                                    Else
                                                        subSendMsg "&rThat target is not worthy of your time.", zPortID
                                                    End If
                                                Else
                                                    subSendMsg gblzFNYEL & MyCStr(rsPlayer!PlayerName) & " is too busy to fight you right now.", zPortID
                                                End If
                                            Else
                                                subSendMsg "&yYou are too busy to do that right now.", zPortID
                                            End If
                                        Else
                                            If (bShowErrorMsg) Then subSendMsg "&gThat is not here to kill.", zPortID
                                        End If
                                        Set rsPlayer = Nothing
                                    Else
                                        subSendMsg "&RYou cannot attack a player here or the moons are not aligned properly.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RSorry this person will have nothing to do with you anymore.", zPortID
                                End If
                            Else
                                subSendMsg "&RMurder who?" & vbCrLf & gblzFNBLU & "NOTE: You MAY have to ask an immortal to turn on the arena" & vbCrLf & "or choose to fight at the glory challenge area" & vbCrLf & "if you are not already standing there.", zPortID
                            End If
                        Else
                            If (bShowErrorMsg) Then subSendMsg "&rYou are fighting as hard as you can!", zPortID
                        End If
                    Else
                        subSendMsg "&gThat Player is not here to kill.", zPortID
                    End If
                Else
                    subSendMsg "&GYou dream of an evil plan of murder and conquest.", zPortID
                End If
            Else
                subSendMsg "&GYou sit and scheme a plan of murder and conquest.", zPortID
            End If
        Else
            subSendMsg "&GYou rest and scheme a plan of murder and conquest.", zPortID
        End If
        
        If (bLoseAlignment) Then  'This will make a player evil for comitting the offense
            If (lRandom(lCHA) < lRandom(10)) Then
                If (lCHA > 100) Then lCHA = 100
                subSendMsg "&gYou loose some alignment for your actions!", zPortID
                MyDB.Execute "UPDATE tblPlayer SET Alignment = [Alignment]-" & lRandom(100) + 100 & " WHERE (PlayerID=" & lOPlayerID & " AND Alignment>-1000);", dbFailOnError
                MyDB.Execute "UPDATE tblPlayer SET Alignment = -1000 WHERE (PlayerID=" & lOPlayerID & " AND Alignment < -1000);", dbFailOnError
            End If
        End If
    Else
        subSendMsg "&MYou are only a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ", you cannot do that!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerVsPlayerCombatSetUp," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBreakEntangle(zPortID As String)
On Error GoTo Err_Check
    'subBreakEntangle zPortID 'If (lEntanglementDuration = 0 Or (zClass = "GL" Or zClass = "WA" Or zClass = "PL" Or zClass = "KN")) Then
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zClass As String
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCMove As Long
    Dim zGender As String
    Dim zGenderVerbose As String
    Dim lEntanglementDuration As Long
    Dim zEntanglementDesc As String
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Class, EntanglementDesc, EntanglementDuration, CMove, Gender, Status, X, Y, Z, PlayerName, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lCMove = MyCLng(rsPlayer!CMove)
        zClass = MyCStr(rsPlayer!Class)
        zGender = MyCStr(rsPlayer!Gender)
        zGenderVerbose = LCase(zTranslateGender(zGender, 2))
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        zEntanglementDesc = LCase(MyCStr(rsPlayer!EntanglementDesc))
    End If
    Set rsPlayer = Nothing
    
    If (lEntanglementDuration > 0) Then
        Select Case zClass
            Case "GY", "WA", "KN", "PA", "AS", "PL", "BA"
                If (lCMove > 1999) Then
                    MyDB.Execute "UPDATE tblPlayer SET EntanglementDesc='', EntanglementDuration=0, CMOVE=CMOVE/2 WHERE PlayerID=" & lPlayerID & ";", dbFailOnError
                    subSendMsgAreaAllDISmart "&y", zPlayerName, "You break free of the " & zEntanglementDesc & " and your muscles are now sore!", "", "%s1 breaks free of the " & zEntanglementDesc & ".", lX, lY, lZ
                Else
                    subSendMsg "&gYou are too weak to break the entanglement! (2000 moves required)", zPortID
                End If
            Case Else
                subSendMsg "&gHuh?", zPortID
        End Select
    Else
        subSendMsg "&g...but, you are not entangled in web/netting my friend.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subBreakEntangle," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatAttack(zPortID As String, zTargetName As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim bPlayerFound As Boolean
    Dim zPlayerName As String
    Dim lPlayerLevel As Long
    Dim lPlayerID As Long
    Dim lNeverAttackable As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lFPlayerGroupStatus As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lStatus As Long
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim lSleepDuration As Long
    Dim zGender As String
    Dim lFlyDuration As Long
    Dim lPlayerHeight As Long
    Dim zRace As String
    Dim zClass As String
    Dim lTurnedIntoAnimalType As Long
    Dim lPortID As Long
    
    lPortID = MyCLng(zPortID)
    If (gbllFishing(lPortID) = 0) Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, TurnedIntoAnimalType, Class, Race, Height, FlyDuration, SleepDuration, PlayerFleeDuration, Gender, StunDuration, DetectInvisibilityDuration, BlindDuration, FPlayerGroupStatus, X, Y, Z, Status, PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            bPlayerFound = True
            lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
            zRace = MyCStr(rsPlayer!Race)
            zClass = MyCStr(rsPlayer!Class)
            lFlyDuration = MyCLng(rsPlayer!FlyDuration)
            If (lFlyDuration = 0) Then
                If (zRace = "PIX" Or zClass = "VA") Then
                    lFlyDuration = 1
                End If
            End If
            
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lPlayerHeight = MyCLng(rsPlayer!Height)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
            lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            lStatus = MyCLng(rsPlayer!Status)
            zGender = MyCStr(rsPlayer!Gender)
            lBlindDuration = MyCLng(rsPlayer!BlindDuration)
            lStunDuration = MyCLng(rsPlayer!StunDuration)
            lSleepDuration = MyCLng(rsPlayer!SleepDuration)
            lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        Else
            bPlayerFound = False
        End If
        Set rsPlayer = Nothing
        
        If (bPlayerFound) Then
            If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then 'the morphed bull can fight
                If (lSleepDuration = 0) Then
                    If (lPlayerFleeDuration = 0) Then
                        If (zClass = "IO") Then 'are you a witchlocke
                            If (lRandom(20) > 4) Then 'witch doesnt respond well to KILL commands
                                bPlayerVsMobCombatSetUp zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, True, False
                            Else
                                Select Case lRandom(40)
                                    Case 1
                                        subSendMsg "&g*cackle to self* NO I WANT TO RAISE THE DEAD!", zPortID
                                    Case 2
                                        subSendMsg "&g*cackle to self* NO I WANT TO CAST ANY SPELL INSTEAD!", zPortID
                                    Case 3
                                        subSendMsg "&g*cackle to self* JUST NOOOOOO! CHAIN THE ENEMY INSTEAD! YES YES !!", zPortID
                                    Case 4
                                        subSendMsg "&g*cackle to self* THE PETS ARE STRONG - LETS PLAY WITH THEM INSTEAD!", zPortID
                                    Case 5
                                        subSendMsg "&g*cackle to self* WHY SO - SERIOUS?!", zPortID
                                    Case Else
                                        subSendMsg "&gYour head is spinning with anger. Attack again!", zPortID
                                End Select
                            End If
                        Else 'attack normally when not a witch
                            If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'lPortID = MyCLng(zPortID)
                                If (gbllAngryVentingSystem(lPortID) > -1 And gbllAngryVentingSystem(lPortID) < lRandom(25) + 75) Then 'the random makes it rought riding
                                    gbllAttackLevel(lPortID) = gbllAttackLevel(lPortID) + 1
                                    If (gbllAttackLevel(lPortID) < lRaceClassAttackLevelMAX(zRace, zClass)) Then
                                        bPlayerVsMobCombatSetUp zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, True, False
                                    Else
                                        subSendMsg "&rYour body needs a break!", zPortID
                                        If (lPlayerLevel < 11) Then subSendMsg zReturnPlayerLevelAscii(11) & "&GH&gINT: This MUD is about forging not leveling:" & vbCrLf & "Go slow and find crowns of glory everywhere!" & vbCrLf & "This MUD will play with you, give you quests, and the Oracle has crowns too!" & vbCrLf & "&GOnce triggered, the above warning message disappears" & vbCrLf & "in about thirty seconds, when not disturbed with another attack.", zPortID
                                    End If
                                Else
                                    subSendMsg "&YHeating System requires venting...(skipping command)", zPortID
                                End If
                            End If
                        End If
                        If (lRandom(10) = 1) Then subDamageTheArea zPortID 'attacking mobs cause damage to the area
                    Else
                        subSendMsg "&RYou are too scared to attack anything!", zPortID
                    End If
                Else
                    subSendMsg "&RYou are too sleepy to attack anything!", zPortID
                End If
            Else
                subSendMsg "&MYou are only a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ", you cannot do that!", zPortID
            End If
        Else
            subSendMsg "&RsubCombatAttack: ERROR Player File not found report this to an immortal!", zPortID
        End If
    Else
        subSendMsg "&gBut wait, you are fishing. Stand or move away first.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatAttack," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subEnsnare(zPortID As String, zTargetName As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim rsPlayerWeapons As Recordset
    Dim bSuccess As Boolean
    Dim zMobName As String
    Dim lGetTranslateSkillStunCost As Long
    Dim lTargetID As Long
    Dim zSQL As String
    Dim lStunInterruptionByClass As Long
    Dim zTPlayerName As String
    
    Dim rsPlayer As Recordset
    Dim bPlayerFound As Boolean
    
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCDEX As Long
    Dim lCStr As Long
    Dim lCCon As Long
    Dim lCSoul As Long
    Dim lSoulCost As Long
    Dim zClass As String
    Dim zRace As String
    Dim lShadowCloakDuration As Long
    Dim lStunInterruption As Long
    Dim lFPlayerGroupStatus As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lStatus As Long
    Dim bInterrupted As Boolean
    Dim zDPortID As String
    Dim lIASChance As Long
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim zGender As String
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim bMobVisible As Boolean
    Dim lFlyDuration As Long
    Dim lPlayerHeight As Long
    Dim zPlayerWeapon(1 To 2) As String
    Dim zPlayerWeaponType(1 To 2) As String
    Dim lWeaponTypeCellNet As Long
    Dim lCount As Long
    Dim lPlayerWeaponCount As Long
    Dim lEntanglementDuration As Long
    Dim zEntanglementDesc As String
    Dim zEntanglementDescHitMsg As String
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Race, IASChance, EntanglementDuration, EntanglementDesc, ShadowCloakDuration, Height, FlyDuration, SleepDuration, PlayerFleeDuration, Gender, Class, CSoul, StunDuration, DetectInvisibilityDuration, BlindDuration, StunInterruption, CDex, CStr, CCon, FPlayerGroupStatus, X, Y, Z, Status, PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        lIASChance = MyCLng(rsPlayer!IASChance)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        zEntanglementDesc = MyCStr(rsPlayer!EntanglementDesc)
        lShadowCloakDuration = MyCLng(rsPlayer!ShadowCloakDuration)
        lFlyDuration = MyCLng(rsPlayer!FlyDuration)
        lPlayerHeight = MyCLng(rsPlayer!Height)
        lStatus = MyCLng(rsPlayer!Status)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCStr = MyCLng(rsPlayer!CStr)
        lCCon = MyCLng(rsPlayer!CCon)
        lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        zClass = MyCStr(rsPlayer!Class)
        zRace = MyCStr(rsPlayer!Race)
        zGender = MyCStr(rsPlayer!Gender)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lStunInterruption = MyCLng(rsPlayer!StunInterruption)
    Else
        bPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    lPlayerWeaponCount = 0: lWeaponTypeCellNet = 0: zEntanglementDescHitMsg = ""
    'get what the player weapons are
    Set rsPlayerWeapons = MyDB.OpenRecordset("SELECT tblPlayerEquipmentItems.PlayerID, tblPlayerEquipmentItems.Location, tblObject.ObjectName, tblObject.WeaponType, tblObject.CriticalHR, tblObject.CriticalHRChance, tblObject.CriticalDR, tblObject.CriticalDRChance, tblObject.CriticalBlindChance, tblObject.IndestructibleMobLv FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerEquipmentItems.Location)=20) AND ((tblObject.WeaponType)<>'' And (tblObject.WeaponType) Is Not Null));", dbOpenSnapshot) 'destiny weapons and weapontype weapons count as weapons only - this way a player can forcus on a weapon and hold a shield
    Do While (Not rsPlayerWeapons.EOF And lPlayerWeaponCount < 2)
        lPlayerWeaponCount = lPlayerWeaponCount + 1
        If (lShadowCloakDuration <> 0) Then
            Select Case lRandom(5)
                Case 1
                    zPlayerWeapon(lPlayerWeaponCount) = "++cloaked weapon of shadows++"
                Case 2
                    zPlayerWeapon(lPlayerWeaponCount) = "++flowing shadow weapon++"
                Case 3
                    zPlayerWeapon(lPlayerWeaponCount) = "++concealed weapon wrapped in shadows++"
                Case 4
                    zPlayerWeapon(lPlayerWeaponCount) = "++darkforce of shadows++"
                Case 5
                    zPlayerWeapon(lPlayerWeaponCount) = "++power of shadows++"
            End Select
        Else
            zPlayerWeapon(lPlayerWeaponCount) = zShortstop(MyCStr(rsPlayerWeapons!ObjectName))
        End If
        zPlayerWeaponType(lPlayerWeaponCount) = MyCStr(rsPlayerWeapons!WeaponType)
        If (zPlayerWeaponType(lPlayerWeaponCount) = "NET") Then lWeaponTypeCellNet = lPlayerWeaponCount
        rsPlayerWeapons.MoveNext
    Loop
    Set rsPlayerWeapons = Nothing
    
    If (bPlayerFound) Then
        If (lStatus <> 50) Then 'is player asleep?
            If (zAreaRules(1, lX, lY, lZ) = "1") Then
                If (lSleepDuration = 0) Then
                    If (lEntanglementDuration = 0) Then
                        If (lWeaponTypeCellNet > 0) Then 'we found a net
                            zEntanglementDescHitMsg = zPlayerWeapon(lWeaponTypeCellNet)
                            If (lPlayerFleeDuration = 0) Then
                                If (lBlindDuration = 0) Then
                                    If (lStunDuration = 0) Then
                                        If (lStatus = 5 Or lStatus = 0) Then
                                            If (lStunInterruption = 0) Then
                                                bInterrupted = False
                                                lGetTranslateSkillStunCost = lTranslateSkillEnsnareCost(zClass)
                                                lSoulCost = cstlEnsnareSoulCost * lGetTranslateSkillStunCost
                                                bSuccess = False
                                                If (lCSoul >= lSoulCost) Then 'Attacker uses essence in the stun attack
                                                    lTargetID = lPlayerFightingMobID(zPortID)
                                                    If (Len(zTargetName) >= cstMinAttackMobLen Or lTargetID <> 0) Then
                                                        If (bPlayerVsMobCombatSetUp(zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, False, False)) Then
                                                            'Check for mob in area
                                                            Select Case (lTargetID = 0)
                                                                Case True
                                                                    zSQL = "SELECT EntanglementDuration, EntanglementDesc, Invisible, MobID, StunLevel, PlayerID, MobLevel, MobName, StunRandom, StunDuration, StunExtraDodge, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobName Like ""*" & zTargetName & "*"") AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0);"
                                                                Case False
                                                                    zSQL = "SELECT EntanglementDuration, EntanglementDesc, Invisible, MobID, StunLevel, PlayerID, MobLevel, MobName, StunRandom, StunDuration, StunExtraDodge, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobID=" & lTargetID & ") AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0);"
                                                            End Select
                                                            bMobVisible = False
                                                            Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                                            If (Not rsData.EOF) Then
                                                                bMobVisible = (lDetectInvisibilityDuration <> 0) Or (MyCInt(rsData!Invisible) = 0)
                                                                lTargetID = MyCLng(rsData!MobID)
                                                                zMobName = MyCStr(rsData!MobName)
                                                                zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
                                                                If (bMobVisible) Then
                                                                    If (lPlayerLevel >= MyCLng(rsData!StunLevel)) Then
                                                                        If (MyCLng(rsData!RespawnDelay) = 0) Then
                                                                            If (MyCLng(rsData!EntanglementDuration) = 0) Then
                                                                                bSuccess = True
                                                                                If (lRandom(MyCLng(lPlayerLevel / 3)) + (lRandom(lCDEX) * 2) > lRandom(MyCLng(rsData!MobLevel)) + MyCLng(rsData!StunExtraDodge) + lRandom(MyCLng(rsData!StunRandom))) Then  'mobs that have stun can dodge stuns easier
                                                                                    MyDB.Execute "UPDATE tblMob SET EntanglementDuration=" & lRandom(4) & ", EntanglementDesc='" & zEntanglementDescHitMsg & "', PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 net [" & zPlayerWeapon(lWeaponTypeCellNet) & "] " & zMobName & ".", "", "%s1 nets [" & zPlayerWeapon(lWeaponTypeCellNet) & "] " & zMobName & ".", lX, lY, lZ
                                                                                    'subSendMsg "&GYou&R SLAM&G into and stun " & zMobName & ".", zPortID
                                                                                    'subSendMsgAreaExcept2 gblzFBWHI & zOPlayerName & "&R SLAMS&G into and stuns " & zMobName & ".", lOX, lOY, lOZ, zPortID, ""
                                                                                Else
                                                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 failed to net [" & zPlayerWeapon(lWeaponTypeCellNet) & "] " & zMobName & ".", "", "%s1 failed to net [" & zPlayerWeapon(lWeaponTypeCellNet) & "] " & zMobName & ".", lX, lY, lZ
                                                                                    'subSendMsg "&yYou run past " & zMobName & " as you try to stun.", zPortID
                                                                                    'subSendMsgAreaExcept2 gblzFNYEL & zOPlayerName & " runs past " & zMobName & " as if trying to stun.", lOX, lOY, lOZ, zPortID, ""
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&G" & zMobName & " is already netted!", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg gblzFNGRE & zShortstop(MyCStr(rsData!MobName)) & " is not here.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&gYou have to be level " & MyCLng(rsData!StunLevel) & " to net " & zMobName & ".", zPortID
                                                                    End If
                                                                Else
                                                                    subSendMsg "&gEnsnare Who?", zPortID
                                                                End If
                                                            End If
                                                            Set rsData = Nothing
                                                        End If
    
                                                        'Check for player in area
                                                        If (Not bSuccess) Then 'Mob not found try to find player
                                                            Set rsData = MyDB.OpenRecordset("SELECT EntanglementDuration, EntanglementDesc, PlayerID, InvisibilityDuration, CamoflaguedDuration, HideDuration, SneakingMovesLeft, CHP, PlayerLevel, CDEX, PlayerName, StunDuration, X, Y, Z, PortID, Class FROM tblPlayer WHERE (PlayerName Like """ & zKeepLettersOnly(zTargetName) & "*"") AND (PortID<>'" & zPortID & "' And Len([PortID])>1) AND (PlayerID<>" & lPlayerID & " AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
                                                            If (Not rsData.EOF) Then
                                                                zDPortID = MyCStr(rsData!PortID)
                                                                lTargetID = MyCLng(rsData!PlayerID)
                                                                zTPlayerName = MyCStr(rsData!PlayerName)
                                                                If (MyCLng(rsData!PlayerLevel) >= cstNewbieSafeLevel) Then
                                                                    If ((MyCLng(rsData!InvisibilityDuration) = 0 And MyCLng(rsData!CamoflaguedDuration) = 0 And MyCLng(rsData!HideDuration) = 0) Or (lDetectInvisibilityDuration > 0)) Then
                                                                        If (MyCLng(rsData!EntanglementDuration) = 0) Then
                                                                            Select Case MyCStr(rsData!Class)
                                                                                Case "WA", "GL", "KN", "PL", "VE"
                                                                                    subSendMsg "&rYou cannot net warriors or gladiators or knights or plantforms.", zPortID
                                                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 fail to even budge %s2!", zTPlayerName, "%s1 fails to even budge %s2!", lX, lY, lZ
                                                                                Case Else
                                                                                    bSuccess = True
                                                                                    If (lRandom(lPlayerLevel) + lRandom(lCDEX) > lRandom(MyCLng(rsData!PlayerLevel)) + lRandom(MyCLng(rsData!CDEX))) Then 'if the players attack level plus his full random dex beats the same the target tried to dodge but failed, defender wins ties.
                                                                                        subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 ensnare [" & zPlayerWeapon(lWeaponTypeCellNet) & "] %s2!", zTPlayerName, "%s1 ensnares [" & zPlayerWeapon(lWeaponTypeCellNet) & "] %s2!", lX, lY, lZ
                                                                                        MyDB.Execute "UPDATE tblPlayer SET EntanglementDuration=" & lRandom(4) & ", EntanglementDesc='" & zEntanglementDescHitMsg & "' WHERE (PlayerID=" & lTargetID & ");", dbFailOnError
                                                                                        'subSendMsg "&GYou&R SLAM&G into and stun " & MyCStr(rsData!PlayerName) & ".", zPortID
                                                                                        'subSendMsg "&G" & zOPlayerName & "&R SLAMS&G into you!", MyCStr(rsData!PortID)
                                                                                        'subSendMsgAreaExcept2 gblzFBWHI & zOPlayerName & "&R SLAMS&G into and stuns " & MyCStr(rsData!PlayerName) & ".", lOX, lOY, lOZ, zPortID, MyCStr(rsData!PortID)
                                                                                    Else
                                                                                        subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 failed to ensnare [" & zPlayerWeapon(lWeaponTypeCellNet) & "] %s2.", zTPlayerName, "%s1 failed to ensnare [" & zPlayerWeapon(lWeaponTypeCellNet) & "] %s2.", lX, lY, lZ
                                                                                        'subSendMsgAreaExcept2 gblzFBMAG & MyCStr(rsData!PlayerName) & " stands ready!", lOX, lOY, lOZ, zPortID, MyCStr(rsData!PortID)
                                                                                        'subSendMsg "&M"  & zOPlayerName & "&R RUNS&G at you!", MyCStr(rsData!PortID)
                                                                                        'subSendMsg "&GYou &Yrush past " & gblzFBGRE & MyCStr(rsData!PlayerName) & ".", zPortID
                                                                                        'subSendMsgAreaExcept2 gblzFBWHI & zOPlayerName & gblzFBYEL & " rushes past " & gblzFBGRE & MyCStr(rsData!PlayerName) & ".", lOX, lOY, lOZ, zPortID, MyCStr(rsData!PortID)
                                                                                    End If
                                                                            End Select
                                                                        Else
                                                                            subSendMsg "&G" & zTPlayerName & " is already ensnared!", zPortID
                                                                        End If
                                                                        Select Case MyCStr(rsData!Class)
                                                                            Case "WA", "GL", "KN", "PL", "VE"
                                                                            Case Else 'we can interrupt even ensnared people
                                                                                bInterrupted = True
                                                                                Select Case zClass
                                                                                    Case "GL" 'gladiators can keep the target down with a 25 percent failure chance
                                                                                        subForceInterrupt lIASChance, zDPortID, zPortID, lRandom(2) 'ensnare even if the person is trapped still can interrupt
                                                                                    Case Else
                                                                                        subForceInterrupt lIASChance, zDPortID, zPortID, 3 'ensnare even if the person is trapped still can interrupt
                                                                                End Select
                                                                        End Select
                                                                    Else
                                                                        subSendMsg "&gNet whom?", zPortID
                                                                    End If
                                                                Else
                                                                    subSendMsg "&gYou can only net players that are level " & cstNewbieSafeLevel & " and higher.", zPortID
                                                                End If
                                                            Else
                                                                subSendMsg "&gNet who?", zPortID
                                                            End If
                                                            Set rsData = Nothing
                                                        End If
                                                    Else
                                                        subSendMsg "&gYour target name must be at least " & cstMinAttackMobLen & " characters in length.", zPortID
                                                    End If
                                                Else
                                                    subSendMsg "&gEnsnare who?", zPortID
                                                End If
                                                
                                                'We now subtract the soul from the player if the ensnare attacked worked or not
                                                If (bSuccess Or bInterrupted) Then
                                                    lStunInterruptionByClass = lTranslateEnsnareNetInterruption(zClass)
                                                    If (bInterrupted) Then lSoulCost = MyCLng(lSoulCost / 2)
                                                    MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lSoulCost & ", StunInterruption=" & lRandom(lStunInterruptionByClass) + 1 & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                            Else
                                                subSendMsg "&RYou have to wait a few rounds before you can ensnare.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&RYou have to stand to do that.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RYou are too stunned to attempt an ensnare.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou are too blind to attempt a stun.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou are too scared to attempt an ensnare.", zPortID
                            End If
                        Else
                            subSendMsg "&RYou need to hold a netting item in your hands.", zPortID
                        End If
                    Else
                        subSendMsg "&RYou are ensnared and cannot move.", zPortID
                    End If
                Else
                    subSendMsg "&RYou are too sleepy to attempt an ensnare.", zPortID
                End If
            Else
                subSendMsg "&BA magical barrier prevents you from ensnaring.", zPortID
            End If
        Else
            subSendMsg "&GYou envision great battles in your sleep.", zPortID
        End If
    Else
        subSendMsg "&RsubCombatStun: Tell an immortal that your player file was not found!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatStun," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBackstab(zPortID As String, zTargetName As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bSuccess As Boolean
    Dim zMobName As String
    Dim lMHerdMobID As Long
    Dim lMHP As Long
    Dim lMLevel As Long
    Dim bBounty As Boolean
    Dim lGold As Long
    Dim lMMoveAllowed As Long
    Dim lDamage As Long
    Dim lFlyHeight As Long
    Dim lGetTranslateSkillStunCost As Long
    Dim lTargetID As Long
    Dim lMobID As Long
    Dim lQuestMobID As Long
    Dim zSQL As String
    Dim lStunType As Long
    Dim lStunInterruptionByClass As Long
    Dim zTPlayerName As String
    Dim rsPlayer As Recordset
    Dim bPlayerFound As Boolean
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lMagicFind As Long
    Dim lMagicFindBase As Long
    Dim lCLuc As Long
    Dim lCDEX As Long
    Dim lCStr As Long
    Dim lCCon As Long
    Dim lCSoul As Long
    Dim lSoulCost As Long
    Dim lStunInterruption As Long
    Dim lFPlayerGroupStatus As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lStatus As Long
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim zGender As String
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim bMobVisible As Boolean
    Dim lFlyDuration As Long
    Dim lPlayerHeight As Long
    Dim lEntanglementDuration As Long
    Dim zEntanglementDesc As String
    Dim bAttackAway As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim lSlayChance As Long
    Dim lWeaponSkillBackStabClassLevel As Long
    Dim lSneakingMovesLeft As Long
    Dim lSneakingMovesLeftCalc As Long
    Dim zRace As String
    Dim zClass As String
    Dim lCHITROLL As Long
    Dim lCDAMROLL As Long
    Dim lXP As Long
    Dim zBSMsg As String
    Dim zWeaponName As String
    Dim rsWeapons As Recordset
    Dim bWeaponsFound As Boolean
    Dim lSQLCount As Long
    Dim bMasterstabber As Boolean

    Set rsPlayer = MyDB.OpenRecordset("SELECT QuestMobID, Gold, PlayerLevel, MagicFindBase, MagicFind, CHITROLL, CDAMROLL, XP, CAC, CHP, CEssence, CMana, CSoul, CMove, CSTR, CINT, CWIS, CDEX, CCON, CCHA, CLUC, NumAttRnd, Race, SneakingMovesLeft, SlayChance, WeaponSkillBackStabClassLevel, TurnedIntoAnimalType, EntanglementDuration, EntanglementDesc, Height, FlyDuration, SleepDuration, PlayerFleeDuration, Gender, Class, CSoul, StunDuration, DetectInvisibilityDuration, BlindDuration, StunInterruption, CDex, CStr, CCon, FPlayerGroupStatus, X, Y, Z, Status, PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        zRace = MyCStr(rsPlayer!Race)
        zClass = MyCStr(rsPlayer!Class)
        bMasterstabber = (zRace = "ORC" Or zClass = "TH" Or zClass = "AS" Or zClass = "GY")
        lCHITROLL = MyCLng(rsPlayer!CHITROLL)
        lCDAMROLL = MyCLng(rsPlayer!CDAMROLL)
        lQuestMobID = MyCLng(rsPlayer!QuestMobID)
        lXP = MyCLng(rsPlayer!XP)
        lGold = MyCLng(rsPlayer!Gold)
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        lFlyDuration = MyCLng(rsPlayer!FlyDuration)
        lPlayerHeight = MyCLng(rsPlayer!Height)
        lStatus = MyCLng(rsPlayer!Status)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lMagicFind = MyCLng(rsPlayer!MagicFind)
        lMagicFindBase = MyCLng(rsPlayer!MagicFindBase)
        lCLuc = MyCLng(rsPlayer!CLuc)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCStr = MyCLng(rsPlayer!CStr)
        lCCon = MyCLng(rsPlayer!CCon)
        lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        Select Case zClass
            Case "AS", "WA", "GL"
                lStunType = 1 + lRandom(3)
            Case "KN"
                lStunType = 1 + lRandom(2)
            Case Else
                lStunType = lRandom(3)
        End Select
        zGender = MyCStr(rsPlayer!Gender)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lStunInterruption = MyCLng(rsPlayer!StunInterruption)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        zEntanglementDesc = MyCStr(rsPlayer!EntanglementDesc)
        lWeaponSkillBackStabClassLevel = MyCLng(rsPlayer!WeaponSkillBackStabClassLevel)
        lSlayChance = MyCLng(rsPlayer!SlayChance)
        lSneakingMovesLeft = MyCLng(rsPlayer!SneakingMovesLeft)
        lSneakingMovesLeftCalc = 1
        zBSMsg = "crit-stab"
        If (lSneakingMovesLeft > 0) Then
            If (zClass = "TH") Then
                lSlayChance = (lSlayChance * 2) + 1
                zBSMsg = "hopper-stab"
            End If
            If (zClass = "AS") Then
                lSlayChance = (lSlayChance * 3) + 9
                zBSMsg = "master-stab"
            End If
            lSneakingMovesLeftCalc = 5 'sneaking mode enhances the chance
            If (bWhenIsIt("", False)) Then lSneakingMovesLeftCalc = lSneakingMovesLeftCalc * 2
        End If
        If (bMasterstabber) Then zBSMsg = "{M}" & zBSMsg
    Else
        bPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    If (bPlayerFound) Then
    If (lPlayerLevel > 29) Then
        bWeaponsFound = False
        Select Case zClass
            Case "AS" 'just about anything works for assassin to backstab with
                zSQL = ""
                zSQL = zSQL & "tblPlayer.PlayerID, tblPlayer.PortID, tblObject.ObjectName, Len([WeaponType]) AS lenwt, tblObject.FishingRodLevel, tblObject.ExplodeLevel, tblObject.CHITROLL, Len([WeaponSkillBackStabClass]) AS lenwsbc, Len([WeaponSkillMissileRangeClass]) AS lenwsmrc FROM (tblPlayer INNER JOIN tblPlayerEquipmentItems ON tblPlayer.PlayerID = tblPlayerEquipmentItems.PlayerID) INNER JOIN "
                zSQL = zSQL & "tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((Len([WeaponType]))<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.FishingRodLevel)<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.ExplodeLevel)<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.CHITROLL)<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((Len([WeaponSkillBackStabClass]))<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((Len([WeaponSkillMissileRangeClass]))<>0));"
            Case Else
                zSQL = ""
                zSQL = zSQL & "tblPlayer.PlayerID, tblPlayer.PortID, tblObject.ObjectName, tblObject.WeaponType AS sblawt, tblObject.FishingRodLevel, Len([WeaponSkillBackStabClass]) AS lenwsbc "
                zSQL = zSQL & "FROM (tblPlayer INNER JOIN tblPlayerEquipmentItems ON tblPlayer.PlayerID = tblPlayerEquipmentItems.PlayerID) INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID "
                zSQL = zSQL & "WHERE (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.WeaponType)='SBLA' Or (tblObject.WeaponType)='TALO')) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.FishingRodLevel)<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((Len([WeaponSkillBackStabClass]))<>0));"
        End Select
        lSQLCount = lngSQLRecordCount("SELECT " & zSQL)
        If (lSQLCount <> 0) Then
            Set rsWeapons = MyDB.OpenRecordset("SELECT TOP " & lRandom(lSQLCount) & " " & zSQL, dbOpenSnapshot) 'backstab can use various parts of eq automatically!
            If (Not rsWeapons.EOF) Then 'random on something you can use to backstab with
                rsWeapons.MoveLast
                bWeaponsFound = True
                zWeaponName = zShortstop(MyCStr(rsWeapons!ObjectName))
            End If
            Set rsWeapons = Nothing
        End If
        
        If (bWeaponsFound) Then
            If (lStatus <> 50) Then 'is player asleep?
            If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then
                If (zAreaRules(1, lX, lY, lZ) = "1") Then
                    If (lSleepDuration = 0) Then
                        If (lPlayerFleeDuration = 0) Then
                            If (lEntanglementDuration = 0) Then
                                If (lBlindDuration = 0) Then
                                    If (lStunDuration = 0) Then
                                        If (lStatus = 5 Or lStatus = 0) Then
                                            If (lStunInterruption = 0) Then
                                                zBSMsg = zBSMsg & "[" & zWeaponName & "]"
                                                lTargetID = lPlayerFightingMobID(zPortID)
                                                If (lTargetID = 0) Then
                                                    bAttackAway = bPlayerVsMobCombatSetUp(zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, False, False)
                                                    If (Not bAttackAway) Then
                                                        bAttackAway = (lngSQLRecordCount("SELECT PlayerID FROM tblPlayer WHERE (PlayerName Like ""*" & zTargetName & "*"" AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") > 0) 'see if its a player
                                                    Else
                                                        lTargetID = lPlayerFightingMobID(zPortID) 'we grab the value
                                                    End If
                                                Else
                                                    bAttackAway = True
                                                    'We have this at this point lTargetID = lPlayerFightingMobID(zPortID)
                                                End If
                                                If (bAttackAway) Then
                                                    If (Len(zTargetName) >= cstMinAttackMobLen Or lTargetID <> 0) Then
                                                        lGetTranslateSkillStunCost = lTranslateSkillStunCost(zClass)
                                                        
                                                        lSoulCost = cstlStunSoulCost * lGetTranslateSkillStunCost
                                                        
                                                        bSuccess = False
                                                        If (lCSoul >= lSoulCost) Then 'Attacker uses essence in the stun attack
                                                            If (Len(zTargetName) > 0 Or lTargetID <> 0) Then
                                                                'Check for mob in area
                                                                Select Case (lTargetID = 0)
                                                                    Case True
                                                                        zSQL = "SELECT MoveAllowed, DefeatedMobDesc, HerdMobID, Flys, FlyHeight, MHP, Invisible, MobID, StunLevel, PlayerID, MobLevel, MobName, StunRandom, StunDuration, StunExtraDodge, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobName Like ""*" & zTargetName & "*"") AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0);"
                                                                    Case False
                                                                        zSQL = "SELECT MoveAllowed, DefeatedMobDesc, HerdMobID, Flys, FlyHeight, MHP, Invisible, MobID, StunLevel, PlayerID, MobLevel, MobName, StunRandom, StunDuration, StunExtraDodge, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobID=" & lTargetID & ") AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0);"
                                                                End Select
                                                                bMobVisible = False
                                                                Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                                                If (Not rsData.EOF) Then
                                                                    lMobID = MyCLng(rsData!MobID)
                                                                    lMLevel = MyCLng(rsData!MobLevel)
                                                                    bBounty = (Len(MyCStr(rsData!DefeatedMobDesc)) > 0)
                                                                    lMMoveAllowed = MyCLng(rsData!MoveAllowed)
                                                                    lFlyHeight = MyCLng(rsData!FlyHeight)
                                                                    lMHerdMobID = MyCLng(rsData!HerdMobID)
                                                                    lMHP = MyCLng(rsData!MHP)
                                                                    bMobVisible = (lDetectInvisibilityDuration <> 0) Or (MyCInt(rsData!Invisible) = 0)
                                                                    lTargetID = MyCLng(rsData!MobID)
                                                                    If (bBounty) Then MyDB.Execute "UPDATE tblMob SET DefeatedMobDesc='' WHERE (MobID=" & lTargetID & ");", dbFailOnError 'remove the bounty/joke corpse held right away
                                                                    zMobName = MyCStr(rsData!MobName)
                                                                    zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
                                                                    If (bMobVisible) Then
                                                                        If (lPlayerLevel >= MyCLng(rsData!StunLevel)) Then
                                                                            If (lFlyDuration > 0 Or zClass = "VA" Or zRace = "PIX") Or (lPlayerHeight + (lPlayerHeight / 3) > lFlyHeight) Then 'Weapons do not help with this reach
                                                                            If (MyCLng(rsData!StunDuration) = 0) Then
                                                                                If (lRandom(MyCLng((lPlayerLevel * lSneakingMovesLeftCalc) / 3)) + (lRandom(lCDEX * lWeaponSkillBackStabClassLevel)) > lRandom(MyCLng(rsData!MobLevel) + MyCLng(rsData!MobLevel)) + MyCLng(rsData!StunExtraDodge) + lRandom(MyCLng(rsData!StunRandom))) Then    'mobs that have stun can dodge stuns easier
                                                                                    bSuccess = True
                                                                                    If ((MyCLng(lSlayChance / 2) + lRandom(MyCLng(lSlayChance / 2))) > lRandom(MyCLng(rsData!MobLevel) * 2) + lRandom(MyCLng(rsData!StunExtraDodge)) + lRandom(MyCLng(rsData!StunRandom))) Then
                                                                                        subSendMsgAreaAllDISmart "&R", zPlayerName, "%s1 " & zBSMsg & " " & zMobName & ".", "", "%s1 " & zBSMsg & "s " & zMobName & ".", lX, lY, lZ
                                                                                        lDamage = lMHP
                                                                                        lMHP = 0
                                                                                    Else
                                                                                        lDamage = lRandom(lCDAMROLL)
                                                                                        If (lMHP - lDamage < 0) Then lDamage = lMHP
                                                                                        lMHP = lMHP - lDamage
                                                                                        Select Case zClass
                                                                                            Case "AS"
                                                                                                MyDB.Execute "UPDATE tblMob SET MHP=" & lMHP & ", StunDuration=" & lRandom(lStunType) & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                            Case Else
                                                                                                If (lRandom(3) = 1) Then
                                                                                                    MyDB.Execute "UPDATE tblMob SET MHP=" & lMHP & ", StunDuration=" & lRandom(lStunType) & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                                Else
                                                                                                    MyDB.Execute "UPDATE tblMob SET MHP=" & lMHP & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                                End If
                                                                                        End Select
                                                                                        subSendMsgAreaAllDISmart "&g", zPlayerName, "%s1 backstab " & zMobName & ".", "", "%s1 backstabs " & zMobName & ".", lX, lY, lZ
                                                                                    End If
                                                                                    lXP = lXP + lDamage
                                                                                    MyDB.Execute "UPDATE tblPlayer SET [XP]=" & lXP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                    If (lMHP < 1) Then
                                                                                        If (lMHerdMobID <> 0) Then
                                                                                            subQuestHerdMob lMHerdMobID, zPlayerName, lPlayerID, lMagicFind, lMagicFindBase, lPlayerLevel, bMasterstabber, zPortID
                                                                                        End If
                                                                                        subPlayerQuest zPlayerName, lPlayerID, lPlayerLevel, lQuestMobID, zMobName, lMobID, lMLevel, bBounty, zPortID, lX, lY, lZ, lGold, lMMoveAllowed
                                                                                        subCombatEndedInitializeCombatCellsMobID lTargetID
                                                                                        subMakeCorpse zPortID, lPlayerID, lPlayerLevel, lTargetID, "M", lMagicFind, lMagicFindBase, lCLuc
                                                                                        Select Case zClass
                                                                                            Case "AS"
                                                                                                MyDB.Execute "UPDATE tblMob SET [RespawnDelay]=1+" & lRandom(3) & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                            Case Else
                                                                                                MyDB.Execute "UPDATE tblMob SET [RespawnDelay]=5+" & lRandom(9) & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                        End Select
                                                                                    End If
                                                                                Else
                                                                                    subSendMsgAreaAllDISmart "&R", zPlayerName, "%s1 fail to backstab " & zMobName & ".", "", "%s1 fails to backstab " & zMobName & ".", lX, lY, lZ
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&G" & zMobName & " is already dazed.", zPortID
                                                                            End If
                                                                            Else
                                                                                subSendMsg gblzFNGRE & zMobName & " is out of reach!", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&gYou have to be level " & MyCLng(rsData!StunLevel) & " to backstab " & zMobName & ".", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&gBackstab Who?", zPortID
                                                                    End If
                                                                End If
                                                                Set rsData = Nothing
                                                                
                                                                'Check for player in area
                                                                If (Not bSuccess) Then 'Mob not found try to find player
                                                                    Set rsData = MyDB.OpenRecordset("SELECT PlayerID, InvisibilityDuration, CamoflaguedDuration, HideDuration, SneakingMovesLeft, CHP, PlayerLevel, CDEX, PlayerName, StunDuration, X, Y, Z, PortID, Class FROM tblPlayer WHERE (PlayerName Like """ & zKeepLettersOnly(zTargetName) & "*"") AND (PortID<>'" & zPortID & "' And Len([PortID])>1) AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
                                                                    If (Not rsData.EOF) Then
                                                                        lTargetID = MyCLng(rsData!PlayerID)
                                                                        zTPlayerName = MyCStr(rsData!PlayerName)
                                                                        If (MyCLng(rsData!PlayerLevel) >= cstNewbieSafeLevel) Then
                                                                            If ((MyCLng(rsData!InvisibilityDuration) = 0 And MyCLng(rsData!CamoflaguedDuration) = 0 And MyCLng(rsData!HideDuration) = 0) Or (lDetectInvisibilityDuration > 0)) Then
                                                                                If (MyCLng(rsData!StunDuration) = 0) Then
                                                                                    If (lRandom((lPlayerLevel * lSneakingMovesLeftCalc)) + lRandom(lCDEX * lWeaponSkillBackStabClassLevel) > lRandom(MyCLng(rsData!PlayerLevel)) + (MyCLng(rsData!PlayerLevel) * 2) + lRandom(MyCLng(rsData!CDEX))) Then 'if the players attack level plus his full random dex beats the same the target tried to dodge but failed, defender wins ties.
                                                                                        bSuccess = True
                                                                                        MyDB.Execute "UPDATE tblPlayer SET CHP=CLng((CHP+1)/1.03), StunDuration=" & lRandom(lStunType) & " WHERE (PlayerID=" & lTargetID & ");", dbFailOnError
                                                                                        If (lRandom(lSlayChance) > lRandom(MyCLng(rsData!PlayerLevel) + MyCLng(rsData!CDEX))) Then
                                                                                            subSendMsgAreaAllDISmart "&R", zPlayerName, "%s1 " & zBSMsg & " %s2!", zTPlayerName, "%s1 " & zBSMsg & "s %s2!", lX, lY, lZ
                                                                                            MyDB.Execute "UPDATE tblPlayer SET CHP=CLng(CHP/2) WHERE (PlayerID=" & lTargetID & ");", dbFailOnError
                                                                                        Else
                                                                                            subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 backstab %s2!", zTPlayerName, "%s1 backstabs %s2!", lX, lY, lZ
                                                                                        End If
                                                                                        MyDB.Execute "UPDATE tblPlayer SET CHP=1 WHERE (CHP < 1 AND PlayerID=" & lTargetID & ");", dbFailOnError
                                                                                    Else
                                                                                        subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 miss backstabbing %s2.", zTPlayerName, "%s1 misses %s2 in a failed attempt to backstab.", lX, lY, lZ
                                                                                    End If
                                                                                Else
                                                                                    subSendMsg "&G" & zTPlayerName & " is already dazed from backstab!", zPortID
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&gBackstab who?", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&gYou can only backstab players that are level " & cstNewbieSafeLevel & " and higher.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&gBackstab who?", zPortID
                                                                    End If
                                                                    Set rsData = Nothing
                                                                End If
                                                                
                                                                'We now subtract the soul from the player if the stun attacked worked or not
                                                                If (bSuccess) Then
                                                                    Select Case zClass 'fighter classes dont get a long stun interruption
                                                                        Case "WA"
                                                                            lStunInterruptionByClass = 9
                                                                        Case "GL", "KN"
                                                                            lStunInterruptionByClass = 2
                                                                        Case "PA"
                                                                            lStunInterruptionByClass = 4
                                                                        Case "MA", "TH", "AS", "DR"
                                                                            lStunInterruptionByClass = 1
                                                                        Case "CL"
                                                                            lStunInterruptionByClass = 2
                                                                        Case Else
                                                                            lStunInterruptionByClass = 5
                                                                    End Select
                                                                    MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lSoulCost & ", StunInterruption=" & lRandom(lStunInterruptionByClass) + 1 & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                    subAddPortIDsCyborgVentingSystem MyCLng(zPortID), 4
                                                                End If
                                                            Else
                                                                subSendMsg "&gBackstab who?", zPortID
                                                            End If
                                                        Else
                                                            subSendMsg "&cYou are short " & lSoulCost - lCSoul & " soul points.", zPortID
                                                        End If
                                                    Else
                                                        subSendMsg "&gYour target name must be at least " & cstMinAttackMobLen & " characters in length.", zPortID
                                                    End If
                                                Else
                                                    subSendMsg "&gBackstab whom?", zPortID
                                                End If
                                            Else
                                                subSendMsg "&RYou have to wait " & lStunInterruption & " round(s before you can stun or backstab again.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&RYou have to stand to do that.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RYou are too stunned to attempt a backstab.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou are too blind to attempt a backstab.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou are ensnared and cannot move.", zPortID
                            End If
                        Else
                            subSendMsg "&RYou are too scared to attempt a backstab.", zPortID
                        End If
                    Else
                        subSendMsg "&RYou are too sleepy to attempt a backstab.", zPortID
                    End If
                Else
                    subSendMsg "&BA magical barrier prevents you from backstabbing.", zPortID
                End If
            Else
                subSendMsg "&MYou cannot do that when you are a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ".", zPortID
            End If
            Else
                subSendMsg "&GYou envision great battles in your sleep.", zPortID
            End If
        Else
            subSendMsg "&RYou have literally nothing to backstab with.", zPortID
        End If
    Else
        subSendMsg "&R[PL30] You are not quite the appropriate level!", zPortID
    End If
    Else
        subSendMsg "&RsubBackstab: Tell an immortal that your player file was not found!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subBackstab," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatStun(zPortID As String, zTargetName As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bSuccess As Boolean
    Dim zMobName As String
    Dim lGetTranslateSkillStunCost As Long
    Dim lTargetID As Long
    Dim zSQL As String
    Dim lStunType As Long
    Dim lStunInterruptionByClass As Long
    Dim zTPlayerName As String
    
    Dim rsPlayer As Recordset
    Dim bPlayerFound As Boolean
    
    Dim zPlayerName As String
    Dim lRaceClassBonus As Long
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCDEX As Long
    Dim lCStr As Long
    Dim lCCon As Long
    Dim lCSoul As Long
    Dim lSoulCost As Long
    Dim zRace As String
    Dim zClass As String
    Dim lStunInterruption As Long
    Dim lFPlayerGroupStatus As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lStatus As Long
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim zGender As String
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim bMobVisible As Boolean
    Dim lFlyDuration As Long
    Dim lPlayerHeight As Long
    Dim lEntanglementDuration As Long
    Dim zEntanglementDesc As String
    Dim bAttackAway As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim lPortID As Long
    
    lPortID = MyCLng(zPortID)
    If (gbllFishing(lPortID) = 0) Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, Race, TurnedIntoAnimalType, EntanglementDuration, EntanglementDesc, Height, FlyDuration, SleepDuration, PlayerFleeDuration, Gender, Class, CSoul, StunDuration, DetectInvisibilityDuration, BlindDuration, StunInterruption, CDex, CStr, CCon, FPlayerGroupStatus, X, Y, Z, Status, PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            bPlayerFound = True
            lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
            lFlyDuration = MyCLng(rsPlayer!FlyDuration)
            lPlayerHeight = MyCLng(rsPlayer!Height)
            lStatus = MyCLng(rsPlayer!Status)
            lSleepDuration = MyCLng(rsPlayer!SleepDuration)
            lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            lCSoul = MyCLng(rsPlayer!CSoul)
            lCDEX = MyCLng(rsPlayer!CDEX)
            lCStr = MyCLng(rsPlayer!CStr)
            lCCon = MyCLng(rsPlayer!CCon)
            lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
            lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
            zRace = MyCStr(rsPlayer!Race)
            zClass = MyCStr(rsPlayer!Class)
            lRaceClassBonus = 1
            Select Case zClass
                Case "AS", "WA", "GL"
                    lRaceClassBonus = lRaceClassBonus + 20
                    lStunType = 3 + lRandom(2)
                Case "KN", "GY"
                    lRaceClassBonus = lRaceClassBonus + 5
                    lStunType = 1 + lRandom(4)
                Case Else
                    lStunType = lRandom(5)
            End Select
            Select Case zRace
                Case "DRA", "FEL", "HUM", "ORC"
                    lRaceClassBonus = lRaceClassBonus + 5
                Case "DWA"
                    lRaceClassBonus = lRaceClassBonus + 2
                Case Else
                    lRaceClassBonus = lRaceClassBonus + 1
            End Select
            zGender = MyCStr(rsPlayer!Gender)
            lBlindDuration = MyCLng(rsPlayer!BlindDuration)
            lStunDuration = MyCLng(rsPlayer!StunDuration)
            lStunInterruption = MyCLng(rsPlayer!StunInterruption)
            lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
            zEntanglementDesc = MyCStr(rsPlayer!EntanglementDesc)
        Else
            bPlayerFound = False
        End If
        Set rsPlayer = Nothing

        If (bPlayerFound) Then
            If (gbllAttackLevel(lPortID) < lRaceClassAttackLevelMAX(zRace, zClass)) Then
                If (zClass <> "MA" And zClass <> "IO" And zClass <> "DR" And zClass <> "PA") Then
                If (lStatus <> 50) Then 'is player asleep?
                If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then
                    If (zAreaRules(1, lX, lY, lZ) = "1") Then
                        If (lSleepDuration = 0) Then
                            If (lPlayerFleeDuration = 0) Then
                                If (lEntanglementDuration = 0) Then
                                    If (lBlindDuration = 0) Then
                                        If (lStunDuration = 0) Then
                                            If (lStatus = 5 Or lStatus = 0) Then
                                                If (lStunInterruption = 0) Then
                                                    lTargetID = lPlayerFightingMobID(zPortID)
                                                    If (lTargetID = 0) Then
                                                        bAttackAway = bPlayerVsMobCombatSetUp(zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, False, False)
                                                        If (Not bAttackAway) Then
                                                            bAttackAway = (lngSQLRecordCount("SELECT PlayerID FROM tblPlayer WHERE (PlayerName Like ""*" & zTargetName & "*"" AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") > 0) 'see if its a player
                                                        Else
                                                            lTargetID = lPlayerFightingMobID(zPortID) 'we grab the value
                                                        End If
                                                    Else
                                                        bAttackAway = True
                                                        'We have this at this point lTargetID = lPlayerFightingMobID(zPortID)
                                                    End If
                                                    If (bAttackAway) Then
                                                        If (Len(zTargetName) >= cstMinAttackMobLen Or lTargetID <> 0) Then
                                                            lGetTranslateSkillStunCost = lTranslateSkillStunCost(zClass)
                                                            
                                                            lSoulCost = cstlStunSoulCost * lGetTranslateSkillStunCost
                                                            
                                                            bSuccess = False
                                                            If (lCSoul >= lSoulCost) Then 'Attacker uses essence in the stun attack
                                                                If (Len(zTargetName) > 0 Or lTargetID <> 0) Then
                                                                    'Check for mob in area
                                                                    Select Case (lTargetID = 0)
                                                                        Case True
                                                                            zSQL = "SELECT Invisible, MobID, StunLevel, PlayerID, MobLevel, MobName, StunRandom, StunDuration, StunExtraDodge, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobName Like ""*" & zTargetName & "*"") AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0);"
                                                                        Case False
                                                                            zSQL = "SELECT Invisible, MobID, StunLevel, PlayerID, MobLevel, MobName, StunRandom, StunDuration, StunExtraDodge, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobID=" & lTargetID & ") AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0);"
                                                                    End Select
                                                                    bMobVisible = False
                                                                    Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                                                    If (Not rsData.EOF) Then
                                                                        bMobVisible = (lDetectInvisibilityDuration <> 0) Or (MyCInt(rsData!Invisible) = 0)
                                                                        lTargetID = MyCLng(rsData!MobID)
                                                                        zMobName = MyCStr(rsData!MobName)
                                                                        zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
                                                                        If (bMobVisible) Then
                                                                            If (lPlayerLevel >= MyCLng(rsData!StunLevel)) Then
                                                                                If (MyCLng(rsData!RespawnDelay) = 0) Then
                                                                                    If (MyCLng(rsData!StunDuration) = 0) Then
                                                                                        If (lRandom(MyCLng(lPlayerLevel / 3)) + (lRandom(lCDEX * 2)) + lRaceClassBonus > lRandom(MyCLng(rsData!MobLevel)) + MyCLng(rsData!StunExtraDodge) + lRandom(MyCLng(rsData!StunRandom))) Then  'mobs that have stun can dodge stuns easier
                                                                                            bSuccess = True
                                                                                            subSendMsg "&GYou stun for " & lStunType & " rnds.", zPortID
                                                                                            MyDB.Execute "UPDATE tblMob SET StunDuration=" & lStunType & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                            subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 stun " & zMobName & ".", "", "%s1 stuns " & zMobName & ".", lX, lY, lZ
                                                                                        Else
                                                                                            subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 run past " & zMobName & ".", "", "%s1 runs past " & zMobName & " in a failed attempt to stun.", lX, lY, lZ
                                                                                        End If
                                                                                    Else
                                                                                        subSendMsg "&G" & zMobName & " is already stunned!", zPortID
                                                                                    End If
                                                                                Else
                                                                                    subSendMsg gblzFNGRE & zShortstop(MyCStr(rsData!MobName)) & " is not here.", zPortID
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&gYou have to be level " & MyCLng(rsData!StunLevel) & " to stun " & zMobName & ".", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&gStun Who?", zPortID
                                                                        End If
                                                                    End If
                                                                    Set rsData = Nothing
                                                                    
                                                                    'Check for player in area
                                                                    If (Not bSuccess) Then 'Mob not found try to find player
                                                                        Set rsData = MyDB.OpenRecordset("SELECT PlayerID, InvisibilityDuration, CamoflaguedDuration, HideDuration, SneakingMovesLeft, CHP, PlayerLevel, CDEX, PlayerName, StunDuration, X, Y, Z, PortID, Class FROM tblPlayer WHERE (PlayerName Like """ & zKeepLettersOnly(zTargetName) & "*"") AND (PortID<>'" & zPortID & "' And Len([PortID])>1) AND (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
                                                                        If (Not rsData.EOF) Then
                                                                            lTargetID = MyCLng(rsData!PlayerID)
                                                                            zTPlayerName = MyCStr(rsData!PlayerName)
                                                                            If (MyCLng(rsData!PlayerLevel) >= cstNewbieSafeLevel) Then
                                                                                If ((MyCLng(rsData!InvisibilityDuration) = 0 And MyCLng(rsData!CamoflaguedDuration) = 0 And MyCLng(rsData!HideDuration) = 0) Or (lDetectInvisibilityDuration > 0)) Then
                                                                                    If (MyCLng(rsData!StunDuration) = 0) Then
                                                                                        Select Case MyCStr(rsData!Class)
                                                                                            Case "WA", "GL"
                                                                                                subSendMsg "&rYou cannot stun warriors or gladiators.", zPortID
                                                                                                subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 fail to even budge %s2!", zTPlayerName, "%s1 fails to even budge %s2!", lX, lY, lZ
                                                                                            Case Else
                                                                                                If (lRandom(lPlayerLevel) + lRandom(lCDEX) > lRandom(MyCLng(rsData!PlayerLevel)) + lRandom(MyCLng(rsData!CDEX))) Then 'if the players attack level plus his full random dex beats the same the target tried to dodge but failed, defender wins ties.
                                                                                                    bSuccess = True
                                                                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 slam into %s2!", zTPlayerName, "%s1 slams into %s2!", lX, lY, lZ
                                                                                                    MyDB.Execute "UPDATE tblPlayer SET StunDuration=" & lRandom(lStunType) & " WHERE (PlayerID=" & lTargetID & ");", dbFailOnError
                                                                                                Else
                                                                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 run past %s2 in a failed attempt to stun.", zTPlayerName, "%s1 runs past %s2 in a failed attempt to stun.", lX, lY, lZ
                                                                                                End If
                                                                                        End Select
                                                                                    Else
                                                                                        subSendMsg "&G" & zTPlayerName & " is already stunned!", zPortID
                                                                                    End If
                                                                                Else
                                                                                    subSendMsg "&gStun who?", zPortID
                                                                                End If
                                                                            Else
                                                                                subSendMsg "&gYou can only stun players that are level " & cstNewbieSafeLevel & " and higher.", zPortID
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&gStun who?", zPortID
                                                                        End If
                                                                        Set rsData = Nothing
                                                                    End If
                                                                    
                                                                    'We now subtract the soul from the player if the stun attacked worked or not
                                                                    If (bSuccess) Then
                                                                        Select Case zClass 'fighter classes dont get a long stun interruption
                                                                            Case "WA", "KN"
                                                                                lStunInterruptionByClass = 1
                                                                            Case "GL", "AS"
                                                                                lStunInterruptionByClass = 2
                                                                            Case "PA"
                                                                                lStunInterruptionByClass = 2
                                                                            Case "MA", "CL", "DR"
                                                                                lStunInterruptionByClass = 3
                                                                            Case Else
                                                                                lStunInterruptionByClass = 5
                                                                        End Select
                                                                        MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lSoulCost & ", StunInterruption=" & lRandom(lStunInterruptionByClass) + 1 & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                        subAddPortIDsCyborgVentingSystem lPortID, 2
                                                                    End If
                                                                Else
                                                                    subSendMsg "&gStun who?", zPortID
                                                                End If
                                                            Else
                                                                subSendMsg "&cYou are short " & lSoulCost - lCSoul & " soul points.", zPortID
                                                            End If
                                                        Else
                                                            subSendMsg "&gYour target name must be at least " & cstMinAttackMobLen & " characters in length.", zPortID
                                                        End If
                                                    Else
                                                        subSendMsg "&gStun whom?", zPortID
                                                    End If
                                                Else
                                                    subSendMsg "&RYou have to wait " & lStunInterruption & " round(s before you can stun or backstab again.", zPortID
                                                End If
                                            Else
                                                subSendMsg "&RYou have to stand to do that.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&RYou are too stunned to attempt a stun.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RYou are too blind to attempt a stun.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou are ensnared and cannot move.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou are too scared to attempt a stun.", zPortID
                            End If
                        Else
                            subSendMsg "&RYou are too sleepy to attempt a stun.", zPortID
                        End If
                    Else
                        subSendMsg "&BA magical barrier prevents you from stunning.", zPortID
                    End If
                Else
                    subSendMsg "&MYou cannot do that when you are a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ".", zPortID
                End If
                Else
                    subSendMsg "&GYou envision great battles in your sleep.", zPortID
                End If
                Else
                    subSendMsg "&rYour class is forbidden to use STUN.", zPortID
                End If
            Else
                subSendMsg "&rYour body needs a break!", zPortID
                'If (lPlayerLevel < 11) Then subSendMsg "&Y[&yPL11&Y]&GH&gINT: This MUD is about forging not leveling:" & vbCrLf & "Go slow and find crowns of glory everywhere!" & vbCrLf & "This MUD will play with you, give you quests, and the Oracle has crowns too!" & vbCrLf & "&GOnce triggered, the above warning message disappears" & vbCrLf & "in about thirty seconds, when not disturbed with another attack.", zPortID
            End If
        Else
            subSendMsg "&RsubCombatStun: Tell an immortal that your player file was not found!", zPortID
        End If
    Else
        subSendMsg "&gBut wait, you are fishing. Stand or move away first.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatStun," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatAid(zTargetName As String, zPortID As String)
On Error GoTo Err_Check
    Const cstSoulCost = 11
    Const cstMoveCost = 21
    Dim lRollA As Long
    Dim lRollB As Long
    Dim rsPlayer As Recordset
    Dim bFound As Boolean
    Dim rsData As Recordset
    'Dim bSuccess As Boolean
    Dim bInvisOkay As Boolean
    Dim lTotalSoulCost As Long
    Dim lTotalMoveCost As Long
    Dim lTargetID As Long
    Dim zOPlayerName As String
    Dim zTargetPortID As String
    Dim lOPlayerID As Long
    Dim lOPlayerLevel As Long
    Dim lMove As Long
    Dim lSoul As Long
    Dim lOCINT As Long
    Dim lOCCha As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lStatus As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lPortID As Long
    
    'Debug.Print zTargetName
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT Status, PlayerName, PlayerID, PlayerLevel, CMove, CSoul, CCHA, CINT, X, Y, Z, DetectInvisibilityDuration FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        zOPlayerName = MyCStr(rsPlayer!PlayerName)
        lOPlayerID = MyCLng(rsPlayer!PlayerID)
        lOPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lMove = MyCLng(rsPlayer!CMove)
        lSoul = MyCLng(rsPlayer!CSoul)
        lOCINT = MyCLng(rsPlayer!CInt)
        lOCCha = MyCLng(rsPlayer!CCHA)
        lOX = MyCLng(rsPlayer!x)
        lOY = MyCLng(rsPlayer!y)
        lOZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        If (lStatus <> 50) Then
            'bSuccess = False
            lTotalMoveCost = 100 + (cstMoveCost * lOPlayerLevel)
            If (lMove >= lTotalMoveCost) Then 'Aid uses Move to cure
                lTotalSoulCost = 500 + (cstSoulCost * lOPlayerLevel)
                If (lSoul >= lTotalSoulCost) Then 'Aid uses Soul to cure
                    lPortID = MyCLng(zPortID)
                    If (lRandom(lOCCha) > lRandom(999)) Then
                        subSendMsg "&YNo cost, you are one &Wcharming &Yphysician.", zPortID
                    Else
                        MyDB.Execute "UPDATE tblPlayer SET [CSoul]=[CSoul]-" & lTotalSoulCost & ", [CMove]=[CMove]-" & lTotalMoveCost & " WHERE (PlayerID=" & lOPlayerID & ");", dbFailOnError
                    End If
                    
                    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'lPortID = MyCLng(zPortID)
                        If (gbllAngryVentingSystem(lPortID) > 0) Then
                            gbllAngryVentingSystem(lPortID) = gbllAngryVentingSystem(lPortID) - 1
                        End If
                    End If
                    
                    If (Len(zTargetName) > 0) Then
                        'Check for player in area
                        Set rsData = MyDB.OpenRecordset("SELECT PlayerID, InvisibilityDuration, PlayerLevel, PlayerName, BlindDuration, StunDuration, X, Y, Z, PortID FROM tblPlayer WHERE (PlayerName Like """ & zTargetName & "*"") AND (PortID<>'" & zPortID & "' And PortID<>'' And PortID Is Not Null) AND (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
                        If (Not rsData.EOF) Then
                            lTargetID = MyCLng(rsData!PlayerID)
                            zTargetPortID = MyCStr(rsData!PortID)
                            bInvisOkay = ((MyCLng(rsData!InvisibilityDuration) = 0) Or (lDetectInvisibilityDuration > 0 And MyCLng(rsData!InvisibilityDuration) > 0))
                            If (bInvisOkay) Then
                                If (MyCLng(rsData!StunDuration) > 1) Then 'we do not check foor [BlindDuration] on purpose, stun is the trigger only here
                                    lRollA = lRandom(lOPlayerLevel + lOCINT)
                                    lRollB = lRandom(MyCLng(rsData!PlayerLevel))
                                    subSendMsg "&GM&gedical-&GA&gid rolls are: " & lRollA & "&G(lv+int) &wvs &g" & lRollB & "&G(lv)", zPortID
                                    If (lRollA >= lRollB) Then 'if the players attack level plus his full random dex beats the same the target tried to dodge but failed, defender wins ties.
                                        'bSuccess = True no point seeting it in code but its worth here is true, sorry about the pun, eh? ;)
                                        If (lRandom(33) = 1) Then
                                            MyDB.Execute "UPDATE tblPlayer SET [BlindDuration]=33, [StunDuration]=1 WHERE ([PlayerID]=" & lTargetID & ");", dbFailOnError
                                            subSendMsg "&RYou went from medical-aide to medical-blindness, &rahhhhhh&R!!", zTargetPortID
                                        Else
                                            MyDB.Execute "UPDATE tblPlayer SET [BlindDuration]=0, [StunDuration]=1 WHERE ([PlayerID]=" & lTargetID & ");", dbFailOnError
                                        End If
                                        'bSuccess = True
                                        subSendMsgAreaAllDISmart "&g", zOPlayerName, "%s1 medically-aide %s2.", MyCStr(rsData!PlayerName), "%s1 medically-aides %s2.", lOX, lOY, lOZ
                                    Else
                                        subSendMsg "&gYou fail to aid or revive " & MyCStr(rsData!PlayerName) & "!", zPortID
                                    End If
                                Else
                                    subSendMsg "&G" & MyCStr(rsData!PlayerName) & " is not stunned and does not need your aid.", zPortID
                                End If
                            Else
                                subSendMsg "&gAid whom?", zPortID
                            End If
                        Else
                            subSendMsg "&gAid whom?", zPortID
                        End If
                        Set rsData = Nothing
                        
                        If (lRandom(lOCCha) = 1) Then
                            MyDB.Execute "UPDATE tblPlayer SET [BlindDuration]=" & lRandom(5) + 5 & ", [StunDuration]=3, [CSoul]=1, [CMove]=1 WHERE (PlayerID=" & lOPlayerID & ");", dbFailOnError
                            subSendMsg "&RYour charming [" & lOCCha & "] powers to aid malfunctions in an &rEXP&WLOS&RIO&WN&R!", zPortID
                        End If
                    Else
                        subSendMsg "&gAid whom?", zPortID
                    End If
                Else
                    subSendMsg "&rYou are short " & lTotalSoulCost - lSoul & " souls", zPortID
                End If
            Else
                subSendMsg "&rYou are short " & lTotalMoveCost - lMove & " moves", zPortID
            End If
        Else
            subSendMsg "&GYou dream about helping out in a great battle.", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subCombatAid", zPortID
    End If
    'Debug.Print bSuccess
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatAid," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function subImmortalTeleport(zPortID As String, zWord2 As String, zWord3 As String, zWord4 As String)
On Error GoTo Err_Check
    Const bStatusBM = False
    Const cstlImmortalTeleportLevel = 9
    Dim bStatusGUID As Boolean
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zClass As String
    Dim zRace As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lInvisibilityDuration As Long
    Dim lStatus As Long
    Dim bPlayerFound As Boolean
    Dim lCMove As Long
    Dim lCSoul As Long
    Dim lPlayerID As Long
    Dim lBlindDuration As Long
    Dim lImmortalLevel As Long
    Dim lEntanglementDuration As Long
    Dim lPortID As Long
    Dim lPlayerLevel As Long
    
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, EntanglementDuration, ImmortalLevel, BlindDuration, Race, PlayerID, CMove, CSoul, InvisibilityDuration, Class, X, Y, Z, Status, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zClass = MyCStr(rsPlayer!Class)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lStatus = MyCLng(rsPlayer!Status)
        lCMove = MyCLng(rsPlayer!CMove)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        zRace = MyCStr(rsPlayer!Race)
    Else
        bPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    If (bPlayerFound) Then
        lPortID = MyCLng(zPortID)
        lTX = MyCLng(zWord2): lTY = MyCLng(zWord3): lTZ = MyCLng(zWord4)
        If (lImmortalLevel >= cstlImmortalTeleportLevel Or bImmortalPlayerWithInRadius(lPlayerID, lTX, lTY, lTZ)) Then
            If (lEntanglementDuration = 0) Then
                If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                    'Select Case zAreaRules(15, MyCLng(zWord(2)), MyCLng(zWord(3)), MyCLng(zWord(4)))
                    '    Case "0"
                    '        subSendMsg "&RThis is a no teleport zone.", zPortID
                    '    Case "1" 'Allowed
                            'subSendMsgAreaExcept2 gblzFBBLU & zPlayerName & " is enveloped in a puff of smoke and disappears!", lX, lY, lZ, zPortID, ""
                            MyDB.Execute "UPDATE tblPlayer SET tblPlayer.X = " & lTX & ", tblPlayer.Y = " & lTY & ", tblPlayer.Z = " & lTZ & " WHERE (((tblPlayer.PlayerID)=" & lPlayerID & "));", dbFailOnError
                            subSendMsg "&B[sneak] You see a blinding flash of &Ylight&B and arrive somewhere else.", zPortID
                            subUpdatePlayer lPlayerID 'Update player with area's information
                            bStatusGUID = gblbGraphicIDsOnOff(lPortID)
                            subAreaDesc 0, 0, zPortID, lTX, lTY, lTZ, lPlayerLevel, lPlayerID, 0, 0, zRace, zClass, "11111", 0, 1, bStatusBM, bStatusGUID, ""
                            'subSendMsgAreaExcept2 gblzFBBLU & zPlayerName & " appears from a puff of smoke!", MyCLng(zWord(2)), MyCLng(zWord(3)), MyCLng(zWord(4)), zPortID, ""
                    'End Select
                Else
                    subSendMsg "&gYou cannot do that while you are fighting! [try to FLEE]", zPortID
                End If
            Else
                subSendMsg "&yYou are too entangled to do that.", zPortID
            End If
        Else
            subSendMsg "&gHuh?", zPortID
        End If
    End If
    Exit Function
Err_Check:
    subWriteErrorFile "subImmortalTeleport," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function subCombatScan(zPortID As String, zScanRange As String, zType As String)
On Error GoTo Err_Check
    Dim rsAreas As Recordset
    Dim rsPlayer As Recordset
    Dim lScanRange As Long
    Dim zDirection As String
    Dim zHoldDirection As String
    Dim lSeeX As Long
    Dim lSeeY As Long
    Dim lSeeZ As Long
    Dim zCount As String
    Dim zGetType As String
    Dim lScanDistance As Long
    Dim zMoreInfo As String
    
    Dim zPlayerName As String
    Dim zClass As String
    Dim zRace As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lInvisibilityDuration As Long
    Dim lStatus As Long
    Dim bPlayerFound As Boolean
    Dim lCMove As Long
    Dim lCSoul As Long
    Dim lPlayerID As Long
    Dim lBlindDuration As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT BlindDuration, Race, PlayerID, CMove, CSoul, InvisibilityDuration, Class, X, Y, Z, Status, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zClass = MyCStr(rsPlayer!Class)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lStatus = MyCLng(rsPlayer!Status)
        lCMove = MyCLng(rsPlayer!CMove)
        lCSoul = MyCLng(rsPlayer!CSoul)
        zRace = MyCStr(rsPlayer!Race)
    Else
        bPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    If (bPlayerFound) Then
        If (lStatus = 5) Then
            If (lBlindDuration = 0) Then
                If (lCMove >= lTranslateSkillScanMoveCost(zClass)) Then
                    If (lCSoul >= lTranslateSkillScanSoulCost(zClass)) Then
                        zHoldDirection = ""
                        
                        lScanDistance = MyCLng(zScanRange)
                        
                        lScanRange = lTranslateClassScanArea(zClass)
                        If (lScanRange > 3 And lScanDistance = 0) Then lScanRange = 3 'we default small range
                        
                        If (lScanRange > lScanDistance And lScanDistance > 0) Then lScanRange = lScanDistance
                        
                        If (Len(zType) > 0) Then
                            zGetType = UCase(Mid(zType, 1, 1))
                        Else
                            If (MyCLng(zScanRange) = 0) Then zGetType = UCase(Mid(zScanRange, 1, 1))
                        End If
                        
                        subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 scan " & lScanRange & " areas!", zPlayerName, "%s1 scans " & lScanRange & " areas!", lX, lY, lZ
                        
                        MyDB.Execute "UPDATE tblPlayer SET CMove = " & (lCMove - lTranslateSkillScanMoveCost(zClass)) & ", CSoul = " & (lCSoul - lTranslateSkillScanSoulCost(zClass)) & " WHERE PlayerID=" & lPlayerID & ";", dbFailOnError
                        
                        If (zGetType = "" Or zGetType = "ALL" Or zGetType = "PLAY") Then
                            'cant scan invis or camo or immortals
                            Set rsAreas = MyDB.OpenRecordset("SELECT tblPlayer.PlayerName, tblArea.X, tblArea.Y, tblArea.Z, tblPlayer.PortID, tblPlayer.InvisibilityDuration, tblPlayer.HideDuration, tblPlayer.CamoflaguedDuration FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblPlayer.Y = tblArea.Y) AND (tblPlayer.X = tblArea.X) WHERE (((tblArea.X)>=" & lX - lScanRange & " And (tblArea.X)<=" & lX + lScanRange & ") AND ((tblArea.Y)>=" & lY - lScanRange & " And (tblArea.Y)<=" & lY + lScanRange & ") AND ((tblArea.Z)>=" & lZ - lScanRange & " And (tblArea.Z)<=" & lZ + lScanRange & ") AND ((tblPlayer.ImmortalLevel)=0) AND ((tblPlayer.PortID)<>'' And (tblPlayer.PortID)<>'0' And (tblPlayer.PortID) Is Not Null) AND ((tblPlayer.InvisibilityDuration)=0) AND ((tblPlayer.HideDuration)=0) AND ((tblPlayer.CamoflaguedDuration)=0)) ORDER BY tblArea.X, tblArea.Y, tblArea.Z;", dbOpenSnapshot)
                            If (Not rsAreas.EOF) Then
                                subSendMsg "&WSCANNING FOR PLAYERS" & vbCrLf & "----------------------------------------------", zPortID
                                Do While (Not rsAreas.EOF)
                                    zDirection = ""
                                    lSeeX = MyCLng(rsAreas!x)
                                    lSeeY = MyCLng(rsAreas!y)
                                    lSeeZ = MyCLng(rsAreas!z)
                                    If (lSeeZ < lZ) Then
                                        zDirection = zDirection & "U "
                                    End If
                                    If (lSeeZ > lZ) Then
                                        zDirection = zDirection & "D "
                                    End If
                                    If (lSeeY < lY) Then
                                        zDirection = zDirection & "N"
                                    End If
                                    If (lSeeY > lY) Then
                                        zDirection = zDirection & "S"
                                    End If
                                    If (lSeeX < lX) Then
                                        zDirection = zDirection & "W"
                                    End If
                                    If (lSeeX > lX) Then
                                        zDirection = zDirection & "E"
                                    End If
                                    If (lSeeY = lY And lSeeX = lX And lSeeZ = lZ) Then
                                        zDirection = "HERE"
                                    End If
                                    If (zHoldDirection <> zDirection) Then
                                        subSendMsg "&w" & strForceSize(UCase(zDirection), 5, " ", "A") & " - " & MyCStr(rsAreas!PlayerName), zPortID
                                    Else
                                        subSendMsg "&w      - " & MyCStr(rsAreas!PlayerName), zPortID
                                    End If
                                    zHoldDirection = zDirection
                                    rsAreas.MoveNext
                                Loop
                            End If
                            Set rsAreas = Nothing
                        End If
                        
                        If (zGetType = "" Or zGetType = "ALL" Or zGetType = "M" Or zGetType = "C") Then
                            Set rsAreas = MyDB.OpenRecordset("SELECT Count(tblMob.MobID) AS CountOfMobID, tblMob.MobName, tblArea.X, tblArea.Y, tblArea.Z, tblMob.RespawnDelay, tblMob.Invisible FROM tblMob INNER JOIN tblArea ON (tblMob.X = tblArea.X) AND (tblMob.Y = tblArea.Y) AND (tblMob.Z = tblArea.Z) GROUP BY tblMob.MobName, tblArea.X, tblArea.Y, tblArea.Z, tblMob.RespawnDelay, tblMob.Invisible HAVING (((tblArea.X)>=" & lX - lScanRange & " And (tblArea.X)<=" & lX + lScanRange & ") AND ((tblArea.Y)>=" & lY - lScanRange & " And (tblArea.Y)<=" & lY + lScanRange & ") AND ((tblArea.Z)>=" & lZ - lScanRange & " And (tblArea.Z)<=" & lZ + lScanRange & ") AND ((tblMob.RespawnDelay)=0)) ORDER BY tblArea.X, tblArea.Y, tblArea.Z;", dbOpenSnapshot)
                            If (Not rsAreas.EOF) Then
                                subSendMsg "&WSCANNING FOR MOBS" & vbCrLf & "----------------------------------------------", zPortID
                                Do While (Not rsAreas.EOF)
                                    zDirection = ""
                                    lSeeX = MyCLng(rsAreas!x)
                                    lSeeY = MyCLng(rsAreas!y)
                                    lSeeZ = MyCLng(rsAreas!z)
                                    If (lSeeZ < lZ) Then
                                        zDirection = zDirection & "U "
                                    End If
                                    If (lSeeZ > lZ) Then
                                        zDirection = zDirection & "D "
                                    End If
                                    If (lSeeY < lY) Then
                                        zDirection = zDirection & "N"
                                    End If
                                    If (lSeeY > lY) Then
                                        zDirection = zDirection & "S"
                                    End If
                                    If (lSeeX < lX) Then
                                        zDirection = zDirection & "W"
                                    End If
                                    If (lSeeX > lX) Then
                                        zDirection = zDirection & "E"
                                    End If
                                    If (lSeeY = lY And lSeeX = lX And lSeeZ = lZ) Then
                                        zDirection = "HERE"
                                    End If
                                    
                                    zCount = ""
                                    If (MyCLng(rsAreas!CountOfMobID) > 1) Then
                                        zCount = " (" & MyCLng(rsAreas!CountOfMobID) & ")"
                                    End If
                                    
                                    zMoreInfo = ""
                                    If (MyCInt(rsAreas!Invisible) <> 0) Then
                                        zMoreInfo = "(invis) [you can hear whatever it is]" 'I didnt implement so player's have to have detect invis on, on purpose
                                    Else
                                        zMoreInfo = zShortstop(MyCStr(rsAreas!MobName))
                                    End If
                                    
                                    If (zHoldDirection <> zDirection) Then
                                        subSendMsg "&w" & strForceSize(UCase(zDirection), 5, " ", "A") & " - " & zMoreInfo & zCount, zPortID
                                    Else
                                        subSendMsg "&w      - " & zMoreInfo & zCount, zPortID
                                    End If
                                    zHoldDirection = zDirection
                                    rsAreas.MoveNext
                                Loop
                            End If
                            Set rsAreas = Nothing
                        End If
                        
                        If (zRace = "FEL" Or zClass = "TH" Or zClass = "BA" Or zClass = "GY") Then 'only thieves can see objects laying around
                            If (zGetType = "" Or zGetType = "ALL" Or zGetType = "O" Or zGetType = "I") Then
                                Set rsAreas = MyDB.OpenRecordset("SELECT Count(tblObject.ObjectID) AS CountOfObjectID, tblObject.ObjectName, tblArea.X, tblArea.Y, tblArea.Z, tblObject.Status, tblObject.Burried, tblObject.Location FROM tblObject INNER JOIN tblArea ON (tblObject.X = tblArea.X) AND (tblObject.Y = tblArea.Y) AND (tblObject.Z = tblArea.Z) GROUP BY tblObject.ObjectName, tblArea.X, tblArea.Y, tblArea.Z, tblObject.Status, tblObject.Burried, tblObject.Location HAVING (((tblArea.X)>=" & lX - lScanRange & " And (tblArea.X)<=" & lX + lScanRange & ") AND ((tblArea.Y)>=" & lY - lScanRange & " And (tblArea.Y)<=" & lY + lScanRange & ") AND ((tblArea.Z)>=" & lZ - lScanRange & " And (tblArea.Z)<=" & lZ + lScanRange & ") AND ((tblObject.Status)=0) AND ((tblObject.Burried)=False)) ORDER BY tblArea.X, tblArea.Y, tblArea.Z;", dbOpenSnapshot)
                                If (Not rsAreas.EOF) Then
                                    subSendMsg "&WSCANNING FOR ITEMS" & vbCrLf & "----------------------------------------------", zPortID
                                    Do While (Not rsAreas.EOF)
                                        zDirection = ""
                                        lSeeX = MyCLng(rsAreas!x)
                                        lSeeY = MyCLng(rsAreas!y)
                                        lSeeZ = MyCLng(rsAreas!z)
                                        If (lSeeZ < lZ) Then
                                            zDirection = zDirection & "U "
                                        End If
                                        If (lSeeZ > lZ) Then
                                            zDirection = zDirection & "D "
                                        End If
                                        If (lSeeY < lY) Then
                                            zDirection = zDirection & "N"
                                        End If
                                        If (lSeeY > lY) Then
                                            zDirection = zDirection & "S"
                                        End If
                                        If (lSeeX < lX) Then
                                            zDirection = zDirection & "W"
                                        End If
                                        If (lSeeX > lX) Then
                                            zDirection = zDirection & "E"
                                        End If
                                        If (lSeeY = lY And lSeeX = lX And lSeeZ = lZ) Then
                                            zDirection = "HERE"
                                        End If
                                        
                                        zCount = ""
                                        If (MyCLng(rsAreas!CountOfObjectID) > 1) Then
                                            zCount = " (" & MyCLng(rsAreas!CountOfObjectID) & ")"
                                        End If
                                        
                                        If (zHoldDirection <> zDirection) Then
                                            subSendMsg "&w" & strForceSize(UCase(zDirection), 5, " ", "A") & " - " & (MyCStr(rsAreas!ObjectName)) & zCount, zPortID
                                        Else
                                            subSendMsg "&w      - " & (MyCStr(rsAreas!ObjectName)) & zCount, zPortID
                                        End If
                                        zHoldDirection = zDirection
                                        rsAreas.MoveNext
                                    Loop
                                End If
                                Set rsAreas = Nothing
                            End If
                        End If
                        If (zGetType = "") Then subSendMsg "&WSCAN MOBS or SCAN OBJECTS to narrow down your search.", zPortID
                    Else
                        subSendMsg "&gYou require " & (lTranslateSkillScanSoulCost(zClass) - lCSoul) & " more soul points.", zPortID
                    End If
                Else
                    subSendMsg "&gYou require " & (lTranslateSkillScanMoveCost(zClass) - lCMove) & " more move points.", zPortID
                End If
            Else
                subSendMsg "&RYou cannot scan when you are blind!", zPortID
            End If
        Else
            subSendMsg "&GYou must stand at ease to scan.", zPortID
        End If
    Else
        subSendMsg "&RERROR! Your player file was not found! Report this to an immortal!", zPortID
    End If
    Exit Function
Err_Check:
    subWriteErrorFile "subCombatScan," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subCombatPlayerFlee(zPortID As String)
On Error GoTo Err_Check
    Const cstlFleeXPCost = 5 'added on
    Dim lPortID As Long
    Dim lTotalFleeCost As Long
    Dim bStatusBM As Boolean
    Dim bStatusGUID As Boolean
    Dim rsPlayer As Recordset
    Dim bTryingToFlee As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    
    Dim rsAreas As Recordset
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long

    Dim iCount As Integer
    Dim bMoveSuccess As Boolean
    Dim iResultMomentumEngineXYZ As Integer
    Dim lCalcuMoveNeeded As Long
    Dim lXP As Long
    
    Dim lPlayerID As Long
    Dim lStatus As Long
    Dim zPlayerConfig As String
    Dim lBlindDuration As Long
    Dim lAreaTrapDuration As Long
    Dim lEntanglementDuration As Long
    Dim lCMove As Long
    Dim lPlayerLevel As Long
    Dim lStunDuration As Long
    Dim zPlayerName As String
    
    lPortID = MyCLng(zPortID) 'fleeing player's port
    If (rSCombat(lPortID).iStatus <> cstiStatusNotInBattleMode) Then
        bStatusBM = gblbFilterMode(lPortID)
        bStatusGUID = gblbGraphicIDsOnOff(lPortID)
        Set rsPlayer = MyDB.OpenRecordset("SELECT Config, CMove, BlindDuration, StunDuration, AreaTrapDuration, EntanglementDuration, PlayerFleeDuration, DetectInvisibilityDuration, X, Y, Z, Status, PortID, PlayerID, PlayerName, SitObjectID, Class, Race, PlayerLevel, XP FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lStunDuration = MyCLng(rsPlayer!StunDuration)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
            lAreaTrapDuration = MyCLng(rsPlayer!AreaTrapDuration)
            lBlindDuration = MyCLng(rsPlayer!BlindDuration)
            lCMove = MyCLng(rsPlayer!CMove)
            
            If (lStunDuration = 0) Then
                If (lEntanglementDuration = 0) Then
                    If (lAreaTrapDuration = 0) Then
                        If (lBlindDuration = 0) Then
                            lCalcuMoveNeeded = MyCLng(lPlayerLevel / 4) + (4 * cstlFleeXPCost)
                            If (lCMove >= lCalcuMoveNeeded) Then
                                If (lStatus <> 50) Then
                                    zPlayerName = MyCStr(rsPlayer!PlayerName)
                                    lX = MyCLng(rsPlayer!x)
                                    lY = MyCLng(rsPlayer!y)
                                    lZ = MyCLng(rsPlayer!z)
                                    
                                    If (lPlayerLevel < 20) Then
                                        lTotalFleeCost = 10
                                    Else
                                        lTotalFleeCost = (MyCLng(lPlayerLevel / 4) + cstlFleeXPCost) + 5
                                    End If
                                    lXP = MyCLng(rsPlayer!XP)
                                    
                                    If (lXP >= lTotalFleeCost) Then
                                        lStatus = MyCLng(rsPlayer!Status)
                                        zPlayerConfig = MyCStr(rsPlayer!Config)
                                        
                                        'we set the mob so it cant be stolen from so players cant exploit: flee then steal then flee then steal
                                        MyDB.Execute "UPDATE tblMob SET StealDelay=50+" & lRandom(50) & " WHERE (MobID=" & rMCombat(lPortID).lID & " AND RespawnDelay=0);", dbFailOnError
                                        
                                        'Get the area X Y Z around the Mob X Y Z - now we have places to move to.
                                        Set rsAreas = MyDB.OpenRecordset("SELECT X, Y, Z FROM tblArea WHERE (X=" & lX & " OR X=" & lX - 1 & " OR X=" & lX + 1 & ") AND (Y=" & lY & " OR Y=" & lY - 1 & " OR Y=" & lY + 1 & ") AND (Z=" & lZ & " OR Z=" & lZ - 1 & " OR Z=" & lZ + 1 & ") AND (NoFleeZone=False);", dbOpenSnapshot)
                                        If (Not rsAreas.EOF) Then
                                            bMoveSuccess = False
                                            Do While (Not rsAreas.EOF And Not bMoveSuccess)  'We look at all the areas here and try to go there.
                                                lTX = MyCLng(rsAreas!x)
                                                lTY = MyCLng(rsAreas!y)
                                                lTZ = MyCLng(rsAreas!z)
                                                If (bAreaMovementAllowed(lTX, lTY, lTZ, lX, lY, lZ, 0)) Then
                                                    'we test to make sure we are allowed to move there
                                                    iResultMomentumEngineXYZ = iMomentumEngineXYZ(zTranslateMatrixDirection(lTX, lTY, lTZ, lX, lY, lZ, 1), True, bStatusBM, bStatusGUID, zPortID)
                                                    'subMessagesMovementResult iResultMomentumEngineXYZ, MyCStr(rsPlayer!PortID)
                                                    
                                                    If (iResultMomentumEngineXYZ = 0) Then
                                                        bMoveSuccess = True
                                                        lPlayerID = MyCLng(rsPlayer!PlayerID)
                                                        MyDB.Execute "UPDATE tblPlayer SET SitObjectID=0, Status=5, PlayerFleeDuration=" & lRandom(4) + 2 & ", XP=" & (lXP - lTotalFleeCost) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        
                                                        For iCount = cstlMinPort To cstlMaxPort 'If this player is fleeing from a combat P v P then we find all the player attacking him and stop it
                                                            If (rPCombat(iCount).lID = lPlayerID) Then
                                                                MyDB.Execute "UPDATE tblPlayer SET Status=5 WHERE (PortID='" & MyCStr(iCount) & "');", dbFailOnError
                                                                rPCombat(iCount).lID = 0
                                                                rSCombat(iCount).iStatus = cstiStatusNotInBattleMode
                                                            End If
                                                        Next iCount
                                                        
                                                        'We turn off any fighting with any mobs
                                                        subCombatEndedInitializeCombatCellsPortID lPortID
                                                        subSendMsg "&gFleeing costed you " & lTotalFleeCost & " experience points!", zPortID
                                                    End If
                                                End If
                                                rsAreas.MoveNext
                                            Loop
                                            
                                            If (Not bMoveSuccess) Then
                                                subSendMsg "&RYou fail to escape! Noooooooooooo!", zPortID
                                            Else
                                                subClearPortTotalXP MyCLng(zPortID)
                                            End If
                                        Else
                                            subSendMsg "&RYou fail to escape! Noooooooooooo!", zPortID
                                        End If
                                        Set rsAreas = Nothing
                                    Else
                                        subSendMsg "&RYou do not have the required " & lTotalFleeCost & " experience points to flee.", zPortID
                                    End If
                                Else
                                    subSendMsg "&GYou dream of running from trouble.", zPortID
                                End If
                            Else
                                subSendMsg "&RARRRrrrrrg! You need at least " & lCalcuMoveNeeded & " move to flee!", zPortID
                            End If
                        Else
                            subSendMsg "&RYou are blind and cannot see to flee - OH NO!.", zPortID
                        End If
                    Else
                        subSendMsg "&RYou are trapped you cannot flee!", zPortID
                    End If
                Else
                    subSendMsg "&RYour legs are entangled you cannot flee!", zPortID
                End If
            Else
                subSendMsg "&RYou are too stunned to flee!", zPortID
            End If
        End If
        Set rsPlayer = Nothing
    Else
        subSendMsg "&gYou can only flee during combat!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatPlayerFlee," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalStopAuction(zPortID As String, zType As String)
On Error GoTo Err_Check
    Dim rsAuctionCheck As Recordset
    Dim rsObject As Recordset
    Dim zObjectName As String
    
    Set rsAuctionCheck = MyDB.OpenRecordset("SELECT * FROM tblAuction;", dbOpenDynaset)
    If (Not rsAuctionCheck.EOF) Then 'there is something in auction go get it
        Set rsObject = MyDB.OpenRecordset("SELECT ObjectID, ObjectName FROM tblObject WHERE (ObjectID=" & MyCLng(rsAuctionCheck!ObjectID) & ");", dbOpenSnapshot)
        If (Not rsObject.EOF) Then
            zObjectName = zShortstop(MyCStr(rsObject!ObjectName))
            Select Case zType
                Case "S"
                    subAuctoneerChannel "Auctioneer yells, 'I just stopped this nonsense auction.'"
                    subAuctoneerChannel "Everything was returned to its owner."
                    'Mark Object property of the new player.
                    MyDB.Execute "UPDATE tblObject SET tblObject.Status = 2, tblObject.PlayerID = " & MyCLng(rsAuctionCheck!OwnerPlayerID) & " WHERE (((tblObject.ObjectID)=" & MyCLng(rsAuctionCheck!ObjectID) & "));", dbFailOnError
                    'Transfer object to buyer
                    MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & MyCLng(rsAuctionCheck!OwnerPlayerID) & ", " & MyCLng(rsAuctionCheck!ObjectID) & ";", dbFailOnError
                    
                    MyDB.Execute "DELETE * FROM tblAuction;", dbFailOnError
                Case Else
                    subSendMsg "&r(EYE) &yAUCTION - Seller: " & zReturnPlayerName(rsAuctionCheck!OwnerPlayerID) & " Bidder: " & zReturnPlayerName(rsAuctionCheck!BidderPlayerID) & ".", zPortID
            End Select
        Else
            MyDB.Execute "DELETE * FROM tblAuction;", dbFailOnError
            subSendMsg "&RThe item could not be found in the Auction table!", zPortID
        End If
        Set rsObject = Nothing
    Else
        subSendMsg "&gThere is nothing up at the auction.", zPortID
    End If
    Set rsAuctionCheck = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalStopAuction," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subTryToSendInfoLine(lChance As Long)
On Error GoTo Err_Check
    Dim rsInfo As Recordset
    Dim lTotal As Long
    If (lRandom(lChance) = 1) Then
        lTotal = lngSQLRecordCount("SELECT * FROM tblSystemInfoLine;")
        Set rsInfo = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotal) & " InfoLine FROM tblSystemInfoLine;", dbOpenSnapshot)
        If (Not rsInfo.EOF) Then
            rsInfo.MoveLast 'we just random info once in awhile
            If (Mid(MyCStr(rsInfo!InfoLine), 1, 1) = "@") Then
                subSendMsgInfoChannel MyCStr(rsInfo!InfoLine)
            Else
                subSendMsgInfoChannel "&w" & MyCStr(rsInfo!InfoLine)
            End If
        End If
        Set rsInfo = Nothing
    Else 'if we fail to try to retrieve one from the data base we try to just have the mud send something
        Select Case lRandom(2000 + lChance)
            Case 1
                subSendMsgInfoChannel "GO EASY ON EACHOTHER OUT THERE"
            Case 2
                subSendMsgInfoChannel "NO SWEARING - THANK YOU"
            Case 3
                subSendMsgInfoChannel "NO PUBLICLY DISPLAYED ARGUMENTS - THANK YOU"
            Case 4
                subSendMsgInfoChannel "NO YELLING - THANK YOU"
            Case 5
                subSendMsgInfoChannel "THANK YOU FOR USING OTHER CHANNELS TO FURTHER YOUR DISCUSSIONS"
            Case 6
                subSendMsgInfoChannel "TIME HEALS ALL WOUNDS"
            Case 7
                subSendMsgInfoChannel "IT IS APPRECIATED BY EVERYONE TO ENFORCE OUR REALM RULES"
            Case 8
                subSendMsgInfoChannel "CHOOSE TO BE POLITE AND COURTEOUS AND FRIENDLY"
            Case 9
                subSendMsgInfoChannel "DON'T WORRY ... BE HAPPY"
            Case 10
                subSendMsgInfoChannel "READ THE RULES: HELP [RULA/RULB/RULC/RULD]"
            Case 11
                subSendMsgInfoChannel "GO DO SOME QUESTS! At the Oracle (ne of x0 y0 z0) type QUEST GO."
            Case 12
                subSendMsgInfoChannel "TIME HEALS ALL WOUNDS"
            Case 13
                subSendMsgInfoChannel "YOU ARE HERE to RELAX AND ALWAYS HAVE FUN"
            Case 14
                subSendMsgInfoChannel "REFRAIN FROM EXAGGERATION OR TRICKING ANYONE INTO ANYTHING THANK YOU"
            Case 15
                subSendMsgInfoChannel "WE HOPE THE REALM IS FUN ENOUGH TO PLAY EVEN WHEN YOU ARE ALONE"
            Case 16
                subSendMsgInfoChannel "GLOBAL CHANNELS ARE NOT MEANT FOR TWO WAY CONVERSATIONS - THANK YOU"
        End Select
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subTryToSendInfoLine," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subTrainAnimal(zWord2 As String, zWord3 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lPlayerLevel As Long
    Dim lGold As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim zClass As String
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,X,Y,Z,PlayerName,Class,PlayerLevel,Gold,Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lGold = MyCLng(rsPlayer!Gold)
        zClass = MyCStr(rsPlayer!Class)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        subPlayerSkillsTrain zPlayerName, lPlayerID, lX, lY, lZ, zPortID, UCase(MyCStr(zWord2)), UCase(MyCStr(zWord3)), lPlayerLevel, zClass, lStatus
    Else
        subSendMsg "&RPlayer File not found :: subTrainAnimal", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subTrainAnimal," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subTrainAnimalControl(zWord1 As String, zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lPlayerLevel As Long
    Dim lInvisibilityDuration As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,X,Y,Z,PlayerName,PlayerLevel,InvisibilityDuration,Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        Select Case UCase(Mid(zWord1, 1, 1))
            Case "D", "U" 'dismount/unmount
                subPlayerPositionUnMount zPlayerName, lPlayerID, lX, lY, lZ, zPortID, lStatus
            Case "M", "R" 'mount/ride a pet
                If (Len(zWord2) > 0) Then
                    subPlayerPositionMountPet lPlayerID, zPlayerName, lX, lY, lZ, zWord2, lStatus, lInvisibilityDuration, zPortID
                Else
                    subPlayerPositionUnMount zPlayerName, lPlayerID, lX, lY, lZ, zPortID, lStatus
                End If
        End Select
    Else
        subSendMsg "&RPlayer File not found :: subTrainAnimalControl", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subTrainAnimalControl," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subAuctoneerChannel(zMessage As String)
On Error GoTo Err_Check
'Sends a message to all ports EXCEPT the one designated
    Dim iCount As Integer
    Dim zFSPortID As String
    
    For iCount = cstlMinPort To cstlMaxPort
        zFSPortID = MyCStr(iCount) 'player is in the mud and fully logged in
        If (gbliAuctionChannelStatus(iCount)) Then
            If (gbliFlow(iCount) > 99) Then 'is the user fully logged in and in the game or at the login screen?
                subSendMsg "&w" & (zMessage), zFSPortID    'This is so those logging on are not interrupted by messages.
            End If
        Else
            If (lRandom(4) = 1) Then subSendMsg "&wYou can hear something going on at the auction.", zFSPortID
        End If
    Next iCount
    Exit Sub
Err_Check:
    subWriteErrorFile "subAuctoneerChannel," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bPartOfAuction(zPortID As String, lPlayerID As Long) As Boolean
On Error GoTo Err_Check
    Dim rsAuction As Recordset
    Set rsAuction = MyDB.OpenRecordset("SELECT * FROM tblAuction WHERE (BidderPlayerID=" & lPlayerID & " OR OwnerPlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    bPartOfAuction = (Not rsAuction.EOF)
    Set rsAuction = Nothing
    Exit Function
Err_Check:
    subWriteErrorFile "bPartOfAuction," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subAuctionBidLoad(zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim lGold As Long
    Dim lStatus As Long
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,Gold,Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lGold = MyCLng(rsPlayer!Gold)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        subAuctionBid zWord2, lPlayerID, lGold, lStatus, zPortID
    Else
        subSendMsg "&RPlayer file not found :: subAuctionBidLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subAuctionBidLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subAuctionBid(zWord2 As String, lPlayerID As Long, lGold As Long, lStatus As Long, zPortID As String)
'See also. bPartofAuction
On Error GoTo Err_Check
    Dim rsAuction As Recordset
    Dim rsPlayer As Recordset
    Dim rsBidder As Recordset
    Dim lBetAmt As Long
    Dim lLastBidPlayerID As Long
    Dim lLastBidAmt As Long
    Dim lBetAmtGoal As Long
    
    If (lStatus <> 50) Then
        Set rsAuction = MyDB.OpenRecordset("SELECT * FROM tblAuction;", dbOpenDynaset)
        If (Not rsAuction.EOF) Then
            lBetAmt = MyCLng(zWord2) 'what the player wants to bid
            lLastBidAmt = MyCLng(rsAuction!Gold) 'what the last bid was
            lLastBidPlayerID = MyCLng(rsAuction!BidderPlayerID)
            lBetAmtGoal = MyCLng(lLastBidAmt * 1.3) + 10
            If (lBetAmt <= lGold) Then
                Set rsPlayer = MyDB.OpenRecordset("SELECT OwnerPlayerID FROM tblAuction WHERE (OwnerPlayerID=" & lPlayerID & ");", dbOpenSnapshot)
                If (Not rsPlayer.EOF) Then
                    subSendMsg "&RYou may not bid on your own auction item.", zPortID
                Else
                    Set rsBidder = MyDB.OpenRecordset("SELECT BidderPlayerGold, BidderPlayerID FROM tblAuction WHERE (BidderPlayerID=" & lPlayerID & ");", dbOpenSnapshot)
                    If (Not rsBidder.EOF) Then
                        subSendMsg "&RThe last bid is your bid, please be patient.", zPortID
                    Else
                        If (lBetAmt < lBetAmtGoal) Then
                            subSendMsg "&wNext accepted bid: " & lBetAmtGoal & " gold.", zPortID
                        Else
                            rsAuction.Edit
                            rsAuction!BidderPlayerID = lPlayerID
                            rsAuction!BidderPlayerGold = lBetAmt
                            rsAuction!Gold = lBetAmt
                            rsAuction!BidTurn = 0
                            rsAuction.Update
                            subSendMsg "&GYou place a bid on the item at the auction!", zPortID
                            subAuctoneerChannel "Auctioneer informs, 'We have a bid on the item for " & lBetAmt & " gold!"
                            If (lLastBidPlayerID <> 0) Then MyDB.Execute "UPDATE tblPlayer SET Gold=[Gold]+" & lLastBidAmt & " WHERE PlayerID=" & lLastBidPlayerID & ";", dbFailOnError 'return the gold to the previousbidder
                            MyDB.Execute "UPDATE tblPlayer SET Gold=[Gold]-" & lBetAmt & " WHERE PlayerID=" & lPlayerID & ";", dbFailOnError 'remove the gold from the bidder and put it on reserve
                        End If
                    End If
                    Set rsBidder = Nothing
                End If
                Set rsPlayer = Nothing
            Else
                subSendMsg "&RYou don't have that much gold!", zPortID
            End If
        Else
            subSendMsg "&GThere is nothing at the auction to bid on.", zPortID
        End If
        Set rsAuction = Nothing
    Else
        subSendMsg "&GYou are asleep and cannot do that.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subAuctionBid," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDoorOpenClose(zWord1 As String, zWord2 As String, zPortID As String)
On Error GoTo Err_Check 'zWord2 is the Direction ie. OPEN NORTH
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,X,Y,Z,PlayerName,Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing

    If (bFound) Then
        Select Case Mid(zWord1, 1, 1)
            Case "O", "o"
                subDoorOpen zPortID, zPlayerName, zWord2, lX, lY, lZ, lPlayerID, lStatus
            Case "C", "c"
                subDoorClose zPortID, zPlayerName, zWord2, lX, lY, lZ, lPlayerID, lStatus
            Case Else
                subSendMsg "&RDo what now?", zPortID
        End Select
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDoorOpenClose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subAuctionLoad(zWord2 As String, zWord3 As String, zPortID As String)
On Error GoTo Err_Check 'subAuction zWord(2), zWord(3), zPortID, lPlayerID, lStatus
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    If (bFound) Then
        subAuction zWord2, zWord3, lPlayerID, lStatus, zPortID
    Else
        subSendMsg "&RPlayer File not found :: subAuctionLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subAuctionLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subAuction(zWord2 As String, zWord3 As String, lPlayerID As Long, lStatus As Long, zPortID As String)
'See also. bPartofAuction
On Error GoTo Err_Check
    Dim rsAuction As Recordset
    Dim rsPlayer As Recordset
    Dim lAppraisalValue As Long
    Dim lTopSearch As Long
    Dim zSearchWord2 As String
    Dim lPlayerObjectID As Long
    
    'If (lStatus <> 50) Then
        Set rsAuction = MyDB.OpenRecordset("SELECT * FROM tblAuction;", dbOpenSnapshot)
        If (rsAuction.EOF) Then
            lAppraisalValue = 1000000
            If (Len(zWord3) < 7) Then
                If (MyCLng(zWord3) <= lAppraisalValue) Then
                    If (MyCLng(zWord3) > 0) Then
                        zSearchWord2 = zWord2
                        lTopSearch = lTop(zSearchWord2)
                        
                        Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lTopSearch & " tblPlayerInventoryItems.PlayerID, tblObject.ReturnPlayerID, tblObject.Cursed, tblObject.AuctionAllowed, tblObject.MurderPlayerHeart, tblPlayerInventoryItems.ObjectID, tblObject.ObjectName, tblObject.RottingRounds FROM tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.ObjectName) Like ""*" & zSearchWord2 & "*"")) ORDER BY tblObject.ObjectID;", dbOpenSnapshot)
                        If (Not rsPlayer.EOF) Then
                            rsPlayer.MoveLast
                            lPlayerObjectID = MyCLng(rsPlayer!ObjectID)
                            If (lContainerItemContentTotal(lPlayerObjectID) = 0) Then
                                lAppraisalValue = MyCLng(vReturnObjectValue(lPlayerObjectID, 2))
                                If (lAppraisalValue < 1) Then lAppraisalValue = 1
                                If (MyCLng(zWord3) <= (lAppraisalValue * 3)) Then
                                    If (MyCLng(rsPlayer!ReturnPlayerID) = 0 And MyCLng(rsPlayer!Cursed) = 0 And MyCLng(rsPlayer!RottingRounds) = 0 And MyCInt(rsPlayer!AuctionAllowed) <> 0 And MyCInt(rsPlayer!MurderPlayerHeart) = 0) Then
                                        MyDB.Execute "INSERT INTO tblAuction ( OwnerPlayerID, BidderPlayerID, ObjectID, Gold ) SELECT " & lPlayerID & ", 0, " & lPlayerObjectID & ", " & MyCLng(zWord3) & ";", dbFailOnError 'append to the auction
                                        MyDB.Execute "DELETE tblPlayerInventoryItems.PlayerID, tblPlayerInventoryItems.ObjectID FROM tblPlayerInventoryItems WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerInventoryItems.ObjectID)=" & lPlayerObjectID & "));", dbFailOnError 'remove the item from the player's inventory
                                        subSendMsg "&WThe auction will begin for the public shortly." & vbCrLf & "The free estimate is: " & vbCrLf & vReturnObjectValue(lPlayerObjectID, 1), zPortID
                                    Else
                                        subSendMsg "&gYou cannot auction that.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gThe most that item can auction for is " & (lAppraisalValue * 3) & " gold.", zPortID
                                End If
                            Else
                                subSendMsg "&gYou cannot auction a container with contents.", zPortID
                            End If
                        Else
                            subSendMsg "&RThat was not found in your inventory to place on the auction.", zPortID
                        End If
                        Set rsPlayer = Nothing
                    Else
                        subSendMsg "&gSYNTAX: AUCTION ObjectName HowMuchInGold", zPortID
                    End If
                Else
                    subSendMsg "&gSYNTAX: AUCTION ObjectName HowMuchInGold" & vbCrLf & "HowMuchInGold cannot be more than 1000000 gold.", zPortID
                End If
            Else
                subSendMsg "&gSYNTAX: AUCTION ObjectName HowMuchInGold" & vbCrLf & "HowMuchInGold cannot be more than 1000000 gold.", zPortID
            End If
        Else
            'if an object deletes before the auction is completed the next check will fix it
            'if the stock doesnt have a object matching then we delete the auction
            If (lngSQLRecordCount("SELECT tblObject.ObjectID FROM tblObject WHERE (((tblObject.ObjectID)=" & MyCLng(rsAuction!ObjectID) & "));") = 0) Then
               'if there is no link to the object from the auction we delete the auction and start over
               
               MyDB.Execute "DELETE ObjectID FROM tblAuction;", dbFailOnError
               
               subSendMsg "&GThe auction was cleared, you may now auction your item.", zPortID
            Else
                If (Len(zSearchWord2) > 0) Then
                    subSendMsg "&GThere is something already up for auction." & vbCrLf & "Try your auction again after this one has passed.", zPortID
                Else
                    subSendMsg "&BYou gaze up at the item hovering amongst the clouds.", zPortID
                End If
                subIdentifyObjectID MyCLng(rsAuction!ObjectID), zPortID, False
                subSendMsg "&B" & zObjectWearRequirements(MyCLng(rsAuction!ObjectID)), zPortID
            End If
        End If
        Set rsAuction = Nothing
    'Else
    '    subSendMsg "&GYou are asleep and cannot do that.", zPortID
    'End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subAuction," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCheckAndRunAuction()
On Error GoTo Err_Check
    Dim zObjectName As String
    Dim rsObject As Recordset
    Dim rsAuctionCheck As Recordset
    Dim lLastBidAmt As String
    Dim zMinBid As String
    
    Set rsAuctionCheck = MyDB.OpenRecordset("SELECT * FROM tblAuction;", dbOpenDynaset)
    If (Not rsAuctionCheck.EOF) Then 'there is something in auction go get it
        lLastBidAmt = MyCStr(MyCLng(rsAuctionCheck!Gold))
        Set rsObject = MyDB.OpenRecordset("SELECT ObjectID, ObjectName FROM tblObject WHERE (ObjectID=" & MyCLng(rsAuctionCheck!ObjectID) & ");", dbOpenSnapshot)
        If (Not rsObject.EOF) Then
            zObjectName = MyCStr(rsObject!ObjectName)
            If (MyCLng(rsAuctionCheck!BidTurn) = 4) Then
                Select Case (MyCLng(rsAuctionCheck!BidderPlayerID))
                    Case 0 'no bidders
                        'gbliAuctionChannelStatus
                        subAuctoneerChannel "Auctioneer informs, '" & zShortstop(zObjectName) & " was returned to the owner.'"
                        'Return object to owner
                        MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & MyCLng(rsAuctionCheck!OwnerPlayerID) & ", " & MyCLng(rsAuctionCheck!ObjectID) & ";", dbFailOnError
                    Case Else
                        subAuctoneerChannel "Auctioneer yells, '" & zShortstop(zObjectName) & " SOLD for " & MyCLng(rsAuctionCheck!Gold) & " gold. The object was transfered from the owner to the buyer.'"
                        'Transfer the gold.
                        MyDB.Execute "UPDATE tblPlayer INNER JOIN tblAuction ON tblPlayer.PlayerID = tblAuction.OwnerPlayerID SET tblPlayer.Gold = [tblPlayer].[Gold]+[tblAuction].[Gold];", dbFailOnError 'give to seller
                        'we take the gold when the person bids  -- MyDB.Execute "UPDATE tblPlayer INNER JOIN tblAuction ON tblPlayer.PlayerID = tblAuction.BidderPlayerID SET tblPlayer.Gold = [tblPlayer].[Gold]-[tblAuction].[Gold];", dbFailOnError 'take from bidder
                        'Mark Object property of the new player.
                        MyDB.Execute "UPDATE tblObject SET tblObject.Status = 2, tblObject.PlayerID = " & MyCLng(rsAuctionCheck!BidderPlayerID) & " WHERE (((tblObject.ObjectID)=" & MyCLng(rsAuctionCheck!ObjectID) & "));", dbFailOnError
                        'Transfer object to buyer
                        MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & MyCLng(rsAuctionCheck!BidderPlayerID) & ", " & MyCLng(rsAuctionCheck!ObjectID) & ";", dbFailOnError
                End Select
                'Now remove object from auction
                MyDB.Execute "DELETE * FROM tblAuction;", dbFailOnError
            Else
                'Message object for auction and keep going.
                rsAuctionCheck.Edit
                rsAuctionCheck!BidTurn = MyCLng(rsAuctionCheck!BidTurn) + 1
                rsAuctionCheck.Update
                zMinBid = " Min-Bid[" & MyCStr(MyCLng(lLastBidAmt * 1.3) + 10) & "gold]"
                Select Case (MyCLng(rsAuctionCheck!BidderPlayerID))
                    Case 0 'no bidders yet...
                        subAuctoneerChannel "&wAUCTION ITEM&W[&G" & (4 - MyCStr(rsAuctionCheck!BidTurn)) & "&W]&w [" & zShortstop(zObjectName) & "]" & zMinBid
                    Case Else 'someone made a bid
                        Select Case MyCLng(rsAuctionCheck!BidTurn)
                            Case 1
                                'subAuctoneerChannel "Auctioneer yells, '" & zShortstop(zObjectName) & " going once for " & MyCLng(rsAuctionCheck!Gold) & " gold.'" & zMinBid
                                subAuctoneerChannel "&WAUCTION ITEM&w[&Gonce&w] " & zShortstop(zObjectName) & " &y" & zMinBid
                            Case 2
                                'subAuctoneerChannel "Auctioneer yells, '" & zShortstop(zObjectName) & " going twice for " & MyCLng(rsAuctionCheck!Gold) & " gold.'" & zMinBid
                                subAuctoneerChannel "&WAUCTION ITEM&w[&Gtwice&w] " & zShortstop(zObjectName) & " &y" & zMinBid
                            Case 3
                                'subAuctoneerChannel "Auctioneer yells, '" & zShortstop(zObjectName) & " going three times for " & MyCLng(rsAuctionCheck!Gold) & " gold.'" & zMinBid
                                subAuctoneerChannel "&WAUCTION ITEM&w[&Gthrice&w] " & zShortstop(zObjectName) & " &y" & zMinBid
                        End Select
                End Select
                'subAuctoneerChannel "Auctioneer yells, '" & zShortstop(zObjectName) & " appraises at " & vReturnObjectValue(rsAuctionCheck!ObjectID, 1) & " gold.'"
            End If
        End If
        Set rsObject = Nothing
    End If
    Set rsAuctionCheck = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckAndRunAuction," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zCurrentVotes() As String
On Error Resume Next
    Dim iCounter As Integer
    Dim iVoteN As Integer
    Dim iVoteY As Integer
    Dim iVoteA As Integer
    Dim iTotalVotes As Integer
    Dim zMsg As String
    
    zMsg = ""
    iVoteN = 0
    iVoteY = 0
    iVoteA = 0
    iTotalVotes = 0
    For iCounter = cstlMinPort To cstlMaxPort
        If (lngSQLRecordCount("SELECT PortID FROM tblPlayerLoggedIn WHERE (PortID='" & MyCStr(iCounter) & "');") > 0) Then 'is this player connected
            iTotalVotes = iTotalVotes + 1
            Select Case gblzVoteCasted(iCounter)
                Case "N"
                    iVoteN = iVoteN + 1
                Case "Y"
                    iVoteY = iVoteY + 1
                Case "A", "", " "
                    iVoteA = iVoteA + 1
            End Select
        End If
    Next iCounter
    
    Select Case (iVoteN > iVoteY)
        Case True
            zMsg = zMsg & "The no's have it!"
        Case False
            Select Case (iVoteN = iVoteY)
                Case True
                    zMsg = zMsg & "T I E  V O T E!"
                Case False
                    zMsg = zMsg & "The yes's have it!"
            End Select
    End Select
    
    zCurrentVotes = " Voted No: " & iVoteN & vbCrLf & "Voted Yes: " & iVoteY & vbCrLf & "Abstained: " & iVoteA & vbCrLf & "    Total: " & iTotalVotes & vbCrLf & "Officially! " & zMsg
End Function
Public Sub subVoteClear()
On Error Resume Next
    Dim iCounter As Integer
    For iCounter = cstlMinPort To cstlMaxPort
        gblzVoteCasted(iCounter) = ""
    Next iCounter
End Sub
Public Sub subCheckAndRunVote()
On Error Resume Next
    Dim iCounter As Integer
    Dim bComplete As Boolean
    
    If (gbllVoteDuration > 0) Then
        bComplete = True
        For iCounter = cstlMinPort To cstlMaxPort
            If (lngSQLRecordCount("SELECT PortID FROM tblPlayerLoggedIn WHERE (PortID='" & MyCStr(iCounter) & "');") > 0) Then 'is this player connected
                If (gblzVoteCasted(iCounter) = "") Then
                    bComplete = False 'someone didn't vote yet
                End If
            End If
        Next iCounter
        
        If (bComplete) Then gbllVoteDuration = 1 'If everyone voted we quickly show the poll.
        
        Select Case (gbllVoteDuration)
            Case 1
                subSimpleEchoChannel "&WPOLL RESULT: " & vbCrLf & zCurrentVotes() & vbCrLf & "&w" & gblzVoteTopic
            Case 3
                subSimpleEchoChannel "&WThe voting poll will end in a minute...cast or change your vote now." & vbCrLf & "&w" & gblzVoteTopic
            Case 7
                subSimpleEchoChannel "&WThe voting poll will end in a few minutes...cast or change your vote now." & vbCrLf & "&w" & gblzVoteTopic
            Case 15
                subSimpleEchoChannel "&WThe voting poll is coming to an end...cast or change your vote now." & vbCrLf & "&w" & gblzVoteTopic
            Case 18, 20, 30, 40, 50, 60, 70, 80, 90 'rest is quiet time
                subSimpleEchoChannel "&WThe voting poll is in progress...cast or change your vote now." & vbCrLf & "&w" & gblzVoteTopic
        End Select
        gbllVoteDuration = gbllVoteDuration - 1
    Else
        gbllVoteDuration = 0
    End If
End Sub
Public Sub subPlayerStepPlayer(zTargetName As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim rsTargetPlayer As Recordset
    Dim zPlayerName As String
    Dim zTPlayerName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lTurnedIntoAnimalType As Long
    Dim lTTurnedIntoAnimalType As Long
    Dim lTPlayerID As Long
    Dim lPlayerID As Long
    Dim lTShrinkDuration As Long
    Dim lCDEX As Long
    Dim lTCDEX As Long
    Dim lTCLUC As Long
    Dim lTCCHA As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT CMove, TurnedIntoAnimalType, PlayerID, DetectInvisibilityDuration, InvisibilityDuration, CamoflaguedDuration, HideDuration, CDEX, CLUC, CCHA, PortID, PlayerName, X, Y, Z, PlayerLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        If (MyCLng(rsPlayer!CMove) > 499) Then
            lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
            If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then 'fairly normal or a bull?
                zPlayerName = MyCStr(rsPlayer!PlayerName)
                lPlayerID = MyCLng(rsPlayer!PlayerID)
                lX = MyCLng(rsPlayer!x)
                lY = MyCLng(rsPlayer!y)
                lZ = MyCLng(rsPlayer!z)
                lCDEX = MyCLng(rsPlayer!CDEX)
                Set rsTargetPlayer = MyDB.OpenRecordset("SELECT ShrinkDuration, BlindDuration, StunDuration, PlayerID, TurnedIntoAnimalType, DetectInvisibilityDuration, InvisibilityDuration, CamoflaguedDuration, HideDuration, CDEX, CLUC, CCHA, PortID, PlayerName, X, Y, Z, PlayerLevel FROM tblPlayer WHERE (Len([PortID])>1 AND PlayerName='" & zTargetName & "' AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
                If (Not rsTargetPlayer.EOF) Then
                    lTPlayerID = MyCLng(rsTargetPlayer!PlayerID)
                    If (lPlayerID = lTPlayerID) Then
                        subSendMsg "&gYou cannot step on yourself.", zPortID
                    Else
                        zTPlayerName = MyCStr(rsTargetPlayer!PlayerName)
                        lTShrinkDuration = MyCLng(rsTargetPlayer!ShrinkDuration)
                        lTCDEX = MyCLng(rsTargetPlayer!CDEX)
                        lTCLUC = MyCLng(rsTargetPlayer!CLuc)
                        lTCCHA = MyCLng(rsTargetPlayer!CCHA)
                        lTTurnedIntoAnimalType = MyCLng(rsTargetPlayer!TurnedIntoAnimalType)
                        If (lTTurnedIntoAnimalType = 1 Or lTTurnedIntoAnimalType = 2 Or lTShrinkDuration <> 0) Then 'some heights are just asking to be stepped on :)
                            MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-500 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            If (lRandom(lCDEX) > lRandom(lTCDEX * lTTurnedIntoAnimalType) + lRandom(lTCLUC * lTTurnedIntoAnimalType) + lRandom(lTCCHA)) Then
                                MyDB.Execute "UPDATE tblPlayer SET BlindDuration=" & lRandom(2) & ", StunDuration=" & lRandom(2) & " WHERE (PlayerID=" & lTPlayerID & ");", dbFailOnError
                                subSendMsgAreaAllDISmart "&y", zPlayerName, "You step on %s2[" & zTranslatePoofAnimalTypes(1, lTTurnedIntoAnimalType) & "] &r*SQUISH*", zTPlayerName, "%s1 steps on %s2[" & zTranslatePoofAnimalTypes(1, lTTurnedIntoAnimalType) & "] &r*SQUISH*", lX, lY, lZ
                            Else
                                subSendMsgAreaAllDISmart "&y", zPlayerName, "You try to step on %s2[" & zTranslatePoofAnimalTypes(1, lTTurnedIntoAnimalType) & "] &w*MISS*", zTPlayerName, "%s1 tries to step on %s2[" & zTranslatePoofAnimalTypes(1, lTTurnedIntoAnimalType) & "] &w*MISS*", lX, lY, lZ
                            End If
                        Else
                            Select Case (lTTurnedIntoAnimalType = 0)
                                Case True
                                    subSendMsg "&gYou cannot step on " & zTPlayerName & ".", zPortID
                                Case False
                                    subSendMsg "&gYou cannot step on " & zTPlayerName & " the " & zTranslatePoofAnimalTypes(1, lTTurnedIntoAnimalType) & ".", zPortID
                            End Select
                        End If
                    End If
                Else
                    subSendMsg "&gStep On?", zPortID
                End If
                Set rsTargetPlayer = Nothing
            Else
                subSendMsg "&MYou cannot do that while you are a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ".", zPortID
            End If
        Else
            subSendMsg "&MYou need 500 move points to step on something.", zPortID
        End If
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerStepPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subVOTE(zPlayerName As String, zPromptOriginal As String, lClanMemberLevel As Long, zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim iPort As Integer
    
    If (gbllVoteDuration > 0) Then
        iPort = MyCInt(zPortID)
    
        Select Case UCase(zWord2)
            Case "Y", "YES"
                subSendMsg "&wYou are in favour of the topic:" & vbCrLf & "&g" & gblzVoteTopic, zPortID
                gblzVoteCasted(iPort) = "Y"
            Case "N", "NO"
                subSendMsg "&wYou are not in favour of the topic:" & vbCrLf & "&g" & gblzVoteTopic, zPortID
                gblzVoteCasted(iPort) = "N"
            Case "A", "ABS", "ABST", "ABSTAIN"
                subSendMsg "&wYou will abstain from the topic:" & vbCrLf & "&g" & gblzVoteTopic, zPortID
                gblzVoteCasted(iPort) = "A"
            Case Else
                subSendMsg "&wVOTE Y/N/A on this topic: " & vbCrLf & "&g" & gblzVoteTopic & vbCrLf & gbllVoteDuration & " rounds left.", zPortID
                Select Case gblzVoteCasted(iPort)
                    Case "Y"
                        subSendMsg "&AYour vote is currently Yes.", zPortID
                    Case "N"
                        subSendMsg "&AYour vote is currently No.", zPortID
                    Case "A"
                        subSendMsg "&AYour vote is currently Abstain.", zPortID
                    Case ""
                        subSendMsg "&AYou have not voted yet.", zPortID
                End Select
        End Select
    Else
        subSendMsg "&WLAST VOTE" & vbCrLf & "&w-----------------------------------------" & vbCrLf & gblzVoteTopic & vbCrLf & zCurrentVotes() & vbCrLf, zPortID
        If (lClanMemberLevel > 9) Then
            If (Len(zWord2) > 0) Then
                gblzVoteTopic = zPromptOriginal
                gblzVoteTopic = zDropFirstWordCleanLine(gblzVoteTopic)
                If (Len(zPlayerName) > 0) Then gblzVoteTopic = zPlayerName & "'s POLL: " & vbCrLf & gblzVoteTopic
                
                gbllVoteDuration = 19
                subVoteClear
                subSimpleEchoChannel "&WYou can now vote on a new topic...cast your vote now." & vbCrLf & "&aY o u r  v o t e  c o u n t s  t o o!&w" & vbCrLf & gblzVoteTopic
            Else
                subSendMsg "&gCLAN LEADERS can start a POLL - SYNTAX: VOTE MESSAGE", zPortID
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subVOTE," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subSpecialSelfObjectMagic() 'See Also: subSelfDeletingObjectsAndObjectPortals subSpecialSelfDeletingObject, subCorpseRottingRounds, subCastGroupOfProcedures
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lGOTDur As Long
    Dim lGroundObjectType As Long
        
    Set rsObject = MyDB.OpenRecordset("SELECT tblObjectSpecialSelfDeletingDelay.ObjectID, tblObject.GroundObjectType, tblObject.GroundObjectTypeDuration, tblObject.SpecialSelfDeletingDelay, tblObject.X, tblObject.Y, tblObject.Z FROM tblObject INNER JOIN tblObjectSpecialSelfDeletingDelay ON tblObject.ObjectID = tblObjectSpecialSelfDeletingDelay.ObjectID;", dbOpenSnapshot)
    If (Not rsObject.EOF) Then
        Do While (Not rsObject.EOF)
            lX = MyCLng(rsObject!x)
            lY = MyCLng(rsObject!y)
            lZ = MyCLng(rsObject!z)
            lGroundObjectType = MyCLng(rsObject!GroundObjectType)
            Select Case lGroundObjectType
                Case 1 'Healing Spring object = 'Healing Spring has Area of Effect for all abilities (Bards only)
                    lGOTDur = (MyCLng(rsObject!GroundObjectTypeDuration) * 4) + 150
                    If (lGOTDur > 0) Then
                        If (lGOTDur > 999) Then lGOTDur = 999
                        MyDB.Execute "UPDATE tblPlayer SET CHP=[CHP]+" & lGOTDur & ", CEssence=[CEssence]+" & lGOTDur & ", CMana=[CMana]+" & lGOTDur & ", CSoul=[CSoul]+" & lGOTDur & ", CMove=[CMove]+" & lGOTDur & " WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
                        Select Case lRandom(18) 'we have a myst tick catch for chp now leave it go over now
                            Case 1
                                subSendMsgAreaAll gblzFNBLU & "The spring water's bubbles pop gently against your skin.", lX, lY, lZ
                            Case 2
                                subSendMsgAreaAll gblzFNBLU & "Spring water splashes about the room.", lX, lY, lZ
                            Case 3
                                subSendMsgAreaAll gblzFNBLU & "You inhale the refreshing mist...ahhhhhhhhhh", lX, lY, lZ
                        End Select
                    End If
            End Select
            rsObject.MoveNext
        Loop
    End If
    Set rsObject = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpecialSelfObjectMagic," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subSpecialSelfDeletingObject() 'See Also: subSelfDeletingObjectsAndObjectPortals, subSpecialSelfObjectMagic, subCorpseRottingRounds, subCastGroupOfProcedures
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lObjectID As Long
    Dim lSSDD As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    'Dim lGroundObjectType As Long
    Set rsObject = MyDB.OpenRecordset("SELECT tblObjectSpecialSelfDeletingDelay.ObjectID, tblObject.GroundObjectType, tblObject.GroundObjectTypeDuration, tblObject.SpecialSelfDeletingDelay, tblObject.X, tblObject.Y, tblObject.Z FROM tblObject INNER JOIN tblObjectSpecialSelfDeletingDelay ON tblObject.ObjectID = tblObjectSpecialSelfDeletingDelay.ObjectID;", dbOpenSnapshot)
    Do While (Not rsObject.EOF)
        'lGroundObjectType = MyCLng(rsObject!GroundObjectType)
        lX = MyCLng(rsObject!x)
        lY = MyCLng(rsObject!y)
        lZ = MyCLng(rsObject!z)
        lObjectID = MyCLng(rsObject!ObjectID)
        lSSDD = MyCLng(rsObject!SpecialSelfDeletingDelay) - 1
        If (lSSDD = 1) Then
            subSendMsgAreaAll gblzFNBLU & "With its last *drip* the spring magically disappears.", lX, lY, lZ
            MyDB.Execute "DELETE ObjectID FROM tblObject WHERE ObjectID=" & lObjectID & ";", dbFailOnError
            MyDB.Execute "DELETE ObjectID FROM tblObjectSpecialSelfDeletingDelay WHERE ObjectID=" & lObjectID & ";", dbFailOnError
        Else
            MyDB.Execute "UPDATE tblObject SET GroundObjectTypeDuration=[GroundObjectTypeDuration]-1, SpecialSelfDeletingDelay=[SpecialSelfDeletingDelay]-1 WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
        End If
        rsObject.MoveNext
    Loop
    Set rsObject = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpecialSelfDeletingObject," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lRaceClassAttackLevelMAX(zRaceType As String, zClassType As String)
On Error GoTo Err_Check
    Dim lReturn As Long
    Dim lRace As Long
    Dim lClass As Long
    
    lReturn = 9
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 3
        Case "CL"
            lReturn = 12
        Case "DR"
            lReturn = 3
        Case "BA"
            lReturn = 4
        Case "MO"
            lReturn = 5
        Case "AS"
            lReturn = 9
        Case "GY"
            lReturn = 4
        Case "TH"
            lReturn = 1
        Case "WA"
            lReturn = 15
        Case "GL"
            lReturn = 20
        Case "RA"
            lReturn = 4
        Case "KN"
            lReturn = 6
        Case "PA"
            lReturn = 7
        Case "WE"
            lReturn = 8
        Case "VA"
            lReturn = 9
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 30
        Case "IO"
            lReturn = 5
    End Select
    lClass = lReturn
    
    lReturn = 2
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 1
        Case "HAL"
            lReturn = 1
        Case "OGE"
            lReturn = 3
        Case "ELF"
            lReturn = 2
        Case "ORC"
            lReturn = 3
        Case "FEL"
            lReturn = 1
        Case "HUM"
            lReturn = 3
        Case "MIN"
            lReturn = 4
        Case "DWA"
            lReturn = 2
        Case "TRO"
            lReturn = 4
        Case "DRA"
            lReturn = 1
        Case "PIX"
            lReturn = 1
        Case "UND"
            lReturn = 3
    End Select
    lRace = lReturn
    
    lRaceClassAttackLevelMAX = 3 + lClass + lRace 'base of 3
    Exit Function
Err_Check:
    subWriteErrorFile "lRaceClassAttackLevelMAX," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub basRestAttackLevel()
On Error GoTo Err_Check 'see also: lRaceClassAttackLevelMAX
    Dim lCount As Long
    For lCount = cstlMinPort To cstlMaxPort
        gbllAttackLevel(lCount) = gbllAttackLevel(lCount) - 1
        If (gbllAttackLevel(lCount) < 0 Or lRandom(5) = 1) Then gbllAttackLevel(lCount) = 0 'prevents long waits
    Next lCount
    Exit Sub
Err_Check:
    subWriteErrorFile "basRestAttackLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSelfDeletingObjectsAndObjectPortals()
On Error GoTo Err_Check
    Dim rsCountdown As Recordset
    Dim lObjectID As Long
    MyDB.Execute "UPDATE tblObject INNER JOIN tblObjectPortal ON tblObject.ObjectID = tblObjectPortal.ObjectID SET tblObject.SpecialSelfDeletingDelay = [SpecialSelfDeletingDelay]-1 WHERE (((tblObject.SpecialSelfDeletingDelay)>1));", dbFailOnError
    Set rsCountdown = MyDB.OpenRecordset("SELECT tblObject.ObjectID, tblObject.ObjectName, tblObject.SpecialSelfDeletingDelay, tblObject.X, tblObject.Y, tblObject.Z FROM tblObject INNER JOIN tblObjectPortal ON tblObject.ObjectID = tblObjectPortal.ObjectID WHERE (((tblObject.SpecialSelfDeletingDelay)=1));", dbOpenSnapshot)
    Do While (Not rsCountdown.EOF)
        lObjectID = MyCLng(rsCountdown!ObjectID)
        subSendMsgAreaAll gblzFBWHI & zShortstop(MyCStr(rsCountdown!ObjectName)) & "&B winks out of existence!", MyCLng(rsCountdown!x), MyCLng(rsCountdown!y), MyCLng(rsCountdown!z)
        MyDB.Execute "DELETE ObjectID FROM tblObject WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
        MyDB.Execute "DELETE ObjectID FROM tblObjectPortal WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
        rsCountdown.MoveNext
    Loop
    Set rsCountdown = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSelfDeletingObjectsAndObjectPortals," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCheckMobSpaceShipFireOnPlayer(lNum As Long)
On Error GoTo Err_Check
    'mob ships fire on players now
    Dim rsMob As Recordset
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim lAreaX As Long
    Dim lAreaY As Long
    Dim lAreaZ As Long
    Dim lSSPhaserLevel As Long
    Dim zAreaName As String
    Dim lSQLCount As Long
    
    If lRandom(lNum) = 1 Then
        Set rsMob = MyDB.OpenRecordset("SELECT MobSpaceshipLevel, SSLaserLevel, AreaName, X, Y, Z FROM tblArea WHERE (MobSpaceshipLevel>0 AND SSLaserLevel>0);", dbOpenSnapshot)
        Do While (Not rsMob.EOF)
            zAreaName = MyCStr(rsMob!AreaName) 'mobship name actually
            lAreaX = MyCLng(rsMob!x)
            lAreaY = MyCLng(rsMob!y)
            lAreaZ = MyCLng(rsMob!z)
            lSSPhaserLevel = MyCLng(rsMob!SSLaserLevel)
            lSQLCount = lngSQLRecordCount("SELECT PlayerID FROM tblPlayer WHERE (Len(PortID)>1 AND [X]<" & lAreaX & "+" & lSSPhaserLevel & " AND [X]>" & lAreaX & "-" & lSSPhaserLevel & " AND [Y]<" & lAreaY & "+" & lSSPhaserLevel & " AND [Y]>" & lAreaY & "-" & lSSPhaserLevel & " AND [Z]<" & lAreaZ & "+" & lSSPhaserLevel & " AND [Z]>" & lAreaZ & "-" & lSSPhaserLevel & ");")
            If (lSQLCount > 0) Then
                Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lSQLCount) & " PlayerID FROM tblPlayer WHERE (Len(PortID)>1 AND [X]<" & lAreaX & "+" & lSSPhaserLevel & " AND [X]>" & lAreaX & "-" & lSSPhaserLevel & " AND [Y]<" & lAreaY & "+" & lSSPhaserLevel & " AND [Y]>" & lAreaY & "-" & lSSPhaserLevel & " AND [Z]<" & lAreaZ & "+" & lSSPhaserLevel & " AND [Z]>" & lAreaZ & "-" & lSSPhaserLevel & ");", dbOpenSnapshot)
                If (Not rsPlayer.EOF) Then 'each mobship only attacks once some random player
                    rsPlayer.MoveLast
                    If (lRandom(15) = 1) Then
                        lPlayerID = MyCLng(rsPlayer!PlayerID)
                        MyDB.Execute "UPDATE tblPlayer SET BlindDuration=4, StunDuration=2, CMove = ([CMove]/" & lRandom(5) & "), CHP = ([CHP]/" & lRandom(5) & ") WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        subSendMsgInfoChannel "&W" & zAreaName & "&w[&M" & lSQLCount & "&w][x" & lAreaX & " y" & lAreaY & " z" & lAreaZ & "] &R-=<phazerz>=- &w" & zReturnPlayerName(MyCLng(lPlayerID))
                    End If
                End If
                Set rsPlayer = Nothing
            End If
            If lRandom(55) = 1 Then subSendMsgInfoChannel "&W" & zAreaName & "&w[x" & lAreaX & " y" & lAreaY & " z" & lAreaZ & "] &Y((scans)) nearby."
            rsMob.MoveNext
        Loop
        Set rsMob = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckMobSpaceShipFireOnPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCheckInitiateClanning(lChance As Long)
On Error GoTo Err_Check 'people that log on can get promotions by level and because no one is in the clan
    Dim rsClan As Recordset 'see also: zTranslateMortalClanRanks zReturnClanNameClanID
    Dim rsPlayer As Recordset
    Dim lPromoteLevel As Long
    Dim lPlayerID As Long
    Dim lClanID As Long
    Dim lClanMemberLevel As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zPortID As String
    Dim lClanCount As Long
    Dim bComplete As Boolean
    Dim bNew As Boolean
    
    'SELECT AreaID, AreaName, ClanID, X, Y, Z FROM tblArea WHERE ([ClanID]=" & lClanID & "); 'this finds part of the clans x y z so they have an idea where to go
    If (lRandom(lChance) = 1) Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,PlayerLevel,ClanID,ClanMemberLevel,X,Y,Z,PortID FROM tblPlayer WHERE (Len([PortID])>1 AND PlayerLevel>29 AND ClanMemberLevel<17);", dbOpenSnapshot)
        Do While (Not rsPlayer.EOF)
            zPortID = MyCStr(rsPlayer!PortID)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lClanID = MyCLng(rsPlayer!ClanID)
            lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            
            lPromoteLevel = 0
            bComplete = False
            bNew = False
            Select Case lClanID
                Case 0 'new clan
                    If (lPlayerLevel > 29) Then
                        bNew = True
                        lClanCount = 0
                        Set rsClan = MyDB.OpenRecordset("SELECT ClanID, ClanName, ClanType FROM tblPlayerClan WHERE (ClanName<>'' AND ClanType=0);", dbOpenSnapshot)
                        rsClan.MoveLast
                        lClanCount = rsClan.RecordCount
                        Set rsClan = Nothing
                        
                        bComplete = True
                        lClanID = lRandom(lClanCount)
                        lPromoteLevel = 1
                    End If
                Case Else 'promote them
                    If (lPlayerLevel >= (lClanMemberLevel * 12) - 4) Then 'even 200 for more chances
                        If (lRandom(99) = 1) Then 'small chance for a promotion or whatever
                            lPromoteLevel = lClanMemberLevel + 1
                            If (lPromoteLevel < 17) Then
                                bComplete = True
                                Select Case lRandom(9)
                                    Case 1 'make it hard to become a leader unless you are very high up
                                        If (lPlayerLevel > 99) Then lPromoteLevel = 17
                                    Case Else
                                        If (lPlayerLevel > 199) Then lPromoteLevel = 17
                                End Select
                            End If
                        End If
                    End If
            End Select
            If (bComplete) Then
                MyDB.Execute "UPDATE tblPlayer SET ClanMemberLevel=" & (lPromoteLevel) & ", ClanID=" & (lClanID) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                Select Case (bNew)
                    Case True
                        subSendMsg "&GCongratulations !!!" & vbCrLf & "&AYou are now clanned! Type 'WHO' to see the details." & vbCrLf & "&CTo find your clan, syntax: AREA " & UCase(zReturnClanNameClanID(lClanID)), zPortID
                    Case False
                        subSendMsg "&GCongratulations &wold(" & Trim(zTranslateMortalClanRanks(lClanMemberLevel)) & ") &Wnew[" & Trim(zTranslateMortalClanRanks(lPromoteLevel)) & "]" & vbCrLf & "&AYou got a clan promotion! Type 'WHO' to see the details." & vbCrLf & "&CTo find your clan, syntax: AREA " & UCase(zReturnClanNameClanID(lClanID)), zPortID
                End Select
                subSendMsg "&rUnhappy? Type: 'clan LEAVE THIS GUILD' to try again much later.", zPortID
            End If
            rsPlayer.MoveNext
        Loop
        Set rsPlayer = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckInitiateClanning," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCheckMobAutoMoveNAttack() 'see also: subMobEquipmentStealsFromPlayerInventory
On Error GoTo Err_Check
    Dim rsMob As Recordset 'this procedure looks at autoattack and initiates combat
    Dim zMobName As String
    Dim lMobID As Long
    Dim lOldMobID As Long 'We allow the mob to attack once
    Dim lPortID As Long
    Dim lOPlayerID As Long
    Dim zOPlayerName As String
    Dim bAutoAttack As Boolean
    
    bAutoAttack = False
    lOldMobID = 0
    'If (gbliCPUSpeedControl > 0) Then
    Set rsMob = MyDB.OpenRecordset("SELECT [PlayerLevel]+[CCHA] AS NotPlayerChrismatic, tblPlayer.PortID, tblMob.MobName, tblPlayer.PlayerName, tblPlayer.PlayerID, tblMob.MobAutoAttacks, tblMob.MobID, tblMob.PlayerID, tblPlayer.InvisibilityDuration, tblPlayer.HideDuration, tblPlayer.CamoflaguedDuration FROM tblMob INNER JOIN tblPlayer ON (tblMob.Z = tblPlayer.Z) AND (tblMob.Y = tblPlayer.Y) AND (tblMob.X = tblPlayer.X) WHERE ((([PlayerLevel]+[CCHA])<[MobLevel]) AND ((tblPlayer.PortID) Is Not Null And (tblPlayer.PortID)<>'' And ((tblPlayer.PortID)<>'0') AND ((tblMob.MobAutoAttacks)=True) AND ((tblPlayer.SneakingMovesLeft)=0) AND ((tblPlayer.InvisibilityDuration)=0) AND ((tblPlayer.HideDuration)=0) AND ((tblPlayer.CamoflaguedDuration)=0) AND (tblMob.RespawnDelay)=0));", dbOpenSnapshot)
    Do While (Not rsMob.EOF)
        lPortID = MyCLng(rsMob!PortID)
        lMobID = MyCLng(rsMob!MobID)
        If (lPortID <> 0 And lOldMobID <> lMobID) Then
            bAutoAttack = True
            lOldMobID = lMobID
            lOPlayerID = MyCLng(rsMob![tblPlayer.PlayerID])
            zOPlayerName = MyCStr(rsMob!PlayerName)
            subSendMsg "&M" & zAdverb(MyCStr(rsMob!MobName), 2) & zShortstop(MyCStr(rsMob!MobName)) & " attacks you!", MyCStr(rsMob!PortID)
            MyDB.Execute "UPDATE tblMob SET PlayerID = " & lOPlayerID & " WHERE (MobID=" & lMobID & ");", dbFailOnError
            rSCombat(lPortID).iStatus = cstiStatusPlayerVsMob
            zMobName = zShortstop(MyCStr(rsMob!MobName))
            zMobName = zAdverb(zMobName, 1) & zMobName
            
            rMCombat(lPortID).Name = zMobName
            rMCombat(lPortID).lID = MyCLng(rsMob!MobID)
            
            rPCombat(lPortID).Name = zOPlayerName
            rPCombat(lPortID).lID = lOPlayerID
        End If
        rsMob.MoveNext
    Loop
    Set rsMob = Nothing
    
    If (Not bAutoAttack) Then subMoveMobsWhereID "SPOT" 'move all mobs at player locations so they cant just sit there and bot
    
    'End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckMobAutoMoveNAttack," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subAttackerDisarmsPlayer(zDisarmAttackerName As String, zDisarmTargetName As String, lTargetPlayerID As Long, lX As Long, lY As Long, lZ As Long, zPortID As String)
On Error GoTo Err_Check
'Good for M v P or P v P disarm code, the target in this code is always a player the attacker can be a mob or a player
    Dim lPlayerID As Long
    Dim rsTargetPlayerWeapon As Recordset
    Dim rsPlayer As Recordset
    lPlayerID = 0
    Set rsTargetPlayerWeapon = MyDB.OpenRecordset("SELECT PlayerID, ObjectID, Location FROM tblPlayerEquipmentItems WHERE (PlayerID=" & lTargetPlayerID & " AND Location=20);", dbOpenDynaset)
    If (Not rsTargetPlayerWeapon.EOF) Then
        If (Not rsTargetPlayerWeapon.EOF) Then
            lPlayerID = MyCLng(rsTargetPlayerWeapon!PlayerID)
            subSendMsg "&RClank, " & zDisarmAttackerName & " disarms you!", zPortID
            subSendMsgAreaExcept2 gblzFBGRE & zDisarmAttackerName & " disarms " & zDisarmTargetName & "!", lX, lY, lZ, zPortID, ""
            MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & MyCLng(rsTargetPlayerWeapon!PlayerID) & ", " & MyCLng(rsTargetPlayerWeapon!ObjectID) & ";", dbFailOnError
            rsTargetPlayerWeapon.Delete
        End If
        MyDB.Execute "UPDATE tblPlayer SET DisarmedDuration = [DisarmedDuration]+" & lRandom(3) + 1 & " WHERE (PlayerID=" & lTargetPlayerID & ");", dbFailOnError
    End If
    Set rsTargetPlayerWeapon = Nothing
    If (lPlayerID <> 0) Then subRecalculatePlayerEquipment lPlayerID, zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobDisarmsPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subSendPlayerList(zPortID As String, zWord1 As String, zWord2 As String, zWord3 As String, zWord4 As String, zPrompt As String)
On Error GoTo Err_Check
    Dim rsInfo As Recordset
    Dim lCountNames As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lRX As Long
    Dim lRY As Long
    Dim lRZ As Long
    Dim lPRX As Long
    Dim lPRY As Long
    Dim lPRZ As Long
    Dim zName As String
    Dim lPlayerID As Long
    Dim lFacingGraphicsID As Long
    Dim bUpdateRoom As Boolean
    Dim bTeleportDetected As Boolean
    Dim bShow As Boolean
    Dim lDetectInvisibilityDuration As Long
    Dim bCanSee As Boolean
    
    bShow = False
    bTeleportDetected = False
    
    'get playerfile data
    Set rsInfo = MyDB.OpenRecordset("SELECT DetectInvisibilityDuration,GraphicsID,PlayerID,X,Y,Z,RoomX,RoomY,RoomZ FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsInfo.EOF) Then
        lFacingGraphicsID = MyCLng(rsInfo!GraphicsID)
        lPlayerID = MyCLng(rsInfo!PlayerID)
        lDetectInvisibilityDuration = MyCLng(rsInfo!DetectInvisibilityDuration)
        lX = MyCLng(rsInfo!x)
        lY = MyCLng(rsInfo!y)
        lZ = MyCLng(rsInfo!z)
        lPRX = MyCLng(rsInfo!RoomX)
        lPRY = MyCLng(rsInfo!RoomY)
        lPRZ = MyCLng(rsInfo!RoomZ)
    End If
    Set rsInfo = Nothing
    
    bUpdateRoom = (Len(zWord1) <> 0)
    If (bUpdateRoom) Then
        lRX = MyCLng(zWord1)
        lRY = MyCLng(zWord2)
        lRZ = MyCLng(zWord3)
        lFacingGraphicsID = MyCLng(zWord4)
        If lRX < cstgblRoomX1 Then lRX = cstgblRoomX1
        If lRX > cstgblRoomX2 Then lRX = cstgblRoomX2
        If lRY < cstgblRoomY1 Then lRY = cstgblRoomY1
        If lRY > cstgblRoomY2 Then lRY = cstgblRoomY2
        If lRZ < cstgblRoomZ1 Then lRZ = cstgblRoomZ1
        If lRZ > cstgblRoomZ2 Then lRZ = cstgblRoomZ2
        bTeleportDetected = (Abs(lRX - lPRX) + Abs(lRY - lPRY) + Abs(lRZ - lPRZ)) > 5
        If (Not bTeleportDetected) Then
            MyDB.Execute "UPDATE tblPlayer SET GraphicsID=" & lFacingGraphicsID & ", RoomX=" & lRX & ", RoomY=" & lRY & ", RoomZ=" & lRZ & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
        End If
    End If
    
    lCountNames = 0
    Set rsInfo = MyDB.OpenRecordset("SELECT DetectInvisibilityDuration, ShadowCloakDuration, InvisibilityDuration, CamoflaguedDuration, HideDuration, SneakingMovesLeft, GraphicsID, RoomX, RoomY, RoomZ, PlayerID, PlayerName, Race, Class, QuestMobID, RolePlayID, TurnedIntoAnimalType, ([CHP]/[OHP])*100 AS PerHP, ([CEssence]/[OEssence])*100 AS PerE, ([CMana]/[OMana])*100 AS PerMa, ([CSoul]/[OSoul])*100 AS PerS, ([CMove]/[OMove])*100 AS PerMv, CAC, CHITROLL, CDAMROLL FROM tblPlayer WHERE ( X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Len([PortID])>1 ) ORDER BY PlayerName;", dbOpenSnapshot)
    Do While (Not rsInfo.EOF)
        zName = ""
        bCanSee = (MyCLng(rsInfo!InvisibilityDuration) + MyCLng(rsInfo!CamoflaguedDuration) + MyCLng(rsInfo!HideDuration) + MyCLng(rsInfo!SneakingMovesLeft)) = 0
        If (Not bCanSee) Then bCanSee = (lDetectInvisibilityDuration <> 0)
        If (bCanSee) Then
            If (rsInfo!PlayerID = lPlayerID) Then
                zName = zName & "&C"
            Else
                zName = zName & "&c"
            End If
            zName = zName & MyCStr(rsInfo!PlayerName)
            zName = zName & " &aid[" & MyCLng(rsInfo!PlayerID) & "] ani[" & MyCLng(rsInfo!TurnedIntoAnimalType) & "] qm[" & MyCLng(rsInfo!QuestMobID) & "] rp[" & MyCLng(rsInfo!RolePlayID) & "]" & vbCrLf & " di[" & MyCLng(rsInfo!DetectInvisibilityDuration) & "] id[" & MyCLng(rsInfo!InvisibilityDuration) & "] cd[" & MyCLng(rsInfo!CamoflaguedDuration) & "] hd[" & MyCLng(rsInfo!HideDuration) & "] sml[" & MyCLng(rsInfo!SneakingMovesLeft) & "] sc[" & MyCLng(rsInfo!ShadowCloakDuration) & "]" & vbCrLf
            zName = zName & " &y[" & MyCLng(rsInfo!PerHP) & "%] &m[" & MyCLng(rsInfo!PerMa) & "%] &c[" & MyCLng(rsInfo!PerE) & "%] &r[" & MyCLng(rsInfo!PerS) & "%] &g[" & MyCLng(rsInfo!PerMv) & "%]" & vbCrLf
            zName = zName & " &w[a" & MyCLng(rsInfo!CAC) & " h" & MyCLng(rsInfo!CHITROLL) & " d" & MyCLng(rsInfo!CDAMROLL) & "] &y" & MyCStr(rsInfo!Class) & "/" & MyCStr(rsInfo!Race) & " &Ar[x" & MyCLng(rsInfo!RoomX) & " y" & MyCLng(rsInfo!RoomY) & " z" & MyCLng(rsInfo!RoomZ) & "] faceid[" & MyCLng(rsInfo!GraphicsID) & "]"
            lCountNames = lCountNames + 1
            subSendMsg zName, zPortID
        Else
            subSendMsg "&aSomeone else is here.", zPortID
        End If
        rsInfo.MoveNext
    Loop
    Set rsInfo = Nothing
    If (Len(lCountNames) = 0) Then subSendMsg "&CNo players here.", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendPlayerList," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendMobileList(zPortID As String)
On Error GoTo Err_Check
    Dim rsInfo As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zName As String
    Set rsInfo = MyDB.OpenRecordset("SELECT X,Y,Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsInfo.EOF) Then
        lX = MyCLng(rsInfo!x)
        lY = MyCLng(rsInfo!y)
        lZ = MyCLng(rsInfo!z)
    End If
    Set rsInfo = Nothing
    
    zName = ""
    Set rsInfo = MyDB.OpenRecordset("SELECT RoomX, RoomY, RoomZ, MobID, MobName, RespawnDelay, FlyHeight FROM tblMob WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    Do While (Not rsInfo.EOF)
        zName = zName & "&M" & MyCStr(rsInfo!MobName) & " &Aid[" & MyCStr(rsInfo!MobID) & "] rd[" & MyCStr(rsInfo!RespawnDelay) & "] h[" & MyCStr(rsInfo!FlyHeight) & "] [rx" & MyCLng(rsInfo!RoomX) & " ry" & MyCLng(rsInfo!RoomY) & " rz" & MyCLng(rsInfo!RoomZ) & "]" & vbCrLf
        rsInfo.MoveNext
    Loop
    Set rsInfo = Nothing
    If (Len(zName) > 0) Then
        subSendMsg zTrimCrLf(zName), zPortID
    Else
        subSendMsg "&CNo mobiles here.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendMobileList," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSendObjectList(zPortID As String)
On Error GoTo Err_Check
    Dim rsInfo As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zName As String
    Set rsInfo = MyDB.OpenRecordset("SELECT X,Y,Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsInfo.EOF) Then
        lX = MyCLng(rsInfo!x)
        lY = MyCLng(rsInfo!y)
        lZ = MyCLng(rsInfo!z)
    End If
    Set rsInfo = Nothing
    
    zName = ""
    Set rsInfo = MyDB.OpenRecordset("SELECT RoomX, RoomY, RoomZ, ObjectID, ObjectName, VisibleLevel FROM tblObject WHERE (Status=0 AND Location=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    Do While (Not rsInfo.EOF)
        zName = zName & "&w" & MyCStr(rsInfo!ObjectName) & " &Avl[" & MyCStr(rsInfo!VisibleLevel) & "] id[" & MyCStr(rsInfo!ObjectID) & "] [rx" & MyCLng(rsInfo!RoomX) & " ry" & MyCLng(rsInfo!RoomY) & " rz" & MyCLng(rsInfo!RoomZ) & "]" & vbCrLf
        rsInfo.MoveNext
    Loop
    Set rsInfo = Nothing
    If (Len(zName) > 0) Then
        subSendMsg zTrimCrLf(zName), zPortID
    Else
        subSendMsg "&CNo objects here.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendObjectList," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function subCombatDisarm(zPortID As String, zTargetName As String)
On Error GoTo Err_Check
'subCombatDisarm zWord(2), zPortID, lPlayerID, zPortID, lX, lY, lZ, lCLuc + lCDex + lPlayerLevel + lGrip, zPlayerName, lCSoul, zClass, lDisarmInterruption, lDetectInvisibilityDuration
'subCombatDisarm(zTPlayerName As String, lOPlayerID As Long, zPortID As String, lOX As Long, lOY As Long, lOZ As Long, lOGripAbility As Long, zOPlayerName As String, lOCSoul As Long, zOClass As String, lDisarmInterruption As Long, lDetectInvisibilityDuration As Long)

    'WeaponName and DisarmDuration works with mobs.
    'Players are more complicated.
    Dim lDisarmLength As Long
    Dim rsTargetPlayer As Recordset
    Dim rsTargetPlayerWeapon As Recordset
    Dim zMobName As String
    Dim zWeaponName As String
    Dim lDisarmedPlayerID As Long
    Dim bSoul As Boolean
    Dim lTargetID As Long
    Dim zSQL As String
    
    Dim rsPlayer As Recordset
    Dim bPlayerFound As Boolean
    
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCDEX As Long
    Dim lCLuc As Long
    Dim lCStr As Long
    Dim lCCon As Long
    Dim lCSoul As Long
    Dim lSoulCost As Long
    Dim zClass As String
    Dim zRace As String
    Dim lStunInterruption As Long
    Dim lFPlayerGroupStatus As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lStatus As Long
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim zGender As String
    Dim lDisarmInterruption As Long
    Dim lGripAbility As Long
    Dim lGrip As Long
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim lFlyDuration As Long
    Dim lPlayerHeight As Long
    Dim bAttackAway As Boolean
    Dim lTurnedIntoAnimalType As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Race, TurnedIntoAnimalType, Height, FlyDuration, SleepDuration, PlayerFleeDuration, Grip, DisarmInterruption, Gender, Class, CSoul, StunDuration, DetectInvisibilityDuration, BlindDuration, StunInterruption, CLuc, CDex, CStr, CCon, FPlayerGroupStatus, X, Y, Z, Status, PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        lFlyDuration = MyCLng(rsPlayer!FlyDuration)
        lPlayerHeight = MyCLng(rsPlayer!Height)
        lStatus = MyCLng(rsPlayer!Status)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lCLuc = MyCLng(rsPlayer!CLuc)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCStr = MyCLng(rsPlayer!CStr)
        lCCon = MyCLng(rsPlayer!CCon)
        lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        zRace = MyCStr(rsPlayer!Race)
        zClass = MyCStr(rsPlayer!Class)
        zGender = MyCStr(rsPlayer!Gender)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lStunInterruption = MyCLng(rsPlayer!StunInterruption)
        lDisarmInterruption = MyCLng(rsPlayer!DisarmInterruption)
        lGrip = MyCLng(rsPlayer!Grip)
        lGripAbility = lCLuc + lCDEX + lPlayerLevel + lGrip
    Else
        bPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    If (bPlayerFound) Then
    If (gbllAttackLevel(MyCLng(zPortID)) < lRaceClassAttackLevelMAX(zRace, zClass)) Then
        If (zClass <> "MA" And zClass <> "IO" And zClass <> "DR" And zClass <> "PA") Then
        If (lStatus <> 50) Then
        If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then
            If (lTurnedIntoAnimalType = 0 And UCase(zTargetName) = "TRAP") Then
                subDisarmTrap zClass, zPlayerName, lPlayerID, zPortID, lX, lY, lZ, lCDEX, lPlayerLevel, lCSoul
            Else
                If (zAreaRules(1, lX, lY, lZ) = "1") Then
                    If (lSleepDuration = 0) Then
                        If (lBlindDuration = 0) Then
                            If (lStunDuration = 0) Then
                                If (lPlayerFleeDuration = 0) Then
                                    If (lDisarmInterruption = 0) Then
                                        lTargetID = lPlayerFightingMobID(zPortID)
                                        If (lTargetID = 0) Then
                                            bAttackAway = bPlayerVsMobCombatSetUp(zRace, zClass, lFlyDuration, lPlayerHeight, lFPlayerGroupStatus, lDetectInvisibilityDuration, zPortID, zTargetName, lX, lY, lZ, lPlayerID, zPlayerName, zGender, lStatus, lBlindDuration, lStunDuration, False, False)
                                            If (Not bAttackAway) Then
                                                bAttackAway = (lngSQLRecordCount("SELECT PlayerID FROM tblPlayer WHERE (PlayerName Like ""*" & zTargetName & "*"" AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");") > 0) 'see if its a player
                                            Else
                                                lTargetID = lPlayerFightingMobID(zPortID) 'we grab the value
                                            End If
                                        Else
                                            bAttackAway = True
                                            'We have this at this point lTargetID = lPlayerFightingMobID(zPortID)
                                        End If
                                        If (bAttackAway) Then
                                            If (Len(zTargetName) >= cstMinAttackMobLen Or lTargetID <> 0) Then
                                                lDisarmedPlayerID = 0
                                                lSoulCost = MyCLng(cstlDisarmSoulCost / lTranslateDisarmCost(zClass))
                                                bSoul = False
                                                
                                                If (lCSoul >= lSoulCost) Then
                                                    Select Case (lTargetID = 0)
                                                        Case True 'disarm player
                                                            Set rsTargetPlayer = MyDB.OpenRecordset("SELECT InvisibilityDuration, CamoflaguedDuration, HideDuration, SneakingMovesLeft, PlayerID, CDEX, CLUC, PortID, PlayerName, X, Y, Z, CSTR, CLUC, Grip, PlayerLevel FROM tblPlayer WHERE (Len([PortID])>1 AND PlayerName Like '*" & zTargetName & "*' AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
                                                            If (Not rsTargetPlayer.EOF) Then
                                                                If ((MyCLng(rsTargetPlayer!InvisibilityDuration) = 0 And MyCLng(rsTargetPlayer!CamoflaguedDuration) = 0 And MyCLng(rsTargetPlayer!HideDuration) = 0) Or (lDetectInvisibilityDuration > 0)) Then
                                                                    If (MyCLng(rsTargetPlayer!SneakingMovesLeft) = 0) Then 'sneak protects against disarm
                                                                        If (MyCLng(rsTargetPlayer!PlayerID) <> lPlayerID) Then
                                                                            bSoul = True
                                                                            lDisarmLength = lRandom(3) + 1
                                                                            If (lRandom(lGripAbility) > lRandom(MyCLng(rsTargetPlayer!CDEX) + MyCLng(rsTargetPlayer!CStr)) + MyCLng(rsTargetPlayer!PlayerLevel) + MyCLng(rsTargetPlayer!Grip)) Then
                                                                                Set rsTargetPlayerWeapon = MyDB.OpenRecordset("SELECT PlayerID, ObjectID, Location FROM tblPlayerEquipmentItems WHERE (PlayerID=" & MyCLng(rsTargetPlayer!PlayerID) & " AND Location=20);", dbOpenDynaset)
                                                                                If (Not rsTargetPlayerWeapon.EOF) Then
                                                                                    'subSendMsg "&GYou disarm " & MyCStr(rsTargetPlayer!PlayerName) & "!", zPortID
                                                                                    'subSendMsgAreaExcept2 gblzFBGRE & zOPlayerName & " disarms " & MyCStr(rsTargetPlayer!PlayerName) & "!", lOX, lOY, lOZ, zPortID, MyCStr(rsTargetPlayer!PortID)
                                                                                    'subSendMsg "&RCLANK! " & zOPlayerName & " disarms you, your hand vibrates in deep pain!", MyCStr(rsTargetPlayer!PortID)
                                                                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 disarm %s2!", MyCStr(rsTargetPlayer!PlayerName), "%s1 disarms %s2!", lX, lY, lZ
                                                                                    MyDB.Execute "INSERT INTO tblPlayerInventoryItems ( PlayerID, ObjectID ) SELECT " & MyCLng(rsTargetPlayer!PlayerID) & ", " & MyCLng(rsTargetPlayerWeapon!ObjectID) & ";", dbFailOnError
                                                                                    MyDB.Execute "UPDATE tblPlayer SET DisarmedDuration=" & lDisarmLength & " WHERE PlayerID=" & MyCLng(rsTargetPlayer!PlayerID) & ";"
                                                                                    rsTargetPlayerWeapon.Delete
                                                                                    lDisarmedPlayerID = MyCLng(rsTargetPlayer!PlayerID)
                                                                                Else
                                                                                    subSendMsg "&R" & MyCStr(rsTargetPlayer!PlayerName) & " is already disarmed!", zPortID
                                                                                End If
                                                                                Set rsTargetPlayerWeapon = Nothing
                                                                            Else
                                                                                subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 fail to disarm %s2!", MyCStr(rsTargetPlayer!PlayerName), "%s1 failed to disarm %s2!", lX, lY, lZ
                                                                                'subSendMsg "&RYou try to disarm " & MyCStr(rsTargetPlayer!PlayerName) & " and fail!", zPortID
                                                                                'subSendMsgAreaExcept2 "&R" & zOPlayerName & " fails to disarm " & MyCStr(rsTargetPlayer!PlayerName) & "!", lOX, lOY, lOZ, zPortID, MyCStr(rsTargetPlayer!PortID)
                                                                                'subSendMsg "&R" & zOPlayerName & " fails to disarm you!", MyCStr(rsTargetPlayer!PortID)
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&RYou do not wish to disarm yourself.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsg "&RYou cannot disarm a sneaking player.", zPortID
                                                                    End If
                                                                Else
                                                                    subSendMsg "&gDisarm Who?", zPortID
                                                                End If
                                                            Else
                                                                subSendMsg "&gDisarm Who?", zPortID
                                                                If (zClass = "TH") Or (zClass = "AS") Then subSendMsg "&GBeing a thief or an assassin you can: DISARM TRAP", zPortID
                                                            End If
                                                            Set rsTargetPlayer = Nothing
                                                        Case False
                                                            'Now we check mobs in the area to set their StunDuration
                                                            Select Case (lTargetID = 0)
                                                                Case True
                                                                    zSQL = "SELECT MobLevel, WeaponName, MobName, X, Y, Z, DisarmDuration, WeaponName FROM tblMob WHERE (RespawnDelay=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND MobName Like '*" & zTargetName & "*');"
                                                                Case False
                                                                    zSQL = "SELECT MobLevel, WeaponName, MobName, X, Y, Z, DisarmDuration, WeaponName FROM tblMob WHERE (RespawnDelay=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND MobID=" & lTargetID & ");"
                                                            End Select
                                                            
                                                            Set rsTargetPlayer = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
                                                            If (Not rsTargetPlayer.EOF) Then
                                                                zMobName = zAdverb(zMobName, 2) & zShortstop(MyCStr(rsTargetPlayer!MobName))
                                                                
                                                                bSoul = True
                                                                zWeaponName = MyCStr(rsTargetPlayer!WeaponName)
                                                                If (Len(zWeaponName) > 0) Then
                                                                    If (lRandom(lGripAbility) > MyCLng(rsTargetPlayer!MobLevel)) Then
                                                                        If (Len(rsTargetPlayer!WeaponName) > 0) Then
                                                                            If (MyCLng(rsTargetPlayer!DisarmDuration) = 0) Then
                                                                                rsTargetPlayer.Edit
                                                                                rsTargetPlayer!DisarmDuration = lRandom(2) + 2
                                                                                rsTargetPlayer.Update
                                                                                subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 disarm " & zMobName & ".", "", "%s1 disarms " & zMobName & "!", lX, lY, lZ
                                                                                'subSendMsg "&GYou disarm " & zMobName & " from the " & zWeaponName & ".", zPortID
                                                                                'subSendMsgAreaExcept2 gblzFBGRE & zOPlayerName & " disarms " & zMobName & " from the " & zWeaponName & ".", lOX, lOY, lOZ, zPortID, ""
                                                                            Else
                                                                                subSendMsg "&G" & zMobName & " is already disarmed of the " & zWeaponName & ".", zPortID
                                                                                'subSendMsgAreaExcept2 gblzFBGRE & zOPlayerName & " attempts to disarm " & zMobName & vbCrLf & " of the " & zWeaponName & " but is already disarmed.", lOX, lOY, lOZ, zPortID, ""
                                                                            End If
                                                                        Else
                                                                            subSendMsg "&R" & zMobName & " is not carring a weapon you can disarm.", zPortID
                                                                        End If
                                                                    Else
                                                                        subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 fail to disarm " & zMobName & ".", "", "%s1 failed to disarm " & zMobName & "!", lX, lY, lZ
                                                                        'subSendMsg "&RYou fail to disarm " & zMobName & " of the " & zWeaponName & ".", zPortID
                                                                        'subSendMsgAreaExcept2 "&R" & zOPlayerName & " fails to disarm " & zMobName & " of the " & zWeaponName & ".", lOX, lOY, lOZ, zPortID, ""
                                                                    End If
                                                                Else
                                                                    subSendMsg "&RYou cannot get a fix on the weapon and fail to disarm " & zMobName & ".", zPortID
                                                                    subSendMsgAreaExcept2 "&R" & zPlayerName & " cannot get a fix on the weapon and fails to disarm " & zMobName & ".", lX, lY, lZ, zPortID, ""
                                                                End If
                                                            Else
                                                                subSendMsg "&gDisarm Who?", zPortID
                                                                If (zClass = "TH") Or (zClass = "AS") Then subSendMsg "&GBeing a thief or an assassin you can: DISARM TRAP", zPortID
                                                            End If
                                                            Set rsTargetPlayer = Nothing
                                                    End Select
                                                Else
                                                    subSendMsg "&gYou cannot attempt a disarm, you are short " & (lSoulCost - lCSoul) & " soul points.", zPortID
                                                End If
                                                'Else
                                                '    subSendMsg "&GThat is not here to disarm.", zPortID
                                                '    If (zOClass = "TH") Or (zOClass = "AS") Then
                                                '        subSendMsg "&GBeing a thief or an assassin you can: DISARM TRAP", zPortID
                                                '    End If
                                                'End If
                                                
                                                If (bSoul) Then
                                                    MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lSoulCost & ", DisarmInterruption=2 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'We spen the soul then try to hit.
                                                    subAddPortIDsCyborgVentingSystem MyCLng(zPortID), 1
                                                End If
                                                
                                                If (lDisarmedPlayerID <> 0) Then
                                                    subRecalculatePlayerEquipment lDisarmedPlayerID, zPortID
                                                End If
                                            Else
                                                subSendMsg "&gYour target name must be at least " & cstMinAttackMobLen & " characters in length.", zPortID
                                                If (zClass = "TH") Or (zClass = "AS") Then subSendMsg "&GBeing a thief or an assassin you can: DISARM TRAP", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gDisarm whom?", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RYou are not ready to attempt a disarm.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou are too scared to attempt a disarm.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou are too stunned to attempt a disarm.", zPortID
                            End If
                        Else
                            subSendMsg "&RYou cannot see anything to attempt a disarm.", zPortID
                        End If
                    Else
                        subSendMsg "&RYou are too sleepy to attempt a disarm.", zPortID
                    End If
                Else
                    subSendMsg "&BA magical barrier prevents you from attacking.", zPortID
                End If
            End If
        Else
            subSendMsg "&MYou cannot do that when you are a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & ".", zPortID
        End If
        Else
            subSendMsg "&GYou dream about disarming a nemesis.", zPortID
        End If
        Else
            subSendMsg "&rYour class is forbidden to use DISARM.", zPortID
        End If
    Else
        subSendMsg "&rYour body needs a break!", zPortID
        'If (lPlayerLevel < 11) Then subSendMsg "&Y[&yPL11&Y]&GH&gINT: This MUD is about forging not leveling:" & vbCrLf & "Go slow and find crowns of glory everywhere!" & vbCrLf & "This MUD will play with you, give you quests, and the Oracle has crowns too!" & vbCrLf & "&GOnce triggered, the above warning message disappears" & vbCrLf & "in about thirty seconds, when not disturbed with another attack.", zPortID
    End If
    Else
        subSendMsg "&RsubCombatDisarm: Tell an immortal that your player file was not found!", zPortID
    End If
    Exit Function
Err_Check:
    subWriteErrorFile "subCombatDisarm," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subThiefSteal(zTargetObject As String, zTargetPlayer As String, zPortID As String)
On Error GoTo Err_Check
    Dim bSentDayMsg As Boolean
    Dim lSoulCost As Long
    Dim lMoveCost As Long
    Dim lGold As Long
    Dim lOMagicFind As Long
    Dim lOMagicFindBase As Long
    Dim rsTargetPlayer As Recordset
    Dim rsTargetObject As Recordset
    Dim rsTargetEquipment As Recordset
    Dim lTargetEquipmentItemsStolen As Long
    Dim lMagicFindObjectBonus As Long
    Dim lPortID As Long
    Dim bAttackPlayer As Boolean
    Dim zMobName As String
    Dim zUcaseMobName As String
    Dim zStealInfo As String
    Dim lMobRareRandom As Long
    Dim lMobLevel As Long
    Dim bInvisible As Boolean
    Dim lFlyDuration As Long
    Dim lFlyHeight As Long
    
    Dim rsPlayer As Recordset
    Dim lStatus As Long
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lBlindDuration As Long
    Dim zRace As String
    Dim zClass As String
    Dim lMove As Long
    Dim lSoul As Long
    Dim lPlayerLevel As Long
    Dim lCLuc As Long
    Dim lCDEX As Long
    Dim lCCHA As Long
    Dim lWhereID As Long
    Dim zPlayerName As String
    Dim lMagicFind As Long
    Dim lMagicFindBase As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim lPlayerHeight As Long
    Dim lStealChance As Long
    Dim bPlayerFound As Boolean
    Dim bRecPlayerFound As Boolean
    Dim bWhisperedTo As Boolean
    Dim bDay As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim bBonusChance As Boolean
    Dim lBonusChance As Long
    Dim lSneakingMovesLeft As Long
    Dim lHideDuration As Long
    Dim lCamoflaguedDuration As Long
    Dim lInvisibilityDuration As Long
    Dim lPFactionID As Long
    Dim lAFactionID As Long
    Dim lCountOfPlayerFactionsInArea As Long
    
    bDay = bWhenIsIt("", False)
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT FactionedWith, HideDuration, InvisibilityDuration, CamoflaguedDuration, SneakingMovesLeft, TurnedIntoAnimalType, FlyDuration, Race, Height, PlayerFleeDuration, DetectInvisibilityDuration, PlayerID, X, Y, Z, CLuc, CDex, CCha, PlayerLevel, PlayerName, WhereID, CSoul, CMove, Class, MagicFindBase, MagicFind, Status, BlindDuration FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bRecPlayerFound = True
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        
        lPFactionID = MyCLng(rsPlayer!FactionedWith)
        If (lPlayerLevel < cstFACTIONSAFEPlayerLevel) Then
            lCountOfPlayerFactionsInArea = 0 'no penality
        Else
            lAFactionID = lReturnAreaFaction(lX, lY, lZ)
            If (lAFactionID = lPFactionID) Then
                lCountOfPlayerFactionsInArea = 1
            Else
                lCountOfPlayerFactionsInArea = -1 'error, lReturnCountOfPlayerFactions2x2(lPFactionID)
            End If
        End If
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lSneakingMovesLeft = MyCLng(rsPlayer!SneakingMovesLeft)
        lHideDuration = MyCLng(rsPlayer!HideDuration)
        lCamoflaguedDuration = MyCLng(rsPlayer!CamoflaguedDuration)
        If (lInvisibilityDuration = 0) Then
            bBonusChance = (lRandom(100) < 80 And lSneakingMovesLeft <> 0) Or (lRandom(100) < 90 And lHideDuration <> 0) Or (lRandom(100) < 21 And lCamoflaguedDuration <> 0)
        Else
            bBonusChance = False
        End If
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        zRace = MyCStr(rsPlayer!Race)
        zClass = MyCStr(rsPlayer!Class)
        lFlyDuration = MyCLng(rsPlayer!FlyDuration)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lStatus = MyCLng(rsPlayer!Status)
        lPlayerHeight = MyCLng(rsPlayer!Height)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lWhereID = MyCLng(rsPlayer!WhereID)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lMove = MyCLng(rsPlayer!CMove)
        lSoul = MyCLng(rsPlayer!CSoul)
        lMagicFindBase = MyCLng(rsPlayer!MagicFindBase)
        lMagicFind = MyCLng(rsPlayer!MagicFind)
        lOMagicFindBase = lMagicFindBase
        lOMagicFind = lMagicFind
        lCLuc = MyCLng(rsPlayer!CLuc)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        lStealChance = lRandom(lCLuc) + lRandom(lCDEX) + lRandom(lCCHA) + lRandom(lPlayerLevel) + lTranslateThiefPickLock(zClass)
        
        If (bBonusChance) Then
            lBonusChance = (8 * lTranslateThiefPickLock(zClass))
            lStealChance = lStealChance + lBonusChance
            subSendMsg "&WYou get a +" & lBonusChance & " bonus chance!", zPortID
        End If
    Else
        bRecPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    If (bRecPlayerFound) Then
        If (lCountOfPlayerFactionsInArea > -1) Then
        If (zClass <> "IO") Then  'witch/warlock = Witchlock
        If (lTurnedIntoAnimalType = 0) Then
        If (Not bReturnOutCastedPlayerID(lPlayerID)) Then
            'bDoCosts = False
            lPortID = MyCLng(zPortID)
            'one player gets a: No one hears you yell.
            If (lStatus <> 50) Then
            If (lInvisibilityDuration = 0) Then
                If (lTotalObjectsPlayerInv(lPlayerID) < 11) Then
                    If (iCombatPlayerStatus(zPortID) = cstiStatusNotInBattleMode) Then
                        If (lPlayerFleeDuration = 0) Then
                            If (zAreaRules(1, lX, lY, lZ) = "1") Then
                                If (lBlindDuration = 0) Then
                                    lSoulCost = lTranslateSoulStealCost(zClass)
                                    lMoveCost = lTranslateMoveStealCost(zClass)
                                    bPlayerFound = False
                                    If (lMove >= lMoveCost) Then
                                        If (lSoul >= lSoulCost) Then
                                            'We have enough soul and movement points
                                            If (Len(zTargetObject) > 0) Then
                                                'STEAL FROM PLAYER FIRST if its not a player try a MOB
                                                If (Len(zTargetPlayer) > 0) Then
                                                    Set rsTargetPlayer = MyDB.OpenRecordset("SELECT tblPlayer.Class, tblPlayer.PortID, tblPlayer.PlayerName, tblPlayer.PlayerID, tblPlayer.PlayerLevel, tblPlayer.CDEX, tblPlayer.CINT, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, tblPlayer.PlayerID FROM tblPlayer WHERE (((tblPlayer.PortID) Is Not Null And (tblPlayer.PortID)<>'' And (tblPlayer.PortID)<>'0') AND ((tblPlayer.PlayerName) Like ""*" & zTargetPlayer & "*"") AND ((tblPlayer.X)=" & lX & ") AND ((tblPlayer.Y)=" & lY & ") AND ((tblPlayer.Z)=" & lZ & ") AND ((tblPlayer.PlayerID)<>" & lPlayerID & ") AND ((tblPlayer.ImmortalLevel)=0));", dbOpenSnapshot)
                                                    If (Not rsTargetPlayer.EOF) Then
                                                        bPlayerFound = True
                                                        If (rsTargetPlayer!PlayerID <> lPlayerID) Then
                                                            Set rsTargetObject = MyDB.OpenRecordset("SELECT tblPlayerInventoryItems.PlayerID, tblObject.ObjectName, tblObject.ObjectID, tblObject.ReturnPlayerID FROM tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & MyCLng(rsTargetPlayer!PlayerID) & ") AND ((tblObject.ObjectName) Like ""*" & zTargetObject & "*""));", dbOpenSnapshot)
                                                            If (Not rsTargetObject.EOF) Then
                                                                If (MyCLng(rsTargetObject!ReturnPlayerID) = 0) Then
                                                                    'found the player and the inventory object - we now STEAL
                                                                    Select Case UCase(MyCStr(rsTargetPlayer!Class))
                                                                        Case "KN" 'so very hard to steal from this class
                                                                            subSendMsg "&AA Knights inventory is highly protected from the force, you dolt!", zPortID
                                                                            lStealChance = MyCLng(lStealChance / lRandom(3) + 1) + 1
                                                                    End Select
                                                                    If (lStealChance > (MyCLng(rsTargetPlayer!PlayerLevel) * 2) + MyCLng(rsTargetPlayer!CInt) + MyCLng(rsTargetPlayer!CDEX)) Then
                                                                        'bDoCosts = True
                                                                        subSendMsg "&GGOT IT! You steal the " & zShortstop(MyCStr(rsTargetObject!ObjectName)) & " from " & MyCStr(rsTargetPlayer!PlayerName) & ".", zPortID
                                                                        MyDB.Execute "UPDATE tblPlayerInventoryItems SET PlayerID=" & lPlayerID & " WHERE (PlayerID=" & MyCLng(rsTargetPlayer!PlayerID) & " AND ObjectID=" & MyCLng(rsTargetObject!ObjectID) & ");", dbFailOnError 'We switch the items from the player to the thief
                                                                        MyDB.Execute "UPDATE tblObject SET PlayerID=" & lPlayerID & " WHERE (ObjectID=" & MyCLng(rsTargetObject!ObjectID) & ");", dbFailOnError 'We make the object the thiefs property.
                                                                        subRecalculatePlayerEquipment lPlayerID, zPortID
                                                                        subRecalculatePlayerEquipment MyCLng(rsTargetPlayer!PlayerID), zPortID
                                                                    Else
                                                                        'the player yells BLOODY THIEF!
                                                                        'subChannelYell MyCStr(rsTargetPlayer!PortID), MyCStr(rsTargetPlayer!PlayerName), lWhereID, gblzFBMAG & UCase(zPlayerName) & " IS A &Rb&W THIEF ! ! !", 0, 0, 0, 0, 0, 0
                                                                        subSendMsg "&RFOR SHAME! " & zPlayerName & " tried to steal from you! (murder at will!)", MyCStr(rsTargetPlayer!PortID)
                                                                        MyDB.Execute "UPDATE tblPlayer SET Alignment=[Alignment]-" & lRandom(100) & ", PlayerFleeDuration=[PlayerFleeDuration]+" & (lRandom(20) + 40) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'mark player to hunt
                                                                        MyDB.Execute "UPDATE tblPlayer SET Alignment=(-1000+(CCHA/4)) WHERE (Alignment < (-1000+(CCHA/4)) AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                        MyDB.Execute "UPDATE tblPlayer SET Alignment=0 WHERE (Race='UND' AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                        subSendMsg "&gFAILED! Now is a good time to slip out of here!", zPortID
                                                                    End If
                                                                Else
                                                                    subSendMsg "&RZAP! " & zShortstop(MyCStr(rsTargetObject!ObjectName)) & " cannot be stolen it is a stamped object! (no one saw this)", zPortID
                                                                    'subChannelYell MyCStr(rsTargetPlayer!PortID), MyCStr(rsTargetPlayer!PlayerName), lWhereID, gblzFBMAG & UCase(zPlayerName) & " IS A &Rb&W THIEF ! ! !", 0, 0, 0, 0, 0, 0
                                                                End If
                                                            Else
                                                                subSendMsg "&gYou don't see that in " & MyCStr(rsTargetPlayer!PlayerName) & "'s inventory.", zPortID
                                                            End If
                                                            Set rsTargetObject = Nothing
                                                        Else
                                                            subSendMsg "&gYou cannot steal from yourself.", zPortID
                                                        End If
                                                    End If
                                                End If
                                                
                                                'TRY TO STEAL FROM A MOB
                                                If (Not bPlayerFound) Then
                                                    'bDoCosts = False
                                                    bAttackPlayer = False
                                                    'we will add lDuplicateObject(ObjectID (held by mob), lPlayerID) as part of a method to try to take stuff from mobs not just gold
                                                    Set rsTargetPlayer = Nothing
                                                    'Debug.Print "SELECT MobID, MobName, MobLevel, X, Y, Z  FROM tblMob WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND MobName Like '*" & zAntiSQLCrash(zTargetObject) & "*');"
                                                    Set rsTargetPlayer = MyDB.OpenRecordset("SELECT MobName, MobNameNight, Flys, FlyHeight, MobEmotePlayerAllowed, MobID, StealDelay, MobLevel, X, Y, Z, Invisible FROM tblMob WHERE (RespawnDelay=0 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND MobName Like '*" & zAntiSQLCrash(zTargetObject) & "*');", dbOpenSnapshot)
                                                    If (Not rsTargetPlayer.EOF) Then
                                                        bInvisible = (MyCInt(rsTargetPlayer!Invisible) <> 0)
                                                        zMobName = MyCStr(rsTargetPlayer!MobName)
                                                        zUcaseMobName = UCase(zMobName)
                                                        zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
                                                        lFlyHeight = MyCLng(rsTargetPlayer!FlyHeight)
                                                        If (lFlyDuration > 0 Or zClass = "VA" Or zRace = "PIX") Or (lPlayerHeight + (lPlayerHeight / 3) > lFlyHeight) Then 'Weapons do not help with this reach
                                                            If (lDetectInvisibilityDuration <> 0 Or Not bInvisible) Then 'Can we See the Mob?
                                                                lMobLevel = MyCLng(rsTargetPlayer!MobLevel)
                                                                If (MyCLng(rsTargetPlayer!StealDelay) = 0) Then
                                                                    lMagicFindObjectBonus = 0
                                                                    Select Case zClass
                                                                        Case "TH"
                                                                            lMagicFindObjectBonus = 9
                                                                        Case "GY"
                                                                            lMagicFindObjectBonus = 6
                                                                        Case "BA"
                                                                            lMagicFindObjectBonus = 2
                                                                    End Select
                                                                    
                                                                    zStealInfo = ""
                                                                    
                                                                    'We see if mobs have anything to steal, gold, magic find objects etc...
                                                                    
                                                                    'GOLD
                                                                    If (MyCLng(rsTargetPlayer!MobEmotePlayerAllowed) <> 0) Then 'steal GOLD only from beings
                                                                        If ((lRandom(lCDEX + lPlayerLevel)) > lRandom(lMobLevel * 3)) Then
                                                                            'bDoCosts = True
                                                                            lGold = (lRandom(lMobLevel / 2)) + (lMobLevel / 2) + (lRandom(5))
                                                                            zStealInfo = zStealInfo & lGold & " gold"
                                                                            MyDB.Execute "UPDATE tblPlayer SET Gold=[Gold]+" & lGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'mark player to hunt
                                                                        End If
                                                                    End If
                                                                    
                                                                    'ITEMS
                                                                    If (cstbGlobalThiveryAllowed Or zClass = "TH" Or zClass = "BA" Or zClass = "GY" Or zClass = "AS") Then
                                                                        lTargetEquipmentItemsStolen = 0
                                                                        bSentDayMsg = False
                                                                        Set rsTargetEquipment = MyDB.OpenRecordset("SELECT tblMobEquipmentItems.ObjectID, tblMobEquipmentItems.RareRandom FROM tblMobEquipmentItems INNER JOIN tblObject ON tblMobEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblMobEquipmentItems.MobID)=" & MyCLng(rsTargetPlayer!MobID) & ") AND ((tblObject.SSFuel)=0) AND ((tblObject.Gold)=0) AND ((tblObject.SSCryogenic)=0));", dbOpenSnapshot) 'we cannt steal gold items or fuel or cryogenic colonists
                                                                        Do While (Not rsTargetEquipment.EOF)
                                                                            lMagicFind = lOMagicFind
                                                                            lMagicFindBase = lOMagicFindBase 'without this the div by 2 would shrink for each items chance
                                                                            lMobRareRandom = MyCLng(rsTargetEquipment!RareRandom)
                                                                            If (InStr(zUcaseMobName, "MAGE") > 0 Or InStr(zUcaseMobName, "WIZA") > 0 Or InStr(zUcaseMobName, "DRAGON") > 0 Or InStr(zUcaseMobName, "PROF") > 0 Or InStr(zUcaseMobName, "STUD") > 0 Or InStr(zUcaseMobName, "DEX") > 0 Or InStr(zUcaseMobName, "STEAL") > 0 Or InStr(zUcaseMobName, "THIEF") > 0 Or InStr(zUcaseMobName, "ROGUE") > 0 Or InStr(zUcaseMobName, "BURGLAR") > 0 Or InStr(zUcaseMobName, "ASSASSIN") > 0 Or InStr(zUcaseMobName, "HOBBIT") > 0 Or InStr(zUcaseMobName, "FELPUR") > 0 Or InStr(zUcaseMobName, "HALFLING") > 0) Then
                                                                                lMobRareRandom = (lMobRareRandom * 2) 'harder to steal from these matches
                                                                                zStealInfo = zStealInfo & "[HARD STEALx2<vs " & lMobRareRandom & ">]"
                                                                            End If
                                                                            
                                                                            'We make magic find hard for steal cause really its cheap to bot steal
                                                                            
                                                                            If (bDay) Then 'harder to steal from mobs during the day
                                                                                If (Not bSentDayMsg) Then zStealInfo = zStealInfo & "[DAY TIME - Half Magicfinds]"
                                                                                bSentDayMsg = True
                                                                                lMagicFindBase = MyCLng(lMagicFindBase / 2)
                                                                                If lMagicFindBase < 1 Then lMagicFindBase = 1
                                                                                lMagicFind = MyCLng(lMagicFind / 2)
                                                                                If lMagicFind < 5 Then lMagicFindBase = 5
                                                                            End If
                                                                            
                                                                            If (lRandom(lMagicFind) + lMagicFindBase > lRandom(lMobRareRandom)) Then
                                                                                'bDoCosts = True
                                                                                'this will insert the object in the player's inventory
                                                                                lDuplicateObject MyCLng(rsTargetEquipment!ObjectID), lPlayerID, lPlayerLevel, False, False, True, 0
                                                                                lTargetEquipmentItemsStolen = lTargetEquipmentItemsStolen + 1
                                                                                If (lMobRareRandom <= lMagicFindBase + lRandom(lMagicFind)) Then 'if the mob lost it to easily then
                                                                                    Select Case lRandom(9)
                                                                                        Case 1
                                                                                            bWhisperedTo = True
                                                                                            bAttackPlayer = True
                                                                                            subSendMsg gblzFNYEL & zMobName & " whispers to you, 'You just won't leave me alone! BANZAI!'", zPortID
                                                                                        Case 2
                                                                                            bWhisperedTo = True
                                                                                            bAttackPlayer = True
                                                                                            subSendMsg gblzFNYEL & zMobName & " whispers to you, 'STOP STEALING FROM ME!'", zPortID
                                                                                        Case 3
                                                                                            bWhisperedTo = True
                                                                                            bAttackPlayer = True
                                                                                            subSendMsg gblzFNYEL & zMobName & " whispers to you, 'Not YOU again! DIE!'", zPortID
                                                                                        Case 4, 5
                                                                                            bWhisperedTo = True
                                                                                            bAttackPlayer = True
                                                                                            subSendMsg gblzFNYEL & zMobName & " whispers to you, 'Treasure digger! BANZAI!!!'", zPortID
                                                                                        Case Else
                                                                                            bWhisperedTo = False
                                                                                    End Select
                                                                                    If (bWhisperedTo) Then subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " is being whispered to by " & zMobName & ".", lX, lY, lZ, zPortID, ""
                                                                                    MyDB.Execute "UPDATE tblPlayer SET Alignment=[Alignment]-" & lRandom(100) & " WHERE (Race<>'UND' AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                    MyDB.Execute "UPDATE tblPlayer SET Alignment=(-1000+(CCHA/4)) WHERE (Race<>'UND') AND (Alignment < (-1000+(CCHA/4)) AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                End If
                                                                            Else
                                                                                bAttackPlayer = True
                                                                            End If
                                                                            rsTargetEquipment.MoveNext
                                                                        Loop
                                                                        Set rsTargetEquipment = Nothing
                                                                        
                                                                        If (lTargetEquipmentItemsStolen > 0) Then
                                                                            If (Len(zStealInfo) <> 0) Then zStealInfo = zStealInfo & " and "
                                                                            Select Case lTargetEquipmentItemsStolen
                                                                                Case 0
                                                                                Case 1
                                                                                    zStealInfo = zStealInfo & "one item"
                                                                                Case Else
                                                                                    zStealInfo = zStealInfo & lTargetEquipmentItemsStolen & " items"
                                                                            End Select
                                                                        End If
                                                                    End If
                                                                    zStealInfo = MyCStr(zStealInfo)
                                                                    If (Len(zStealInfo) <> 0) Then
                                                                        subSendMsg "&yYou steal " & zStealInfo & " from " & zMobName & "!", zPortID
                                                                        subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " steals " & zStealInfo & " from " & zMobName & "!", lX, lY, lZ, zPortID, ""
                                                                    Else
                                                                        subSendMsg "&gYou fail to steal anything from " & zMobName & ".", zPortID
                                                                    End If
                                                                Else
                                                                    If (lRandom(lMagicFindObjectBonus) = 1) Then
                                                                        bAttackPlayer = True
                                                                    Else
                                                                        subSendMsg "&gThe creature was just stolen from, you will have to wait.", zPortID
                                                                    End If
                                                                End If
                                                            
                                                                If (bAttackPlayer) Then
                                                                    'If (MyCLng(rsTargetPlayer!MobEmotePlayerAllowed) <> 0) Then
                                                                        MyDB.Execute "UPDATE tblMob INNER JOIN tblArea ON (tblMob.Z = tblArea.Z) AND (tblArea.Y = tblMob.Y) AND (tblMob.X = tblArea.X) SET tblMob.PlayerID = " & lPlayerID & " WHERE ((tblMob.MobName LIKE '*guard*') AND (tblMob.NeverAttackable=0 AND tblArea.WhereID=" & lWhereID & "));", dbFailOnError 'there is no casesensitive with sql LIKE cmd
                                                                        subChannelYellMob zMobName, lWhereID, zPlayerName & " you  T H I E F!", bInvisible
                                                                        If lRandom(lReturnTranslateCharismaticBonus(zRace, zClass)) + 5 < lRandom(25) Then gbllQuestGuardFailCount(lPortID) = gbllQuestGuardFailCount(lPortID) + lRandom(3) 'bad guards steal! banzi!
                                                                        MyDB.Execute "UPDATE tblPlayer SET LazyGuardLevel=" & gbllQuestGuardFailCount(lPortID) & ", SneakingMovesLeft=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                        'subPlayerRecordMobDetails MyCLng(rsTargetPlayer!MobID), lPlayerID, "T"
                                                                    'End If
                                                                    
                                                                    MyDB.Execute "UPDATE tblMob SET StealDelay=55+" & lRandom(45) & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & MyCLng(rsTargetPlayer!MobID) & ");", dbFailOnError 'mark player to hunt
                                                                    
                                                                    rSCombat(lPortID).iStatus = cstiStatusPlayerVsMob
                                                                    rMCombat(lPortID).Name = MyCStr(rsTargetPlayer!MobName)
                                                                    rMCombat(lPortID).lID = MyCLng(rsTargetPlayer!MobID)
                                                                    
                                                                    rPCombat(lPortID).Name = zPlayerName
                                                                    rPCombat(lPortID).lID = lPlayerID
                                                                    
                                                                    basTriggerGuardsArea lPlayerID, lX, lY, lZ

                                                                    subSendMsg "&R" & zMobName & " attacks YOU!", zPortID
                                                                    subSendMsgAreaExcept2 "&R" & zMobName & " attacks " & zPlayerName & "!", lX, lY, lZ, zPortID, ""
                                                                Else
                                                                    If (lRandom(lMagicFindObjectBonus) < lRandom(5)) Then MyDB.Execute "UPDATE tblMob SET StealDelay=" & 1 + lRandom(3) & " WHERE (MobID=" & MyCLng(rsTargetPlayer!MobID) & ");", dbFailOnError 'mark player to hunt
                                                                End If
                                                            Else
                                                                subSendMsg "&gThat creature of the realm is not here." & vbCrLf & gblzFNMAG & vbCrLf & "&gMOB SYNTAX: STEAL MOBNAME      - no item name required" & vbCrLf & "PLAYER SYNTAX: STEAL ITEMNAME PLAYERNAME      - item name required", zPortID
                                                            End If
                                                        Else
                                                            subSendMsgAreaAllDISmart "&y", zPlayerName, "&g*Out of Reach* &mYou fail to steal from [fly@" & Format((lFlyHeight / glblCentimetreToFeetConverter), "FIXED") & "ft] " & zMobName & ".", "", "&g*Out of Reach* &m%s1 fails to steal from [fly@" & Format((lFlyHeight / glblCentimetreToFeetConverter), "FIXED") & "ft] " & zMobName & ".", lX, lY, lZ
                                                        End If
                                                    Else
                                                        subSendMsg "&gThat creature of the realm is not here." & vbCrLf & gblzFNMAG & vbCrLf & "&gMOB SYNTAX: STEAL MOBNAME      - no item name required" & vbCrLf & "PLAYER SYNTAX: STEAL ITEMNAME PLAYERNAME      - item name required", zPortID
                                                    End If
                                                End If
                                                Set rsTargetPlayer = Nothing
                                                
                                                MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul] - " & lSoulCost & ", CMove = [CMove] - " & lMoveCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'If (bDoCosts) Then
                                            Else
                                                subSendMsg "&gSteal from whom?", zPortID
                                            End If
                                        Else
                                            subSendMsg "&RYou don't have enough soul to steal. You are short " & lSoulCost - lSoul & " points.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&RYou don't have enough move to steal. You are short " & lMoveCost - lMove & " points.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou are blind you cannot see to attempt a steal.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou cannot steal here.", zPortID
                            End If
                        Else
                            subSendMsg "&RYou are too scared to steal right now.", zPortID
                        End If
                    Else
                        subSendMsg "&RYou cannot do that when you are fighting.", zPortID
                    End If
                Else
                    subSendMsg "&gINVENTORY: You have ten items already, sell some to perform this delicate steal.", zPortID
                End If
            Else
                subSendMsg "&RYou cannot steal when invisible!", zPortID
            End If
            Else
                subSendMsg "&GYou dream about stealing gold from a wealthy player.", zPortID
            End If
        Else
            subSendMsg "&RYou are an outcasted player you cannot steal anything!", zPortID
        End If
        Else
            subSendMsg "&gYou cannot do that when you are a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & "!", zPortID
        End If
        Else
            subSendMsg "&gYou cannot do that when you are a Witchlock.", zPortID
        End If
        Else
            subSendMsg "&gFirst you need to &GFACTION COMMAND", zPortID
        End If
    Else
        subSendMsg "&RSYSTEM ERROR! STEAL FAILED! PLAYER FILE NOT FOUND!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subThiefSteal," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subDigFind(lX As Long, lY As Long, lZ As Long, zPortID As String, lPlayerID As Long, zPlayerName As String, lStatus As Long, lCMove As Long)
'This is like search area but digging.
On Error GoTo Err_Check
    Const cstlMoveCost = 425
    Dim zObjectName As String
    Dim rsObject As Recordset
    If (lStatus <> 50) Then
        If (lCMove >= cstlMoveCost) Then
            MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-" & cstlMoveCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            Set rsObject = MyDB.OpenRecordset("SELECT ObjectName, Burried, X, Y, Z FROM tblObject WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Burried=True);", dbOpenDynaset)
            If (Not rsObject.EOF) Then
                zObjectName = zAdverb(MyCStr(rsObject!ObjectName), 2) & zShortstop(MyCStr(rsObject!ObjectName))
                rsObject.Edit
                rsObject!Burried = False
                rsObject.Update
                subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 uncover " & zObjectName & ".", "", "%s1 uncovers " & zObjectName & ".", lX, lY, lZ
                'subSendMsg "&yYou uncover " & zAdverb(MyCStr(rsObject!ObjectName), 2) & zShortstop(MyCStr(rsObject!ObjectName)) & " in the area!", zPortID
                'subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " uncovers " & zAdverb(MyCStr(rsObject!ObjectName), 2) & zShortstop(MyCStr(rsObject!ObjectName)) & "!", lX, lY, lZ, zPortID, ""
            Else
                subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 do not uncover anything.", "", "%s1 digs here a moment then stops.", lX, lY, lZ
                'subSendMsg "&gYou don't uncover anything.", zPortID
                'subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " digs here a moment and stops.", lX, lY, lZ, zPortID, ""
            End If
            Set rsObject = Nothing
        Else
            subSendMsg "&gYou need " & cstlMoveCost & " move to dig here.", zPortID
        End If
    Else
        subSendMsg "&GYou are asleep you cannot move.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDigFind," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBury(lX As Long, lY As Long, lZ As Long, zObject As String, zPortID As String, lPlayerID As Long, zPlayerName As String, lStatus As Long, lCMove As Long)
On Error GoTo Err_Check
    Const cstlMoveCost = 500
    Dim rsObject As Recordset
    Dim bBuryAllowed As Boolean
    Dim bPlayerOnShip As Boolean
    Dim bPlayerInClanHall As Boolean
    Dim bPlayerInHouse As Boolean
    Dim iGetLocationValue As Integer
    Dim lObjectID As Long
    Dim lWeight As Long
    Dim zObjectName As String
    
    Select Case zAreaRules(10, lX, lY, lZ)
        Case 0 'No drop or bury spot
            subSendMsg "&RA magical barrier prevents you from burying anything here.", zPortID
        Case 1 'Allowed
            If (lCMove >= cstlMoveCost) Then
                bPlayerInHouse = False
                bPlayerOnShip = False
                bPlayerInClanHall = False
                MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-" & cstlMoveCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                iGetLocationValue = iPlayerLocationValue(lPlayerID)
                Select Case (iGetLocationValue)
                    Case 0, 10, 12, 13
                        bPlayerInHouse = (iGetLocationValue = 10 Or iGetLocationValue = 12)
                        bPlayerOnShip = (iGetLocationValue = 11)
                        bPlayerInClanHall = (iGetLocationValue = 13)
                        bBuryAllowed = True
                    Case Else '11 cant bury on a starship
                        bBuryAllowed = False
                End Select
                
                If (bBuryAllowed And Not bPlayerInClanHall And Not bPlayerInHouse And Not bPlayerOnShip) Then
                    If (lStatus <> 50) Then
                        If (lTotalObjectsInArea(lX, lY, lZ) < gblcstlMaxAreaObjects) Then
                            Set rsObject = MyDB.OpenRecordset("SELECT tblPlayerInventoryItems.PlayerID, tblObject.Weight, tblObject.Cursed, tblObject.ObjectName, tblObject.Burried, tblObject.ObjectID, tblObject.X, tblObject.Y, tblObject.Z, tblObject.CaptureFlagClanID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.ObjectName) Like ""*" & zObject & "*"") AND ((tblObject.CaptureFlagClanID)=0) AND ((tblObject.WeightMax)=0) AND ((tblObject.ReturnPlayerID)=0));", dbOpenSnapshot)
                            If (Not rsObject.EOF) Then
                                zObjectName = zShortstop(MyCStr(rsObject!ObjectName))
                                zObjectName = zAdverb(zObjectName, 2) & zObjectName
                                If (MyCInt(rsObject!Cursed) = 0) Then
                                    lObjectID = MyCLng(rsObject!ObjectID)
                                    lWeight = MyCLng(rsObject!Weight)
                                    MyDB.Execute "UPDATE tblPlayer SET Weight=[Weight]-" & lWeight & " WHERE PlayerID=" & lPlayerID & ";", dbFailOnError
                                    MyDB.Execute "UPDATE tblObject SET PlayerID = 0, Status = 0, Burried = True, GroundTimerNotAvailable = " & (bPlayerInHouse Or bPlayerOnShip Or bPlayerInClanHall) & ", X = " & lX & ", Y = " & lY & ", Z = " & lZ & " WHERE (ObjectID=" & lObjectID & ");", dbFailOnError
                                    MyDB.Execute "DELETE PlayerID, ObjectID FROM tblPlayerInventoryItems WHERE (PlayerID=" & lPlayerID & " AND ObjectID=" & lObjectID & ");", dbFailOnError
                                    
                                    subSendMsgAreaAllDISmart "&y", zPlayerName, "%s1 bury " & zObjectName & ".", "", "%s1 buries " & zObjectName & ".", lX, lY, lZ
                                    'subSendMsg "&yYou bury " & zObjectName & ".", zPortID
                                    'subSendMsgAreaExcept2 gblzFNYEL & zPlayerName & " buries " & zObjectName & ".", lX, lY, lZ, zPortID, ""
                                Else
                                    subSendMsg "&RYou cannot let go of " & zObjectName & "!", zPortID
                                    'subSendMsgAreaExcept2 "&R" & zPlayerName & " tries to bury " & zObjectName & " but cannot let go of it!", lX, lY, lZ, zPortID, ""
                                End If
                            Else
                                subSendMsg "&gYou don't see that in your inventory." & vbCrLf & "You cannot bury some items," & vbCrLf & "Containers, Stamped items, or Clan Flags.", zPortID
                            End If
                            Set rsObject = Nothing
                        Else
                            subSendMsg "&gThere are too many objects in the area.", zPortID
                        End If
                    Else
                        subSendMsg "&GYou are asleep you cannot move.", zPortID
                    End If
                Else
                    subSendMsg "&RThe floor is too solid to bury anything here.", zPortID
                End If
            Else
                subSendMsg "&gYou need " & cstlMoveCost & " move to bury something here.", zPortID
            End If
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subBury," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatMissileTarget(zPortID As String, zTargetName As String, bVerbose As Boolean, bOverrideLock As Boolean)
On Error GoTo Err_Check
'1: We check to make sure the player is holding a misslile weapon: bow, xbow, or sling
'2: We make sure the mob's respawn or player is alive.
'3: We add the mob or player to the target ID
    Dim rsPlayer As Recordset
    Dim rsTarget As Recordset
    Dim zAdVerbName As String
    Dim bTargetAquired As Boolean
    Dim lMissileTargetID As Long
    Dim lMissileStatus As Long
    
    Dim bPlayerFound As Boolean
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zClass As String
    Dim lStatus As Long
    
    bPlayerFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT Status, Class, X, Y, Z, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zClass = MyCStr(rsPlayer!Class)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    
    'subCombatMissileTarget zPortID, lPlayerID, zWord(3), lX, lY, lZ
    If (bPlayerFound) Then
        If (zAreaRules(1, lX, lY, lZ) = "1") Then
            '(bCanClassWearWeaponType(zClass, "BOW") Or bCanClassWearWeaponType(zClass, "XBOW") Or bCanClassWearWeaponType(zClass, "SLIN") Or bCanClassWearWeaponType(zClass, "NET"))
            If (lStatus = 5 Or bOverrideLock) Then
                zAdVerbName = ""
                lMissileTargetID = 0
                lMissileStatus = 0
                
                bTargetAquired = False
                
                Set rsTarget = MyDB.OpenRecordset("SELECT MobID, MobName, X, Y, Z, RespawnDelay FROM tblMob WHERE (MobName Like ""*" & zTargetName & "*"" AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND RespawnDelay=0 AND NeverAttackable=0);", dbOpenSnapshot)
                If (Not rsTarget.EOF) Then
                    zAdVerbName = zShortstop(MyCStr(rsTarget!MobName))
                    zAdVerbName = zAdverb(zAdVerbName, 2) & zAdVerbName
                    lMissileTargetID = MyCLng(rsTarget!MobID)
                    MyDB.Execute "UPDATE tblMob SET BeconPlayerID=" & lPlayerID & " WHERE (MobID=" & lMissileTargetID & ");", dbFailOnError 'the mob will start to fire arrows back if possible and verbally harass the player
                    lMissileStatus = 1 'Mob
                    
                    bTargetAquired = True
                End If
                Set rsTarget = Nothing
                
                If (Not bTargetAquired) Then 'now we check the players
                    Set rsTarget = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, X, Y, Z FROM tblPlayer WHERE (PlayerName Like ""*" & zTargetName & "*"" AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND InvisibilityDuration=0 AND CamoflaguedDuration=0 AND HideDuration=0 AND Len([PortID])>1);", dbOpenSnapshot)
                    If (Not rsTarget.EOF) Then
                        zAdVerbName = zShortstop(MyCStr(rsTarget!PlayerName))
                        zAdVerbName = zAdverb(zAdVerbName, 2) & zAdVerbName
                        lMissileTargetID = MyCLng(rsTarget!PlayerID)
                        lMissileStatus = 2 'Player
                        
                        bTargetAquired = True
                    End If
                    Set rsTarget = Nothing
                End If
                
                If (bTargetAquired) Then
                    MyDB.Execute "UPDATE tblPlayer SET MissileTargetID= " & lMissileTargetID & ", MissileStatus=" & lMissileStatus & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                    subSendMsg "&GRANGE TARGET [" & zAdVerbName & "]", zPortID
                Else
                    If (Not bVerbose) Then subSendMsg "&RThat target is not here.", zPortID
                End If
            Else
                subSendMsg "&gYou must be standing to target anything.", zPortID
            End If
        Else
            subSendMsg "&BA magical barrier here prevents you from using your ranged weapons.", zPortID
        End If
    Else
        subSendMsg "&RYour player was not found report this to an immortal.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatMissileTarget," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subForceInterrupt(lIASChance As Long, zDPortID As String, zPortID As String, lChance As Long)
On Error GoTo Err_Check
    Dim lDPortID As Long
    If (lRandom(lChance) = 1) Then
        Select Case (lRandom(lIASChance) > lRandom(100)) 'the player is skilled in netting or missile distract so its a constant 100 non comparing chance
            Case True
                lDPortID = MyCLng(zDPortID)
                If (lDPortID >= cstlMinPort And lDPortID <= cstlMaxPort) Then
                    gblbInterruptPlayer(lDPortID) = True
                    subSendMsg "&A(you interrupt the target)", zPortID
                End If
            Case Else
                subSendMsg "&A(you attempted to interrupt the target)", zPortID
        End Select
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subForceInterrupt," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCombatMissileWeapons(zPortID As String)
On Error GoTo Err_Check
'1: Check to make sure the Target is aquired and in range.
'2: we check to see if the player's other hand is free first before: a) we pull back the bow string b) we crank back the crossbow c) we pull back the sling
'3: we check to see if the proper missile ammo is available for the missile type in the player's inventory
'4: we make sure some ammo is available
'5: we get the name of the missile weapon using the weapon name - ARROW for BOW, BOLT for CROSSBOW, STONE for SLINGS
'6: We use the missile name to check the player's inventory for the ammo.
'7: If we use up the ammo we delete the empty quiver.
    Const cstlPerfectShotValue = 700
    Dim rsPlayer As Recordset
    Dim rsTarget As Recordset
    Dim rsMissileWeapon As Recordset
    Dim zSQL As String
    Dim lMAntiMoveDuration As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMMoveAllowed As Long
    Dim zAdVerbName As String
    Dim lRange As Long
    Dim zMissileName As String
    Dim lMissileWeaponID As Long
    Dim lMissileAmmoGroupAmt As Long
    Dim lMissileAmmoID As Long
    Dim lHandsFull As Long
    Dim lTargetID As Long
    Dim bCorrectAmmo As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim lMissileFinalDamageTotal As Long
    Dim bTargetAquired As Boolean
    Dim lXP As Long
    Dim lMissileAverageDamage As Long
    Dim lBaseAttribDmg As Long
    Dim zDPortID As String
    Dim bMissileWeapon As Boolean
    Dim lTotalHP As Long
    Dim bAutoLoot As Boolean
    Dim iMessedUp As Integer
    Dim iHit As Integer
    Dim bMobTargeted As Boolean
    Dim bPlayerTargeted As Boolean
    Dim zDirection As String
    Dim zDirectionCameFrom As String
    Dim lObjectSlayChance As Long
    Dim bPlayerFound As Boolean
    Dim bBounty As Boolean
    Dim lPlayerID As Long
    Dim lMagicFind As Long
    Dim lMagicFindBase As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zClass As String
    Dim lMissileTargetID  As Long
    Dim lMissileStatus As Long
    Dim lWeaponSkillMissileRangeClassLevel As Long
    Dim lPlayerLevel As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lCDEX As Long
    Dim lCCon As Long
    Dim lCCHA As Long
    Dim lCLuc As Long
    Dim lQuestMobID As Long
    Dim zPlayerName As String
    Dim lStunDuration As Long
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration  As Long
    Dim lInvisibilityDuration As Long
    Dim lStatus As Long
    Dim lDistance As Long
    Dim lMissileDistance As Long
    Dim lSlayChance As Long
    Dim lTLevel As Long
    Dim bCanSlayChance As Boolean
    Dim bWatchSpeed As Boolean
    Dim lPortID As Long
    Dim lStance As Long
    Dim lEntanglementDuration As Long
    Dim lIASChance As Long
    Dim lHoldGold As Long
    Dim lGold As Long
    Dim bMSpecialSelfDeleting As Boolean
    Dim lMSpecialGloryPlayerAmt As Long
    Dim lPlayerTotalStats As Long
    Dim lMHerdMobID As Long
    Dim iDamageResult As Integer
    Dim lSpeedShooting As Long
    Dim zMissileWeaponType As String
    
    iMessedUp = -1
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
    If (gbltDurations(lPortID).lPullMissile = 0) Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT TurnedIntoAnimalType, CStr, CInt, CWis, CDex, CCon, CCha, CLuc, XP, Gold, QuestMobID, IASChance, EntanglementDuration, Stance, MagicFindBase, MagicFind, SlayChance, InvisibilityDuration, Status, SleepDuration, StunDuration, PlayerFleeDuration, PlayerName, PlayerLevel, WeaponSkillMissileRangeClassLevel, MissileStatus, MissileTargetID, Status, Class, X, Y, Z, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lCStr = MyCLng(rsPlayer!CStr)
            lCINT = MyCLng(rsPlayer!CInt)
            lCWIS = MyCLng(rsPlayer!CWIS)
            lCDEX = MyCLng(rsPlayer!CDEX)
            lCCon = MyCLng(rsPlayer!CCon)
            lCCHA = MyCLng(rsPlayer!CCHA)
            lCLuc = MyCLng(rsPlayer!CLuc)
            lPlayerTotalStats = lCStr + lCINT + lCWIS + lCDEX + lCCon + lCCHA + lCLuc + lPlayerLevel
            lXP = MyCLng(rsPlayer!XP)
            lHoldGold = 0
            lGold = MyCLng(rsPlayer!Gold)
            lIASChance = MyCLng(rsPlayer!IASChance)
            lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration) 'If (lEntanglementDuration = 0) Then    subSendMsg "&RYou are ensnared and cannot move.", zPortID
            lStance = MyCLng(rsPlayer!stance)
            lSlayChance = MyCLng(rsPlayer!SlayChance)
            bPlayerFound = True
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            lQuestMobID = MyCLng(rsPlayer!QuestMobID)
            lMagicFind = MyCLng(rsPlayer!MagicFind)
            lMagicFindBase = MyCLng(rsPlayer!MagicFindBase)
            zClass = MyCStr(rsPlayer!Class)
            Select Case zClass
                Case "KN"
                    lSlayChance = MyCLng((lSlayChance) + MyCLng(lSlayChance * 0.25))
                Case "RA"
                    lSlayChance = MyCLng((lSlayChance) + MyCLng(lSlayChance * 0.8)) 'ranger gets this bonus too but only with a bow
            End Select
            lStatus = MyCLng(rsPlayer!Status)
            lMissileTargetID = MyCLng(rsPlayer!MissileTargetID)
            lMissileStatus = MyCLng(rsPlayer!MissileStatus)
            lWeaponSkillMissileRangeClassLevel = MyCLng(rsPlayer!WeaponSkillMissileRangeClassLevel)
            lStunDuration = MyCLng(rsPlayer!StunDuration)
            lSleepDuration = MyCLng(rsPlayer!SleepDuration)
            lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
            lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        Else
            bPlayerFound = False
        End If
        Set rsPlayer = Nothing
        
        If (bPlayerFound) Then
            If (lInvisibilityDuration = 0) Then
            If (lTurnedIntoAnimalType = 0) Then 'have to be humanoid not a pumpkin, or frog, or mouse or dog or w/e
            If (lEntanglementDuration = 0 Or zClass = "CY") Then 'cyborg isnt affected by entanglement
                If (lStance = 0 Or zClass = "RA") Then 'rangers can do just about anything with a bow
                If (lStatus = 5) Then 'standing mode, not asleep or in battle, during battle the ranger can type STAND to fix this for some typing fun
                    If (lSleepDuration = 0) Then
                        If (lStunDuration = 0) Then
                            If (lPlayerFleeDuration = 0) Then
                                lSpeedShooting = 0
                                bCanSlayChance = False
                                lMissileFinalDamageTotal = MyCLng(lPlayerLevel / 4) 'there are many more calculations below
                                lMissileDistance = 0
                                
                                bCorrectAmmo = False
                                zMissileName = ""
                                lMissileAmmoGroupAmt = 0
                                zDPortID = ""
                                bMobTargeted = False
                                bPlayerTargeted = False
                                Select Case lMissileStatus
                                    Case 1 'Mob
                                        bMobTargeted = (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lMissileTargetID & " AND RespawnDelay=0 AND NeverAttackable=0);") <> 0)
                                    Case 2 'Player
                                        bPlayerTargeted = (lngSQLRecordCount("SELECT PlayerID, PortID FROM tblPlayer WHERE (PlayerID=" & lMissileTargetID & " AND Len([PortID])>1);") <> 0)
                                End Select
                                
                                If (bMobTargeted Or bPlayerTargeted) Then
                                    'We get the name for the missile weapon
                                    bMissileWeapon = False
                                    lObjectSlayChance = 0
                                    lMissileAverageDamage = 0
                                    Set rsMissileWeapon = MyDB.OpenRecordset("SELECT tblObject.SlayChance, tblObject.MissileAverageDamage, tblObject.ObjectID, tblObject.PlayerID, tblObject.WeaponType, tblObject.Location FROM tblObject INNER JOIN tblPlayerEquipmentItems ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID WHERE (((tblObject.PlayerID)=" & lPlayerID & ") AND ((tblObject.WeaponType)='MGUN' Or (tblObject.WeaponType)='PHAS' Or (tblObject.WeaponType)='BOW' Or (tblObject.WeaponType)='XBOW' Or (tblObject.WeaponType)='SLIN') AND ((tblObject.Location)=20));", dbOpenSnapshot)
                                    If (Not rsMissileWeapon.EOF) Then
                                        lObjectSlayChance = lObjectSlayChance + MyCLng(rsMissileWeapon!SlayChance)
                                        bMissileWeapon = True
                                        lMissileAverageDamage = lMissileAverageDamage + MyCLng(rsMissileWeapon!MissileAverageDamage)
                                        lMissileWeaponID = MyCLng(rsMissileWeapon!ObjectID)
                                        zMissileWeaponType = MyCStr(rsMissileWeapon!WeaponType)
                                        Select Case zMissileWeaponType
                                            Case "MGUN"
                                                zMissileName = "bullet" 'CLIP or AMMO is the same thing Player holds a machinegun
                                            Case "PHAS"
                                                zMissileName = "energy" 'BLAST or ENERGY same thing. Player holds a phaser
                                            Case "BOW"
                                                zMissileName = "arrow" 'Player holds a missile weapon
                                            Case "XBOW"
                                                zMissileName = "bolt" 'Player holds a missile weapon
                                            Case "SLIN"
                                                zMissileName = "stone" 'Player holds a missile weapon
                                        End Select
                                    Else
                                        subSendMsg "&gYou are not holding a missile weapon to target or fire with.", zPortID
                                    End If
                                    Set rsMissileWeapon = Nothing
                                    
                                    If (bMissileWeapon) Then
                                        'We get the amount of ammo for the missile weapon
                                        Set rsMissileWeapon = MyDB.OpenRecordset("SELECT tblObject.SlayChance, tblObject.MissileAverageDamage, tblObject.ObjectID, tblObject.PlayerID, tblObject.WeaponType, tblObject.MissileGroupAmount FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.PlayerID)=" & lPlayerID & ") AND ((tblObject.WeaponType)='CLIP' Or (tblObject.WeaponType)='BLAS' Or (tblObject.WeaponType)='ARRO' Or (tblObject.WeaponType)='BOLT' Or (tblObject.WeaponType)='STON') AND ((tblObject.MissileGroupAmount)>0));", dbOpenSnapshot)
                                        Do While (Not rsMissileWeapon.EOF And bCorrectAmmo = False)
                                            zMissileWeaponType = MyCStr(rsMissileWeapon!WeaponType)
                                            Select Case UCase(zMissileName)
                                                Case "CLIP", "AMMO", "BULLET" 'ammo clip
                                                    If (zMissileWeaponType = "CLIP" Or zMissileWeaponType = "AMMO") Then
                                                        lSpeedShooting = 1 'makes it a natural machine gun
                                                        lMissileAverageDamage = lMissileAverageDamage + MyCLng(rsMissileWeapon!MissileAverageDamage)
                                                        lObjectSlayChance = lObjectSlayChance + MyCLng(rsMissileWeapon!SlayChance)
                                                        bCanSlayChance = True
                                                        bCorrectAmmo = True
                                                        lMissileFinalDamageTotal = lMissileFinalDamageTotal * 8
                                                    End If
                                                Case "BLAST", "ENERGY" 'blasts of energy
                                                    If (zMissileWeaponType = "BLAS" Or zMissileWeaponType = "ENER") Then
                                                        lSpeedShooting = 2 'makes it a natural pulse gun
                                                        lMissileAverageDamage = lMissileAverageDamage + MyCLng(rsMissileWeapon!MissileAverageDamage)
                                                        lObjectSlayChance = lObjectSlayChance + MyCLng(rsMissileWeapon!SlayChance)
                                                        bCanSlayChance = True
                                                        bCorrectAmmo = True
                                                        lMissileFinalDamageTotal = lMissileFinalDamageTotal * 16
                                                    End If
                                                Case "ARROW"
                                                    If (zMissileWeaponType = "ARRO") Then
                                                        lMissileAverageDamage = lMissileAverageDamage + MyCLng(rsMissileWeapon!MissileAverageDamage)
                                                        lObjectSlayChance = lObjectSlayChance + MyCLng(rsMissileWeapon!SlayChance)
                                                        If (lRandom(4) = 1) Then bCanSlayChance = True
                                                        bCorrectAmmo = True
                                                        lMissileFinalDamageTotal = lMissileFinalDamageTotal * 3
                                                    End If
                                                Case "BOLT"
                                                    If (zMissileWeaponType = "BOLT") Then
                                                        lMissileAverageDamage = lMissileAverageDamage + MyCLng(rsMissileWeapon!MissileAverageDamage)
                                                        lObjectSlayChance = lObjectSlayChance + MyCLng(rsMissileWeapon!SlayChance)
                                                        If (lRandom(3) = 1) Then bCanSlayChance = True
                                                        bCorrectAmmo = True
                                                        lMissileFinalDamageTotal = lMissileFinalDamageTotal * 4
                                                    End If
                                                Case "STONE"
                                                    If (MyCStr(rsMissileWeapon!WeaponType) = "STON") Then
                                                        lObjectSlayChance = lObjectSlayChance + MyCLng(rsMissileWeapon!SlayChance)
                                                        bCorrectAmmo = True
                                                        lMissileFinalDamageTotal = lMissileFinalDamageTotal * 2
                                                    End If
                                            End Select
                                            
                                            lMissileAverageDamage = lRandom(lMissileAverageDamage)
                                            lBaseAttribDmg = lRandom(MyCLng(lCDEX / 2)) + MyCLng(lCDEX / 2) + lRandom(MyCLng(lCStr / 2))
                                            lMissileFinalDamageTotal = lMissileFinalDamageTotal + lMissileAverageDamage + lBaseAttribDmg
                                            
                                            If (bCorrectAmmo) Then
                                                lMissileAmmoID = MyCLng(rsMissileWeapon!ObjectID)
                                                lMissileAmmoGroupAmt = MyCLng(rsMissileWeapon!MissileGroupAmount)
                                            End If
                                            rsMissileWeapon.MoveNext
                                        Loop
                                        Set rsMissileWeapon = Nothing
                                        
                                        If (Len(zMissileName) > 0) Then
                                            'Number of empty hands
                                            lHandsFull = 0
                                            Set rsMissileWeapon = MyDB.OpenRecordset("SELECT tblObject.PlayerID, tblObject.Location FROM tblObject INNER JOIN tblPlayerEquipmentItems ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID WHERE (((tblObject.PlayerID)=" & lPlayerID & ") AND ((tblObject.Location)=20));", dbOpenSnapshot)
                                            If (Not rsMissileWeapon.EOF) Then
                                                rsMissileWeapon.MoveLast
                                                lHandsFull = rsMissileWeapon.RecordCount
                                            End If
                                            Set rsMissileWeapon = Nothing
                                            
                                            Select Case lHandsFull
                                                Case 0
                                                    subSendMsg "&gYou are not holding a missile weapon.", zPortID
                                                Case 1
                                                    If (lMissileAmmoGroupAmt > 0) Then
                                                        'We subtract one from the ammo group value.
                                                        MyDB.Execute "UPDATE tblObject SET MissileGroupAmount = [MissileGroupAmount]-1 WHERE (ObjectID=" & lMissileAmmoID & ");", dbFailOnError
                                                        
                                                        If (bCorrectAmmo) Then
                                                            Select Case (lMissileAmmoGroupAmt - 1)
                                                                Case 0
                                                                    subSendMsg "&yYou are now out of " & zMissileName & "s.", zPortID
                                                                Case Else
                                                                    subSendMsg "&yYou check your ammo and find " & lMissileAmmoGroupAmt - 1 & " " & zMissileName & "(s) left.", zPortID
                                                            End Select
                                                            
                                                            Select Case lMissileStatus
                                                                Case 1 'Mob
                                                                    zSQL = "SELECT AntiMoveDuration, MoveAllowed, HerdMobID, SpecialGloryPlayerAmt, SpecialSelfDeleting, DefeatedMobDesc, MobLevel, MHP, MobID, MobName, X, Y, Z FROM tblMob WHERE (MobID=" & lMissileTargetID & " AND RespawnDelay=0);"
                                                                Case 2 'Player
                                                                    zSQL = "SELECT PlayerLevel, CHP, PlayerID, PlayerName, X, Y, Z, PortID FROM tblPlayer WHERE (PlayerID=" & lMissileTargetID & " AND Len([PortID])>1);"
                                                            End Select
                                                            
                                                            lTX = 0
                                                            lTY = 0
                                                            lTZ = 0
                                                            
                                                            lRange = lWeaponSkillMissileRangeClassLevel
                                                            
                                                            bTargetAquired = False
                                                            'We get the X, Y, Z location of the target
                                                            Set rsTarget = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                                            If (Not rsTarget.EOF) Then
                                                                Select Case lMissileStatus
                                                                    Case 1 'Mob
                                                                        lMAntiMoveDuration = MyCLng(rsTarget!AntiMoveDuration)
                                                                        lMMoveAllowed = MyCLng(rsTarget!MoveAllowed)
                                                                        lMHerdMobID = MyCLng(rsTarget!HerdMobID)
                                                                        lMSpecialGloryPlayerAmt = MyCLng(rsTarget!SpecialGloryPlayerAmt)
                                                                        bMSpecialSelfDeleting = (MyCInt(rsTarget!SpecialSelfDeleting) <> 0)
                                                                        bBounty = (Len(MyCStr(rsTarget!DefeatedMobDesc)) > 0)
                                                                        lTLevel = MyCLng(rsTarget!MobLevel)
                                                                        lTotalHP = MyCLng(rsTarget!MHP)
                                                                    Case 2 'Player
                                                                        lMSpecialGloryPlayerAmt = 0
                                                                        bMSpecialSelfDeleting = False
                                                                        bBounty = False
                                                                        lTLevel = MyCLng(rsTarget!PlayerLevel)
                                                                        lTotalHP = MyCLng(rsTarget!CHP)
                                                                End Select
                                                                
                                                                bTargetAquired = True
                                                                lTX = MyCLng(rsTarget!x)
                                                                lTY = MyCLng(rsTarget!y)
                                                                lTZ = MyCLng(rsTarget!z)
                                                                
                                                                If (lX = lTX And lY = lTY And lZ = lTZ) Then
                                                                    lRange = lRange + 1 'we allow a player to shoot in the same room with a mob ALWAYS
                                                                Else
                                                                    If (lRange = 0) Then subSendMsg "&RYou do not have the range to shoot that far.", zPortID
                                                                End If
                                                                
                                                                Select Case lMissileStatus
                                                                    Case 1 'Mob
                                                                        lTargetID = MyCLng(rsTarget!MobID)
                                                                        zAdVerbName = zShortstop(MyCStr(rsTarget!MobName))
                                                                    Case 2 'Player
                                                                        zDPortID = MyCStr(rsTarget!PortID)
                                                                        lTargetID = MyCLng(rsTarget!PlayerID)
                                                                        zAdVerbName = zShortstop(MyCStr(rsTarget!PlayerName))
                                                                End Select
                                                                zAdVerbName = zAdverb(zAdVerbName, 2) & zAdVerbName
                                                            End If
                                                            Set rsTarget = Nothing
                                                            
                                                            If (bTargetAquired) Then
                                                                'We get the math directions towards the target
                                                                lPX = lTX - lX 'get the path x
                                                                lPY = lTY - lY 'get the path y
                                                                lPZ = lTZ - lZ 'get the path z
                                                                lDistance = Abs(lPX) + Abs(lPY) + Abs(lPZ)
                                                                zDirection = ""
                                                                zDirectionCameFrom = ""
                                                                If (lPY > 0) Then
                                                                    lPY = 1
                                                                    zDirection = "S"
                                                                    zDirectionCameFrom = "N"
                                                                End If
                                                                If (lPY < 0) Then
                                                                    lPY = -1
                                                                    zDirection = "N"
                                                                    zDirectionCameFrom = "S"
                                                                End If
                                                                If (lPX > 0) Then
                                                                    lPX = 1
                                                                    zDirection = zDirection & "E"
                                                                    zDirectionCameFrom = zDirectionCameFrom & "W"
                                                                End If
                                                                If (lPX < 0) Then
                                                                    lPX = -1
                                                                    zDirection = zDirection & "W"
                                                                    zDirectionCameFrom = zDirectionCameFrom & "E"
                                                                End If
                                                                If (lPZ > 0) Then
                                                                    lPZ = 1
                                                                    zDirection = zDirection & "D"
                                                                    zDirectionCameFrom = zDirectionCameFrom & "U"
                                                                End If
                                                                If (lPZ < 0) Then
                                                                    lPZ = -1
                                                                    zDirection = zDirection & "U"
                                                                    zDirectionCameFrom = zDirectionCameFrom & "D"
                                                                End If
                                                                If (zDirection = "") Then zDirection = "HERE"
                                                                If (zDirectionCameFrom = "") Then zDirectionCameFrom = "HERE"
                                                                
                                                                lMX = lX
                                                                lMY = lY
                                                                lMZ = lZ
                                                                
                                                                subSendMsgAreaAllDISmart "&a", zPlayerName, "&B[" & zDirection & "] &yYou [release d[" & lDistance & "]] " & zMissileName & ".", "", "&B[" & zDirection & "] &y%s1 [releases d[" & lDistance & "]] " & zMissileName & ".", lX, lY, lZ
                                                                
                                                                iHit = 0 'hasnt hit anything yet
                                                                bWatchSpeed = True
                                                                Do While (lRange > 0 And iHit = 0)
                                                                    lMissileDistance = lMissileDistance + 1
                                                                    lRange = lRange - 1
                                                                    lMX = lMX + lPX
                                                                    lMY = lMY + lPY
                                                                    lMZ = lMZ + lPZ
                                                                    
                                                                    'We now guide the missile towards the target with the max range of WeaponSkillMissileRangeClassLevel
                                                                    If (bCheckAreaExists(zPortID, lMX, lMY, lMZ, False)) Then
                                                                        If (lMX = lTX And lMY = lTY And lMZ = lTZ) Then
                                                                            iDamageResult = 0
                                                                            If (lMissileStatus = 1) Then 'bonus dmg
                                                                                If (lRandom(lCStr + (lCDEX * 2) + lRandom(lCLuc * 2) + lPlayerLevel) + (lWeaponSkillMissileRangeClassLevel * 2) > lRandom(3200)) Then
                                                                                    iDamageResult = 11 'perfect shot
                                                                                    lMissileFinalDamageTotal = lMissileFinalDamageTotal + MyCLng(lMissileFinalDamageTotal / 2) + (lRandom(lMissileFinalDamageTotal / 2))
                                                                                    subSendMsg "&W*PIN-DOWN SET*" & zFormatGoldCofGLearnpts(1000, "p", True), zPortID
                                                                                    lMAntiMoveDuration = lRandom(9) + 19
                                                                                    MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+1000 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                Else
                                                                                    iDamageResult = 10 'normal hit
                                                                                End If
                                                                            End If
                                                                            lTotalHP = lTotalHP - lMissileFinalDamageTotal
                                                                            If (lTotalHP < 1) Then lTotalHP = 1
                                                                            
                                                                            'If (lTotalHP = 1) Then subSendMsg "&R             ~ F I N I S H  I T ~", zPortID
                                                                            'We now subtract the hitpoints of the target but we never let it fall below zero.
                                                                            'We do not give experience for this attack - like fireball attack spell
                                                                            'Mob and Player hit points never fall below 1
                                                                            
                                                                            Select Case (lMissileStatus) 'we do the dmg for the right target
                                                                                Case 1 'Mob
                                                                                    iHit = 1
                                                                                    'If (lRandom(lPlayerTotalStats + lCStr + (lCDEX * 2) + lRandom(lCLuc + lCCha) + lPlayerLevel) + (lWeaponSkillMissileRangeClassLevel * 2) > lRandom(cstlPerfectShotValue)) Then
                                                                                    '    iDamageResult = 11 'perfect shot
                                                                                    '    lMissileFinalDamageTotal = lMissileFinalDamageTotal + lRandom(lMissileFinalDamageTotal)
                                                                                    '    subSendMsg "&W"  & "*perfect shot*" & zFormatGoldCofGLearnpts(1000,"p"), zPortID
                                                                                    '    MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+1000 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                    'Else
                                                                                    '    iDamageResult = 10 'normal hit
                                                                                    'End If
                                                                                    'For mobs we set the tblMob.PlayerID to missile attacker so the mob can chase them
                                                                                    If (lTotalHP = 1 Or bCanSlayChance Or lRandom(lObjectSlayChance) > lRandom(100)) Then
                                                                                        If (lTotalHP = 1 Or lRandom(lSlayChance + lObjectSlayChance) > lRandom(700 + lTLevel) Or lRandom(lObjectSlayChance) > lRandom(100)) Then
                                                                                            iMessedUp = 0
                                                                                            If (lTotalHP = 1) Then
                                                                                                iDamageResult = 12 'normal killed
                                                                                                subSendMsg "&r" & zAdVerbName & " was -=killed=- by your " & zMissileName & "! *normal shot*" & zFormatGoldCofGLearnpts(500, "p", True), zPortID
                                                                                                subSendMsgAreaAll gblzFNRED & zMissileName & " -=killed=- " & zAdVerbName & "!", lMX, lMY, lMZ
                                                                                                MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+500 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                            Else
                                                                                                iDamageResult = 13 'slay killed
                                                                                                subSendMsg "&R" & zAdVerbName & " was -=slayed=- by your " & zMissileName & zFormatGoldCofGLearnpts(2000, "p", True), zPortID
                                                                                                subSendMsgAreaAll "&R" & zMissileName & " -=slays=- " & zAdVerbName & "!", lMX, lMY, lMZ
                                                                                                MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+2000 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                            End If
                                                                                            'cancel all those attacking this mobid
                                                                                            subCombatEndedInitializeCombatCellsMobID lMissileTargetID
                                                                                            MyDB.Execute "UPDATE tblMob SET RespawnDelay=2+" & lRandom(9) & " WHERE (MobID=" & lMissileTargetID & ");"
                                                                                            If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                                                                                                bAutoLoot = gblbAutoloot(lPortID)
                                                                                                gblbAutoloot(lPortID) = False
                                                                                                subMakeCorpse zPortID, lPlayerID, lPlayerLevel, lMissileTargetID, "M", lMagicFind, lMagicFindBase, lCLuc
                                                                                                subPlayerQuest zPlayerName, lPlayerID, lPlayerLevel, lQuestMobID, zAdVerbName, lMissileTargetID, lTLevel, bBounty, zPortID, lMX, lMY, lMZ, lHoldGold, lMMoveAllowed
                                                                                                If (lHoldGold > 0) Then lGold = lGold + lHoldGold
                                                                                                If (bMSpecialSelfDeleting) Then
                                                                                                    MyDB.Execute "DELETE MobID FROM tblMob WHERE (MobID=" & lMissileTargetID & ");", dbFailOnError
                                                                                                    'RULE: Careful to NEVER give a deleting mob equipment to drop or sell
                                                                                                End If
                                                                                                If (lMSpecialGloryPlayerAmt > 0) Then
                                                                                                    If (lPlayerTotalStats > (lTLevel * 3)) Then 'this keeps the exploit of high levels killing all mobs
                                                                                                        subSendMsg "&M[EASY] Congratulations! You defeated " & zAdVerbName & ".", zPortID
                                                                                                    Else
                                                                                                        subSendMsg "&W[HARD] Congratulations! You heroically defeated " & zAdVerbName & "!", zPortID
                                                                                                    End If
                                                                                                    subSendMsgInfoChannel "[" & zWhereName(lPX, lPY, lPZ) & "&g] &w" & zPlayerName & " &a[defeated] &g[" & zAdVerbName & "] " & zFormatGoldCofGLearnpts(lMSpecialGloryPlayerAmt, "c", True)
                                                                                                    MyDB.Execute "UPDATE tblPlayer SET QuestMissionLog='', Crown=[Crown]+" & lMSpecialGloryPlayerAmt & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                                End If
                                                                                                subMobSpeakDeathScene lMissileTargetID
                                                                                                
                                                                                                'We now check to see if this mob is part of a quest herd
                                                                                                If (lMHerdMobID <> 0) Then subQuestHerdMob lMHerdMobID, zPlayerName, lPlayerID, lMagicFind, lMagicFindBase, lPlayerLevel, False, zPortID
                                                                                                gblbAutoloot(lPortID) = bAutoLoot 'return autoloot to the original status
                                                                                            End If
                                                                                        End If
                                                                                    End If
                                                                                    
                                                                                    If (iDamageResult <> 12 And iDamageResult <> 13) Then MyDB.Execute "UPDATE tblMob SET AntiMoveDuration=" & lMAntiMoveDuration & ", MHP=" & lTotalHP & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                                                Case 2 'Player
                                                                                    iHit = 1
                                                                                    iDamageResult = 20 'hit we dont slay player past 1 hp
                                                                                    subSendMsg "&ROWE!!! &B[" & zDirectionCameFrom & "] &R[missile hit] [" & zMissileName & "] d[" & lMissileDistance & "] dmg[" & lMissileFinalDamageTotal & "]", zDPortID
                                                                                    subForceInterrupt lIASChance, zDPortID, zPortID, 1
                                                                                    If (bCanSlayChance Or lRandom(lObjectSlayChance) > lRandom(100)) Then
                                                                                        If (lRandom(lSlayChance + lObjectSlayChance) > lRandom(700 + lTLevel) Or lRandom(lObjectSlayChance) > lRandom(100)) Then
                                                                                            iMessedUp = 0
                                                                                            iDamageResult = 21 'slayed
                                                                                            subSendMsg "&W-=slayed to a single hitpoint=-", zPortID
                                                                                            MyDB.Execute "UPDATE tblPlayer SET CHP=1 WHERE (PlayerID=" & lTargetID & ");"
                                                                                        End If
                                                                                    Else
                                                                                        MyDB.Execute "UPDATE tblPlayer SET CHP=" & lTotalHP & " WHERE (PlayerID=" & lTargetID & ");", dbFailOnError
                                                                                    End If
                                                                            End Select
                                                                            
                                                                            'print results
                                                                            If (iDamageResult <> 12 And iDamageResult <> 13 And iDamageResult <> 21) Then
                                                                                'if it didnt kill then show the status
                                                                                iMessedUp = 1
                                                                                subSendMsg "&yYour " & zMissileName & " hit " & zAdVerbName & "! d[" & lMissileDistance & "] dmg[" & lMissileFinalDamageTotal & "] hp[" & lTotalHP & "]", zPortID
                                                                                subSendMsgAreaExcept2 "&B[" & zDirectionCameFrom & "] &yThe " & zMissileName & " hits " & zAdVerbName & "!", lMX, lMY, lMZ, zPortID, zDPortID
                                                                            Else
                                                                                'the missile weapon finished off the creature
                                                                                subSendMsg "&yYour " & zMissileName & " finished off " & zAdVerbName & "! d[" & lMissileDistance & "] dmg[" & lMissileFinalDamageTotal & "] hp[" & lTotalHP & "]", zPortID
                                                                                subSendMsgAreaExcept2 "&B[" & zDirectionCameFrom & "] &yThe " & zMissileName & " finished off " & zAdVerbName & "!", lMX, lMY, lMZ, zPortID, zDPortID
                                                                                iMessedUp = 0
                                                                            End If
                                                                        Else
                                                                            If (bWatchSpeed) Then
                                                                                bWatchSpeed = False
                                                                                subSendMsg "&yYou watch the " & zMissileName & " speed for its target!", zPortID
                                                                            End If
                                                                            subSendMsgAreaExcept2 "&ySomething is heard speeding through the room!", lMX, lMY, lMZ, zPortID, ""
                                                                        End If
                                                                    Else
                                                                        iHit = 2
                                                                        iMessedUp = 3
                                                                        subSendMsg "&y[missed] d[" & lMissileDistance & "] The " & zMissileName & " smashed into a wall!", zPortID
                                                                        subSendMsgAreaExcept2 "&GSomething swishing though the air smashed into a wall closeby!", lMX, lMY, lMZ, zPortID, ""
                                                                    End If
                                                                Loop
                                                                
                                                                If (iHit = 0) Then
                                                                    iMessedUp = 4
                                                                    subSendMsg "&y d[" & lMissileDistance & "] Your " & zMissileName & " crashes to the ground before it reaches " & zAdVerbName & ".", zPortID
                                                                    subSendMsgAreaExcept2 "&yd[" & lMissileDistance & "] Something is heard hitting the ground.", lMX, lMY, lMZ, zPortID, ""
                                                                End If
                                                            Else
                                                                subSendMsg "&y[missed] The target must of moved!", zPortID
                                                            End If
                                                            If (iMessedUp > 0) Then subChanceGuardsInWhereIDAttackPlayerID lPlayerID, 12
                                                            Select Case (lSpeedShooting) 'delay port its set to 4 seconds a tick
                                                                Case 1 'machine gun
                                                                    Select Case zClass
                                                                        Case "RA", "GY", "BA", "CY", "DR"
                                                                            gbltDurations(lPortID).lPullMissile = 1
                                                                        Case "KN", "GL", "WA"
                                                                            gbltDurations(lPortID).lPullMissile = 2
                                                                        Case Else
                                                                            gbltDurations(lPortID).lPullMissile = 2
                                                                    End Select
                                                                    If (lRandom(100) < 80) Then gbltDurations(lPortID).lPullMissile = gbltDurations(lPortID).lPullMissile - 1
                                                                Case 2 'phaser
                                                                    Select Case zClass
                                                                        Case "KN", "WA", "CY"
                                                                            gbltDurations(lPortID).lPullMissile = 1
                                                                            If (lRandom(100) < 60) Then gbltDurations(lPortID).lPullMissile = 0
                                                                        Case Else
                                                                            gbltDurations(lPortID).lPullMissile = 1
                                                                    End Select
                                                                    If (lRandom(100) < 90) Then gbltDurations(lPortID).lPullMissile = 0
                                                                Case Else 'bows xbows slings
                                                                    Select Case zClass
                                                                        Case "RA"
                                                                            gbltDurations(lPortID).lPullMissile = 1
                                                                            If (lRandom(3) = 3) Then gbltDurations(lPortID).lPullMissile = 0
                                                                        Case "KN", "WA", "GL"
                                                                            gbltDurations(lPortID).lPullMissile = 2
                                                                        Case "DR"
                                                                            gbltDurations(lPortID).lPullMissile = 2
                                                                            If (lRandom(3) <> 3) Then gbltDurations(lPortID).lPullMissile = 0
                                                                        Case Else
                                                                            gbltDurations(lPortID).lPullMissile = 4
                                                                    End Select
                                                            End Select
                                                        Else
                                                            subSendMsg "&yYou check your ammo and find you have no " & zMissileName & "s.", zPortID
                                                        End If
                                                    Else
                                                        subSendMsg "&yYou do not have any " & zMissileName & "s left in your inventory.", zPortID
                                                    End If
                                                Case Else
                                                    subSendMsg "&yYou need to empty a hand to use your missile weapon.", zPortID
                                            End Select
                                        Else
                                            subSendMsg "&gYou will need to hold a missile weapon to use this skill.", zPortID
                                        End If
                                    End If
                                Else
                                    subSendMsg "&gYou need to MISSILE TARGET something first.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou are too scared to fire a weapon!", zPortID
                            End If
                        Else
                            subSendMsg "&RYou are too stunned to fire your missile weapon!", zPortID
                        End If
                    Else
                        subSendMsg "&RYou dream about a perfect bullseye!", zPortID
                    End If
                Else
                    subSendMsg "&RYou must be standing to do that.", zPortID
                End If
                Else
                    subSendMsg "&RYou must be in a normal stance to use a missile weapon.", zPortID
                End If
            Else
                subSendMsg "&RYour missile weapon is too entangled and drifts targets too easily!", zPortID
            End If
            Else
                subSendMsg "&RYou are not of a humanoid form to do that.", zPortID
            End If
            Else
                subSendMsg "&RYou would break your invisibility if you attacked.", zPortID
            End If
        Else
            subSendMsg "&RMISSILE FIRE: Your player file was not found report this to an immortal.", zPortID
        End If
    Else
        subSendMsg "&R       ...standby, you are notching the ammunition, standby...", zPortID
    End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatMissileWeapons," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lLearnPlayerPointsLeft(lPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim rsLearn As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsLearn = MyDB.OpenRecordset("SELECT PlayerID, LearnPoints FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsLearn.EOF) Then
        lReturn = MyCLng(rsLearn!LearnPoints)
    End If
    lLearnPlayerPointsLeft = lReturn
    Set rsLearn = Nothing
    Exit Function
Err_Check:
    subWriteErrorFile "lLearnPlayerPointsLeft," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subLearnMobList(lOX As Long, lOY As Long, lOZ As Long, zClassType As String, zRaceType As String, zPortID As String, lPlayerLevel As Long)
On Error GoTo Err_Check
    Dim zMobName As String
    Dim rsLearn As Recordset
    Dim zLearnDamage As String
    Dim zPrefix As String
    Dim zInfo As String
    Dim lLearnDamage As Long
    Dim lLearnType As Long
    Dim lLearnDamageNeg As Long
        
    Set rsLearn = MyDB.OpenRecordset("SELECT LearnLevelRestricted, LearnName, LearnDamage, LearnType, MobID, LearnNameRestricted, CounterLearnName, ActivateCommand FROM tblPlayerLearn WHERE ((ClassNotPermitted<>'" & zClassType & "' Or ClassNotPermitted='' Or ClassNotPermitted Is Null) AND (RaceRestricted='" & zRaceType & "' Or RaceRestricted='' Or RaceRestricted Is Null)  AND (ClassRestricted='" & zClassType & "' Or ClassRestricted='' Or ClassRestricted Is Null) AND (LearnX=" & lOX & ") AND (LearnY=" & lOY & ") AND (LearnZ=" & lOZ & ") AND (LearnStatus=0)) ORDER BY LearnLevelRestricted, LearnName;", dbOpenSnapshot)
    If (Not rsLearn.EOF) Then
        zMobName = zReturnMobIDName(MyCLng(rsLearn!MobID))
        zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
        subSendMsg "&G" & UCase(zMobName) & " teaches " & UCase(zTranslateClass(zClassType)) & "S the following skills:", zPortID
        Do While (Not rsLearn.EOF) 'We show all the skills the mob has
            zLearnDamage = ""
            lLearnDamage = MyCLng(rsLearn!LearnDamage)
            If lLearnDamage < 0 Then
                lLearnDamageNeg = True
            Else
                lLearnDamageNeg = False
            End If
            lLearnDamage = Abs(lLearnDamage)
            lLearnType = MyCLng(rsLearn!LearnType)
            'Debug.Print lLearnDamage, lLearnType
            If (lLearnDamage <> 0) Then
                If (Not lLearnDamageNeg) Then
                    zLearnDamage = " damage " & lLearnDamage
                Else
                    zLearnDamage = "  heals " & Abs(lLearnDamage)
                End If
                
                Select Case MyCLng(rsLearn!LearnType)
                    Case 1
                        zLearnDamage = zLearnDamage & " + your Lv(" & (Abs(lLearnDamage) + lPlayerLevel) & ")"
                    Case 2
                        zLearnDamage = zLearnDamage & " * your Lv(" & (Abs(MyCLng(rsLearn!LearnDamage)) * lPlayerLevel) & ")"
                End Select
            End If
            
            zInfo = ""
            
            If (Len(MyCStr(rsLearn!LearnNameRestricted)) > 0) Then
                zInfo = ", requires " & LCase(MyCStr(rsLearn!LearnNameRestricted))
            End If
            
            Select Case MyCLng(rsLearn!ActivateCommand)
                Case 2, 3 '2=defensive spell 3=offensive spell
                    zPrefix = gblzFNMAG & "(spell)"
                Case Else
                    zPrefix = gblzFNGRE & "(skill)"
            End Select
            subSendMsg zPrefix & " " & gblzFBWHI & strForceSize(MyCStr(rsLearn!LearnName), 26, " ", "A") & strForceSize("Lv " & MyCStr(rsLearn!LearnLevelRestricted), 6, " ", "A") & " " & zLearnDamage & zInfo & ".", zPortID
            rsLearn.MoveNext
        Loop
        Set rsLearn = Nothing
    Else
        subSendMsg "&gThere isn't any skills that you can learn here.", zPortID
    End If
    Set rsLearn = Nothing
    subSendMsg "&gNOTE: LEARN TREE to see your entire list, PRAC to see what you can cast.", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subLearnMobList," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lCountStargatesInArea(lOX As Long, lOY As Long, lOZ As Long) As Long
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lReturn As Long
    
    'is there one stargate in the area
    lReturn = 0
    Set rsObject = MyDB.OpenRecordset("SELECT ObjectID FROM tblObject WHERE (StargateStatus<>0 AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
    Do While (Not rsObject.EOF)
        lReturn = lReturn + 1
        rsObject.MoveNext
    Loop
    Set rsObject = Nothing
    
    lCountStargatesInArea = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCountStargatesInArea," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bCheckLearnArea(lOX As Long, lOY As Long, lOZ As Long) As Boolean
On Error GoTo Err_Check
    Dim rsLearn As Recordset
    Dim bReturn As Boolean
    
    Set rsLearn = MyDB.OpenRecordset("SELECT LearnX, LearnY, LearnZ FROM tblPlayerLearn WHERE (LearnStatus=0 AND LearnX=" & lOX & " AND LearnY=" & lOY & " AND LearnZ=" & lOZ & ");", dbOpenSnapshot)
    
    bReturn = (Not rsLearn.EOF) 'True means this is a learn area
    
    Set rsLearn = Nothing
    
    bCheckLearnArea = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bCheckLearnArea," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bCheckLearnCorrectMob(lOX As Long, lOY As Long, lOZ As Long) As Boolean
On Error GoTo Err_Check
    Dim rsLearn As Recordset
    Dim bReturn As Boolean
    
    Set rsLearn = MyDB.OpenRecordset("SELECT tblPlayerLearn.LearnStatus, tblMob.RespawnDelay, tblMob.X, tblMob.Y, tblMob.Z FROM tblPlayerLearn INNER JOIN tblMob ON tblPlayerLearn.MobID = tblMob.MobID WHERE (((tblPlayerLearn.LearnStatus)=0) AND ((tblMob.RespawnDelay)=0) AND ((tblPlayerLearn.LearnX)=" & lOX & ") AND ((tblPlayerLearn.LearnY)=" & lOY & ") AND ((tblPlayerLearn.LearnZ)=" & lOZ & ") AND ((tblMob.X)=" & lOX & ") AND ((tblMob.Y)=" & lOY & ") AND ((tblMob.Z)=" & lOZ & "));", dbOpenSnapshot)
    
    bReturn = (Not rsLearn.EOF) 'True means the mob is alive at this spot.
    
    Set rsLearn = Nothing
    
    bCheckLearnCorrectMob = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bCheckLearnCorrectMob," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iCheckLearnPlayerUseRightSkillName(lOX As Long, lOY As Long, lOZ As Long, zPrompt As String, zClassType As String, lOPlayerID As Long, zPortID As String) As Integer
On Error GoTo Err_Check
'0 error, learn area not here
'1 means this is a learn area and everything is fine
'2 error, class is never allowed to use this skill, nor can the class see it in the learn list
'3 error, this is the only class that can use this skill
'4 error, this skill requires another skill
    Dim rsLearn As Recordset
    Dim rsLearnNameRestricted As Recordset
    Dim iReturn As Integer
    
    iReturn = 0
    Set rsLearn = MyDB.OpenRecordset("SELECT tblPlayerLearn.LearnName, tblPlayerLearn.LearnStatus, tblPlayerLearn.ClassNotPermitted, tblPlayerLearn.ClassRestricted, tblPlayerLearn.LearnNameRestricted FROM tblPlayerLearn WHERE (((tblPlayerLearn.LearnName)='" & zAntiSQLCrash(zPrompt) & "') AND ((tblPlayerLearn.LearnStatus)=0) AND ((tblPlayerLearn.ClassNotPermitted)<>'" & zClassType & "' Or (tblPlayerLearn.ClassNotPermitted) Is Null Or (tblPlayerLearn.ClassNotPermitted)='') AND ((tblPlayerLearn.ClassRestricted)='" & zClassType & "' Or (tblPlayerLearn.ClassRestricted) Is Null Or (tblPlayerLearn.ClassRestricted)='') AND ((tblPlayerLearn.LearnX)=" & lOX & ") AND ((tblPlayerLearn.LearnY)=" & lOY & ") AND ((tblPlayerLearn.LearnZ)=" & lOZ & "));", dbOpenSnapshot)
    If (Not rsLearn.EOF) Then
        iReturn = 1
        'If (zClassType = MyCStr(rsLearn!ClassNotPermitted)) Then
            'iReturn = 2 'class is never allowed to use this skill, nor can the class see it in the learn list
        'End If
        'If (Len(MyCStr(rsLearn!ClassRestricted)) > 0) Then
        '    If (zClassType <> MyCStr(rsLearn!ClassRestricted)) Then
        '        iReturn = 3 'this is the only class that can use this skill
        '    End If
        'End If
        
        'If (iReturn = 1) Then
        If (Len(MyCStr(rsLearn!LearnNameRestricted)) > 0) Then
            'We see if the player has the learn skill because it is required to learn this skill
            Set rsLearnNameRestricted = MyDB.OpenRecordset("SELECT LearnNameRestricted FROM tblPlayerLearn WHERE (TargetID=" & lOPlayerID & " AND LearnName='" & MyCStr(rsLearn!LearnNameRestricted) & "' AND LearnStatus=2);", dbOpenSnapshot)
            If (rsLearnNameRestricted.EOF) Then 'player doesnt have the skill that is required
                subSendMsg "&yThis skill requires " & LCase(MyCStr(rsLearn!LearnNameRestricted)) & ".", zPortID
                iReturn = 4 'this skill requires another skill
            End If
            Set rsLearnNameRestricted = Nothing
        End If
        'End If
    End If
    Set rsLearn = Nothing
        
    iCheckLearnPlayerUseRightSkillName = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bCheckLearnPlayerUseRightSkillName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bCheckLearnPlayerKnowsThisSkill(lPlayerID As Long, lOX As Long, lOY As Long, lOZ As Long, zPrompt As String) As Boolean
On Error GoTo Err_Check
    Dim rsLearn As Recordset
    Dim bReturn As Boolean
    
    Set rsLearn = MyDB.OpenRecordset("SELECT PlayerID FROM tblPlayerLearn WHERE (PlayerID=" & lPlayerID & " AND LearnName='" & zPrompt & "' AND LearnStatus=2);", dbOpenSnapshot)
    
    bReturn = (Not rsLearn.EOF) 'True means this player knows the skill
    
    Set rsLearn = Nothing
    
    bCheckLearnPlayerKnowsThisSkill = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bCheckLearnPlayerKnowsThisSkill," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subPlayerSkillsLearn(zPortID As String, zPrompt As String)
On Error GoTo Err_Check
    Dim rsLearnMother As Recordset
    Dim rsLearn As Recordset
    Dim zSkillName As String
    Dim lLearnPercentMAX As Long
    Dim lCount As Long
    Dim lTimes As Long
    
    Dim rsPlayer As Recordset
    Dim bPlayerFound As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim zClass As String
    Dim zRace As String
    Dim lLearnPointsLeft As Long
    Dim lOriginalLearnPointsLeft As Long
    Dim bKeepLooping As Boolean
        
    Set rsPlayer = MyDB.OpenRecordset("SELECT LearnPoints, X, Y, Z, PlayerName, PlayerID, Class, PlayerLevel, Race, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bPlayerFound = True
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID) 'This is the player doing the request
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        zClass = MyCStr(rsPlayer!Class)
        zRace = MyCStr(rsPlayer!Race)
        lLearnPointsLeft = MyCLng(rsPlayer!LearnPoints)
        lOriginalLearnPointsLeft = lLearnPointsLeft
    Else
        bPlayerFound = False
    End If
    Set rsPlayer = Nothing
    
    If (bPlayerFound) Then
        If (bCheckLearnArea(lX, lY, lZ)) Then
            If (bCheckLearnCorrectMob(lX, lY, lZ)) Then
                lTimes = 0
                If (Len(zPrompt) > 0) Then
                    lTimes = MyCLng(zKeepNumbersOnly(zPrompt))
                    If (lTimes > 5) Then lTimes = 5
                    If (lTimes < 1) Then lTimes = 1
                    lCount = 0
                    bKeepLooping = True
                    Do While (lCount < lTimes And bKeepLooping)
                        lCount = lCount + 1
                        Select Case iCheckLearnPlayerUseRightSkillName(lX, lY, lZ, zKeepLettersOnly(zPrompt, " "), zClass, lPlayerID, zPortID)
                            Case 1
                                'We see if the player already knows the skill they want to learn.
                                Set rsLearn = MyDB.OpenRecordset("SELECT * FROM tblPlayerLearn WHERE (TargetID=" & lPlayerID & " AND LearnName='" & zKeepLettersOnly(zPrompt, " ") & "' AND LearnStatus=2) AND (RaceRestricted='" & zRace & "' OR RaceRestricted Is Null OR RaceRestricted='') AND (ClassRestricted='" & zClass & "' OR ClassRestricted Is Null OR ClassRestricted='');", dbOpenDynaset)
                                If (Not rsLearn.EOF) Then
                                    'The player knows this skill, so we add a skill percent to it and subtract a learn point.
                                    If (lLearnPointsLeft > 0) Then
                                        zSkillName = MyCStr(rsLearn!LearnName)
                                        Select Case (MyCLng(rsLearn!CraftedLevel) > 0)
                                            Case True
                                                lLearnPercentMAX = lTranslateRaceCraftBonus(zRace)
                                            Case Else
                                                Select Case MyCLng(rsLearn!ActivateCommand)
                                                    Case 0, 1
                                                        lLearnPercentMAX = lTranslateLearnPointBonus(zClass)
                                                    Case 2, 3
                                                        lLearnPercentMAX = lTranslateLearnPointBonus(zClass)
                                                End Select
                                        End Select
                                        If (MyCLng(rsLearn!LearnPercent) < lLearnPercentMAX) Then
                                            If (lCount = 1) Then
                                                subSendMsg "&gYou learn a little more about the skill " & LCase(zSkillName) & ".", zPortID
                                            End If
                                            rsLearn.Edit
                                            rsLearn!LearnPercent = MyCLng(rsLearn!LearnPercent) + 1
                                            rsLearn.Update
                                            lLearnPointsLeft = lLearnPointsLeft - 1
                                        Else
                                            subSendMsg "&yYou have learnt as much as you can about " & LCase(zSkillName) & ".", zPortID
                                            bKeepLooping = False
                                        End If
                                    Else
                                        subSendMsg "&gYou do not have any learn points left, level to earn more points.", zPortID
                                        bKeepLooping = False
                                    End If
                                Else
                                    If (lLearnPointsLeft > 0) Then
                                        Set rsLearnMother = MyDB.OpenRecordset("SELECT * FROM tblPlayerLearn WHERE (LearnName='" & zKeepLettersOnly(zPrompt, " ") & "' AND LearnStatus=0) AND (RaceRestricted='" & zRace & "' OR RaceRestricted Is Null OR RaceRestricted='') AND (ClassRestricted='" & zClass & "' OR ClassRestricted Is Null OR ClassRestricted='');", dbOpenDynaset)
                                        If (Not rsLearnMother.EOF) Then
                                            If (MyCLng(rsLearnMother!LearnLevelRestricted) <= lPlayerLevel) Then
                                                zSkillName = MyCStr(rsLearnMother!LearnName)
                                                subSendMsg "&Y* * * &GYou start a new skill, " & LCase(zSkillName) & gblzFBYEL & " * * *" & vbCrLf & "&gNOTE: You can learn 5 percent at a time. Just put the number 5 at the" & vbCrLf & "end of the spellname you are trying to learn." & vbCrLf & "SYNTAX: LEARN " & zSkillName & "5", zPortID
                                                rsLearn.AddNew
                                                rsLearn!TargetID = lPlayerID 'Note: TargetID 0 is always the mother spell, the egg hatcher if you like where you get most of your DNA for your learn tree from
                                                'EntangleLevel
                                                rsLearn!ObjectName = MyCStr(rsLearnMother!ObjectName) 'object that must be in inventory to use this skill or spell
                                                rsLearn!WeaponType = MyCStr(rsLearnMother!WeaponType)
                                                rsLearn!LearnName = MyCStr(rsLearnMother!LearnName)
                                                rsLearn!LearnPercent = 10 + lRandom(10) 'so there is a chance they can just use it
                                                rsLearn!LearnDamage = MyCLng(rsLearnMother!LearnDamage)
                                                rsLearn!LearnType = MyCLng(rsLearnMother!LearnType)
                                                rsLearn!LearnStatus = 2 'Player skill
                                                rsLearn!MobID = MyCLng(rsLearnMother!MobID)
                                                rsLearn!LearnX = MyCLng(rsLearnMother!LearnX)
                                                rsLearn!LearnY = MyCLng(rsLearnMother!LearnY)
                                                rsLearn!LearnZ = MyCLng(rsLearnMother!LearnZ)
                                                rsLearn!PoisonLevel = MyCLng(rsLearnMother!PoisonLevel)
                                                rsLearn!PoisonChance = MyCLng(rsLearnMother!PoisonChance)
                                                rsLearn!PoisonStrength = MyCLng(rsLearnMother!PoisonStrength)
                                                rsLearn!PindownLevel = MyCLng(rsLearnMother!PindownLevel)
                                                rsLearn!PindownChance = MyCLng(rsLearnMother!PindownChance)
                                                rsLearn!SleepLevel = MyCLng(rsLearnMother!SleepLevel)
                                                rsLearn!SleepChance = MyCLng(rsLearnMother!SleepChance)
                                                rsLearn!ElementalType = MyCLng(rsLearnMother!ElementalType)
                                                rsLearn!ElementalCelsius = MyCLng(rsLearnMother!ElementalCelsius)
                                                rsLearn!StunLevel = MyCLng(rsLearnMother!StunLevel)
                                                rsLearn!StunChance = MyCLng(rsLearnMother!StunChance)
                                                rsLearn!BlindLevel = MyCLng(rsLearnMother!BlindLevel)
                                                rsLearn!BlindChance = MyCLng(rsLearnMother!BlindChance)
                                                rsLearn!EntangleLevel = MyCLng(rsLearnMother!EntangleLevel)
                                                rsLearn!EntangleChance = MyCLng(rsLearnMother!EntangleChance)
                                                rsLearn!CounterLearnName = MyCStr(rsLearnMother!CounterLearnName)
                                                rsLearn!ClassNotPermitted = MyCStr(rsLearnMother!ClassNotPermitted)
                                                rsLearn!LearnNameRestricted = MyCStr(rsLearnMother!LearnNameRestricted)
                                                rsLearn!LearnLevelRestricted = MyCLng(rsLearnMother!LearnLevelRestricted)
                                                rsLearn!ClassRestricted = MyCStr(rsLearnMother!ClassRestricted)
                                                rsLearn!RaceRestricted = MyCStr(rsLearnMother!RaceRestricted)
                                                rsLearn!HP = MyCLng(rsLearnMother!HP)
                                                rsLearn!AC = MyCLng(rsLearnMother!AC)
                                                rsLearn!HITROLL = MyCLng(rsLearnMother!HITROLL)
                                                rsLearn!DAMROLL = MyCLng(rsLearnMother!DAMROLL)
                                                rsLearn!Str = MyCLng(rsLearnMother!Str)
                                                rsLearn!Int = MyCLng(rsLearnMother!Int)
                                                rsLearn!Wis = MyCLng(rsLearnMother!Wis)
                                                rsLearn!Dex = MyCLng(rsLearnMother!Dex)
                                                rsLearn!Con = MyCLng(rsLearnMother!Con)
                                                rsLearn!Cha = MyCLng(rsLearnMother!Cha)
                                                rsLearn!Luc = MyCLng(rsLearnMother!Luc)
                                                rsLearn!Grip = MyCLng(rsLearnMother!Grip)
                                                rsLearn!mana = MyCLng(rsLearnMother!mana)
                                                rsLearn!Weight = MyCLng(rsLearnMother!Weight)
                                                rsLearn!Gold = MyCLng(rsLearnMother!Gold)
                                                rsLearn!essence = MyCLng(rsLearnMother!essence)
                                                rsLearn!soul = MyCLng(rsLearnMother!soul)
                                                rsLearn!Move = MyCLng(rsLearnMother!Move)
                                                rsLearn!ActivateCommand = MyCLng(rsLearnMother!ActivateCommand) 'important for learn command to work
                                                rsLearn!ActivateDuration = MyCLng(rsLearnMother!ActivateDuration)
                                                rsLearn!ActivateDurationStart = MyCLng(rsLearnMother!ActivateDurationStart)
                                                rsLearn!ActivateReloadDuration = MyCLng(rsLearnMother!ActivateReloadDuration)
                                                rsLearn!ActivateManaCost = MyCLng(rsLearnMother!ActivateManaCost)
                                                rsLearn!ActivateEssenceCost = MyCLng(rsLearnMother!ActivateEssenceCost)
                                                rsLearn!ActivateSoulCost = MyCLng(rsLearnMother!ActivateSoulCost)
                                                rsLearn!ActivateMoveCost = MyCLng(rsLearnMother!ActivateMoveCost)
                                                rsLearn!ObjectActivateSpellNo = MyCLng(rsLearnMother!ObjectActivateSpellNo)
                                                rsLearn!ObjectActivateSkillNo = MyCLng(rsLearnMother!ObjectActivateSkillNo)
                                                rsLearn!CreateBodyLocation = MyCLng(rsLearnMother!CreateBodyLocation)
                                                rsLearn!LevelRequirement = MyCLng(rsLearnMother!LevelRequirement)
                                                rsLearn!GroundObjectType = MyCLng(rsLearnMother!GroundObjectType)
                                                rsLearn!GroundObjectName = MyCStr(rsLearnMother!GroundObjectName)
                                                rsLearn!CraftedLevel = MyCLng(rsLearnMother!CraftedLevel)
                                                rsLearn!Duration = MyCLng(rsLearnMother!Duration)
                                                rsLearn.Update
                                                subSendMsgAreaExcept2 gblzFNGRE & zPlayerName & " trains in the art of " & LCase(zSkillName) & ".", lX, lY, lZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou must attain level " & MyCLng(rsLearnMother!LearnLevelRestricted) & " to learn this skill.", zPortID
                                                bKeepLooping = False
                                            End If
                                        Else
                                            subSendMsg "&gYou cannot learn that skill here.", zPortID
                                        End If
                                        Set rsLearnMother = Nothing
                                    Else
                                        subSendMsg "&gYou do not have any learn points left, level to earn more points.", zPortID
                                        bKeepLooping = False
                                    End If
                                End If
                                Set rsLearn = Nothing
                            Case Else
                                subSendMsg "&gThis teacher cannot teach you that skill.", zPortID
                                'List all the mobs skills
                                subLearnMobList lX, lY, lZ, zClass, zRace, zPortID, lPlayerLevel
                                bKeepLooping = False
                        End Select
                    Loop
                Else
                    'List all the mobs skills
                    subLearnMobList lX, lY, lZ, zClass, zRace, zPortID, lPlayerLevel
                End If
                If (lTimes < 2 And lPlayerLevel < 20) Then subSendMsg "&wNOTE: LEARN SPELLNAME5   - to learn 5 percent at a time" & vbCrLf & "                         - the number must touch the spell name." & vbCrLf & "Use PRACTICE to see what you have already learnt." & vbCrLf & "Use LEARN TREE to see what other spells and skills you can learn." & vbCrLf & "See Also: SLIST", zPortID
            Else
                subSendMsg "&gThe teacher must be in the class room to teach you.", zPortID
            End If
        Else
            subSendMsg "&gYou need to find a class room to list the teacher's skills." & vbCrLf & "HELP [QUICK/BASIC/ADVANCED/COST/PRAC/SLIST/LEARN TREE/AFFECT/RELOAD]", zPortID
        End If
        subSendMsg zFormatGoldCofGLearnpts(lLearnPointsLeft, "L", True), zPortID
        If (lLearnPointsLeft <> lOriginalLearnPointsLeft) Then MyDB.Execute "UPDATE tblPlayer SET LearnPoints=" & lLearnPointsLeft & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
    Else
        subSendMsg "&RSYSTEM ERROR! Your player file was not found!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerSkillsLearn," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSkillReloadRemoveWear(zPlayerName As String, lPlayerID As Long, lReloadPenalty As Long, zPortID As String, zGender As String, lOX As Long, lOY As Long, lOZ As Long, lStatus As Long, lInvisibilityDuration As Long)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim bMissing As Boolean
    Dim lMissing As Long
    Dim lDuration As Long
    Dim lObjectActivateSkillNo As Long
    Dim lFails As Long
    Dim zScript1p As String
    Dim zScript3p As String
    Dim zScriptSkillsMissing As String
    Dim bBerserk As Boolean
    Dim bDoublePunch As Boolean
    Dim bDropKick As Boolean
    Dim bMeditate As Boolean
    Dim bHeadButt As Boolean
    Dim bElbow As Boolean
    Dim bKnee As Boolean
    Dim bClawHand As Boolean
    Dim bKnifeHand As Boolean
    Dim bDragonUppercut As Boolean
    Dim bPowerKick As Boolean
    Dim bHurricaneKick As Boolean
    Dim lObjectActivateSpellNo As Long
    Dim zSQL As String
    Dim bLightDuration As Boolean
    Dim bInvisibilityDuration As Boolean
    Dim bFireshieldDuration As Boolean
    Dim bIceshieldDuration As Boolean
    Dim bSanctuary As Boolean
    Dim bNegateDuration As Boolean
    Dim bBarkskinDuration As Boolean
    Dim bStoneskinDuration As Boolean
    Dim bDragonskinDuration As Boolean
    Dim bDemonskinDuration As Boolean
    Dim bShadowCloakDuration As Boolean
         
    If (lStatus = 5) Then
        zScriptSkillsMissing = ""
        
        bBerserk = False
        bDoublePunch = False
        bDropKick = False
        bMeditate = False
        bHeadButt = False
        bElbow = False
        bKnee = False
        bClawHand = False
        bKnifeHand = False
        bDragonUppercut = False
        bPowerKick = False
        bHurricaneKick = False
        bLightDuration = False
        bInvisibilityDuration = False
        bFireshieldDuration = False
        bIceshieldDuration = False
        bSanctuary = False
        bNegateDuration = False
        bBarkskinDuration = False
        bStoneskinDuration = False
        bDragonskinDuration = False
        bDemonskinDuration = False
        bShadowCloakDuration = False
        
        zSQL = "SELECT tblPlayer.PlayerID, tblPlayer.PlayerName, tblObject.ObjectName, tblObject.ObjectActivateSpellNo, tblObject.ObjectActivateSkillNo, tblPlayer.LightDuration, tblPlayer.InvisibilityDuration, tblPlayer.FireshieldDuration, tblPlayer.IceshieldDuration, tblPlayer.SanctuaryDuration, tblPlayer.NegateDuration, tblPlayer.BarkskinDuration, tblPlayer.StoneskinDuration, tblPlayer.DragonskinDuration, tblPlayer.DemonskinDuration, tblPlayer.ShadowCloakDuration, "
        zSQL = zSQL & "tblPlayer.BeserkDuration, tblPlayer.DoublePunchDuration, tblPlayer.DropKickDuration, tblPlayer.MeditateDuration, tblPlayer.HeadButtDuration, tblPlayer.ElbowDuration, tblPlayer.KneeDuration, tblPlayer.ClawHandDuration, tblPlayer.KnifeHandDuration, tblPlayer.DragonUppercutDuration, tblPlayer.PowerKickDuration, tblPlayer.HurricaneKickDuration FROM (tblPlayer INNER JOIN tblPlayerEquipmentItems ON tblPlayer.PlayerID = tblPlayerEquipmentItems.PlayerID) INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.ObjectActivateSkillNo)<>0)) OR (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblObject.ObjectActivateSpellNo)<>0));"
        Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            subSendMsg "&GYou begin to reload all your item spells and skills.", zPortID
            lFails = 0
            lDuration = 50 + lRandom(25)
            Do While (Not rsPlayer.EOF)
                zScript1p = ""
                zScript3p = ""
                lObjectActivateSpellNo = MyCLng(rsPlayer!ObjectActivateSpellNo)
                Select Case lObjectActivateSpellNo
                    Case 1, 2, 3, 4, 5 'LightDuration Light and Radius
                        bLightDuration = True
                        If (MyCLng(rsPlayer!LightDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 20 'InvisibilityDuration
                        bInvisibilityDuration = True
                        If (MyCLng(rsPlayer!InvisibilityDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 30 'FireshieldDuration
                        bFireshieldDuration = True
                        If (MyCLng(rsPlayer!FireshieldDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 40 'IceshieldDuration
                        bIceshieldDuration = True
                        If (MyCLng(rsPlayer!IceshieldDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 50 'SanctuaryDuration
                        bSanctuary = True
                        If (MyCLng(rsPlayer!SanctuaryDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 60 'NegateDuration
                        bNegateDuration = True
                        If (MyCLng(rsPlayer!NegateDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 80 'BarkskinDuration
                        bBarkskinDuration = True
                        If (MyCLng(rsPlayer!BarkskinDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 81 'StoneskinDuration
                        bStoneskinDuration = True
                        If (MyCLng(rsPlayer!StoneskinDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 82 'DragonskinDuration
                        bDragonskinDuration = True
                        If (MyCLng(rsPlayer!DragonskinDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 83 'DemonskinDuration
                        bDemonskinDuration = True
                        If (MyCLng(rsPlayer!DemonskinDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 99 'ShadowCloakDuration
                        bShadowCloakDuration = True
                        If (MyCLng(rsPlayer!ShadowCloakDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                End Select
                
                lObjectActivateSkillNo = MyCLng(rsPlayer!ObjectActivateSkillNo)
                Select Case lObjectActivateSkillNo
                    Case 10 'Berserk
                        bBerserk = True
                        If (MyCLng(rsPlayer!BeserkDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 20 'Double Punch
                        bDoublePunch = True
                        If (MyCLng(rsPlayer!DoublePunchDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 30 'Drop Kick
                        bDropKick = True
                        If (MyCLng(rsPlayer!DropKickDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 40 'Meditate
                        bMeditate = True
                        If (MyCLng(rsPlayer!MeditateDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 50 'Head Butt
                        bHeadButt = True
                        If (MyCLng(rsPlayer!HeadButtDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 60 'Elbow
                        bElbow = True
                        If (MyCLng(rsPlayer!ElbowDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 70 'Knee
                        bKnee = True
                        If (MyCLng(rsPlayer!KneeDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 80 'Claw Hand
                        bClawHand = True
                        If (MyCLng(rsPlayer!ClawHandDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 90 'Knife Hand
                        bKnifeHand = True
                        If (MyCLng(rsPlayer!KnifeHandDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 100 'Dragon Uppercut
                        bDragonUppercut = True
                        If (MyCLng(rsPlayer!DragonUppercutDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 110 'Power Kick
                        bPowerKick = True
                        If (MyCLng(rsPlayer!PowerKickDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                    Case 120 'Hurricane Kick
                        bHurricaneKick = True
                        If (MyCLng(rsPlayer!HurricaneKickDuration) <> 0 And (lReloadPenalty = 0)) Then lFails = lFails + 1
                End Select
                
                If (lReloadPenalty = 0) Then
                    subActivateWeaponSpell lObjectActivateSpellNo, lPlayerID, zScript1p, zScript3p
                    subActivateWeaponSkill lObjectActivateSkillNo, lPlayerID, zScript1p, zScript3p
                End If
                If (Len(zScript1p) > 0) Then subSendMsg zTrimCrLf(zScript1p), zPortID
                
                rsPlayer.MoveNext
            Loop
            
            If (lFails > 0) Then
                MyDB.Execute "UPDATE tblPlayer SET ReloadPenalty = " & (lFails * lDuration) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                zScript1p = zScript1p & "&GYou reload all of your skills and had " & lFails & " penalties." & vbCrLf
            End If
        Else
            subSendMsg "&GYou are not wearing any reload spells nor skills.", zPortID
        End If
        Set rsPlayer = Nothing
        
        If (lReloadPenalty <> 0) Then subSendMsg "&RYou have a reload penalty of " & lReloadPenalty & " rounds left!" & vbCrLf & "To prevent this make sure all of your skills are not active when you reload.", zPortID
        
        lMissing = 0
        If (Not bBerserk) Then lMissing = lMissing + 1
        If (Not bDoublePunch) Then lMissing = lMissing + 1
        If (Not bDropKick) Then lMissing = lMissing + 1
        If (Not bMeditate) Then lMissing = lMissing + 1
        If (Not bHeadButt) Then lMissing = lMissing + 1
        If (Not bElbow) Then lMissing = lMissing + 1
        If (Not bKnee) Then lMissing = lMissing + 1
        If (Not bClawHand) Then lMissing = lMissing + 1
        If (Not bKnifeHand) Then lMissing = lMissing + 1
        If (Not bDragonUppercut) Then lMissing = lMissing + 1
        If (Not bPowerKick) Then lMissing = lMissing + 1
        If (Not bHurricaneKick) Then lMissing = lMissing + 1
        
        bMissing = False
        If (Not gblbFilterMode(MyCLng(zPortID))) Then
            bMissing = (Not bBerserk Or Not bDoublePunch Or Not bDropKick Or Not bMeditate Or Not bHeadButt Or Not bElbow Or Not bKnee Or Not bClawHand Or Not bKnifeHand Or Not bDragonUppercut Or Not bPowerKick Or Not bHurricaneKick)
            If (bMissing) Then
                If (Not bBerserk) Then zScriptSkillsMissing = zScriptSkillsMissing & "Berserk "
                If (Not bDoublePunch) Then zScriptSkillsMissing = zScriptSkillsMissing & "Double-Punch "
                If (Not bDropKick) Then zScriptSkillsMissing = zScriptSkillsMissing & "Drop-Kick "
                If (Not bMeditate) Then zScriptSkillsMissing = zScriptSkillsMissing & "Meditate "
                If (Not bHeadButt) Then zScriptSkillsMissing = zScriptSkillsMissing & "Head-Butt "
                If (Not bElbow) Then zScriptSkillsMissing = zScriptSkillsMissing & "Elbow "
                
                If (Len(zScriptSkillsMissing) > 65) Then zScriptSkillsMissing = zScriptSkillsMissing & vbCrLf
                
                If (Not bKnee) Then zScriptSkillsMissing = zScriptSkillsMissing & "Knee "
                If (Not bClawHand) Then zScriptSkillsMissing = zScriptSkillsMissing & "Claw-Hand "
                If (Not bKnifeHand) Then zScriptSkillsMissing = zScriptSkillsMissing & "Knife-Hand "
                If (Not bDragonUppercut) Then zScriptSkillsMissing = zScriptSkillsMissing & "Dragon-Uppercut "
                If (Not bPowerKick) Then zScriptSkillsMissing = zScriptSkillsMissing & "Power-Kick "
                If (Not bHurricaneKick) Then zScriptSkillsMissing = zScriptSkillsMissing & "Hurricane-Kick "
                
                subSendMsg cstzRealmQuestTitle & " &cYou are MISSING the following reload skills: " & vbCrLf & zScriptSkillsMissing & vbCrLf & "&ytype PAGE SKILLS to find more skills and their locations in the realm.", zPortID
            End If
        End If
        
        If (lMissing = 0 Or gblbFilterMode(MyCLng(zPortID))) Then
            subSendMsg "&gReloaded and done!", zPortID
        Else
            subSendMsg "&gReloaded and done! Missing &y" & lMissing & " &gwear skill items.", zPortID
        End If
    Else
        subSendMsg "&GYou need to be standing to reload your skills!", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSkillReloadRemoveWear," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bClassCanStance(zClass As String) As Boolean
On Error Resume Next
    bClassCanStance = (zClass = "AS" Or zClass = "WA" Or zClass = "GL" Or zClass = "MO" Or zClass = "GY")
End Function
Public Sub subPlayerStance(zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim lStatus As Long
    Dim lStance As Long
    Dim zClass As String
    Dim bNormalStance As Boolean
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, Status, Stance, Class FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lStatus = MyCLng(rsPlayer!Status)
        lStance = MyCLng(rsPlayer!stance)
        zClass = MyCStr(rsPlayer!Class)
    Else
        lPlayerID = 0
    End If
    Set rsPlayer = Nothing
    
    If (lPlayerID <> 0) Then
        If (bClassCanStance(zClass)) Then
            If (lStatus = 5) Then
                Select Case MyCStr(Mid(zWord2, 1, 4))
                    Case "AGRE", "A"
                        If (lStance = 1) Then
                            subSendMsg "&rYou are already in an aggressive stance.", zPortID
                        Else
                            lStance = 1
                            subSendMsg "&rYou take an aggressive stance.", zPortID
                        End If
                    Case "DEFE", "D"
                        If (lStance = 2) Then
                            subSendMsg "&rYou are already in a defensive stance.", zPortID
                        Else
                            lStance = 2
                            subSendMsg "&rYou take a defensive stance.", zPortID
                        End If
                    Case "SLAY", "S"
                        If (zClass <> "AS" And zClass <> "MO") Then 'Assassin and Monk cannot slay stance
                            If (lStance = 3) Then
                                subSendMsg "&rYou are already taking a slaying stance.", zPortID
                            Else
                                lStance = 3
                                subSendMsg "&rYou take a slaying stance.", zPortID
                            End If
                        Else
                            bNormalStance = True
                        End If
                    Case "WATE", "W" 'waterloo karate monk stance
                        If (zClass = "MO") Then
                            If (lStance = 4) Then
                                subSendMsg "&rYou are already taking a waterloo stance.", zPortID
                            Else
                                lStance = 4
                                subSendMsg "&rYou take a waterloo stance.", zPortID
                            End If
                        Else
                            bNormalStance = True
                        End If
                    Case "CHIO", "C" 'chiotru karate monk stance
                        If (zClass = "MO") Then
                            If (lStance = 5) Then
                                subSendMsg "&rYou are already taking a chiotru stance.", zPortID
                            Else
                                lStance = 5
                                subSendMsg "&rYou take a chiotru stance.", zPortID
                            End If
                        Else
                            bNormalStance = True
                        End If
                    Case Else
                        bNormalStance = True
                End Select
                
                If (bNormalStance) Then
                    If (lStance = 0) Then
                        subSendMsg "&rYou are already in a normal stance.", zPortID
                    Else
                        lStance = 0
                        subSendMsg "&rYou take a normal stance.", zPortID
                    End If
                End If
                
                MyDB.Execute "UPDATE tblPlayer SET Stance=" & lStance & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            Else
                subSendMsg "&gYou have to stand to use your stance, type ST to stand.", zPortID
            End If
        Else
            subSendMsg "&gOnly Assassins, Gladiators, Gypsys, Monks, Warriors may use stances." & vbCrLf & "If you are trying to wake up or stand type ST.", zPortID
        End If
        subRecalculatePlayerEquipment lPlayerID, zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerStance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lSpeedShootingArcaneBolt(zRace As String, zClass As String)
    Dim lSpeedShooting As Long
    lSpeedShooting = 9
    Select Case zRace
        Case "DRA", "HAL", "HUM", "ELF", "GNO"
            lSpeedShooting = 1 '1 makes it a natural machine gun
        Case "DWA", "FEL"
            lSpeedShooting = 3 '1 makes it a natural machine gun
        Case Else
            Select Case zClass
                Case "PA", "MA"
                    lSpeedShooting = 1 '1 makes it a natural machine gun
                Case "CL", "DR"
                    lSpeedShooting = 3 '1 makes it a natural machine gun
            End Select
    End Select 'dont use an else here
    lSpeedShootingArcaneBolt = lSpeedShooting
End Function
Public Sub subChanceGuardsInWhereIDAttackPlayerID(lPlayerID As Long, lChance As Long)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT tblMob.MobID FROM (tblArea INNER JOIN tblMob ON (tblArea.Z = tblMob.Z) AND (tblArea.Y = tblMob.Y) AND (tblArea.X = tblMob.X)) INNER JOIN tblPlayer ON tblArea.WhereID = tblPlayer.WhereID WHERE (((tblPlayer.PlayerID)=" & lPlayerID & ") AND ((tblMob.MobName) Like '*guard*'));", dbOpenSnapshot)
    Do While (Not rsPlayer.EOF)
        If (lRandom(lChance) = 1) Then MyDB.Execute "UPDATE tblMob SET PlayerID=" & lPlayerID & " WHERE (MobID=" & MyCLng(rsPlayer!MobID) & ");", dbFailOnError
        rsPlayer.MoveNext
    Loop
    Set rsPlayer = Nothing
    
    Exit Sub
Err_Check:
   subWriteErrorFile "subChanceGuardsInWhereIDAttackPlayerID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subCombatARCANEBOLT(zPortID As String, zCmd As String, zWord1 As String, zWord2 As String)
On Error GoTo Err_Check 'gbllWITCHLOCKPlayerID  means you are a fresh and powerful witchlocke before you get old and cannot use it as well but you have slist still!!! its a MAJIK-MORPH
'1: Check to make sure the Target is aquired and in range.
'2: we check to see if the player's other hand is free first before: a) we pull back the bow string b) we crank back the crossbow c) we pull back the sling
'3: we check to see if the proper missile ammo is available for the missile type in the player's inventory
'4: we make sure some ammo is available
'5: we get the name of the missile weapon using the weapon name - ARROW for BOW, BOLT for CROSSBOW, STONE for SLINGS
'6: We use the missile name to check the player's inventory for the ammo.
'7: If we use up the ammo we delete the empty quiver.
    Const cstlPerfectShotValue = 700
    Const cstlManaCost = 400
    Const cstlSoulCost = 250
    Dim rsPlayer As Recordset
    Dim rsTarget As Recordset
    Dim zSQL As String
    Dim lMAntiMoveDuration As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMMoveAllowed As Long
    Dim zAdVerbName As String
    Dim lRange As Long
    Dim zMissileName As String
    Dim lMissileWeaponID As Long
    Dim lMissileAmmoGroupAmt As Long
    Dim lMissileAmmoID As Long
    Dim lHandsFull As Long
    Dim lTargetID As Long
    Dim bCorrectAmmo As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim lMissileFinalDamageTotal As Long
    Dim bTargetAquired As Boolean
    Dim lXP As Long
    Dim lMissileAverageDamage As Long
    Dim lBaseAttribDmg As Long
    Dim zDPortID As String
    Dim bMissileWeapon As Boolean
    Dim lTotalHP As Long
    Dim bAutoLoot As Boolean
    Dim iMessedUp As Integer
    Dim iHit As Integer
    Dim bMobTargeted As Boolean
    Dim bPlayerTargeted As Boolean
    Dim zDirection As String
    Dim zDirectionCameFrom As String
    Dim bPlayerFound As Boolean
    Dim bBounty As Boolean
    Dim lPlayerID As Long
    Dim lMagicFind As Long
    Dim lMagicFindBase As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zRace As String
    Dim zClass As String
    Dim lMissileTargetID  As Long
    Dim lMissileStatus As Long
    Dim lWeaponSkillMissileRangeClassLevel As Long
    Dim lPlayerLevel As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lCDEX As Long
    Dim lCCon As Long
    Dim lCCHA As Long
    Dim lCLuc As Long
    Dim lQuestMobID As Long
    Dim zPlayerName As String
    Dim lStunDuration As Long
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration  As Long
    Dim lInvisibilityDuration As Long
    Dim bInvisEvilMage As Boolean
    Dim lStatus As Long
    Dim lAlignment As Long
    Dim lDistance As Long
    Dim lMissileDistance As Long
    Dim lSlayChance As Long
    Dim lTLevel As Long
    Dim bCanSlayChance As Boolean
    Dim bWatchSpeed As Boolean
    Dim lPortID As Long
    Dim lStance As Long
    Dim lEntanglementDuration As Long
    Dim lIASChance As Long
    Dim lHoldGold As Long
    Dim lGold As Long
    Dim lCMana As Long
    Dim lCSoul As Long
    Dim bMSpecialSelfDeleting As Boolean
    Dim lMSpecialGloryPlayerAmt As Long
    Dim lPlayerTotalStats As Long
    Dim lMHerdMobID As Long
    Dim iDamageResult As Integer
    Dim lSpeedShooting As Long
    Dim zMissileWeaponType As String
    Dim zBittenReservedOriginalClass As String
    Dim lNeverAttackable As Long
    Dim zMsg As String
    Dim lCrown As Long
    Dim lCrownCost As Long
    
    iMessedUp = -1
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
    If (gbltDurations(lPortID).lARCANEBOLT = 0) Then
        If (Len(MyCStr(zWord1 & zWord2)) > 0) Then subCombatMissileTarget zPortID, MyCStr(zWord1 & zWord2), False, True
        Set rsPlayer = MyDB.OpenRecordset("SELECT Crown, Alignment, BittenReservedOriginalClass, CMana, CSoul, TurnedIntoAnimalType, CStr, CInt, CWis, CDex, CCon, CCha, CLuc, XP, Gold, QuestMobID, IASChance, EntanglementDuration, Stance, MagicFindBase, MagicFind, SlayChance, InvisibilityDuration, Status, SleepDuration, StunDuration, PlayerFleeDuration, PlayerName, PlayerLevel, WeaponSkillMissileRangeClassLevel, MissileStatus, MissileTargetID, Status, Race, Class, X, Y, Z, PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lCrown = MyCLng(rsPlayer!Crown)
            lAlignment = MyCLng(rsPlayer!Alignment)
            zRace = MyCStr(rsPlayer!Race)
            zClass = MyCStr(rsPlayer!Class)
            zBittenReservedOriginalClass = MyCStr(rsPlayer!BittenReservedOriginalClass)
            Select Case zBittenReservedOriginalClass
                Case "MA", "CL", "DR"
                    lCrownCost = 1
                Case "PA"
                    lCrownCost = 5
                Case Else
                    lCrownCost = 3
            End Select
            lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lCStr = MyCLng(rsPlayer!CStr)
            lCINT = MyCLng(rsPlayer!CInt)
            lCWIS = MyCLng(rsPlayer!CWIS)
            lCDEX = MyCLng(rsPlayer!CDEX)
            lCCon = MyCLng(rsPlayer!CCon)
            lCCHA = MyCLng(rsPlayer!CCHA)
            lCLuc = MyCLng(rsPlayer!CLuc)
            lCMana = MyCLng(rsPlayer!CMana)
            lCSoul = MyCLng(rsPlayer!CSoul)
            lPlayerTotalStats = lCStr + lCINT + lCWIS + lCDEX + lCCon + lCCHA + lCLuc + lPlayerLevel
            lXP = MyCLng(rsPlayer!XP)
            lHoldGold = 0
            lGold = MyCLng(rsPlayer!Gold)
            lIASChance = MyCLng(rsPlayer!IASChance)
            lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration) 'If (lEntanglementDuration = 0) Then    subSendMsg "&RYou are ensnared and cannot move.", zPortID
            lStance = MyCLng(rsPlayer!stance)
            lSlayChance = MyCLng(rsPlayer!SlayChance)
            bPlayerFound = True
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lX = MyCLng(rsPlayer!x)
            lY = MyCLng(rsPlayer!y)
            lZ = MyCLng(rsPlayer!z)
            lQuestMobID = MyCLng(rsPlayer!QuestMobID)
            lMagicFind = MyCLng(rsPlayer!MagicFind)
            lMagicFindBase = MyCLng(rsPlayer!MagicFindBase)
            If (zClass = "IO") Then
                lSlayChance = MyCLng((lSlayChance) + MyCLng(lSlayChance * 0.5)) 'ranger gets this bonus too but only with a bow
            Else
                Select Case zBittenReservedOriginalClass
                    Case "DR", "CL" 'druid cleric witchlocke
                        lSlayChance = MyCLng((lSlayChance) + MyCLng(lSlayChance * 0.25))
                    Case "MA", "PA" 'mage paladin
                        lSlayChance = MyCLng((lSlayChance) + MyCLng(lSlayChance * 0.65)) 'ranger gets this bonus too but only with a bow
                End Select
            End If
            lStatus = MyCLng(rsPlayer!Status)
            lMissileTargetID = MyCLng(rsPlayer!MissileTargetID)
            lMissileStatus = MyCLng(rsPlayer!MissileStatus)
            lWeaponSkillMissileRangeClassLevel = MyCLng(rsPlayer!WeaponSkillMissileRangeClassLevel)
            lStunDuration = MyCLng(rsPlayer!StunDuration)
            lSleepDuration = MyCLng(rsPlayer!SleepDuration)
            lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
            lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
            
            lHandsFull = lngSQLRecordCount("SELECT tblObject.PlayerID, tblObject.Location FROM tblObject INNER JOIN tblPlayerEquipmentItems ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID WHERE (((tblObject.PlayerID)=" & lPlayerID & ") AND ((tblObject.Location)=20));")
        Else
            bPlayerFound = False
        End If
        Set rsPlayer = Nothing
        
        If (bPlayerFound) Then
            bInvisEvilMage = False
            If (lPlayerID = gbllWITCHLOCKPlayerID Or zClass = "IO" Or zClass = "MA" Or zClass = "PA" Or zClass = "CL" Or zClass = "DR") Then 'io is witchlocke
            If (lCrown >= lCrownCost) Then
            If (lCMana >= cstlManaCost And lCSoul >= cstlSoulCost) Then
            If (lAlignment < -989) Then
                If (lPlayerID = gbllWITCHLOCKPlayerID Or zClass = "MA" Or zClass = "PA" Or zClass = "CY" Or zClass = "IO") Then
                    bInvisEvilMage = True
                End If
            End If
            If (lInvisibilityDuration = 0 Or lPlayerID = gbllWITCHLOCKPlayerID Or bInvisEvilMage) Then    'witch can fire during invisibility during this short peroid
            If (lTurnedIntoAnimalType = 0 Or lPlayerID = gbllWITCHLOCKPlayerID Or bInvisEvilMage Or zClass = "IO" Or zClass = "DR") Then   'have to be humanoid not a pumpkin, or frog, or mouse or dog or w/e witches are still witches
            If (lEntanglementDuration = 0 Or lPlayerID = gbllWITCHLOCKPlayerID Or bInvisEvilMage Or zClass = "IO") Then   'cyborg isnt affected by entanglement
                If (lStatus = 5 Or lPlayerID = gbllWITCHLOCKPlayerID Or bInvisEvilMage Or zClass = "IO" Or zClass = "CY" Or zClass = "MA" Or zClass = "PA" Or zClass = "CL") Then   'standing mode, not asleep or in battle, during battle the ranger can type STAND to fix this for some typing fun
                    If (lSleepDuration = 0) Then
                        If (lStunDuration = 0) Then
                            If (lPlayerFleeDuration = 0) Then
                                gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges + 1 'causes a random lighting to come down from the heavens, eventually, in thunderstorms only areas
                                If (gbllAtmosphereStaticCharges > cstAtmozDefault) Then gbllAtmosphereStaticCharges = cstAtmozDefault
                                lSpeedShooting = 0
                                bCanSlayChance = False
                                lMissileFinalDamageTotal = (lCINT * 2) + lRandom(lCWIS) * 2 + MyCLng(lPlayerLevel / 4)  'there are many more calculations below this is the default
                                lMissileDistance = 0
                                bCorrectAmmo = False
                                zMissileName = ""
                                lMissileAmmoGroupAmt = 0
                                zDPortID = ""
                                bMobTargeted = False
                                bPlayerTargeted = False
                                Select Case lMissileStatus
                                    Case 1 'Mob
                                        bMobTargeted = (lngSQLRecordCount("SELECT MobID FROM tblMob WHERE (MobID=" & lMissileTargetID & " AND RespawnDelay=0 AND NeverAttackable=0);") <> 0)
                                    Case 2 'Player
                                        bPlayerTargeted = (lngSQLRecordCount("SELECT PlayerID, PortID FROM tblPlayer WHERE (PlayerID=" & lMissileTargetID & " AND Len([PortID])>1);") <> 0)
                                End Select
                                
                                If (bMobTargeted Or bPlayerTargeted) Then
                                    'We get the name for the missile weapon
                                    bMissileWeapon = False
                                    bMissileWeapon = True
                                    lMissileAverageDamage = 200
                                    lMissileWeaponID = 0 'no ammo required
                                    zMissileWeaponType = "majik"
                                    zMissileName = "arcane-bolt"
                                    If (UCase(Mid(zCmd, 1, 1)) = "B") Then zMissileName = "kenetic-bolt"
                                    
                                    lSpeedShooting = lSpeedShootingArcaneBolt(zRace, zClass)
                                    gbltDurations(lPortID).lARCANEBOLT = lSpeedShooting 'see also subCountdownDurations
                                    bCanSlayChance = True
                                    bCorrectAmmo = True
                                    lMissileAverageDamage = lRandom(lMissileAverageDamage)
                                    lBaseAttribDmg = lRandom(MyCLng(lCDEX / 2)) + MyCLng(lCDEX / 2) + lRandom(MyCLng(lCStr / 2))
                                    lMissileFinalDamageTotal = lMissileAverageDamage + lBaseAttribDmg + lMissileAverageDamage
                                    lMissileAmmoID = -100
                                    lMissileAmmoGroupAmt = 1
                                    
                                    'Number of empty hands some classes can bolt while holding items
                                    If (lHandsFull = 0 Or zClass = "MA" Or zClass = "PA" Or zClass = "IO") Then
                                        MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]-" & lCrownCost & ", CMana=[CMana]-" & cstlManaCost & ", CSoul=[CSoul]-" & cstlSoulCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        If (lRandom(100) >= lReturnTranslateAimlevel(zRace, zClass)) Then 'bolt hit
                                        Select Case lMissileStatus
                                            Case 1 'Mob
                                                zSQL = "SELECT AntiMoveDuration, MoveAllowed, HerdMobID, SpecialGloryPlayerAmt, SpecialSelfDeleting, DefeatedMobDesc, MobLevel, MHP, MobID, MobName, X, Y, Z FROM tblMob WHERE (MobID=" & lMissileTargetID & " AND RespawnDelay=0);"
                                            Case 2 'Player
                                                zSQL = "SELECT PlayerLevel, CHP, PlayerID, PlayerName, X, Y, Z, PortID FROM tblPlayer WHERE (PlayerID=" & lMissileTargetID & " AND Len([PortID])>1);"
                                        End Select
                                        
                                        lTX = 0
                                        lTY = 0
                                        lTZ = 0
                                        
                                        lRange = lWeaponSkillMissileRangeClassLevel
                                        
                                        bTargetAquired = False
                                        'We get the X, Y, Z location of the target
                                        Set rsTarget = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                        If (Not rsTarget.EOF) Then
                                            Select Case lMissileStatus
                                                Case 1 'Mob
                                                    lMAntiMoveDuration = MyCLng(rsTarget!AntiMoveDuration)
                                                    lMMoveAllowed = MyCLng(rsTarget!MoveAllowed)
                                                    lMHerdMobID = MyCLng(rsTarget!HerdMobID)
                                                    lMSpecialGloryPlayerAmt = MyCLng(rsTarget!SpecialGloryPlayerAmt)
                                                    bMSpecialSelfDeleting = (MyCInt(rsTarget!SpecialSelfDeleting) <> 0)
                                                    bBounty = (Len(MyCStr(rsTarget!DefeatedMobDesc)) > 0)
                                                    lTLevel = MyCLng(rsTarget!MobLevel)
                                                    lTotalHP = MyCLng(rsTarget!MHP)
                                                Case 2 'Player
                                                    lMSpecialGloryPlayerAmt = 0
                                                    bMSpecialSelfDeleting = False
                                                    bBounty = False
                                                    lTLevel = MyCLng(rsTarget!PlayerLevel)
                                                    lTotalHP = MyCLng(rsTarget!CHP)
                                            End Select
                                            
                                            bTargetAquired = True
                                            lTX = MyCLng(rsTarget!x)
                                            lTY = MyCLng(rsTarget!y)
                                            lTZ = MyCLng(rsTarget!z)
                                            
                                            If (lX = lTX And lY = lTY And lZ = lTZ) Then
                                                lRange = lRange + 1 'we allow a player to shoot in the same room with a mob ALWAYS
                                            Else
                                                If (lRange = 0) Then subSendMsg "&RYou do not have the range to shoot that far.", zPortID
                                            End If
                                            
                                            Select Case lMissileStatus
                                                Case 1 'Mob
                                                    lTargetID = MyCLng(rsTarget!MobID)
                                                    zAdVerbName = zShortstop(MyCStr(rsTarget!MobName))
                                                Case 2 'Player
                                                    zDPortID = MyCStr(rsTarget!PortID)
                                                    lTargetID = MyCLng(rsTarget!PlayerID)
                                                    zAdVerbName = zShortstop(MyCStr(rsTarget!PlayerName))
                                            End Select
                                            zAdVerbName = zAdverb(zAdVerbName, 2) & zAdVerbName
                                        End If
                                        Set rsTarget = Nothing
                                        
                                        If (bTargetAquired) Then
                                            'We get the math directions towards the target
                                            lPX = lTX - lX 'get the path x
                                            lPY = lTY - lY 'get the path y
                                            lPZ = lTZ - lZ 'get the path z
                                            lDistance = Abs(lPX) + Abs(lPY) + Abs(lPZ)
                                            zDirection = ""
                                            zDirectionCameFrom = ""
                                            If (lPY > 0) Then
                                                lPY = 1
                                                zDirection = "S"
                                                zDirectionCameFrom = "N"
                                            End If
                                            If (lPY < 0) Then
                                                lPY = -1
                                                zDirection = "N"
                                                zDirectionCameFrom = "S"
                                            End If
                                            If (lPX > 0) Then
                                                lPX = 1
                                                zDirection = zDirection & "E"
                                                zDirectionCameFrom = zDirectionCameFrom & "W"
                                            End If
                                            If (lPX < 0) Then
                                                lPX = -1
                                                zDirection = zDirection & "W"
                                                zDirectionCameFrom = zDirectionCameFrom & "E"
                                            End If
                                            If (lPZ > 0) Then
                                                lPZ = 1
                                                zDirection = zDirection & "D"
                                                zDirectionCameFrom = zDirectionCameFrom & "U"
                                            End If
                                            If (lPZ < 0) Then
                                                lPZ = -1
                                                zDirection = zDirection & "U"
                                                zDirectionCameFrom = zDirectionCameFrom & "D"
                                            End If
                                            If (zDirection = "") Then zDirection = "HERE"
                                            If (zDirectionCameFrom = "") Then zDirectionCameFrom = "HERE"
                                            
                                            lMX = lX
                                            lMY = lY
                                            lMZ = lZ
                                            
                                            subSendMsgAreaAllDISmart "&a", zPlayerName, "&B[" & zDirection & "] &yYou [release d[" & lDistance & "]] " & zMissileName & ".", "", "&B[" & zDirection & "] &y%s1 [releases d[" & lDistance & "]] " & zMissileName & ".", lX, lY, lZ
                                            
                                            iHit = 0 'hasnt hit anything yet
                                            bWatchSpeed = True
                                            Do While (lRange > 0 And iHit = 0)
                                                lMissileDistance = lMissileDistance + 1
                                                lRange = lRange - 1
                                                lMX = lMX + lPX
                                                lMY = lMY + lPY
                                                lMZ = lMZ + lPZ
                                                
                                                'We now guide the missile towards the target with the max range of WeaponSkillMissileRangeClassLevel
                                                If (bCheckAreaExists(zPortID, lMX, lMY, lMZ, False)) Then
                                                    If (lMX = lTX And lMY = lTY And lMZ = lTZ) Then
                                                        iDamageResult = 0
                                                        If (lMissileStatus = 1) Then 'bonus dmg
                                                            If (lRandom(lCStr + (lCDEX * 2) + lRandom(lCLuc * 2) + lPlayerLevel) + (lWeaponSkillMissileRangeClassLevel * 2) > lRandom(3200)) Then
                                                                iDamageResult = 11 'perfect shot
                                                                lMissileFinalDamageTotal = lMissileFinalDamageTotal + MyCLng(lMissileFinalDamageTotal / 2) + (lRandom(lMissileFinalDamageTotal / 2))
                                                                subSendMsg "&W*PIN-DOWN SET*" & zFormatGoldCofGLearnpts(1000, "p", True), zPortID
                                                                lMAntiMoveDuration = lRandom(9) + 19
                                                                MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+1000 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                            Else
                                                                iDamageResult = 10 'normal hit
                                                            End If
                                                        End If
                                                        lTotalHP = lTotalHP - lMissileFinalDamageTotal
                                                        If (lTotalHP < 1) Then lTotalHP = 1
                                                        
                                                        'If (lTotalHP = 1) Then subSendMsg "&R             ~ F I N I S H  I T ~", zPortID
                                                        'We now subtract the hitpoints of the target but we never let it fall below zero.
                                                        'We do not give experience for this attack - like fireball attack spell
                                                        'Mob and Player hit points never fall below 1
                                                        
                                                        Select Case (lMissileStatus) 'we do the dmg for the right target
                                                            Case 1 'Mob
                                                                iHit = 1
                                                                'If (lRandom(lPlayerTotalStats + lCStr + (lCDEX * 2) + lRandom(lCLuc + lCCha) + lPlayerLevel) + (lWeaponSkillMissileRangeClassLevel * 2) > lRandom(cstlPerfectShotValue)) Then
                                                                '    iDamageResult = 11 'perfect shot
                                                                '    lMissileFinalDamageTotal = lMissileFinalDamageTotal + lRandom(lMissileFinalDamageTotal)
                                                                '    subSendMsg "&W"  & "*perfect shot*" & zFormatGoldCofGLearnpts(1000,"p"), zPortID
                                                                '    MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+1000 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                'Else
                                                                '    iDamageResult = 10 'normal hit
                                                                'End If
                                                                'For mobs we set the tblMob.PlayerID to missile attacker so the mob can chase them
                                                                If (lTotalHP = 1 Or bCanSlayChance Or lRandom(lSlayChance) > lRandom(100)) Then
                                                                    If (lTotalHP = 1 Or lRandom(lSlayChance + lSlayChance) > lRandom(700 + lTLevel) Or lRandom(lSlayChance) > lRandom(100)) Then
                                                                        iMessedUp = 0
                                                                        If (lTotalHP = 1) Then
                                                                            iDamageResult = 12 'normal killed
                                                                            subSendMsg "&r" & zAdVerbName & " was -=killed=- by your " & zMissileName & "! *normal shot*" & zFormatGoldCofGLearnpts(500, "p", True), zPortID
                                                                            subSendMsgAreaAll gblzFNRED & zMissileName & " -=killed=- " & zAdVerbName & "!", lMX, lMY, lMZ
                                                                            MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+500 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                        Else
                                                                            iDamageResult = 13 'slay killed
                                                                            subSendMsg "&R" & zAdVerbName & " was -=slayed=- by your " & zMissileName & zFormatGoldCofGLearnpts(2000, "p", True), zPortID
                                                                            subSendMsgAreaAll "&R" & zMissileName & " -=slays=- " & zAdVerbName & "!", lMX, lMY, lMZ
                                                                            MyDB.Execute "UPDATE tblPlayer SET XP = [XP]+2000 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                        End If
                                                                        'cancel all those attacking this mobid
                                                                        subCombatEndedInitializeCombatCellsMobID lMissileTargetID
                                                                        MyDB.Execute "UPDATE tblMob SET RespawnDelay=2+" & lRandom(9) & " WHERE (MobID=" & lMissileTargetID & ");"
                                                                        If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                                                                            bAutoLoot = gblbAutoloot(lPortID)
                                                                            gblbAutoloot(lPortID) = False
                                                                            subMakeCorpse zPortID, lPlayerID, lPlayerLevel, lMissileTargetID, "M", lMagicFind, lMagicFindBase, lCLuc
                                                                            subPlayerQuest zPlayerName, lPlayerID, lPlayerLevel, lQuestMobID, zAdVerbName, lMissileTargetID, lTLevel, bBounty, zPortID, lMX, lMY, lMZ, lHoldGold, lMMoveAllowed
                                                                            If (lHoldGold > 0) Then lGold = lGold + lHoldGold
                                                                            If (bMSpecialSelfDeleting) Then
                                                                                MyDB.Execute "DELETE MobID FROM tblMob WHERE (MobID=" & lMissileTargetID & ");", dbFailOnError
                                                                                'RULE: Careful to NEVER give a deleting mob equipment to drop or sell
                                                                            End If
                                                                            If (lMSpecialGloryPlayerAmt > 0) Then
                                                                                If (lPlayerTotalStats > (lTLevel * 3)) Then 'this keeps the exploit of high levels killing all mobs
                                                                                    subSendMsg "&M[EASY] Congratulations! You defeated " & zAdVerbName & ".", zPortID
                                                                                Else
                                                                                    subSendMsg "&W[HARD] Congratulations! You heroically defeated " & zAdVerbName & "!", zPortID
                                                                                End If
                                                                                subSendMsgInfoChannel "[" & zWhereName(lPX, lPY, lPZ) & "&g] &w" & zPlayerName & " &a[defeated] &g[" & zAdVerbName & "] " & zFormatGoldCofGLearnpts(lMSpecialGloryPlayerAmt, "c", True)
                                                                                MyDB.Execute "UPDATE tblPlayer SET QuestMissionLog='', Crown=[Crown]+" & lMSpecialGloryPlayerAmt & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                            End If
                                                                            subMobSpeakDeathScene lMissileTargetID
                                                                            
                                                                            'We now check to see if this mob is part of a quest herd
                                                                            If (lMHerdMobID <> 0) Then subQuestHerdMob lMHerdMobID, zPlayerName, lPlayerID, lMagicFind, lMagicFindBase, lPlayerLevel, False, zPortID
                                                                            gblbAutoloot(lPortID) = bAutoLoot 'return autoloot to the original status
                                                                        End If
                                                                    End If
                                                                End If
                                                                
                                                                If (iDamageResult <> 12 And iDamageResult <> 13) Then MyDB.Execute "UPDATE tblMob SET AntiMoveDuration=" & lMAntiMoveDuration & ", MHP=" & lTotalHP & ", PlayerID=" & lPlayerID & " WHERE (MobID=" & lTargetID & ");", dbFailOnError
                                                            Case 2 'Player
                                                                iHit = 1
                                                                iDamageResult = 20 'hit we dont slay player past 1 hp
                                                                subSendMsg "&ROWE!!! &B[" & zDirectionCameFrom & "] &R[missile hit] [" & zMissileName & "] d[" & lMissileDistance & "] dmg[" & lMissileFinalDamageTotal & "]", zDPortID
                                                                subForceInterrupt lIASChance, zDPortID, zPortID, 1
                                                                If (bCanSlayChance Or lRandom(lSlayChance) > lRandom(100)) Then
                                                                    If (lRandom(lSlayChance + lSlayChance) > lRandom(700 + lTLevel) Or lRandom(lSlayChance) > lRandom(100)) Then
                                                                        iMessedUp = 0
                                                                        iDamageResult = 21 'slayed
                                                                        subSendMsg "&W-=slayed to a single hitpoint=-", zPortID
                                                                        MyDB.Execute "UPDATE tblPlayer SET CHP=1 WHERE (PlayerID=" & lTargetID & ");"
                                                                    End If
                                                                Else
                                                                    MyDB.Execute "UPDATE tblPlayer SET CHP=" & lTotalHP & " WHERE (PlayerID=" & lTargetID & ");", dbFailOnError
                                                                End If
                                                        End Select
                                                        
                                                        'print results
                                                        If (iDamageResult <> 12 And iDamageResult <> 13 And iDamageResult <> 21) Then
                                                            'if it didnt kill then show the status
                                                            subSendMsg "&yYour " & zMissileName & " hit " & zAdVerbName & "! d[" & lMissileDistance & "] dmg[" & lMissileFinalDamageTotal & "] hp[" & lTotalHP & "]", zPortID
                                                            subSendMsgAreaExcept2 "&B[" & zDirectionCameFrom & "] &yThe " & zMissileName & " hits " & zAdVerbName & "!", lMX, lMY, lMZ, zPortID, zDPortID
                                                            iMessedUp = 1
                                                        Else
                                                            'the missile weapon finished off the creature
                                                            subSendMsg "&yYour " & zMissileName & " finished off " & zAdVerbName & "! d[" & lMissileDistance & "] dmg[" & lMissileFinalDamageTotal & "] hp[" & lTotalHP & "]", zPortID
                                                            subSendMsgAreaExcept2 "&B[" & zDirectionCameFrom & "] &yThe " & zMissileName & " finished off " & zAdVerbName & "!", lMX, lMY, lMZ, zPortID, zDPortID
                                                            iMessedUp = 0
                                                        End If
                                                    Else
                                                        If (bWatchSpeed) Then
                                                            bWatchSpeed = False
                                                            subSendMsg "&yYou watch the " & zMissileName & " speed for its target!", zPortID
                                                        End If
                                                        subSendMsgAreaExcept2 "&ySomething is heard speeding through the room!", lMX, lMY, lMZ, zPortID, ""
                                                    End If
                                                Else
                                                    iMessedUp = 3
                                                    iHit = 2
                                                    subSendMsg "&y[missed] d[" & lMissileDistance & "] The " & zMissileName & " smashed into a wall!", zPortID
                                                    subSendMsgAreaExcept2 "&GSomething swishing though the air smashed into a wall closeby!", lMX, lMY, lMZ, zPortID, ""
                                                End If
                                            Loop
                                            
                                            If (iHit = 0) Then
                                                iMessedUp = 4
                                                subSendMsg "&y d[" & lMissileDistance & "] Your " & zMissileName & " crashes to the ground before it reaches " & zAdVerbName & ".", zPortID
                                                subSendMsgAreaExcept2 "&yd[" & lMissileDistance & "] Something is heard hitting the ground.", lMX, lMY, lMZ, zPortID, ""
                                            End If
                                        Else
                                            subSendMsg "&y[missed] The target must of moved!", zPortID
                                        End If
                                        Else 'If (lRandom(100) > 9) Then 'bolt hit
                                            If (MyCLng(lCCHA / 2) + (lRandom(lCDEX) + lCDEX) + lRandom(lCINT) + MyCLng(lRandom(lCWIS / 4)) < lRandom(333) + 100) Or (lRandom(5) = 1) Then
                                                MyDB.Execute "UPDATE tblPlayer SET [StunDuration]=" & lRandom(20) + 6 & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError  'dex + cha are the base values for this formula
                                                MyDB.Execute "UPDATE tblPlayer SET [CSoul]=1 WHERE (Len([PortID])>1 AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
                                                If (gblbScareMode(lPortID)) Then MyDB.Execute "UPDATE tblMob SET PlayerID=" & lPlayerID & " WHERE (MobName LIKE '*guard*' AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError 'activate guards in the room too
                                                subSendMsgAreaAll "&R~ ~ EVERYONE IN THE ROOM SACRIFICES THEIR SOUL TO A BOGUS ARCANE BOLT ~ ~", lX, lY, lZ
                                                iMessedUp = 5
                                            Else
                                                If lRandom(2) = 1 Then MyDB.Execute "UPDATE tblPlayer SET [CSoul]=([CSoul]/2)+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            End If
                                            If lRandom(2) = 1 Then MyDB.Execute "UPDATE tblPlayer SET [CMana]=([CMana]/2)+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            If lRandom(5) = 1 Then MyDB.Execute "UPDATE tblPlayer SET [CHP]=([CHP]/2)+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            subSendMsg "&RBoGuS! Your bolt miss-fired!", zPortID
                                        End If
                                        If (iMessedUp > 0) Then subChanceGuardsInWhereIDAttackPlayerID lPlayerID, 2
                                    Else
                                        subSendMsg "&yYou need to free both your hands.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYou need to MISSILE TARGET something first.", zPortID
                                End If
                            Else
                                subSendMsg "&RYou are too scared to arcane-bolt anything!", zPortID
                            End If
                        Else
                            subSendMsg "&RYou are too stunned to arcane-bolt!", zPortID
                        End If
                    Else
                        subSendMsg "&RYou dream about a perfect arcane-bolting to the enemy face!", zPortID
                    End If
                Else
                    subSendMsg "&RYou must be standing to do that.", zPortID
                End If
            Else
                subSendMsg "&RYour arcane-bolt is too entangled and drifts targets too easily!", zPortID
            End If
            Else
                subSendMsg "&RYou are not of a humanoid form to do that.", zPortID
            End If
            Else
                subSendMsg "&RYou would break your invisibility if you attacked.", zPortID
            End If
        Else
            subSendMsg "&RArcane-Bolt: Need " & cstlManaCost & " Mana and " & cstlSoulCost & " Soul per cast", zPortID
        End If
        Else
            subSendMsg "&RYou have " & lCrown & " and require " & lCrownCost & " cofg to kenetic bolt.", zPortID
        End If
        Else
            subSendMsg "&gHuh?", zPortID
        End If
        Else
            subSendMsg "&RArcane-Bolt: Your player file was not found report this to an immortal.", zPortID
        End If
    Else
        subSendMsg "&R       ...standby, forming hand energy, standby...", zPortID
    End If
    End If
    
    Exit Sub
Err_Check:
   subWriteErrorFile "subCombatARCANEBOLT," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
