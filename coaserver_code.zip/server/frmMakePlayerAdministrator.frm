VERSION 5.00
Begin VB.Form frmMakePlayerAdministrator 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Administrator"
   ClientHeight    =   3285
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   2310
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "frmMakePlayerAdministrator.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   3285
   ScaleWidth      =   2310
   Begin VB.CommandButton cmdRevokeAdmin 
      Appearance      =   0  'Flat
      Caption         =   "Revoke"
      Height          =   255
      Left            =   1200
      TabIndex        =   2
      ToolTipText     =   "Revoke this player name from being immortal."
      Top             =   2880
      Width           =   975
   End
   Begin VB.CommandButton cmdMakeAdmin 
      Appearance      =   0  'Flat
      Caption         =   "Make"
      Height          =   255
      Left            =   120
      TabIndex        =   1
      ToolTipText     =   "Make this player name an immortal."
      Top             =   2880
      Width           =   975
   End
   Begin VB.ListBox lstPlayerNames 
      Appearance      =   0  'Flat
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   2430
      Left            =   120
      TabIndex        =   0
      ToolTipText     =   "asterix means the player is an immortal already."
      Top             =   360
      Width           =   2055
   End
   Begin VB.Label lblTitle 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      Caption         =   "0 to 100 | Player Name"
      ForeColor       =   &H80000008&
      Height          =   255
      Left            =   120
      TabIndex        =   3
      Top             =   120
      Width           =   2055
   End
End
Attribute VB_Name = "frmMakePlayerAdministrator"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gblzPlayerName As String

Private Sub Form_Load()
    Dim rsPlayer As Recordset
    
    lstPlayerNames.Clear
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, ImmortalLevel FROM tblPlayer WHERE (Len([PortID])>1) ORDER BY ImmortalLevel DESC, PlayerName;", dbOpenSnapshot)
    Do While (Not rsPlayer.EOF)
        lstPlayerNames.AddItem MyCStr(rsPlayer!ImmortalLevel) & " " & MyCStr(rsPlayer!PlayerName)
        rsPlayer.MoveNext
    Loop
    Set rsPlayer = Nothing
    
    gblzPlayerName = ""
End Sub

Private Sub lstPlayerNames_Click()
    gblzPlayerName = zKeepLettersOnly(MyCStr(lstPlayerNames.Text))
End Sub

Private Sub cmdMakeAdmin_Click()
    If (Len(gblzPlayerName) > 3) Then
        If (MsgBox("Would you like to set " & gblzPlayerName & " to Full Systems Administrator?" & vbCrLf & vbCrLf & "NOTE: Use HELP IMMORTAL in the MUD for your commands.", 4) = 6) Then
            subImmortalSetImmLvPlayerName gblzPlayerName, 100
            MsgBox "Player is now an Admin.", vbOKOnly
            Form_Load
        Else
            MsgBox "Cancelled."
        End If
    End If
End Sub

Private Sub cmdRevokeAdmin_Click()
    If (Len(gblzPlayerName) > 3) Then
        If (MsgBox("Would you like to Revoke " & gblzPlayerName & " from being an Administrator?" & vbCrLf & vbCrLf & "NOTE: Use HELP IMMORTAL in the MUD for your commands.", 4) = 6) Then
            subImmortalRevokeImmLvPlayerName gblzPlayerName
            MsgBox "Player has been revoked and no longer an Admin.", vbOKOnly
            Form_Load
        Else
            MsgBox "Cancelled."
        End If
    End If
End Sub
