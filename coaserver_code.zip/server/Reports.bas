Attribute VB_Name = "modReports"
Option Explicit
Public Sub subEyeBeamToggle(zPortID As String)
    Dim rsPlayer As Recordset
    Dim zClass As String
    Dim lPortID As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Class FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zClass = MyCStr(rsPlayer!Class)
    End If
    Set rsPlayer = Nothing

    If (zClass = "CY") Then
        lPortID = MyCLng(zPortID)
        gblbEyeBeams(lPortID) = Not gblbEyeBeams(lPortID)
        If (gblbEyeBeams(lPortID)) Then
            subSendMsg "&gEyebeams are now on.", zPortID
        Else
            subSendMsg "&gEyebeams are now off.", zPortID
        End If
    Else
        subSendMsg "&gYou need to be a Cyborg morph-class to do that.", zPortID
    End If
End Sub
Public Sub subPlayerReports(zPortID As String, zType As String)
On Error GoTo Err_Check
    Dim lImmortalLevel As Long
    'Dim bPageLast As Boolean
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    
    lPlayerID = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, PlayerID, ImmortalLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        'bPageLast = (MyCInt(rsPlayer!PageLast) <> 0)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
    End If
    Set rsPlayer = Nothing

    If (lPlayerLevel >= gblcstlPlayerLevelToWHOPAGELAST) Then
        'These are realm report the players can use to see how they are doing
        Select Case UCase(Mid(zType, 1, 4))
            Case "LOST"
                subReportCheckLostItems zPortID
            Case "ARMA"
                If (gbllREALMQuestArmageddonKillThisManyCreatures > 0) Then
                    subSendMsg "&WREALM QUEST: " & gbllREALMQuestArmageddonPayOff & " GLORY " & gblzFBRED & """ARMAGEDDON""&w Creatures to go: " & gbllREALMQuestArmageddonKillThisManyCreatures & ", " & lArmageddonMinsLeft() & " mins left", zPortID
                    subShowArmageddonKillCount zPortID
                Else
                    subSendMsg "&WREALM QUEST: &r""ARMAGEDDON""&w NOT CURRENTLY RUNNING", zPortID
                End If
            Case "ITEM", "MERC", "POTI", "OBJE"
                subReportMerchantItems zPortID
            Case "THIE", "CHES"
                subReportThiefChest zPortID 'SELECT tblWhere.WhereTitle, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblMob.MobName, tblMob.X, tblMob.Y, tblMob.Z, tblArea.ThiefMobID, tblArea.ThiefChestOfGlory, tblArea.ThiefObjectID FROM (tblArea INNER JOIN tblWhere ON tblArea.WhereID = tblWhere.WhereID) INNER JOIN tblMob ON tblArea.ThiefMobID = tblMob.MobID WHERE (((tblArea.ThiefMobID)<>0));
            Case "ARMY" 'Factions have army quest mobs that move around this is their list
                subSystemFactionArmyQuestMob zPortID
            Case "DONA", "MONE", "USD", "PAYP"
                subPayPalDonationsReport zPortID
            Case "LAST", "WHO", "DATE", "TIME"
                If (gblbPageLastOkay) Then
                    subSystemReportLast10LoggedOn zPortID, lImmortalLevel
                Else
                    subSendMsg "&gHuh?", zPortID
                End If
            Case "FACT"
                subSystemReportFactions zPortID
            Case "REAL"
                subSystemReportRealmStats zPortID, lImmortalLevel
            Case "PK"
                subSystemReportPKsTopBest zPortID
            Case "SKIL"
                subSystemReportSkillLocations zPortID
            Case "COMP"
                subSystemReportSpellComponents zPortID
    '        Case "CASI"
    '            subSystemReportCasinoStats zPortID
            Case "DEAT", "SOUL"
                subSystemReportDeathsToMobs zPortID
            Case "NEUT"
                subSystemReportNeutralColonists zPortID
            Case "CONT"
                subSystemReportTopColonistsControlled zPortID
            Case "STAR"
                subSystemReportTopStarships zPortID
            Case "COLO"
                subSystemReportTopColonists zPortID
            Case "CLAN"
                subSystemReportTotalClan zPortID
            Case "HITR", "HR"
                subSystemReportTopHRDRAC zPortID, "H"
            Case "DAMR", "AVER", "DR", "DAMA"
                subSystemReportTopHRDRAC zPortID, "D"
            Case "AC", "ARMO"
                subSystemReportTopHRDRAC zPortID, "A"
            Case "LV", "LEVE"
                subSystemReportTopHRDRAC zPortID, "L"
            Case "CLAS"
                subSystemReportTotalClass zPortID
            Case "RACE"
                subSystemReportTotalRace zPortID
            Case "QUES", "LOG", "MISS", "ORAC", "ASTE"
                subSystemReportQuestLog zPortID
            Case "BUSY"
                subSystemReportBusy "H", zPortID
            Case "WEEK"
                subSystemReportBusy "W", zPortID
            Case "STR", "INT", "WIS", "DEX", "CON", "CHA", "LUC", "STRE", "INTE", "WISD", "DEXT", "CONS", "CHAR", "LUCK", "SUM", "SUMM", "ALL", "ADD"
                subSystemReportStats UCase(Mid(zType, 1, 3)), zPortID
    '        Case "GOLD", "RICH"
    '            subSystemReportStatsGold UCase(Mid(zType, 1, 4)), zPortID
            Case "SLAY"
                subSystemReportStatsSLAY UCase(Mid(zType, 1, 4)), zPortID
            Case "IAS"
                subSystemReportStatsIAS UCase(Mid(zType, 1, 4)), zPortID
            Case "MAGI", "MF"
                subSystemReportStatsMagicFind UCase(Mid(zType, 1, 4)), zPortID
            Case "BASE"
                subSystemReportStatsBaseMagicFind UCase(Mid(zType, 1, 4)), zPortID
            Case Else
                If (MyCLng(Format(Now(), "yyyy")) < 2040) Then
                    subSendMsg "&gPAGE DONATIONS       - HELP PAYPAL - I will help you build your in game house.", zPortID
                    subSendMsg "&g                     - This message was updated: " & Format(Now(), "yyyy"), zPortID
                    subSendMsg "&g                     - This message remains until the year 2040.", zPortID
                End If
                If (gblbPageLastOkay) Then subSendMsg "&gPAGE LAST            - shows you the last few people that logged in", zPortID
                subSendMsg "&gPAGE ARMAGEDDON      - ARMA command, shows you the quest's current state.", zPortID
                subSendMsg "&gPAGE PK              - shows top best player killers", zPortID
                subSendMsg "&gPAGE SKILLS          - shows you where the hidden power skills are", zPortID
                subSendMsg "&gPAGE DEATHS          - lists who doesn't die.", zPortID
                subSendMsg "&gPAGE QUEST           - will show you your last quest", zPortID
                subSendMsg "&gPAGE BUSY            - shows you which hours people log in the most", zPortID
                subSendMsg "&gPAGE WEEK/REALM      - shows you which days are most popular", zPortID
                subSendMsg "&gPAGE COLONISTS       - shows you how the spacewar is going"
                subSendMsg "&gPAGE CONTROL         - shows you how many worlds are owned."
                subSendMsg "&gPAGE NEUTRAL         - shows you how many primitive worlds still exist."
                subSendMsg "&gPAGE STARSHIPS       - shows you who owns the best starship.", zPortID
                subSendMsg "&gPAGE CHESTS          - shows you were some thief's chests are hidden", zPortID
                subSendMsg "&gPAGE MERCHANTS       - Shows you what merchants carry in all cities.", zPortID
                subSendMsg "&gPAGE MAGIC FIND/BASE", zPortID
                subSendMsg "&gPAGE CLASS/RACE/CLAN/LEVEL/HITROLL/DAMAGEROLL/AC/SLAY/IAS", zPortID
                subSendMsg "&gPAGE ALL STATS       - reports all players stats", zPortID
                subSendMsg "&gPAGE COMPONENTS      - Reveals all your spells components", zPortID
                subSendMsg "&gPAGE LOST            - Finds Cursed items that (ZAP!) off you during combat", zPortID
                'subSendMsg "&gPAGE FACTIONS    - see who is winning, who to join", zPortID
        End Select
    Else
        subSendMsg "&APL:" & gblcstlPlayerLevelToWHOPAGELAST & ": You are not powerful enough to do that yet.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerReports," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subReportCharacterSheet(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lStatus As Long
    Dim lTurnedIntoAnimalType As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCHP As Long
    Dim lOHP As Long
    Dim lCMana As Long
    Dim lOMANA As Long
    Dim lCEssence As Long
    Dim lOEssence As Long
    Dim lCSoul As Long
    Dim lOSoul As Long
    Dim lCMove As Long
    Dim lOMove As Long
    Dim lSleepDuration As Long
    Dim lStunDuration As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT StunDuration, SleepDuration, X, Y, Z, PlayerLevel, PlayerName, TurnedIntoAnimalType, Status, CHP, OHP, CMana, OMana, CEssence, OEssence, CSoul, OSoul, CMove, OMove FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lCHP = MyCLng(rsPlayer!CHP)
        lOHP = MyCLng(rsPlayer!OHP)
        lCMana = MyCLng(rsPlayer!CMana)
        lOMANA = MyCLng(rsPlayer!OMANA)
        lCEssence = MyCLng(rsPlayer!CEssence)
        lOEssence = MyCLng(rsPlayer!OEssence)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lOSoul = MyCLng(rsPlayer!OSoul)
        lCMove = MyCLng(rsPlayer!CMove)
        lOMove = MyCLng(rsPlayer!OMove)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
    End If
    Set rsPlayer = Nothing
    
    If (lSleepDuration = 0) Then
        If (lStunDuration = 0) Then
            If (lStatus <> 50) Then
                If (lTurnedIntoAnimalType = 0) Then
                    subSendMsgAreaAll "&B^&g" & zPlayerName & "<" & lPlayerLevel & "> H" & lCHP & "/" & lOHP & " M" & lCMana & "/" & lOMANA & " E" & lCEssence & "/" & lOEssence & " S" & lCSoul & "/" & lOSoul & " M" & lCMove & "/" & lOMove, lX, lY, lZ
                Else
                    subSendMsgAreaAll "&B^&g" & zPlayerName & "<" & lPlayerLevel & "> [" & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & "]", lX, lY, lZ
                End If
            Else
                subSendMsg "&gYou dream of reports and schedules.", lX, lY, lZ, zPortID
            End If
        Else
            subSendMsg "&rYou dream about your stunning looks.", lX, lY, lZ, zPortID
        End If
    Else
        subSendMsg "&rYou dream about waking up from this nightmare.", lX, lY, lZ, zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subReportCharacterSheet," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subReportCharacterSheetNAME(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lStatus As Long
    Dim lTurnedIntoAnimalType As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCHP As Long
    Dim lOHP As Long
    Dim lCMana As Long
    Dim lOMANA As Long
    Dim lCEssence As Long
    Dim lOEssence As Long
    Dim lCSoul As Long
    Dim lOSoul As Long
    Dim lCMove As Long
    Dim lOMove As Long
    Dim lSleepDuration As Long
    Dim lStunDuration As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT StunDuration, SleepDuration, X, Y, Z, PlayerLevel, PlayerName, TurnedIntoAnimalType, Status, CHP, OHP, CMana, OMana, CEssence, OEssence, CSoul, OSoul, CMove, OMove FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lCHP = MyCLng(rsPlayer!CHP)
        lOHP = MyCLng(rsPlayer!OHP)
        lCMana = MyCLng(rsPlayer!CMana)
        lOMANA = MyCLng(rsPlayer!OMANA)
        lCEssence = MyCLng(rsPlayer!CEssence)
        lOEssence = MyCLng(rsPlayer!OEssence)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lOSoul = MyCLng(rsPlayer!OSoul)
        lCMove = MyCLng(rsPlayer!CMove)
        lOMove = MyCLng(rsPlayer!OMove)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
    End If
    Set rsPlayer = Nothing
    
    If (lSleepDuration = 0) Then
        If (lStunDuration = 0) Then
            If (lStatus <> 50) Then
                If (lTurnedIntoAnimalType = 0) Then
                    subSendMsg "&C^^&g" & zPlayerName & "<" & lPlayerLevel & "> H" & lCHP & "/" & lOHP & " M" & lCMana & "/" & lOMANA & " E" & lCEssence & "/" & lOEssence & " S" & lCSoul & "/" & lOSoul & " M" & lCMove & "/" & lOMove, zPortID
                Else
                    subSendMsg "&C^^&g" & zPlayerName & "<" & lPlayerLevel & "> [" & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & "]", zPortID
                End If
            Else
                subSendMsg "&gYou dream of reports and schedules.", zPortID
            End If
        Else
            subSendMsg "&rYou dream about your stunning looks.", zPortID
        End If
    Else
        subSendMsg "&rYou dream about waking up from this nightmare.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subReportCharacterSheetNAME," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerDAYNIGHTDESCQuick(zPortID As String)
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim rsPlayer As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zADD As String
    Dim zADN As String
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT X,Y,Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        Set rsArea = MyDB.OpenRecordset("SELECT AreaDescDay, AreaDescNight FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
        If (Not rsArea.EOF) Then
            zADD = MyCStr(rsArea!AreaDescDay)
            zADN = MyCStr(rsArea!AreaDescNight)
        End If
        Set rsArea = Nothing
        
        If (zADD = zADN) Then
            'doesnt matter which one is shown
            subSendMsg "&B|^|" & vbCrLf & zADD & vbCrLf & "&B|^|", zPortID
        Else
            subSendMsg "&B|^^|" & vbCrLf & zADD & vbCrLf & zADN & vbCrLf & "&B|^^|", zPortID
        End If
        
    End If
    Set rsPlayer = Nothing

    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerDAYNIGHTDESCQuick," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerExitsQuicks(zPortID As String)
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim rsPlayer As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zHiddenExits As String
    Dim zBlockedExits As String
    Dim zLookExits As String
    Dim zLookDesc As String
    Set rsPlayer = MyDB.OpenRecordset("SELECT X,Y,Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        zLookExits = zShowExits(lX, lY, lZ)
        If (Len(zLookExits) > 0) Then subSendMsg "&w" & zLookExits, zPortID
        Set rsArea = MyDB.OpenRecordset("SELECT HiddenExits,BlockedExits FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
        If (Not rsArea.EOF) Then
            zHiddenExits = MyCStr(rsArea!HiddenExits)
            zBlockedExits = MyCStr(rsArea!BlockedExits)
        End If
        Set rsArea = Nothing
        zLookDesc = zAreaShowDoors(zHiddenExits, zBlockedExits, lX, lY, lZ) 'doors have to be dynamic because they open and close a lot
        If (Len(zLookDesc) > 0) Then subSendMsg zLookDesc, zPortID
    End If
    Set rsPlayer = Nothing

    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerExitsQuicks," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerWhoIS(zSearchPlayerName As String, zPromptOriginal As String, zPortID As String)
On Error GoTo Err_Check
    Dim zCompareIP As String
    Dim zPlayerStatus As String
    Dim rsPlayer As Recordset
    Dim lDaysLapse As Long
    Dim lPlayerID As Long
    Dim lHoldPlayerID As Long
    Dim zHoldCompareIP As String
    Dim zBanned As String
    Dim zIPMatch As String
    Dim lRC As Long
    Dim zSearchIP As String
    Dim bSearchViaIP As Boolean
    Dim zSQL As String
    Dim zPlayerNeverBan As String
    Dim lOriginalPlayerID As Long
    Dim lImmortalLevel As Long
        
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, ImmortalLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lOriginalPlayerID = MyCStr(rsPlayer!PlayerID)
        lImmortalLevel = MyCStr(rsPlayer!ImmortalLevel)
    End If
    Set rsPlayer = Nothing

    zSearchIP = zAntiSQLCrash(zPromptOriginal)
    bSearchViaIP = False
    If (InStr(zSearchIP, " ") <> 0) Then 'strip first word
        zSearchIP = Mid(zSearchIP, InStr(zSearchIP, " ") + 1) 'we get only the ip
        bSearchViaIP = (InStr(zSearchIP, ".") > 0 And lImmortalLevel >= 90)
    End If
    
    lPlayerID = 0
    If (Not bSearchViaIP) Then
        If (Len(zSearchPlayerName) <> 0) Then
            zSQL = "SELECT Password, ClanID, ClanMemberLevel, PlayerID, CSTR, CINT, CWIS, CDEX, CCON, CCHA, CLUC, PlayerName, Class, BittenReservedOriginalClass, Gender, PlayerLevel, NumAttRnd, ImmortalSupervisor, SilencedDate, LastPlayed, Entered, MobKills, SlayKills, DeathsToMobs, DeathsToPlayers, MurderPKills, RoomTitle, Race, Title, PlayerDesc, Weight, Height FROM tblPlayer WHERE (ImmortalLevel = 0 AND PlayerName='" & zAntiSQLCrash(zSearchPlayerName) & "');"
        Else 'whois self
            zSQL = "SELECT Password, ClanID, ClanMemberLevel, PlayerID, CSTR, CINT, CWIS, CDEX, CCON, CCHA, CLUC, PlayerName, Class, BittenReservedOriginalClass, Gender, PlayerLevel, NumAttRnd, ImmortalSupervisor, SilencedDate, LastPlayed, Entered, MobKills, SlayKills, DeathsToMobs, DeathsToPlayers, MurderPKills, RoomTitle, Race, Title, PlayerDesc, Weight, Height FROM tblPlayer WHERE (PlayerID=" & lOriginalPlayerID & ");"
        End If
        Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lDaysLapse = DateDiff("d", Format(MyCStr(rsPlayer!LastPlayed), "mmm dd, yyyy"), Format(Now(), "mmm dd, yyyy"))
            
            subTitleBar "W H O I S", zPortID
            If (lImmortalLevel >= 90) Then subSendMsg "&gIL90: ID#" & lPlayerID, zPortID
            subSendMsg gblzFNGRE & MyCStr(MyCStr(rsPlayer!RoomTitle) & " " & MyCStr(rsPlayer!PlayerName)) & vbCrLf & "&a" & (MyCStr(rsPlayer!Title)), zPortID
            'If (lImmortalLevel >= 99) Then subSendMsg "&gIL99: Password: " & MyCStr(rsPlayer!Password), zPortID
            If (MyCLng(rsPlayer!ClanID) <> 0) Then subSendMsg zReturnClanName(lPlayerID) & " " & MyCStr(zTranslateMortalClanRanks(MyCLng(rsPlayer!ClanMemberLevel))), zPortID
            subSendMsg gblzFNYEL & (MyCStr(rsPlayer!PlayerDesc)), zPortID
            subSendMsg "&w" & zTranslateGender(MyCStr(rsPlayer!Gender), 50) & " is " & zAdverb(zTranslateRace(MyCStr(rsPlayer!Race)), 3) & zTranslateRace(MyCStr(rsPlayer!Race)) & " and studies the path of " & zAdverb(zTranslateClass(MyCStr(rsPlayer!Class)), 3) & zTranslateClass(MyCStr(rsPlayer!Class)), zPortID
            If (MyCStr(rsPlayer!BittenReservedOriginalClass) <> MyCStr(rsPlayer!Class)) Then subSendMsg "&yoriginal class " & zTranslateClass(MyCStr(rsPlayer!BittenReservedOriginalClass)), zPortID
            subSendMsg "&w         level " & strForceSize(MyCLng(rsPlayer!PlayerLevel), 13, " ", "A"), zPortID
            subSendMsg "&w        height " & Format((MyCLng(rsPlayer!Height) / glblCentimetreToFeetConverter), "FIXED") & " feet tall", zPortID
            'subSendMsg "&w"  & "       entered " & Format(MyCStr(rsPlayer!Entered), "mmm dd, yyyy"), zPortID
            'subSendMsg "&w"  & "   last played " & Format(MyCStr(rsPlayer!LastPlayed), "mmm dd, yyyy hh:nn"), zPortID
            'subSendMsg "&w"  & "  houses owned " & lReturnAreaTypeOwned(lPlayerID, 1), zPortID
            'subSendMsg "&w"  & "starship owned " & basBoolean(lReturnAreaTypeOwned(lPlayerID, 2) > 0), zPortID
            If (gblbLastPlayedActive) Then
                Select Case ((lDaysLapse - (MyCLng(rsPlayer!PlayerLevel) * cstlNukeMAX)) >= 0)
                    Case True 'player has expired and will be deleted as soon as the mud is left up running!
                        subSendMsg "&R     *EXPIRING ACCOUNT*", zPortID
                    Case Else 'the player has days left till delete
                        subSendMsg "&W     safe days " & Abs(lDaysLapse - (MyCLng(rsPlayer!PlayerLevel) * cstlNukeMAX)) & " or " & Format(Abs(lDaysLapse - (MyCLng(rsPlayer!PlayerLevel) * cstlNukeMAX)) / 365, "FIXED") & " years.", zPortID
                End Select
            End If
        Else
            subSendMsg "&gPlayer name [excludes immortals] not found in the realm.", zPortID
        End If
        Set rsPlayer = Nothing
        
        If (lImmortalLevel >= 4 And lPlayerID <> 0) Then 'demi-gods can whois ips
            subSendMsg "&r(immortal eye 4+) Search Active Trail Annex Numbers" & "&g", zPortID
            'Search Active Trail Annex Numbers
            zPlayerStatus = ""
            lRC = lngSQLRecordCount("SELECT PlayerID FROM tblPlayerRemoteHost WHERE (PlayerID=" & lPlayerID & ");")
            If (lRC < 1) Then lRC = 1
            zSQL = "SELECT TOP " & lRandom(lRC) & " tblPlayer.PlayerID, tblPlayerLoggedIn.RemoteHostID, tblPlayerRemoteHost.Matches FROM (tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PlayerName = tblPlayerLoggedIn.PlayerName) INNER JOIN tblPlayerRemoteHost ON tblPlayer.PlayerID = tblPlayerRemoteHost.PlayerID WHERE (((tblPlayer.PlayerID)=" & lPlayerID & ")) ORDER BY tblPlayerRemoteHost.Matches;"
            zCompareIP = ""
            Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                rsPlayer.MoveLast
                zPlayerStatus = "On-line"
                zCompareIP = MyCStr(rsPlayer!RemoteHostID)
            End If
            Set rsPlayer = Nothing
            
            If (Len(zCompareIP) = 0) Then 'player may be offline
                zPlayerStatus = "Offline"
                zCompareIP = ""
                Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lRC) & " tblPlayerRemoteHost.PlayerID, tblPlayerRemoteHost.RemoteHostID FROM tblPlayerRemoteHost WHERE (((tblPlayerRemoteHost.PlayerID)=" & lPlayerID & ")) ORDER BY tblPlayerRemoteHost.Matches;", dbOpenSnapshot)
                If (Not rsPlayer.EOF) Then
                    rsPlayer.MoveLast
                    zCompareIP = MyCStr(rsPlayer!RemoteHostID)
                End If
                Set rsPlayer = Nothing
            End If
            
            If (Len(zCompareIP) <> 0) Then
                zHoldCompareIP = zCompareIP
                zHoldCompareIP = Mid(zHoldCompareIP, 1, lInStrOccurance(zHoldCompareIP, ".", 2))
                Set rsPlayer = MyDB.OpenRecordset("SELECT tblPlayerRemoteHost.BannedIP, tblPlayer.PlayerID, tblPlayer.PlayerName, tblPlayerRemoteHost.RemoteHostID, tblPlayerRemoteHost.Matches FROM tblPlayer INNER JOIN tblPlayerRemoteHost ON tblPlayer.PlayerID = tblPlayerRemoteHost.PlayerID WHERE (((tblPlayerRemoteHost.RemoteHostID) Like """ & zHoldCompareIP & "*"")) ORDER BY tblPlayer.PlayerID, tblPlayerRemoteHost.BannedIP, tblPlayerRemoteHost.Matches DESC, tblPlayerRemoteHost.RemoteHostID, tblPlayer.PlayerName;", dbOpenSnapshot)
                If (Not rsPlayer.EOF) Then
                    subSendMsg "Player " & zPlayerStatus & " IP search >|" & strForceSize(zCompareIP, 20, " ", "A") & "| searching by -> " & zHoldCompareIP, zPortID
                    lHoldPlayerID = 0
                    
                    Do While (Not rsPlayer.EOF)
                        lPlayerID = MyCLng(rsPlayer!PlayerID)
                        
                        If (lPlayerID <> lHoldPlayerID) Then
                            lHoldPlayerID = lPlayerID 'adds some speed to the search
                            If (bPlayerNeverBanned(lPlayerID)) Then
                                zPlayerNeverBan = "N"
                            Else
                                zPlayerNeverBan = " "
                            End If
                        End If
                        
                        zBanned = " "
                        zIPMatch = " "
                        
                        If (MyCInt(rsPlayer!BannedIP) <> 0) Then zBanned = "B"
                        If (UCase(zCompareIP) = UCase(MyCStr(rsPlayer!RemoteHostID))) Then zIPMatch = "+"
                        
                        subSendMsg zBanned & zPlayerNeverBan & zIPMatch & strForceSize(MyCStr(rsPlayer!PlayerName), 24, " ", "A") & " " & strForceSize(MyCStr(rsPlayer!RemoteHostID), 20, " ", "A") & " - this ip was used " & MyCLng(rsPlayer!Matches) & " times.", zPortID
                        rsPlayer.MoveNext
                    Loop
                End If
                Set rsPlayer = Nothing
            Else
                subSendMsg "No IPs found.", zPortID
            End If
        End If
    Else
        'Reverse of: Search Active Trail Annex Numbers
        subSendMsg "&r(EYE) Reverse Directory" & "&g", zPortID
        zPlayerStatus = ""
        lRC = lngSQLRecordCount("SELECT PlayerID FROM tblPlayerRemoteHost WHERE (RemoteHostID Like """ & zSearchIP & "*"");")
        If (lRC < 1) Then lRC = 1
        If (lRC <= 50) Then
            zSQL = "SELECT tblPlayer.PlayerName, tblPlayerRemoteHost.RemoteHostID, tblPlayerRemoteHost.Matches FROM tblPlayerRemoteHost INNER JOIN tblPlayer ON tblPlayerRemoteHost.PlayerID = tblPlayer.PlayerID WHERE (((tblPlayerRemoteHost.RemoteHostID) Like """ & zSearchIP & "*"")) ORDER BY tblPlayer.PlayerName, tblPlayerRemoteHost.Matches DESC;"
        Else
            zSQL = "SELECT TOP 50 tblPlayer.PlayerName, tblPlayerRemoteHost.RemoteHostID, tblPlayerRemoteHost.Matches FROM tblPlayerRemoteHost INNER JOIN tblPlayer ON tblPlayerRemoteHost.PlayerID = tblPlayer.PlayerID WHERE (((tblPlayerRemoteHost.RemoteHostID) Like """ & zSearchIP & "*"")) ORDER BY tblPlayer.PlayerName, tblPlayerRemoteHost.Matches DESC;"
        End If
        
        zCompareIP = ""
        Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsPlayer.EOF)
            subSendMsg "  " & strForceSize(MyCStr(rsPlayer!PlayerName), 24, " ", "A") & " " & strForceSize(MyCStr(rsPlayer!RemoteHostID), 20, " ", "A") & " - this ip was used " & MyCLng(rsPlayer!Matches) & " times.", zPortID
            rsPlayer.MoveNext
        Loop
        Set rsPlayer = Nothing
        
        If (lRC > 50) Then
            subSendMsg lRC & " total results, some not shown.", zPortID
        End If
        
        subSendMsg "&r(EYE) Reverse Directory - Complete Ban" & "&g", zPortID
        'now search complete ban
        zCompareIP = ""
        Set rsPlayer = MyDB.OpenRecordset("SELECT RemoteHostIP, LastAttempt, BadPersonPoints FROM tblPlayerRemoteHostCompletelyBanned WHERE (RemoteHostIP Like """ & zSearchIP & "*"") ORDER BY LastAttempt DESC, BadPersonPoints DESC, RemoteHostIP;", dbOpenSnapshot)
        Do While (Not rsPlayer.EOF)
            subSendMsg "  " & strForceSize(MyCStr(rsPlayer!RemoteHostIP), 15, " ", "A") & " " & Format(MyCStr(rsPlayer!LastAttempt), "mmm dd, yyyy hh:nn:ss") & " BPPts: " & MyCStr(rsPlayer!BadPersonPoints), zPortID
            rsPlayer.MoveNext
        Loop
        Set rsPlayer = Nothing
        
        If (lRC > 50) Then
            subSendMsg lRC & " total results, some not shown.", zPortID
        End If
    End If
    
    'We now Search for password matches
    If (lImmortalLevel >= 4 And Len(zKeepLettersOnly(zSearchIP)) > 0) Then
        'Match Password Search
        zSQL = "SELECT PlayerName FROM tblPlayer WHERE Password='" & zKeepLettersOnly(zSearchIP) & "' ORDER BY PlayerName;"
        Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            subSendMsg "&r(immortal eye 4+) PASSWORD MATCHING - Possible Other Player Names" & "&g", zPortID
            Do While (Not rsPlayer.EOF)
                subSendMsg MyCStr(rsPlayer!PlayerName), zPortID
                rsPlayer.MoveNext
            Loop
        End If
        Set rsPlayer = Nothing
    End If

    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerWhoIS," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
    'FreeLocks
End Sub
