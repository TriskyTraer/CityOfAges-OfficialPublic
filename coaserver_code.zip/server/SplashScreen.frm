VERSION 5.00
Begin VB.Form frmSplashScreen 
   Appearance      =   0  'Flat
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   0  'None
   Caption         =   "City of Ages"
   ClientHeight    =   7035
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   5145
   ControlBox      =   0   'False
   DrawMode        =   16  'Merge Pen
   BeginProperty Font 
      Name            =   "Arial"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "SplashScreen.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   Picture         =   "SplashScreen.frx":0442
   ScaleHeight     =   463.472
   ScaleMode       =   0  'User
   ScaleWidth      =   345.392
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picPentagramCntDn 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   5
      Left            =   720
      Picture         =   "SplashScreen.frx":76B34
      ScaleHeight     =   3585
      ScaleWidth      =   3585
      TabIndex        =   6
      Top             =   3360
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.PictureBox picPentagramCntDn 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   4
      Left            =   720
      Picture         =   "SplashScreen.frx":A2802
      ScaleHeight     =   3585
      ScaleWidth      =   3585
      TabIndex        =   5
      Top             =   3360
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.PictureBox picPentagramCntDn 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   3
      Left            =   720
      Picture         =   "SplashScreen.frx":CDF18
      ScaleHeight     =   3585
      ScaleWidth      =   3585
      TabIndex        =   4
      Top             =   3360
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.PictureBox picPentagramCntDn 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   2
      Left            =   720
      Picture         =   "SplashScreen.frx":F962E
      ScaleHeight     =   3585
      ScaleWidth      =   3585
      TabIndex        =   3
      Top             =   3360
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.PictureBox picPentagramCntDn 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   1
      Left            =   720
      Picture         =   "SplashScreen.frx":124D44
      ScaleHeight     =   3585
      ScaleWidth      =   3585
      TabIndex        =   2
      Top             =   3360
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.PictureBox picPentagramCntDn 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   3615
      Index           =   0
      Left            =   720
      Picture         =   "SplashScreen.frx":15045A
      ScaleHeight     =   3585
      ScaleWidth      =   3585
      TabIndex        =   1
      Top             =   3360
      Visible         =   0   'False
      Width           =   3615
   End
   Begin VB.Timer tmrAutoClose 
      Left            =   120
      Top             =   0
   End
   Begin VB.CommandButton cmdClose 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      Height          =   255
      Left            =   0
      MaskColor       =   &H000000FF&
      Picture         =   "SplashScreen.frx":17AE30
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   0
      Width           =   495
   End
End
Attribute VB_Name = "frmSplashScreen"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Dim gbllCount As Long
Private Sub basExit()
On Error GoTo Err_Check
    subCoAClientLoad
    tmrAutoClose.Interval = 0
    Unload frmSplashScreen
    mdiMainMenu.Show
    Exit Sub
Err_Check:
    basHelpMessage64 "SPLASH SCREEN ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub cmdClose_Click()
    End
End Sub

Private Sub Form_Click()
On Error Resume Next
    If (tmrAutoClose.Interval <> 0) Then
        basExit
        'basAdminFollowText "SYSTEM UP: " & Format(Date, "mmm dd, yyyy") & " TIME: " & Format(Time(), "HH:NN")
    Else
        Beep
    End If
End Sub
Private Sub Form_Load()
On Error Resume Next
    Dim iCount As Integer
    gbllWearItemMAX = 20
    If (App.PrevInstance) Then
        MsgBox "MUD Realm: This application is already running..."
        End
    End If
    
    gblbBullCowValueDigitReuseAllowed = False
    gblzBullsCowsSecretNumber = ""
    For iCount = cstlMinPort To cstlMaxPort
        gblbLineFeed(iCount) = False
    Next iCount
    tmrAutoClose.Interval = 0
    DoEvents
    subCompactNRepair 0
    DoEvents
    basStoreMDBLocationToMemory ' Load MDB location to memory plus show error messages.
    DoEvents
    gblConstructorlMode = 1
    gblbLastPlayedActive = False
    
    'Quest mobs can give special items
    gbllLoadRandomGivesObjectID = 0
    gblzLoadRandomGivesObjectID = ""
    'MOON
    gbllMoon = 0
    gblbAllowAutoRebooting = False
    'REALM QUEST [cstzRealmQuestTitle] INTIIALIZE ALL
    gbllREALMQuestArmageddonKillThisManyCreatures = 0
    gbllREALMQuestArmageddonTicksAllowed = 0
    gbllREALMQuestArmageddonPayOff = 0
    
    gbllDEATHX = 0: gbllDEATHY = 0: gbllDEATHZ = 0 'lingers and pulsates from 1 to 9 around this spot draining random stats
    
    gbllCount = 10
    gblbMatchingAllowed = False
    gblbTiming = False
    gbllSpeakControlMax = 900
    gblbServerWillBeRightBack = False 'we start the server running and operational mode
    gblbAutoActivateAllListentingPorts = False
    gbllRaceFeet = -1 'we check to see if a horse racing is running
    gblbRaceBeginning = False
    gbllRouletteGo = -1 'we check to see if roulette was running

    gblzImmortalEmail = zSystemConfig(2)
    gblzImmortalName1 = zSystemConfig(35)
    gblzImmortalName2 = zSystemConfig(36)
    gblzImmortalName3 = zSystemConfig(37)
    gblzImmortalName4 = zSystemConfig(38)
    gblzMUDHomePageURL = zSystemConfig(20)
    gblzMUDName = zSystemConfig(27)
    gblzFTPServerURL = zSystemConfig(28) '= "www3.telus.net/public_html"
    gblzFTPUserName = zSystemConfig(29) '= "Traer"
    gblzFTPUserPassword = zSystemConfig(30) '= "xagua302"
    gblzFTPServerDirectory = zSystemConfig(31) '= "public_html/"
    gbllFTPProxyServer = MyCLng(zSystemConfig(32))
    gbllHTTPProxyServer = MyCLng(zSystemConfig(33))
    gbllTelnetProxyServer = MyCLng(zSystemConfig(34))
    gblzMUDTelnetURL = zSystemConfig(99)
    
    frmPort23.bUnload = True
    frmDTPortAlternate2.bUnload = True
    frmDTPortAlternate1.bUnload = True
    gblbHarassANearbyRandomPlayerMS = False
    DoEvents
    subArcadeInit
    DoEvents
    subClearArmageddonKillCount
    gbllEarthQuake = 0
    subLoadAreaDescExits
    subEnforceBeamableRules
    subLoadCardDeck "^"
    subInitializeDurations
    tmrAutoClose.Interval = 1000
    gblbUseMemoryExits = False
End Sub
Private Sub Form_LostFocus()
    basExit
End Sub
Private Sub Form_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
On Error Resume Next
    If (Button = 2) Then
        basExit
    End If
End Sub
Private Sub lblADSURL_Click()
    basGOTOADSURL
End Sub
Private Sub lblFeatures_Click(Index As Integer)
    basExit
End Sub
Private Sub lblHowToExit_Click()
    basExit
End Sub
Private Sub lblSite_Click(Index As Integer)
    basExit
End Sub
Private Sub lblTitle_Click(Index As Integer)
    basExit
End Sub

Private Sub tmrAutoClose_Timer()
On Error Resume Next
    gblbServerWillBeRightBack = False
    'This is just to autolaunch the application so we can use batch files to run it
    gbllCount = gbllCount - 1
    Select Case (gbllCount)
        Case 0
            Form_Click
            'gblbAutoActivateAllListentingPorts = True
        Case 1 To 6
            picPentagramCntDn(0).Visible = False
            picPentagramCntDn(1).Visible = False
            picPentagramCntDn(2).Visible = False
            picPentagramCntDn(3).Visible = False
            picPentagramCntDn(4).Visible = False
            picPentagramCntDn(5).Visible = False
            picPentagramCntDn(gbllCount - 1).Visible = True
    End Select
End Sub

