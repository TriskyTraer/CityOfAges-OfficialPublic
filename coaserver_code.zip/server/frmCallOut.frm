VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmCallOut 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Calling..."
   ClientHeight    =   150
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   900
   ControlBox      =   0   'False
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   150
   ScaleWidth      =   900
   Begin VB.Timer tmrCallOut 
      Interval        =   2000
      Left            =   0
      Top             =   0
   End
   Begin MSWinsockLib.Winsock wsCallOut 
      Left            =   0
      Top             =   360
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      RemoteHost      =   "coa.servegame.com"
      RemotePort      =   23
      LocalPort       =   9999
   End
End
Attribute VB_Name = "frmCallOut"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public lCount As Long
Private Sub Form_Load()
On Error Resume Next
    lCount = 0
End Sub
Private Sub tmrCallOut_Timer()
'On Error Resume Next
    tmrCallOut.Interval = 0
    lCount = lCount + 1
    Select Case lCount
        Case 0
            tmrCallOut.Interval = 3000
        Case 1
            If (wsCallOut.State <> sckClosed) Then
                wsCallOut.Close
                basDelay 1000
            End If
            
            If (wsCallOut.State <> sckConnected) Then
                wsCallOut.RemoteHost = "coa.servegame.com"
                wsCallOut.RemotePort = 23
                wsCallOut.Connect
            End If
            tmrCallOut.Interval = 3000
        Case 2
            If (wsCallOut.State = sckConnected) Then
                wsCallOut.SendData gblcstzDetectCode & wsCallOut.LocalIP & "/" & wsCallOut.LocalPort & "/" & Format(Now(), "mmmddyyyy hh:nn:ss") & vbCrLf
                wsCallOut.SendData vbCrLf
            End If
            tmrCallOut.Interval = 3000
        Case 3
            If (wsCallOut.State = sckConnected) Then wsCallOut.Close
            tmrCallOut.Interval = 3000
        Case Else
            lCount = 0
            tmrCallOut.Interval = 0
            Unload frmCallOut
    End Select
End Sub
