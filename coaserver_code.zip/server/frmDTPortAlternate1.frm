VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmDTPortAlternate1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Watch"
   ClientHeight    =   930
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   1410
   Icon            =   "frmDTPortAlternate1.frx":0000
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   930
   ScaleWidth      =   1410
   Begin VB.TextBox txtLocalIP 
      Alignment       =   2  'Center
      BackColor       =   &H80000018&
      Height          =   285
      Left            =   0
      TabIndex        =   3
      Text            =   "000.000.000.000"
      Top             =   720
      Width           =   1455
   End
   Begin VB.CommandButton cmdResetPort 
      Caption         =   "reset port"
      Height          =   195
      Left            =   0
      TabIndex        =   2
      TabStop         =   0   'False
      Top             =   540
      Width           =   1455
   End
   Begin MSWinsockLib.Winsock ctlServer 
      Left            =   0
      Top             =   0
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
      LocalPort       =   1234
   End
   Begin VB.Label lblRemoteHost 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00C000C0&
      Height          =   255
      Left            =   0
      TabIndex        =   1
      Top             =   240
      Width           =   1575
   End
   Begin VB.Label lblMsg 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H000080FF&
      Caption         =   "XXXX"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   735
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   1455
   End
End
Attribute VB_Name = "frmDTPortAlternate1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Public bUnload As Boolean
Public gbllTimeOuts As Long
Public gblzOUserInput As String
Public gbliOUserInput As Integer
Public gblzMode As String


Private Sub cmdResetPort_Click()
    Form_Load
End Sub
'Ports unavailable to users: 21,23,443, 4000 ,25,110,70,80,6667
Private Sub Form_Load()
On Error GoTo Err_Check
    gbllDynamicPortID1 = zSystemConfig(101)
    
    Me.bUnload = False
    If (Me.ctlServer.State <> sckClosed) Then Me.ctlServer.Close
    Me.lblMsg.Caption = MyCStr(gbllDynamicPortID1)
    DoEvents 'a must here to update the form variable
    gblzMode = ""
    DoEvents
    Me.Caption = "p" & MyCStr(gbllDynamicPortID1)
    Me.lblMsg.ForeColor = 0
    DoEvents
    Me.ctlServer.LocalPort = gbllDynamicPortID1 'set telnet port
    DoEvents
    Me.ctlServer.Listen 'Listen for the user to connect to this port
    DoEvents
    Me.txtLocalIP.Text = Me.ctlServer.LocalIP
    DoEvents
    Exit Sub
Err_Check:
    'subWriteErrorFile "Form_Load p" & gbllDynamicPortID1 & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error GoTo Err_Check
    DoEvents
    If (Me.ctlServer.State <> sckClosed) Then Me.ctlServer.Close
    Me.lblMsg.ForeColor = 0
    Me.Caption = "p" & gbllDynamicPortID1
    bUnload = True
    Exit Sub
Err_Check:
    'subWriteErrorFile "Form_Unload p" & gbllDynamicPortID1 & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub
Private Sub ctlServer_ConnectionRequest(ByVal lRequestID As Long)
On Error GoTo Err_Check
    Dim iGetValue As Integer
    Dim zRemoteHostIP As String
    zRemoteHostIP = Me.ctlServer.RemoteHostIP
    'user online port gbllDynamicPortID1 - listen mode was successful
    Me.lblMsg.ForeColor = &H8000&
    Me.Caption = "p+" & gbllDynamicPortID1
    DoEvents
    'We need to pass the port to another port.
    If (Not gblbServerWillBeRightBack) Then
        'We need to pass the port to another port.
        iGetValue = iAssignPort(lRequestID, zRemoteHostIP)
    Else
        iGetValue = -9
    End If
    If (iGetValue < 1) Then
        Me.Caption = "p" & gbllDynamicPortID1 'user offline
        Me.lblMsg.ForeColor = 255     'Failed
        If (Me.ctlServer.State <> sckClosed) Then Me.ctlServer.Close
        DoEvents
        Me.ctlServer.Accept lRequestID
        DoEvents
        Select Case iGetValue
            Case 0
                Me.ctlServer.SendData gblzFBYEL & gblzMUDName & vbCrLf & "All ports are full or resetting. Try again later! Thanks!" & vbCrLf & "If this persists for you, EMail: " & zSystemConfig(2) & vbCrLf & vbCrLf & gblzFBYEL & "THANKS - STAFF"
            Case -1
                Me.ctlServer.SendData gblzFBYEL & gblzMUDName & vbCrLf & "&RYour IP " & zRemoteHostIP & " is already in use!" & vbCrLf & "Disconnecting..."
            Case -9
                Me.ctlServer.SendData gblzFBYEL & gblzMUDName & " is currently performing a system clean up." & vbCrLf & "The realm will be back up in a few hours." & vbCrLf & "&R" & vbCrLf & "Disconnecting..."
            Case Else
                Me.ctlServer.SendData gblzFBYEL & gblzMUDName & vbCrLf & "No ports are available! Try again later! Thanks!" & vbCrLf & "If this persists for you, EMail: " & zSystemConfig(2) & vbCrLf & vbCrLf & gblzFBYEL & "THANKS - STAFF"
        End Select
        DoEvents
        Me.ctlServer.SendData vbCrLf
        Me.ctlServer.SendData "&aNOTE: In all cases the system resets at 9:30am each day."
        Me.ctlServer.SendData vbCrLf
        DoEvents
        Unload Me
    Else
        Me.Caption = "p" & gbllDynamicPortID1 'go back to listening
        Me.lblMsg.ForeColor = 0
    End If
    Exit Sub
Err_Check:
    'subWriteErrorFile "ctlServer_ConnectionRequest p" & gbllDynamicPortID1 & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub

Private Sub txtLocalIP_LostFocus()
On Error GoTo Err_Check
    Me.txtLocalIP.Text = Me.ctlServer.LocalIP
    Exit Sub
Err_Check:
    subWriteErrorFile "txtLocalIP_LostFocus p" & gbllDynamicPortID1 & ", ERROR #" & Err.Number & "-" & Err.Description
    Unload Me
End Sub
