Attribute VB_Name = "modHardcodedModules"
Option Explicit 'if you add global port variables add them to subClearLoginPort(zPortID As String)
Public Const cstlMinPort = 2011 'KEEP the port range at the top of this document
Public Const cstlMaxPort = 2057 'change this when you add more ports Win98 can handle 2-0-1-1 to 2-0-5-7 - XP can handle 2011 to 2045
Public gblzFNBLA As String ' Chr(27) & "[1;30m"
Public gblzFNRED As String ' Chr(27) & "[0;31m"
Public gblzFNGRE As String ' Chr(27) & "[0;32m"
Public gblzFNYEL As String ' Chr(27) & "[0;33m"
Public gblzFNBLU As String ' Chr(27) & "[0;34m"
Public gblzFNMAG As String ' Chr(27) & "[0;35m"
Public gblzFNCYA As String ' Chr(27) & "[0;36m"
Public gblzFNWHI As String ' Chr(27) & "[0;37m"

Public gblzFBRED As String ' Chr(27) & "[1;31m"
Public gblzFBGRE As String ' Chr(27) & "[1;32m"
Public gblzFBYEL As String ' Chr(27) & "[1;33m"
Public gblzFBBLU As String ' Chr(27) & "[1;34m"
Public gblzFBMAG As String ' Chr(27) & "[1;35m"
Public gblzFBCYA As String ' Chr(27) & "[1;36m"
Public gblzFBWHI As String ' Chr(27) & "[1;37m"
Public gblbTurnOnMapRealmGhost As Boolean
Public Const cstlLearnPointCost = 1 '1 or more only value
Public Const gbllWearItemMAXLimit = 52
Public Const cstzRealmQuestTitle = "&RREALM QUEST&r!" 'or we could put here "&R" & "REALM QUEST" & "&r!"
Public Const gblzAsciiPoltergeist = "&WP&wolter&ageist"
Public Const gblzAsciiRealmGhost = "&WR&wealm &WG&whost"
Public gblzServerGhostPlayerName As String
Public gbllServerCemeteryLocDX1 As Long '-9 -12 to -1 -7 is the cemetary
Public gbllServerCemeteryLocDX2 As Long
Public gbllServerCemeteryLocDY1 As Long
Public gbllServerCemeteryLocDY2 As Long
Public gblbRealmGhostCemetaryAwake As Boolean
Public gblzServerGhostPortID As String
Public gbllServerGhostPlayerID As Long
Public gbllServerGhostX As Long
Public gbllServerGhostY As Long
Public gbllServerGhostZ As Long
Public gbllServerGhostAX As Long
Public gbllServerGhostAY As Long
Public gbllServerGhostAZ As Long
Public gbllMimicLevel(cstlMinPort To cstlMaxPort) As Long
Public gbllLoadRandomGivesObjectID As Long 'Mobs that fall into the realm have a chance at giving a special item!
Public gblzLoadRandomGivesObjectID As String
Public gblbServerSteroid As Boolean 'If (gblbServerSteroid) Then DoEvents 'SUBLOOPSystem-Tick[
Public gblzLagTimerA As String
Public gblzLagTimerB As String
Public gblbMOBINTELLIGENCEMODE As Boolean 'details of mobs, street sweepers dusting off statues etc
Public gbllWITCHLOCKDuration As Long
Public gbllWITCHLOCKPlayerID As Long
Public cstdtActivate6pmSequence As String
Public cstboActivate6pmSequence As Boolean
Public cstAtmozDefault As Long
Public Const cstgblRoomX1 = -99
Public Const cstgblRoomX2 = 99
Public Const cstgblRoomY1 = -99
Public Const cstgblRoomY2 = 99
Public Const cstgblRoomZ1 = -5
Public Const cstgblRoomZ2 = 5
Public Const cstFACTIONSAFEPlayerLevel = 333
Public Const cstBountyTitle = "&GB&go&wun&aty"
Public Const gblzSHOWTIMEGameName = "&WSHOW&wTI&aME"
Public gblzEveryoneWelcomeDateTime As String
'KEEP the port range at the top of this document
Public gblbRealmAdditionalMoveCosts As Boolean 'type MAP for Pestilence in the area can bring it down and blocking a wee bit can too
Public Const gblcstForgeValueMAX = 2222
Public Const gblcstzDetectCode = "@IP@" 'special code
Public Const gblzMAPPEROFFCODE = "<@[MAPPEROFF]@>"
Public Const gblzMAPPERONCODE = "<@[MAPPERON]@>"
Public gblbLastPlayedActive As Boolean 'If this is true then the system will auto remove from clans over so many days and delete the entire character after playerlevel * 3 days
Public gblbFilterPlayerNames As Boolean 'true = if you want a more roleplay names from players - but they can take awhile to figure one out
'others
Public gbllImmortalPortEAR As Long 'max 5 controls 1999(EAR) since 2022 (EAR), port spam
Public Const gblcstlPlayerLevelToWHOPAGELAST = 1
Public Const gblcstRaceFeet = 1500 'Length in feet for the race track
Public gbllRaceFeet As Long 'this is to tell the system when to run
Public gblTornadoLevel As Long '-1: off 0: windy 1: dust devil 2: quite windy many dust devils 3: high winds 4: blowing high kilometre windows 5to9: Tornadoe Level 1to5 10: utter destruction except location 0 items - use CLEAN command a lot
Public gbllTornadeoX As Long
Public gbllTornadeoY As Long
Public gbllTornadeoZ As Long
Public gbllPentagramX As Long
Public gbllPentagramY As Long
Public gbllPentagramZ As Long
Public gbllWearItemMAX As Long 'gbllWearItemMAXLimit 52 is the TRUE MAX but we start them off at 20 plus race and class boosts
Public gbllWearItemMAXAdmin As Long
Public Const gblbSilenceFactions = True
Public Const cstbQuestShowTimeSingleWinnerMode = False 'False can be more fun for everyone
Public gbllQuestShowtimeItemsCount As Long
Public gblzQuestShowtimeObjectName(1 To 9) As String
Public gbllQuestShowtimeObjectValue(1 To 9) As Long
Public gbllQuestShowtimeObjectID(1 To 9) As Long 'their are up to 9 ObjectID s to guess their value, closest TOTAL wins 1 glory each 3 objects  to guess = 3 glory max
Public gbllQuestShowtimeDuration As Long 'game is running down in time subSimpleQuestChannel
Public gbllQuestShowtimeBID(cstlMinPort To cstlMaxPort) As Long
Public gblbGraphicIDsOnOff(cstlMinPort To cstlMaxPort) As Boolean
Public gblzGraphicalClientCode As String 'ie. gblzFNGRE & gblzFNMAG & "&y" 'The Graphical Client watches for this code and when it is see it uses the data separated by MOREBAR | to display graphics
Public gblbSensesMode(cstlMinPort To cstlMaxPort) As Boolean
Public gblbFilterMode(cstlMinPort To cstlMaxPort) As Boolean
Public gblbClientMode(cstlMinPort To cstlMaxPort) As Boolean
Public gbllAttackLevel(cstlMinPort To cstlMaxPort) As Long
Public gblbScareMode(cstlMinPort To cstlMaxPort) As Boolean 'works with subHarassANearbyRandomPlayer
Public gblbHarassANearbyRandomPlayerMS As Boolean
Public gbllRecalculatedDelay(cstlMinPort To cstlMaxPort) As Long
Public gbllAngryVentingSystem(cstlMinPort To cstlMaxPort) As Long
Public Const cstlQuestGuardFailCountMAX = 6
Public gbllQuestGuardAreaID(cstlMinPort To cstlMaxPort) As Long
Public gblzQuestGuardAreaDesc(cstlMinPort To cstlMaxPort) As String
Public gbllQuestGuardFailCount(cstlMinPort To cstlMaxPort) As Long 'ANTI-BOT if this gets high you know that person is botting hard
Public gblbLineFeed(cstlMinPort To cstlMaxPort) As Boolean
Public gblzGRAMMARLYIncorrectTIME(1 To 5) As String
Public gblbStarshipTested(cstlMinPort To cstlMaxPort) As Boolean
Public gblStarshipX(cstlMinPort To cstlMaxPort) As Long
Public gblStarshipY(cstlMinPort To cstlMaxPort) As Long
Public gblStarshipZ(cstlMinPort To cstlMaxPort) As Long
Public gblbStarship(cstlMinPort To cstlMaxPort) As Boolean
Public gbllDEATHX As Long 'lingers randomly - its like FortNight to force people out of an area randomly
Public gbllDEATHY As Long
Public gbllDEATHZ As Long
Public gbllCLOUDX1 As Long 'lingers randomly - healing 99 x 99 x 99 and random LOOOOOONG 20000 streatches
Public gbllCLOUDY1 As Long
Public gbllCLOUDZ1 As Long
Public gbllCLOUDX2 As Long 'lingers randomly - healing 99 x 99 x 99 and random LOOOOOONG 20000 streatches
Public gbllCLOUDY2 As Long
Public gbllCLOUDZ2 As Long
Public gbllAtmosphereStaticCharges As Long
Public Const gblcstlArcadePackmanPoints = 250
Public gblbRaceBeginning As Boolean
Public gbllEarthQuake As Long
Public gbllRouletteGo As Long 'this is to tell the system when to run
Public gbllRouletteBetTimes(cstlMinPort To cstlMaxPort) As Long
Public gblbImmortalWHODisplayed(cstlMinPort To cstlMaxPort) As Boolean
'Public gblbSmeagols(cstlMinPort To cstlMaxPort) As Boolean
Public Const cstbFastPets = False
'FTP SERVER
Public Const cstlExits = 99 ' Allows a person to room create so many rooms by immortal level
Public Const cstzFileNameFTPWHOIS = "c:\coawhois.htm"
Public gblzImmortalEmail As String
Public gblzImmortalName1 As String
Public gblzImmortalName2 As String
Public gblzImmortalName3 As String
Public gblzImmortalName4 As String
Public gbllFTPProxyServer As Long
Public gbllHTTPProxyServer As Long
Public gbllTelnetProxyServer As Long
Public gblzFTPServerURL As String
Public gblzFTPServerDirectory As String
Public gblzFTPUserName As String
Public gblzFTPUserPassword As String
Public gblsStockValue As Single
Public gblzMUDTelnetURL As String '= "Stargate - City of Ages" 'zSystemConfig(27)
Public gblzMUDName As String '= "Stargate - City of Ages" 'zSystemConfig(27)
Public gblzMUDHomePageURL As String '= "Stargate - City of Ages" 'zSystemConfig(27)

Public gblbAsciiFormActive As Boolean 'used to turn off min resize control to tray

'FORGE
Public Const cstlTemperCost = 33
Public Const cstlChizzleCost = 50
Public Const cstlMissileCost = 99
Public Const cstlBackStbCost = 199
Public Const cstlIASEachCost = 3 'Case 1010
Public Const cstlSlayEachCost = 222 'Case 1030 'immortal slay chance

Public Const gbllForgeCostSTRCrowns = 13
Public Const gbllForgeCostINTCrowns = 8
Public Const gbllForgeCostWISCrowns = 8
Public Const gbllForgeCostDEXCrowns = 9
Public Const gbllForgeCostCONCrowns = 11
Public Const gbllForgeCostCHACrowns = 7
Public Const gbllForgeCostLUCCrowns = 12

'LOAD ARCADE INFO
Type tArcadeGame
    lGrid(1 To 1200) As Long '1 to 80 for GridX AND 1 to 15 for GridY   1=X here and 2=` and 3=o and 9=the moving man
    lSpot As Long 'eg. for pacman there is a 1 = dot and 2 = powerup to eat ghosts
End Type
Public gbltArcadeGrid(cstlMinPort To cstlMaxPort) As tArcadeGame

Type tDurations 'If someone put all the durations of the character in here it would cause lag to go away
'see also: subInitializeDurations subCountdownDurations
    lPullMissile As Long
    lARCANEBOLT As Long
End Type
Public gbltDurations(cstlMinPort To cstlMaxPort) As tDurations

Type tArcadePlayer
    lGame As Long '1=pacman
    lSpeed As Long 'The monster skips a turn to make it look like the player is moving faster
    bFireGun As Boolean
    bFirePhaser As Boolean
    bDropBomb As Boolean
    bButtonX As Boolean
    bButtonY As Boolean
    bButtonZ As Boolean
    lTimer1 As Long
    lTimer2 As Long
    lTimer3 As Long
    lPoints As Long
    lX As Long '1 to 80 on a telnet screen
    lY As Long '1 to 15 in height max
    zJoystick As String 'This will be E or N or S or W or NE NW SE SW U or Down
End Type
Public gbltArcadePlayer(cstlMinPort To cstlMaxPort) As tArcadePlayer
'LOAD CARDS
Type tCard
    zPicture1 As String
    zPicture2 As String
    zPicture3 As String
    zPicture4 As String
    zPicture5 As String
    zPicture6 As String
    zPicture7 As String
    zPicture8 As String
    zPicture9 As String
    lSuit As Long
    lPlayerID As Long 'which player has this card
End Type
Public gbltCard(1 To 54) As tCard 'Clubs Diamonds Spades Hearts Joker1 Joker2

Public gbllCountAreaDescExits As Long
Public gblbUseMemoryExits As Boolean  'Works with Exits: to show the exits faster
'SYSTEM
Public Const gblcstlDodgeParryWeaponsBlockXPMin = 2000
Public Const cstlWin9xMaxPort = 2026
Public Const cstlTotalCoaBackupsPossible = 3
Public Const glblMaxConnectionsFromIP = 3 'this must NEVER be 0 or less it must be 1 or more allowed connections
Public Const glblCentimetreToFeetConverter = 30.48 'this can NEVER be zero
'Moon phases
Public gbllMoon As Long '-5 skullmoon // +5 eclipse
'Armour Absorption and Gold Chance
Public Const cstlPlayerStarAbsCalcu = 40
'Public gbllPlayerProfessions(cstlMinPort To cstlMaxPort) As tProfessions
Public zWatchzPromptOriginal(cstlMinPort To cstlMaxPort) As String  'this remembers the last command
Public gbllFishing(cstlMinPort To cstlMaxPort) As Long 'Times when the user can fish next, the long is set to 1-99 tick messages (which are random for aumbiance other then at 1 which means they are nearly done)
Public gblbInterruptPlayer(cstlMinPort To cstlMaxPort) As Boolean 'the next command sent by the user is interrupted
Public gbllInitativeChance(cstlMinPort To cstlMaxPort) As Long
Public gbllArmourAbsorbtionChance(cstlMinPort To cstlMaxPort) As Long
Public gbllGoldDropChance(cstlMinPort To cstlMaxPort) As Long
'REALM QUESTS [cstzRealmQuestTitle]
'Const cstlArmageddon = 5000 'mili seconds time left
'Public gbllArmageddonTimeLeft As Long 'gbllArmageddonTimeLeft = (creatures * cstlArmageddon) * 60000
Public gbllArmageddonKills(cstlMinPort To cstlMaxPort) As Long
Public gbllREALMQuestArmageddonKillThisManyCreatures As Long 'you are allowed only so many ticks to do this
Public gbllREALMQuestArmageddonTicksAllowed As Long '1 tick is 1 minute
Public gbllREALMQuestArmageddonPayOff As Long 'glory
'ORACLE QUEST
Public Const cstlQuestDifficulity = 5
Public Const gblsExtraHardQuest = cstlQuestDifficulity 'must be less than cstlQuestDifficulity
Public Const gblsHardQuest = 3.77 'must be less than gblsExtraHardQuest

'OTHER
Public Const gblbPageLastOkay = True
Public Const gblbAllowExplosives = True
'MERCHANT MULTIPLIER - SELL - BUY - LIST
Public Const cstMerchantPlayerLevel = 20
Public Const cstlGlobalEmoteLevel = 1
Public Const cstlMAXStreamLength = 1280 'this prevents port flooding

'STARSHIP
Public Const cstlBeamDistance = 75
Public Const gbllSSGoldCost = 40000
Public Const cstlMaxStarshipComponentDamage = 9
Public Const cstlMaxStarshipPhaserHullIntegrityDamage = 79 'When the hull integrity falls below this value then phasers will be affected - engines are affected with any damage below 98
Public Const cstlMaxStarshipEngineHullIntegrityDamage = 98 'ie. lSSEngineLevel = lElementalResistance(lSSEngineLevel, (100 - lSSHullIntegrity))
Public Const cstlMaxStarshipShieldNebularHullIntegrityDamage = 90 'this means that only 10 percent of the shields will operate
Public Const cstlLaserReducedSigDivider = 25
Public Const cstlCloakingSigReduction = 5
'STARSHIP WARZ
Public Const cstlRequiredTotalPlanets = 7
Public Const cstlRequiredTotalColonists = 15000

'TWEEK PETS
Public Const cstlPetLevelXP = 18
Public Const cstlPetHPMultiplier = 40
Public Const cstlPetDmgMultiplier = 2

Public Const cstlPhaserFuelCost = 119
Public Const gbllSSGoldCostShieldUpgrade = 12625
Public Const gbllSSGoldCostHullUpgrade = 9250
Public Const gbllSSGoldCostLaserUpgrade = 6800
Public Const gbllSSGoldCostPMinesUpgrade = 9100
Public Const gbllSSGoldCostEngineUpgrade = 25250
Public Const gbllSSGoldCostScanUpgrade = 4615
Public Const gbllSSGoldCostCloakingUpgrade = 17600
Public Const gbllSSGoldCostRepulsorUpgrade = 15500
Public Const gbllSSGoldCostPowerLevelUpgrade = 485
Public Const gbllSSGoldCostBatteryUpgrade = 875
    
Public Const cstlPMinesSoulCost = 60 'pet ssminelevel
Public Const cstlPReplicatorSoulCost = 2200

'ANSI GLOBALS Foreground Normal/Bold
Public gblbServerWillBeRightBack As Boolean 'This is so when there isnt anyone on someone can run scandisk or something and keep the mud running - push the RESET REALM BUTTON TO RELEASE IT
'Public gbliServerForcedNoLag As Integer 'This is the mode where everything except mob talking is disabled for server speed - this is different for slow normal fast pc modes this actually disables how the game oper
Public gblzLocalHost As String
'TO SUPPORT REGULAR TELNET
Public gbllFailedBackUps As Long
Public gblbAutoActivateAllListentingPorts As Boolean
Public gblzBackupTelnet(cstlMinPort To cstlMaxPort) As Variant
Public gblzTelnet(cstlMinPort To cstlMaxPort) As Variant
Public gblzTelnetRepeatCommand(cstlMinPort To cstlMaxPort) As Variant
Public gblbAutoloot(cstlMinPort To cstlMaxPort) As Variant 'So players dont have to get all corpse
Public gblzVoteCasted(cstlMinPort To cstlMaxPort) As String
Public gbllGolfSwings(cstlMinPort To cstlMaxPort) As Long
Public gbllSpeakControl(cstlMinPort To cstlMaxPort) As Long
Public gbllVoteDuration As Long
Public gblzVoteTopic As String
Public gblzTelnetReplyCommand(cstlMinPort To cstlMaxPort + 5) As String
'MONITOR
Public gblzPortSpy1(cstlMinPort To 2061) As String
Public gblzPortSpy2(cstlMinPort To 2061) As String
Public gblzPortSpy3(cstlMinPort To 2061) As String
Public gblzPortSpy4(cstlMinPort To 2061) As String

'Port experience
Public gbllPortTotalXP(cstlMinPort To cstlMaxPort) As Long 'ports total XP till dump - this is just a visual variable for reports - the XP is added as it goes.
Public gblbAlternateConnectPortsEnabled As Boolean

'SPAM
Public Const cstlSPAMDisconnectLevel = 12
Public gbllSpeakControlMax As Long

'GAME CONSTANTS
Public gblbOnline As Boolean
Public Const cstzShortstopChar = ","
Public Const cstzPortsFull = "%PORTREJECTED%"
Public Const cstzTimerControlNuke = "%NUKETHISFINEFELLOW%" 'This is a command delivered to that players port for the port to deal with.
Public Const cstzTimerControlGoodbye = "%GOODBYE%" 'This is a command delivered to that players port for the port to deal with.
Public Const cstzTimerControlPortsFullGoodbye = "%PORTSFULLBYE%"
Public Const cstzTimerControlQuit = "%QUITNORMALLY%" 'This is a command delivered to that players port for the port to deal with.
Public Const cstzTimerControlLook = "%LOOK%" 'This is a command delivered to that players port for the port to deal with.
Public Const cstlClassGlowing = 6 'makecorpse and lduplicateobject

Public Const cstlNukeMAX = 33 'PlayerLevel * NukeMAX < start day - 3 is average
Public Const cstlRankLost = 55 'if a player doesnt play for 55 days we remove them automatically from the clan

Public Const cstlSoulshieldDuration = 3
Public Const cstlEssenceshieldDuration = 4
Public Const cstlManashieldDuration = 5
Public Const cstlBaseItemsHeld = 30

Public gblbTiming As Boolean
Public gbliFlow(cstlMinPort To cstlMaxPort) As Integer
Public gbliPlayerNameTries(cstlMinPort To cstlMaxPort) As Integer
Public gbliPasswordTries(cstlMinPort To cstlMaxPort) As Integer
Public gbliAuctionChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliInfoChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliTellChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliPrayChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliLordChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliHeroChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliRaceChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliClassChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliRumoChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliRambChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliQuotChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliIMCChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliQuesChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliMusiChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliOOCChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliNewbieChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliGossipChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliClanChannelStatus(cstlMinPort To cstlMaxPort) As Boolean
Public gbliPortStatus(cstlMinPort To cstlMaxPort) As Integer 'controls AFK - VOID 0 prevents form load errors
Public gblbTimerAvailable(cstlMinPort To cstlMaxPort) As Boolean 'Speeds up the port communications.
Public gbllRumorCounter(cstlMinPort To cstlMaxPort) As Long 'used so that Rumor: doesnt spam we need only one in the list displayed
Public gbllQuestCounter(cstlMinPort To cstlMaxPort) As Long 'used so that Quest: doesnt spam we need only one in the list displayed
Public gbliMinutes As Integer
Public Const gblcstlSystemCleanHouse = 1600
Public gblbAllowAutoRebooting As Boolean
Public gbllDefcon As Long
Public gbllPosted As Long
Public gblbSkip As Boolean

Public gbllSystemCleanHouse As Long
Public gbllSystemTick As Long
Public gbllClearObjects As Long
Public gblzSystemGuessWord As String
Public gbliSystemGuessWordBonusGlory As Integer
Public gblzSystemGuessWordScrambled As String
Public gbliDayCodeTick As Long
Public Const gbllPlayerWeightMultiplierInGrams = 3000 'player str * this amount to get objects
'For spells
Public Const cstlAquaBreathCost = 4950
Public Const cstlAquaBreathLevel = 1900
Public Const cstlNegateCost = 950
Public Const cstlNegateLevel = 600
Public Const cstlSummonCost = 7550
Public Const cstlSummonLevel = 1700
Public Const cstlIdentifyCost = 5550
Public Const cstlIdentifyLevel = 1300
Public Const cstlGotoLevel = 7100
Public Const cstlInvisibleCost = 2500
Public Const cstlInvisibleLevel = 1500
Public Const cstlFlyCost = 4000
Public Const cstlFlyLevel = 2040
Public Const cstlCreateLightCost = 950
Public Const cstlCreateLightLevel = 1400
Public Const cstlDetectInvisCost = 850
Public Const cstlDetectInvisLevel = 900
Public Const cstlRestoreHealthCost = 2021
Public Const cstlRestoreHealthLevel = 1750
Public Const cstlExorcismCost = 3150
Public Const cstlExorcismLevel = 800
Public Const cstlFireBallCost = 27600
Public Const cstlFireBallLevel = 1000
Public Const cstlSanctuaryCost = 2350
Public Const cstlSanctuaryLevel = 1600
Public Const cstlFireshieldCost = 6000
Public Const cstlFireshieldLevel = 3800
Public Const cstlIceshieldCost = 4600
Public Const cstlIceshieldLevel = 2150
Public Const cstlHealCost = 5900
Public Const cstlHealLevel = 850
Public Const cstlRemoveCurseCost = 2900
Public Const cstlRemoveCurseLevel = 350
Public Const cstlBarkSkinCost = 2600
Public Const cstlBarkSkinLevel = 700
Public Const cstlDragonSkinCost = 4100
Public Const cstlDragonSkinLevel = 1200
Public Const cstlDemonSkinCost = 9300
Public Const cstlDemonSkinLevel = 2400
Public Const cstlSleepCost = 8700
Public Const cstlSleepLevel = 3100
Public Const cstlStunSoulCost = 130
Public Const cstlEnsnareSoulCost = 350
Public Const cstlEnsnareMoveCost = 100
Public Const cstlDisarmSoulCost = 1900
Public Const cstlSneakSoulCost = 350
Public Const cstlStealMoveCost = 2800

Public Const cstlDisarmTrapSoulCost = 950
Public Const cstlDisarmTrapChanceAS = 16
Public Const cstlDisarmTrapChanceRA = 31
Public Const cstlDisarmTrapChanceDR = 41
Public Const cstlDisarmTrapChanceTH = 26
Public Const cstlDisarmTrapChanceOption = 11

Public Const cstlDisarmTrapMoveCost = 2800
Public Const cstlLocateMobEqCost = 6130
Public Const cstlLocateMobEqLevel = 5130

Public Const gblcstlRottingRounds = 4
Public Const cstlMobileRespawnDelay = gblcstlRottingRounds

Public Const lcstNegateDuration = 30 '1 point = 1 minute 15 seconds
Public Const gblcstlMaxAreaObjects = 20
Public Const gblcstlMaxAreaDonationObjects = 90
Public Const cstlMartialArts = 1000

Declare Function ExitWindowsEx& Lib "user32" (ByVal uFlags&, ByVal dwReserved&)  'lresult = ExitWindowsEx(EWX_REBOOT, 0&) 'restart the computer

Private Type MEMORYSTATUS
    dwLength As Long        ' Size of MEMORYSTATUS
    dwMemoryLoad As Long    ' % of memory in use
    dwTotalPhys As Long     ' Total bytes of physical memory
    dwAvailPhys As Long     ' Bytes of free physical memory
    dwTotalPageFile As Long ' Bytes in paging file
    dwAvailPageFile As Long ' Free bytes in paging file
    dwTotalVirtual As Long  ' User bytes of address space
    dwAvailVirtual As Long  ' Free user bytes
End Type
Private Declare Sub GlobalMemoryStatus Lib "kernel32" (lpBuffer As MEMORYSTATUS)
Public Function bActivate6pmSequence() As Boolean
    Dim bReturn As Boolean
    bReturn = False
    If (DateDiff("d", cstdtActivate6pmSequence, Now()) > 0) Then
        bReturn = True
        cstdtActivate6pmSequence = Format(Now(), "mmm dd, yyyy 20:59")
    End If
    bActivate6pmSequence = bReturn
End Function
Public Function zTranslateBoolean(vValue As Variant) As String
    Dim zReturn As String
    Select Case MyCLng(vValue)
        Case 0
            zReturn = "NO"
        Case Else
            zReturn = "YES"
    End Select
    zTranslateBoolean = zReturn
End Function

Public Function zMemoryInfo() As String
On Error GoTo Err_Check
Dim mem As MEMORYSTATUS
Dim zReturn As String
    GlobalMemoryStatus mem
    
    zReturn = ""
    
    With mem
        zReturn = zReturn & "Percent used:          " & Format((.dwMemoryLoad) / 100, "PERCENT") & vbCrLf
        zReturn = zReturn & "Total physical memory: " & Format(.dwTotalPhys, "STANDARD") & vbCrLf
        zReturn = zReturn & "Physical memory free:  " & Format(.dwAvailPhys, "STANDARD") & vbCrLf
        zReturn = zReturn & "Total page file size:  " & Format(.dwTotalPageFile, "STANDARD") & vbCrLf
        zReturn = zReturn & "Free page file size:   " & Format(.dwAvailPageFile, "STANDARD") & vbCrLf
        zReturn = zReturn & "Total virtual memory:  " & Format(.dwTotalVirtual, "STANDARD") & vbCrLf
        zReturn = zReturn & "Free virtual memory:   " & Format(.dwAvailVirtual, "STANDARD") & vbCrLf
    End With
    zMemoryInfo = zReturn
    Exit Function
Err_Check:
    zMemoryInfo = "Memory Check failed!"
End Function
Public Function zShortstop(vObjectName As Variant) As String
'This detects the comma and cuts to that point - no farther.
On Error GoTo Err_Check
    Dim zReturn As String
    
    zReturn = MyCStr(vObjectName) 'ObjectNames are to be in the format of 'NAME, cool description' <-- note the COMMA!!!
    If (InStr(zReturn, cstzShortstopChar) > 0) Then zReturn = Mid(zReturn, 1, InStr(zReturn, cstzShortstopChar) - 1)
    zShortstop = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zShortstop," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subInitializeAnsiGraphics()
On Error Resume Next
    gblzFNBLA = Chr(27) & "[1;30m" 'this is a grey without the zero part of [0;30m
    gblzFNRED = Chr(27) & "[0;31m"
    gblzFNGRE = Chr(27) & "[0;32m"
    gblzFNYEL = Chr(27) & "[0;33m"
    gblzFNBLU = Chr(27) & "[0;34m"
    gblzFNMAG = Chr(27) & "[0;35m"
    gblzFNCYA = Chr(27) & "[0;36m"
    gblzFNWHI = Chr(27) & "[0;37m"
    
    gblzFBRED = Chr(27) & "[1;31m"
    gblzFBGRE = Chr(27) & "[1;32m"
    gblzFBYEL = Chr(27) & "[1;33m"
    gblzFBBLU = Chr(27) & "[1;34m"
    gblzFBMAG = Chr(27) & "[1;35m"
    gblzFBCYA = Chr(27) & "[1;36m"
    gblzFBWHI = Chr(27) & "[1;37m"
    'Public gblzGraphicalClientCode As String
    gblzGraphicalClientCode = gblzFNBLA & gblzFNGRE & gblzFBCYA 'The Graphical Client watches for this code and when it is see it uses the data separated by MOREBAR | to display graphics - the mud will never allow a single quote to be accepted so we can use it
End Sub
Public Function zTranslateDropColours(zMsg As String) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = strReplaceWordWithThisWord(zMsg, "&B", "", False) 'ucase is suppored inside this sub
    zReturn = strReplaceWordWithThisWord(zReturn, "&C", "", False)
    zReturn = strReplaceWordWithThisWord(zReturn, "&Y", "", False)
    zReturn = strReplaceWordWithThisWord(zReturn, "&R", "", False)
    zReturn = strReplaceWordWithThisWord(zReturn, "&W", "", False)
    zReturn = strReplaceWordWithThisWord(zReturn, "&G", "", False)
    zReturn = strReplaceWordWithThisWord(zReturn, "&M", "", False)
    zReturn = strReplaceWordWithThisWord(zReturn, "&A", "", False)
    
    zTranslateDropColours = zReturn
End Function
Public Function zHTMLColourFont(zAscii As String) As String
On Error Resume Next
    Dim zHTMLColour As String
    zHTMLColour = zAscii
    
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&a", "<font color=gray>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&A", "<font color=gray>", True)
    
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&y", "<font color=gold>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&w", "<font color=silver>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&g", "<font color=darkgreen>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&b", "<font color=darkblue>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&c", "<font color=teal>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&m", "<font color=purple>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&r", "<font color=darkred>", True)
    
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&Y", "<font color=yellow>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&W", "<font color=white>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&G", "<font color=green>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&B", "<font color=blue>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&C", "<font color=cyan>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&M", "<font color=magenta>", True)
    zHTMLColour = strReplaceWordWithThisWord(zHTMLColour, "&R", "<font color=red>", True)
    zHTMLColourFont = zHTMLColour
End Function
Public Function vUnColour(zAscii As Variant) As Variant
On Error Resume Next
    Dim zNoColourTitle As String
    zNoColourTitle = zAscii
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&a", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&A", "")
    
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&y", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&w", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&g", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&b", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&c", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&m", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&r", "")
    
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&Y", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&W", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&G", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&B", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&C", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&M", "")
    zNoColourTitle = strReplaceWordWithThisWord(zNoColourTitle, "&R", "")
    vUnColour = zNoColourTitle
End Function
Public Function zTranslateLocation(lLocation As Long, zLocationLR As String) As String
On Error Resume Next
'This is a BODY LOCATION
    Dim zReturn As String
    Select Case lLocation
        Case 0
            zReturn = "ground item"
        Case 8
            zReturn = "headset"
        Case 9
            zReturn = "forehead"
        Case 10
            zReturn = "head"
        Case 11
            zReturn = "collar"
        Case 12
            zReturn = "around neck"
        Case 13
            zReturn = "talisman"
        Case 14
            zReturn = "pendant"
        Case 15
            zReturn = "amulet"
        Case 16
            zReturn = "over mouth"
        Case 17
            zReturn = "inside mouth"
        Case 18
            zReturn = "mask"
        Case 19
            zReturn = "over eyes"
        Case 20
            Select Case zLocationLR
                Case "L"
                    zReturn = "strong hand"
                Case "R"
                    zReturn = "available hand"
                Case "S"
                    zReturn = "hands"
            End Select
        Case 21
            zReturn = "buckler"
        Case 22
            zReturn = "over hands"
        Case 23
            zReturn = "poker card"
        Case 30
            Select Case zLocationLR
                Case "L"
                    zReturn = "left finger"
                Case "R"
                    zReturn = "right finger"
                Case "S"
                    zReturn = "fingers"
            End Select
        Case 31
            Select Case zLocationLR
                Case "L"
                    zReturn = "left thumb"
                Case "R"
                    zReturn = "right thumb"
                Case "S"
                    zReturn = "thumbs"
            End Select
        Case 32
            zReturn = "tongue stud"
        Case 33
            zReturn = "nose ring"
        Case 40
            Select Case zLocationLR
                Case "L"
                    zReturn = "left wrist"
                Case "R"
                    zReturn = "right wrist"
                Case "S"
                    zReturn = "wrist"
            End Select
        Case 41
            Select Case zLocationLR
                Case "L"
                    zReturn = "left cuff"
                Case "R"
                    zReturn = "right cuff"
                Case "S"
                    zReturn = "cuff"
            End Select
        Case 45 'bracers
            Select Case zLocationLR
                Case "L"
                    zReturn = "upper left arm"
                Case "R"
                    zReturn = "upper right arm"
                Case "S"
                    zReturn = "upper arms"
            End Select
        Case 50
            zReturn = "forearms"
        Case 60
            zReturn = "legs"
        Case 61
            Select Case zLocationLR
                Case "L"
                    zReturn = "left ankle"
                Case "R"
                    zReturn = "right ankle"
                Case "S"
                    zReturn = "ankles"
            End Select
        Case 62
            zReturn = "knee pads"
        Case 63
            zReturn = "elbow pads"
        Case 70
            zReturn = "torso"
        Case 71
            zReturn = "broach"
        Case 72
            zReturn = "chest insignia"
        Case 73
            zReturn = "over body"
        Case 80
            zReturn = "middle back"
        Case 81
            zReturn = "upper back"
        Case 82
            zReturn = "hips"
        Case 83
            zReturn = "waist"
        Case 84
            Select Case zLocationLR
                Case "L"
                    zReturn = "left shoulder"
                Case "R"
                    zReturn = "right shoulder"
                Case "S"
                    zReturn = "over a shoulder"
            End Select
        Case 85 'extra corpse carrying location
            zReturn = "over a shoulder"
        Case 90
            zReturn = "feet"
        Case 100
            Select Case zLocationLR
                Case "L"
                    zReturn = "left ear lobe"
                Case "R"
                    zReturn = "right ear lobe"
                Case "S"
                    zReturn = "ear lobes"
            End Select
        Case 110
            zReturn = "light source"
        Case 120
            zReturn = "money"
        Case 121
            zReturn = "bonus xp"
        Case Else
            zReturn = "Phasing" 'Nice error is all this is KEEP THIS parts of the system use it for ERROR CHECKING!
    End Select
    zTranslateLocation = zReturn 'Return strings 9 long and that is all
End Function
Public Sub subTranslateLocationValue(zLWord1 As String, ByRef lLWord1 As Long, zLWord2 As String, ByRef lLWord2 As Long)
On Error Resume Next
'This is a BODY LOCATION ranging for the EQUIP command
    Dim lReturn As Long
    Select Case UCase(MyCStr(zKeepLettersOnly(zLWord1)))
        Case "HEADSET", "SET"
            lReturn = 8
        Case "FOREHEAD", "FORE"
            lReturn = 9
        Case "HEAD"
            lReturn = 10
        Case "COLLAR", "NECK"
            lReturn = 11
        Case "AROUND", "AROUNDNECK", "AROUNDNECKS"
            lReturn = 12
        Case "TALISMAN"
            lReturn = 13
        Case "PENDANT"
            lReturn = 14
        Case "AMULET"
            lReturn = 15
        Case "OVERMOUTH", "OVERMOUTHS"
            lReturn = 16
        Case "INSIDEMOUTH", "INSIDEMOUTHS", "MOUTH", "MOUTHS"
            lReturn = 17
        Case "MASK", "FACE"
            lReturn = 18
        Case "OVEREYE", "OVEREYES", "EYES", "EYE"
            lReturn = 19
        Case "STRONGHAND", "AVAILABLEHAND", "HAND", "HANDS", "WEAPONS", "WEAPON", "STRONG", "AVAILABLE"
            lReturn = 20
        Case "BUCKLER", "SHIELD"
            lReturn = 21
        Case "OVERHANDS"
            lReturn = 22
        Case "POKERCARD", "POKER", "CARD"
            lReturn = 23
        Case "LEFTFINGER", "RIGHTFINGER", "FINGER", "FINGERS", "RING", "RINGS"
            lReturn = 30
        Case "LEFTTHUMB", "RIGHTTHUMB", "THUMB", "THUMBS", "THUMBRING", "THUMBRINGS"
            lReturn = 31
        Case "TONGUESTUD", "TONGUE", "STUD"
            lReturn = 32
        Case "NOSERING", "NOSE"
            lReturn = 33
        Case "LEFTWRIST", "RIGHTWRIST", "WRIST", "WRISTS"
            lReturn = 40
        Case "LEFTCUFF", "RIGHTCUFF", "CUFF", "CUFFS"
            lReturn = 41
        Case "UPPERARM", "UPPERARMS", "ARM", "ARMS", "UPPERLEFTARM", "UPPERRIGHTARM", "UPPERLEFTARMS", "UPPERRIGHTARMS"
            lReturn = 45
        Case "FOREARMS", "FOREARM"
            lReturn = 50
        Case "LEGS", "LEG"
            lReturn = 60
        Case "LEFTANKLE", "RIGHTANKLE", "ANKLE", "ANKLES"
            lReturn = 61
        Case "KNEEPADS", "KNEE", "KNEES"
            lReturn = 62
        Case "ELBOWPADS", "ELBOW", "ELBOWS"
            lReturn = 63
        Case "TORSO"
            lReturn = 70
        Case "BROACH"
            lReturn = 71
        Case "CHESTINSIGNIA", "CHEST", "INSIGNIA"
            lReturn = 72
        Case "OVERBODY", "BODY", "OVER", "ROBE", "BACK"
            lReturn = 73
        Case "MIDDLEBACK", "MBACK", "MIDDLE", "CLOAK"
            lReturn = 80
        Case "UPPERBACK", "UBACK"
            lReturn = 81
        Case "HIPS", "HIP", "SASH"
            lReturn = 82
        Case "WAIST", "WAISTS"
            lReturn = 83
        Case "LEFTSHOULDER", "RIGHTSHOULDER", "SHOULDER", "SHOULDERS"
            lReturn = 84
        Case "OVERASHOULDER", "OVERSHOULDER", "CORPSE", "CORPSES"
            lReturn = 85
        Case "FEET", "BOOTS", "BOOT", "SHOE", "SHOES"
            lReturn = 90
        Case "EAR", "EARS", "LOBE", "LOBES", "EARRING", "EARRINGS", "RIGHTEARLOBE", "LEFTEARLOBE", "RIGHTEARLOBES", "LEFTEARLOBES"
            lReturn = 100
        Case "LIGHT", "LIGHTSOURCE", "TORCH", "LAMP"
            lReturn = 110
        Case "MONEY", "CASH", "$", "#", "GOLD", "COIN", "COINS", "WORTH", "WORTHS", "CHARGE", "CHEQUE", "MONIES"
            lReturn = 120
        Case "BONUSXP", "BONUS XP", "BONUS", "XP", "EXP", "EXPERIENCE", "SOD"
            lReturn = 121
        Case Else
            lReturn = 0
    End Select
    lLWord1 = lReturn
    
    If (Len(zLWord2) = 0) Then zLWord2 = zLWord1
    Select Case UCase(MyCStr(zKeepLettersOnly(zLWord2)))
        Case "HEADSET", "SET"
            lReturn = 8
        Case "FOREHEAD", "FORE"
            lReturn = 9
        Case "HEAD"
            lReturn = 10
        Case "COLLAR"
            lReturn = 11
        Case "AROUND", "AROUNDNECK", "AROUNDNECKS"
            lReturn = 12
        Case "TALISMAN"
            lReturn = 13
        Case "PENDANT"
            lReturn = 14
        Case "AMULET", "NECK"
            lReturn = 15
        Case "OVERMOUTH", "OVERMOUTHS"
            lReturn = 16
        Case "INSIDEMOUTH", "INSIDEMOUTHS", "MOUTH", "MOUTHS"
            lReturn = 17
        Case "MASK", "FACE"
            lReturn = 18
        Case "OVEREYE", "OVEREYES", "EYES", "EYE"
            lReturn = 19
        Case "STRONGHAND", "AVAILABLEHAND", "STRONG", "AVAILABLE"
            lReturn = 20
        Case "BUCKLER", "SHIELD"
            lReturn = 21
        Case "OVERHANDS", "HAND", "HANDS", "WEAPONS", "WEAPON"
            lReturn = 22
        Case "POKERCARD", "POKER", "CARD"
            lReturn = 23
        Case "LEFTFINGER", "RIGHTFINGER", "FINGER", "FINGERS", "RING", "RINGS"
            lReturn = 30
        Case "LEFTTHUMB", "RIGHTTHUMB", "THUMB", "THUMBS", "THUMBRING", "THUMBRINGS"
            lReturn = 31
        Case "TONGUESTUD", "TONGUE", "STUD"
            lReturn = 32
        Case "NOSERING", "NOSE"
            lReturn = 33
        Case "LEFTWRIST", "RIGHTWRIST", "WRIST", "WRISTS"
            lReturn = 40
        Case "LEFTCUFF", "RIGHTCUFF", "CUFF", "CUFFS"
            lReturn = 41
        Case "UPPERARM", "UPPERARMS", "ARM", "ARMS", "UPPERLEFTARM", "UPPERRIGHTARM", "UPPERLEFTARMS", "UPPERRIGHTARMS"
            lReturn = 45
        Case "FOREARMS", "FOREARM"
            lReturn = 50
        Case "LEGS", "LEG"
            lReturn = 60
        Case "LEFTANKLE", "RIGHTANKLE", "ANKLE", "ANKLES"
            lReturn = 61
        Case "KNEEPADS", "KNEE", "KNEES"
            lReturn = 62
        Case "ELBOWPADS", "ELBOW", "ELBOWS"
            lReturn = 63
        Case "TORSO"
            lReturn = 70
        Case "BROACH"
            lReturn = 71
        Case "CHESTINSIGNIA", "CHEST", "INSIGNIA"
            lReturn = 72
        Case "OVERBODY", "BODY", "OVER", "ROBE"
            lReturn = 73
        Case "MIDDLEBACK", "MBACK", "MIDDLE", "CLOAK"
            lReturn = 80
        Case "UPPERBACK", "UBACK", "BACK"
            lReturn = 81
        Case "HIPS", "HIP", "SASH"
            lReturn = 82
        Case "WAIST", "WAISTS"
            lReturn = 83
        Case "LEFTSHOULDER", "RIGHTSHOULDER"
            lReturn = 84
        Case "OVERASHOULDER", "OVERSHOULDER", "CORPSE", "CORPSES", "SHOULDER", "SHOULDERS"
            lReturn = 85
        Case "FEET", "BOOTS", "BOOT", "SHOE", "SHOES"
            lReturn = 90
        Case "EAR", "EARS", "LOBE", "LOBES", "EARRING", "EARRINGS", "RIGHTEARLOBE", "LEFTEARLOBE", "RIGHTEARLOBES", "LEFTEARLOBES"
            lReturn = 100
        Case "LIGHT", "LIGHTSOURCE", "TORCH", "LAMP"
            lReturn = 110
        Case "MONEY", "CASH", "$", "#", "GOLD", "COIN", "COINS", "WORTH", "WORTHS", "CHARGE", "CHEQUE", "MONIES"
            lReturn = 120
        Case "BONUSXP", "BONUS XP", "BONUS", "XP", "EXP", "EXPERIENCE", "SOD"
            lReturn = 121
        Case Else
            lReturn = 0
    End Select
    lLWord2 = lReturn
End Sub
Public Function zTranslateLocationVerbose(zObjectName As String, iObjectDuelWield As Integer, lLocation As Long, zLocationLR As String, zPlayerName As String, bDuelWield As Boolean, zGender As String, zPersonMode As String) As String
On Error Resume Next
    Dim zParsedObjectName As String
    Dim zAORAN As String
    Dim zReturn As String
    
    zParsedObjectName = zShortstop(zObjectName) 'ObjectNames are to be in the format of 'NAME, cool description' <-- note the COMMA!!!
    
    'For better english use a or an infront of the proper words.
    zAORAN = zAdverb(zParsedObjectName, 2)
    
    '0=not equiptment, 10=head, 11-15=neck locations, 16=mouth, 17=eyes, 20=Hand, 21=Buckler, 22=pair of gloves, 28=Two Handed, 30=finger,  40=wrist decoration, 45=forearms, 50=arm, 60=leggings, 70=chest, 80=back middle, 81=back upper, 82=hips - back lower, 83=waist/belt, 84=over shoulder, 90=feet,100=ears
    
    Select Case lLocation
        Case 8 'headset
            If (zPersonMode = "1") Then
                zReturn = "Using both hands you attach " & zAORAN & zParsedObjectName & " headset to your head."
            Else
                zReturn = zPlayerName & " uses both hands to attach " & zAORAN & zParsedObjectName & " to " & zGender & " head."
            End If
        Case 9
            If (zPersonMode = "1") Then
                zReturn = "Using both hands you tie " & zAORAN & zParsedObjectName & " around your forehead."
            Else
                zReturn = zPlayerName & " uses both hands to tie " & zAORAN & zParsedObjectName & " around " & zGender & " forehead."
            End If
        Case 10
            If (zPersonMode = "1") Then
                zReturn = "You don " & zAORAN & zParsedObjectName & " on your head."
            Else
                zReturn = zPlayerName & " dons " & zAORAN & zParsedObjectName & " upon " & zGender & " head."
            End If
        Case 11 'Collar
            If (zPersonMode = "1") Then
                zReturn = "You fasten " & zAORAN & zParsedObjectName & " around your neck."
            Else
                zReturn = zPlayerName & " fastens " & zAORAN & zParsedObjectName & " around " & zGender & " neck."
            End If
        Case 12
            If (zPersonMode = "1") Then
                zReturn = "You pull " & zAORAN & zParsedObjectName & " over your head."
            Else
                zReturn = zPlayerName & " pulls " & zAORAN & zParsedObjectName & " over " & zGender & " head."
            End If
        Case 13
            If (zPersonMode = "1") Then
                zReturn = "You pull " & zAORAN & zParsedObjectName & " over your head and around your neck."
            Else
                zReturn = zPlayerName & " pulls " & zAORAN & zParsedObjectName & " over " & zGender & " head and around " & zGender & " neck."
            End If
        Case 14
            If (zPersonMode = "1") Then
                zReturn = "You pull " & zAORAN & zParsedObjectName & " over your head and around your neck."
            Else
                zReturn = zPlayerName & " pulls " & zAORAN & zParsedObjectName & " over " & zGender & " head and around " & zGender & " neck."
            End If
        Case 15
            If (zPersonMode = "1") Then
                zReturn = "You pull " & zAORAN & zParsedObjectName & " over your head and around your neck."
            Else
                zReturn = zPlayerName & " pulls " & zAORAN & zParsedObjectName & " over " & zGender & " head and around " & zGender & " neck."
            End If
        Case 16 'over mouth
            If (zPersonMode = "1") Then
                zReturn = "You fit " & zAORAN & zParsedObjectName & " over your mouth."
            Else
                zReturn = zPlayerName & " fits " & zParsedObjectName & " over " & zGender & " mouth."
            End If
        Case 17 'inside mouth
            If (zPersonMode = "1") Then
                zReturn = "You fit " & zAORAN & zParsedObjectName & " inside your mouth."
            Else
                zReturn = zPlayerName & " fits " & zAORAN & zParsedObjectName & " inside " & zGender & " mouth."
            End If
        Case 18 'mask
            If (zPersonMode = "1") Then
                zReturn = "You fit " & zParsedObjectName & " on your face."
            Else
                zReturn = zPlayerName & " fits " & zParsedObjectName & " on " & zGender & " face."
            End If
        Case 19 'eyes
            If (zPersonMode = "1") Then
                zReturn = "You place " & zParsedObjectName & " over your eyes."
            Else
                zReturn = zPlayerName & " places " & zParsedObjectName & " over " & zGender & " eyes."
            End If
        Case 20
            Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        Select Case iObjectDuelWield
                            Case 1 'object is something that can be dual wielded
                                zReturn = "You dual wield " & zAORAN & zParsedObjectName & " in your strong hand."
                            Case Else
                                zReturn = "You hold " & zAORAN & zParsedObjectName & " in your strong hand."
                        End Select
                    Else
                        Select Case iObjectDuelWield
                            Case 1
                                zReturn = zPlayerName & " dual wields " & zAORAN & zParsedObjectName & " in " & zGender & " strong hand."
                            Case Else
                                zReturn = zPlayerName & " dual holds " & zAORAN & zParsedObjectName & " in " & zGender & " strong hand."
                        End Select
                    End If
                Case Else 'Right handed, when there is battle the system looks at the right hand and determines if the object there can be dual wielded if it can it can be used in the battle and there is a dual wield emote for it
                    If (zPersonMode = "1") Then
                        Select Case iObjectDuelWield
                            Case 1 'object is something that can be dual wielded
                                zReturn = "You dual wield " & zAORAN & zParsedObjectName & " in your available hand."
                            Case Else
                                zReturn = "You hold " & zAORAN & zParsedObjectName & " in your available hand."
                        End Select
                    Else
                        Select Case iObjectDuelWield
                            Case 1
                                zReturn = zPlayerName & " dual wields " & zAORAN & zParsedObjectName & " in " & zGender & " available hand."
                            Case Else
                                zReturn = zPlayerName & " dual holds " & zAORAN & zParsedObjectName & " in " & zGender & " available hand."
                        End Select
                    End If
            End Select
        Case 21 'buckler
            If (zPersonMode = "1") Then
                zReturn = "You buckle " & zAORAN & zParsedObjectName & " over your strong arm."
            Else
                zReturn = zPlayerName & " buckles " & zAORAN & zParsedObjectName & " over " & zGender & " strong arm."
            End If
        Case 22 'pair of gloves
            If (zPersonMode = "1") Then
                zReturn = "You slip " & zAORAN & zParsedObjectName & " over your hands."
            Else
                zReturn = zPlayerName & " slips " & zAORAN & zParsedObjectName & " over " & zGender & " hands."
            End If
        Case 23 'poker card
            If (zPersonMode = "1") Then
                zReturn = "You flip the " & zParsedObjectName & " between two fingers."
            Else
                zReturn = zPlayerName & " flips the " & zParsedObjectName & " between two fingers."
            End If
        Case 30 'finger
            Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You slip " & zAORAN & zParsedObjectName & " over your left finger."
                    Else
                        zReturn = zPlayerName & " slips " & zAORAN & zParsedObjectName & " over " & zGender & " left finger."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You slip " & zAORAN & zParsedObjectName & " over your right finger."
                    Else
                        zReturn = zPlayerName & " slips " & zAORAN & zParsedObjectName & " over " & zGender & " right finger."
                    End If
            End Select
        Case 31 'thumbs
            Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You slip " & zAORAN & zParsedObjectName & " over your left thumb."
                    Else
                        zReturn = zPlayerName & " slips " & zAORAN & zParsedObjectName & " over " & zGender & " left thumb."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You slip " & zAORAN & zParsedObjectName & " over your right thumb."
                    Else
                        zReturn = zPlayerName & " slips " & zAORAN & zParsedObjectName & " over " & zGender & " right thumb."
                    End If
            End Select
        Case 32
            If (zPersonMode = "1") Then
                zReturn = "You pierce your tongue with the " & zParsedObjectName & "."
            Else
                zReturn = zPlayerName & " pierces " & zGender & " tongue with the " & zParsedObjectName & "."
            End If
        Case 33
            If (zPersonMode = "1") Then
                zReturn = "You pierce your nose with the " & zParsedObjectName & "."
            Else
                zReturn = zPlayerName & " pierces " & zGender & " nose with the " & zParsedObjectName & "."
            End If
        Case 40 'wrist
            Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You push your left wrist through " & zAORAN & zParsedObjectName & "."
                    Else
                        zReturn = zPlayerName & " pushes " & zGender & " left wrist through " & zAORAN & zParsedObjectName & "."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You push your right wrist through " & zAORAN & zParsedObjectName & "."
                    Else
                        zReturn = zPlayerName & " pushes " & zGender & " right wrist through " & zAORAN & zParsedObjectName & "."
                    End If
            End Select
        Case 41 'cuff
            Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You clip " & zAORAN & zParsedObjectName & " to your left wrist."
                    Else
                        zReturn = zPlayerName & " clips " & zAORAN & zParsedObjectName & " to " & zGender & " left wrist."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You clip " & zAORAN & zParsedObjectName & " to your right wrist."
                    Else
                        zReturn = zPlayerName & " clips " & zAORAN & zParsedObjectName & " to " & zGender & " right wrist."
                    End If
            End Select
        Case 45 'a pair of bracers - bicep or upper arm.
          Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You clip " & zAORAN & zParsedObjectName & " over your left bicep."
                    Else
                        zReturn = zPlayerName & " clips " & zAORAN & zParsedObjectName & " over " & zGender & " left bicep."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You clip " & zAORAN & zParsedObjectName & " over your right bicep."
                    Else
                        zReturn = zPlayerName & " clips " & zAORAN & zParsedObjectName & " over " & zGender & " right bicep."
                    End If
            End Select
        Case 50 'a pair of armmings
            If (zPersonMode = "1") Then
                zReturn = "You place " & zAORAN & zParsedObjectName & " over both of your forearms."
            Else
                zReturn = zPlayerName & " places " & zAORAN & zParsedObjectName & " over each of " & zGender & " forearms."
            End If
        Case 60 'leggings
            If (zPersonMode = "1") Then
                zReturn = "You slide " & zAORAN & zParsedObjectName & " over both of your legs."
            Else
                zReturn = zPlayerName & " slides " & zAORAN & zParsedObjectName & " over both of " & zGender & " legs."
            End If
        Case 61 'anklets
          Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You drop your left ankle into " & zAORAN & zParsedObjectName & "."
                    Else
                        zReturn = zPlayerName & " drops " & zGender & " left ankle into " & zAORAN & zParsedObjectName & "."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You drop your right ankle into " & zAORAN & zParsedObjectName & "."
                    Else
                        zReturn = zPlayerName & " drops " & zGender & " right ankle into " & zAORAN & zParsedObjectName & "."
                    End If
            End Select
        Case 62 'knee pads
            If (zPersonMode = "1") Then
                zReturn = "You slip " & zAORAN & zParsedObjectName & " over your both of your knees."
            Else
                zReturn = zPlayerName & " slips into " & zAORAN & zParsedObjectName & " over both of " & zGender & " knees."
            End If
        Case 63 'elbow pads
            If (zPersonMode = "1") Then
                zReturn = "You slip " & zAORAN & zParsedObjectName & " over both of your elbows."
            Else
                zReturn = zPlayerName & " slips into " & zAORAN & zParsedObjectName & " over both of " & zGender & " elbows."
            End If
        Case 70 'Chest
            If (zPersonMode = "1") Then
                zReturn = "You fit " & zAORAN & zParsedObjectName & " over your body."
            Else
                zReturn = zPlayerName & " fits " & zAORAN & zParsedObjectName & " over " & zGender & " body."
            End If
        Case 71 'broach
            If (zPersonMode = "1") Then
                zReturn = "You pin " & zAORAN & zParsedObjectName & " to the upper side of your chest."
            Else
                zReturn = zPlayerName & " pins " & zAORAN & zParsedObjectName & " to the upper side of " & zGender & " chest." 'his/her chest
            End If
        Case 72 'chest insignia
            If (zPersonMode = "1") Then
                zReturn = "You attach " & zParsedObjectName & " to the centre of your chest."
            Else
                zReturn = zPlayerName & " attaches " & zParsedObjectName & " to the centre of " & zGender & " chest." 'his/her chest
            End If
        Case 73 'around the body - robes, cloakes
            If (zPersonMode = "1") Then
                zReturn = "You swing " & zAORAN & zParsedObjectName & " about your body."
            Else
                zReturn = zPlayerName & " swings " & zAORAN & zParsedObjectName & " about " & zGender & " body."
            End If
        Case 80 'Middle Back
            If (zPersonMode = "1") Then
                zReturn = "You gear into " & zAORAN & zParsedObjectName & "."
            Else
                zReturn = zPlayerName & " gears into " & zAORAN & zParsedObjectName & "."
            End If
        Case 81 'Back upper
            If (zPersonMode = "1") Then
                zReturn = "You attach " & zAORAN & zParsedObjectName & " to your back."
            Else
                zReturn = zPlayerName & " attaches " & zAORAN & zParsedObjectName & " to " & zGender & " back."
            End If
        Case 82 'Back lower - hips
            If (zPersonMode = "1") Then
                Select Case UCase(zGender)
                    Case "HIS"
                        zReturn = "You wrap " & zAORAN & zParsedObjectName & " around your hips."
                    Case "HER"
                        zReturn = "You wrap " & zAORAN & zParsedObjectName & " around your sexy hips."
                End Select
            Else
                Select Case UCase(zGender)
                    Case "HIS"
                        zReturn = zPlayerName & " wraps " & zAORAN & zParsedObjectName & " around " & zGender & " hips."
                    Case "HER"
                        zReturn = zPlayerName & " wraps " & zAORAN & zParsedObjectName & " around " & zGender & " sexy hips."
                End Select
            End If
        Case 83 'Belt - Waist
            If (zPersonMode = "1") Then
                zReturn = "You wrap " & zAORAN & zParsedObjectName & " around your waist."
            Else
                zReturn = zPlayerName & " wraps " & zAORAN & zParsedObjectName & " around " & zGender & " waist."
            End If
        Case 84 'Over neck and shoulder
          Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You drop your left shoulder through " & zAORAN & zParsedObjectName & "."
                    Else
                        zReturn = zPlayerName & " drops " & zGender & " left shoulder through " & zAORAN & zParsedObjectName & "."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You drop your right shoulder through " & zAORAN & zParsedObjectName & "."
                    Else
                        zReturn = zPlayerName & " drops " & zGender & " right shoulder through " & zAORAN & zParsedObjectName & "."
                    End If
            End Select
        Case 85 'Corpse carrying location
            If (zPersonMode = "1") Then
                zReturn = "You slap " & zAORAN & zParsedObjectName & " over a strong shoulder."
            Else
                zReturn = zPlayerName & " slaps " & zAORAN & zParsedObjectName & " over " & zGender & " strongest shoulder."
            End If
        Case 90 'Boots/feet
            If (zPersonMode = "1") Then
                zReturn = "You slip your feet into " & zAORAN & zParsedObjectName & "."
            Else
                zReturn = zPlayerName & " slips " & zGender & " feet into " & zAORAN & zParsedObjectName & "."
            End If
        Case 100 'Earrings
          Select Case zLocationLR
                Case "L"
                    If (zPersonMode = "1") Then
                        zReturn = "You clip on " & zAORAN & zParsedObjectName & " on your left ear lobe."
                    Else
                        zReturn = zPlayerName & " clips on " & zAORAN & zParsedObjectName & " on " & zGender & " left ear lobe."
                    End If
                Case Else 'Right
                    If (zPersonMode = "1") Then
                        zReturn = "You clip on " & zAORAN & zParsedObjectName & " on your right ear lobe."
                    Else
                        zReturn = zPlayerName & " clips on " & zAORAN & zParsedObjectName & " on " & zGender & " right ear lobe."
                    End If
            End Select
        Case 110 'Light source
            If (zPersonMode = "1") Then
                zReturn = "You wear " & zAORAN & zParsedObjectName & " as your light source."
            Else
                zReturn = zPlayerName & " uses " & zAORAN & zParsedObjectName & " as " & zGender & " light source."
            End If
        Case 120
            If (zPersonMode = "1") Then
                zReturn = "You wear " & zAORAN & zParsedObjectName & " as your money item."
            Else
                zReturn = zPlayerName & " uses " & zAORAN & zParsedObjectName & " as " & zGender & " money item."
            End If
        Case 121
            If (zPersonMode = "1") Then
                zReturn = "You wear " & zAORAN & zParsedObjectName & " as your grass sod."
            Else
                zReturn = zPlayerName & " uses " & zAORAN & zParsedObjectName & " as " & zGender & " grass sod."
            End If
        Case Else
            zReturn = "Phasing" 'Nice error is all this is
    End Select 'zTranslateGender(zGender, 2)
    zTranslateLocationVerbose = zReturn 'Return strings 9 long and that is all
End Function
Public Function zTranslateWeight(lWeight As Long) As String
On Error Resume Next
    Dim zReturn As String
    
    If (Abs(lWeight) < 1000) Then
        zReturn = MyCStr(lWeight) & " grams"
    Else
        zReturn = MyCStr(Format(lWeight / 1000, "FIXED")) & " kgs"
    End If
    zTranslateWeight = zReturn
End Function
Public Function bGrammarPrefixed(zType As String) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    Dim zTest As String
    
    zTest = UCase(Trim(zType))
    
    If (InStr(zTest, " ")) Then zTest = Mid(zTest, 1, InStr(zTest, " ") - 1)
    
    Select Case zTest
        Case "A", "AN", "THE"
            bReturn = True
        Case Else
            bReturn = False
    End Select
    bGrammarPrefixed = bReturn
End Function
Public Function zAdverb(zName As String, iType As Integer) As String
On Error Resume Next
'TheAorAn
    Dim zReturn As String
    zReturn = ""
    If (Not bGrammarPrefixed(zName)) Then
        If (zName <> "") Then
            If (MyCLng(Mid(zName, 1, 1)) = 0) Then 'let number ie. money show through with no prefix
                If (Not bCapital(zName) Or iType = 3 Or iType = 4 Or iType = 5) Then
                    zReturn = "a "
                    Select Case iType
                        Case 1, 3
                            If (bVoul(zName)) Then
                                zReturn = "an "
                            End If
                        Case 2, 4
                            If (bVoul(zName)) Then
                                zReturn = "an "
                            Else
                                zReturn = "the "
                            End If
                        Case 5
                            If (bVoul(zName)) Then
                                zReturn = "the "
                            Else
                                zReturn = ""
                            End If
                        Case 6
                            zReturn = "the "
                        Case 99 'we check for plural
                            If (bPlural(zName)) Then
                                zReturn = ""
                            Else
                                zReturn = "the "
                            End If
                    End Select
                End If
            End If
        End If
    End If
    zAdverb = zReturn
End Function
Public Function zTranslateDirection(zODir As String, iType As Integer) As String
On Error Resume Next 'zTranslateLocationVerb
    Dim zDir As String
    Dim zReturn As String
    
    Select Case UCase(Trim(zODir)) 'We give it a gereric iType of 0
        Case "N", "NORTH"
            zDir = "N"
        Case "S", "SOUTH"
            zDir = "S"
        Case "E", "EAST"
            zDir = "E"
        Case "W", "WEST"
            zDir = "W"
        Case "NE", "NORTHEAST", "NORTHE", "NEAST"
            zDir = "NE"
        Case "NW", "NORTHWEST", "NORTHW", "NWEST"
            zDir = "NW"
        Case "SE", "SOUTHEAST", "SOUTHE", "SEAST"
            zDir = "SE"
        Case "SW", "SOUTHWEST", "SOUTHW", "SWEST"
            zDir = "SW"
        Case "U", "UP", "ABOVE"
            zDir = "U"
        Case "D", "DOWN", "BELOW"
            zDir = "D"
    End Select
    
    '10=head, 11=neck (infinite), 20=lefthand, 25=righthand, 30=left finger, 35=rightfinger
    '40=leftwrist, 45=rightwrist, 50=left arm, 55= right arm, 60=left leg, 65=rightleg, 70=chest, 80=back, 90=feet
    Select Case iType
        Case 0
            zReturn = zDir
        Case 1 'movement - player/mob strides in/arrives to area - trick here is the player moves down but arrives from up so everything is reversed.
            Select Case UCase(zDir) 'SPECIAL: ~~ REVERSED DIRECTIONS ~~
                Case "S"
                    zReturn = "the north"
                Case "N"
                    zReturn = "the south"
                Case "W"
                    zReturn = "the east"
                Case "E"
                    zReturn = "the west"
                Case "SW"
                    zReturn = "the northeast"
                Case "SE"
                    zReturn = "the northwest"
                Case "NW"
                    zReturn = "the southeast"
                Case "NE"
                    zReturn = "the southwest"
                Case "D"
                    zReturn = "above"
                Case "U"
                    zReturn = "below"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
        Case 10 'search proper direction
            Select Case UCase(zDir)
                Case "N"
                    zReturn = "the north"
                Case "S"
                    zReturn = "the south"
                Case "E"
                    zReturn = "the east"
                Case "W"
                    zReturn = "the west"
                Case "NE"
                    zReturn = "the northeast"
                Case "NW"
                    zReturn = "the northwest"
                Case "SE"
                    zReturn = "the southeast"
                Case "SW"
                    zReturn = "the southwest"
                Case "U"
                    zReturn = "above"
                Case "D"
                    zReturn = "below"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
        Case 11 'reverse directions
            Select Case UCase(zDir)
                Case "N"
                    zReturn = "the south"
                Case "S"
                    zReturn = "the north"
                Case "E"
                    zReturn = "the west"
                Case "W"
                    zReturn = "the east"
                Case "NE"
                    zReturn = "the southwest"
                Case "NW"
                    zReturn = "the southeast"
                Case "SE"
                    zReturn = "the northwest"
                Case "SW"
                    zReturn = "the northeast"
                Case "U"
                    zReturn = "below"
                Case "D"
                    zReturn = "above"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
        Case 2 'movement - player/mob leaves area
            Select Case UCase(zDir)
                Case "N"
                    zReturn = "north"
                Case "S"
                    zReturn = "south"
                Case "E"
                    zReturn = "east"
                Case "W"
                    zReturn = "west"
                Case "NE"
                    zReturn = "northeast"
                Case "NW"
                    zReturn = "northwest"
                Case "SE"
                    zReturn = "southeast"
                Case "SW"
                    zReturn = "southwest"
                Case "U"
                    zReturn = "up"
                Case "D"
                    zReturn = "down"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
        Case 3 'Door desc
            Select Case UCase(zDir)
                Case "N"
                    zReturn = "northern"
                Case "S"
                    zReturn = "southern"
                Case "E"
                    zReturn = "eastern"
                Case "W"
                    zReturn = "western"
                Case "NE"
                    zReturn = "northeastern"
                Case "NW"
                    zReturn = "northwestern"
                Case "SE"
                    zReturn = "southeastern"
                Case "SW"
                    zReturn = "southwestern"
                Case "U"
                    zReturn = "trap-ceiling"
                Case "D"
                    zReturn = "trap-floor"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
        Case 4 'Door desc
            Select Case UCase(zDir)
                Case "N"
                    zReturn = "northern"
                Case "S"
                    zReturn = "southern"
                Case "E"
                    zReturn = "eastern"
                Case "W"
                    zReturn = "western"
                Case "NE"
                    zReturn = "northeastern"
                Case "NW"
                    zReturn = "northwestern"
                Case "SE"
                    zReturn = "southeastern"
                Case "SW"
                    zReturn = "southwestern"
                Case "U"
                    zReturn = "upward"
                Case "D"
                    zReturn = "downward"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
        Case Else 'standard return
            Select Case UCase(zDir)
                Case "N"
                    zReturn = "north"
                Case "S"
                    zReturn = "south"
                Case "E"
                    zReturn = "east"
                Case "W"
                    zReturn = "west"
                Case "NE"
                    zReturn = "northeast"
                Case "NW"
                    zReturn = "northwest"
                Case "SE"
                    zReturn = "southeast"
                Case "SW"
                    zReturn = "southwest"
                Case "U"
                    zReturn = "up"
                Case "D"
                    zReturn = "down"
                Case Else
                    zReturn = "?Dir=" & zDir & "?"
            End Select
    End Select
    zTranslateDirection = zReturn 'Return strings 9 long max and that is all
End Function
Public Function zTranslatePlayerStatus(lPlayerID As Long, lStance As Long, zPlayerName As String, iHealStatus As Integer, zGender As String, lShadowCloakDuration As Long, lFlyDuration As Long, lSanctuaryDuration As Long, lIceshieldDuration As Long, lFireshieldDuration As Long, lStaticshieldDuration As Long, lChaosshieldDuration As Long, lInvisibilityDuration As Long, lStunDuration As Long, lCHP As Long, lOHP As Long, lHidingDuration As Long, lCamoflaguedDuration As Long, lDetectInvisibilityDuration As Long) As String
On Error Resume Next
    Dim zReturn As String
    Dim zBodyColour As String
    zReturn = ""
    
    If (lShadowCloakDuration > 0) Then
        zBodyColour = gblzFNBLA
    Else
        Select Case UCase(Mid(zGender, 1, 1))
            Case "M"
                zBodyColour = gblzFNCYA
            Case Else
                zBodyColour = gblzFNMAG
        End Select
    End If
    
    Select Case lStance
        Case 1 'aggressive
            zReturn = zReturn & "&r+A+ "
        Case 2 'def
            zReturn = zReturn & "&r+D+ "
        Case 3 'slay
            zReturn = zReturn & "&r+S+ "
        Case 4 'waterloo
            zReturn = zReturn & "&r+W+ "
        Case 5 'chiotru
            zReturn = zReturn & "&r+C+ "
    End Select
    
    If (lSanctuaryDuration > 0) Then
        zReturn = zReturn & gblzFBWHI & zPlayerName
    Else
        zReturn = zReturn & zBodyColour & zPlayerName
    End If
    zReturn = zReturn & zBodyColour & " is "
    
    If (lStunDuration > 0) Then iHealStatus = 1
    '1=battle ready (knights and paladins MUST go into this mode before attacking), 2=standing at ease, 3=Relaxing, 4=Resting, 5=Sitting, 6=Sleeping
    Select Case iHealStatus
        Case 0
            zReturn = zReturn & "fighting"
        Case 1
            zReturn = zReturn & "stunned" 'This isnt used by is reserved for use with stunduration - stunduration takes precidence
        Case 2
            zReturn = zReturn & "dazed"
        Case 3
            zReturn = zReturn & "battle ready"  'this is forced during a fight unless dazed or stunned.
        Case 5
            If (bPlayerMounted(lPlayerID)) Then
                zReturn = zReturn & "riding a mount"
            Else
                zReturn = zReturn & "standing at ease"
            End If
        Case 10
            zReturn = zReturn & "relaxing"
        Case 15
            zReturn = zReturn & "resting"
        Case 20
            zReturn = zReturn & "sitting"
        Case 50
            zReturn = zReturn & "sleeping"
        Case Else
            zReturn = zReturn & "engulfed in divinity"
    End Select
    If (lCHP < lOHP) Then zReturn = zReturn & "&r *" & MyCLng((MyCLng(lCHP) * 100 / MyCLng(lOHP))) & "%*"
    
    If (lDetectInvisibilityDuration > 0 And lInvisibilityDuration > 0) Then
        zReturn = zReturn & "&B (di)"
    Else
        If (lDetectInvisibilityDuration > 0) Then zReturn = zReturn & "&B (d)"
        If (lInvisibilityDuration > 0) Then zReturn = zReturn & "&B (i)"
    End If
    If (lCamoflaguedDuration > 0) Then zReturn = zReturn & gblzFNBLU & " (camo)"
    If (lHidingDuration > 0) Then zReturn = zReturn & "&y (hiding)"
    If (lFlyDuration > 0) Then zReturn = zReturn & "&c (fly)"
    
    If (lFireshieldDuration > 0) Then zReturn = zReturn & "&r [f&Rir&re]"
    If (lIceshieldDuration > 0) Then zReturn = zReturn & "&c [i&Cc&ce]"
    If (lChaosshieldDuration > 0) Then zReturn = zReturn & "&a [c&rh" & gblzFNMAG & "a&ro&as]"
    If (lStaticshieldDuration > 0) Then zReturn = zReturn & "&a [s&wt&Wat&wi&ac]"
    
    zTranslatePlayerStatus = zReturn 'Return strings 9 long and that is all
End Function
Public Function lAreaWhereID(lAreaX As Long, lAreaY As Long, lAreaZ As Long) As Long
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsData = MyDB.OpenRecordset("SELECT WhereID FROM tblArea WHERE (X=" & lAreaX & " OR Y=" & lAreaY & " OR Z=" & lAreaZ & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        lReturn = MyCLng(rsData!WhereID)
    End If
    Set rsData = Nothing
    
    lAreaWhereID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lAreaWhereID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lImmortalLevelPortID(zPortID As String) As Long
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerID, ImmortalLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        lReturn = MyCLng(rsData!ImmortalLevel)
    End If
    Set rsData = Nothing
    
    lImmortalLevelPortID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lImmortalLevelPortID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnRandomPlayerID() As Long
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lTotalPlayersOnline As Long
    Dim zSQL As String
    Dim lReturn As Long
    
    lReturn = 0
    zSQL = "SELECT PlayerID FROM tblPlayer WHERE (Len([PortID])>1 AND Len(PortID)>1);"
    lTotalPlayersOnline = lngSQLRecordCount(zSQL)
    If (lTotalPlayersOnline > 0) Then
    zSQL = "SELECT TOP " & lRandom(lTotalPlayersOnline) & " PlayerID FROM tblPlayer WHERE (Len([PortID])>1 AND Len(PortID)>1);"
    Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        rsPlayer.MoveLast
        lReturn = MyCLng(rsPlayer!PlayerID)
    End If
    Set rsPlayer = Nothing
    End If
    lReturnRandomPlayerID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnRandomPlayerID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnPlayerIDPort(zPortID As String) As Long
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lReturn = MyCLng(rsPlayer!PlayerID)
    End If
    Set rsPlayer = Nothing
    
    lReturnPlayerIDPort = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnPlayerIDPort," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPortIDByPlayerName(zPlayerName As String) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!PortID)
    End If
    Set rsData = Nothing
    
    zReturnPortIDByPlayerName = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPortIDByPlayerName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPortIDByPlayerID(lPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsData = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!PortID)
    End If
    Set rsData = Nothing
    
    zReturnPortIDByPlayerID = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPortIDByPlayerID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Function zReturnPlayerNamePort(zPortID As String) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!PlayerName)
    End If
    Set rsData = Nothing
    
    zReturnPlayerNamePort = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPlayerNamePort," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnImmortalLevelPlayerID(lPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsData = MyDB.OpenRecordset("SELECT ImmortalLevel FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        lReturn = MyCLng(rsData!ImmortalLevel)
    End If
    Set rsData = Nothing
    
    lReturnImmortalLevelPlayerID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnImmortalLevelPlayerID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnStarshipCommandDelay(lPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    Dim rsPlayer As Recordset
    
    lReturn = 0
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT StarshipCommandDelay FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lReturn = MyCLng(rsPlayer!StarshipCommandDelay)
    End If
    Set rsPlayer = Nothing
    
    lReturnStarshipCommandDelay = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnStarshipCommandDelay," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnAreaID(lX As Long, lY As Long, lZ As Long) As Long
On Error GoTo Err_Check
    Dim rsWhere As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsWhere = MyDB.OpenRecordset("SELECT AreaID FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    If (Not rsWhere.EOF) Then
        lReturn = MyCLng(rsWhere!AreaID)
    End If
    Set rsWhere = Nothing
    
    lReturnAreaID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnAreaID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnWhereID(lX As Long, lY As Long, lZ As Long) As Long
On Error GoTo Err_Check
    Dim rsWhere As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsWhere = MyDB.OpenRecordset("SELECT WhereID FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    If (Not rsWhere.EOF) Then
        lReturn = MyCLng(rsWhere!WhereID)
    End If
    Set rsWhere = Nothing
    
    lReturnWhereID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnWhereID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnWhereNameXYZ(lX As Long, lY As Long, lZ As Long) As String
On Error GoTo Err_Check
    Dim rsWhere As Recordset
    Dim zReturn As String
    
    zReturn = ""
    Set rsWhere = MyDB.OpenRecordset("SELECT tblWhere.WhereTitle FROM tblArea INNER JOIN tblWhere ON tblArea.WhereID = tblWhere.WhereID WHERE (((tblArea.X)=" & lX & ") AND ((tblArea.Y)=" & lY & ") AND ((tblArea.Z)=" & lZ & "));", dbOpenSnapshot)
    If (Not rsWhere.EOF) Then
        zReturn = MyCStr(rsWhere!WhereTitle)
    End If
    Set rsWhere = Nothing
    
    zReturnWhereNameXYZ = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnWhereNameXYZ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnPlayerIDPlayerName(zPlayerName As String) As Long
On Error GoTo Err_Check
    Dim lPlayerID As Long
    Dim rsPlayer As Recordset
    
    lPlayerID = 0
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID FROM tblPlayer WHERE (((tblPlayer.PlayerName)='" & zPlayerName & "'));", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
    End If
    Set rsPlayer = Nothing
    
    lReturnPlayerIDPlayerName = lPlayerID
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnPlayerIDPlayerName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnPlayerIDPortID(zPortID As String) As Long
On Error GoTo Err_Check
    Dim lPlayerID As Long
    Dim rsPlayer As Recordset
    
    lPlayerID = 0
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
    End If
    Set rsPlayer = Nothing
    
    lReturnPlayerIDPortID = lPlayerID
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnPlayerIDPortID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnRandomSystemProtectedObjectID() As Long
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lSQLCount As Long
    Dim lReturn As Long
    
    lReturn = 0
    lSQLCount = lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE ((Status=2 or Status=3) AND SystemProtected<>0 AND MissileGroupAmount=0 AND SitMAX=0 AND CaptureFlagClanID=0 AND Cursed=0 AND PlayerID=0 AND ReturnPlayerID=0 AND ExplodeDuration=0 AND Location<>0);")
    Set rsObject = MyDB.OpenRecordset("SELECT TOP " & lRandom(lSQLCount) & " ObjectID FROM tblObject WHERE ((Status=2 or Status=3) AND SystemProtected<>0 AND MissileGroupAmount=0 AND SitMAX=0 AND CaptureFlagClanID=0 AND Cursed=0 AND PlayerID=0 AND ReturnPlayerID=0 AND ExplodeDuration=0 AND Location<>0);", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsObject.EOF) Then
        rsObject.MoveLast
        lReturn = MyCLng(rsObject!ObjectID)
    End If
    Set rsObject = Nothing
    
    lReturnRandomSystemProtectedObjectID = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnRandomSystemProtectedObjectID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnObjectIDWeight(lObjectID As Long) As Long
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    Set rsObject = MyDB.OpenRecordset("SELECT Weight FROM tblObject WHERE (ObjectID=" & lObjectID & ");", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsObject.EOF) Then
        lReturn = MyCLng(rsObject!Weight)
    End If
    Set rsObject = Nothing
    
    lReturnObjectIDWeight = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnObjectIDWeight," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPlayerName(lPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsPlayer.EOF) Then
        zReturn = MyCStr(rsPlayer!PlayerName)
    End If
    Set rsPlayer = Nothing
    
    zReturnPlayerName = zReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPlayerName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPlayerClass(lPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Class FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsPlayer.EOF) Then
        zReturn = MyCStr(rsPlayer!Class)
    End If
    Set rsPlayer = Nothing
    
    zReturnPlayerClass = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPlayerClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPlayerClassByPortID(lPortID As Long) As String
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Class FROM tblPlayer WHERE ([PortID]='" & MyCStr(lPortID) & "');", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsPlayer.EOF) Then
        zReturn = MyCStr(rsPlayer!Class)
    End If
    Set rsPlayer = Nothing
    
    zReturnPlayerClassByPortID = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPlayerClassByPortID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnObjectName(lObjectID As Long) As String
On Error GoTo Err_Check
    Dim rsObject As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsObject = MyDB.OpenRecordset("SELECT ObjectName FROM tblObject WHERE (ObjectID=" & lObjectID & ");", dbOpenSnapshot) 'Objects online can get hit in a lightning storm
    If (Not rsObject.EOF) Then
        zReturn = MyCStr(rsObject!ObjectName)
    End If
    Set rsObject = Nothing
    
    zReturnObjectName = zReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnObjectName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnMobLevel(lMobID As Long) As Long
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsMob = MyDB.OpenRecordset("SELECT MobLevel FROM tblMob WHERE (MobID=" & lMobID & ");", dbOpenSnapshot) 'Mobs online can get hit in a lightning storm
    If (Not rsMob.EOF) Then
        lReturn = MyCStr(rsMob!MobLevel)
    End If
    Set rsMob = Nothing
    
    lReturnMobLevel = lReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnMobLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lRandomMobID() As Long
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim lReturn As Long
    Dim lTotalMobs As Long
    lReturn = 0
    lTotalMobs = lngSQLRecordCount("SELECT MobID FROM tblMob;")
    If (lTotalMobs > 0) Then
        Set rsMob = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalMobs) & " MobID FROM tblMob;", dbOpenSnapshot) 'Mobs online can get hit in a lightning storm
        If (Not rsMob.EOF) Then
            rsMob.MoveLast
            lReturn = MyCLng(rsMob!MobID)
        End If
    Set rsMob = Nothing
    End If
    lRandomMobID = lReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "lRandomMobID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnMobName(lMobID As Long) As String
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsMob = MyDB.OpenRecordset("SELECT MobName FROM tblMob WHERE (MobID=" & lMobID & ");", dbOpenSnapshot) 'Mobs online can get hit in a lightning storm
    If (Not rsMob.EOF) Then
        zReturn = MyCStr(rsMob!MobName)
    End If
    Set rsMob = Nothing
    
    zReturnMobName = zReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnMobName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnPortID(lPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PortID FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsPlayer.EOF) Then
        zReturn = MyCStr(rsPlayer!PortID)
    End If
    Set rsPlayer = Nothing
    
    zReturnPortID = zReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnPortID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zPlayerNameByPortID(zPortID As String) As String
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot) 'Players online can get hit in a lightning storm
    If (Not rsPlayer.EOF) Then
        zReturn = MyCStr(rsPlayer!PlayerName)
    End If
    Set rsPlayer = Nothing
    
    zPlayerNameByPortID = zReturn 'Return strings 9 long and that is all
    Exit Function
Err_Check:
    subWriteErrorFile "zPlayerNameByPortID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateRequiredForNextLevel(lLevel As Long) As Long
On Error Resume Next
    Dim lReturn As Long
    Select Case lLevel
        Case 0
            lReturn = 1
        Case 1 To 9
            lReturn = (lLevel * (25 * lLevel)) + 1
        Case 10 To 19
            lReturn = lLevel * (50 * lLevel)
        Case 20 To 29
            lReturn = lLevel * (110 * lLevel)
        Case 30 To 49
            lReturn = lLevel * (120 * lLevel)
        Case 50 To 100 'little harder
            lReturn = lLevel * (145 * lLevel)
        Case 101 To 150 'harder
            lReturn = lLevel * (175 * lLevel)
        Case 151 To 200 'hard!
            lReturn = lLevel * (215 * lLevel)
        Case 201 To 265 'very hard!
            lReturn = lLevel * (265 * lLevel)
        Case Else 'HARDEST
            lReturn = (lLevel ^ 3)
    End Select
    lTranslateRequiredForNextLevel = lReturn
End Function
Public Function zTranslatePlayerGrip(lGrip As Long) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = "?grip?"
    Select Case lGrip
        Case 0 To 4
            zReturn = "training" 'loose grip
        Case 5 To 9
            zReturn = "relaxed"
        Case 10 To 14
            zReturn = "steady"
        Case 15 To 19
            zReturn = "firm"
        Case 20 To 24
            zReturn = "strong"
        Case 25 To 29
            zReturn = "iron"
        Case Else
            zReturn = "unbeatable" 'godly
    End Select
    
    zTranslatePlayerGrip = zReturn 'Return strings 9 long and that is all
End Function
Public Function zTranslateMatrixDirection(lTX As Long, lTY As Long, lTZ As Long, lOX As Long, lOY As Long, lOZ As Long, iType As Integer) As String
On Error Resume Next
'from the Original location the target location is the returned word
'Coding Warning: bAreaMovementAllowed will be affected if the return words are modified.
    Dim lDirX As Long
    Dim lDirY As Long
    Dim lDirZ As Long
    Dim zReturn As String
    
    lDirX = lTX - lOX
    If (lDirX > 1) Then
        lDirX = 1
    End If
    If (lDirX < -1) Then
        lDirX = -1
    End If
    
    lDirY = lTY - lOY
    If (lDirY > 1) Then
        lDirY = 1
    End If
    If (lDirY < -1) Then
        lDirY = -1
    End If
    
    lDirZ = lTZ - lOZ
    If (lDirZ > 1) Then
        lDirZ = 1
    End If
    If (lDirZ < -1) Then
        lDirZ = -1
    End If
    
    If (iType = 2) Then 'reverse directions
        lDirX = lDirX * -1
        lDirY = lDirY * -1
        lDirZ = lDirZ * -1
    End If
    
    'Debug.Print "lTX = " & lTX & " lTY = " & lTY & " lTZ = " & lTZ
    'Debug.Print "lOX = " & lOX & " lOY = " & lOY & " lOZ = " & lOZ
    'Debug.Print "lDirX = " & lDirX & " lDirY = " & lDirY & " lDirZ = " & lDirZ
    'Debug.Print "iType = " & iType
    
    zReturn = ""
    Select Case lDirX
        Case -1
            Select Case lDirY
                Case -1
                    zReturn = "northwest"
                Case 0
                    zReturn = "west"
                Case 1
                    zReturn = "southwest"
            End Select
        Case 0 'No X movement
            Select Case lDirY
                Case -1
                    zReturn = "north"
                Case 0 'No Y movement
                    Select Case lDirZ
                        Case -1
                            zReturn = "above"
                        Case 1
                            zReturn = "below"
                        Case 0 'There is where you are standing
                            zReturn = ""
                    End Select
                Case 1
                    zReturn = "south"
            End Select
        Case 1
            Select Case lDirY
                Case -1
                    zReturn = "northeast"
                Case 0
                    zReturn = "east"
                Case 1
                    zReturn = "southeast"
            End Select
    End Select
    'Now we check for up and direction and down and direction and other illegal movements
    'A mob cannot go down or up and then to an angle
    'Players and mobs can only go one direction at a time!
    If (lDirX <> 0 And lDirZ <> 0) Then
        zReturn = ""
    End If
    If (lDirY <> 0 And lDirZ <> 0) Then
        zReturn = ""
    End If
    zTranslateMatrixDirection = zReturn
End Function
Public Function zDoorHasWindowIndicator(iType As Integer) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    Select Case iType
        Case 0
            zReturn = "This door is solid."
        Case 1
            zReturn = "This door has a barred window. You can PEEK DIRECTION to see in."
        Case 2
            zReturn = "This door has a glass window. You can PEEK DIRECTION to see in."
        Case 3
            zReturn = "This door has an arrow hole you can see through. You can PEEK DIRECTION to see in."
        Case Else
            zReturn = "This door has a dungeon window. You can PEEK DIRECTION to see in."
    End Select
    zDoorHasWindowIndicator = zReturn
End Function
Public Function zLockIndicator(iStatus As Integer) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    Select Case iStatus '0 = Always Open, 1 = Unlocked, 2 = Locked, 3=open but is locakable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and not lockable, 7 = Bashed closed
        Case 0
            zReturn = "The door is open."
        Case 1
            zReturn = "The door is unlocked."
        Case 2
            zReturn = "The door is closed and locked."
        Case 3
            zReturn = "The door is open and lockable."
        Case 4
            zReturn = "The door is magically sealed."
        Case 5 'this is the same as 0=Always Open just a fun desc.
            zReturn = "Has a broken lock from being bashed in along time ago."
        Case 6
            zReturn = "The door is closed and not locked."
        Case 7
            zReturn = "The door is bashed closed."
    End Select
    zLockIndicator = zReturn
End Function
Public Function bVerifyWeaponType(zType As String) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    bReturn = False
    Select Case UCase(Mid(zType, 1, 4))
        Case "JAVI"
            bReturn = True
        Case "SPEA"
            bReturn = True
        Case "SAXE"
            bReturn = True
        Case "GAXE" 'great axe
            bReturn = True
        Case "SSTA" 'short staff
            bReturn = True
        Case "LSTA" 'long staff
            bReturn = True
        Case "BLUD" 'Bludgeons
            bReturn = True
        Case "FLEX" 'Flexible arms
            bReturn = True
        Case "LBLA" 'Long Blades
            bReturn = True
        Case "SBLA" 'Short Blades
            bReturn = True
        Case "PUGI" 'Pugilism
            bReturn = True
        Case "TALO" 'Talonous
            bReturn = True
        Case "POLE" 'Polearms
            bReturn = True
        Case "LANC" 'Lance
            bReturn = True
        Case "NET" 'Netting with ENSNARE
            bReturn = True
        Case "SLIN" 'Sling
            bReturn = True
        Case "STON" 'Stones for slings
            bReturn = True
        Case "XBOW" 'crossbow
            bReturn = True
        Case "BOLT" 'Bolts for crossbows
            bReturn = True
        Case "BOW" 'bow
            bReturn = True
        Case "ARRO" 'Arrows for bows
            bReturn = True
        Case "PHAS" 'Phaser
            bReturn = True
        Case "BLAS", "ENER" 'blasting energy
            bReturn = True
        Case "MGUN" 'Machine Gun - this uses its own ammo not a secondary, however it needs to use a reload clip object.AmmoAmount or osmething like that
            bReturn = True
        Case "CLIP", "AMMO" 'Machine Gun - this uses its own ammo not a secondary, however it needs to use a reload clip object.AmmoAmount or osmething like that
            bReturn = True
    End Select
    
    bVerifyWeaponType = bReturn
End Function
Public Sub subInitCombat()
On Error Resume Next
    Dim iCount As Integer
    For iCount = cstlMinPort To cstlMaxPort
        gbllQuestCounter(iCount) = 0
        gbllRumorCounter(iCount) = 0
        rMCombat(iCount).lID = 0     'refresh
        rPCombat(iCount).lID = 0     'refresh
        rSCombat(iCount).iStatus = 0 'mark all combat cells as available
    Next iCount
    'Messages during battle:
    'You are already trying to stun you cannot punch at the same time
    'Your shields repel X amount of damage from that blow.
    'Note:
    'combat is completely automated the player can do these
    'FLEE, BERSERK, STUN, HEADBUTT, PUNCHL, PUNCHR, KICKL, KICKR, TRIP
    'BLIND OPPONENT, and lastly they can cast their attack or heal spells.
End Sub
Public Function zTranslateObjectLockIndicator(iType As Integer) As String
On Error Resume Next
    Dim zReturn As String
    Select Case iType
        Case 10
            zReturn = "is open."
        Case 20
            zReturn = "is open and is unlocked."
        Case 21
            zReturn = "is closed and unlocked."
        Case 22
            zReturn = "is closed and locked."
        Case 30
            zReturn = "is open and has a combination lock."
        Case 31
            zReturn = "is closed and has a combination lock."
        Case 32
            zReturn = "is closed and is combination locked."
        Case 40
            zReturn = "has a latch that is bent and doesn't quite open all the way."
        Case 41
            zReturn = "has a latch that is bent and doesn't quite shut all the way."
    End Select
    zTranslateObjectLockIndicator = zReturn
End Function
Public Function zTranslateWeaponTypes(zType As String) As String
Dim zReturn As String
    zReturn = "bare hands"
    Select Case zType
        Case "JAVI"
            zReturn = "Javelin"
        Case "SPEA"
            zReturn = "Spear"
        Case "SAXE"
            zReturn = "Small Axe"
        Case "GAXE" 'great axe
            zReturn = "Great Axe"
        Case "BLUD"
            zReturn = "Bludgeon"
        Case "SBLA"
            zReturn = "Short Blade"
        Case "LBLA"
            zReturn = "Long Blade"
        Case "SSTA"
            zReturn = "Short Staff"
        Case "LSTA"
            zReturn = "Long Staff"
        Case "FLEX"
            zReturn = "Flexible"
        Case "PUGI"
            zReturn = "Pugilism"
        Case "TALO"
            zReturn = "Talonous arm"
        Case "POLE"
            zReturn = "Polearm"
        Case "LANC"
            zReturn = "Lance"
        Case "SLIN"
            zReturn = "Sling"
        Case "BOW"
            zReturn = "Bow"
        Case "XBOW"
            zReturn = "Crossbow"
        Case "NET"
            zReturn = "Net"
        Case "BOLT" 'these last two are used with the tblObject.MissileMissileGroupAmount so a player can carry many bolts and arrows.
            zReturn = "Bolt"
        Case "ARRO"
            zReturn = "Arrow"
        Case "STON"
            zReturn = "Stone"
        Case "PHAS"
            zReturn = "Phaser"
        Case "MGUN"
            zReturn = "Machine Gun"
        Case "ENER", "BLAS"
            zReturn = "Blasting Energy"
        Case "CLIP", "AMMO"
            zReturn = "Ammo Clip"
    End Select
    zTranslateWeaponTypes = zReturn
End Function
Public Sub subCutTo(ByRef zCutSentence As String, ByRef zLine As String, zStopPattern As String)
On Error GoTo Err_Check
    zCutSentence = ""
    If (InStr(zLine, zStopPattern) > 0) Then
        zCutSentence = MyCStr(Mid(zLine, 1, InStr(zLine, zStopPattern) - 1)) 'We extract the part we need
        zLine = MyCStr(Mid(zLine, InStr(zLine, zStopPattern) + 1)) 'We cut out what we took
    Else
        zCutSentence = MyCStr(zLine)
        zLine = ""
    End If
    Exit Sub
Err_Check:
End Sub
Public Function zTranslateHealth(lCHealth As Long, lMHealth As Long) As String
On Error Resume Next
    Dim zReturn As String
    Dim iRatio As Integer 'holds -3 to 101
    
    zReturn = ""
    'Current health ratio with maximum health
    If (lMHealth <> 0) Then
        iRatio = Round((lCHealth * 100) / lMHealth)
        If (iRatio < -3) Then iRatio = -3
        If (iRatio > 100) Then iRatio = 101
        Select Case iRatio 'put either: (persons name) or (he/she) muse work in front of the following:
            Case -3 'a player actually dies at -4
                zReturn = "is knocking on death's door, and cannot be saved"
            Case -2
                zReturn = "is unconscious, and cannot be saved"
            Case -1
                zReturn = "is unconscious, and may recover"
            Case 0
                zReturn = "is unconscious, and is recovering"
            Case 1 To 2
                zReturn = "is leaking guts"
            Case 3 To 5
                zReturn = "is almost dead"
            Case 6 To 10
                zReturn = "is dying"
            Case 11 To 15
                zReturn = "is bleeding to death"
            Case 16 To 20
                zReturn = "is mortally wounded"
            Case 21 To 25
                zReturn = "is covered in blood from deep war wounds"
            Case 26 To 30
                zReturn = "is blood soaked from many deep battle wounds"
            Case 31 To 35
                zReturn = "is losing blood from many battle wounds"
            Case 36 To 40
                zReturn = "is dripping blood from a few battle wounds"
            Case 41 To 45
                zReturn = "is dripping blood from many gashes"
            Case 46 To 50
                zReturn = "leaking blood from a few gashes"
            Case 51 To 55
                zReturn = "is heavily wounded"
            Case 56 To 60
                zReturn = "has horrible injuries"
            Case 61 To 65
                zReturn = "has terrible injuries"
            Case 66 To 70
                zReturn = "has a few cuts and wounds"
            Case 71 To 75
                zReturn = "has a few gashes"
            Case 76 To 80
                zReturn = "has a few deep cuts"
            Case 81 To 85
                zReturn = "has a few cuts and is badly bruised"
            Case 86 To 90
                zReturn = "has a few scratches and discoloured bruises"
            Case 91 To 95
                zReturn = "has a few scratches and light bruising"
            Case 96
                zReturn = "has some light scratches"
            Case 97
                zReturn = "is in fair condition"
            Case 98
                zReturn = "is in good condition"
            Case 99
                zReturn = "is in excellent condition"
            Case 100
                zReturn = "is in perfect health"
            Case 101
                zReturn = "is in exceptional health"
        End Select
    End If
    zTranslateHealth = zReturn
End Function
Public Function lRunningNumberOfDays(zType As String) As Long
On Error Resume Next
    'This will tell the player how long the mud has been running for in mud days
    'zType "Y" returns year, "D" days, "M" month, "S" season you are in
    Const cstzDate = "Aug 01 2002"
    Const cstlMudDays = 24
    Const cstlMudYears = 14 'never 0!
    Dim lReturn As Long
    
    lReturn = DateDiff("D", cstzDate, Date) 'this is already in months
    Select Case UCase(Mid(zType, 1, 1))
        Case "S"
            lReturn = MyCLng(lReturn / cstlMudYears)
        Case "Y"
            lReturn = MyCLng(lReturn / cstlMudYears)
        Case "D" 'days
            lReturn = (lReturn * cstlMudDays)
    End Select
    If (lReturn < 0) Then lReturn = 1 'we have to have a starting day. This is the first day, first year, of creation!
    lRunningNumberOfDays = lReturn
End Function
Public Function iDayCode() As Integer
'see also: subSendWhereMessageAllPlayers
On Error Resume Next
    Dim iReturn As Integer
    Select Case MyCInt(Format(Time(), "NN"))
        'Midnight
        Case 58 To 60, 0 To 1 '60 isnt used but its here just in case
            iReturn = 10
        Case 2 To 3
            iReturn = 11
        'Dawn
        Case 4 To 12
            iReturn = 13
        'Morning
        Case 13 To 21
            iReturn = 15
        'Noon
        Case 22 To 30
            iReturn = 20
        'Afternoon
        Case 31 To 34
            iReturn = 25
        Case 35 To 39
            iReturn = 26
        'Evening
        Case 40 To 45
            iReturn = 30
        Case 46 To 48
            iReturn = 31
        'Dusk
        Case 49 To 57
            iReturn = 35
    End Select
    iDayCode = iReturn
End Function
Public Function zSeasonCode() As String
On Error Resume Next
    Dim zReturn As String
    Select Case MyCInt(Format(Date, "d"))
        Case 1 To 6
            zReturn = "Spring"
        Case 7
            zReturn = "Warm Spring"
        Case 8 To 14
            zReturn = "Summer"
        Case 15 To 17
            zReturn = "Warm Fall"
        Case 18 To 20
            zReturn = "Cool Fall"
        Case 21
            zReturn = "Cold Fall"
        Case 22 To 26, 28 To 31
            zReturn = "Winter"
        Case 27
            zReturn = "Freezing Winter"
    End Select
    zSeasonCode = zReturn
End Function
Public Function zSeasonDescriptionCode() As String
On Error Resume Next
    Const cstlMudDays = 24
    Const cstlMudYears = 14 'never 0!
    Dim zDayResult As String
    Dim zReturn As String
    
    '1 To 6             Spring
    '7                  Warm Spring
    '8 To 14            Summer
    '15 To 17           Warm Fall
    '18 To 20           Cool Fall
    '21                 Cold Fall
    '22 To 26, 28 To 31 Winter
    '27                 Freezing Winter
    
    Select Case MyCInt(Format(Date, "d"))
        Case 1, 2
            zReturn = "Zelisan"
        Case 3, 4
            zReturn = "Halnii"
        Case 5, 6
            zReturn = "Tathar"
        Case 7, 8
            zReturn = "Aestas"
        Case 9, 10
            zReturn = "Caliga"
        Case 11, 12
            zReturn = "Ordino"
        Case 13, 14
            zReturn = "Nemorosus"
        Case 15, 16
            zReturn = "Umbra"
        Case 17, 18
            zReturn = "Cesura"
        Case 19, 20
            zReturn = "Opulentia"
        Case 21, 22
            zReturn = "Priscus"
        Case 23, 24
            zReturn = "Illac"
        Case 25, 26
            zReturn = "Atraluna"
        Case 27, 28
            zReturn = "Venosis"
        Case 29, 30
            zReturn = "Khear"
        Case 31
            zReturn = "Solotis"
    End Select
    
    Select Case MyCLng(Format(Time(), "HH")) + 1
        Case 1
            zDayResult = "1st"
        Case 2
            zDayResult = "2nd"
        Case 3
            zDayResult = "3rd"
        Case 21
            zDayResult = "21st"
        Case 22
            zDayResult = "22nd"
        Case 23
            zDayResult = "23rd"
        Case 31
            zDayResult = "31st"
        Case 32
            zDayResult = "32nd"
        Case 33
            zDayResult = "33rd"
        Case Else
            zDayResult = MyCLng(Format(Time(), "HH")) + 1 & "th"
    End Select
    
    zSeasonDescriptionCode = zSeasonCode() & " - " & zDayResult & " day of " & zReturn
End Function
Public Sub subSendWhereMessageAllPlayers()
On Error GoTo Err_Check
    Const zS = "&a[{"
    Const zE = "&a}]"
    Dim iHoldDayCode As Integer
    Dim zClass As String 'Some Classes cook under the sun like Vampyres, or stronger at night like Vamps Werewolves
    Dim zRace As String
    Dim lCHP As Long
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim rsArea As Recordset
    Dim rsWhere As Recordset
    Dim rsMob As Recordset
    Dim lMobID As Long
    Dim zLine As String
    Dim lAreaHotCold As Long
    Dim lHoldPlayerWarmEQ As Long
    Dim zPortID As String
'        Case 58 To 60, 0 To 1 '60 isnt used but its here just in case
'            iRvgeturn = 10
'        Case 2 To 3
'            iReturn = 11
'        'Dawn
'        Case 4 To 12
'            iReturn = 13
'        'Morning
'        Case 13 To 21
'            iReturn = 15
'        'Noon
'        Case 22 To 30
'            iReturn = 20
'        'After noon
'        Case 31 To 34
'            iReturn = 25
'        Case 35 To 39
'            iReturn = 26
'        'Evening
'        Case 40 To 45
'            iReturn = 30
'        Case 46 To 48
'            iReturn = 31
'        'Dusk
'        Case 49 To 57
'            iReturn = 35
    
    iHoldDayCode = iDayCode()
    
    Set rsWhere = MyDB.OpenRecordset("SELECT tblPlayer.PlayerID, tblPlayer.Race, tblPlayer.Class, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, tblPlayer.PortID, tblPlayer.CHP, tblWhere.* FROM tblPlayer INNER JOIN tblWhere ON tblPlayer.WhereID = tblWhere.WhereID WHERE (((tblPlayer.PortID) Is Not Null And (tblPlayer.PortID)<>'' And (tblPlayer.PortID)<>'0')) ORDER BY tblWhere.WhereID;", dbOpenSnapshot)
    Do While (Not rsWhere.EOF)
        lPlayerID = MyCLng(rsWhere!PlayerID)
        lCHP = MyCLng(rsWhere!CHP)
        zClass = MyCStr(rsWhere!Class)
        zRace = MyCStr(rsWhere!Race)
        zPortID = MyCStr(rsWhere!PortID)
        Select Case iHoldDayCode
            Case 10
                zLine = MyCStr(rsWhere!WhereMidnight)
                If (Len(zLine) > 0) Then subSendMsg zS & "&A" & zLine & zE, zPortID
            Case 11
                zLine = MyCStr(rsWhere!WhereLateMorning)
                If (Len(zLine) > 0) Then subSendMsg zS & "&m" & zLine & zE, zPortID
            Case 13
                zLine = MyCStr(rsWhere!WhereDawn)
                If (Len(zLine) > 0) Then subSendMsg zS & "&M" & zLine & zE, zPortID
            Case 15
                zLine = MyCStr(rsWhere!WhereMorning)
                If (Len(zLine) > 0) Then subSendMsg zS & "&y" & zLine & zE, zPortID
            Case 20
                zLine = MyCStr(rsWhere!WhereNoon)
                If (Len(zLine) > 0) Then subSendMsg zS & "&Y" & zLine & zE, zPortID
            Case 25
                zLine = MyCStr(rsWhere!WhereAfternoon)
                If (Len(zLine) > 0) Then subSendMsg zS & "&W" & zLine & zE, zPortID
            Case 26
                zLine = MyCStr(rsWhere!WhereLateAfternoon)
                If (Len(zLine) > 0) Then subSendMsg zS & "&w" & zLine & zE, zPortID
            Case 30
                zLine = MyCStr(rsWhere!WhereEvening)
                If (Len(zLine) > 0) Then subSendMsg zS & "&B" & zLine & zE, zPortID
            Case 31
                zLine = MyCStr(rsWhere!WhereLateEvening)
                If (Len(zLine) > 0) Then subSendMsg zS & "&b" & zLine & zE, zPortID
            Case 35
                zLine = MyCStr(rsWhere!WhereDusk)
                If (Len(zLine) > 0) Then subSendMsg zS & "&r" & zLine & zE, zPortID
        End Select
        
        If (lRandom(5) = 1) Then
            MyDB.Execute "UPDATE tblDoor SET BashDoorTries=0 WHERE BashDoorTries>0;" 'Fix all bashed in doors
        End If
        
        If (lCHP > 100) Then
            lHoldPlayerWarmEQ = lPlayerWarmEQ(lPlayerID)
            '0=not shaded 1=freezing cold not shaded // SHADED + Roof&Area is ( 9=shaded and wet 10=leaf shaded 20=Wooden 21=Brick/Rock 22=Concrete Roof 23=jiprock 29=Tin 30=cavern 31=alien)
            'lAreaHotCold if negative means its a COLD area and positive value makes it a HOT area
            If (zClass <> "VA" And zClass <> "WE" And zClass <> "CY" And zRace <> "UND") Then
                Set rsArea = MyDB.OpenRecordset("SELECT tblPlayer.PlayerID, tblPlayer.Class, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, tblPlayer.CHP, tblPlayer.PortID, tblArea.AreaHotCold, tblArea.AreaType FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X) WHERE (tblPlayer.PlayerID=" & lPlayerID & " AND tblArea.AreaType=1);", dbOpenSnapshot)
                If (Not rsArea.EOF) Then
                    lAreaHotCold = (MyCLng(rsArea!AreaHotCold) + lHoldPlayerWarmEQ)
                    If (lAreaHotCold < -3 Or lAreaHotCold > 5) Then
                        lCHP = lCHP - (100 * (Abs(lAreaHotCold) - 2))
                        subSendMsg "&RYou are uncomfortable! [" & (100 * (Abs(lAreaHotCold) - 2)) & "]", MyCStr(rsWhere!PortID)
                    End If
                    lCHP = lCHP - (MyCLng(lRandom(lCHP)) / (1 + lRandom(3)))
                    If (lCHP < 1) Then lCHP = 1 'just for extra code protection
                    If (lHoldPlayerWarmEQ < lAreaHotCold) Then
                        subSendMsg "&WIt is cold out but you are nice and warm.", MyCStr(rsWhere!PortID)
                    Else
                        subSendMsg "&WFrost Bite!! Its freezing cold here!" & vbCrLf & "You need to wear five fuzzy warm items to be comfortable!", MyCStr(rsWhere!PortID)
                        MyDB.Execute "UPDATE tblPlayer SET CHP=" & lCHP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                    End If
                End If
                Set rsArea = Nothing
            End If

            Select Case iHoldDayCode
                Case 15, 20, 25, 26 'Day time is bad for Vampyres and Werewolves
                    Select Case zClass
                        Case "VA" 'heat only affects
                            Set rsArea = MyDB.OpenRecordset("SELECT tblPlayer.PlayerID, tblPlayer.Class, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, tblPlayer.CHP, tblPlayer.PortID, tblArea.AreaHotCold, tblArea.AreaType FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X) WHERE (tblPlayer.PlayerID=" & lPlayerID & " AND tblArea.AreaType=0);", dbOpenSnapshot)
                            If (Not rsArea.EOF) Then
                                lAreaHotCold = (MyCLng(rsArea!AreaHotCold) + lHoldPlayerWarmEQ)
                                If (lAreaHotCold < -3 Or lAreaHotCold > 5) Then
                                    lCHP = lCHP - (100 * (Abs(lAreaHotCold) - 2))
                                    subSendMsg "&RYou are uncomfortable! [" & (100 * (Abs(lAreaHotCold) - 2)) & "]", MyCStr(rsWhere!PortID)
                                End If
                                lCHP = lCHP - (MyCLng(lRandom(lCHP)) / (2 + lRandom(3)))
                                If (lCHP < 1) Then lCHP = 1 'just for extra code protection
                                subSendMsg "&YSiZZle! &RYEEEOUCH! &yYou are frying in the sun!", MyCStr(rsWhere!PortID)
                                MyDB.Execute "UPDATE tblPlayer SET CHP=" & lCHP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            End If
                            Set rsArea = Nothing
                        Case "WE" 'heat only affects
                            Set rsArea = MyDB.OpenRecordset("SELECT tblPlayer.PlayerID, tblPlayer.Class, tblPlayer.X, tblPlayer.Y, tblPlayer.Z, tblPlayer.CHP, tblPlayer.PortID, tblArea.AreaHotCold, tblArea.AreaType FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X) WHERE (tblPlayer.PlayerID=" & lPlayerID & " AND tblArea.AreaType=0);", dbOpenSnapshot)
                            If (Not rsArea.EOF) Then
                                lAreaHotCold = (MyCLng(rsArea!AreaHotCold) + lHoldPlayerWarmEQ)
                                If (lAreaHotCold < -3 Or lAreaHotCold > 5) Then
                                    lCHP = lCHP - (100 * (Abs(lAreaHotCold) - 2))
                                    subSendMsg "&RYou are uncomfortable! [" & (100 * (Abs(lAreaHotCold) - 2)) & "]", MyCStr(rsWhere!PortID)
                                End If
                                lCHP = lCHP - (MyCLng(lRandom(lCHP)) / (4 + lRandom(3)))
                                If (lCHP < 1) Then lCHP = 1 'just for extra code protection
                                subSendMsg "&YOWE! &ROOOOHhh! &yThe sun burns your skin, your fur provides some protection!", MyCStr(rsWhere!PortID)
                                MyDB.Execute "UPDATE tblPlayer SET CHP=" & lCHP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            End If
                            Set rsArea = Nothing
                    End Select
            End Select
        End If
        rsWhere.MoveNext
    Loop
    Set rsWhere = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subSendWhereMessageAllPlayers," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalSpellZAPPlayer(zPlayerName As String, lType As Long, zPortID As String)
On Error GoTo Err_Check
'see also subWeatherLightningStrikeAllPlayerOnline
    Dim rsPlayer As Recordset
    Dim lShowValue As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, ShadowCloakDuration, Status, PortID, PlayerID, StunDuration, BlindDuration, PlayerName, PortID, Gold, X, Y, Z, RecallX, RecallY, RecallZ, CHP FROM tblPlayer WHERE (ImmortalLevel<100 AND PlayerName='" & zAntiSQLCrash(zPlayerName) & "');", dbOpenDynaset) 'high immortals are immune to hell and heaven
    If (Not rsPlayer.EOF) Then
        subCombatEndedInitializeCombatCellsPortID MyCLng(rsPlayer!PortID)
        Select Case lType
            Case 1
                subImmortalTeaseChannelAll MyCStr(rsPlayer!PortID), "ITC &RA fireball is heard exploding somewhere in the " & zWhereName(MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z)) & "!"
            Case 2
                subImmortalTeaseChannelAll MyCStr(rsPlayer!PortID), "ITC &WA lightning bolt shoots out of the heavens and towards the " & zWhereName(MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z)) & "!"
            Case 3, 4
                subImmortalTeaseChannelAll MyCStr(rsPlayer!PortID), "ITC &CYou see &Wlightning &YFORK &Cin mid-air over the " & zWhereName(MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z)) & " &Cbefore &YSTRIKING &Wthe ground!"
                If (MyCLng(rsPlayer!Gold) > 0) Then
                    subDropGold MyCStr(rsPlayer!PlayerName) & "'s " & MyCStr(MyCLng(rsPlayer!Gold)) & " {{M E L T E D}} gold, is a rock here on the ground", MyCLng(rsPlayer!PlayerID), MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), MyCLng(rsPlayer!Gold)
                End If
        End Select
        
        rsPlayer.Edit
        rsPlayer!ShadowCloakDuration = 0
        Select Case lType
            Case 1
                'fireball Title/Desc is the TITLE and DESC commands - they also have colour and players can be profanic
                rsPlayer!StunDuration = 5
                rsPlayer!BlindDuration = 1
                rsPlayer!Status = 15 'rest position
                rsPlayer!CHP = MyCLng(rsPlayer!CHP / 2) + 1
                subSendMsg "&RA fireball *EXPLODES* against you!", MyCStr(rsPlayer!PortID) 'morning
                subSendMsgAreaExcept2 "&RA fireball *EXPLODES* against " & MyCStr(rsPlayer!PlayerName) & "!", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), MyCLng(rsPlayer!PortID), ""
                subSendMsg "&wYou set Title/Desc" & lShowValue & "lv CHP/2+Rest+5 Stun Duration, 1 Blind Duration.", zPortID
            Case 2
                'bolt of lightning
                rsPlayer!StunDuration = 50
                rsPlayer!BlindDuration = 10
                rsPlayer!Status = 15 'rest position
                rsPlayer!CHP = MyCLng(rsPlayer!CHP / 2) + 1
                subSendMsg "&WA bolt of lightning ~ELECTRIFIES~ you!", MyCStr(rsPlayer!PortID)  'morning
                subSendMsgAreaExcept2 gblzFBWHI & "A bolt of lightning ~ELECTRIFIES~ " & MyCStr(rsPlayer!PlayerName) & "!", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), MyCLng(rsPlayer!PortID), ""
                subSendMsg "&wYou set Title/Desc" & lShowValue & "lv CHP/2+Rest+50 Stun Duration, 10 Blind Duration.", zPortID
            Case 3
                'Heaven
                subSendMsg "&WPUNISHING LIGHTNING &BFROM HEAVEN STRIKES YOU &RDEAD!", MyCStr(rsPlayer!PortID)
                subSendMsgAreaExcept2 gblzFBWHI & "PUNISHING LIGHTNING &RSENDS " & MyCStr(rsPlayer!PlayerName) & " TO HEAVEN!", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), MyCLng(rsPlayer!PortID), ""
                subSendMsg "&wYou added CHP=1 + Sleep + Heaven + Gold Melted + 5 Stun Duration, 2 Blind Duration.", zPortID
                rsPlayer!x = 0
                rsPlayer!y = 0
                rsPlayer!z = -2
                rsPlayer!RecallX = 0
                rsPlayer!RecallY = 0
                rsPlayer!RecallZ = 0
                rsPlayer!StunDuration = MyCLng(rsPlayer!StunDuration) + 5
                rsPlayer!BlindDuration = MyCLng(rsPlayer!BlindDuration) + 2
                rsPlayer!Status = 50 'Sleep position
                rsPlayer!CHP = 1
            Case 4
                'Hell
                subSendMsg "&WPUNISHING LIGHTNING &RSTRIKES YOU TO HAYDES!", MyCStr(rsPlayer!PortID)
                subSendMsgAreaExcept2 gblzFBWHI & "PUNISHING LIGHTNING &RSENDS " & MyCStr(rsPlayer!PlayerName) & " TO HAYDES!" & vbCrLf & "&w(You will be stunned for about 10 minutes)", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), MyCLng(rsPlayer!PortID), ""
                subSendMsg "&wYou added CHP=1 + Sleep + Hell + Gold Melted + 50 Stun Duration, +15 Blind Duration.", zPortID
                rsPlayer!x = 0
                rsPlayer!y = 0
                rsPlayer!z = 10
                rsPlayer!RecallX = 0
                rsPlayer!RecallY = 0
                rsPlayer!RecallZ = 10
                rsPlayer!StunDuration = MyCLng(rsPlayer!StunDuration) + 50
                rsPlayer!BlindDuration = MyCLng(rsPlayer!BlindDuration) + 15
                rsPlayer!Status = 50 'Sleep position
                rsPlayer!CHP = 1
        End Select
        rsPlayer.Update
        subSendMsg "&r(EYE) &g" & MyCStr(rsPlayer!PlayerName) & " status, CHP(" & MyCLng(rsPlayer!CHP) & ") StunDuration(" & MyCLng(rsPlayer!StunDuration) & ") BlindDuration(" & MyCLng(rsPlayer!BlindDuration) & ") Port(" & rsPlayer!PortID & ")", zPortID
    Else
        subSendMsg "&gPlayer name not found online.", zPortID
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalSpellZAPPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zRandomBirdName() As String
On Error GoTo Err_Check
    Dim zReturn As String
    Select Case lRandom(10)
        Case 1
            zReturn = "crow"
        Case 2
            zReturn = "albatross"
        Case 3
            zReturn = "pigeon"
        Case 4
            zReturn = "raven"
        Case 5
            zReturn = "seagull"
        Case 6
            zReturn = "robin"
        Case 7
            zReturn = "sparrow"
        Case 8
            zReturn = "hawk"
        Case 9
            zReturn = "vulture"
        Case 10
            zReturn = "parrot"
        Case Else
            zReturn = "hawk"
    End Select
    zRandomBirdName = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zRandomBirdName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zRandomBirdResult() As String
On Error GoTo Err_Check
    Dim zReturn As String
    Select Case lRandom(12)
        Case 1
            zReturn = "is flying overhead."
        Case 2
            zReturn = "is flying high overhead."
        Case 3
            zReturn = "is flying low but out of reach."
        Case 4
            zReturn = "is flying in the area."
        Case 5
            zReturn = "is flying over the northern part of the room."
        Case 6
            zReturn = "is flying over the southern part of the room."
        Case 7
            zReturn = "is flying over the eastern part of the room."
        Case 8
            zReturn = "is flying over the western part of the room."
        Case 9
            zReturn = "calls out while circling overhead!"
        Case 10
            zReturn = "landed on a branch of a nearby tree."
        Case 11
            zReturn = "is circling high overhead."
        Case 12
            zReturn = "is hidden in a nearby tree and calls out!"
        Case Else
            zReturn = "is flying overhead."
    End Select
    zRandomBirdResult = "To your surprize, a " & zRandomBirdName() & " " & zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zRandomBirdResult," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subFlyingBirdReality(lChance As Long)
On Error GoTo Err_Check
    'This is just for athetic purposes to add depth to the storyline and give out a glory
    Dim rsPlayer As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lTotalOnline As Long
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim zLine As String
    
    If (lRandom(lChance) = 1) Then 'we allow offline players to get it too
        lTotalOnline = lngSQLRecordCount("SELECT PlayerID FROM tblPlayer;")
        If (lTotalOnline > 0) Then
            Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lTotalOnline) & " PlayerID, PlayerName, X, Y, Z, PortID FROM tblPlayer;", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                rsPlayer.MoveLast
                lX = MyCLng(rsPlayer!x)
                lY = MyCLng(rsPlayer!y)
                lZ = MyCLng(rsPlayer!z)
                lPlayerID = MyCLng(rsPlayer!PlayerID)
                zPlayerName = MyCStr(rsPlayer!PlayerName)
                zLine = zRandomBirdResult()
                subSendMsgAreaAll "&M" & zLine, lX, lY, lZ
                MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                subSendMsgInfoChannel "[" & zWhereName(lX, lY, lZ) & "&g] &w" & zPlayerName & " &a[bird watcher] " & zFormatGoldCofGLearnpts(1, "c", False)
            End If
            Set rsPlayer = Nothing
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subFlyingBirdReality," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subShowStargateMagicWordAreaLocHints(zReportTitle As String, zPortID As String)
On Error GoTo Err_Check
    Const zcstFileName = "coaREPORT-subShowStargateMagicWordAreaLocHints.txt"
    Dim rsLoc As Recordset
    Dim rsSearch As Recordset
    Dim lSX As Long
    Dim lSY As Long
    Dim lSZ As Long
    Dim zSearch As String
    Dim zSQL As String
    Dim zPrint As String
    Dim iFileNo As Integer
    
    iFileNo = FreeFile 'open the file for writing
    Open zcstFileName For Output As #iFileNo 'create/overwrite file
    subSendMsg "&WW O R K I N G..." & zReportTitle, zPortID
    subSendMsg "&WCreating Filename '" & zcstFileName & "'", zPortID
    
    DoEvents: basDelay 3000: DoEvents
    Print #iFileNo, zReportTitle & vbCrLf & "********************************************************************************" & vbCrLf
    
    Print #iFileNo, "S T A R G A T E  C H E V R O N  R U N E S"
    Set rsSearch = MyDB.OpenRecordset("SELECT StargateRunes FROM tblObject WHERE (StargateRunes<>'' And StargateRunes Is Not Null) ORDER BY StargateRunes;", dbOpenSnapshot) 'Level to receive
    Do While (Not rsSearch.EOF)
        zSearch = MyCStr(rsSearch!StargateRunes)
        Print #iFileNo, "Stargate Chevron Rune [" & zSearch & "]"
        zSQL = "SELECT AreaName, AreaDescDay, AreaDescNight, X, Y, Z, AreaID FROM tblArea WHERE (AreaName Like '*" & zSearch & "*' OR AreaDescDay Like '*" & zSearch & "*' OR AreaDescNight Like '*" & zSearch & "*');"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   SG-CR-Area Desc @ [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        
        zSQL = "SELECT ObjectName, ObjectDesc, X, Y, Z, ObjectID FROM tblObject WHERE (ObjectName Like '*" & zSearch & "*' OR ObjectDesc Like '*" & zSearch & "*');"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   SG-CR-Object Desc [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        
        zSQL = "SELECT MobName, MobDesc, X, Y, Z, MobID FROM tblMob WHERE (MobName Like '*" & zSearch & "*' OR MobDesc Like '*" & zSearch & "*');"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   SG-CR-Mob Desc [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        rsSearch.MoveNext
        
        zSQL = "SELECT tblMobQuestObject.FinishQuestEmote1, tblMobQuestObject.FinishQuestMessage1, tblMobQuestObject.FinishQuestEmote2, tblMobQuestObject.FinishQuestMessage2, tblMobQuestObject.FinishQuestEmote3, tblObject.X, tblObject.Y, tblObject.Z, tblObject.ObjectID FROM tblObject INNER JOIN tblMobQuestObject ON tblObject.ObjectName = tblMobQuestObject.ObjectName WHERE (((tblMobQuestObject.FinishQuestEmote1) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestMessage1) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestEmote2) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestMessage2) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestEmote3) Like '*" & zSearch & "*'));"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   SG-CR-Mob Finish Quest Speak @ [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
    Loop
    Set rsSearch = Nothing
    
    Print #iFileNo, vbCrLf & "*" & vbCrLf
    
    Print #iFileNo, "M A G I C  S A Y  W O R D S"
    Set rsSearch = MyDB.OpenRecordset("SELECT AreaMagicWord FROM tblAreaMagicWords ORDER BY AreaMagicWord;", dbOpenSnapshot) 'Level to receive
    Do While (Not rsSearch.EOF)
        zSearch = MyCStr(rsSearch!AreaMagicWord)
        Print #iFileNo, "Area Magic Word [" & zSearch & "]"
        zSQL = "SELECT tblObject.ObjectName, tblObject.ObjectDesc, tblObject.Location, tblObject.X, tblObject.Y, tblObject.Z, tblObject.ObjectID FROM tblObject WHERE (((tblObject.ObjectName) Like '*" & zSearch & "*') AND ((tblObject.Location)=0)) OR (((tblObject.ObjectDesc) Like '*" & zSearch & "*') AND ((tblObject.Location)=0)) ORDER BY tblObject.ObjectName;"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   MW-Area Desc @ [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        
        zSQL = "SELECT ObjectName, ObjectDesc, X, Y, Z, ObjectID FROM tblObject WHERE (ObjectName Like '*" & zSearch & "*' OR ObjectDesc Like '*" & zSearch & "*');"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   MW-Object Desc @ [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        
        zSQL = "SELECT MobName, MobDesc, X, Y, Z, MobID FROM tblMob WHERE (MobName Like '*" & zSearch & "*' OR MobDesc Like '*" & zSearch & "*');"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   MW-Mob Desc @ [x" & strForceSize(lSX, 12, " ", "A") & " " & strForceSize(lSY, 12, " ", "A") & "y " & strForceSize(lSZ, 12, " ", "A") & "z]"
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        
        zSQL = "SELECT tblMobQuestObject.FinishQuestEmote1, tblMobQuestObject.FinishQuestMessage1, tblMobQuestObject.FinishQuestEmote2, tblMobQuestObject.FinishQuestMessage2, tblMobQuestObject.FinishQuestEmote3, tblObject.X, tblObject.Y, tblObject.Z, tblObject.ObjectID FROM tblObject INNER JOIN tblMobQuestObject ON tblObject.ObjectName = tblMobQuestObject.ObjectName WHERE (((tblMobQuestObject.FinishQuestEmote1) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestMessage1) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestEmote2) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestMessage2) Like '*" & zSearch & "*')) OR (((tblMobQuestObject.FinishQuestEmote3) Like '*" & zSearch & "*'));"
        Set rsLoc = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsLoc.EOF)
            lSX = MyCLng(rsLoc!x)
            lSY = MyCLng(rsLoc!y)
            lSZ = MyCLng(rsLoc!z)
            zPrint = "   MW-Mob Finish Quest Speak @ [x" & strForceSize(lSX, 12, " ", "A") & " y" & strForceSize(lSY, 12, " ", "A") & " z" & strForceSize(lSZ, 12, " ", "A")
            'subSendMsg zPrint, zPortID
            Print #iFileNo, zPrint
            rsLoc.MoveNext
        Loop
        Set rsLoc = Nothing
        rsSearch.MoveNext
    Loop
    Set rsSearch = Nothing
    
    'close the file
    Close #iFileNo
    subSendMsg "&GSuccess! Created Filename '" & zcstFileName & "'", zPortID
    
    Exit Sub
Err_Check:
    Close #iFileNo 'in case it is already opened which shouldnt happen but still we check
    subWriteErrorFile "subShowStargateMagicWordAreaLocHints," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lCalculateArmourAbsorbtionChance(lPlayerID As Long, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lReturn As Long
    Dim lPortID As Long
    lReturn = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT Sum(tblObject.ArmourAbsorbtionChance) AS SumOfArmourAbsorbtionChance FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID GROUP BY tblPlayerEquipmentItems.PlayerID HAVING (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lReturn = MyCLng(rsPlayer!SumOfArmourAbsorbtionChance)
    End If
    Set rsPlayer = Nothing
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        gbllArmourAbsorbtionChance(lPortID) = lReturn
    End If
    
    lCalculateArmourAbsorbtionChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCalculateArmourAbsorbtionChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lCalculateInitativeChance(lPlayerID As Long, zPortID As String, lStance As Long)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lReturn As Long
    Dim lPortID As Long
    lReturn = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT Sum(tblObject.InitativeChance) AS SumOfInitativeChance FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID GROUP BY tblPlayerEquipmentItems.PlayerID HAVING (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lReturn = MyCLng(rsPlayer!SumOfInitativeChance)
    End If
    Set rsPlayer = Nothing
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        lReturn = lReturn + lTranslateInitiativeChance(lStance)
        gbllInitativeChance(lPortID) = lReturn
    End If
    
    lCalculateInitativeChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCalculateInitativeChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lCalculateGoldDropChance(lPlayerID As Long, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lReturn As Long
    Dim lPortID As Long
    lReturn = 0
    Set rsPlayer = MyDB.OpenRecordset("SELECT Sum(tblObject.GoldDropChance) AS SumOfGoldDropChance FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID GROUP BY tblPlayerEquipmentItems.PlayerID HAVING (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & "));", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lReturn = MyCLng(rsPlayer!SumOfGoldDropChance)
    End If
    Set rsPlayer = Nothing
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        gbllGoldDropChance(lPortID) = lReturn
    End If
    
    lCalculateGoldDropChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCalculateGoldDropChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lMoonCycle(lMoonType As Long) As String
On Error Resume Next
    Dim lReturn As Long
    
    Select Case (lMoonType)
        Case -5 'death moons last a very long time too - mobs are allowed 200 times the armour
            lReturn = 9
        Case -4
            lReturn = 7
        Case -3
            lReturn = 6
        Case -2
            lReturn = 5
        Case -1
            lReturn = 5
        Case 0
            lReturn = 5
        Case 1
            lReturn = 5
        Case 2
            lReturn = 5
        Case 3 'fullmoons last awhile for open arena player vs player
            lReturn = 6
        Case 4 'blue moon if this happens there is a good chance an eclipse wont
            lReturn = 4
        Case 5 'eclipsed
            lReturn = 9
        Case Else
            lReturn = 5
    End Select
    
    lMoonCycle = lReturn
End Function
Public Function zMoonStatus(lMoonType As Long) As String
On Error Resume Next
    Dim zReturn As String
    Select Case (lMoonType)
        Case -5
            zReturn = "skull" 'skull moon is when everything is super hard
        Case -4
            zReturn = "blood"
        Case -3
            zReturn = "hexed"
        Case -2
            zReturn = "bewitched"
        Case -1
            zReturn = "harvest"
        Case 0
            zReturn = "normal"
        Case 1
            zReturn = "quarter"
        Case 2
            zReturn = "half"
        Case 3
            zReturn = "full"
        Case 4
            zReturn = "blue"
        Case 5
            zReturn = "eclipsed"
        Case Else
            zReturn = "turning moon"
    End Select
    zMoonStatus = zReturn
End Function
Public Sub subLightningBoltARandomPlayer(bOkay As Boolean) 'find a player in this whereid area and thunder zap them
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lSQLCount As Long
    Dim lPlayerID As Long

    If (gbllAtmosphereStaticCharges >= cstAtmozDefault Or bOkay) Then
        gbllAtmosphereStaticCharges = cstAtmozDefault
        'If (lRandom(5) = 1 Or bOkay) Then
        lPlayerID = 0
        lSQLCount = lngSQLRecordCount("SELECT PlayerID FROM tblPlayer WHERE (Class<>'CL' AND Class<>'PA' AND Race<>'DRA' AND Race<>'UND' AND Len([PortID])>1);")
        Set rsPlayer = MyDB.OpenRecordset("SELECT TOP " & lRandom(lSQLCount) & " PlayerID FROM tblPlayer WHERE (Class<>'PA' AND Race<>'DRA' AND Race<>'UND' AND Len([PortID])>1);", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then 'found our victim?
            rsPlayer.MoveLast
            gbllAtmosphereStaticCharges = 0
            lPlayerID = MyCLng(rsPlayer!PlayerID)
        End If
        Set rsPlayer = Nothing
        If (lPlayerID <> 0) Then subCombatPlayerDiedReset "~lightning~", lPlayerID
        'End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subLightningBoltARandomPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subWeatherCondition()
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lWhereWeatherType As Long
    Dim zDirectedSeasonCode As String
    Dim zWeatherControl As String 'This is just a marker for other weather conditions I did.
    Dim zDefaultWC As String
    Dim bDay As Boolean
    Dim lWeatherCondition As Long
    Dim lWhereID As Long
    Dim lEvent As Long
    Dim zMoon As String
    
    If (lRandom(5) > 2) Then 'Sometimes no weather change
        bDay = bWhenIsIt("", False)   'for day and night weather conditions
        If (lRandom(lMoonCycle(gbllMoon)) = 1) Then
            Select Case (gbllMoon)
                Case 5
                    subSimpleEchoChannel "&AThe eclipse ends sharply!"
                    gblbArenaOnOff = 0 'arena offline
                Case -5
                    subSimpleEchoChannel "&RThe skull moon ends sharply!"
                    gbllWearItemMAX = gbllWearItemMAXAdmin
                    frmTelnetServerEngine.txtWearItemMAX.Text = gbllWearItemMAX
                    gblbArenaOnOff = 0 'arena offline
            End Select
            gbllMoon = gbllMoon + 1
            If (gbllMoon < -5 Or gbllMoon > 5) Then gbllMoon = 0
            If (lRandom(6) = 1 And gbllMoon < 0) Or (lRandom(2) = 1 And gbllMoon > 2) Or (lRandom(2) = 1 And gbllMoon = 4) Then
                Select Case lRandom(8)
                    Case 8
                        gbllMoon = 0 - lRandom(5)
                    Case Else 'normal moon
                        gbllMoon = 0
                End Select
            End If
            Select Case (gbllMoon)
                Case 5
                    gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges + 10
                    subSimpleEchoChannel "&AAn eclipse falls over the realm! [-camohidevissneak]"
                    gblbArenaOnOff = 0 'Universal arena offline
                    gbllWearItemMAX = 20
                    frmTelnetServerEngine.txtWearItemMAX.Text = gbllWearItemMAX
                    MyDB.Execute "UPDATE tblPlayer SET CamoflaguedDuration=0, InvisibilityDuration=0, SneakingMovesLeft=0, HideDuration=0;", dbFailOnError
                Case -5
                    gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges + 20
                    subSimpleEchoChannel "&RA &Askull moon &Rfalls over the realm! GEAR UP!"
                    MyDB.Execute "UPDATE tblPlayer SET ShadowCloakDuration=0, NegateDuration=0, CamoflaguedDuration=0, InvisibilityDuration=0, SneakingMovesLeft=0, HideDuration=0;", dbFailOnError
                    gblbArenaOnOff = 1 'Universal arena online
                    gbllWearItemMAX = 52
                    frmTelnetServerEngine.txtWearItemMAX.Text = gbllWearItemMAX
            End Select
        End If
        zMoon = zMoonStatus(gbllMoon)
        
        'we rotate the weather condition for all areas by one
        MyDB.Execute "UPDATE tblWhere SET WeatherCondition = [WeatherCondition]+1;", dbFailOnError
        
        lEvent = lRandom(3)
        zDefaultWC = ""
        If (bDay) Then
            Select Case lRandom(5)
                Case 1
                    zDefaultWC = "&YThe <*<*sun shines*>*> brightly."
                Case 2
                    zDefaultWC = "&YThe <*<*sun sparkles mystically*>*>"
                Case 3
                    zDefaultWC = "&YThe <*<*sun shines happily*>*>"
                Case 4
                    zDefaultWC = "&YThe <*<*sun glows high in the sky*>*>"
                Case 5
                    zDefaultWC = "&YThe <*<*sun is but a golden point*>*> high in the sky."
            End Select
        Else
            Select Case lRandom(5)
                Case 1
                    zDefaultWC = "&BThe " & zMoon & " <*<*moon glows silently*>*>"
                Case 2
                    zDefaultWC = "&BThe " & zMoon & " <*<*moon seems larger*>*>"
                Case 3
                    zDefaultWC = "&BThe " & zMoon & " <*<*moon seems evil tonight*>*>"
                Case 4
                    zDefaultWC = "&BA " & zMoon & " <*<*moon glows nicely*>*>"
                Case 5
                    zDefaultWC = "&BThe " & zMoon & " <*<*moon glows brightly*>*>"
            End Select
        End If
        'We show everyone in the system the weather change, if the area is a house we ignore the house
        Set rsPlayer = MyDB.OpenRecordset("SELECT tblWhere.WhereID, tblWhere.WeatherCondition, tblWhere.WhereWeatherType, tblPlayer.PortID FROM tblPlayer INNER JOIN tblWhere ON tblPlayer.WhereID = tblWhere.WhereID WHERE (((tblWhere.House)=False) AND ((tblWhere.WhereWeatherType)<>0) AND ((tblPlayer.PortID) Is Not Null And (tblPlayer.PortID)<>'' And (tblPlayer.PortID)<>'0'));", dbOpenSnapshot)
        Do While (Not rsPlayer.EOF)
            zWeatherControl = zDefaultWC
            lWhereID = MyCLng(rsPlayer!WhereID)
            lWhereWeatherType = MyCLng(rsPlayer!WhereWeatherType) '1=freezing, 2=cold, 3=cool/temperate, 4=rainforest, 5=jungle, 6=desert, 7=hot
            lWeatherCondition = MyCLng(rsPlayer!WeatherCondition)
            If (lWhereWeatherType > 0) Then
                zDirectedSeasonCode = ""
                
                'Never make a weather condition that exceeds 30 it will never happen.
                Select Case lWhereWeatherType
                    Case 1 'freezing
                        zDirectedSeasonCode = "FREEZING WINTER"
                    Case 2 'cold
                        zDirectedSeasonCode = "WINTER"
                    Case 3 'cool / temperate
                        zDirectedSeasonCode = "COOL FALL"
                    Case 4 'rainforest
                        zDirectedSeasonCode = "WARM FALL"
                    Case 5 'jungle
                        zDirectedSeasonCode = "SUMMER"
                    Case 6 'desert
                        zDirectedSeasonCode = "HOT"
                    Case 7 'hell
                        zDirectedSeasonCode = "HELL"
                    Case Else
                        zDirectedSeasonCode = "SUMMER"
                End Select
                
                Select Case zDirectedSeasonCode
                    Case "FREEZING WINTER"
                        Select Case lWeatherCondition
                            Case 1
                                Select Case lRandom(3)
                                    Case 1
                                        zWeatherControl = "&wIt is <*<*freezing cold and overcast*>*>"
                                    Case 2
                                        zWeatherControl = "&wIt is <*<*freezing cold and cloudy*>*>"
                                    Case 3
                                        zWeatherControl = "&CThere is a sudden <*<*rush of wind*>*>, a <*<*blizzard*>*> will be here soon!"
                                End Select
                            Case 2
                                Select Case lRandom(4)
                                    Case 1
                                        zWeatherControl = "&WIt begins to <*<*snow during a still wind*>*>"
                                    Case 2
                                        zWeatherControl = "&WThe <*<*wind grows quiet*>*> and <*<*it begins to snow*>*>"
                                    Case 3
                                        zWeatherControl = "&WA few flakes of <*<*snow twinkle*>*> in the air."
                                    Case Else
                                        zWeatherControl = "&cYou <*<*see your breath*>*> as it <*<*begins to snow*>*>"
                                End Select
                            Case 3
                                Select Case lRandom(3)
                                    Case 1
                                        zWeatherControl = "&WIt is now <*<*snowing*>*> lightly."
                                    Case 2
                                        zWeatherControl = "&WIt is now <*<*snowing*>*> harder."
                                    Case Else
                                        zWeatherControl = "&WThe <*<*snow stops*>*>."
                                End Select
                            Case 4
                                Select Case lRandom(3)
                                    Case 1
                                        zWeatherControl = "&WThe snow turns into a <*<*raging BlIzZaRd*>*>"
                                    Case 2
                                        zWeatherControl = "&WIt is now <*<*snowing harder*>*>"
                                    Case 3
                                        zWeatherControl = "&CThe <*<*snow and winds speed up*>*>"
                                End Select
                            Case 5
                                Select Case lRandom(4)
                                    Case 1
                                        zWeatherControl = "&WThe <*<*snow and wind is freezing against your skin*>*>"
                                    Case 2
                                        zWeatherControl = "&WThe <*<*wind picks up*>*>"
                                    Case 3
                                        zWeatherControl = "&WThe <*<*wind howls*>*> as it increases in speed."
                                    Case Else
                                        zWeatherControl = "&BThe <*<*wind picks up*>*> and happily goes back to moulding another snowdrift."
                                End Select
                            Case 6
                                Select Case lRandom(4)
                                    Case 1
                                        zWeatherControl = "&WThe <*<*snow and wind*>*> is freezing against your skin!"
                                    Case 2
                                        zWeatherControl = "&WThe <*<*wind picks up*>*>"
                                    Case 3
                                        zWeatherControl = "&WThe <*<*wind howls*>*> as it increases in speed."
                                    Case Else
                                        zWeatherControl = "&BThe <*<*wind picks up*>*> and happily goes back to moulding another snowdrift."
                                End Select
                            Case 7
                                Select Case lRandom(4)
                                    Case 1
                                        zWeatherControl = "&WThe <*<*wind calms down*>*> some more."
                                    Case 2
                                        zWeatherControl = "&WThe <*<*cold wind whistles*>*> and slows down a little."
                                    Case 3
                                        zWeatherControl = "&WThe <*<*wind swirls*>*> glittering flakes into a blowing funnel of snow."
                                    Case Else
                                        zWeatherControl = "&WThe <*<*snow is falling lighter*>*>"
                                End Select
                                'If (bDay) Then
                            Case 8
                                Select Case lRandom(3)
                                    Case 1
                                        zWeatherControl = "&WThe <*<*clouds begin to thin out*>*>"
                                    Case 2
                                        zWeatherControl = "&WThe <*<*clouds begin to break up*>*>"
                                    Case Else
                                        zWeatherControl = "&WThe <*<*wind begins to slow down*>*>"
                                End Select
                            Case 9
                                Select Case lRandom(3)
                                    Case 1
                                        zWeatherControl = "&WYou can <*<*hear hungry animals call*>*> into the wind."
                                    Case 2
                                        zWeatherControl = "&WThe <*<*snow is beginning to break up*>*>."
                                    Case Else
                                        zWeatherControl = "&WThe <*<*snow storm is breaking up*>*>."
                                End Select
                            Case 10
                                zWeatherControl = "&BThe <*<*wind picks up*>*> and begins moulding another snowdrift."
                            Case 11
                                zWeatherControl = "&BA <*<*snowdrift builds up*>*> as the wind drops light flakes of snow over it."
                            Case 12 To 15
                                zWeatherControl = "&w<*<*Snow is sprinkling everywhere*>*>"
                            Case 16, 18, 20
                                zWeatherControl = "&wThere is a <*<*sudden rush of cold area*>*>"
                            Case 17, 19
                                zWeatherControl = "&CYou feel the <*<*deep freezing cold*>*> pass though your legs!"
                            Case Else
                                zWeatherControl = "&wThe <*<*clouds drift overhead*>*>"
                        End Select
                    Case "WINTER"
                        Select Case lWeatherCondition
                            Case 1
                                zWeatherControl = "&W<*<*Snow falls*>*> while its &wovercast."
                            Case 2
                                zWeatherControl = "&W<*<*Snow falls*>*> while its &wovercast."
                            Case 3
                                zWeatherControl = "&WIt begins to <*<*lightly snow*>*>."
                            Case 4
                                zWeatherControl = "&WThe <*<*snow stops*>*>"
                            Case 5
                                zWeatherControl = "&wIt's <*<*cloudy*>*>"
                            Case 6
                                zWeatherControl = "&WIt <*<*starts to snow*>*>"
                            Case 7
                                zWeatherControl = "&wIt's <*<*overcast*>*>"
                            Case 8
                                If (bDay) Then
                                    zWeatherControl = "&wThe <*<*clouds break up*>*> enough you can see a few &Y<*<*rays from the sun*>*>"
                                Else
                                    zWeatherControl = "&wThe <*<*clouds break up*>*> enough you can see a few &B<*<*rays from the moon*>*>" & vbCrLf & "You can see twinkling lights on the moonbase."
                                End If
                            Case 9
                                If (bDay) Then
                                    zWeatherControl = "&wThe clouds close in and the <*<*sun disappears*>*>"
                                Else
                                    zWeatherControl = "&wThe clouds close in and the <*<*moon disappears*>*>"
                                End If
                            Case 10
                                zWeatherControl = "&WIt <*<*begins to snow*>*>"
                            Case 11
                                zWeatherControl = "&BThe <*<*winds pick up pushing the snow over drifts*>*>"
                            Case 12
                                zWeatherControl = "&WYou are in a <*<*blizzard*>*>, the wind whistles past and nips at your ears"
                            Case 13
                                zWeatherControl = "&WThe <*<*blizzard calms down*>*> to a dull roar"
                            Case 14 To 20
                                zWeatherControl = "&WIt is <*<*snowing lightly*>*>"
                            Case 21
                                zWeatherControl = "&WThe <*<*snow subsides, its now overcast*>*>"
                            Case Else
                                zWeatherControl = "&wThe <*<*clouds drift overhead*>*>"
                        End Select
                    Case "COOL FALL" 'City of Ages uses this one
                        Select Case lWeatherCondition
                            Case 1
                                zWeatherControl = "&CCool <*<*rain begins to fall*>*>"
                            Case 2
                                zWeatherControl = "&CThe <*<*rain is making puddles*>*> all around you."
                            Case 3
                                zWeatherControl = "&BThe <*<*rain picks up*>*>"
                            Case 4
                                zWeatherControl = "&wThe <*<*rain is pounding away at everything*>*>"
                            Case 5
                                Select Case (lEvent) 'Events are things that can happen in the matching WhereIDs
                                    Case 1
                                        zWeatherControl = "&wYou saw a bolt of&Y <*<*LIGHTNING*>*> &wthen its loud &aKABOOM&w overhead!"
                                        gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges + 5
                                        subLightningBoltARandomPlayer False
                                    Case Else
                                        zWeatherControl = "&wIt starts to &Y<*<*thunder>*>*>&w and &Brain&w."
                                End Select
                            Case 6
                                zWeatherControl = "&BThe <*<*storm calms down*>*> and turns into a pleasant rainy day."
                            Case 7
                                zWeatherControl = "&BIt <*<*stops*>*> raining."
                            Case 8
                                zWeatherControl = "&wIt's <*<*cloudy*>*>"
                            Case 9
                                zWeatherControl = "&WThe <*<*clouds begin to break up*>*>"
                            Case 10, 12
                                If (bDay) Then
                                    zWeatherControl = "&YThe <*<*sun shines*>*> through the cool air."
                                Else
                                    zWeatherControl = "&BThe <*<*moon howls*>*> as it reflects rays through the cool air."
                                End If
                            Case 11, 13, 21
                                If (bDay) Then
                                    zWeatherControl = "&YThe <*<*sun shines*>*> through the warm air."
                                Else
                                    zWeatherControl = "&BThe <*<*moon howls*>*> as it reflects rays through the warm air."
                                End If
                            Case 14 To 19, 26
                                If (bDay) Then
                                    zWeatherControl = "&YThe <*<*sun warms*>*> your skin."
                                Else
                                    zWeatherControl = "&BThe <*<*warm night air*>*> fills your lungs."
                                End If
                            Case 20, 23, 25
                                zWeatherControl = "&wIt's <*<*overcast*>*>"
                            Case 28
                                zWeatherControl = "&wThe <*<*clouds drift*>*> overhead."
                        End Select
                    Case "WARM FALL"
                        Select Case lWeatherCondition
                            Case 1
                                zWeatherControl = "&B<*<*Cold rain begins to fall*>*>"
                            Case 2
                                zWeatherControl = "&B<*<*Cold rain begins to fall*>*>"
                            Case 3
                                zWeatherControl = "&cIt <*<*stops raining*>*>"
                            Case 4
                                zWeatherControl = "&BIt starts to <*<*thunder*>*> and rain!"
                            Case 5
                                zWeatherControl = "&BIt starts to <*<*pour cool rain*>*>"
                            Case 6
                                zWeatherControl = "&WThere is a bright &Yflash&W in the sky followed by <*<*thunder*>*> " & lRandom(5) + 1 & " seconds later."
                                Select Case (lEvent) 'Events are things that can happen in the matching WhereIDs
                                    Case 1, 2
                                        gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges + 5
                                        subLightningBoltARandomPlayer False
                                End Select
                            Case 7
                                zWeatherControl = "&BIt <*<*stops raining*>*>"
                            Case 8, 1
                                zWeatherControl = "&BIt's <*<*cloudy and calm*>*>"
                            Case 9
                                zWeatherControl = "&BThe <*<*clouds begin to separate*>*>"
                            Case 10, 12
                                If (bDay) Then
                                    zWeatherControl = "&YThe sun shines as a &C<*<*cool wind blows*>*> through your &yhair."
                                Else
                                    zWeatherControl = "&BThe moon howls as a &C<*<*cool wind blows*>*> through your &yhair."
                                End If
                            Case 11, 13
                                If (bDay) Then
                                    zWeatherControl = "&YThe <*<*sun shines warmly*>*> over the land."
                                Else
                                    zWeatherControl = "&BThe <*<*moon howls warmly*>*> over the land."
                                End If
                            Case 14
                                zWeatherControl = "&wIt's <*<*overcast*>*>"
                            Case 15 To 20
                                zWeatherControl = "&wThe <*<*clouds drift overhead*>*>"
                            Case 21 To 24
                                If (bDay) Then
                                    zWeatherControl = "&Ya <*<*single cloud blocks the rays*>*> of the sun."
                                Else
                                    zWeatherControl = "&Ba <*<*single cloud covers the moon*>*>"
                                End If
                        End Select
                    Case "SUMMER"
                        Select Case lWeatherCondition
                            Case 1
                                zWeatherControl = "&B<*<*Warm rain begins to sprinkle*>*> the area."
                            Case 2
                                zWeatherControl = "&B<*<*Warm rain falls harder*>*> around you."
                            Case 3
                                zWeatherControl = "&B<*<*Warm rain streaks and pounds*>*> the area around you."
                            Case 4
                                zWeatherControl = "&WIt starts to &Y<*<*thunder*>*>&W and &Brain&W."
                            Case 5
                                zWeatherControl = "&B<*<*It is now pouring &Crain&B*>*>"
                            Case 6
                                zWeatherControl = "&WThere is a bright&Y flash &Win the sky followed by <*<*thunder*>*> " & lRandom(5) + 1 & " seconds later."
                                gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges + 5
                                subLightningBoltARandomPlayer False
                            Case 7
                                zWeatherControl = "&BIt <*<*stops raining*>*>"
                            Case 8
                                zWeatherControl = "&wIt's <*<*cloudy*>*>"
                            Case 9
                                zWeatherControl = "&BThe <*<*clouds begin to break up*>*>"
                            Case 10, 12
                                If (bDay) Then
                                    zWeatherControl = "&YThe <*<*sun shines warmly*>*> over the land."
                                Else
                                    zWeatherControl = "&BThe <*<*moon howls warmly*>*> over the land."
                                End If
                            Case 11, 13
                                If (bDay) Then
                                    zWeatherControl = "&YThe <*<*sun shines with intense heat*>*> on this summer day."
                                Else
                                    zWeatherControl = "&BThe <*<*moon sparkles with intense heat*>*> on this summer night."
                                End If
                            Case 14 To 20
                                zWeatherControl = "&wIt's <*<*overcast*>*>"
                            Case 21 To 24
                                If (bDay) Then
                                    zWeatherControl = "&YA single cloud blocks the rays of the sun."
                                Else
                                    zWeatherControl = "&BA single cloud covers the moon."
                                End If
                            Case Else
                                zWeatherControl = "&wThe clouds drift overhead."
                        End Select
                    Case "HOT" 'desert like
                        Select Case lWeatherCondition
                            Case 1, 10
                                zWeatherControl = "&WThe heat in the area is intense."
                            Case 2 To 4, 16
                                zWeatherControl = "&wYour shoulders are tanning from the blazing rays."
                            Case 5 To 9, 21
                                zWeatherControl = "&BYou feel you need some shade away from the sun."
                            Case 14, 19
                                zWeatherControl = "&B<*<*Insects buzz*>*> the area near you."
                            Case 26 To 27, 11 To 13
                                zWeatherControl = "&wA single puffy white cloud drifts overhead."
                        End Select
                    Case "HELL"
                        Select Case lWeatherCondition
                            Case 1 To 5
                                zWeatherControl = "&W<*<*Lava flows around you*>*> and heats the ground beneath you."
                            Case 6 To 9
                                zWeatherControl = "&wThe heat from the <*<*lava makes you gasp*>*> for cold water."
                            Case 10 To 16
                                zWeatherControl = "&BYour finger nails are painfully hot."
                            Case 17 To 20
                                zWeatherControl = "&cThe <*<*heat around you makes you gasp*>*> for a cold glass of water."
                            Case Else
                                zWeatherControl = "&wThe pebbles around you glow like <*<*hot embers*>*>"
                        End Select
                End Select
                
                If (Len(zWeatherControl) > 0) Then subSendMsg zWeatherControl, MyCStr(rsPlayer!PortID)
            End If
            rsPlayer.MoveNext
        Loop
        Set rsPlayer = Nothing
        
        MyDB.Execute "UPDATE tblWhere SET WeatherCondition = 0 WHERE WeatherCondition>30;", dbFailOnError 'Never make a weather condition that exceeds 30 it will never happen.
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subWeatherCondition," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bWhenIsIt(zPortID As String, bShowDesc As Boolean) As Boolean
On Error Resume Next
'See also: subSendWhereMessageAllPlayers FALSE = Nighttime
    Dim bDay As Boolean
    Dim zTime As String

    'zSeason = zSeasonCode()

    bDay = False 'night time
    Select Case iDayCode()
        Case 10
            zTime = "midnight"
        Case 11
            zTime = "approaching dawn"
        Case 13
            zTime = "dawn"
            bDay = True
        Case 15
            zTime = "morning"
            bDay = True
        Case 20
            zTime = "noon"
            bDay = True
        Case 21
            zTime = "approaching afternoon"
            bDay = True
        Case 25
            zTime = "afternoon"
            bDay = True
        Case 26
            zTime = "approaching evening"
            bDay = True
        Case 30
            zTime = "evening"
        Case 31
            zTime = "approaching dusk"
        Case 35
            If (lRandom(5) < 4) Then
                zTime = "dusk"
            Else
                zTime = zMoonStatus(gbllMoon) & " dusk"
            End If
    End Select
    
    If (bShowDesc) Then 'skull moon is when everything is super hard
        If (bDay) Then
            subSendMsg "&G" & zSeasonDescriptionCode() & vbCrLf & "It is currently " & zTime & "." & vbCrLf & "&yAlthough hidden by the sun, there is a " & zMoonStatus(gbllMoon) & " moon out.", zPortID
        Else
            subSendMsg "&G" & zSeasonDescriptionCode() & vbCrLf & "It is currently " & zTime & "." & vbCrLf & "&BA " & zMoonStatus(gbllMoon) & " moon is out.", zPortID
        End If
        subSendMsg "&gServer time: " & Format(Now(), "dddd, Mmm dd, yyyy HH:NN:SS AMPM"), zPortID
    End If
    bWhenIsIt = bDay 'true is when its day time
End Function
Public Function zWhenIsIt() As String
On Error Resume Next
    Dim zTime As String
    Dim zReturn As String

    zTime = ""
    Select Case iDayCode()
        Case 10
            zTime = "midnight"
        Case 13
            zTime = "dawn"
        Case 15
            zTime = "morning"
        Case 20
            zTime = "noon"
        Case 25
            zTime = "afternoon"
        Case 30
            zTime = "evening"
        Case 35
            zTime = "dusk"
    End Select
    
    zWhenIsIt = UCase(zSeasonCode() & "|" & zTime)
End Function
Public Function zTranslateComplicatedDirection(zType As String) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = zType
    Select Case MyCStr(UCase(zType))
        Case "NORTH", "N", "NORTHERN"
            zReturn = "N"
        Case "SOUTH", "S", "SOUTHERN"
            zReturn = "S"
        Case "EAST", "S", "EASTERN"
            zReturn = "E"
        Case "WEST", "W", "WESTERN"
            zReturn = "W"
        Case "NORTHEAST", "NE", "NORTHEASTERN"
            zReturn = "NE"
        Case "NORTHWEST", "NW", "NORTHWESTERN"
            zReturn = "NW"
        Case "SOUTHEAST", "SE", "SOUTHEASTERN"
            zReturn = "SE"
        Case "SOUTHWEST", "SW", "SOUTHWESTERN"
            zReturn = "SW"
        Case "UP", "U", "UPWARDS", "CEILING", "TRAP-CEILING", "ABOVE"
            zReturn = "U"
        Case "DOWN", "D", "DOWNWARDS", "FLOOR", "TRAP-FLOOR", "BELOW"
            zReturn = "D"
    End Select
    zTranslateComplicatedDirection = zReturn
End Function
Public Function zTranslatePokerCardType(lPokerCardType As Long) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    Select Case lPokerCardType
        Case 2
            zReturn = "TWO"
        Case 3
            zReturn = "THREE"
        Case 4
            zReturn = "FOUR"
        Case 5
            zReturn = "FIVE"
        Case 6
            zReturn = "SIX"
        Case 7
            zReturn = "SEVEN"
        Case 8
            zReturn = "EIGHT"
        Case 9
            zReturn = "NINE"
        Case 10
            zReturn = "TEN"
        Case 11
            zReturn = "JACK"
        Case 12
            zReturn = "QUEEN"
        Case 13
            zReturn = "KING"
        Case 14
            zReturn = "ACE"
        Case 15
            zReturn = "JOKER"
        Case 16
            zReturn = "RUNIC ACE"
    End Select
    zTranslatePokerCardType = zReturn
End Function
Public Function zTranslateRottingContainer(lRottingRounds As Long, iType As Integer) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    
    Select Case iType
        Case 1
            Select Case lRottingRounds
                Case 1, 2
                    zReturn = "is turning into dust"
        '        Case 2
        '            zReturn = "is a pile of rotting flesh, guts, and bones"
                Case 3
                    zReturn = "is rotting away"
        '        Case 4
        '            zReturn = "has decayed so much that maggots are now crawling over it"
        '        Case 4
        '            zReturn = "has started to decay"
                Case Else
                    zReturn = "was just slain"
        '        Case Else
        '            zReturn = "is turning into dust"
            End Select
        Case 2
            Select Case lRottingRounds
                Case 1
                    zReturn = "is unrecognizable"
                Case 2
                    zReturn = "is turning into dust"
                Case 3, 4, 5
                    zReturn = "is rotting away"
                Case 6, 7
                    zReturn = "is starting to rot"
                Case 8, 9
                    zReturn = "is falling apart"
                Case 10, 11
                    zReturn = "is getting old"
                Case 12, 13
                    zReturn = "is in poor condition"
                Case 14, 15
                    zReturn = "is soiled and cracked"
                Case 16, 17
                    zReturn = "is soiled and tarnished"
                Case 18
                    zReturn = "is slightly tarnished"
                Case Else
                    zReturn = "is in fine condition"
            End Select
    End Select
    zTranslateRottingContainer = zReturn
End Function
Public Function zTranslatePlayerCombatStatus(iType As Integer) As String
On Error Resume Next
    Dim zReturn As String
    '0=available battle cell 1=battle mode 2=Target fled, 3=Attacker fled.
    zReturn = ""
    Select Case iType
        Case 1
            zReturn = "battling"
        Case 2
            zReturn = "fled from target"
        Case 3
            zReturn = "fled from target"
    End Select
    zTranslatePlayerCombatStatus = zReturn
End Function
Public Function zTranslateGender(zGetGenderType As String, iType As Integer) As String
On Error GoTo Err_Check
    Dim zGenderType As String
    Dim zReturn As String
    Select Case UCase(zGetGenderType)
        Case "HIM", "HIS", "M"
            zGenderType = "M"
        Case "HER", "HERS", "F"
            zGenderType = "F"
    End Select
    Select Case iType
        Case 1
            Select Case zGenderType
                Case "M"
                    zReturn = "him"
                Case "F"
                    zReturn = "her"
            End Select
        Case 2
            Select Case zGenderType
                Case "M"
                    zReturn = "his"
                Case "F"
                    zReturn = "her"
            End Select
        Case 30
            Select Case zGenderType
                Case "M"
                    zReturn = "male"
                Case "F"
                    zReturn = "female"
            End Select
        Case 31
            Select Case zGenderType
                Case "M"
                    zReturn = "Male"
                Case "F"
                    zReturn = "Female"
            End Select
        Case 40
            Select Case zGenderType
                Case "M"
                    zReturn = "himself"
                Case "F"
                    zReturn = "herself"
            End Select
        Case 50
            Select Case zGenderType
                Case "M"
                    zReturn = "he"
                Case "F"
                    zReturn = "she"
            End Select
    End Select
    'NOTE: In the program append self to ZReturn for himself and herself
    zTranslateGender = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateGender," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subTranslateChartRaces(zPortID As String)
On Error Resume Next
    Dim zReturn  As String
    zReturn = ""
    subSendMsgNoPortCheck vbCrLf & "&GCharacter Charts - Race Stats:", zPortID
    zReturn = zReturn & "          STR INT WIS DEX CON CHR LUC" & vbCrLf
    zReturn = zReturn & " DRAC      1   1   1   1       1     (60% poison immune)(dragon scales)" & vbCrLf
    zReturn = zReturn & " DWARF     1       1   1   1       1 (lucky with forge)(+1att)" & vbCrLf
    zReturn = zReturn & " ELF       1   2   1   1  -1   1     (race skill)(true sight)" & vbCrLf
    zReturn = zReturn & " FELPUR    3           2             (race skill)(night-vision)" & vbCrLf
    zReturn = zReturn & " GNOME     1       2   1       1     (race skill)(master spellcrafters)(+1regn)" & vbCrLf
    zReturn = zReturn & " HALFLING              3   1       1 (race skill)" & vbCrLf
    zReturn = zReturn & " HUMAN     1   1   1           1   1 (race skill)" & vbCrLf
    zReturn = zReturn & " MINOTAUR  3           1           1 (eat corpses)(race skill)(+1att)" & vbCrLf
    zReturn = zReturn & " OGRE      2  -1       1   2       1 (eat corpses)(strong hides)(+1att)(+2regn)" & vbCrLf
    zReturn = zReturn & " ORC       2           1   1       1 (race skill)(+1att)(+2regn)" & vbCrLf
    zReturn = zReturn & " PIXIE         3       1           1 (fly)" & vbCrLf
    zReturn = zReturn & " TROLL     3  -2           3       1 (eat corpses)(iron hides)(+1att)(+3regn)" & vbCrLf
    zReturn = zReturn & " UNDEAD (no creation bonus) (no alignment changes) (% less chance for death)    " 'this is 80 length exactly
    'Vampires (can eat corpses to regenerate) I disabled vampires for my mud
    subSendMsgNoPortCheck vbCrLf & "&g" & zReturn, zPortID
End Sub
Public Sub subTranslateChartClasses(zPortID As String)
On Error Resume Next
    Dim zReturn  As String
    'Assassin Bard Cleric Druid Gladiator Gypsy Knight Mage Monk Paladin Ranger Thief Warrior
    zReturn = ""
    subSendMsgNoPortCheck vbCrLf & "&GCharacter Charts - Class Stats:", zPortID
    zReturn = ""
    zReturn = zReturn & "          STR INT WIS DEX CON CHR LUC" & vbCrLf
    zReturn = zReturn & " ASSASSIN  2   1       2             " & vbCrLf
    zReturn = zReturn & " BARD      1       2       2         " & vbCrLf
    zReturn = zReturn & " CLERIC            5                 " & vbCrLf
    zReturn = zReturn & " DRUID         2   3                 " & vbCrLf
    zReturn = zReturn & " GLADIATOR 5                          (+1att)" & vbCrLf
    zReturn = zReturn & " GYPSY     3           1   1         "
    subSendMsgNoPortCheck gblzFNGRE & zReturn, zPortID
    
    zReturn = ""
    zReturn = " KNIGHT    4       1                 " & vbCrLf
    zReturn = zReturn & " MAGE          5                     " & vbCrLf
    zReturn = zReturn & " MONK      3           2             " & vbCrLf
    zReturn = zReturn & " PALADIN   3   2                     " & vbCrLf
    zReturn = zReturn & " RANGER    2   1   1   1             " & vbCrLf
    zReturn = zReturn & " THIEF                 3           2 " & vbCrLf
    zReturn = zReturn & " WARRIOR   3               2         (+1att)"
    subSendMsgNoPortCheck gblzFNGRE & zReturn, zPortID
    
    subSendMsgNoPortCheck "&gMorph Classes later in the game are: Cyborg, Plantlife, Vampire, Werewolf.", zPortID
End Sub
Public Function iTranslateChartAbilities(zRace As String, zClass As String, zAbility As String) As Integer
On Error Resume Next
    Dim iReturn  As Integer
    iReturn = 0 'Undead get no stats
    Select Case Mid(zAbility, 1, 3)
        Case "STR"
            Select Case Mid(zRace, 1, 3)
                Case "DWA", "HUM", "GNO", "ELF", "DRA"
                    iReturn = iReturn + 1
                Case "OGR", "ORC"
                    iReturn = iReturn + 2
                Case "TRO", "MIN", "FEL"
                    iReturn = iReturn + 3
            End Select
        
            Select Case Mid(zClass, 1, 2)
                Case "WA"
                    iReturn = iReturn + 3
                Case "GY"
                    iReturn = iReturn + 3
                Case "BA"
                    iReturn = iReturn + 1
                Case "MO", "PA"
                    iReturn = iReturn + 3
                Case "AS", "RA"
                    iReturn = iReturn + 2
                Case "GL"
                    iReturn = iReturn + 5
                Case "KN"
                    iReturn = iReturn + 4
            End Select
        Case "INT"
            Select Case Mid(zRace, 1, 3)
                Case "PIX"
                    iReturn = iReturn + 3
                Case "HUM", "DRA"
                    iReturn = iReturn + 1
                Case "OGR"
                    iReturn = iReturn - 1
                Case "TRO"
                    iReturn = iReturn - 2
                Case "ELF"
                    iReturn = iReturn + 2
            End Select
        
            Select Case Mid(zClass, 1, 2)
                Case "MA"
                    iReturn = iReturn + 5
                Case "DR", "UN", "PA"
                    iReturn = iReturn + 2
                Case "AS", "RA"
                    iReturn = iReturn + 1
            End Select
        Case "WIS"
            Select Case Mid(zRace, 1, 3)
                Case "DWA", "HUM", "ELF", "DRA"
                    iReturn = iReturn + 1
                Case "GNO"
                    iReturn = iReturn + 2
            End Select
        
            Select Case Mid(zClass, 1, 2)
                Case "CL"
                    iReturn = iReturn + 5
                Case "DR", "UN"
                    iReturn = iReturn + 3
                Case "BA"
                    iReturn = iReturn + 2
                Case "RA", "KN"
                    iReturn = iReturn + 1
            End Select
        Case "DEX"
            Select Case Mid(zRace, 1, 3)
                Case "PIX", "DWA", "OGR", "ORC", "GNO", "ELF", "MIN", "DRA"
                    iReturn = iReturn + 1
                Case "FEL"
                    iReturn = iReturn + 2
                Case "HAL"
                    iReturn = iReturn + 3
            End Select
        
            Select Case Mid(zClass, 1, 2)
                Case "GY"
                    iReturn = iReturn + 1
                Case "MO", "AS"
                    iReturn = iReturn + 2
                Case "RA"
                    iReturn = iReturn + 1
                Case "TH"
                    iReturn = iReturn + 3
            End Select
        Case "CON"
            Select Case Mid(zRace, 1, 3)
                Case "DWA", "ORC", "HAL"
                    iReturn = iReturn + 1
                Case "OGR"
                    iReturn = iReturn + 2
                Case "TRO"
                    iReturn = iReturn + 3
                Case "ELF"
                    iReturn = iReturn - 1
            End Select
            
            Select Case Mid(zClass, 1, 2)
                Case "WA"
                    iReturn = iReturn + 2
                Case "BA"
                    iReturn = iReturn + 2
                Case "GY"
                    iReturn = iReturn + 1
            End Select
        Case "CHA"
            Select Case Mid(zRace, 1, 3)
                Case "HUM", "GNO", "ELF", "DRA"
                    iReturn = iReturn + 1
                Case "OGR"
                    iReturn = iReturn + 2
                Case "TRO"
                    iReturn = iReturn + 3
                Case "ELF"
                    iReturn = iReturn - 1
            End Select
        Case "LUC"
            Select Case Mid(zRace, 1, 3)
                Case "PIX", "DWA", "HUM", "OGR", "ORC", "TRO", "MIN", "HAL"
                    iReturn = iReturn + 1
            End Select
            Select Case Mid(zClass, 1, 2)
                Case "TH"
                    iReturn = iReturn + 2
            End Select
    End Select
    iTranslateChartAbilities = iReturn
End Function
Public Function lRaceArmourAbsorbtionChance(zRaceType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    Select Case zRaceType
        Case "GNO"
            lReturn = 5
        Case "HAL"
            lReturn = 3
        Case "OGE"
            lReturn = 5
        Case "ELF"
            lReturn = 0
        Case "ORC"
            lReturn = 6
        Case "FEL"
            lReturn = 2
        Case "HUM"
            lReturn = 1
        Case "MIN"
            lReturn = 7
        Case "DWA"
            lReturn = 3
        Case "TRO"
            lReturn = 8
        Case "DRA"
            lReturn = 9
        Case "PIX"
            lReturn = 0
        Case "UND"
            lReturn = 0
        Case Else
            lReturn = 2
    End Select
    lRaceArmourAbsorbtionChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lRaceArmourAbsorbtionChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lClassArmourAbsorbtionChance(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    'best thieves are (in order): "TH" "GY" "BA" "AS"
    lReturn = 1 '/ lTranslateThiefPickLock(zPlayerClass)
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "TH"
            lReturn = 0
        Case "GY"
            lReturn = 2
        Case "BA"
            lReturn = 1
        Case "AS"
            lReturn = 5
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 0
        Case "DR"
            lReturn = 0
        Case "MO"
            lReturn = 5
        Case "WA", "IO"
            lReturn = 20
        Case "GL"
            lReturn = 15
        Case "RA"
            lReturn = 5
        Case "KN"
            lReturn = 10
        Case "PA"
            lReturn = 8
        Case "VA"
            lReturn = 7
        Case "WE"
            lReturn = 10
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 10
    End Select
    lClassArmourAbsorbtionChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lClassArmourAbsorbtionChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateInitiativeChance(lStance As Long) As Long
On Error Resume Next
    Dim lReturn As Long
    Select Case lStance
        Case 0 'normal
            lReturn = 1
        Case 1 'aggro
            lReturn = 5
        Case 2 'defensive
            lReturn = 9
        Case 3 'slay
            lReturn = 5
        Case 4 'waterloo
            lReturn = 8
        Case 5 'chiotru
            lReturn = 9
        Case Else
            lReturn = 0
    End Select
    lTranslateInitiativeChance = lReturn
End Function
Public Function lTranslateSoulStealCost(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    'best thieves are (in order): "TH" "GY" "BA" "AS"
    lReturn = 4000 '/ lTranslateThiefPickLock(zPlayerClass)
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "TH"
            lReturn = 200
        Case "GY"
            lReturn = 500
        Case "BA"
            lReturn = 600
        Case "AS"
            lReturn = 950
        Case "MA"
            lReturn = 3000
        Case "CL"
            lReturn = 2500
        Case "DR"
            lReturn = 2000
        Case "MO"
            lReturn = 1000
        Case "WA"
            lReturn = 2700
        Case "GL"
            lReturn = 2200
        Case "RA"
            lReturn = 2100
        Case "KN"
            lReturn = 2150
        Case "PA"
            lReturn = 2250
        Case "VA"
            lReturn = 1150
        Case "WE"
            lReturn = 950
        Case "PL", "VE"
            lReturn = 1350
        Case "CY"
            lReturn = 1750
    End Select
    lTranslateSoulStealCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSoulStealCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateWearMAXRC(zRaceType As String, zClassType As String, zType As String) As Long
On Error GoTo Err_Check '52 gbllWearItemMAXLimit is absolute max a player can wear for item placements
    Dim lReturn As Long
    lReturn = 0
    If zType = "B" Or zType = "R" Then
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "GNO"
            lReturn = 22
        Case "HAL"
            lReturn = 12
        Case "OGE"
            lReturn = 20
        Case "ELF"
            lReturn = 12
        Case "ORC"
            lReturn = 14
        Case "FEL"
            lReturn = 14
        Case "HUM"
            lReturn = 14
        Case "MIN"
            lReturn = 20
        Case "DWA"
            lReturn = 11
        Case "TRO"
            lReturn = 20
        Case "DRA"
            lReturn = 16
        Case "PIX"
            lReturn = 6
        Case "UND"
            lReturn = 18 'being burning during the process is just fine with the undead
    End Select
    End If
    
    If zType = "B" Or zType = "C" Then
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "TH"
            lReturn = lReturn + 1
        Case "GY"
            lReturn = lReturn + 1
        Case "BA"
            lReturn = lReturn + 1
        Case "AS"
            lReturn = lReturn + 1
        Case "MA"
            lReturn = lReturn + 1
        Case "CL"
            lReturn = lReturn + 1
        Case "DR"
            lReturn = lReturn + 1
        Case "MO"
            lReturn = lReturn + 1
        Case "WA"
            lReturn = lReturn + 2
        Case "GL"
            lReturn = lReturn + 2
        Case "RA"
            lReturn = lReturn + 2
        Case "KN"
            lReturn = lReturn + 1
        Case "PA"
            lReturn = lReturn + 3
        Case "VA"
            lReturn = lReturn + 3
        Case "WE"
            lReturn = lReturn + 3
        Case "PL", "VE"
            lReturn = lReturn + 4
        Case "CY"
            lReturn = lReturn + 8
        Case "IO"
            lReturn = lReturn + 3
    End Select
    End If
    lTranslateWearMAXRC = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateWearMAXRC," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateWidthHeightRaceClass(zRace As String, zClass As String, iType As Integer) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    'this is to be used as a multiple.
    Select Case (iType = 1 Or iType = 3)
        Case True
            Select Case UCase(Mid(zClass, 1, 2))
                Case "TH"
                    lReturn = lReturn + 1
                Case "GY"
                    lReturn = lReturn + 2
                Case "BA"
                    lReturn = lReturn + 3
                Case "AS"
                    lReturn = lReturn + 1
                Case "MA"
                    lReturn = lReturn + 1
                Case "CL"
                    lReturn = lReturn + 4
                Case "DR"
                    lReturn = lReturn + 5
                Case "MO"
                    lReturn = lReturn + 1
                Case "WA"
                    lReturn = lReturn + 2
                Case "GL"
                    lReturn = lReturn + 2
                Case "RA"
                    lReturn = lReturn + 1
                Case "KN"
                    lReturn = lReturn + 3
                Case "PA"
                    lReturn = lReturn + 2
                Case "VA"
                    lReturn = lReturn + 2
                Case "WE"
                    lReturn = lReturn + 3
                Case "PL", "VE"
                    lReturn = lReturn + 4
                Case "CY"
                    lReturn = lReturn + 1
            End Select
    End Select
    
    Select Case (iType = 2 Or iType = 3)
        Case True
            Select Case zRace
                Case "GNO"
                    lReturn = lReturn + 2
                Case "HAL"
                    lReturn = lReturn + 3
                Case "OGE"
                    lReturn = lReturn + 5
                Case "ELF"
                    lReturn = lReturn + 0
                Case "ORC"
                    lReturn = lReturn + 6
                Case "FEL"
                    lReturn = lReturn + 8
                Case "HUM"
                    lReturn = lReturn + 2
                Case "MIN"
                    lReturn = lReturn + 0
                Case "DWA"
                    lReturn = lReturn + 5
                Case "TRO"
                    lReturn = lReturn + 9
                Case "DRA"
                    lReturn = lReturn + 3
                Case "PIX"
                    lReturn = lReturn + 1
                Case "UND"
                    lReturn = lReturn + 1
            End Select
    End Select
    lTranslateWidthHeightRaceClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateWidthHeightRaceClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateGainStatsClassBonus(zClass As String, zType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    
    Select Case (zType)
        Case "STR"
            Select Case zClass
                Case "AS"
                    lReturn = 3
                Case "BA"
                    lReturn = 3
                Case "CL"
                    lReturn = 0
                Case "DR"
                    lReturn = 0
                Case "GL"
                    lReturn = 4
                Case "GY", "IO"
                    lReturn = 3
                Case "MA"
                    lReturn = 0
                Case "MO"
                    lReturn = 3
                Case "PA"
                    lReturn = 1
                Case "RA"
                    lReturn = 2
                Case "TH"
                    lReturn = 0
                Case "KN"
                    lReturn = 5
                Case "WA"
                    lReturn = 6
                Case "CY"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 0
                Case "WE"
                    lReturn = 6
                Case "VA"
                    lReturn = 5
                Case Else
                    lReturn = 0
            End Select
        Case "INT"
            Select Case zClass
                Case "AS"
                    lReturn = 1
                Case "BA"
                    lReturn = 3
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 3
                Case "GL"
                    lReturn = 1
                Case "GY"
                    lReturn = 5
                Case "MA"
                    lReturn = 6
                Case "MO"
                    lReturn = 3
                Case "PA"
                    lReturn = 3
                Case "RA"
                    lReturn = 3
                Case "TH"
                    lReturn = 1
                Case "KN"
                    lReturn = 1
                Case "WA"
                    lReturn = 0
                Case "CY", "IO"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 1
                Case "WE"
                    lReturn = 1
                Case "VA"
                    lReturn = 3
                Case Else
                    lReturn = 0
            End Select
        Case "WIS"
            Select Case zClass
                Case "AS"
                    lReturn = 2
                Case "BA"
                    lReturn = 3
                Case "CL"
                    lReturn = 6
                Case "DR"
                    lReturn = 6
                Case "GL"
                    lReturn = 1
                Case "GY"
                    lReturn = 4
                Case "MA"
                    lReturn = 3
                Case "MO"
                    lReturn = 3
                Case "PA"
                    lReturn = 3
                Case "RA"
                    lReturn = 3
                Case "TH"
                    lReturn = 3
                Case "KN"
                    lReturn = 4
                Case "WA"
                    lReturn = 0
                Case "CY"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 4
                Case "WE", "IO"
                    lReturn = 1
                Case "VA"
                    lReturn = 3
                Case Else
                    lReturn = 0
            End Select
        Case "DEX"
            Select Case zClass
                Case "AS"
                    lReturn = 6
                Case "BA"
                    lReturn = 3
                Case "CL"
                    lReturn = 1
                Case "DR"
                    lReturn = 3
                Case "GL"
                    lReturn = 5
                Case "GY"
                    lReturn = 5
                Case "MA"
                    lReturn = 0
                Case "MO"
                    lReturn = 3
                Case "PA"
                    lReturn = 2
                Case "RA"
                    lReturn = 6
                Case "TH"
                    lReturn = 6
                Case "KN"
                    lReturn = 4
                Case "WA"
                    lReturn = 3
                Case "CY"
                    lReturn = 0
                Case "PL", "VE"
                    lReturn = 6
                Case "WE", "IO"
                    lReturn = 6
                Case "VA"
                    lReturn = 5
                Case Else
                    lReturn = 0
            End Select
        Case "CON"
            Select Case zClass
                Case "AS"
                    lReturn = 3
                Case "BA"
                    lReturn = 5
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 3
                Case "GL"
                    lReturn = 6
                Case "GY"
                    lReturn = 5
                Case "MA"
                    lReturn = 0
                Case "MO"
                    lReturn = 6
                Case "PA"
                    lReturn = 3
                Case "RA"
                    lReturn = 3
                Case "TH"
                    lReturn = 1
                Case "KN"
                    lReturn = 3
                Case "WA"
                    lReturn = 6
                Case "CY"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 1
                Case "WE"
                    lReturn = 3
                Case "VA", "IO"
                    lReturn = 3
                Case Else
                    lReturn = 0
            End Select
        Case "CHA"
            Select Case zClass
                Case "AS"
                    lReturn = 6
                Case "BA"
                    lReturn = 6
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 6
                Case "GL"
                    lReturn = 3
                Case "GY"
                    lReturn = 4
                Case "MA", "IO"
                    lReturn = 1
                Case "MO"
                    lReturn = 3
                Case "PA"
                    lReturn = 4
                Case "RA"
                    lReturn = 6
                Case "TH"
                    lReturn = 6
                Case "KN"
                    lReturn = 15
                Case "WA"
                    lReturn = 0
                Case "CY"
                    lReturn = 1
                Case "PL", "VE"
                    lReturn = 6
                Case "WE"
                    lReturn = 1
                Case "VA"
                    lReturn = 6
                Case Else
                    lReturn = 0
            End Select
        Case "LUC"
            Select Case zClass
                Case "AS"
                    lReturn = 4
                Case "BA"
                    lReturn = 3
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 1
                Case "GL"
                    lReturn = 5
                Case "GY"
                    lReturn = 6
                Case "MA"
                    lReturn = 1
                Case "MO"
                    lReturn = 3
                Case "PA"
                    lReturn = 0
                Case "RA"
                    lReturn = 0
                Case "TH"
                    lReturn = 6
                Case "KN"
                    lReturn = 6
                Case "WA", "IO"
                    lReturn = 0
                Case "CY"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 6
                Case "WE"
                    lReturn = 0
                Case "VA"
                    lReturn = 6
                Case Else
                    lReturn = 0
            End Select
    End Select
    
    lTranslateGainStatsClassBonus = lReturn
End Function
Public Function lTranslateGainStatsRaceBonus(zRace As String, zType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Select Case (zType)
        Case "STR"
            Select Case zRace
                Case "DRA"
                    lReturn = 3
                Case "DWA"
                    lReturn = 3
                Case "ELF"
                    lReturn = 0
                Case "FEL"
                    lReturn = 0
                Case "GNO"
                    lReturn = 1
                Case "HAL"
                    lReturn = 0
                Case "HUM"
                    lReturn = 1
                Case "MIN"
                    lReturn = 4
                Case "OGR"
                    lReturn = 4
                Case "ORC"
                    lReturn = 4
                Case "PIX"
                    lReturn = 0
                Case "TRO"
                    lReturn = 5
                Case "UND"
                    lReturn = 0
                Case Else
                    lReturn = 0
            End Select
        Case "INT"
            Select Case zRace
                Case "DRA"
                    lReturn = 3
                Case "DWA"
                    lReturn = 3
                Case "ELF"
                    lReturn = 5
                Case "FEL"
                    lReturn = 1
                Case "GNO"
                    lReturn = 5
                Case "HAL"
                    lReturn = 3
                Case "HUM"
                    lReturn = 4
                Case "MIN"
                    lReturn = 0
                Case "OGR"
                    lReturn = 0
                Case "ORC"
                    lReturn = 1
                Case "PIX"
                    lReturn = 5
                Case "TRO"
                    lReturn = 0
                Case "UND"
                    lReturn = 0
                Case Else
                    lReturn = 0
            End Select
        Case "WIS"
            Select Case zRace
                Case "DRA"
                    lReturn = 3
                Case "DWA"
                    lReturn = 3
                Case "ELF"
                    lReturn = 2
                Case "FEL"
                    lReturn = 5
                Case "GNO"
                    lReturn = 3
                Case "HAL"
                    lReturn = 1
                Case "HUM"
                    lReturn = 2
                Case "MIN"
                    lReturn = 0
                Case "OGR"
                    lReturn = 0
                Case "ORC"
                    lReturn = 2
                Case "PIX"
                    lReturn = 5
                Case "TRO"
                    lReturn = 0
                Case "UND"
                    lReturn = 0
                Case Else
                    lReturn = 0
            End Select
        Case "DEX"
            Select Case zRace
                Case "DRA"
                    lReturn = 0
                Case "DWA"
                    lReturn = 0
                Case "ELF"
                    lReturn = 4
                Case "FEL"
                    lReturn = 5
                Case "GNO"
                    lReturn = 0
                Case "HAL"
                    lReturn = 5
                Case "HUM"
                    lReturn = 3
                Case "MIN"
                    lReturn = 0
                Case "OGR"
                    lReturn = 0
                Case "ORC"
                    lReturn = 0
                Case "PIX"
                    lReturn = 5
                Case "TRO"
                    lReturn = 0
                Case "UND"
                    lReturn = 0
                Case Else
                    lReturn = 0
            End Select
        Case "CON"
            Select Case zRace
                Case "DRA"
                    lReturn = 3
                Case "DWA"
                    lReturn = 3
                Case "ELF"
                    lReturn = 0
                Case "FEL"
                    lReturn = 0
                Case "GNO"
                    lReturn = 2
                Case "HAL"
                    lReturn = 0
                Case "HUM"
                    lReturn = 1
                Case "MIN"
                    lReturn = 4
                Case "OGR"
                    lReturn = 4
                Case "ORC"
                    lReturn = 3
                Case "PIX"
                    lReturn = 0
                Case "TRO"
                    lReturn = 5
                Case "UND"
                    lReturn = 0
                Case Else
                    lReturn = 0
            End Select
        Case "CHA"
            Select Case zRace
                Case "DRA"
                    lReturn = 0
                Case "DWA"
                    lReturn = 3
                Case "ELF"
                    lReturn = 5
                Case "FEL"
                    lReturn = 5
                Case "GNO"
                    lReturn = 1
                Case "HAL"
                    lReturn = 3
                Case "HUM"
                    lReturn = 5
                Case "MIN"
                    lReturn = 0
                Case "OGR"
                    lReturn = 0
                Case "ORC"
                    lReturn = 0
                Case "PIX"
                    lReturn = 0
                Case "TRO"
                    lReturn = 0
                Case "UND"
                    lReturn = 0
                Case Else
                    lReturn = 0
            End Select
        Case "LUC"
            Select Case zRace
                Case "DRA"
                    lReturn = 3
                Case "DWA"
                    lReturn = 3
                Case "ELF"
                    lReturn = 5
                Case "FEL"
                    lReturn = 5
                Case "GNO"
                    lReturn = 3
                Case "HAL"
                    lReturn = 5
                Case "HUM"
                    lReturn = 5
                Case "MIN"
                    lReturn = 0
                Case "OGR"
                    lReturn = 1
                Case "ORC"
                    lReturn = 2
                Case "PIX"
                    lReturn = 5
                Case "TRO"
                    lReturn = 3
                Case "UND"
                    lReturn = 2
                Case Else
                    lReturn = 0
            End Select
    End Select
    lTranslateGainStatsRaceBonus = lReturn
End Function
Public Function lTranslateMoveStealCost(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    'best thieves are (in order): "TH" "GY" "BA" "AS"
    lReturn = 4000 '/ lTranslateThiefPickLock(zPlayerClass)
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "TH"
            lReturn = 400
        Case "GY"
            lReturn = 500
        Case "BA"
            lReturn = 600
        Case "AS"
            lReturn = 950
        Case "MA"
            lReturn = 3000
        Case "CL"
            lReturn = 2500
        Case "DR"
            lReturn = 2000
        Case "MO"
            lReturn = 1000
        Case "WA"
            lReturn = 2700
        Case "GL"
            lReturn = 2200
        Case "RA"
            lReturn = 2100
        Case "KN"
            lReturn = 2150
        Case "PA"
            lReturn = 2250
        Case "VA"
            lReturn = 1150
        Case "WE"
            lReturn = 950
        Case "PL", "VE"
            lReturn = 1350
        Case "CY"
            lReturn = 1750
    End Select
    lTranslateMoveStealCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateMoveStealCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateForgeFreeGloryChance(zRaceType As String, zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    Select Case zRaceType
        Case "GNO"
            lReturn = 15
        Case "HAL"
            lReturn = 3
        Case "OGE"
            lReturn = 5
        Case "ELF"
            lReturn = 3
        Case "ORC"
            lReturn = 6
        Case "FEL"
            lReturn = 8
        Case "HUM"
            lReturn = 2
        Case "MIN"
            lReturn = 0
        Case "DWA"
            lReturn = 10
        Case "TRO"
            lReturn = 4
        Case "DRA"
            lReturn = 30
        Case "PIX"
            lReturn = 2
        Case "UND"
            lReturn = 12 'being burning during the process is just fine with the undead
        Case Else
            lReturn = 0
    End Select
    
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "TH"
            lReturn = lReturn + 5
        Case "GY"
            lReturn = lReturn + 5
        Case "BA"
            lReturn = lReturn + 8
        Case "AS"
            lReturn = lReturn + 12
        Case "MA"
            lReturn = lReturn + 1
        Case "CL"
            lReturn = lReturn + 2
        Case "DR"
            lReturn = lReturn + 3
        Case "MO"
            lReturn = lReturn + 7
        Case "WA"
            lReturn = lReturn + 25
        Case "GL"
            lReturn = lReturn + 35
        Case "RA"
            lReturn = lReturn + 20
        Case "KN"
            lReturn = lReturn + 16
        Case "PA"
            lReturn = lReturn + 18
        Case "VA"
            lReturn = lReturn + 16
        Case "WE"
            lReturn = lReturn + 16
        Case "PL", "VE"
            lReturn = lReturn + 16
        Case "CY"
            lReturn = lReturn + 16
        Case "IO"
            lReturn = lReturn + 16
    End Select
    lTranslateForgeFreeGloryChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateForgeFreeGloryChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassOffensiveSpell(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 2
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA", "IO"
            lReturn = 50
        Case "CL"
            lReturn = 40
        Case "DR"
            lReturn = 35
        Case "BA"
            lReturn = 20
        Case "MO"
            lReturn = 15
        Case "AS"
            lReturn = 4
        Case "GY"
            lReturn = 10
        Case "TH"
            lReturn = 2
        Case "WA"
            lReturn = 2
        Case "GL"
            lReturn = 3
        Case "RA"
            lReturn = 9
        Case "KN"
            lReturn = 8
        Case "PA"
            lReturn = 15
        Case "VA"
            lReturn = 12
        Case "WE"
            lReturn = 13
        Case "PL", "VE"
            lReturn = 15
        Case "CY"
            lReturn = 14
    End Select
    lTranslateClassOffensiveSpell = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassOffensiveSpell," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassDodgeTimes(zClassType As String, zRaceType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 3
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 10
        Case "CL"
            iReturn = 9
        Case "DR"
            iReturn = 8
        Case "BA"
            iReturn = 8
        Case "MO"
            iReturn = 8
        Case "AS"
            iReturn = 12
        Case "GY"
            iReturn = 15
        Case "TH"
            iReturn = 6
        Case "WA"
            iReturn = 7
        Case "GL"
            iReturn = 8
        Case "RA"
            iReturn = 8
        Case "KN"
            iReturn = 5
        Case "PA"
            iReturn = 6
        Case "PL", "VE"
            iReturn = 15
        Case "CY"
            iReturn = 4
        Case "VA"
            iReturn = 12
        Case "WE"
            iReturn = 13
    End Select
    Select Case zRaceType
        Case "GNO"
            iReturn = iReturn + 10
        Case "HAL"
            iReturn = iReturn + 2
        Case "OGE"
            iReturn = iReturn + 1
        Case "ELF"
            iReturn = iReturn + 2
        Case "ORC"
            iReturn = iReturn + 1
        Case "FEL"
            iReturn = iReturn + 15
        Case "HUM"
            iReturn = iReturn + 4
        Case "MIN"
            iReturn = iReturn + 1
        Case "DWA"
            iReturn = iReturn + 2
        Case "TRO"
            iReturn = iReturn + 2
        Case "DRA"
            iReturn = iReturn + 5
        Case "PIX"
            iReturn = iReturn + 10
        Case "UND"
            iReturn = iReturn + 1
        Case Else
            iReturn = iReturn + 1
    End Select
    iTranslateClassDodgeTimes = (iReturn / 2) + 1
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassDodgeTimes," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassParryTimes(zClassType As String, zRaceType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 10
        Case "CL"
            iReturn = 9
        Case "DR"
            iReturn = 8
        Case "BA"
            iReturn = 8
        Case "MO"
            iReturn = 8
        Case "AS"
            iReturn = 12
        Case "GY"
            iReturn = 15
        Case "TH"
            iReturn = 6
        Case "WA"
            iReturn = 7
        Case "GL"
            iReturn = 8
        Case "RA"
            iReturn = 8
        Case "KN"
            iReturn = 5
        Case "PA"
            iReturn = 6
        Case "PL", "VE"
            iReturn = 15
        Case "CY"
            iReturn = 4
        Case "VA"
            iReturn = 12
        Case "WE"
            iReturn = 13
    End Select
    Select Case zRaceType
        Case "GNO"
            iReturn = iReturn + 10
        Case "HAL"
            iReturn = iReturn + 4
        Case "OGE"
            iReturn = iReturn + 1
        Case "ELF"
            iReturn = iReturn + 9
        Case "ORC"
            iReturn = iReturn + 1
        Case "FEL"
            iReturn = iReturn + 7
        Case "HUM"
            iReturn = iReturn + 4
        Case "MIN"
            iReturn = iReturn + 1
        Case "DWA"
            iReturn = iReturn + 2
        Case "TRO"
            iReturn = iReturn + 2
        Case "DRA"
            iReturn = iReturn + 5
        Case "PIX"
            iReturn = iReturn + 10
        Case "UND"
            iReturn = iReturn + 1
        Case Else
            iReturn = iReturn + 1
    End Select
    iTranslateClassParryTimes = (iReturn / 2) + 1
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassParryTimes," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassDodgePercent(zClassType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 1
        Case "CL"
            iReturn = 2
        Case "DR"
            iReturn = 4
        Case "BA"
            iReturn = 4
        Case "MO"
            iReturn = 5
        Case "AS"
            iReturn = 5
        Case "GY"
            iReturn = 3
        Case "TH"
            iReturn = 7
        Case "WA"
            iReturn = 7
        Case "GL"
            iReturn = 5
        Case "RA"
            iReturn = 4
        Case "KN"
            iReturn = 2
        Case "PA"
            iReturn = 3
        Case "PL", "VE"
            iReturn = 1
        Case "CY"
            iReturn = 1
        Case "VA"
            iReturn = 6
        Case "WE"
            iReturn = 6
    End Select
    iTranslateClassDodgePercent = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassDodgePercent," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassParryPercent(zClassType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 2
        Case "CL"
            iReturn = 3
        Case "DR"
            iReturn = 4
        Case "BA"
            iReturn = 4
        Case "MO"
            iReturn = 5
        Case "AS"
            iReturn = 5
        Case "GY"
            iReturn = 5
        Case "TH"
            iReturn = 7
        Case "WA"
            iReturn = 5
        Case "GL"
            iReturn = 6
        Case "RA"
            iReturn = 7
        Case "KN"
            iReturn = 4
        Case "PA"
            iReturn = 6
        Case "PL", "VE"
            iReturn = 4
        Case "CY"
            iReturn = 4
        Case "VA"
            iReturn = 6
        Case "WE"
            iReturn = 6
    End Select
    iTranslateClassParryPercent = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassParryPercent," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassWeaponBlockPercent(zClassType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 1
        Case "CL"
            iReturn = 3
        Case "DR"
            iReturn = 2
        Case "BA"
            iReturn = 2
        Case "MO"
            iReturn = 1
        Case "AS"
            iReturn = 5
        Case "GY"
            iReturn = 5
        Case "TH"
            iReturn = 7
        Case "WA"
            iReturn = 9
        Case "GL"
            iReturn = 12
        Case "RA"
            iReturn = 7
        Case "KN"
            iReturn = 15
        Case "PA"
            iReturn = 6
        Case "PL", "VE"
            iReturn = 1
        Case "CY"
            iReturn = 1
        Case "VA"
            iReturn = 1
        Case "WE"
            iReturn = 1
    End Select
    iTranslateClassWeaponBlockPercent = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassWeaponBlockPercent," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassWeaponBlockPercentTNL(zClassType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 500
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 1000
        Case "CL"
            iReturn = 500
        Case "DR"
            iReturn = 800
        Case "BA"
            iReturn = 700
        Case "MO"
            iReturn = 200
        Case "AS"
            iReturn = 800
        Case "GY"
            iReturn = 500
        Case "TH"
            iReturn = 200
        Case "WA"
            iReturn = 100
        Case "GL"
            iReturn = 100
        Case "RA"
            iReturn = 600
        Case "KN"
            iReturn = 300
        Case "PA"
            iReturn = 500
        Case "PL", "VE"
            iReturn = 1000
        Case "CY"
            iReturn = 1000
        Case "VA"
            iReturn = 800
        Case "WE"
            iReturn = 600
    End Select
    iTranslateClassWeaponBlockPercentTNL = iReturn + 325
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassWeaponBlockPercentTNL," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassDodgePercentTNL(zClassType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 500
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 1000
        Case "CL"
            iReturn = 500
        Case "DR"
            iReturn = 800
        Case "BA"
            iReturn = 700
        Case "MO"
            iReturn = 200
        Case "AS"
            iReturn = 800
        Case "GY"
            iReturn = 500
        Case "TH"
            iReturn = 200
        Case "WA"
            iReturn = 100
        Case "GL"
            iReturn = 100
        Case "RA"
            iReturn = 100
        Case "KN"
            iReturn = 200
        Case "PA"
            iReturn = 300
        Case "PL", "VE"
            iReturn = 1000
        Case "CY"
            iReturn = 1000
        Case "VA"
            iReturn = 500
        Case "WE"
            iReturn = 500
    End Select
    iTranslateClassDodgePercentTNL = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassDodgePercentTNL," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTranslateClassParryPercentTNL(zClassType As String) As Integer
On Error GoTo Err_Check
    Dim iReturn As Integer
    iReturn = 1000
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            iReturn = 300
        Case "CL"
            iReturn = 400
        Case "DR"
            iReturn = 500
        Case "BA"
            iReturn = 500
        Case "MO"
            iReturn = 300
        Case "AS"
            iReturn = 700
        Case "GY"
            iReturn = 600
        Case "TH"
            iReturn = 600
        Case "WA"
            iReturn = 100
        Case "GL"
            iReturn = 300
        Case "RA"
            iReturn = 100
        Case "KN"
            iReturn = 200
        Case "PA"
            iReturn = 400
        Case "PL", "VE"
            iReturn = 1000
        Case "CY"
            iReturn = 1000
        Case "VA"
            iReturn = 500
        Case "WE"
            iReturn = 500
    End Select
    iTranslateClassParryPercentTNL = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iTranslateClassparryPercentTNL," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSpellHealRatio(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 35
        Case "CL"
            lReturn = 450
        Case "DR"
            lReturn = 50
        Case "BA"
            lReturn = 25
        Case "MO"
            lReturn = 40
        Case "AS"
            lReturn = 20
        Case "GY"
            lReturn = 23
        Case "TH"
            lReturn = 16
        Case "WA"
            lReturn = 2
        Case "GL"
            lReturn = 1
        Case "RA"
            lReturn = 25
        Case "KN"
            lReturn = 20 'same as paladin but can heal self
        Case "PA"
            lReturn = 190 'same as knight but can heal others
        Case "VA"
            lReturn = 300
        Case "WE"
            lReturn = 300
        Case "PL", "VE"
            lReturn = 1000
        Case "CY"
            lReturn = 600
    End Select
    lTranslateSpellHealRatio = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSpellHealRatio," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateCastSkinsClassValue(zClassType As String, zSkinType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 1
    Select Case zSkinType '5 long all caps only, these are the bonuses.
        Case "BARKS", "STATI"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 50
                Case "CL"
                    lReturn = 50
                Case "DR"
                    lReturn = 100
                Case "BA"
                    lReturn = 30
                Case "MO"
                    lReturn = 18
                Case "AS"
                    lReturn = 2
                Case "GY"
                    lReturn = 15
                Case "TH"
                    lReturn = 4
                Case "WA"
                    lReturn = 1
                Case "GL"
                    lReturn = 2
                Case "RA"
                    lReturn = 35
                Case "KN"
                    lReturn = 2 'same as paladin but can heal self
                Case "PA"
                    lReturn = 9 'same as knight but can heal others
                Case "VA"
                    lReturn = 50
                Case "WE"
                    lReturn = 50
                Case "PL", "VE"
                    lReturn = 200
                Case "CY"
                    lReturn = 50
            End Select
        Case "STONE", "ICESH"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 150
                Case "CL"
                    lReturn = 100
                Case "DR"
                    lReturn = 20
                Case "BA"
                    lReturn = 30
                Case "MO"
                    lReturn = 18
                Case "AS"
                    lReturn = 50
                Case "GY"
                    lReturn = 15
                Case "TH"
                    lReturn = 65
                Case "WA"
                    lReturn = 1
                Case "GL"
                    lReturn = 2
                Case "RA"
                    lReturn = 95
                Case "KN"
                    lReturn = 2 'same as paladin but can heal self
                Case "PA"
                    lReturn = 120 'same as knight but can heal others
                Case "VA"
                    lReturn = 50
                Case "WE"
                    lReturn = 10
                Case "PL", "VE"
                    lReturn = 200
                Case "CY"
                    lReturn = 200
            End Select
        Case "DRAGO", "FIRES"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 250
                Case "CL"
                    lReturn = 150
                Case "DR"
                    lReturn = 210
                Case "BA"
                    lReturn = 30
                Case "MO"
                    lReturn = 15
                Case "AS"
                    lReturn = 62
                Case "GY"
                    lReturn = 65
                Case "TH"
                    lReturn = 4
                Case "WA"
                    lReturn = 70
                Case "GL"
                    lReturn = 2
                Case "RA"
                    lReturn = 115
                Case "KN"
                    lReturn = 182 'same as paladin but can heal self
                Case "PA"
                    lReturn = "9" 'same as knight but can heal others
                Case "VA"
                    lReturn = 71
                Case "WE"
                    lReturn = 50
                Case "PL", "VE"
                    lReturn = 100
                Case "CY"
                    lReturn = 400
            End Select
        Case "DEMON", "CHAOS"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 150
                Case "CL"
                    lReturn = 275
                Case "DR"
                    lReturn = 370
                Case "BA"
                    lReturn = 100
                Case "MO"
                    lReturn = 125
                Case "AS"
                    lReturn = 82
                Case "GY"
                    lReturn = 65
                Case "TH"
                    lReturn = 54
                Case "WA"
                    lReturn = 400
                Case "GL"
                    lReturn = 12
                Case "RA"
                    lReturn = 125
                Case "KN"
                    lReturn = 42 'same as paladin but can heal self
                Case "PA"
                    lReturn = 129 'same as knight but can heal others
                Case "VA"
                    lReturn = 240
                Case "WE"
                    lReturn = 300
                Case "PL", "VE"
                    lReturn = 50
                Case "CY"
                    lReturn = 200
            End Select
    End Select
    lTranslateCastSkinsClassValue = lReturn
End Function
Public Function lTranslateSpellBonusByClass(zClassType As String, zSpellName As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case zSpellName
        Case "REST"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = -25
                Case "CL"
                    lReturn = 35
                Case "DR"
                    lReturn = 21
                Case "BA"
                    lReturn = 8
                Case "MO"
                    lReturn = 5
                Case "AS"
                    lReturn = -10
                Case "GY"
                    lReturn = 10
                Case "TH"
                    lReturn = -10
                Case "WA"
                    lReturn = 5
                Case "GL"
                    lReturn = 6
                Case "RA"
                    lReturn = 12
                Case "KN"
                    lReturn = 10
                Case "PA"
                    lReturn = 22
                Case "VA"
                    lReturn = 10
                Case "WE"
                    lReturn = 10
                Case "PL", "VE"
                    lReturn = -55
                Case "CY"
                    lReturn = -55
            End Select
        Case "IDEN"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 0
                Case "CL"
                    lReturn = 20
                Case "DR"
                    lReturn = 20
                Case "BA"
                    lReturn = 0
                Case "MO"
                    lReturn = 0
                Case "AS"
                    lReturn = 20
                Case "GY"
                    lReturn = 20
                Case "TH"
                    lReturn = 65
                Case "WA"
                    lReturn = 85
                Case "GL"
                    lReturn = 55
                Case "RA"
                    lReturn = 15
                Case "KN"
                    lReturn = 25
                Case "PA"
                    lReturn = 0
                Case "VA", "WE"
                    lReturn = 10
                Case "PL", "VE"
                    lReturn = 5
                Case "CY"
                    lReturn = 10
            End Select
    End Select
    lTranslateSpellBonusByClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSpellBonusByClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSpellFailValueByClass(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 85
        Case "CL"
            lReturn = 40
        Case "DR"
            lReturn = 37
        Case "BA"
            lReturn = 29
        Case "MO"
            lReturn = 18
        Case "AS"
            lReturn = 20
        Case "GY"
            lReturn = 23
        Case "TH"
            lReturn = 16
        Case "WA"
            lReturn = 10
        Case "GL"
            lReturn = 15
        Case "RA"
            lReturn = 25
        Case "KN"
            lReturn = 20 'same as paladin but can heal self
        Case "PA"
            lReturn = "27" 'same as knight but can heal others
        Case "VA"
            lReturn = 10
        Case "WE"
            lReturn = 10
        Case "PL", "VE"
            lReturn = 60
        Case "CY"
            lReturn = 60
    End Select
    lTranslateSpellFailValueByClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSpellFailValueByClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateDisarmCost(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 8
        Case "DR"
            lReturn = 13
        Case "BA"
            lReturn = 11
        Case "MO"
            lReturn = 4
        Case "AS"
            lReturn = 23
        Case "GY"
            lReturn = 11
        Case "TH"
            lReturn = 6
        Case "WA"
            lReturn = 20
        Case "GL"
            lReturn = 25
        Case "RA"
            lReturn = 18
        Case "KN"
            lReturn = 35 'same as paladin but can heal self
        Case "PA"
            lReturn = 30 'same as knight but can heal others
        Case "VA"
            lReturn = 30
        Case "WE"
            lReturn = 30
        Case "PL", "VE"
            lReturn = 30
        Case "CY"
            lReturn = 30
    End Select
    lTranslateDisarmCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateDisarmCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateThiefPickLock(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 2
        Case "AS"
            lReturn = 13
        Case "GY"
            lReturn = 4
        Case "TH"
            lReturn = 20
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 1
        Case "RA"
            lReturn = 1
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 2 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 3
        Case "PL", "VE"
            lReturn = 3
        Case "CY"
            lReturn = 20
    End Select
    lTranslateThiefPickLock = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateThiefPickLock ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillDoublePunchDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 1
        Case "MO"
            lReturn = 90
        Case "AS"
            lReturn = 60
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 4
        Case "WA"
            lReturn = 3
        Case "GL"
            lReturn = 5
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 9
        Case "PL", "VE"
            lReturn = 200
        Case "CY"
            lReturn = 100
    End Select
    lTranslateSkillDoublePunchDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillDoublePunchDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillEnsnareCost(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    'Ensnare skill only works if the person can hold a NET item like Gladiator, so we just fill the table here. Mage could cast Web spell for this value too.
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 8
        Case "CL"
            lReturn = 3
        Case "DR"
            lReturn = 3
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 1
        Case "AS"
            lReturn = 3
        Case "GY"
            lReturn = 2
        Case "TH"
            lReturn = 4
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 3 'same as paladin but can heal self
        Case "PA"
            lReturn = 4 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 4
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 5
    End Select
    lTranslateSkillEnsnareCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillEnsnareCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillStunCost(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    'Current classes: Assassin Bard Cleric Druid Gladiator Gypsy Knight Mage Monk Paladin Ranger Thief Warrior
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 8
        Case "CL"
            lReturn = 3
        Case "DR"
            lReturn = 3
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 1
        Case "AS"
            lReturn = 2
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 4
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 3
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 5 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 4
        Case "PL", "VE"
            lReturn = 3
        Case "CY"
            lReturn = 3
    End Select
    lTranslateSkillStunCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillStunCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillKneeDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 50
        Case "CL"
            lReturn = 20
        Case "DR"
            lReturn = 50
        Case "BA"
            lReturn = 20
        Case "MO"
            lReturn = 40
        Case "AS"
            lReturn = 65
        Case "GY"
            lReturn = 123
        Case "TH"
            lReturn = 190
        Case "WA"
            lReturn = 20
        Case "GL"
            lReturn = 50
        Case "RA"
            lReturn = 181
        Case "KN"
            lReturn = 89 'same as paladin but can heal self
        Case "PA"
            lReturn = 30 'same as knight but can heal others
        Case "VA"
            lReturn = 9
        Case "WE"
            lReturn = 250
        Case "PL", "VE"
            lReturn = 50
        Case "CY"
            lReturn = 200
    End Select
    lTranslateSkillKneeDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillKneeDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillElbowDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 1
        Case "MO"
            lReturn = 20
        Case "AS"
            lReturn = 125
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 70
        Case "WA"
            lReturn = 153
        Case "GL"
            lReturn = 45
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA"
            lReturn = 9
        Case "WE"
            lReturn = 99
        Case "PL", "VE"
            lReturn = 1000
        Case "CY"
            lReturn = 50
    End Select
    lTranslateSkillElbowDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillElbowDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillHeadButtDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 20
        Case "BA"
            lReturn = 10
        Case "MO"
            lReturn = 20
        Case "AS"
            lReturn = 65
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 30
        Case "WA"
            lReturn = 150
        Case "GL"
            lReturn = 25
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA"
            lReturn = 200
        Case "WE"
            lReturn = 300
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 300
    End Select
    lTranslateSkillHeadButtDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillHeadButtDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillClawHandDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 5
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 72
        Case "BA"
            lReturn = 30
        Case "MO"
            lReturn = 60
        Case "AS"
            lReturn = 125
        Case "GY"
            lReturn = 95
        Case "TH"
            lReturn = 44
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 30
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 60 'same as knight but can heal others
        Case "VA"
            lReturn = 20
        Case "WE"
            lReturn = 500
        Case "PL", "VE"
            lReturn = 100
        Case "CY"
            lReturn = 100
    End Select
    lTranslateSkillClawHandDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillClawHandDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillDragonUppercutDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 15
        Case "CL"
            lReturn = 25
        Case "DR"
            lReturn = 72
        Case "BA"
            lReturn = 110
        Case "MO"
            lReturn = 180
        Case "AS"
            lReturn = 65
        Case "GY"
            lReturn = 53
        Case "TH"
            lReturn = 44
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 25
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 60 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 70
        Case "PL", "VE"
            lReturn = 200
        Case "CY"
            lReturn = 200
    End Select
    lTranslateSkillDragonUppercutDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillDragonUppercutDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillKnifeHandDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 2
        Case "DR"
            lReturn = 40
        Case "BA"
            lReturn = 111
        Case "MO"
            lReturn = 120
        Case "AS"
            lReturn = 165
        Case "GY"
            lReturn = 73
        Case "TH"
            lReturn = 24
        Case "WA"
            lReturn = 50
        Case "GL"
            lReturn = 25
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 69
        Case "PL", "VE"
            lReturn = 100
        Case "CY"
            lReturn = 100
    End Select
    lTranslateSkillKnifeHandDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillKnifeHandDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassPlayerPetsAllowed(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 6
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 1
        Case "AS"
            lReturn = 1
        Case "GY"
            lReturn = 2
        Case "TH"
            lReturn = 1
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 5
        Case "KN"
            lReturn = 2 'horse and dog kinda of idea
        Case "PA"
            lReturn = 3
        Case "VA"
            lReturn = 2
        Case "WE"
            lReturn = 2
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 1
    End Select
    lTranslateClassPlayerPetsAllowed = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassPlayerPetsAllowed," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassHitRoll(zClassType As String, zRaceType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 2
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 1
        Case "AS"
            lReturn = 6
        Case "GY"
            lReturn = 2
        Case "TH"
            lReturn = 1
        Case "WA"
            lReturn = 20
        Case "GL"
            lReturn = 15
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 3 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA"
            lReturn = 10
            If (zRaceType = "UND") Then lReturn = lReturn + 2
        Case "WE"
            lReturn = 10
            If (zRaceType = "UND") Then lReturn = lReturn + 2
        Case "PL", "VE"
            lReturn = 12
            If (zRaceType = "ELF") Then lReturn = lReturn + 2
        Case "CY"
            lReturn = 9
            If (zRaceType = "TRO" Or zRaceType = "OGR") Then lReturn = lReturn + 4
    End Select
    
    lTranslateClassHitRoll = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassHitRoll," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassPlayerLevelBarehandsBonus(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 2
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 10
        Case "AS"
            lReturn = 6
        Case "GY"
            lReturn = 5
        Case "TH"
            lReturn = 3
        Case "WA"
            lReturn = 8
        Case "GL"
            lReturn = 6
        Case "RA"
            lReturn = 4
        Case "KN"
            lReturn = 4 'same as paladin but can heal self
        Case "PA"
            lReturn = 4 'same as knight but can heal others
        Case "VA", "WE" 'VA means Vampire and Werewolfs and all other Bitten Classes. This is all the dark creature bonuses. However being the class you must find the proper teacher which means you have to be bitten by all the night creature to collect all the hidden learn skills!
            lReturn = 7
        Case "PL", "VE", "CY" 'VA means Vampire and Werewolfs and all other Bitten Classes. This is all the dark creature bonuses. However being the class you must find the proper teacher which means you have to be bitten by all the night creature to collect all the hidden learn skills!
            lReturn = 2
    End Select
    
    lTranslateClassPlayerLevelBarehandsBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassPlayerLevelBarehandsBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateMartialArtsBarehandedHR(zClass As String, lCHITROLL As Long, lCCHA As Long, lCLuc As Long, lCDEX As Long, zType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    Select Case zClass
        Case "MO", "BA", "VA", "WE"
            Select Case zType 'true martial arts doesnt take a HR penality
                Case "R" 'random - or dice roll
                    lReturn = (lRandom(lCHITROLL) + (lRandom(lCDEX) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + (lRandom(lCCHA) * 2) + (lRandom(lCLuc)))
                Case "M" 'maximum value - just to see what the persons max would be
                    lReturn = ((lCHITROLL) + ((lCDEX) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + ((lCCHA) * 2) + ((lCLuc)))
            End Select
        Case Else
            Select Case zType
                Case "R" 'random
                    lReturn = (lRandom(lCHITROLL / 2) + (lRandom(lCDEX / 4) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + (lRandom(lCCHA / 2) * 2) + (lRandom(lCLuc / 4)))
                Case "M" 'maximum value
                    lReturn = ((lCHITROLL / 2) + ((lCDEX / 4) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + ((lCCHA / 2) * 2) + ((lCLuc / 4)))
            End Select
    End Select
    lTranslateMartialArtsBarehandedHR = lReturn '? lTranslateMartialArtsBarehandedHR("WA", 1000, 100, 100, 200, "M")
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateMartialArtsBarehandedHR," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateMartialArtsBarehandedDR(zClass As String, lCDAMROLL As Long, lCCHA As Long, lCCon As Long, lPlayerLevel As Long, lCStr As Long, zType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    Select Case zClass
        Case "MO", "BA", "VA", "WE"
            Select Case zType 'true martial arts doesnt take a HR penality
                Case "R" 'random
                    lReturn = (lRandom(lCDAMROLL) + (lRandom(lCStr) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + (lRandom(lCCHA) * 2) + (lRandom(lCCon)))
                Case "M" 'maximum value
                    lReturn = ((lCDAMROLL) + ((lCStr) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + ((lCCHA) * 2) + ((lCCon)))
            End Select
        Case Else
            Select Case zType
                Case "R" 'random
                    lReturn = (lRandom(lCDAMROLL / 2) + (lRandom(lCStr / 4) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + (lRandom(lCCHA / 2) * 2) + (lRandom(lCCon / 4)))
                Case "M" 'maximum value
                    lReturn = ((lCDAMROLL / 2) + ((lCStr / 4) * lTranslateClassPlayerLevelBarehandsBonus(zClass)) + ((lCCHA / 2) * 2) + ((lCCon / 4)))
            End Select
    End Select
    lTranslateMartialArtsBarehandedDR = lReturn '? lTranslateMartialArtsBarehandedDR("WA", 1000, 100, 100, 200, "M")
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateMartialArtsBarehandedDR," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassMartialArtsChance(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 8
        Case "CL"
            lReturn = 9
        Case "DR"
            lReturn = 7
        Case "BA"
            lReturn = 7
        Case "MO"
            lReturn = 6
        Case "AS"
            lReturn = 8
        Case "GY"
            lReturn = 9
        Case "TH"
            lReturn = 10
        Case "WA"
            lReturn = 8
        Case "GL"
            lReturn = 7
        Case "RA"
            lReturn = 9
        Case "KN"
            lReturn = 10 'same as paladin but can heal self
        Case "PA"
            lReturn = 10 'same as knight but can heal others
        Case "VA", "WE" 'VA means Vampire and Werewolfs and all other Bitten Classes. This is all the dark creature bonuses. However being the class you must find the proper teacher which means you have to be bitten by all the night creature to collect all the hidden learn skills!
            lReturn = 18
        Case "PL", "VE"
            lReturn = 20
        Case "CY"
            lReturn = 25
    End Select
    
    lTranslateClassMartialArtsChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassMartialArtsChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassHitRollBarehandsBonus(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 5
        Case "CL"
            lReturn = 5
        Case "DR"
            lReturn = 3
        Case "BA"
            lReturn = 10
        Case "MO"
            lReturn = 30
        Case "AS"
            lReturn = 15
        Case "GY"
            lReturn = 14
        Case "TH"
            lReturn = 12
        Case "WA"
            lReturn = 12
        Case "GL"
            lReturn = 11
        Case "RA"
            lReturn = 9
        Case "KN"
            lReturn = 7 'same as paladin but can heal self
        Case "PA"
            lReturn = 8 'same as knight but can heal others
        Case "VA", "WE" 'VA means Vampire and Werewolfs and all other Bitten Classes. This is all the dark creature bonuses. However being the class you must find the proper teacher which means you have to be bitten by all the night creature to collect all the hidden learn skills!
            lReturn = 25
        Case "PL", "VE"
            lReturn = 20
        Case "CY"
            lReturn = 20
    End Select
    
    lTranslateClassHitRollBarehandsBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassHitRollBarehandsBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Function lTranslateEnsnareNetInterruption(zClass As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Select Case zClass 'fighter classes dont get a long ensnare interruption
        Case "GL", "DR", "PL", "VE"
            lReturn = 0
        Case "WA", "KN"
            lReturn = 1
        Case "PA", "AS"
            lReturn = 2
        Case "CL", "MA"
            lReturn = 3
        Case Else
            lReturn = 5
    End Select
    lTranslateEnsnareNetInterruption = lReturn
End Function
Public Function lTranslateClassDamRollBarehandsBonus(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 5
        Case "CL"
            lReturn = 15
        Case "DR"
            lReturn = 10
        Case "BA"
            lReturn = 12
        Case "MO"
            lReturn = 30
        Case "AS"
            lReturn = 20
        Case "GY"
            lReturn = 15
        Case "TH"
            lReturn = 20
        Case "WA"
            lReturn = 25
        Case "GL"
            lReturn = 15
        Case "RA"
            lReturn = 10
        Case "KN"
            lReturn = 15 'same as paladin but can heal self
        Case "PA"
            lReturn = 10 'same as knight but can heal others
        Case "VA", "WE" 'VA means Vampire and Werewolfs and all other Bitten Classes. This is all the dark creature bonuses. However being the class you must find the proper teacher which means you have to be bitten by all the night creature to collect all the hidden learn skills!
            lReturn = 35
        Case "PL", "VE"
            lReturn = 36
        Case "CY"
            lReturn = 36
    End Select
    
    lTranslateClassDamRollBarehandsBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassDamRollBarehandsBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateRegenerationLevelRaceBonus(zRaceType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    Select Case zRaceType
        Case "TRO"
            lReturn = 3
        Case "OGR"
            lReturn = 2
        Case "GNO"
            lReturn = 1
        Case Else
            lReturn = 0
    End Select
    lTranslateRegenerationLevelRaceBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateRegenerationLevelRaceBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassDamRoll(zClassType As String, zRaceType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 4
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 1
        Case "AS"
            lReturn = 6
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 3
        Case "WA"
            lReturn = 9
        Case "GL"
            lReturn = 11
        Case "RA"
            lReturn = 3
        Case "KN"
            lReturn = 7 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA"
            lReturn = 5
            If (zRaceType = "UND") Then lReturn = lReturn + 2
        Case "WE"
            lReturn = 5
            If (zRaceType = "UND") Then lReturn = lReturn + 2
        Case "PL", "VE"
            lReturn = 6
            If (zRaceType = "ELF") Then lReturn = lReturn + 2
        Case "CY"
            lReturn = 6
            If (zRaceType = "TRO" Or zRaceType = "OGR") Then lReturn = lReturn + 2
    End Select
    
    lTranslateClassDamRoll = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassDamRoll," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassHitPointBonus(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 4
        Case "DR"
            lReturn = 1
        Case "BA"
            lReturn = 3
        Case "MO"
            lReturn = 5
        Case "AS"
            lReturn = 4
        Case "GY"
            lReturn = 3
        Case "TH"
            lReturn = 3
        Case "WA"
            lReturn = 15
        Case "GL"
            lReturn = 15
        Case "RA"
            lReturn = 7
        Case "KN"
            lReturn = 17 'same as paladin but can heal self
        Case "PA"
            lReturn = 4 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 12
        Case "PL", "VE"
            lReturn = 9
        Case "CY"
            lReturn = 15
    End Select
    
    lTranslateClassHitPointBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassHitPointBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassScanArea(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 3
        Case "CL"
            lReturn = 3
        Case "DR"
            lReturn = 5
        Case "BA"
            lReturn = 4
        Case "MO"
            lReturn = 3
        Case "AS"
            lReturn = 6
        Case "GY"
            lReturn = 4
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 3
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 6
        Case "KN"
            lReturn = 4 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 5
        Case "PL", "VE"
            lReturn = 6
        Case "CY"
            lReturn = 7
    End Select
    lTranslateClassScanArea = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassScanArea," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lBackStabAttacksLevel(zClass) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClass, 1, 2))
        Case "MA"
            lReturn = 2
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 1
        Case "BA"
            lReturn = 2
        Case "MO"
            lReturn = 3
        Case "AS"
            lReturn = 4
        Case "GY"
            lReturn = 4
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 3
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 1
        Case "KN"
            lReturn = 1
        Case "PA"
            lReturn = 1
        Case "VA"
            lReturn = 2
        Case "WE"
            lReturn = 1
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 1
    End Select
    lBackStabAttacksLevel = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lBackStabAttacksLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillPhysicalCombatHitBonus(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 4
        Case "CL"
            lReturn = 10
        Case "DR"
            lReturn = 5
        Case "BA"
            lReturn = 30
        Case "MO"
            lReturn = 40
        Case "AS"
            lReturn = 55
        Case "GY"
            lReturn = 10
        Case "TH"
            lReturn = 10
        Case "WA"
            lReturn = 30
        Case "GL"
            lReturn = 35
        Case "RA"
            lReturn = 20
        Case "KN"
            lReturn = 10 'same as paladin but can heal self
        Case "PA"
            lReturn = 10 'same as knight but can heal others
        Case "VA"
            lReturn = 40
        Case "WE"
            lReturn = 40
        Case "PL", "VE"
            lReturn = 35
        Case "CY"
            lReturn = 30
    End Select
    lTranslateSkillPhysicalCombatHitBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillHeadButtDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslatePlayerRaceClassIAS(zRace As String, zClass As String) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 0
    Select Case zRace
        Case "TRO"
            lReturn = lReturn + 75
        Case "ORC"
            lReturn = lReturn + 60
        Case "DRA"
            lReturn = lReturn + 50
        Case "GNO"
            lReturn = lReturn + 35
        Case Else
            lReturn = lReturn + 1
    End Select
    Select Case zClass
        Case "WA"
            lReturn = lReturn + 50
        Case "GL", "RA"
            lReturn = lReturn + 40
        Case "AS"
            lReturn = lReturn + 30
        Case "PA"
            lReturn = lReturn + 25
        Case "DR", "MO", "BA"
            lReturn = lReturn + 15
        Case Else
            lReturn = lReturn + 1
    End Select
    lTranslatePlayerRaceClassIAS = lReturn
End Function
Public Function lTranslateSkillDropKickDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 2
        Case "BA"
            lReturn = 1
        Case "MO"
            lReturn = 20
        Case "AS"
            lReturn = 75
        Case "GY"
            lReturn = 43
        Case "TH"
            lReturn = 4
        Case "WA"
            lReturn = 130
        Case "GL"
            lReturn = 95
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA"
            lReturn = 9
        Case "WE"
            lReturn = 350
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 10
    End Select
    lTranslateSkillDropKickDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillDropKickDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillHurricaneKickDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 20
        Case "DR"
            lReturn = 60
        Case "BA"
            lReturn = 80
        Case "MO"
            lReturn = 20
        Case "AS"
            lReturn = 150
        Case "GY"
            lReturn = 43
        Case "TH"
            lReturn = 180
        Case "WA"
            lReturn = 60
        Case "GL"
            lReturn = 80
        Case "RA"
            lReturn = 80
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA"
            lReturn = 69
        Case "WE"
            lReturn = 40
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 10
    End Select
    lTranslateSkillHurricaneKickDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillHurricaneKickDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillPowerKickDamage(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 20
        Case "DR"
            lReturn = 60
        Case "BA"
            lReturn = 180
        Case "MO"
            lReturn = 20
        Case "AS"
            lReturn = 115
        Case "GY"
            lReturn = 43
        Case "TH"
            lReturn = 90
        Case "WA"
            lReturn = 40
        Case "GL"
            lReturn = 75
        Case "RA"
            lReturn = 80
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 3 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 69
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 150
    End Select
    lTranslateSkillPowerKickDamage = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillPowerKickDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillDodge(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 1
        Case "DR"
            lReturn = 10
        Case "BA"
            lReturn = 2
        Case "MO"
            lReturn = 3
        Case "AS"
            lReturn = 8
        Case "GY"
            lReturn = 4
        Case "TH"
            lReturn = 4
        Case "WA"
            lReturn = 3
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 2
        Case "KN"
            lReturn = 2 'same as paladin but can heal self
        Case "PA"
            lReturn = 2 'same as knight but can heal others
        Case "VA"
            lReturn = 2
        Case "WE"
            lReturn = 6
        Case "PL", "VE"
            lReturn = 1
        Case "CY"
            lReturn = 1
    End Select
    lTranslateSkillDodge = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillDropKickDamage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateStatusGain(zStat As String, zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 1
    Select Case zStat
        Case "HP"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 2
                Case "CL"
                    lReturn = 3
                Case "DR"
                    lReturn = 3
                Case "BA"
                    lReturn = 4
                Case "MO"
                    lReturn = 6
                Case "AS"
                    lReturn = 4
                Case "GY"
                    lReturn = 4
                Case "TH"
                    lReturn = 4
                Case "WA"
                    lReturn = 7
                Case "GL"
                    lReturn = 7
                Case "RA"
                    lReturn = 3
                Case "KN"
                    lReturn = 4 'same as paladin but can heal self
                Case "PA"
                    lReturn = 2 'same as knight but can heal others
                Case "VA", "WE"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 7
                Case "CY"
                    lReturn = 7
            End Select
        Case "MANA"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 8
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 3
                Case "BA"
                    lReturn = 4
                Case "MO"
                    lReturn = 2
                Case "AS"
                    lReturn = 1
                Case "GY"
                    lReturn = 3
                Case "TH"
                    lReturn = 1
                Case "WA"
                    lReturn = 1
                Case "GL"
                    lReturn = 1
                Case "RA"
                    lReturn = 3
                Case "KN"
                    lReturn = 2 'same as paladin but can heal self
                Case "PA"
                    lReturn = 2 'same as knight but can heal others
                Case "VA", "WE"
                    lReturn = 4
                Case "PL", "VE"
                    lReturn = 3
                Case "CY"
                    lReturn = 3
            End Select
        Case "ESSE"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 6
                Case "CL"
                    lReturn = 10
                Case "DR"
                    lReturn = 5
                Case "BA"
                    lReturn = 3
                Case "MO"
                    lReturn = 2
                Case "AS"
                    lReturn = 1
                Case "GY"
                    lReturn = 3
                Case "TH"
                    lReturn = 1
                Case "WA"
                    lReturn = 1
                Case "GL"
                    lReturn = 1
                Case "RA"
                    lReturn = 4
                Case "KN"
                    lReturn = 3 'same as paladin but can heal self
                Case "PA"
                    lReturn = 5 'same as knight but can heal others
                Case "VA", "WE"
                    lReturn = 1
                Case "PL", "VE"
                    lReturn = 4
                Case "CY"
                    lReturn = 4
            End Select
        Case "SOUL"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 1
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 2
                Case "BA"
                    lReturn = 4
                Case "MO"
                    lReturn = 5
                Case "AS"
                    lReturn = 6
                Case "GY"
                    lReturn = 4
                Case "TH"
                    lReturn = 4
                Case "WA"
                    lReturn = 8
                Case "GL"
                    lReturn = 10
                Case "RA"
                    lReturn = 3
                Case "KN"
                    lReturn = 6 'same as paladin but can heal self
                Case "PA"
                    lReturn = 4 'same as knight but can heal others
                Case "VA", "WE"
                    lReturn = 5
                Case "PL", "VE"
                    lReturn = 4
                Case "CY"
                    lReturn = 4
            End Select
        Case "MOVE"
            Select Case UCase(Mid(zClassType, 1, 2))
                Case "MA"
                    lReturn = 1
                Case "CL"
                    lReturn = 2
                Case "DR"
                    lReturn = 8
                Case "BA"
                    lReturn = 3
                Case "MO"
                    lReturn = 3
                Case "AS"
                    lReturn = 7
                Case "GY"
                    lReturn = 4
                Case "TH"
                    lReturn = 7
                Case "WA"
                    lReturn = 6
                Case "GL"
                    lReturn = 2
                Case "RA"
                    lReturn = 8
                Case "KN"
                    lReturn = 1 'same as paladin but can heal self
                Case "PA"
                    lReturn = 3 'same as knight but can heal others
                Case "VA", "WE"
                    lReturn = 5
                Case "PL", "VE"
                    lReturn = 1
                Case "CY"
                    lReturn = 1
            End Select
            
    End Select
    lTranslateStatusGain = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateStatusGain," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateSkillSpellForName(lValue As Long, iType As Integer) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = ""
    Select Case iType
        Case 1 'Spells
            Select Case lValue
                Case 1
                    zReturn = "Light Radius level 1"
                Case 2
                    zReturn = "Light Radius level 2"
                Case 3
                    zReturn = "Light Radius level 3"
                Case 4
                    zReturn = "Light Radius level 4"
                Case 5
                    zReturn = "Light Radius level 5"
                Case 20
                    zReturn = "Invisibility"
                Case 30
                    zReturn = "Fireshield"
                Case 40
                    zReturn = "Iceshield"
                Case 50
                    zReturn = "Sanctuary"
                Case 60
                    zReturn = "Negate Summon"
                Case 70
                    zReturn = "Aquabreath"
                Case 80
                    zReturn = "Barkskin"
                Case 81
                    zReturn = "Stoneskin"
                Case 82
                    zReturn = "Dragonskin"
                Case 83
                    zReturn = "Demonskin"
                Case 99
                    zReturn = "Shadow Cloak"
            End Select
        Case 2 'Skills
            Select Case lValue
                Case 10
                    zReturn = "Berserk"
                Case 20
                    zReturn = "Double Punch"
                Case 30
                    zReturn = "Drop Kick"
                Case 40
                    zReturn = "Meditate"
                Case 50
                    zReturn = "Head Butt"
                Case 60
                    zReturn = "Elbow"
                Case 70
                    zReturn = "Knee"
                Case 80
                    zReturn = "Claw Hand"
                Case 90
                    zReturn = "Knife Hand"
                Case 100
                    zReturn = "Dragon Uppercut"
                Case 110
                    zReturn = "Power Kick"
                Case 120
                    zReturn = "Hurricane Kick"
            End Select
    End Select
    zTranslateSkillSpellForName = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateSkillSpellForName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassLearnPointPercentChance(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 10
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 30
        Case "CL"
            lReturn = 35
        Case "DR"
            lReturn = 55
        Case "BA"
            lReturn = 65
        Case "MO"
            lReturn = 90
        Case "AS"
            lReturn = 75
        Case "GY"
            lReturn = 30
        Case "TH"
            lReturn = 15
        Case "WA"
            lReturn = 99
        Case "GL"
            lReturn = 95
        Case "RA"
            lReturn = 80
        Case "KN"
            lReturn = 90
        Case "PA"
            lReturn = 38 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 40
        Case "PL", "VE"
            lReturn = 80
        Case "CY"
            lReturn = 20
    End Select
    
    lTranslateClassLearnPointPercentChance = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassLearnPointPercentChance," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateLearnPointsSkill(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 1
        Case "CL"
            lReturn = 19
        Case "DR"
            lReturn = 5
        Case "BA"
            lReturn = 29
        Case "MO"
            lReturn = 33
        Case "AS"
            lReturn = 34
        Case "GY"
            lReturn = 25
        Case "TH"
            lReturn = 22
        Case "WA"
            lReturn = 37
        Case "GL"
            lReturn = 40
        Case "RA"
            lReturn = 31
        Case "KN"
            lReturn = 40
        Case "PA"
            lReturn = 38 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 3
        Case "PL", "VE"
            lReturn = 2
        Case "CY"
            lReturn = 4
    End Select
    
    lTranslateLearnPointsSkill = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateLearnPointsSkill," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateLearnPointsGains(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 30
        Case "CL"
            lReturn = 19
        Case "DR"
            lReturn = 18
        Case "BA"
            lReturn = 17
        Case "MO"
            lReturn = 12
        Case "AS"
            lReturn = 11
        Case "GY"
            lReturn = 14
        Case "TH"
            lReturn = 9
        Case "WA"
            lReturn = 21
        Case "GL"
            lReturn = 22
        Case "RA"
            lReturn = 23
        Case "KN"
            lReturn = 24
        Case "PA"
            lReturn = 25 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 17
        Case "PL", "VE"
            lReturn = 18
        Case "CY"
            lReturn = 19
    End Select
    
    lTranslateLearnPointsGains = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateLearnPointsGains," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateClassLearnGainBonus(zClassType As String) As Long
On Error GoTo Err_Check
    Dim lReturn As Long
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 50
        Case "CL"
            lReturn = 40
        Case "DR"
            lReturn = 30
        Case "BA"
            lReturn = 25
        Case "MO"
            lReturn = 10
        Case "AS"
            lReturn = 1
        Case "GY"
            lReturn = 22
        Case "TH"
            lReturn = 1
        Case "WA"
            lReturn = 1
        Case "GL"
            lReturn = 2
        Case "RA"
            lReturn = 20
        Case "KN"
            lReturn = 15
        Case "PA"
            lReturn = 22
        Case "WE"
            lReturn = 5
        Case "VA"
            lReturn = 15
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 10
    End Select
    
    If (lReturn > 40) Then lReturn = 40 'We cap how many learn points can be gained
    
    lTranslateClassLearnGainBonus = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateClassLearnGainBonus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateRaceCraftBonus(zRace As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Select Case zRace
        Case "GNO"
            lReturn = 70
        Case "HAL"
            lReturn = 65
        Case "OGE"
            lReturn = 65
        Case "ELF"
            lReturn = 60
        Case "ORC"
            lReturn = 60
        Case "FEL"
            lReturn = 55
        Case "HUM", "MIN", "DWA"
            lReturn = 50
        Case "TRO"
            lReturn = 45
        Case "DRA", "PIX"
            lReturn = 40
        Case "UND"
            lReturn = 35
        Case Else
            lReturn = 15
    End Select
    lTranslateRaceCraftBonus = lReturn
End Function
Public Function lTranslateLearnPointBonus(zClassType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 39
        Case "CL"
            lReturn = 35
        Case "DR"
            lReturn = 30
        Case "BA"
            lReturn = 25
        Case "MO"
            lReturn = 13
        Case "AS"
            lReturn = 7
        Case "GY"
            lReturn = 23
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 4
        Case "GL"
            lReturn = 8
        Case "RA"
            lReturn = 18
        Case "KN"
            lReturn = 18
        Case "PA"
            lReturn = 23
        Case "WE"
            lReturn = 24
        Case "VA"
            lReturn = 27
        Case "PL", "VE"
            lReturn = 30
        Case "CY"
            lReturn = 33
    End Select
    lTranslateLearnPointBonus = 58 + lReturn
End Function
Public Function lTranslateLearnPointsSpell(zClassType As String) As Long
On Error GoTo Err_Check
'none of these can be over 40
    Dim lReturn As Long
    lReturn = 4
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 39
        Case "CL"
            lReturn = 35
        Case "DR"
            lReturn = 30
        Case "BA"
            lReturn = 25
        Case "MO"
            lReturn = 13
        Case "AS"
            lReturn = 7
        Case "GY"
            lReturn = 23
        Case "TH"
            lReturn = 5
        Case "WA"
            lReturn = 4
        Case "GL"
            lReturn = 8
        Case "RA"
            lReturn = 18
        Case "KN"
            lReturn = 18
        Case "PA"
            lReturn = 23
        Case "WE"
            lReturn = 38
        Case "VA"
            lReturn = 27
        Case "PL", "VE"
            lReturn = 29
        Case "CY"
            lReturn = 33
    End Select
    
    If (lReturn > 40) Then lReturn = 40 'We cap how many learn points can be gained
    
    lTranslateLearnPointsSpell = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateLearnPointsSpell," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateDualWeildValueByClass(zClassType As String) As Long
On Error GoTo Err_Check
'The higher the number the longer it takes to get dual weild - (player str + player con).
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 65
        Case "CL"
            lReturn = 58
        Case "DR"
            lReturn = 57
        Case "BA"
            lReturn = 54
        Case "MO"
            lReturn = 58
        Case "AS"
            lReturn = 20
        Case "GY"
            lReturn = 33
        Case "TH"
            lReturn = 21
        Case "WA"
            lReturn = 5
        Case "GL"
            lReturn = 7
        Case "RA"
            lReturn = 25
        Case "KN"
            lReturn = 20 'same as paladin but can heal self
        Case "PA"
            lReturn = 30 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 90
        Case "PL", "VE"
            lReturn = 90
        Case "CY"
            lReturn = 30
    End Select
    lTranslateDualWeildValueByClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateDualWeildValueByClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateBlindFightValueByClass(zClassType As String) As Long
On Error GoTo Err_Check
'The higher the number the longer it takes to get dual weild - (player str + player con).
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 69
        Case "CL"
            lReturn = 38
        Case "DR"
            lReturn = 33
        Case "BA"
            lReturn = 4
        Case "MO"
            lReturn = 8
        Case "AS"
            lReturn = 30
        Case "GY"
            lReturn = 33
        Case "TH"
            lReturn = 71
        Case "WA"
            lReturn = 22
        Case "GL"
            lReturn = 7
        Case "RA"
            lReturn = 20
        Case "KN"
            lReturn = 10 'same as paladin but can heal self
        Case "PA"
            lReturn = 30 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 30
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 30
    End Select
    lTranslateBlindFightValueByClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateBlindFightValueByClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillScanMoveCost(zClassType As String) As Long
On Error GoTo Err_Check
'The higher the number the longer it takes to get dual weild - (player str + player con).
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 900
        Case "CL"
            lReturn = 800
        Case "DR"
            lReturn = 200
        Case "BA"
            lReturn = 400
        Case "MO"
            lReturn = 500
        Case "AS"
            lReturn = 300
        Case "GY"
            lReturn = 400
        Case "TH"
            lReturn = 200
        Case "WA"
            lReturn = 200
        Case "GL"
            lReturn = 300
        Case "RA"
            lReturn = 200
        Case "KN"
            lReturn = 600 'same as paladin but can heal self
        Case "PA"
            lReturn = 500 'same as knight but can heal others
        Case "VA"
            lReturn = 800
        Case "WE"
            lReturn = 200
        Case "PL", "VE"
            lReturn = 300
        Case "CY"
            lReturn = 150
    End Select
    lTranslateSkillScanMoveCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillScanMoveCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateSkillScanSoulCost(zClassType As String) As Long
On Error GoTo Err_Check
'The higher the number the longer it takes to get dual weild - (player str + player con).
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 500
        Case "CL"
            lReturn = 400
        Case "DR"
            lReturn = 150
        Case "BA"
            lReturn = 200
        Case "MO"
            lReturn = 250
        Case "AS"
            lReturn = 200
        Case "GY"
            lReturn = 300
        Case "TH"
            lReturn = 400
        Case "WA"
            lReturn = 300
        Case "GL"
            lReturn = 300
        Case "RA"
            lReturn = 300
        Case "KN"
            lReturn = 200 'same as paladin but can heal self
        Case "PA"
            lReturn = 500 'same as knight but can heal others
        Case "VA"
            lReturn = 400
        Case "WE"
            lReturn = 250
        Case "PL", "VE"
            lReturn = 50
        Case "CY"
            lReturn = 400
    End Select
    lTranslateSkillScanSoulCost = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateSkillScanSoulCost," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateStunFightValueByClass(zClassType As String) As Long
On Error GoTo Err_Check
'The higher the number the longer it takes to get dual weild - (player str + player con).
    Dim lReturn As Long
    lReturn = 1
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "MA"
            lReturn = 72
        Case "CL"
            lReturn = 48
        Case "DR"
            lReturn = 43
        Case "BA"
            lReturn = 14
        Case "MO"
            lReturn = 18
        Case "AS"
            lReturn = 55
        Case "GY"
            lReturn = 43
        Case "TH"
            lReturn = 72
        Case "WA"
            lReturn = 23
        Case "GL"
            lReturn = 17
        Case "RA"
            lReturn = 30
        Case "KN"
            lReturn = 12 'same as paladin but can heal self
        Case "PA"
            lReturn = 40 'same as knight but can heal others
        Case "VA", "WE"
            lReturn = 40
        Case "PL", "VE"
            lReturn = 10
        Case "CY"
            lReturn = 40
    End Select
    lTranslateStunFightValueByClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateStunFightValueByClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateRace(zRaceType As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "?race?"
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "PIX"
            zReturn = "Pixie"
        Case "DWA"
            zReturn = "Dwarf"
        Case "HUM"
            zReturn = "Human"
        Case "OGR"
            zReturn = "Ogre"
        Case "ORC"
            zReturn = "Orc"
        Case "GNO"
            zReturn = "Gnome"
        Case "TRO"
            zReturn = "Troll"
        Case "ELF"
            zReturn = "Elf"
        Case "MIN"
            zReturn = "Minotaur"
        Case "DRA"
            zReturn = "Drac"
        Case "HAL"
            zReturn = "Halfling"
        Case "UND"
            zReturn = "Undead"
        Case "FEL" 'Felpur felineman
            zReturn = "Felpur"
    End Select
    zTranslateRace = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateRace," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateRaceSay(zRaceType As String) As String
On Error GoTo Err_Check
'See Also: zTranslatePoofAnimalTypes or zTranslateRaceSay
    Dim zReturn As String
    zReturn = "?race?"
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "PIX"
            Select Case lRandom(20)
                Case 1
                    zReturn = "squeek"
                Case Else
                    zReturn = "chime"
            End Select
        Case "DWA"
            zReturn = "grumble"
        Case "HUM"
            zReturn = "say"
        Case "OGR"
            zReturn = "hrumph"
        Case "ORC"
            zReturn = "boast"
        Case "GNO"
            zReturn = "speak"
        Case "TRO"
            zReturn = "grunt"
        Case "ELF"
            Select Case lRandom(20)
                Case 1
                    zReturn = "glint"
                Case Else
                    zReturn = "charm"
            End Select
        Case "MIN"
            zReturn = "gruff"
        Case "DRA"
            zReturn = "breath"
        Case "HAL"
            zReturn = "mutter"
        Case "UND"
            zReturn = "rot"
        Case "FEL"
            Select Case lRandom(20)
                Case 1
                    zReturn = "mew"
                Case Else
                    zReturn = "purr"
            End Select
    End Select
    zTranslateRaceSay = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateRaceSay," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subMessagesMovementResult(iResult As Integer, zPortID As String)
On Error Resume Next
    'case 0 means no message
    Select Case iResult
        Case 1 'Errors
            subSendMsg "&gAlas, you cannot go that way.", zPortID
        Case 2
            subSendMsg "&gThe door is locked.", zPortID
        Case 3
            subSendMsg "&gThe door is not open.", zPortID
        Case 10
            subSendMsg "&gYou need to fly there if you want to go there.", zPortID
        Case 11
            subSendMsg "&gYou need to be a higher level to fly there.", zPortID
        Case 19 'You cannot move into areas where your rank is too low to allow it
            subSendMsg "&wYour clan rank does not allow you into that room.", zPortID
            'subSendMsg "&AYou must be ranked " & zKeepLettersOnly(LCase(zTranslateMortalClanRanks(lNewClanMemberLevel))) & " or higher to move there.", zPortID
        Case 20 'Cant move into clan halls unless you are that clannie.
            subSendMsg "&RA magical barrier blocks your path.", zPortID
        Case 30 'Player too tall
            subSendMsg "&gYou need to be shorter to go in there.", zPortID
        Case 40 'Player needs a pass from a guard
            subSendMsg "&gYou need to carry the proper item to go in there.", zPortID
        Case 400 'Player needs to be morphed into a frog or something
            subSendMsg "&gYou must seek out an evil wizard!", zPortID
        Case 50 'Player is trapped in the area.
            subSendMsg "&gYou are trapped you cannot move!", zPortID
        Case 70
            subSendMsg "&GYou would have to stand before you move.", zPortID
        Case 80
            subSendMsg "&GYou are blind and cannot see a thing!", zPortID
        Case 666
            Select Case lRandom(5)
                Case 1
                    subSendMsg "&ROffline venting...(required)", zPortID
                Case 2
                    subSendMsg "&ROverloaded venting...(required)", zPortID
                Case 3
                    subSendMsg "&RForced venting...(required)", zPortID
                Case Else
                    subSendMsg "&RSystems venting...(required)", zPortID
            End Select
    End Select
End Sub
Public Function bCanClassWearWeaponType(zClass As String, zWeaponType As String) As Boolean
On Error GoTo Err_Check
    Dim bReturn As Boolean
    bReturn = True
       
    If (Len(zWeaponType) > 0) Then
        Select Case Mid(zClass, 1, 2)
            Case "MA"
                bReturn = (bAmong(zWeaponType, "SBLA", "FLEX", "SAXE", "JAVI", "SSTA", "LSTA", "MGUN"))
            Case "CL"
                bReturn = (bAmong(zWeaponType, "BLUD", "FLEX", "SAXE", "GAXE", "XBOW", "SLIN", "SSTA", "LSTA", "MGUN"))
            Case "DR"
                bReturn = (bAmong(zWeaponType, "BLUD", "FLEX", "SBLA", "BOW", "SAXE", "GAXE", "SSTA", "LSTA", "MGUN"))
            Case "BA"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "SLIN", "SAXE", "SSTA", "LSTA", "MGUN"))
            Case "MO"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "SLIN", "SSTA", "TALO"))
            Case "GY"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "FLEX", "SLIN", "JAVI", "SAXE", "SSTA", "LSTA", "NET", "MGUN"))
            Case "AS"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "LBLA", "SBLA", "FLEX", "TALO", "JAVI", "SAXE", "SSTA", "LSTA", "POLE", "MGUN"))
            Case "WE"
                bReturn = (bAmong(zWeaponType, "FLEX", "TALO", "SPEA", "POLE"))
            Case "VA"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "FLEX", "TALO", "SSTA", "LSTA"))
            Case "PL", "VE"
                bReturn = (bAmong(zWeaponType, "FLEX", "TALO", "GAXE", "POLE", "JAVI", "SPEA"))
            Case "CY"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "LBLA", "XBOW", "GAXE", "PHAS", "MGUN"))
            Case "GL"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "POLE", "SBLA", "FLEX", "TALO", "LBLA", "SLIN", "NET", "SAXE", "GAXE", "MGUN"))
            Case "WA"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "POLE", "SBLA", "FLEX", "TALO", "LBLA", "JAVI", "SPEA", "SAXE", "GAXE", "XBOW", "BOW", "LANC", "PHAS"))
            Case "RA"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "LBLA", "FLEX", "BOW", "XBOW", "SLIN", "JAVI", "SPEA", "SAXE", "GAXE", "MGUN"))
            Case "PA"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "LBLA", "XBOW", "JAVI", "SPEA", "SAXE", "GAXE"))
            Case "KN"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "POLE", "SBLA", "FLEX", "LBLA", "XBOW", "SPEA", "SAXE", "GAXE", "SSTA", "LSTA", "LANC", "PHAS"))
            Case "TH"
                bReturn = (bAmong(zWeaponType, "BLUD", "PUGI", "SBLA", "FLEX", "TALO", "SLIN", "JAVI", "SPEA", "SAXE", "SSTA"))
        End Select
    End If
    bCanClassWearWeaponType = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bCanClassWearWeaponType," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateObjectDurability(lDurabilityBroken As Long, lDurabilityMAX As Long) As String
On Error GoTo Err_Check
    Dim lRatio As Long
    Dim zReturn As String
    Dim lCheckDurabilityMax As Long
    
    lCheckDurabilityMax = lDurabilityMAX
    
    If (lCheckDurabilityMax < 1) Then lCheckDurabilityMax = 1
    
    lRatio = MyCLng((lDurabilityBroken * 100) / lCheckDurabilityMax)
    Select Case lRatio
        Case 0 To 15
            zReturn = "is in danger of being broken!"
        Case 16 To 30
            zReturn = "needs repairs!"
        Case 31 To 60
            zReturn = "is in rough condition!"
        Case 61 To 70
            zReturn = "is heavily scratched and battered."
        Case 71 To 80
            zReturn = "is lightly scratched and dented."
        Case 81 To 99
            zReturn = "has a few scratches but is fine for battle."
        Case Else
            zReturn = "is in fine condition"
    End Select
    zTranslateObjectDurability = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateObjectDurability," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateHeightDifference(lRatio As Long) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = ""
    Select Case lRatio
        Case 0 To 30
            zReturn = "You look strait up and realize you are very short in comparison."
        Case 31 To 60
            zReturn = "You look up and realize you are quite short in comparison."
        Case 61 To 89
            zReturn = "You look up and realize you are short in comparison."
        Case 90 To 99
            zReturn = "You are a bit shorter but nearly the same height."
        Case 100
            zReturn = "You are exactly the same height."
        Case 101 To 110
            zReturn = "You are taller but nearly the same height."
        Case Else
            zReturn = "You are a giant in comparison."
    End Select
    zTranslateHeightDifference = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateObjectDurability," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateHeightClass(zClass As String) As String
On Error GoTo Err_Check
    Dim lReturn As Long
    Dim lModifier As Long
    lReturn = 153 '153 is 5 feet tall - 91 is 3 feet tall - 30 is 1 feet tall
    Select Case UCase(zClass)
        Case "MA"
            lModifier = -10
        Case "CL"
            lModifier = 0
        Case "DR"
            lModifier = -5
        Case "BA"
            lModifier = 0
        Case "MO"
            lModifier = 20
        Case "AS"
            lModifier = 10
        Case "GL"
            lModifier = 40
        Case "RA"
            lModifier = 30
        Case "PA"
            lModifier = 45
        Case "KN"
            lModifier = 50
        Case "TH"
            lModifier = -20
        Case "GY"
            lModifier = -5
        Case "WA"
            lModifier = 55
        Case "VA", "WE"
            lModifier = 5
        Case "PL", "CY", "VE"
            lModifier = 85
        Case "CY"
            lModifier = 55
    End Select
    lReturn = lReturn + lModifier + lRandom(15)
    lTranslateHeightClass = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateHeightClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTranslateHeightRace(zRace As String) As String
On Error GoTo Err_Check
    Dim lReturn As Long
    Dim lModifier As Long
    'Elf: 5.5-6.2 Minotaur:6.5- 7.6 Dwarf: 3.6- 5.0 Humans: 5.10- 7.0
    'Troll: 6.0- 8ft pixie:2ft- 4ft Undead can be any height,
    'Halflings are half size of man, gnome 1-3ft, Draconians 4-6ft
    'depending on ocupation. Mage draconians 5-6ft, grunts 3-5ft
    
    lReturn = 153 'each 30 is 1 feet tall
    Select Case UCase(Mid(zRace, 1, 3)) 'each 30 is 1 feet tall
        Case "PIX"
            lReturn = 6 + lRandom(9)
        Case "DWA"
            lReturn = 125 + lRandom(15)
        Case "GNO"
            lReturn = 120 + lRandom(20)
        Case "HAL"
            lReturn = 100 + lRandom(30)
        Case "DRA"
            lReturn = 140 + lRandom(80)
        Case "HUM"
            lReturn = 165 + lRandom(20)
        Case "ELF"
            lReturn = 177 + lRandom(25)
        Case "UND"
            lReturn = 110 + lRandom(100)
        Case "FEL" 'Felpur
            lReturn = 120 + lRandom(80)
        Case "ORC"
            lReturn = 190 + lRandom(20)
        Case "OGR"
            lReturn = 225 + lRandom(30)
        Case "TRO"
            lReturn = 225 + lRandom(30)
        Case "MIN"
            lReturn = 225 + lRandom(30)
    End Select
    lReturn = lReturn + lModifier
    lTranslateHeightRace = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lTranslateHeightRace," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lSubNotZero(lMedian As Long, lMoreThanNothing As Long) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 0
    If (lMoreThanNothing > 0) Then
        lReturn = lMedian
    End If
    lSubNotZero = lReturn
End Function
Public Function zDISABLEDOLDTranslateMultiClassStats(lStr As Long, lInt As Long, lWis As Long, lDex As Long, lCon As Long, lCHA As Long, lLUC As Long) As String
On Error Resume Next
'See also: subPlayerGains
    Dim lMedian As Long
    Dim lMedianAvg As Long '-1 = evil, 0=neutral, +1 good classes
'   -1 = evil classing       gypsy mage thief warrior
'   +1 = positive classing   cleric paladin ranger druid
'    0 = neutral             assassin bard gladiator knight monk
    Dim lHP As Long
    Dim lMana As Long
    Dim lEssence As Long
    Dim lSoul As Long
    Dim lMove As Long
    Dim zReturn As String
    Dim lMACase As Long
    Dim lMedianDiv As Long
    
    If (lStr <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lInt <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lWis <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lDex <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lCon <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lCHA <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lLUC <> 0) Then lMedianDiv = lMedianDiv + 1
    If (lMedianDiv < 0) Then lMedianDiv = 1
    lMedian = MyCLng((lStr + lInt + lWis + lDex + lCon + lCHA + lLUC) / lMedianDiv)
    
    lMedianAvg = lSubNotZero(lStr - (lMedian * 2), lStr) + lSubNotZero(lInt - lMedian, lInt) + lSubNotZero(lWis - lMedian, lWis) + lSubNotZero(lDex - (lMedian * 2), lDex) + lSubNotZero(lCon - (lMedian * 2), lCon) + lSubNotZero(lCHA - lMedian, lCHA) + lSubNotZero(lLUC - lMedian, lLUC)
    lMACase = 2
    If (lMedianAvg < -1) Then lMACase = 1
    If (lMedianAvg > 1) Then lMACase = 3
    
    lHP = lStr + lCon
    lMana = lInt + lCHA
    lEssence = lWis + lCHA
    lSoul = lCon + lLUC
    lMove = lDex + lCon
    
    Select Case (lMana + lEssence > lHP + lSoul)
        Case True
            zReturn = "Gypsy"
            If (lMana > lHP Or lEssence > lSoul) Then
                If (lMana > lEssence) Then
                    zReturn = "Mage"
                Else
                    If (lEssence > lMove) Then
                        zReturn = "Cleric"
                    Else
                        zReturn = "Druid"
                    End If
                End If
            Else
                zReturn = "Bard"
            End If
            
            If (lMove = lSoul) Then
                zReturn = "Ranger"
            End If
        Case Else
            Select Case lMACase
                Case 1 '-1
                    zReturn = "Warrior"
                    If (lHP + lSoul > lEssence + lMana) Then
                        If (lMana > lEssence) Then
                            zReturn = "Gypsy"
                        End If
                        If (lMove = lSoul) Then
                            zReturn = "Thief"
                        End If
                    Else
                        zReturn = "Assassin"
                    End If
                Case 2 'neutral
                    zReturn = "Gladiator"
                    If (lHP + lSoul > lEssence + lMana) Then
                        If (lMana > lEssence) Then
                            zReturn = "Druid"
                        Else
                            zReturn = "Cleric"
                        End If
                        If (lMove = lSoul) Then
                            zReturn = "Ranger"
                        End If
                    Else
                        zReturn = "Bard"
                    End If
                Case 3 '+1
                    zReturn = "Cleric"
                    If (lHP + lSoul > lEssence + lMana) Then
                        If (lMana > lEssence) Then
                            zReturn = "Mage"
                        Else
                            zReturn = "Cleric"
                        End If
                        If (lMove = lSoul) Then
                            zReturn = "Paladin"
                        End If
                    Else
                        zReturn = "Bard"
                        If (lSoul > lHP) Then
                            zReturn = "Monk"
                        End If
                        If (lSoul > lMove) Then
                            zReturn = "Knight"
                        End If
                    End If
            End Select
    End Select
    
    'Assassin Bard Cleric Druid Gladiator Gypsy Knight Mage Monk Paladin Ranger Thief Warrior
    zDISABLEDOLDTranslateMultiClassStats = zReturn
End Function
Public Function zTranslateClass(zClassType As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "?class?"
    Select Case UCase(Mid(zClassType, 1, 2))
        Case "IO", "WI", "WO"
            zReturn = "Witchlock" 'witches/warlocks
        Case "MA"
            zReturn = "Mage"
        Case "CL"
            zReturn = "Cleric"
        Case "DR"
            zReturn = "Druid"
        Case "BA"
            zReturn = "Bard"
        Case "MO"
            zReturn = "Monk"
        Case "AS"
            zReturn = "Assassin"
        Case "GY"
            zReturn = "Gypsy"
        Case "TH"
            zReturn = "Thief"
        Case "WA"
            zReturn = "Warrior"
        Case "GL"
            zReturn = "Gladiator"
        Case "RA"
            zReturn = "Ranger"
        Case "KN"
            zReturn = "Knight" 'same as paladin but can heal self
        Case "PA"
            zReturn = "Paladin" 'same as knight but can heal others
        Case "PL", "VE"
            zReturn = "Vegetation" 'morph
        Case "CY"
            zReturn = "Cyborg" 'morph
        Case "VA"
            zReturn = "Vampire" 'morph
        Case "WE"
            zReturn = "Werewolf" 'morph
    End Select
    zTranslateClass = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zDISABLEDTranslateMultiClassStats(lStr As Long, lInt As Long, lWis As Long, lDex As Long, lCon As Long, lCHA As Long, lLUC As Long) As String
On Error Resume Next
'See also: subPlayerGains
'          lDuplicateObject
    Dim zReturn As String
    Dim lRatio(1 To 7) As Long
    Dim lHighestValue As Long
    Dim lMaxCell As Long
    Dim lTotalStats As Long
    Dim lCount As Long
    
    'CALCULATE THE RATIO
    'we find the largest number
    zReturn = ""
    lTotalStats = (lStr + lInt + lWis + lDex + lCon + lCHA + lLUC)
    If (lTotalStats > cstlClassGlowing) Then 'Assassin Bard Cleric Druid Gladiator Gypsy Knight Mage Monk Paladin Ranger Thief Warrior
        lHighestValue = 0
        lMaxCell = 0
        If (lHighestValue < lStr) Then
            lHighestValue = lStr
            lMaxCell = 1
        End If
        If (lHighestValue < lInt) Then
            lHighestValue = lInt
            lMaxCell = 2
        End If
        If (lHighestValue < lWis) Then
            lHighestValue = lWis
            lMaxCell = 3
        End If
        If (lHighestValue < lDex) Then
            lHighestValue = lDex
            lMaxCell = 4
        End If
        If (lHighestValue < lCon) Then
            lHighestValue = lCon
            lMaxCell = 5
        End If
        If (lHighestValue < lCHA) Then
            lHighestValue = lCHA
            lMaxCell = 6
        End If
        If (lHighestValue < lLUC) Then
            lHighestValue = lLUC
            lMaxCell = 7
        End If
        'We get the nominal ratio
        For lCount = 1 To 7
            lRatio(lCount) = 0
        Next lCount
        If (lStr > 0) Then lRatio(1) = (lHighestValue * 100) / lStr
        If (lInt > 0) Then lRatio(2) = (lHighestValue * 100) / lInt
        If (lWis > 0) Then lRatio(3) = (lHighestValue * 100) / lWis
        If (lDex > 0) Then lRatio(4) = (lHighestValue * 100) / lDex
        If (lCon > 0) Then lRatio(5) = (lHighestValue * 100) / lCon
        If (lCHA > 0) Then lRatio(6) = (lHighestValue * 100) / lCHA
        If (lLUC > 0) Then lRatio(7) = (lHighestValue * 100) / lLUC
        
        'Sort cells and ratio
        Select Case (lMaxCell)
            Case 1 'str WA GL MO
                zReturn = "WA"
                If (lRatio(5) > 50) Then zReturn = "GL"
                If (lRatio(5) > 75) Then zReturn = "MO"
            Case 2 'int MA CL DR
                zReturn = "MA"
                If (lRatio(3) > 75) Then zReturn = "CL"
                If ((lRatio(3) > 50) And (lRatio(2) > 30 Or lRatio(3) > 20)) Then zReturn = "DR"
            Case 3 'wis CL DR MA
                zReturn = "CL"
                If ((lRatio(3) > 50) And (lRatio(2) > 30 Or lRatio(3) > 20)) Then zReturn = "DR"
                If ((lRatio(3) > 50) And (lRatio(2) > 20 Or lRatio(3) > 30)) Then zReturn = "MA"
            Case 4 'dex TH AS MO
                zReturn = "TH"
                If ((lRatio(1) > 30) And (lRatio(2) > 10 Or lRatio(3) > 10)) Then zReturn = "AS"
                If ((lRatio(1) > 50 Or lRatio(5) > 50) And (lRatio(3) > 10 Or lRatio(2) > 20)) Then zReturn = "MO"
            Case 5 'con PA RA KN
                zReturn = "PA"
                If ((lRatio(1) > 30) And (lRatio(2) > 10 Or lRatio(3) > 10)) Then zReturn = "RA"
                If ((lRatio(1) > 50 Or lRatio(5) > 50) And (lRatio(6) > 10 Or lRatio(7) > 20)) Then zReturn = "KN"
            Case 6 'cha AS GY BA
                zReturn = "AS"
                If ((lRatio(1) > 30) And (lRatio(2) > 10 Or lRatio(3) > 10)) Then zReturn = "GY"
                If ((lRatio(1) > 50 Or lRatio(5) > 50) And (lRatio(6) > 10 Or lRatio(7) > 20)) Then zReturn = "BA"
            Case 7 'luc BA TH AS
                zReturn = "BA"
                If ((lRatio(1) > 30) And (lRatio(2) > 10 Or lRatio(3) > 10)) Then zReturn = "TH"
                If ((lRatio(1) > 50 Or lRatio(5) > 50) And (lRatio(6) > 10 Or lRatio(7) > 20)) Then zReturn = "RA"
        End Select
        
        Select Case zReturn 'in order of low to high physical strength - classed into magical order
            Case "MA"
                zReturn = "Mage"
            Case "CL"
                zReturn = "Cleric"
            Case "DR"
                zReturn = "Druid"
            Case "GY"
                zReturn = "Gypsy"
            Case "BA"
                zReturn = "Bard"
            Case "MO"
                zReturn = "Monk"
            Case "AS"
                zReturn = "Assassin"
            Case "RA"
                zReturn = "Ranger"
            Case "KN"
                zReturn = "Knight"
            Case "PA"
                zReturn = "Paladin"
            Case "TH"
                zReturn = "Thief"
            Case "WA"
                zReturn = "Warrior"
            Case "GL"
                zReturn = "Gladiator"
        End Select
    End If
    zDISABLEDTranslateMultiClassStats = zReturn
End Function
Public Function zTranslateLanguage(lLanguageSet As Long) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = ""
    Select Case lLanguageSet
        Case 0, 1
            zReturn = "Common"
        Case 2
            zReturn = "Dracian"
        Case 3
            zReturn = "Dwarven"
        Case 4
            zReturn = "Elvish"
        Case 5
            zReturn = "Gnomian"
        Case 6
            zReturn = "Halflingian"
        Case 7
            zReturn = "Human"
        Case 8
            zReturn = "Minotaurian"
        Case 9
            zReturn = "Ogren"
        Case 10
            zReturn = "Orcish"
        Case 11
            zReturn = "Pixien"
        Case 12
            zReturn = "Trollian"
        Case 13
            zReturn = "Undeaden"
        Case 14
            zReturn = "Vampiren"
        Case 15
            zReturn = "Felpur"
    End Select
    zTranslateLanguage = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateLanguage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bReturnAppraiserCheckRaceClass(zPassRace As String, zPassClass As String) As Boolean
On Error GoTo Err_Check
    Dim bReturn As Boolean
    bReturn = False
    Select Case zPassRace
        Case "HUM", "HAL", "ELF", "MIN", "GNO", "TRO"
            bReturn = True
    End Select
    Select Case zPassClass
        Case "TH", "BA", "GY", "PA", "KN", "CL"
            bReturn = True
    End Select
    bReturnAppraiserCheckRaceClass = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bReturnAppraiserCheckRaceClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zPlayerTired(lCMove As Long, lOMove As Long) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = ""
    If (lOMove > 0) Then
        Select Case MyCLng((lCMove * 100) / lOMove)
            Case 0 To 1
                zReturn = "(demoralized)"
            Case 2 To 4
                zReturn = "(delirious)"
            Case 5 To 10
                zReturn = "(exhausted)"
            Case 11 To 20
                zReturn = "(fatigued)"
            Case 21 To 30
                zReturn = "(overworked)"
            Case 31 To 40
                zReturn = "(tired)"
            Case 41 To 50
                zReturn = "(weary)"
            Case 51 To 75
                zReturn = "(sweating)"
        End Select
    End If
    zPlayerTired = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zPlayerTired," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateRoomTitle(zGender As String, lPlayerLevel As Long) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    Select Case UCase(zGender)
        Case "M"
            Select Case lPlayerLevel
                Case 1 To 10
                    zReturn = "Mr."
                Case 11 To 20
                    zReturn = "Mighty"
                Case 21 To 25
                    zReturn = "Apprentice"
                Case 26 To 30
                    zReturn = "Vigilante"
                Case 31 To 35
                    zReturn = "Master"
                Case 36 To 40
                    zReturn = "Captain"
                Case 41 To 45
                    zReturn = "Sir"
                Case 46 To 50
                    zReturn = "Hero"
                Case 51 To 55
                    zReturn = "Sentinel"
                Case 56 To 60
                    zReturn = "Champion"
                Case 61 To 65
                    zReturn = "Highlander"
                Case 66 To 70
                    zReturn = "Baron"
                Case 71 To 75
                    zReturn = "Earl"
                Case 76 To 80
                    zReturn = "Marquis"
                Case 81 To 90
                    zReturn = "Duke"
                Case 91 To 100
                    zReturn = "Noble"
                Case 101 To 110
                    zReturn = "Prince"
                Case 111 To 120
                    zReturn = "Sire"
                Case 121 To 130
                    zReturn = "Sovereign"
                Case 131 To 150
                    zReturn = "Legend"
                Case 151 To 200
                    zReturn = "Eternal"
                Case Else
                    zReturn = "Ancient"
            End Select
        Case "F"
            Select Case lPlayerLevel
                Case 1 To 30
                    zReturn = "Ms."
                Case 31 To 35
                    zReturn = "Apprentice"
                Case 36 To 40
                    zReturn = "Maiden"
                Case 41 To 50
                    zReturn = "Madam"
                Case 51 To 90
                    zReturn = "Princess"
                Case 91 To 100
                    zReturn = "Lady"
                Case 101 To 125
                    zReturn = "Regent"
                Case 126 To 150
                    zReturn = "Monarch"
                Case 151 To 200
                    zReturn = "Eternal"
                Case Else
                    zReturn = "Ancient"
            End Select
    End Select
    zTranslateRoomTitle = zReturn
End Function
Public Function lTranslateInitiativeBonus(zPlayerClass As String, zPlayerRace As String, zType As String) As Long
On Error Resume Next
    Dim lResult As Long
    Dim lReturn As Long
    lResult = 0
    Select Case zType
        Case "B"
            lReturn = 0
            Select Case zPlayerClass
                Case "MA"
                    lReturn = 0
                Case "CL"
                    lReturn = 1
                Case "DR"
                    lReturn = 2
                Case "BA"
                    lReturn = 3
                Case "MO"
                    lReturn = 5
                Case "AS"
                    lReturn = 6
                Case "GY"
                    lReturn = 5
                Case "TH"
                    lReturn = 1
                Case "WA"
                    lReturn = 10
                Case "GL"
                    lReturn = 7
                Case "RA"
                    lReturn = 6
                Case "KN"
                    lReturn = 25
                Case "PA"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 25
                Case "CY"
                    lReturn = 7
                Case "VA"
                    lReturn = 8
                Case "WE"
                    lReturn = 15
            End Select
            lResult = lResult + lReturn
            
            lReturn = 0
            Select Case zPlayerRace
                Case "PIX"
                    lReturn = 25
                Case "DWA"
                    lReturn = 15
                Case "HUM"
                    lReturn = 10
                Case "OGR"
                    lReturn = 11
                Case "ORC"
                    lReturn = 7
                Case "GNO"
                    lReturn = 15
                Case "TRO"
                    lReturn = 15
                Case "ELF"
                    lReturn = 9
                Case "MIN"
                    lReturn = 7
                Case "DRA"
                    lReturn = 9
                Case "HAL"
                    lReturn = 15
                Case "UND"
                    lReturn = 3
                Case "FEL"
                    lReturn = 15
            End Select
            lResult = lResult + lReturn
        Case "C"
            lReturn = 0
            Select Case zPlayerClass
                Case "MA"
                    lReturn = 0
                Case "CL"
                    lReturn = 1
                Case "DR"
                    lReturn = 2
                Case "BA"
                    lReturn = 3
                Case "MO"
                    lReturn = 5
                Case "AS"
                    lReturn = 6
                Case "GY"
                    lReturn = 5
                Case "TH"
                    lReturn = 1
                Case "WA"
                    lReturn = 10
                Case "GL"
                    lReturn = 7
                Case "RA"
                    lReturn = 6
                Case "KN"
                    lReturn = 25
                Case "PA"
                    lReturn = 6
                Case "PL", "VE"
                    lReturn = 25
                Case "CY"
                    lReturn = 7
                Case "VA"
                    lReturn = 8
                Case "WE"
                    lReturn = 15
            End Select
            lResult = lResult + lReturn
        Case "R"
            lReturn = 0
            Select Case zPlayerRace
                Case "PIX"
                    lReturn = 25
                Case "DWA"
                    lReturn = 15
                Case "HUM"
                    lReturn = 10
                Case "OGR"
                    lReturn = 11
                Case "ORC"
                    lReturn = 7
                Case "GNO"
                    lReturn = 15
                Case "TRO"
                    lReturn = 15
                Case "ELF"
                    lReturn = 9
                Case "MIN"
                    lReturn = 7
                Case "DRA"
                    lReturn = 9
                Case "HAL"
                    lReturn = 15
                Case "UND"
                    lReturn = 3
                Case "FEL"
                    lReturn = 15
            End Select
            lResult = lResult + lReturn
    End Select
    
    lTranslateInitiativeBonus = lResult
End Function
Public Function lInvHoldRaceBonus(zRaceType As String) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 0
    Select Case UCase(Mid(zRaceType, 1, 3))
        Case "PIX"
            lReturn = 1
        Case "DWA"
            lReturn = 5
        Case "HUM"
            lReturn = 4
        Case "OGR"
            lReturn = 16
        Case "ORC"
            lReturn = 9
        Case "GNO"
            lReturn = 4
        Case "TRO"
            lReturn = 13
        Case "ELF"
            lReturn = 4
        Case "MIN"
            lReturn = 12
        Case "DRA"
            lReturn = 4
        Case "HAL"
            lReturn = 12
        Case "UND"
            lReturn = 1
        Case "FEL"
            lReturn = 8
    End Select

    lInvHoldRaceBonus = lReturn
End Function
'Beauty
Public Function ToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "BROWN" 'BROWN default
    Select Case zColour
        Case "01"
            zReturn = "BLACK"
        Case "02"
            zReturn = "BLONDE"
        Case "03"
            zReturn = "BLUE"
        Case "04"
            zReturn = "BRONZE"
        Case "05"
            zReturn = "GOLD"
        Case "06"
            zReturn = "EMERALD"
        Case "07"
            zReturn = "GREEN"
        Case "08"
            zReturn = "GRAY"
        Case "09"
            zReturn = "HAZEL"
        Case "10"
            zReturn = "PINK"
        Case "11"
            zReturn = "PURPLE"
        Case "12"
            zReturn = "RED"
        Case "13"
            zReturn = "SHADOW"
        Case "14"
            zReturn = "SILVER"
        Case "15"
            zReturn = "TAN"
        Case "16"
            zReturn = "WHITE"
        Case "17"
            zReturn = "YELLOW"
        Case "18"
            zReturn = "LIGHTBLUE"
        Case "19"
            zReturn = "LIGHTGREEN"
        Case "20"
            zReturn = "LIGHTPURPLE"
        Case "21"
            zReturn = "LIGHTRED"
        Case "22"
            zReturn = "LIGHTGRAY"
        Case "23"
            zReturn = "VIOLET"
    End Select
    ToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "ToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateHairToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "STRAIT" 'STRAIT default
    Select Case zColour
        Case "01"
            zReturn = "BALD"
        Case "02"
            zReturn = "CURLY"
        Case "03"
            zReturn = "PEACHFUZZ"
        Case "04"
            zReturn = "DOWNY"
        Case "05"
            zReturn = "CREWCUT"
        Case "06"
            zReturn = "PARTED-LEFT"
        Case "07"
            zReturn = "PARTED-RIGHT"
        Case "08"
            zReturn = "PARTEDCENTRE"
        Case "09"
            zReturn = "WAVEY"
        Case "10"
            zReturn = "CURLY"
    End Select
    zTranslateHairToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateHairToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateLengthToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "SHORT" 'SHORT default
    Select Case zColour
        Case "01"
            zReturn = "BALD"
        Case "02"
            zReturn = "SHOULDER-LENGTH"
        Case "03"
            zReturn = "MEDIUM"
        Case "04"
            zReturn = "MEDIUMLONG"
        Case "05"
            zReturn = "LONG"
        Case "06"
            zReturn = "EXTRA-LONG"
    End Select
    zTranslateLengthToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateLengthToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateWeightToVerbose(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "OPTIMAL" 'default
    Select Case zColour
        Case "01"
            zReturn = "THIN"
        Case "02"
            zReturn = "MEDIUM"
        Case "03"
            zReturn = "FAT"
        Case "04"
            zReturn = "HUGE"
        Case "05"
            zReturn = "OBEASE"
    End Select
    zTranslateWeightToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateWeightToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateShapeTypeToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "ROUND" 'ROUND default
    Select Case UCase(zColour)
        Case "01"
            zReturn = "GEM"
        Case "02"
            zReturn = "EGYPTIAN"
        Case "03"
            zReturn = "CATLIKE"
        Case "04"
            zReturn = "SLITS"
    End Select
    zTranslateShapeTypeToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateShapeTypeToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateEyeShapeToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "ROUND" 'ROUND default
    Select Case zColour
        Case "01"
            zReturn = "OBLONGUE"
        Case "02"
            zReturn = "TEARDROP"
        Case "03"
            zReturn = "ELFLIKE"
        Case "04"
            zReturn = "SLANT-EYED"
    End Select
    zTranslateEyeShapeToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateEyeShapeToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateEyeLashTypeToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "NORMAL" 'default
    Select Case zColour
        Case "01"
            zReturn = "THIN"
        Case "02"
            zReturn = "FUZZY"
        Case "03"
            zReturn = "INTELLIGENT"
        Case "04"
            zReturn = "THICK"
    End Select
    zTranslateEyeLashTypeToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateEyeLashTypeToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateEyeTypeToVerbose(zColour As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "NORMAL" 'ROUND default
    Select Case zColour
        Case "01"
            zReturn = "GEM"
        Case "02"
            zReturn = "EGYPTIAN"
        Case "03"
            zReturn = "CATLIKE"
        Case "04"
            zReturn = "SLITS"
    End Select
    zTranslateEyeTypeToVerbose = LCase(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateEyeTypeToVerbose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function ToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'BROWN default
    Select Case UCase(zColour)
        Case "BLACK"
            zReturn = "01"
        Case "BLONDE"
            zReturn = "02"
        Case "BLUE"
            zReturn = "03"
        Case "BRONZE"
            zReturn = "04"
        Case "GOLD"
            zReturn = "05"
        Case "EMERALD"
            zReturn = "06"
        Case "GREEN"
            zReturn = "07"
        Case "GRAY"
            zReturn = "08"
        Case "HAZEL"
            zReturn = "09"
        Case "PINK"
            zReturn = "10"
        Case "PURPLE"
            zReturn = "11"
        Case "RED"
            zReturn = "12"
        Case "SHADOW"
            zReturn = "13"
        Case "SILVER"
            zReturn = "14"
        Case "TAN"
            zReturn = "15"
        Case "WHITE"
            zReturn = "16"
        Case "YELLOW"
            zReturn = "17"
        Case "LIGHTBLUE"
            zReturn = "18"
        Case "LIGHTGREEN"
            zReturn = "19"
        Case "LIGHTPURPLE"
            zReturn = "20"
        Case "LIGHTRED"
            zReturn = "21"
        Case "LIGHTGRAY"
            zReturn = "22"
        Case "VIOLET"
            zReturn = "23"
        Case Else
            subSendMsg "&gInvalid colour selection.", zPortID
    End Select
    ToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "ToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateHairToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'STRAIT default
    Select Case UCase(zColour)
        Case "BALD"
            zReturn = "01"
        Case "CURLY", "CURLEY"
            zReturn = "02"
        Case "PEACH", "FUZZ", "PEACHFUZZ", "FUZZY"
            zReturn = "03"
        Case "DOWNY"
            zReturn = "04"
        Case "CREWCUT"
            zReturn = "05"
        Case "PARTEDLEFT"
            zReturn = "06"
        Case "PARTEDRIGHT"
            zReturn = "07"
        Case "PARTEDCENTRE"
            zReturn = "08"
        Case "WAVY", "WAVEY"
            zReturn = "09"
        Case "CURLY"
            zReturn = "10"
        Case Else
            subSendMsg "&gInvalid haircode selection.", zPortID
    End Select
    zTranslateHairToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateHairToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateLengthToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'SHORT default
    Select Case UCase(zColour)
        Case "BALD"
            zReturn = "01"
        Case "SHOULDERS", "SHOULDERLENGTH"
            zReturn = "02"
        Case "MEDIUM"
            zReturn = "03"
        Case "MEDIUMLONG"
            zReturn = "04"
        Case "LONG"
            zReturn = "05"
        Case "LONGLONG", "EXTRALONG"
            zReturn = "06"
        Case Else
            subSendMsg "&gInvalid length selection.", zPortID
    End Select
    zTranslateLengthToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateLengthToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateWeightToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'NORMAL default
    Select Case UCase(zColour)
        Case "THIN"
            zReturn = "01"
        Case "MEDIUM"
            zReturn = "02"
        Case "FAT"
            zReturn = "03"
        Case "HUGE"
            zReturn = "04"
        Case "OBEASE"
            zReturn = "05"
        Case Else
            subSendMsg "&gInvalid weight selection.", zPortID
    End Select
    zTranslateWeightToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateWeightToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateShapeTypeToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'ROUND default
    Select Case UCase(zColour)
        Case "GEM"
            zReturn = "01"
        Case "EGYPTIAN"
            zReturn = "02"
        Case "CAT", "CATLIKE"
            zReturn = "03"
        Case "SLITS"
            zReturn = "04"
        Case Else
            subSendMsg "&gInvalid shapetype selection.", zPortID
    End Select
    zTranslateShapeTypeToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateShapeTypeToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateEyeShapeToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'ROUND default
    Select Case UCase(zColour)
        Case "OBLONGUE", "OBLONG"
            zReturn = "01"
        Case "TEARDROP", "TEAR"
            zReturn = "02"
        Case "ELFLIKE", "ELF"
            zReturn = "03"
        Case "SLANTEYED", "SLANTEYE", "SLANT"
            zReturn = "04"
        Case Else
            subSendMsg "&gInvalid eyeshape selection.", zPortID
    End Select
    zTranslateEyeShapeToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateEyeShapeToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateEyeTypeToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'ROUND default
    Select Case zColour
        Case "GEM"
            zReturn = "01"
        Case "EGYPTIAN"
            zReturn = "02"
        Case "CAT", "CATLIKE"
            zReturn = "03"
        Case "SLITS"
            zReturn = "04"
        Case Else
            subSendMsg "&gInvalid eyetype selection.", zPortID
    End Select
    zTranslateEyeTypeToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateEyeTypeToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateEyeLashTypeToCode(zColour As String, zPortID As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = "00" 'NORMAL default
    Select Case UCase(zColour)
        Case "THIN"
            zReturn = "01"
        Case "FUZZY"
            zReturn = "02"
        Case "INTELLIGENT", "VULCAN", "ELFLIKE", "ELF"
            zReturn = "03"
        Case "THICK"
            zReturn = "04"
        Case Else
            subSendMsg "&gInvalid eyelashtype selection.", zPortID
    End Select
    zTranslateEyeLashTypeToCode = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateEyeLashTypeToCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subPlayerBeauty(zPortID As String, zWord2 As String, zWord3 As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim bOkay As Boolean
    '|EYECOLOUR     |EYETYPE        |EYESHAPE       |               'eye type is like gem or cat-slit, shape is like round or egyptian
    '|EYELASHCOLOUR |EYELASHTYPE    |EYELASHLENGTH  |
    '|EYEBROWCOLOUR |EYEBROWTYPE    |EYEBROWLENGTH  |
    '|HAIRCOLOUR    |HAIRTYPE       |HAIRLENGTH     |
    '|SKINCOLOUR    |SKINTYPE       |SKINWEIGHT     |               'skin weight is like thin fat
    '|FNAILCOLOUR   |FNAILTYPE      |FNAILLENGTH    |               'finger nails
    '|LIPSCOLOUR    |LIPSTYPE       |LIPSSHAPE      |
    '|EARCOLOUR     |EARTYPE        |EARTIPLENGTH   |
    
    bOkay = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerBeauty FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        rsPlayer.Edit
        Select Case UCase(zWord2)
            Case "EYECOLOUR", "EC" 'green eyes
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 3), 50, " ", "A")
            Case "EYETYPE", "ET" 'gem-eyeball, cats-eyeball
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 2) & zTranslateEyeTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 5), 50, " ", "A")
            Case "EYESHAPE", "ES" 'round slit
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 4) & zTranslateEyeShapeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 7), 50, " ", "A")
                
            Case "EYELASHCOLOUR", "ELC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 6) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 9), 50, " ", "A")
            Case "EYELASHTYPE", "ELT"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 8) & zTranslateEyeLashTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 11), 50, " ", "A")
            Case "EYELASHLENGTH", "ELL"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 10) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 13), 50, " ", "A")
                
            Case "EYEBROWCOLOUR", "EBC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 12) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 15), 50, " ", "A")
            Case "EYEBROWTYPE", "EBT"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 14) & zTranslateEyeLashTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 17), 50, " ", "A")
            Case "EYEBROWLENGTH", "EBL"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 16) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 19), 50, " ", "A")
                
            Case "HAIRCOLOUR", "HC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 18) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 21), 50, " ", "A")
            Case "HAIRTYPE", "HT"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 20) & zTranslateShapeTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 23), 50, " ", "A")
            Case "HAIRLENGTH", "HL"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 22) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 25), 50, " ", "A")
                
            Case "SKINCOLOUR", "SC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 24) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 27), 50, " ", "A")
            Case "SKINTYPE", "ST"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 26) & zTranslateShapeTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 29), 50, " ", "A")
            Case "SKINWEIGHT", "WEIGHT", "SW", "W"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 28) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 31), 50, " ", "A")
                
            Case "FNAILCOLOUR", "FNC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 30) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 33), 50, " ", "A")
            Case "FNAILTYPE", "FNT"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 32) & zTranslateShapeTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 35), 50, " ", "A")
            Case "FNAILLENGTH", "FNL"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 34) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 37), 50, " ", "A")
                
            Case "LIPSCOLOUR", "LC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 36) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 39), 50, " ", "A")
            Case "LIPSTYPE", "LT"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 38) & zTranslateShapeTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 41), 50, " ", "A")
            Case "LIPSSHAPE", "LS"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 40) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 43), 50, " ", "A")
                
            Case "EARCOLOUR", "EARC"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 42) & ToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 45), 50, " ", "A")
            Case "EARTYPE", "EART"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 44) & zTranslateShapeTypeToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 47), 50, " ", "A")
            Case "EARTIPLENGTH", "ETL", "EART"
                bOkay = True
                rsPlayer!PlayerBeauty = strForceSize(Mid(MyCStr(rsPlayer!PlayerBeauty), 1, 46) & zTranslateLengthToCode(zWord3, zPortID) & Mid(MyCStr(rsPlayer!PlayerBeauty), 49), 50, " ", "A")
                
            Case Else
                subSendMsg "&GBEAUTIFING YOUR CHARACTER" & vbCrLf & "&g|EYECOLOUR     |EYETYPE        |EYESHAPE       |", zPortID
                subSendMsg "|EYELASHCOLOUR |EYELASHTYPE    |EYELASHLENGTH  |", zPortID
                subSendMsg "|EYEBROWCOLOUR |EYEBROWTYPE    |EYEBROWLENGTH  |", zPortID
                subSendMsg "|HAIRCOLOUR    |HAIRTYPE       |HAIRLENGTH     |", zPortID
                subSendMsg "|SKINCOLOUR    |SKINTYPE       |SKINWEIGHT     |", zPortID
                subSendMsg "|FNAILCOLOUR   |FNAILTYPE      |FNAILLENGTH    |", zPortID
                subSendMsg "|LIPSCOLOUR    |LIPSTYPE       |LIPSSHAPE      |", zPortID
                subSendMsg "|EARCOLOUR     |EARTYPE        |EARTIPLENGTH   |", zPortID
        End Select
        rsPlayer.Update
    End If
    Set rsPlayer = Nothing
    If (bOkay) Then subSendMsg "&GPlayer was modified with beauty.", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerBeauty," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zTranslatePlayerBeauty(zPlayerBeauty As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    '|EYECOLOUR     |EYETYPE        |EYESHAPE       |               'eye type is like gem or cat-slit, shape is like round or egyptian
    '|EYELASHCOLOUR |EYELASHTYPE    |EYELASHLENGTH  |               'eye type is like gem or cat-slit
    '|EYEBROWCOLOUR |EYEBROWTYPE    |EYEBROWLENGTH  |
    '|HAIRCOLOUR    |HAIRTYPE       |HAIRLENGTH     |
    '|SKINCOLOUR    |SKINTYPE       |SKINWEIGHT     |               'skin weight is like thin fat
    '|FNAILCOLOUR   |FNAILTYPE      |FNAILLENGTH    |               'finger nails
    '|LIPSCOLOUR    |LIPSTYPE       |LIPSSHAPE      |
    '|EARCOLOUR     |EARTYPE        |EARTIPLENGTH   |
    
    zReturn = ""
    zReturn = "eyes, " & ToVerbose(Mid(zPlayerBeauty, 1, 2)) & " "
    zReturn = zReturn & zTranslateEyeTypeToVerbose(Mid(zPlayerBeauty, 5, 2)) & " "
    zReturn = zReturn & zTranslateEyeShapeToVerbose(Mid(zPlayerBeauty, 3, 2)) & vbCrLf
    
    zReturn = zReturn & "eyelashes, " & ToVerbose(Mid(zPlayerBeauty, 7, 2)) & " "
    zReturn = zReturn & zTranslateEyeLashTypeToVerbose(Mid(zPlayerBeauty, 9, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 11, 2)) & vbCrLf
    
    zReturn = zReturn & "eyebrows, " & ToVerbose(Mid(zPlayerBeauty, 13, 2)) & " "
    zReturn = zReturn & zTranslateEyeLashTypeToVerbose(Mid(zPlayerBeauty, 15, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 17, 2)) & vbCrLf
    
    zReturn = zReturn & "hair, " & ToVerbose(Mid(zPlayerBeauty, 19, 2)) & " "
    zReturn = zReturn & zTranslateShapeTypeToVerbose(Mid(zPlayerBeauty, 21, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 23, 2)) & vbCrLf
    
    zReturn = zReturn & "skin, " & ToVerbose(Mid(zPlayerBeauty, 25, 2)) & " "
    zReturn = zReturn & zTranslateShapeTypeToVerbose(Mid(zPlayerBeauty, 27, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 29, 2)) & vbCrLf
    
    zReturn = zReturn & "finger nails, " & ToVerbose(Mid(zPlayerBeauty, 31, 2)) & " "
    zReturn = zReturn & zTranslateShapeTypeToVerbose(Mid(zPlayerBeauty, 33, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 35, 2)) & vbCrLf
    
    zReturn = zReturn & "lips, " & ToVerbose(Mid(zPlayerBeauty, 37, 2)) & " "
    zReturn = zReturn & zTranslateShapeTypeToVerbose(Mid(zPlayerBeauty, 39, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 41, 2)) & vbCrLf
    
    zReturn = zReturn & "ears, " & ToVerbose(Mid(zPlayerBeauty, 43, 2)) & " "
    zReturn = zReturn & zTranslateShapeTypeToVerbose(Mid(zPlayerBeauty, 45, 2)) & " "
    zReturn = zReturn & zTranslateLengthToVerbose(Mid(zPlayerBeauty, 47, 2)) & vbCrLf
    
    zTranslatePlayerBeauty = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zPlayerBeauty," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zHallucinate(zLine As String) As String
    Dim lLen As Long
    Dim zLine1 As String
    Dim zLine2 As String
    Dim zLine3 As String
    Dim zReturn As String
    Dim zColour As String
    zReturn = zLine
    If (Len(zReturn) > 0) Then
        lLen = (Len(zReturn) / 3)
        If (bWhenIsIt("", False)) Then 'true is day time
            Select Case lRandom(3)
                Case 1
                    zColour = "&r"
                Case 2
                    zColour = "&y"
                Case 3
                    zColour = "&w"
            End Select
            zLine1 = zColour & Mid(zReturn, 1, lLen)
            Select Case lRandom(3)
                Case 1
                    zColour = "&r"
                Case 2
                    zColour = "&y"
                Case 3
                    zColour = "&w"
            End Select
            zLine2 = zColour & Mid(zReturn, (lLen + 1), lLen)
            Select Case lRandom(3)
                Case 1
                    zColour = "&r"
                Case 2
                    zColour = "&y"
                Case 3
                    zColour = "&w"
            End Select
            zLine3 = zColour & Mid(zReturn, (lLen * 2) + 1)
            zReturn = zLine1 & zLine2 & zLine3
        Else
            Select Case lRandom(3)
                Case 1
                    zColour = "&b"
                Case 2
                    zColour = "&g"
                Case 3
                    zColour = "&w"
            End Select
            zLine1 = zColour & Mid(zReturn, 1, lLen)
            Select Case lRandom(3)
                Case 1
                    zColour = "&b"
                Case 2
                    zColour = "&g"
                Case 3
                    zColour = "&w"
            End Select
            zLine2 = zColour & Mid(zReturn, (lLen + 1), lLen)
            Select Case lRandom(3)
                Case 1
                    zColour = "&b"
                Case 2
                    zColour = "&g"
                Case 3
                    zColour = "&w"
            End Select
            zLine3 = zColour & Mid(zReturn, (lLen * 2) + 1)
            zReturn = zLine1 & zLine2 & zLine3
        End If
    End If
    zHallucinate = zReturn
End Function
Public Function zTranslateFieldNumber(iValue As Integer) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = "(" & MyCStr(iValue) & ")"
    Select Case iValue
        Case 1
            zReturn = "boolean"
        Case 2
            zReturn = "byte"
        Case 3
            zReturn = "integer"
        Case 4
            zReturn = "long"
        Case 6
            zReturn = "single"
        Case 7
            zReturn = "double"
        Case 8
            zReturn = "date/time"
        Case 10
            zReturn = "string"
        Case 12
            zReturn = "memo"
        Case 15
            zReturn = "rep-id"
    End Select
    zTranslateFieldNumber = zReturn
End Function
Public Function zTranslateHeightLocationZero(lHeight As Long) As String
On Error Resume Next
    Dim zReturn As String
    If (lHeight < 0) Then lHeight = 0
    Select Case lHeight
        Case 0
            zReturn = "ground"
        Case 1 To 10
            zReturn = "attached to the ground"
        Case 11 To 20
            zReturn = "bolted to the ground"
        Case 21 To 30
            zReturn = "cemented to the ground"
        Case 31 To 40
            zReturn = "eye level"
        Case 41 To 50
            zReturn = "mounted on a pole"
        Case 51 To 60
            zReturn = "bolted to a wall high above"
        Case 61 To 70
            zReturn = "roped across the road high above"
        Case 71 To 80
            zReturn = "chained across the road high above"
        Case 81 To 90
            zReturn = "magically floating high above"
        Case Else
            zReturn = "high above"
    End Select
    zTranslateHeightLocationZero = zReturn
End Function
Public Function zVariancePercent(lStarCalcuAC As Long, lCAC As Long) As String
On Error Resume Next
    Dim sAnswer As Single
    sAnswer = 0
    If (lCAC > 0) Then
        sAnswer = (lCAC / lStarCalcuAC) * 100
        If (sAnswer > 100) Then sAnswer = 100
    End If
    zVariancePercent = Format(sAnswer, "FIXED")
End Function
Public Function bShortTurnedIntoAnimalType(lTurnedIntoAnimalType As Long) As Boolean
On Error Resume Next 'TurnedIntoAnimalType is the variable morph into a frog or bull etc..
    Dim bReturn As Boolean
    bReturn = (lTurnedIntoAnimalType > 0 And lTurnedIntoAnimalType <> 7 And lTurnedIntoAnimalType <> 8) 'must be morphed, not a bull and not an icicle
    bShortTurnedIntoAnimalType = bReturn
End Function
Public Function bReturnWeaponTypeAmmunition(zWeaponType As String) As Boolean
On Error Resume Next
    Dim bReturn As Boolean
    Select Case zWeaponType
        Case "AMMO", "CLIP", "BOLT", "BLAS", "ENER", "ARRO", "STON" 'AMMO and CLIP are the same thing
            bReturn = True
        Case Else
            bReturn = False
    End Select
    bReturnWeaponTypeAmmunition = bReturn
End Function
Public Function lReturnClassModifierSpellDurations(lValue As Long, zClass As String) As Long
On Error Resume Next 'multiplies how long
    Dim lReturn As Long
    'Percent Duration Increase
    Select Case zClass
        Case "BA", "GY"
            lReturn = 3
        Case "CL"
            lReturn = 4
        Case "MA"
            lReturn = 6 '60 percent increase
        Case Else
            lReturn = 1
    End Select
    lReturnClassModifierSpellDurations = (lValue) + (lValue * (lReturn / 10))
End Function
Public Function zVariableMessage(zLine As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = zLine
    If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "can ", "may ", False)
    If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "may ", "can ", False)
    If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "might ", "could ", False)
    If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "could ", "might ", False)
    If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "the ", "thee ", False)
    If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "thee ", "the ", False)
    If (lRandom(5) = 1) Then
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "1", "one", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "2", "two", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "3", "three", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "4", "four", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "5", "five", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "6", "six", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "7", "seven", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "8", "eight", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "9", "nine", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "10", "ten", False)
    End If
    
    If (lRandom(5) = 1) Then
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "one", "1", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "two", "2", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "three", "3", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "four", "4", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "five", "5", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "six", "6", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "seven", "7", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "eight", "8", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "nine", "9", False)
        If (lRandom(3) = 1) Then zReturn = strReplaceWordWithThisWord(zReturn, "ten", "10", False)
    End If
    zVariableMessage = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zVariableMessage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zFreeRange(zLine As String) As String
'Purpose: To allow the IN-statement in SQL to construct reports.
'Syntax: ? zFreeRange("1,2,3,5-99")
On Error GoTo Err_Check
    Const cstLoopLoadAllowed = 200 '? zFreeRange("1-99")
                                   'Result: 1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63,64,65,66,67,68,69,70
    Dim iCount As Integer
    Dim zHold As String
    Dim zBuildValue As String
    Dim bLoop As Boolean
    Dim iLoopCount As Integer
    Dim iLoopSwap As Integer
    Dim iLoopStart As Integer
    Dim iLoopEnd As Integer
    Dim zReturn As String
    
    iCount = 0
    If (Len(zLine) <> 0) Then
        If (Mid(zLine, Len(zLine), 1) <> ",") Then
            zLine = zLine & "," 'we mark the end of the line
        End If
        For iCount = 1 To Len(zLine)
            zHold = Mid(zLine, iCount, 1)
            Select Case UCase(zHold)
                Case ",", "/", "\"
                    If (IsNumeric(zBuildValue)) Then
                        If (bLoop) Then
                            iLoopEnd = CInt(zBuildValue) 'if we are not looping
                            If (iLoopStart > iLoopEnd) Then 'fix swapping errors
                                iLoopSwap = iLoopStart
                                iLoopStart = iLoopEnd
                                iLoopEnd = iLoopSwap
                            End If
                            If (iLoopEnd - iLoopStart < cstLoopLoadAllowed * 3) Then 'We process past the length of the line just in case it is only a range
                                If (iLoopEnd - iLoopStart > 0) Then
                                    'we count up the loop
                                    For iLoopCount = iLoopStart To iLoopEnd
                                        zReturn = zReturn & CStr(iLoopCount) & ","
                                    Next iLoopCount
                                End If
                                bLoop = False
                            End If
                        Else
                            zReturn = zReturn & zBuildValue & ","
                        End If
                    End If
                    zBuildValue = ""
                Case "-", "+", "T", "O"
                    If (IsNumeric(zBuildValue)) Then
                        bLoop = True 'initialize the loop
                        iLoopStart = CInt(zBuildValue) 'if we are not looping
                        iLoopEnd = iLoopStart 'Just to balance justice
                        zBuildValue = ""
                    End If
                Case Else
                    If IsNumeric(zHold) Then
                        zBuildValue = zBuildValue & zHold 'build next value for use or loop
                    End If
            End Select
        Next iCount

        'clean up
        If (Len(zReturn) <> 0) Then 'drop off the end characters that are not numeric
            If (Len(zReturn) > cstLoopLoadAllowed) Then zReturn = Mid(zReturn, 1, cstLoopLoadAllowed)
            Do While Not IsNumeric(Mid(zReturn, Len(zReturn), 1))
                zReturn = Mid(zReturn, 1, Len(zReturn) - 1)
                If (Len(zReturn) = 0) Then Exit Do
            Loop
        End If
    End If
    zFreeRange = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zFreeRange," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTranslateHINTCommands(zHint As String)
    Dim lLen As Long
    Dim zHintHold As String
    Dim zReturn As String
    
    lLen = Len(zHint)
    zHintHold = MyCStr(zHint)
    If (lLen > 1) Then zHintHold = UCase(Mid(zHintHold, 1, 3))
    zReturn = ""
    
    Select Case zHintHold
        Case "SPR"
            zReturn = "SPREAD"
        Case "SWI"
            zReturn = "SWING"
        Case "SPI"
            zReturn = "SPIN"
        Case "SPE"
            zReturn = "SPEAK"
        Case "TOU"
            zReturn = "TOUCH"
        Case "TAP"
            zReturn = "TAP"
        Case "TUG"
            zReturn = "TUG"
        Case "TUR"
            zReturn = "TURN"
        Case "TWI"
            zReturn = "TWIS"
        Case "FIX"
            zReturn = "FIX"
        Case "SLI"
            zReturn = "SLIDE"
        Case "CLI"
            zReturn = "CLIMB"
        Case "MOV"
            zReturn = "MOVE"
        Case "PRE"
            zReturn = "PRESS"
        Case "PUL"
            zReturn = "PULL"
        Case "PUS"
            zReturn = "PUSH"
        Case "SEA"
            zReturn = "SEARCH"
        Case "SHO"
            zReturn = "SHOVE"
    End Select
    zTranslateHINTCommands = zReturn
End Function
Public Function zFormatGoldCofGLearnpts(lValue As Variant, zType As String, bUseSign As Boolean) As String
    Dim zSign As String
    Dim zReturn As String
    zSign = ""
    zReturn = ""
    Select Case UCase(Mid(zType, 1, 1))
        Case "R"
            If (lValue < 0) Then
                zSign = "&c"
            Else
                zSign = "&C"
            End If
            If (bUseSign) Then
                If (lValue < 0) Then
                    zSign = zSign & "-"
                Else
                    zSign = zSign & "+"
                End If
            End If
            zReturn = "&gxp&R[" & zSign & "&c" & MyCStr(Abs(lValue)) & "&R]"
        Case "P"
            zReturn = "&G[&g" & MyCStr(lValue) & "xp&G]" 'experience gained
        Case "X", "B"
            zReturn = "&G[&g" & MyCStr(lValue) & "&Gb&gxp&G]" 'bonus experience gained
        Case "G" 'gold
            If (lValue < 0) Then
                zSign = "&R"
            Else
                zSign = "&Y"
            End If
            If (bUseSign) Then
                If (lValue < 0) Then
                    zSign = zSign & "-"
                Else
                    zSign = zSign & "+"
                End If
            End If
            zReturn = "&W[" & zSign & "&y" & MyCStr(Abs(lValue)) & "&wgold&W]"
        Case "C" 'crowns of glory
            If (lValue < 0) Then
                zSign = "&R"
            Else
                zSign = "&Y"
            End If
            If (bUseSign) Then
                If (lValue < 0) Then
                    zSign = zSign & "-"
                Else
                    zSign = zSign & "+"
                End If
            End If
            zReturn = "&W[" & zSign & "&W" & MyCStr(Abs(lValue)) & "&wcofg&W]"
        Case "L" 'learn points
            If (lValue < 0) Then
                zSign = "&R"
            Else
                zSign = "&W"
            End If
            If (bUseSign) Then
                If (lValue < 0) Then
                    zSign = zSign & "-"
                Else
                    zSign = zSign & "+"
                End If
            End If
            zReturn = "&w[" & zSign & "&w" & MyCStr(Abs(lValue)) & "&Wlps&w]"
        Case "T"
            zReturn = "&a[&W" & MyCStr(lValue) & "&WT&wD&a]" 'subCombatPvM Total damage
    End Select
    zFormatGoldCofGLearnpts = zReturn
End Function
Public Function zReturnPlayerLevelAscii(lPL As Long) As String
    zReturnPlayerLevelAscii = "&y(&g[&WPL&G" & MyCStr(lPL) & "&g]&y)"
End Function
Public Function zTranslateColour(zPassedColourCode As String) As String
On Error Resume Next
    Dim zColourCode As String
    Dim zReturn As String
    
    zColourCode = zPassedColourCode
    zReturn = strReplaceWordWithThisWord(zColourCode, "&r", gblzFNRED, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&g", gblzFNGRE, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&y", gblzFNYEL, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&b", gblzFNBLU, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&m", gblzFNMAG, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&c", gblzFNCYA, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&w", gblzFNWHI, True)
    
    zReturn = strReplaceWordWithThisWord(zReturn, "&a", gblzFNBLA, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&A", gblzFNBLA, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&R", gblzFBRED, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&G", gblzFBGRE, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&Y", gblzFBYEL, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&B", gblzFBBLU, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&M", gblzFBMAG, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&C", gblzFBCYA, True)
    zReturn = strReplaceWordWithThisWord(zReturn, "&W", gblzFBWHI, True)
    
     zTranslateColour = zReturn
End Function
