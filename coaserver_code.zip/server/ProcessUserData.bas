Attribute VB_Name = "modProcessUserData"
Option Explicit
'LINKER ERROR??? - NO PROBLEM ! your SOLUTION YOU NEED TO JUST MOVE ALL YOUR CODE INTO YOUR OWN MODULE - ie modReport has lots of room left
'START HERE mudverse.com colours to follow pattern: subSendMsgInfoChannel "&W" & zMomentumPlayerName & " &wGUARDED [&g" & gblzQuestGuardAreaDesc(lPortID) & "&w] [&W+&Y" & lRewardTEMP1 & "&Wcofg&w] [&W+" & lRewardTEMP3 & "&wlps&w] [&W+&Y" & lRewardTEMP2 & "&ygold&w]"
'           make alot of use of ? zFormatGoldCofGLearnpts(12,"c")
Public Sub subProcessUserLine(zPortID As String, zUserData As String)
On Error GoTo Err_Check
    Const cstVersion = "-=SAFARICODE2026=-"
    Dim zWord(5) As String 'We dont bother with handling more than 5 key words and one original prompt copy.
    Dim zPromptOriginal As String
    Dim zPromptMessage As String
    Dim lPortID As Long 'Port Controls
    Dim bInterrupt As Boolean 'knight has interrupt for pvp paladins maybe too
    
    gblbIgnoreSpamWarning = False
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'we make sure the port is of a legal range
        bInterrupt = gbllInterrupt(lPortID) 'happens right on their port
        If (Not bInterrupt) Then 'Interrupt is a force command skill
            'zUserData = zRemoveSwears(zUserData)
            subParser zUserData, zPromptOriginal, zWord(1), zWord(2), zWord(3), zWord(4), zWord(5), zPortID 'Debug.Print "1]zwords//" & zWord(1) & " " & zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5) & vbCrLf & "po=" & zPromptOriginal & vbCrLf & "ud=" & zUserData
            If (Len(zPromptOriginal) > 0) Then
                If (zWatchzPromptOriginal(lPortID) <> zPromptOriginal) Then 'this is to keep people from spamming the same thing in channels
                    zWatchzPromptOriginal(lPortID) = zPromptOriginal
                Else
                    If (lCountOfChar(zPromptOriginal, " ") > 2) Then
                        gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1 + MyCLng(Len(zPromptOriginal) / 4)
                    End If
                End If
                
                Select Case UCase(Mid(zWord(1), 1, 4))
                    'NEW ONES BELOW ARE CLEAN having their own PROCs or FUNCTIONs based on zPortID, zWord1-5, zPromptOriginal
                    Case "VENT"
                        subCyborgVentingSystem zPortID
                    Case "X", "SC", "SCOR", "LEVE" 'SCO-ld emote part is db reserved
                        subSystemScoreSheetPlayer zPortID
                    Case "N", "S", "E", "W", "NE", "NW", "SE", "SW", "U", "D"
                        subMessagesMovementResult (iMomentumEngineXYZ(zWord(1), False, gblbFilterMode(lPortID), gblbGraphicIDsOnOff(lPortID), zPortID)), zPortID
                    Case "AID", "UNST" 'unstun
                        subCombatAid zWord(2), zPortID
                    Case "STUN" 'this is a shoulder attack to lay a mob or player on the ground unable to play!
                        subCombatStun zPortID, MyCStr(zWord(2) & " " & zWord(3))
                    Case "STEA" 'steal
                        subThiefSteal zWord(2), zWord(3), zPortID
                        'subHarassANearbyRandomPlayer 1
                    Case "BATT"
                        subShowBattleStatus zPortID, zWord(2)
                    Case "BREA"
                        subBreakEntangle zPortID 'If (lEntanglementDuration = 0 Or (zClass = "GL" Or zClass = "WA" Or zClass = "PL" Or zClass = "KN")) Then
                    Case "CLEA", "LITT" 'LITTER CLEAN
                        subCleanTheDamagedArea zPortID
                    Case "BREA", "HIT", "K", "KIL", "KILL", "JAB", "ATTA", "STAB", "DEST", "SMAS" 'kill mobiles
                        subCombatAttack zPortID, MyCStr(zWord(2) & " " & zWord(3))
                    Case "PETS"
                        subShowPets zPortID
                    Case "DISA" 'and DISARM TRAPs
                        subCombatDisarm zPortID, MyCStr(zWord(2) & " " & zWord(3)) 'subCombatDisarm zWord(2), zPortID, lPlayerID, zPortID, lX, lY, lZ, lCLuc + lCDex + lPlayerLevel + lGrip, zPlayerName, lCSoul, zClass, lDisarmInterruption, lDetectInvisibilityDuration
                    Case "BS" 'some classes get backstab
                        subBackstab zPortID, MyCStr(zWord(2) & " " & zWord(3))
                    Case "I", "IN", "INV", "INVE"
                        subPlayerInventoryList zPortID, 0
                    Case "EQ", "EQU", "EQUI"
                        subPlayerEquipmentList zPortID, zWord(2), zWord(3), 0
                    Case "SCRY" 'dig and create a pentagram
                        subSCRY zPortID, zPromptOriginal, zWord(1), zWord(2)
                    Case "SHOW"
                        subShowtimePlayer zPortID, zWord(2), zWord(3)
                    Case "DRE", "THIN", "THOU", "DREA" 'just a player level test environment
                        subDreamscape zPortID
                    Case "ANGE"
                        subSpellAngerMobileVSMobile 1, zPortID, True
                    Case "LOCA"
                        subMobLocation zPortID, zWord(2), zWord(3), zWord(4)
                    Case "QUIT", "LOGO" 'logout
                        subQuitTheGame zPortID
                    Case "PLYR", "PCOD"
                        subSendPlayerList zPortID, zWord(2), zWord(3), zWord(4), zWord(5), zPromptOriginal
                    Case "MOBS", "MOBI", "MCOD"
                        subSendMobileList zPortID
                    Case "OBJE", "OCOD"
                        subSendObjectList zPortID
                    Case "DEFA"
                        Select Case UCase(CStr(zWord(2)))
                            Case "CM", "FM", "GUI"
                                gblbGraphicIDsOnOff(lPortID) = True
                                gblbFilterMode(lPortID) = False
                                gblbClientMode(lPortID) = True
                                subSendMsg "&GAdjusted only for GUI OFF/FM OFF/CM ON", zPortID
                            Case Else
                                gblbGraphicIDsOnOff(lPortID) = False
                                subSendMsg "&GGraphical ID mode OFF", zPortID
                                gblbSensesMode(lPortID) = True
                                subSendMsg "&GSenses mode ON", zPortID
                                gblbFilterMode(lPortID) = False
                                subSendMsg "&GFilter mode OFF", zPortID
                                gblbScareMode(lPortID) = False
                                subSendMsg "&GScarey Hunted mode OFF", zPortID
                                gblbClientMode(lPortID) = True
                                subSendMsg "&GClient mode ON", zPortID
                        End Select
                    Case "CM"
                        Select Case UCase(CStr(zWord(2)))
                            Case "ON"
                                gblbClientMode(lPortID) = True
                            Case "OFF"
                                gblbClientMode(lPortID) = False
                            Case "ST", "STA", "STAT"
                            Case Else
                                gblbClientMode(lPortID) = Not gblbClientMode(lPortID)
                        End Select
                        Select Case gblbClientMode(lPortID)
                            Case True
                                subSendMsg "&GToggle: Client mode -is- now ON", zPortID
                            Case False
                                subSendMsg "&GToggle: Client mode -is- now OFF", zPortID
                        End Select
                    Case "CMON"
                        gblbClientMode(lPortID) = True
                        subSendMsg "&GClient mode ON", zPortID
                    Case "CMOF"
                        gblbClientMode(lPortID) = False
                        subSendMsg "&GClient mode OFF", zPortID
                    Case "CMS", "CMST" 'status
                        Select Case gblbClientMode(lPortID)
                            Case True
                                subSendMsg "&GClient mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GClient mode -is- OFF", zPortID
                        End Select
                    Case "GMON"
                        gblbGraphicIDsOnOff(lPortID) = True
                        subSendMsg "&GGraphical ID mode ON", zPortID
                    Case "GMOF"
                        gblbGraphicIDsOnOff(lPortID) = False
                        subSendMsg "&GGraphical ID mode OFF", zPortID
                    Case "GMS", "GMST" 'status
                        Select Case gblbGraphicIDsOnOff(lPortID)
                            Case True
                                subSendMsg "&GGraphical ID mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GGraphical ID mode -is- OFF", zPortID
                        End Select
                    Case "GM"
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbGraphicIDsOnOff(lPortID)
                                        Case True
                                            subSendMsg "&GGUId mode -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GGUId mode -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbGraphicIDsOnOff(lPortID) = True
                                Case Else
                                    gblbGraphicIDsOnOff(lPortID) = False
                            End Select
                        Else
                            gblbGraphicIDsOnOff(lPortID) = Not gblbGraphicIDsOnOff(lPortID)
                        End If
                        
                        If (gblbGraphicIDsOnOff(lPortID)) Then
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GGUId mode ON", zPortID
                        Else
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GGUId mode OFF", zPortID
                        End If
                    Case "SENS", "SMON"
                        gblbSensesMode(lPortID) = True
                        subSendMsg "&GSenses mode ON", zPortID
                    Case "SENC", "SMOF"
                        gblbSensesMode(lPortID) = False
                        subSendMsg "&GSenses mode OFF", zPortID
                    Case "SM"
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbSensesMode(lPortID)
                                        Case True
                                            subSendMsg "&GSenses -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GSenses -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbSensesMode(lPortID) = True
                                Case Else
                                    gblbSensesMode(lPortID) = False
                            End Select
                        Else
                            gblbSensesMode(lPortID) = Not gblbSensesMode(lPortID)
                        End If
                        
                        If (gblbSensesMode(lPortID)) Then
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GSenses ON", zPortID
                        Else
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GSenses OFF", zPortID
                        End If
                    Case "BMON", "FMON"
                        gblbFilterMode(lPortID) = True
                        subSendMsg "&GFilter mode ON", zPortID
                    Case "BMOF", "FMOF"
                        gblbFilterMode(lPortID) = False
                        subSendMsg "&GFilter mode OFF", zPortID
                    Case "FMS", "FMST", "BMS", "BMST" 'status
                        Select Case gblbFilterMode(lPortID)
                            Case True
                                subSendMsg "&GFilter mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GFilter mode -is- OFF", zPortID
                        End Select
                    Case "FM", "BM", "BLIN", "VI", "IMPA", "VISU"
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbFilterMode(lPortID)
                                        Case True
                                            subSendMsg "&GFilter -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GFilter -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbFilterMode(lPortID) = True
                                Case Else
                                    gblbFilterMode(lPortID) = False
                            End Select
                        Else
                            gblbFilterMode(lPortID) = Not gblbFilterMode(lPortID)
                        End If
                        
                        If (gblbFilterMode(lPortID)) Then
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GFilter ON", zPortID
                        Else
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GFilter OFF", zPortID
                        End If
                    Case "HMON"
                        gblbScareMode(lPortID) = True
                        subSendMsg "&GHunted mode ON", zPortID
                    Case "HMOF"
                        gblbScareMode(lPortID) = False
                        subSendMsg "&GHunted mode OFF", zPortID
                    Case "HMS", "HMST" 'status
                        Select Case gblbScareMode(lPortID)
                            Case True
                                subSendMsg "&GHunted mode -is- ON", zPortID
                            Case Else
                                subSendMsg "&GHunted mode -is- OFF", zPortID
                        End Select
                    Case "HM" 'works with subHarassANearbyRandomPlayer gblbHarassANearbyRandomPlayerMS
                        If (Len(zWord(2) & zWord(3)) > 0) Then
                            Select Case Mid(UCase(zWord(2)), 1, 2)
                                Case "ST"
                                    Select Case gblbScareMode(lPortID)
                                        Case True
                                            subSendMsg "&GHunted mode -is- ON", zPortID
                                        Case Else
                                            subSendMsg "&GHunted mode -is- OFF", zPortID
                                    End Select
                                Case "ON", "TR", "1", "T"
                                    gblbScareMode(lPortID) = True
                                Case Else
                                    gblbScareMode(lPortID) = False
                            End Select
                        Else
                            gblbScareMode(lPortID) = Not gblbScareMode(lPortID)
                        End If
                        
                        If (gblbScareMode(lPortID)) Then
                            gblbHarassANearbyRandomPlayerMS = True
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GHunted mode ON", zPortID
                        Else
                            gblbHarassANearbyRandomPlayerMS = bSetHarassANearbyRandomPlayerMS()
                            If Mid(UCase(zWord(2)), 1, 2) <> "ST" Then subSendMsg "&GHunted mode OFF", zPortID
                        End If
                    Case "WH", "WHO"
                        subSystemReportWho zPortID
                    Case "HURT", "NUKE", "SUCI", "SUIC", "SLAM", "FIST", "DELE", "THUN" 'slam fists together // HOWEVER, NUKE is delete char forever!!! thunder fist of god
                        'Monk suicide doesnt give the nuke msg
                        subSuicide zPortID, zPromptOriginal, zWord(1), zWord(2)
                    Case "SABA", "SABO" 'Gypsy power skill - someone might spell it Sabatauge or something
                        subSabotage zPortID
                    Case "REPO"
                        subReportCharacterSheet zPortID
                    Case "NAME", "WHOA", "WHAT"
                        subReportCharacterSheetNAME zPortID
                    Case "DD", "DDES", "ND", "DN", "NDES", "DAY", "NIGH", "BOTH"
                        subPlayerDAYNIGHTDESCQuick zPortID
                    Case "QUIC", "DOOR"
                        subPlayerExitsQuicks zPortID
                    Case "WHOI", "FING", "FIN", "FI", "PROF" 'profile finger whois
                        subPlayerWhoIS zWord(2), zPromptOriginal, zPortID
                    Case "DIRE", "DIR", "DI"
                        subShowMyExits zPortID
                    Case "READ", "L", "LOOK", "INSP", "EX", "EXA", "EXAM", "LO", "LOO", "OK", "OOK" 'inspect examine look ... the spam system doesn't look for anything other than these two
                        subLookAreaDesc zPortID, zPromptOriginal, zWord(2), zWord(3), zWord(4), gblbFilterMode(lPortID), gblbGraphicIDsOnOff(lPortID)
                    Case "MBC"
                        subPlayerMessageBoardCreate zPortID, zPromptOriginal
                    Case "MBD"
                        subPlayerMessageBoardDelete zPortID, MyCLng(zWord(2))
                    Case "MBV", "MBR" 'message board view or read
                        subPlayerMessageBoardView zPortID, zWord(2)
                    Case "RETU" 'return clan flags
                        basCaptureTheFlag zPortID
                        subSendMsg "&GDone, any flags you were holding were returned.", zPortID
                    Case "BRID", "SIGN", "CROS", "LOWE" 'cross the bridge, lower the bridge
                        subBridgeRaiseLower zPortID
                    Case "MAGI", "MAJI", "UNDO" 'similar to bash in the door
                        subMagicInTheDoor zWord(2), zPortID 'Word(2) is the direction
                    Case "BUST", "BASH", "SPLI" 'similar to Bash in the Majic Door
                        subBashInTheDoor zWord(2), zPortID 'Word(2) is the direction
                    Case "AZUL"
                        gblbIgnoreSpamWarning = True
                        subGraphicalRequestCode zPortID
                    Case "MARK"
                        subPlayerMark zPortID
                    Case "RECA"
                        subPlayerRecall zPortID
                    Case "POT"
                        subPotArea zWord(2), zWord(3), zPortID
                    Case "RND", "RNDR", "RAND", "DICE"
                        subRandomRoll zWord(2), zPortID
                    Case "DRAW", "DECK", "DEAL"
                        subDrawPlayerCards zWord(2), zWord(3), zPortID
                    Case "HP" 'heal pets
                        subSpellListHealPets zPortID, False 'this is a skill to some classes and is just soul cost
                    Case "DEAD", "RD"
                        subSpellListRaiseArea zPortID, False 'this is a skill to some classes and is just soul cost
                    Case "CHAI"
                        subSpellListChainAreas zPortID, False 'this is a skill to some classes and is just soul cost
                    Case "FORC"
                        subUseForce zPortID, zWord(2)
                    Case "WEA", "WEAR", "WAE", "WAER", "WIE", "WIEL", "HOLD", "WEAL", "ARM", "DUAL" 'some people spell wield weald - go figure
                        subWearObject zPortID, zWord(2)
                    Case "REM", "REMO", "UNEQ", "UNWE" 'unequipt/unwear an item
                        subRemoveObject zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                    Case "DRO", "DROP"
                        subDropObject zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                    Case "GE", "GET", "TA", "TAK", "TAKE" 'this one looks messy but its self-contained in the new method
                        If (Len(zWord(2)) <> 0) Then
                            If (Len(zWord(3)) <> 0 Or Len(zWord(4)) <> 0) Then
                                subGetObjectContainer zPortID, zWord(2), MyCStr(zWord(3) & " " & zWord(4))
                            Else
                                subGetObjectGround zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                            End If
                        Else
                            subSendMsg "&GGet what?", zPortID
                        End If
                    Case "PUT"
                        subPutObjectContainer zPortID, zWord(2), zWord(3)
                    Case "EAT"
                        subPlayerEatInventoryItem zWord(2), zPortID
                    Case "FAVO" 'favour your immortal and vote for your immortal!
                        subPlayerFavour zWord(2), zPortID
                    Case "DRIN", "SIP"
                        subPlayerDrink zPortID, zWord(2)
                    Case "RECI"
                        subReciteObject zPortID, zWord(2), zWord(3)
                    Case "FISH"
                        subFishAreaForObjectsSetUp zPortID
                    Case "QUAF"
                        subQuaffObject zPortID, zWord(2)
                    Case "EXCH" 'must be on a starship
                        subPlayerExchangeBoard zPortID, zWord(2), zWord(3), zWord(4), zWord(5)
                    Case "GOLF" 'GOLF OBJECT HOLENUMBER
                        subGolfGame zPortID, zWord(2), zWord(3)
                    Case "LON"
                        gblbLineFeed(MyCLng(zPortID)) = True
                    Case "LOFF"
                        gblbLineFeed(MyCLng(zPortID)) = False
                    Case "CLRS", "CLR", "CLS", "CLSR" 'clear the screen
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "CLS1" 'scroll the screen up
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf, zPortID
                        DoEvents
                    Case "CLS2" 'scroll the screen up
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "CLSS", "CLS3" 'clear the screen - 3lines small
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "CLSM", "CLS4" 'clear the screen - 3lines small
                        subShowCommandPromptPortID zPortID
                        subSendMsg vbCrLf & vbCrLf & vbCrLf & vbCrLf, zPortID
                        DoEvents
                    Case "STAR" 'stargate
                        subActivateStargate zPortID, zWord(2)
                    Case "PHAS"
                        subPhaserPistol zPortID, zWord(2)
                    Case "HELP", "BRIE" 'help or brief
                        subHelpSystem zPortID, MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5))
                    Case "GAMB", "PLAY"
                        subGamble zWord(2), zWord(3), zPortID
                    Case "SS"
                        subFleetCommand zWord(2), zWord(3), zWord(4), zWord(5), zPortID
                    Case "PAGE", "PGAE", "PAEG" 'Pages of reports
                        subPlayerReports zPortID, zWord(2)
                    Case "EYEB"
                        subEyeBeamToggle zPortID
                    Case "HINT" 'this one looks messey but its the new method
                        gblbHint(lPortID) = Not gblbHint(lPortID)
                        If (gblbHint(lPortID)) Then
                            subSendMsg "&gHints are now on.", zPortID
                        Else
                            subSendMsg "&gHints are now off.", zPortID
                        End If
                        subSendMsg "&gCommands to interact with ground items are:" & vbCrLf & "'ENTER', 'EXIT', 'CLIMB', 'FIX', 'MOVE', 'PRESS', 'PULL', 'PUSH', 'SEARCH', 'SLIDE', 'SPREAD', 'SWING', 'SHOVE', 'SPIN', 'SPEAK', 'TOUCH', 'TAP', 'TUG', 'TURN', 'TWIS'" & vbCrLf & "Note: USE LEVER (objectname) might also be your solution!", zPortID
                    Case "ENTE", "EXIT", "SLID", "CLIM", "MOVE", "PRES", "PULL", "PUSH", "SEAR", "SHOV", "SPRE", "SWIN", "SPIN", "SPEA", "TOUC", "TAP", "TUG", "TURN", "TWIS", "FIX"
                        subAreaConstruct zPortID, zWord(1), zPromptOriginal 'subAreaConstruct zPortID, zPlayerName, lPlayerID, lX, lY, lZ, zClass, zWord(1), zPromptOriginal, lPlayerLevel, lStatus, lEntanglementDuration
                    Case "CHAN"
                        subChannelControl zPortID, zWord(2)
                    Case "STEP" 'so we can step on eachother when a frog or mouse
                        subPlayerStepPlayer zWord(2), zPortID
                    Case "AUTO", "+AUT" 'this one looks like its old-style but its NOT - but it could still be in a PROC
                        If ((lPortID >= cstlMinPort And lPortID <= cstlMaxPort)) Then
                            Select Case UCase(Mid(zWord(2), 1, 2))
                                Case "ON", "+"
                                    gblbAutoloot(lPortID) = True
                                Case "OF", "-"
                                    gblbAutoloot(lPortID) = False
                                Case Else
                                    gblbAutoloot(lPortID) = (Not gblbAutoloot(lPortID))
                            End Select
                            Select Case (gblbAutoloot(lPortID))
                                Case True
                                    subSendMsg "&GAutoloot - on", zPortID
                                Case False
                                    subSendMsg "&gAutoloot - off", zPortID
                            End Select
                        End If
                    Case "VERS", "VER", "ABOU", "WRIT"
                        subSendMsg "&G~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", zPortID
                        subSendMsg "&G                             ~C I T Y  of  A G E S~", zPortID
                        subSendMsg "&g                        Coded by: " & zDecrypt("CbqsdoO-!Kpqz)Ss`fq*"), zPortID
                        subSendMsg "&g               Copyright " & zDecrypt("CbqsdoO-!Kpqz)Ss`fq*") & ", " & cstVersion, zPortID
                        subSendMsg "&G~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~", zPortID
                        'with port counting max
                    Case "ENSN", "ENTR", "NET" 'ensnare - must be holding a net item
                        subEnsnare zPortID, zWord(2)
                    Case "EMPT", "NEED", "DIAG" 'Diagnose missing and needed or empty. What is empty for equipment locations - stuff we need
                        subMissingEq zPortID
                    Case "STOC"
                        subPlayerStockMarket zWord(2), zWord(3), zWord(4), zWord(5), zPortID
                    'Case "BEAU", "BS" 'beauty - painting
                    '    subPlayerBeauty zPortID, zWord(2), zWord(3)
                    Case "TRAN", "CRAF" 'transmute
                        subQuestTransmute zPortID
                    Case "HORS"
                        subHorseBet zPortID, zWord(2), zWord(3)
                    Case "ROUL"
                        subRouletteScreen zPortID, UCase(zWord(2)), UCase(zWord(3)), UCase(zWord(4))
                    'Case "BITE", "MORP" 'I disabled this
                    '    If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                    '        subMorph zPlayerName, lPlayerID, lPlayerLevel, zWord(2), zClass, lX, lY, lZ, zPortID
                    '    Else
                    '        subSendMsg "&rYou can't morph players while in combat.", zPortID
                    '    End If
                    Case "COM", "COMP" 'Compare two items in inventory
                        If (Len(zWord(4)) > 0 And Len(zWord(5)) > 0) Then
                            subCompare MyCStr(zWord(2) & zWord(3)), MyCStr(zWord(4) & zWord(5)), zPortID
                        Else
                            subCompare zWord(2), MyCStr(zWord(3) & zWord(4)), zPortID
                        End If
                    Case "WIZL", "WIZ", "WLIS", "IMMS"
                        subWizList zPortID
                    Case "SAVE" 'yep this does nothing cuz we use a SQL database - try to use a SDD drive whoowhoo!!
                        subSendMsg "&gDone, your game is now saved." & vbCrLf & "Note, the system auto-saves for you when you play in the realm.", zPortID
                    Case "MEDI"
                        subForgeMobTag zWord(2), zPortID
                    Case "GOTO"
                        subImmortalGotoMeditMob zPortID
                    Case "OFOR", "FORG", "OEDI" 'obj edit/forge
                        subForge zWord(2), zWord(3), zPromptOriginal, zPortID
                    Case "HOUS", "HOME" 'Players with a house can use this to get back home fast.
                        subPlayerGotoHouse zPortID
                    Case "TELE" 'Room teleport
                        subImmortalTeleport zPortID, zWord(2), zWord(3), zWord(4)
'                        Case "SUPE" 'Report: Immortal Supervisor this requires no immortal level
'                            subImmortalSupervisorReport zPortID, zWord(2), zWord(3), iImmortalSupervisor, zClass, lImmortalLevel, lClanMemberLevel, lPlayerID
                    Case "ATMO"
                        If (gbllAtmosphereStaticCharges > cstAtmozDefault) Then gbllAtmosphereStaticCharges = cstAtmozDefault
                        subSendMsg "&WATMOZ " & gbllAtmosphereStaticCharges & " pps", zPortID
                    Case "SCAN"
                        subCombatScan zPortID, zWord(2), zWord(3)
                    Case "MAPS", "MAP" 'Shows the matrix you are in
                        subShow11x11Map zPortID
                    Case "PAM", "GUAR"
                        subGuardDetails zPortID
                    Case "PEST", "SICK", "SNEE", "PAND", "PLAG"
                        subShowPestilance zPortID
                    Case "SAY", "SAYS", "'" 'SAY/EXCLAIM/ASK CHANNEL
                        subSpeakSayAskExclaim zPortID, zRemoveInvalidChatChars(zPromptOriginal)
                    Case "WHER"
                        subPlayerWhereAreas zPortID
                    Case "OOC", "OCC"
                        If (gbliOOCChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "ooc", zPromptOriginal, gblzFNBLA
                        Else
                            subSendMsg "&rOut-of-Character Channel: You have this channel turned off.", zPortID
                        End If
                    Case "RUMO", "RHUM", "RHOM", "RUME"
                        If (gbliRumoChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "rumor", zPromptOriginal, gblzFNCYA
                        Else
                            subSendMsg "&rRUMOR: Your realm channel is turned off.", zPortID
                        End If
                    Case "GLOB", "R", "RA", "RAM", "RAMB"
                        If (gbliRambChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "ramble", zPromptOriginal, gblzFBBLU
                        Else
                            subSendMsg "&rRAMBLE: Your channel is turned off.", zPortID
                        End If
                    Case "GO", "GOS", "GOSS", "IC"
                        If (gbliGossipChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "ic", zPromptOriginal, gblzFBMAG
                        Else
                            subSendMsg "&rGOSSIP-In-Character Chatting: Your channel is turned off.", zPortID
                        End If
                    Case "NOOB", "NOO", "NEW", "NEWB"
                        If (gbliNewbieChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "noobie", zPromptOriginal, gblzFBGRE
                        Else
                            subSendMsg "&rNEWBIE CHANNEL: You have this channel turned off.", zPortID
                        End If
                    Case "YELL", "COMM", "SHOU" 'CHANNEL YELL/SHOUT
                        subChannelYell zPortID, zPromptOriginal, zWord(2)
                    Case "INTE", "IMC", "CHAT" 'Intermud chat
                        If (gbliIMCChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "imc", zPromptOriginal, gblzFNWHI
                        Else
                            subSendMsg "&rQUOTE: Your channel is turned off.", zPortID
                        End If
                    Case "QUO", "QUOT" 'QUOTE
                        If (gbliQuotChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "quote", zPromptOriginal, gblzFBCYA
                        Else
                            subSendMsg "&rQUOTE: Your channel is turned off.", zPortID
                        End If
                    Case "QUE", "QUES" 'QUEST CHANNEL
                        If (gbliQuotChannelStatus(lPortID)) Then
                            subQuestSystemAndChannel zWord(2), zWord(3), zPromptOriginal, zPortID
                        Else
                            subSendMsg "&rQUEST: Your channel is turned off.", zPortID
                        End If
                    Case "MUS", "MUSI" 'MUSIC CHANNEL
                        If (gbliMusiChannelStatus(lPortID)) Then
                            subSendChannelAll zPortID, "music", zPromptOriginal, gblzFBBLU
                        Else
                            subSendMsg "&rMUSIC: Your channel is turned off.", zPortID
                        End If
                    Case "LEAD" 'leaders and entities and immortals only
                        subLeaderOnlyChannel zPortID, zPromptOriginal
                    Case "GOC", "GOD", "GODS", "ENTI" 'GOD ONLY CHANNEL
                        subImmortalOnlyChannel zPortID, zPromptOriginal
                    Case "GOP", "GODP", "CLOU", "HAIL", "HEAV"
                        subImmortalCloudChannel zPortID, zPromptOriginal
                    Case "EM", "SOCI", "POSE", "EMO", "EMOT" 'EMOTE CHANNEL
                        subEmoteSpeak zPortID, zRemoveInvalidChatChars(zPromptOriginal)
                    Case "REPL", "REP", "RE"
                        If (gbliTellChannelStatus(lPortID)) Then
                            gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1
                            If (gbllSpeakControl(lPortID) < 150 + gbllSpeakControlMax) Then
                                zPromptOriginal = "tell " & gblzTelnetReplyCommand(lPortID) & " " & Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1)
                                
                                If ((lPortID >= cstlMinPort And lPortID <= cstlMaxPort) And (Len(zWord(2)) <> 0)) Then
                                    zWord(2) = gblzTelnetReplyCommand(lPortID)
                                    subTellChannel zPortID, zWord(2), zPromptOriginal
                                Else
                                    subSendMsg "&RREPLY (Message)" & vbCrLf & "&gYou need to tell to the person once if you wish to use this command.", zPortID
                                End If
                            Else
                                subTryUsingTheMICCommand 2, zPortID
                            End If
                        Else
                            subSendMsg "&RYour tell channel is currently set to off.", zPortID
                        End If
                    Case "TELL", "TEL", "T", "TLL", "TE" 'TELL CHANNEL
                        If (gbliTellChannelStatus(lPortID)) Then
                            gbllSpeakControl(lPortID) = gbllSpeakControl(lPortID) + 1
                            If (gbllSpeakControl(lPortID) < 90 + gbllSpeakControlMax) Then
                                subTellChannel zPortID, zWord(2), zPromptOriginal
                                If (Len(zWord(2)) <> 0) Then gblzTelnetReplyCommand(MyCInt(zPortID)) = zWord(2)
                            Else
                                subTryUsingTheMICCommand 2, zPortID
                            End If
                        Else
                            subSendMsg "&RYour tell channel is currently set to off.", zPortID
                        End If
                    Case "CLAN"
                        If (Len(zWord(2)) <> 0) Then
                            If (zWord(2) = "LEAVE" And zWord(3) = "THIS" And zWord(4) = "GUILD") Then
                                subLeaveMyGuild zPortID
                            Else
                                If (Len(zWord(3)) = 0) Then 'we want people to be able to start words with: CLAN name is Traer of the Gh'oul - without it just running the CLAN NAME report
                                    Select Case zWord(2)
                                        Case "FLA", "FLAS", "FLGA", "FLGAS", "FLAG", "FLAGS", "FAGS" 'yeas FAGS gets typed by accident and its stoopid to see lol
                                            subIndicatePlayerWhereWithFlags zPortID
                                        Case "LIST", "NAME", "NAMES"
                                            subSystemReportClanNameList zPortID
                                        Case "EXPIRE", "EXPIRES" 'expires (DateDiff('d',[LastPlayed],Date()))>" & cstlRankLost & ")
                                            subSystemReportClanExpireLevel zPortID, "E"
                                        Case "RANK", "RANKS"
                                            subSystemReportClanRankLevel zPortID, "R"
                                        Case "LEVEL", "LEVELS"
                                            subSystemReportClanRankLevel zPortID, "L"
                                        Case Else
                                            If (gbliClanChannelStatus(lPortID)) Then
                                                subClanSpeak zPortID, zPromptOriginal
                                            Else
                                                subSendMsg "&rCLAN: Your channel is turned off.", zPortID
                                            End If
                                    End Select
                                Else
                                    If (gbliClanChannelStatus(lPortID)) Then
                                        subClanSpeak zPortID, zPromptOriginal
                                    Else
                                        subSendMsg "&rCLAN: Your channel is turned off.", zPortID
                                    End If
                                End If
                            End If
                        Else
                            subSendMsg "&gtype HELP CLAN" & vbCrLf & "Type CLAN LEAVE THIS GUILD to leave your clan." & vbCrLf & "See Also: HELP INDUCT", zPortID
                        End If
                    Case "MIC", "FRIE" 'speak through the speakerphone
                        If (Len(zWord(2)) <> 0) Then
                            'This sends the message over Speaker phone
                            subSpeakerPhoneMic zPortID, zPromptOriginal
                        Else
                            'List all the people on your Mic list.
                            subSpeakerPhoneMicList zPortID
                        End If
                    Case "BOOK", "ADD"
                        If (Len(zWord(2)) > 0) Then
                            subSpeakerPhoneBookAdd zPortID, zWord(2)
                        Else
                            subSendMsg "&gSyntax: BOOK (add player name to your clan black book)", zPortID
                        End If
                    Case "ERAS"
                        subSpeakerPhoneBookDelete zPortID, zWord(2)
                    Case "MUTE", "HANG" 'hang up on/mute a member
                        subSpeakerPhoneBookMute zPortID, zWord(2), -1
                    Case "UNMU"  'listen to/unmute member
                        subSpeakerPhoneBookMute zPortID, zWord(2), 0
                    Case "PRAY" 'Only gods hear this channel - anyone can use it.
                        subImmortalPrayChannel zPortID, zPromptOriginal
                    Case "CHR"
                        subImmortalRaceOnlyChannel zPortID, zPromptOriginal
                    Case "CHC"
                           subImmortalClassOnlyChannel zPortID, zPromptOriginal
                    Case "HOC", "HERO"
                        subImmortalHeroOnlyChannel zPortID, zPromptOriginal
                    Case "LOC", "LORD"
                        subImmortalLordOnlyChannel zPortID, zPromptOriginal
                    Case "ETE", "ETER"
                        subImmortalEternalOnlyChannel zPortID, zPromptOriginal
                    Case "GTC", "ITC", "ITG"  'IMM Global TEASE CHANNEL
                        subImmortalEchoChannel zPortID, zPromptOriginal
                    Case "GTR", "ITR"  'IMM Room TEASE CHANNEL
                        subImmortalTeaseRoomChannelAll zPortID, zPromptOriginal
                    Case "Q", "EXIT", "OUT", "BYE"
                        subSendMsg "&RTo quit you must type QUIT.", zPortID
                    Case "AFK"
                        subSetAFKMode zPortID
                    Case "FLE", "FLEE" 'Flee from combat
                        subCombatPlayerFlee zPortID
                    Case "FACT"
                        subShowFactionColonistsInArea zPortID
                        subFactionList zPortID, zWord(2), zWord(3)
                    Case "LITE", "LIGH", "IGNI" 'ignite/light torch, light lamp, for example
                        subLightObject zPortID, zWord(2)
                    Case "TIME", "DATE", "CALA"
                        bWhenIsIt zPortID, True
                    Case "PEEK", "PEER"
                        If (Len(zWord(2)) > 0) Then
                            subLookPeek zPortID, zWord(2), False
                        Else
                            subSendMsg "&gSYNTAX: PEEK [direction].", zPortID
                        End If
                    Case "SPEL"
                        subPlayerAffects zPortID, "SPELLS"
                    Case "SKIL"
                        subPlayerAffects zPortID, "SKILLS"
                    Case "AFF", "AFFE"
                        subPlayerAffects zPortID, "BOTH"
                    Case "SHOP", "LIST", "LST", "WARE", "SHOW", "MERC"
                        subMerchantInAreaWares zPortID
                    Case "SELL"
                        subMarketSell MyCStr(zWord(2) & " " & zWord(3)), zPortID
                    Case "BUY"
                        subMerchantInAreaPurchase zPortID, zWord(2)
                    Case "ARMA", "ARME"
                        subArmageddonReport zPortID
                    Case "SACR", "SAC", "TRAS", "JUNK", "DELE"
                        subSacrificeObjects zPortID, zWord(2)
                    Case "JUMP", "POLE", "VAUL", "VALT"
                        subSkillJump zPortID, zWord(2), zWord(3)
                    Case "STOM"
                        subWarriorStomp zPortID
                    Case "HA", "HITA"
                        subHitAllInArea zPortID
                    Case "KE", "KEN", "KENE", "B", "BOL", "BOLT", "ARCA", "ARC" 'ARCANE BOLT for MAGE
                        subCombatARCANEBOLT zPortID, zWord(1), zWord(2), zWord(3) 'quick fire mode too
                    Case "MISS", "FIRE"
                        Select Case Mid(zWord(2), 1, 4)
                            Case "TARG" 'Target for missile weapon, bow, crossbow, or sling
                                subCombatMissileTarget zPortID, MyCStr(zWord(3) & " " & zWord(4)), True, False
                            Case "FIRE" 'fire bow, crossbow, sling to the direction, Arrows, Bolts, Stones must be in inventory
                                subCombatMissileWeapons zPortID
                            Case Else
                                subSendMsg "&gMISSILE TARGET (target name) - will spy your target you must be within range" & vbCrLf & "MISSILE FIRE                 - will fire your weapon at the target", zPortID
                        End Select
                    Case "SNEA" 'sneak
                        subSneak zPortID
                    Case "LOAD"
                        subPlayerLoad zPortID, zWord(2)
                    Case "VET", "HEAL", "VETE"
                        subPlayerVet zPortID, zWord(2)
                    Case "A", "ACT", "ACTI"  'Activate Learn Skill - some of them require it.
                        subActivateLearnSkill zPromptOriginal, zPortID
                    Case "PRAC", "PRA", "PR", "P"
                        If (gblbClientMode(lPortID)) Then
                            subPlayerSkillsLearnTree zPortID, "", "", "<::=-PRACTICED TREE-=::>", True, False, True
                        Else
                            subPlayerSkillsLearnTree zPortID, "", "", "PRACTICED TREE", True, False, True
                        End If
                    Case "C", "CAS", "CAST"
                        subCastGroupOfProcedures zPortID, zWord(2), zWord(3), zWord(4), zWord(5), zPromptOriginal
                    Case "CLAS", "LEAR", "TEAC" 'class room get it lol and Learn Points get traded for a better skill in a weapon type or something unique.
                        If (gblbClientMode(lPortID)) Then
                        Select Case Mid(zWord(2), 1, 4)
                            Case "TREE"
                                subPlayerSkillsLearnTree zPortID, "", "", "<::=-LEARN TREE-=::>", False, False, True
                            Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "FELP", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                                subPlayerSkillsLearnTree zPortID, Mid(zWord(2), 1, 2), Mid(zWord(3), 1, 3), "<::=-LEARN TREE-=::> (peaked)", False, False, False
                            Case Else
                                subPlayerSkillsLearn zPortID, UCase(MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5) & " "))
                        End Select
                        Else
                        Select Case Mid(zWord(2), 1, 4)
                            Case "TREE"
                                subPlayerSkillsLearnTree zPortID, "", "", "LEARN TREE", False, False, True
                            Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "FELP", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                                subPlayerSkillsLearnTree zPortID, Mid(zWord(2), 1, 2), Mid(zWord(3), 1, 3), "LEARN TREE (peaked)", False, False, False
                            Case Else
                                subPlayerSkillsLearn zPortID, UCase(MyCStr(zWord(2) & " " & zWord(3) & " " & zWord(4) & " " & zWord(5) & " "))
                        End Select
                        End If
                    Case "ABSO" 'absorbs same item object, see also merge
                        subGambleAbsorbsLocationObject zPortID
                    Case "JOYS"
                        subAracadeSetup zPortID, zWord(2)
                    Case "RPG", "HEIG", "WEIG", "KGS", "LBS", "NA", "NAR", "NOA", "SLAY", "HR", "DR", "AC", "MF", "BMF", "RECO", "COOR", "STAT", "RACE", "ALI", "ALIG", "LG", "LAZY", "TAG", "TAGS", "TNL", "DND", "GLOR", "CFOG", "COFG", "CROW", "LP", "LPS", "LVL", "LV", "XX", "XXX", "XXXX", "YY", "YYY", "YYYY", "ZZ", "ZZZ", "ZZZZ", "GOLD", "XP", "HHH", "HPS", "HPZ", "HPTS", "PTS", "HITP", "ES", "ESS", "ESSE", "MAN", "MANA", "SOU", "SOUL", "MV", "MOV"
                        subSelfStats UCase(Mid(zWord(1), 1, 4)), zPortID
                    Case "XYZ"
                        subXYZ zPortID
                    Case "SLIS"
                        subSLISTSelector Mid(zWord(2), 1, 4), Mid(zWord(3), 1, 4), zPortID
                    
                    '>>>
                    'OLD STYLE - you can pull out one at a time and make its own sub, "WHO" is a good basic example of how to do this. Note: There is sometimes more than one command that goes with a command: DMGDAMG DMGA (DMGA for those that type fast and make a spelling mistake but still runs the damage code)
                    Case "AREA", "AUCT", "BID", "PDES", "DESC", "PTIT", "TITL", "USE", "UNLO", "TALK", "ASK", "SAYT", _
                         "DAMA", "DMG", "DAMG", "DMAG", "DMGA", "COST", "TRAC", "PATH", "TRAI", "DECL", "MORT", _
                         "DENY", "REPA", "MURD", "CON", "CONS", "IGNO", "IDP", "PID", "PEDI", "TAGP", "PTAG", _
                         "GUES", "SCRA", "GI", "GIV", "GIVE", "OPEN", "CLOS", "FO", "FOL", "FOLL", "STOP", "DISB", _
                         "GR", "GRO", "GROU", "FORM", "GT", "GRPT", "GTAL", ";", "IMMO", "DONA", "ST", "STA", "STAN", _
                         "RELA", "REST", "DISM", "UNMO", "MOUN", "RIDE", "SIT", "WA", "WAK", "WAKE", "SL", "SLE", "SLEE", _
                         "NAP", "BED", "BANK", "BNK", "AID", "IDM", "MID", "MFOR", "EDIT", "DISP", "DIG", "FIND", "UNBU", "BURY", _
                         "VOTE", "POLL", "CANC", "PASS", "UNKE", "UNMA", "KEEP", "INDU", "COLO", "CONF", "RELO", "POWE", "MERG", "PEMO", "PETE", "BOUN"
                        subOldMethodProcess zPromptOriginal, zPortID, zUserData
                    '==============================================================
                        
                    Case Else 'we check the emote system now
                        If (Not bChartEmote(zWord(1), zWord(2), zPortID, "", "", "")) Then
                            If (Len(zPromptOriginal) > 0) Then subSendMsg "&g" & MyCStr(Mid(zPromptOriginal, 1, 10) & " huh?"), zPortID
                        End If
                End Select
                'Check AFK and VOID status
                If (gbliPortStatus(MyCLng(zPortID)) <> 0) And (zWord(1) <> "AFK") Then subSetAFKMode zPortID
            Else
                subSendMsg "&gEhh?", zPortID
            End If
        Else
            gbllInterrupt(lPortID) = False
            Select Case lRandom(3)
                Case 1
                    subSendMsg "&ROops! You were interrupted!", zPortID
                Case 2
                    subSendMsg "&ROops! Some sneaky person interrupted you!", zPortID
                Case 3
                    subSendMsg "&ROops! Something interrupted that command!", zPortID
            End Select
        End If
        gblzTelnetRepeatCommand(lPortID) = zPromptOriginal
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subProcessUserLine," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subOldMethodProcess(zPromptOriginal As String, zPortID As String, zUserData As String)
    Dim rsData As Recordset
    Dim rsPlayer As Recordset
    Dim zWord(5) As String 'We dont bother with handling more than 5 key words and one original prompt copy.
    Dim zPromptMessage As String
    
    'OLD STYLE -    This is the old style because I simply grabbed all variables from tblPlayer and loaded them all
    '               The below variables need to be placed back up into subProcessUserLine(zPortID As String, zUserData As String)
    '               Some commands need to check if the player is able to run the commands, the following onces prevent some Player Commands from running till the duration is 0, these are:
    '                   lStatus = 0 (0 = standing)
    '                   lStunDuration = 0 (0 = not stunned)
    '                   lSleepDuration = 0 (0 = not under a sleep spell)
    '                   lPlayerFleeDuration = 0 (0 = no longer scared)
    '
    '               Then move the onces below back up into subProcessUserLine(zPortID As String, zUserData As String) and should only pass zPortID and maybe zWord1-5 and/or zPromptOriginal
    '               I have already moved all the ones that are used most often to help with the data grab lag issue
    Dim zPlayerName As String
    Dim lMagicFind As Long
    Dim lPlayerID As Long
    Dim lImmortalLevel As Long
    Dim lFPlayerGroupStatus As Long
    Dim zRace As String
    Dim zClass As String
    Dim bImmortalRadius As Boolean
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lPlayerLevel As Long
    Dim lStatus As Long
    Dim lAreaTrapDuration As Long
    Dim zGender As String
    Dim lDrunkLevel As Long
    Dim lDrunkDuration As Long
    Dim lStunDuration As Long
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim lMobWorkID As Long
    Dim lEntanglementDuration As Long
    Dim lWeight As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lColorAreaDesc As Long
    Dim zConfig As String
    Dim lCHITROLL As Long
    Dim lCDAMROLL As Long
    Dim lEdibleWeightEaten As Long
    Dim lDrinkableWeightEaten As Long
    Dim lCAC As Long
    Dim iImmortalSupervisor As Integer
    Dim lWhereID As Long
    Dim lLightRadius As Long
    Dim lBlindDuration As Long
    Dim lRecallX As Long
    Dim lRecallY As Long
    Dim lRecallZ As Long
    Dim lLightDuration As Long
    Dim lHallucinate As Long
    Dim lShadowCloakDuration As Long
    Dim lLearnPoints As Long
    Dim lDisarmInterruption As Long
    Dim lLockPickToolBonus As Long
    Dim lStunInterruption As Long
    Dim lCMana As Long
    Dim lCEssence As Long
    Dim lCSoul As Long
    Dim lCMove As Long
    Dim lTurnedIntoAnimalType As Long
    
    Dim lOMANA As Long
    Dim lOEssence As Long
    Dim lOSoul As Long
    Dim lOMove As Long
    Dim lGrip As Long
    Dim lCHP As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lCDEX As Long
    Dim lCCon As Long
    Dim lCCHA As Long
    Dim lCLuc As Long
    Dim lGold As Long
    Dim lOHP As Long
    Dim lOStr As Long
    Dim lOInt As Long
    Dim lOWIS As Long
    Dim lODEX As Long
    Dim lOCON As Long
    Dim lOCHA As Long
    Dim lOLuc As Long
    Dim zTitle As String
    Dim lKnowAlignmentDuration As Long
    Dim lWeaponSkillMissileRangeClassLevel As Long
    Dim zLanguagesKnown As String
    Dim lSleepSpellInterruption As Long
    Dim lHeight As Long
    Dim lFPlayerID As Long
    Dim lMissileTargetID As Long
    Dim lMissileStatus As Long
    Dim lInvisibilityDuration As Long
    Dim zPassword As String
    Dim lDisarmedDuration As Long
    Dim iDuelWield As Integer
    Dim lCrown As Long
    Dim lAlignment As Long
    Dim lClanMemberLevel As Long
    Dim lClanID As Long
    Dim lFireballInterruption As Long
    Dim lReloadPenalty As Long
    Dim lMagicFindBase As Long
    Dim lSlayChance As Long
    Dim lIASChance As Long
    Dim lNumAttRnd As Long
    Dim lFireshieldDuration As Long
    Dim lIceshieldDuration As Long
    Dim lChaosshieldDuration As Long
    Dim lStaticshieldDuration As Long
    Dim lSanctuaryDuration As Long
    Dim lSilencedGlobal As Long
    Dim lSilencedRoom As Long
    Dim bNukeAllowed As Boolean
    Dim bRebootAllowed As Boolean
    Dim zFlyExitMsg As String
    Dim zWalkExitMsg As String
    Dim zFlyEnterMsg As String
    Dim zWalkEnterMsg As String
    Dim lRolePlayID As Long
    Dim lRolePlayLevel As Long
    Dim lAreaTrapID As Long
    Dim lSneakingMovesLeft As Long
    Dim lFlyDuration As Long
    Dim lStarshipCommandDelay As Long
    Dim bBlackMarket As Boolean
    Dim bBlackMarketSpot As Boolean
    
    'Port Controls
    Dim lPortID As Long
    Dim bInterrupt As Boolean
    
    'MASSIVE DATA GRAB - yuck - only ever take what you need
    Set rsPlayer = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lHallucinate = MyCLng(rsPlayer!Hallucinate)
        lRolePlayID = MyCLng(rsPlayer!RolePlayID)
        lRolePlayLevel = MyCLng(rsPlayer!RolePlayLevel)
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        lSneakingMovesLeft = MyCLng(rsPlayer!SneakingMovesLeft)
        
        lHeight = MyCLng(rsPlayer!Height)
        lClanID = MyCLng(rsPlayer!ClanID)
        lFlyDuration = MyCLng(rsPlayer!FlyDuration)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        
        zFlyExitMsg = MyCStr(rsPlayer!FlyExitMsg)
        zWalkExitMsg = MyCStr(rsPlayer!WalkExitMsg)
        zFlyEnterMsg = MyCStr(rsPlayer!FlyEnterMsg)
        zWalkEnterMsg = MyCStr(rsPlayer!WalkEnterMsg)
        
        zClass = MyCStr(rsPlayer!Class)
        zRace = MyCStr(rsPlayer!Race)
        lMagicFind = MyCLng(rsPlayer!MagicFind)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lStatus = MyCLng(rsPlayer!Status)
        lAreaTrapID = MyCLng(rsPlayer!AreaTrapID)
        lEdibleWeightEaten = MyCLng(rsPlayer!EdibleWeightEaten)
        lDrinkableWeightEaten = MyCLng(rsPlayer!DrinkableWeightEaten)
        lAreaTrapDuration = MyCLng(rsPlayer!AreaTrapDuration)
        zGender = MyCStr(rsPlayer!Gender)
        lDrunkLevel = MyCLng(rsPlayer!DrunkLevel)
        lDrunkDuration = MyCLng(rsPlayer!DrunkDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lPlayerFleeDuration = MyCLng(rsPlayer!PlayerFleeDuration)
        lMobWorkID = MyCLng(rsPlayer!MobWorkID)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        lNumAttRnd = MyCLng(rsPlayer!NumAttRnd)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        lCCon = MyCLng(rsPlayer!CCon)
        lCHP = MyCLng(rsPlayer!CHP)
        lOHP = MyCLng(rsPlayer!OHP)
        lGold = MyCLng(rsPlayer!Gold)
        lWeight = MyCLng(rsPlayer!Weight)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        lFPlayerGroupStatus = MyCLng(rsPlayer!FPlayerGroupStatus)
        lColorAreaDesc = MyCLng(rsPlayer!ColorAreaDesc)
        zConfig = MyCStr(rsPlayer!Config)
        lCHITROLL = MyCLng(rsPlayer!CHITROLL)
        lCDAMROLL = MyCLng(rsPlayer!CDAMROLL)
        lCAC = MyCLng(rsPlayer!CAC)
        iImmortalSupervisor = MyCInt(rsPlayer!ImmortalSupervisor)
        lWhereID = MyCLng(rsPlayer!WhereID)
        lLightRadius = MyCLng(rsPlayer!LightRadius)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lRecallX = MyCLng(rsPlayer!RecallX)
        lRecallY = MyCLng(rsPlayer!RecallY)
        lRecallZ = MyCLng(rsPlayer!RecallZ)
        lSilencedGlobal = MyCLng(rsPlayer!SilencedGlobal)
        lSilencedRoom = MyCLng(rsPlayer!SilencedRoom)
        lLightDuration = MyCLng(rsPlayer!LightDuration)
        lClanID = MyCLng(rsPlayer!ClanID)
        lClanMemberLevel = MyCLng(rsPlayer!ClanMemberLevel)
        lShadowCloakDuration = MyCLng(rsPlayer!ShadowCloakDuration)
        lLearnPoints = MyCLng(rsPlayer!LearnPoints)
        lSlayChance = MyCLng(rsPlayer!SlayChance)
        lIASChance = MyCLng(rsPlayer!IASChance)
        lGrip = MyCLng(rsPlayer!Grip)
        lMagicFind = MyCLng(rsPlayer!MagicFind)
        lMagicFindBase = MyCLng(rsPlayer!MagicFindBase)
        lCMana = MyCLng(rsPlayer!CMana)
        lCEssence = MyCLng(rsPlayer!CEssence)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lCMove = MyCLng(rsPlayer!CMove)
        lFireshieldDuration = MyCLng(rsPlayer!FireshieldDuration)
        lIceshieldDuration = MyCLng(rsPlayer!IceshieldDuration)
        lChaosshieldDuration = MyCLng(rsPlayer!ChaosshieldDuration)
        lStaticshieldDuration = MyCLng(rsPlayer!StaticshieldDuration)
        lSanctuaryDuration = MyCLng(rsPlayer!SanctuaryDuration)
        lOMANA = MyCLng(rsPlayer!OMANA)
        lOEssence = MyCLng(rsPlayer!OEssence)
        lOSoul = MyCLng(rsPlayer!OSoul)
        lOMove = MyCLng(rsPlayer!OMove)
        
        lCStr = MyCLng(rsPlayer!CStr)
        lCINT = MyCLng(rsPlayer!CInt)
        lCWIS = MyCLng(rsPlayer!CWIS)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCCon = MyCLng(rsPlayer!CCon)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lCLuc = MyCLng(rsPlayer!CLuc)
        
        lOStr = MyCLng(rsPlayer!OSTR)
        lOInt = MyCLng(rsPlayer!OINT)
        lOWIS = MyCLng(rsPlayer!OWIS)
        lODEX = MyCLng(rsPlayer!ODEX)
        lOCON = MyCLng(rsPlayer!OCON)
        lOCHA = MyCLng(rsPlayer!OCHA)
        lOLuc = MyCLng(rsPlayer!OLUC)
        
        zLanguagesKnown = MyCStr(rsPlayer!LanguagesKnown)
        
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        zPassword = MyCStr(rsPlayer!Password)
        
        lDisarmedDuration = MyCLng(rsPlayer!DisarmedDuration)
        iDuelWield = MyCInt(rsPlayer!DuelWield)
        
        lAlignment = MyCLng(rsPlayer!Alignment)
        lFPlayerID = MyCLng(rsPlayer!FPlayerID)
        lHeight = MyCLng(rsPlayer!Height)
        lKnowAlignmentDuration = MyCLng(rsPlayer!KnowAlignmentDuration)
        lLockPickToolBonus = MyCLng(rsPlayer!LockPickToolBonus)
        lDisarmInterruption = MyCLng(rsPlayer!DisarmInterruption)
        lStunInterruption = MyCLng(rsPlayer!StunInterruption)
        zTitle = MyCStr(rsPlayer!Title)
        lCrown = MyCLng(rsPlayer!Crown)
        lMissileTargetID = MyCLng(rsPlayer!MissileTargetID)
        lMissileStatus = MyCLng(rsPlayer!MissileStatus)
        lWeaponSkillMissileRangeClassLevel = MyCLng(rsPlayer!WeaponSkillMissileRangeClassLevel)
        lFireballInterruption = MyCLng(rsPlayer!FireballInterruption)
        lSleepSpellInterruption = MyCLng(rsPlayer!SleepSpellInterruption)
        lReloadPenalty = MyCLng(rsPlayer!ReloadPenalty)
        bNukeAllowed = MyCInt(rsPlayer!NukeAllowed)
        bRebootAllowed = MyCInt(rsPlayer!RebootAllowed)
        lStarshipCommandDelay = MyCLng(rsPlayer!StarshipCommandDelay)
    End If
    Set rsPlayer = Nothing
    
    gblbIgnoreSpamWarning = False
    
    'subTitleBar "", zPortID
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'we make sure the port is of a legal range
        bInterrupt = gbllInterrupt(lPortID)
        If (Not bInterrupt) Then 'Interrupt is a knight skill
            subParser MyCStr(zUserData), zPromptOriginal, zWord(1), zWord(2), zWord(3), zWord(4), zWord(5), zPortID
            'READ ME IMPORTANT!!! Once the CASE ELSE below is obsolete this entire case statement can be removed - what I was doing here is making it so that the SQL engine didnt have to grab everything it needed and to do a look up for each command by zPortID only - you can remove all the variables after as well - I got most of it done
            Select Case Mid(zWord(1), 1, 4) 'this will run slicker im slowly moving everything from the 2nd below case statement up to here
                Case "AREA"
                    subAreaArchitectureWhereList zPromptOriginal, zPortID, lX, lY, lZ, lPlayerLevel, lImmortalLevel
                Case "TALK", "ASK", "SAYT"
                    subMobQuestSystem zPortID, zPlayerName, zWord(2), zWord(3), lX, lY, lZ, lPlayerID, lStatus
                Case "BID" 'auction bid
                    subAuctionBid zWord(2), zPortID, lPlayerID, lGold, lStatus
                Case "AUCT" 'this is a global auction
                    subAuction zWord(2), zWord(3), zPortID, lPlayerID, lStatus
                Case "PDES", "DESC"
                    If (lPlayerLevel >= 9) Then 'Level to use
                        subPlayerDesc zPromptOriginal, "D", zPortID, lImmortalLevel
                    Else
                        subSendMsg "&wIL9: PLAYER DESCRIPTION", zPortID
                    End If
                Case "PTIT", "TITL"
                    If (lPlayerLevel >= 5) Then 'Level to use
                        subPlayerDesc zPromptOriginal, "T", zPortID, lImmortalLevel
                    Else
                        subSendMsg "&wPLAYER TITLE - you must be level five or higher to perform that command.", zPortID
                    End If
                Case "USE", "UNLO"
                    If (lStatus <> 50) Then
                        If (Len(zWord(3)) > 0) Then
                            Select Case MyCStr(Mid(UCase(zWord(2)), 1, 3))
                                Case "LEV", "KNO", "BUT" 'USE LEVER or KNOB or BUTTON in room
                                    subDoorLever zPortID, zPlayerName, zWord(3), lX, lY, lZ, lPlayerID, lInvisibilityDuration
                                Case "KEY", "PIC" 'keyring keys pick lock key
                                    subDoorUseKey zPortID, zPlayerName, zWord(3), lX, lY, lZ, lPlayerID, MyCStr(Mid(UCase(zWord(2)), 1, 4)), lLockPickToolBonus, lPlayerLevel, zClass, lCDEX, lCSoul, lCMove, lInvisibilityDuration, lCCHA
                                Case "COM"
                                    subObjectUseCombo zPortID, zPlayerName, zWord(3), zWord(4), lX, lY, lZ, lPlayerID
                                Case Else
                                    subSendMsg "&GUse what?", zPortID
                            End Select
                        Else
                            subSendMsg "&GCOMMAND: USE LEVER (lever name)" & vbCrLf & "         USE KNOB (knob name)" & vbCrLf & "         USE KEY (direction)" & vbCrLf & "         USE Combination (object name) (combination code)" & vbCrLf & "         USE PICK (direction)", zPortID
                        End If
                    Else
                        subSendMsg "&GYou dream of doing stuff.", zPortID
                    End If
                Case "DAMA", "DMG", "DAMG", "DMAG", "DMGA"
                    If (gblbClientMode(lPortID)) Then
                    Select Case Mid(zWord(2), 1, 4)
                        Case "", "TREE"
                            subPlayerSpellHealDamageTree lPlayerLevel, zRace, zClass, "<::=-DAMAGE TREE-=::>", 0, zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSpellHealDamageTree lPlayerLevel, Mid(zWord(3), 1, 3), Mid(zWord(2), 1, 2), "<::=-DAMAGE TREE-=::>", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                    Else
                    Select Case Mid(zWord(2), 1, 4)
                        Case "", "TREE"
                            subPlayerSpellHealDamageTree lPlayerLevel, zRace, zClass, "DAMAGE TREE", 0, zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSpellHealDamageTree lPlayerLevel, Mid(zWord(3), 1, 3), Mid(zWord(2), 1, 2), "DAMAGE TREE", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                    End If
                Case "COST" 'Learn Points get traded for a better skill in a weapon type or something unique.
                    If (gblbClientMode(lPortID)) Then
                    Select Case Mid(zWord(2), 1, 4)
                        Case "", "TREE" '
                            subPlayerSkillsCostTree lPlayerLevel, zRace, zClass, "<::=-COST TREE-=::>", 0, zPortID
                            subSendMsg "&wNOTE: LEARN SPELLNAME5   - to learn 5 percent at a time." & vbCrLf & "Use PRACTICE to see what you have already learnt." & vbCrLf & "Use LEARN TREE to see what other spells and skills you can learn." & vbCrLf & "See Also: SLIST", zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSkillsCostTree lPlayerLevel, Mid(zWord(3), 1, 3), Mid(zWord(2), 1, 2), "<::=-COST TREE-=::>", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                    Else
                    Select Case Mid(zWord(2), 1, 4)
                        Case "", "TREE" '
                            subPlayerSkillsCostTree lPlayerLevel, zRace, zClass, "COST TREE", 0, zPortID
                            subSendMsg "&wNOTE: LEARN SPELLNAME5   - to learn 5 percent at a time." & vbCrLf & "Use PRACTICE to see what you have already learnt." & vbCrLf & "Use LEARN TREE to see what other spells and skills you can learn." & vbCrLf & "See Also: SLIST", zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSkillsCostTree lPlayerLevel, Mid(zWord(3), 1, 3), Mid(zWord(2), 1, 2), "COST TREE", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                    End If
                Case "TRAC", "PATH" 'Track
                    If (lPlayerLevel >= 30) Then 'Level to use
                        zPromptMessage = basRemoveChr1310(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1))
                        If (Len(zPromptMessage) <> 0) Then
                            subMobArchitecturePath zPortID, zPlayerName, lX, lY, lZ, lImmortalLevel, zPromptMessage, "ALL"
                            If (lImmortalLevel >= 10) Then 'Level to use
                                subAreaArchitectureTransit zPortID, lX, lY, lZ, "ALL"
                            End If
                        Else
                            subSendMsg "&GCOMMAND: TRACK (full mobile name)", zPortID
                        End If
                    Else
                        subSendMsg gblzFBCYA & "PL30: You can track at level 30.", zPortID
                    End If
                Case "TRAI" 'Train mob TRAIN (mobname one word use) DISBAND
                    subPlayerSkillsTrain zPlayerName, lPlayerID, lX, lY, lZ, zPortID, UCase(MyCStr(zWord(2))), UCase(MyCStr(zWord(3))), lPlayerLevel, zClass, lStatus
                Case "DECL", "MORT", "DENY" 'see this one needs to be done yet the SQL here should be in a subProcedure or function
                    If (lImmortalLevel + iImmortalSupervisor > 0) Then
                        MyDB.Execute "UPDATE tblPlayer SET ImmortalLevel=0, ImmortalSupervisor=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        subSendMsg "&gWelcome mortal!", zPortID
                    Else
                        subSendMsg "&gHuh, wha?! No! Yes? Try Again???", zPortID
                    End If
                Case "REPA"
                    If (bWhenIsIt("", False) Or lPlayerLevel < 10) Then
                        subRepairDurability zPortID, lPlayerID, lX, lY, lZ, zWord(2), lCCHA, lStatus
                    Else
                        subSendMsg "&BThe shops are closed at night.", zPortID
                    End If
                Case "MURD" 'murder player
                    If (Len(zWord(2)) > 0) Then
                        subPlayerVsPlayerCombatSetUp lCCHA, lDetectInvisibilityDuration, zPortID, zWord(2), lX, lY, lZ, lPlayerID, zPlayerName, zGender, True, zRace, lStatus, lPlayerLevel, lTurnedIntoAnimalType
                    Else
                        subSendMsg "&GCOMMAND: MURDER (player name)", zPortID
                    End If
                Case "CON", "CONS"
                    If (UCase(zWord(2)) = UCase(zPlayerName) Or (UCase(zWord(2)) = "SELF")) Then
                        subSendMsg "&gYou are a perfect match for yourself!", zPortID
                    Else
                        subConsiderTarget zPortID, lPlayerLevel, lCHITROLL, lCAC, zWord(2), lX, lY, lZ, lStatus, lDetectInvisibilityDuration, 0
                    End If
                Case "IGNO" 'ignore player - this will also unflag ignore
                    If (UCase(zWord(2)) = "LIST" Or UCase(zWord(2)) = "BOOK") Then
                        subPlayerIgnoredCommandList zPortID
                    Else
                        subPlayerIgnoredCommand lPlayerID, zWord(2), zPortID
                    End If
                Case "GUES", "SCRA"
                    subGuessTheWordGame zPortID, zWord(2), zPlayerName, lImmortalLevel, lLearnPoints
                    If (lImmortalLevel > 97) Then
                        subSendMsg "&r(EYE) IL98+&W Current word answer is -" & gblzSystemGuessWord & "- the scrambled question is -" & gblzSystemGuessWordScrambled & "-", zPortID
                        If (Len(gblzSystemGuessWord) = 0 And Len(MyCStr(zWord(2))) > 4) Then
                            gblzSystemGuessWord = MyCStr(UCase(zWord(2)))
                            subSendMsg "&WYou set up Guess the Word game! The word is: " & gblzSystemGuessWord & vbCrLf & "You can cancel the quest with IMMO GUESS.", zPortID
                            subSendMsg "&WThe Guess word has been used " & lGuessWordCountAdd(gblzSystemGuessWord) + 1 & ".", zPortID
                            Select Case lRandom(5)
                                Case 1, 2, 3
                                    gbliSystemGuessWordBonusGlory = lRandom(3)
                                Case Else
                                    gbliSystemGuessWordBonusGlory = 0
                            End Select
                            gblzSystemGuessWordScrambled = zScramble(gblzSystemGuessWord, gbliSystemGuessWordBonusGlory)
                            Select Case (gbliSystemGuessWordBonusGlory) 'select a message
                                Case 0
                                    subSimpleQuestChannel "&yUse the GUESS command and unscramble the word(" & Len(gblzSystemGuessWord) & ") " & gblzSystemGuessWordScrambled & "!"
                                Case 1
                                    subSimpleQuestChannel "&yUse the GUESS command and unscramble the word(" & Len(gblzSystemGuessWord) & ") " & gblzSystemGuessWordScrambled & "!" & vbCrLf & "&a*1* Bonus Glory!" & vbCrLf & "There is one extra letter that cannot be used."
                                Case Else
                                    subSimpleQuestChannel "&yUse the GUESS command and unscramble the word(" & Len(gblzSystemGuessWord) & ") " & gblzSystemGuessWordScrambled & "!" & vbCrLf & "&a*" & gbliSystemGuessWordBonusGlory & "* Bonus Glory!" & vbCrLf & "There are " & gbliSystemGuessWordBonusGlory & " extra letters that cannot be used."
                            End Select
                        Else
                            subSendMsg "&GImmortals can: GUESS REALWORD will set up the word scramble game." & vbCrLf & "The RealWord must be at least 5 characters long. IMMO GUESS - will cancel the game.", zPortID
                        End If
                    End If
                Case "GI", "GIV", "GIVE"
                    If (lStatus <> 50) Then
                        If (Len(zWord(2)) <> 0) Then
                            If (Len(zWord(4)) > 3 And zWord(3) = "GOLD") Then
                                'If (lInvisibilityDuration = 0) Then
                                    'We are giving gold to another player
                                    If (lPlayerLevel > 19) Then
                                        If (Not bPartOfAuction(zPortID, lPlayerID)) Then
                                            subPlayerGiveCoins zPortID, MyCLng(zWord(2)), zWord(4)
                                        Else
                                            subSendMsg "&RYou are apart of an auction, it is only honourable you conserve your gold for now.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are able to give gold to players once you are over level 20.", zPortID
                                    End If
                                'Else
                                    'subSendMsg "&gToo much movement would break your invisibility.", zPortID
                                'End If
                            Else
                                If (Len(zWord(3)) > 0) Then
                                    subPlayerGiveObject zPortID, lPlayerLevel, zPlayerName, lPlayerID, lX, lY, lZ, zWord(2), zWord(3), zRace
                                Else
                                    subSendMsg "&GGIVE [objectname/amount] [GOLD] (player name)" & vbCrLf & "for example:" & vbCrLf & "&yGIVE &w500 &YGOLD&y &wTrisker" & vbCrLf & "&g*Note: Give command is multi-use:" & vbCrLf & "&wGIVE Sword Trisker", zPortID
                                End If
                            End If
                        Else
                            subSendMsg "&GGIVE [objectname/amount] [GOLD] (player name)" & vbCrLf & "for example:" & vbCrLf & "&yGIVE &w500 &YGOLD&y &wTrisker" & vbCrLf & "&g*Note: Give command is multi-use:" & vbCrLf & "&wGIVE Sword Trisker", zPortID
                        End If
                    Else
                        subSendMsg "&GYou are asleep you cannot move.", zPortID
                    End If
                Case "OPEN"
                    subDoorOpen zPortID, zPlayerName, zWord(2), lX, lY, lZ, lPlayerID, lStatus
                Case "CLOS"
                    subDoorClose zPortID, zPlayerName, zWord(2), lX, lY, lZ, lPlayerID, lStatus
                Case "FO", "FOL", "FOLL", "STOP"
                    subFollowPlayer zPortID, lPlayerID, lFPlayerID, lX, lY, lZ, zPlayerName, zWord(2)
                Case "DISB"
                    subGroupRemoveMember zPortID, lPlayerID, lFPlayerID, lX, lY, lZ, zPlayerName, zWord(2)
                Case "GR", "GRO", "GROU", "FORM"
                    If (Len(zWord(2)) <> 0) Then
                        subGroupFollowingPlayer zPortID, lPlayerID, lFPlayerID, lX, lY, lZ, zPlayerName, zWord(2)
                    Else
                        subSendMsg zPlayerGroupList(zPlayerName, lPlayerID, lFPlayerID), zPortID
                    End If
                Case "GT", "GRPT", "GTAL", ";"
                    If (Len(zWord(2)) <> 0) Then
                        If (lFPlayerGroupStatus > 0) Then
                            zPromptMessage = zCleanChatMessage(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1, 255))
                            subGroupTalk zPortID, zPlayerName, lPlayerID, lFPlayerGroupStatus, lFPlayerID, zWord(2), zPromptMessage
                        Else
                            subSendMsg "&gYou are the only grouped person in your party.", zPortID
                        End If
                    Else
                        subSendMsg "&GSyntax: GT (message)" & vbCrLf & "&gSee also, GROUP and DISBAND", zPortID
                    End If
                Case "IMMO"
                    subImmortalCommand zPortID, zWord(2), zWord(3), zWord(4), zWord(5), Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1), lImmortalLevel, zPlayerName, lPlayerID, lPlayerLevel, zTitle, lX, lY, lZ, lCrown, lLightRadius, lWhereID, zClass, lBlindDuration, lLightDuration, bRebootAllowed
                Case "DONA" 'donate an item to the weapon type
                    subDonateObject zPortID, zPlayerName, lPlayerID, lX, lY, lZ, zWord(2), lStatus
                Case "ST", "STA", "STAN"
                    subCheckFishingSittingStatus zPortID
                    If (bClassCanStance(zClass)) Then
                        Select Case zWord(1)
                            Case "ST", "STAND"
                                subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 5, zPortID, lStatus, True, lInvisibilityDuration
                            Case "STA", "STAN", "STANCE", "STANC"
                                subPlayerStance zWord(2), zPortID
                        End Select
                    Else
                        subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 5, zPortID, lStatus, True, lInvisibilityDuration
                    End If
                Case "RELA"
                    subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 10, zPortID, lStatus, True, lInvisibilityDuration
                Case "REST"
                    subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 15, zPortID, lStatus, True, lInvisibilityDuration
                Case "DISM", "UNMO" 'dismount/unmount
                    subPlayerPositionUnMount zPlayerName, lPlayerID, lX, lY, lZ, zPortID, lStatus
                Case "MOUN", "RIDE" 'mount/ride a pet
                    If (Len(zWord(2)) > 0) Then
                        subPlayerPositionMountPet lPlayerID, zPlayerName, lX, lY, lZ, zWord(2), zPortID, lStatus, lInvisibilityDuration
                    Else
                        subPlayerPositionUnMount zPlayerName, lPlayerID, lX, lY, lZ, zPortID, lStatus
                    End If
                Case "SIT"
                    If (Len(zWord(2)) > 0) Then
                        subPlayerPositionSitObject lPlayerID, zPlayerName, lX, lY, lZ, zWord(2), zPortID, lStatus, lInvisibilityDuration
                    Else
                        subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 20, zPortID, lStatus, True, lInvisibilityDuration
                    End If
                Case "WA", "WAK", "WAKE"
                    subWAKE zWord(2), lX, lY, lZ, lPlayerID, zPortID, zPlayerName, lStatus, lInvisibilityDuration, lDetectInvisibilityDuration
                Case "SL", "SLE", "SLEE", "NAP", "BED"
                    If (rSCombat(MyCLng(zPortID)).iStatus = cstiStatusNotInBattleMode) Then
                        subPlayerPosition lPlayerID, zPlayerName, lX, lY, lZ, 50, zPortID, lStatus, True, lInvisibilityDuration
                    Else
                        subSendMsg "&gYou cannot do that while you are fighting! [try to FLEE]", zPortID
                    End If
                Case "BANK", "BNK"
                    If (bWhenIsIt("", False) Or lPlayerLevel < 20) Then
                        subBanking zPortID, zPlayerName, lPlayerID, zWord(3), lGold, lX, lY, lZ, zWord(2), lStatus
                    Else
                        subSendMsg "&BThe banks are closed at night.", zPortID
                    End If
                Case "IDM", "MID" 'identify Mob, Mob Identify
                    If (lImmortalLevel >= 1 Or bImmortalPlayerWithInRadius(lPlayerID, lX, lY, lZ)) Then 'Level to use
                        subIdentifyMob lMobWorkID, zPortID
                    Else
                        subSendMsg "&gHuh?", zPortID
                    End If
                Case "MFOR", "EDIT" 'mob forge - mob edit - edit 10 bonusac - medit or tag
                    bImmortalRadius = bImmortalPlayerWithInRadius(lPlayerID, lX, lY, lZ)
                    If (bImmortalRadius) Then lImmortalLevel = 100
                    
                    If (lImmortalLevel >= 89) Then
                        subForgeMob zPlayerName, zRace, lPlayerID, lImmortalLevel, zWord(2), zWord(3), zPromptOriginal, lX, lY, lZ, zPortID, bImmortalRadius
                    Else
                        subSendMsg "&gHuh?", zPortID
                    End If
                Case "DISP"
                    If (lImmortalLevel > 0) Then
                        gblbImmortalWHODisplayed(lPortID) = Not gblbImmortalWHODisplayed(lPortID)
                        Select Case gblbImmortalWHODisplayed(lPortID)
                            Case True
                                subSendMsg "&WYou will be displayed in the who list.", lX, lY, lZ, zPortID
                            Case Else
                                subSendMsg "&wYou will NOT be displayed in the who list.", lX, lY, lZ, zPortID
                        End Select
                    Else
                        subSendMsg "&gHuh?", lX, lY, lZ, zPortID
                    End If
                Case "DIG", "FIND", "UNBU" 'unbury and dig
                    subDigFind lX, lY, lZ, zPortID, lPlayerID, zPlayerName, lStatus, lCMove
                Case "BURY" 'bury object
                    subBury lX, lY, lZ, zWord(2), zPortID, lPlayerID, zPlayerName, lStatus, lCMove
                Case "VOTE", "POLL"
                    subVOTE zPlayerName, zPromptOriginal, lClanMemberLevel, zWord(2), zPortID
                Case "CANC"
                    subCancelQuest lPlayerID, zPortID
                Case "PASS" 'change password
                    subChangePassword zPortID, lPlayerID, MyCStr(zWord(2))
                Case "UNKE", "UNMA" 'unmark or unkeep
                    If (zWord(2) <> "") Then
                        subSendMsg "&gYou can only unkeep everything in your inventory, not specific items.", zPortID
                    Else
                        MyDB.Execute "UPDATE tblPlayerInventoryItems INNER JOIN tblObject ON tblPlayerInventoryItems.ObjectID = tblObject.ObjectID SET tblObject.CanSellItem = True WHERE (((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.CaptureFlagClanID)=0));", dbFailOnError
                        subSendMsg "&AEverything in your inventory can now be sold. Worn items were ignored.", zPortID
                    End If
                Case "KEEP" 'keep
                    If (zWord(2) <> "") Then
                        subSendMsg "&gYou can only keep everything you are wearing, not specific items.", zPortID
                    Else
                        MyDB.Execute "UPDATE tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID SET tblObject.CanSellItem = False WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.CaptureFlagClanID)=0));", dbFailOnError
                        subSendMsg "&WAll your worn equipment is now marked so that it cannot be sold from your inventory.", zPortID
                    End If
                Case "INDU"
                    If (lClanMemberLevel > 6 Or lImmortalLevel > 0) Then 'only officers can rank, majors generals advisors and leaders and most immortals can induct
                        If (lStatus = 5) Then
                            If ((Len(zWord(2)) > 0 And Len(zWord(3)) > 0)) Then
                                subInductionSetClanMemberLevel MyCStr(zWord(2)), zWord(3), lClanID, zPortID, lClanMemberLevel, lPlayerID, lImmortalLevel, zPlayerName
                            Else
                                subSendMsg "&GOfficers only: INDUCT (player name) (rank number)" & vbCrLf & "Rank Numbers:", zPortID
                                subSendMsg "&g 0 = remove a clannie from your clan." & vbCrLf & " 1 = " & zTranslateMortalClanRanks(1) & vbCrLf & " 2 = " & zTranslateMortalClanRanks(2) & vbCrLf & " 3 = " & zTranslateMortalClanRanks(3) & vbCrLf & " 4 = " & zTranslateMortalClanRanks(4) & vbCrLf & " 5 = " & zTranslateMortalClanRanks(5) & vbCrLf & " 6 = " & zTranslateMortalClanRanks(6) & vbCrLf & " 7 = " & zTranslateMortalClanRanks(7) & vbCrLf & " 8 = " & zTranslateMortalClanRanks(8) & vbCrLf & _
                                    " 9 = " & zTranslateMortalClanRanks(9) & vbCrLf & "10 = " & zTranslateMortalClanRanks(10) & vbCrLf & "11 = " & zTranslateMortalClanRanks(11) & vbCrLf & "12 = " & zTranslateMortalClanRanks(12) & vbCrLf & "13 = " & zTranslateMortalClanRanks(13) & vbCrLf & "14 = " & zTranslateMortalClanRanks(14) & vbCrLf & "15 = " & zTranslateMortalClanRanks(15) & vbCrLf & "16 = " & zTranslateMortalClanRanks(16) & vbCrLf & "17 = " & zTranslateMortalClanRanks(17) & vbCrLf & "18 = " & zTranslateMortalClanRanks(18), zPortID
                            End If
                        Else
                            subSendMsg "&GYou need to stand up to use your induct command.", zPortID
                        End If
                    Else
                        subSendMsg "&gOnly Officers of a clan may induct.", zPortID
                    End If
                Case "COLO"
                    subColourPallets lPlayerID, zWord(2), MyCLng(zWord(3)), zPortID
                Case "CONF" 'config type +/-
                    subPlayerConfig zWord(2), zWord(3), lPlayerID, zPortID
                Case "RELO", "POWE"
                    subSkillReloadRemoveWear zPlayerName, lPlayerID, lReloadPenalty, zPortID, zGender, lX, lY, lZ, lStatus, lInvisibilityDuration
                Case "MERG" 'merging cards, see also: absorb
                    subGambleMergeCards lPlayerID, zWord(2), zWord(3), zPortID, zPlayerName, lX, lY, lZ, lStatus
                Case "PEMO", "PETE" 'pet emote
                    If (lStatus <> 50) Then
                        If (Not bChartEmotePet(zPlayerName, zWord(2), zWord(3), zWord(4), lX, lY, lZ, zPortID, lPlayerID)) Then
                            If (Len(zPromptOriginal) > 0) Then subSendMsg "&RYou are too scared to do much right now!", zPortID
                        End If
                    Else
                        subSendMsg "&GYou are asleep you cannot move.", zPortID
                    End If
                Case "BOUN"
                    subQuestBounty zPlayerName, zPortID, lX, lY, lZ
            End Select
        End If
    End If
End Sub
