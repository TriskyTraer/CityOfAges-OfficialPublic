VERSION 5.00
Begin VB.Form frmAsciiArt 
   Caption         =   "A S C I I  A R T"
   ClientHeight    =   6315
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   10230
   Icon            =   "frmAsciiArtForm.frx":0000
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   6315
   ScaleWidth      =   10230
   Begin VB.Frame picbSaving 
      Appearance      =   0  'Flat
      BackColor       =   &H00C0FFC0&
      Caption         =   "SAVING...."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   24
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H80000008&
      Height          =   1095
      Left            =   120
      TabIndex        =   15
      Top             =   120
      Visible         =   0   'False
      Width           =   9975
   End
   Begin VB.TextBox txtSavePositionOver 
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   4680
      TabIndex        =   14
      TabStop         =   0   'False
      Text            =   "1"
      ToolTipText     =   "this will move the picture left to remove extra spacing, 1 is a normal save."
      Top             =   120
      Width           =   255
   End
   Begin VB.TextBox txtGloryPayOut 
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   2520
      TabIndex        =   13
      TabStop         =   0   'False
      ToolTipText     =   "Glory Pay Out value if system randomizes this portrait"
      Top             =   600
      Width           =   975
   End
   Begin VB.CommandButton cmdNEW 
      Caption         =   "*"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   7800
      TabIndex        =   12
      TabStop         =   0   'False
      ToolTipText     =   "go to a new record"
      Top             =   600
      Width           =   375
   End
   Begin VB.CommandButton cmdHelp 
      Caption         =   "?"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   13.5
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   8520
      TabIndex        =   11
      TabStop         =   0   'False
      ToolTipText     =   "quick help"
      Top             =   600
      Width           =   375
   End
   Begin VB.CommandButton cmdDelete 
      Caption         =   "&delete"
      Height          =   375
      Left            =   9000
      TabIndex        =   9
      TabStop         =   0   'False
      ToolTipText     =   "delete this record"
      Top             =   600
      Width           =   1095
   End
   Begin VB.CommandButton cmdTelnetDisplay 
      Caption         =   "&telnet display"
      Height          =   375
      Left            =   2520
      TabIndex        =   3
      Top             =   120
      Width           =   1095
   End
   Begin VB.CheckBox chkRndChoice 
      Caption         =   "Check to add as part of the random choice."
      Height          =   375
      Left            =   7800
      TabIndex        =   6
      Top             =   120
      Width           =   2175
   End
   Begin VB.TextBox txtTitle 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   120
      TabIndex        =   7
      ToolTipText     =   "search string and title (only letters allowed)"
      Top             =   600
      Width           =   2295
   End
   Begin VB.TextBox txtMainGroup 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      Height          =   375
      Left            =   4920
      TabIndex        =   5
      ToolTipText     =   "record to jump to"
      Top             =   120
      Width           =   1215
   End
   Begin VB.CommandButton cmdWrite 
      Caption         =   "&write"
      Height          =   375
      Left            =   3720
      TabIndex        =   4
      Top             =   120
      Width           =   975
   End
   Begin VB.CommandButton cmdPrevious 
      Caption         =   "&previous"
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   120
      Width           =   1095
   End
   Begin VB.CommandButton cmdNext 
      Caption         =   "&next"
      Height          =   375
      Left            =   1320
      TabIndex        =   2
      Top             =   120
      Width           =   1095
   End
   Begin VB.TextBox txtCanvass 
      Appearance      =   0  'Flat
      BackColor       =   &H00000000&
      BeginProperty Font 
         Name            =   "Courier New"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00FFFFFF&
      Height          =   5175
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   0
      ToolTipText     =   "canvass"
      Top             =   1080
      Width           =   9975
   End
   Begin VB.Label lblTotalRecords 
      Alignment       =   2  'Center
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   6240
      TabIndex        =   10
      ToolTipText     =   "total record count"
      Top             =   120
      Width           =   1215
   End
   Begin VB.Label lblArtMsg 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H80000008&
      Height          =   375
      Left            =   3600
      TabIndex        =   8
      ToolTipText     =   "messages box"
      Top             =   600
      Width           =   4095
   End
End
Attribute VB_Name = "frmAsciiArt"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub cmdDelete_Click()
On Error GoTo Err_Art
    Dim intMainGroup As Integer
    If (UCase(InputBox("Type POSITIVE to confirm the delete!", "~DELETE VERIFICATION~")) = "POSITIVE") Then
        intMainGroup = MyCInt(txtMainGroup.Text)
        MyDB.Execute "DELETE * FROM tblSystemAsciiPix WHERE MainGroup=" & intMainGroup & ";", dbFailOnError
        txtTitle.Text = ""
        txtCanvass.Text = ""
        txtGloryPayOut.Text = ""
        If (intMainGroup > 0 And intMainGroup < 60001) Then lblArtMsg.Caption = "Main Group " & MyCInt(txtMainGroup) & " was deleted!"
    End If
    Exit Sub
Err_Art:
    lblArtMsg.Caption = "Error trying to delete!"
End Sub

Private Sub Form_Activate()
    cmdResizemdiMainMenuForm
    frmAsciiArt.WindowState = vbMaximized
End Sub

Private Sub Form_Resize()
On Error Resume Next
    txtCanvass.Height = frmAsciiArt.Height - 1900
    txtCanvass.Width = frmAsciiArt.Width - 370
End Sub

Private Sub Form_Unload(Cancel As Integer)
    gblbAsciiFormActive = False
End Sub

Private Sub txtTitle_LostFocus()
On Error Resume Next
    txtTitle.Text = zKeepLettersOnly(txtTitle.Text)
End Sub
Private Sub subDisplayTotalRecordCount()
On Error Resume Next
    lblTotalRecords.Caption = lngSQLRecordCount("SELECT MainGroup FROM tblSystemAsciiPix GROUP BY MainGroup;")
End Sub
Private Sub cmdHelp_Click()
On Error Resume Next
    MsgBox "Use IMMO PICTURE to display a random ascii picture when logged into the realm." & vbCrLf & "    IMMO PICTURE [TITLENAME/VALUE] to select picture.", 64
End Sub
Private Sub cmdNEW_Click()
On Error Resume Next
    subDisplayTotalRecordCount
    lblTotalRecords.Caption = lngSQLRecordCount("SELECT MainGroup FROM tblSystemAsciiPix GROUP BY MainGroup;")
    txtMainGroup.Text = MyCInt(lblTotalRecords.Caption) + 1
    txtGloryPayOut.Text = "1"
    txtTitle.Text = ""
    txtCanvass.Text = ""
    chkRndChoice.Value = 1
    lblArtMsg.Caption = "NEW Main Group " & txtMainGroup.Text & " ready"
    txtTitle.SetFocus
End Sub
Private Sub cmdTelnetDisplay_Click()
    subPrintAnAsciiPicture False, MyCInt(txtMainGroup), ""
End Sub
Private Sub cmdNext_Click()
On Error GoTo Err_Art
    Dim rsArt As Recordset
    Dim intMainGroup As Integer
    subDisplayTotalRecordCount
    txtMainGroup.Text = MyCInt(txtMainGroup) + 1
    DoEvents
    intMainGroup = MyCInt(txtMainGroup)
    txtCanvass.Text = ""
    If (intMainGroup < 60001) Then
        Set rsArt = MyDB.OpenRecordset("SELECT * FROM tblSystemAsciiPix WHERE MainGroup=" & intMainGroup & " ORDER BY MainGroup, GroupOrder;", dbOpenSnapshot)
        If (Not rsArt.EOF) Then
            lblArtMsg.Caption = "Main Group " & intMainGroup & " WAS found!"
            txtMainGroup.Text = MyCInt(rsArt!MainGroup)
            txtTitle.Text = MyCStr(rsArt!SearchKeyTitle)
            txtGloryPayOut.Text = MyCInt(rsArt!GloryPayOut)
            Select Case (MyCInt(rsArt!RndChoice) <> 0)
                Case True
                    chkRndChoice.Value = 1
                Case False
                    chkRndChoice.Value = 0
            End Select
            Do While (Not rsArt.EOF)
                txtCanvass.Text = txtCanvass.Text & rsArt!PictureLine & vbCrLf
                rsArt.MoveNext
            Loop
        Else
            txtTitle.Text = ""
            lblArtMsg.Caption = "Main Group " & intMainGroup & " record not found!"
        End If
        Set rsArt = Nothing
    Else
        txtMainGroup.Text = "60001"
        lblArtMsg.Caption = "Main Group 60001 record is invalid!"
        txtTitle.Text = ""
    End If
    Exit Sub
Err_Art:
    lblArtMsg.Caption = "Error loading record!"
End Sub
Private Sub cmdPrevious_Click()
On Error GoTo Err_Art
    Dim rsArt As Recordset
    Dim intMainGroup As Integer
    
    subDisplayTotalRecordCount
    txtMainGroup.Text = MyCInt(txtMainGroup) - 1
    DoEvents
    intMainGroup = MyCInt(txtMainGroup)
    txtCanvass.Text = ""
    If (intMainGroup > 0) Then
        Set rsArt = MyDB.OpenRecordset("SELECT * FROM tblSystemAsciiPix WHERE MainGroup=" & intMainGroup & " ORDER BY MainGroup, GroupOrder;", dbOpenSnapshot)
        If (Not rsArt.EOF) Then
            lblArtMsg.Caption = "Main Group " & intMainGroup & " WAS found!"
            txtMainGroup.Text = MyCInt(rsArt!MainGroup)
            txtTitle.Text = MyCStr(rsArt!SearchKeyTitle)
            txtGloryPayOut.Text = MyCInt(rsArt!GloryPayOut)
            Select Case (MyCInt(rsArt!RndChoice) <> 0)
                Case True
                    chkRndChoice.Value = 1
                Case False
                    chkRndChoice.Value = 0
            End Select
            Do While (Not rsArt.EOF)
                txtCanvass.Text = txtCanvass.Text & rsArt!PictureLine & vbCrLf
                rsArt.MoveNext
            Loop
        Else
            txtTitle.Text = ""
            lblArtMsg.Caption = "Main Group " & intMainGroup & " record not found!"
        End If
        Set rsArt = Nothing
    Else
        txtMainGroup.Text = "0"
        lblArtMsg.Caption = "Main Group 0 record is invalid!"
        txtTitle.Text = ""
    End If
    Exit Sub
Err_Art:
    lblArtMsg.Caption = "Error loading record!"
End Sub
Private Sub cmdWrite_Click()
On Error GoTo Err_Art
    Dim rsArt As Recordset
    Dim intMainGroup As Integer
    Dim vPictureLine As Variant
    Dim iLine As Integer
    Dim zUseLine As String
    Dim intSavePositionOver As Integer
    picbSaving.Visible = True: DoEvents
    intSavePositionOver = MyCInt(txtSavePositionOver.Text)
    If (intSavePositionOver < 1) Then intSavePositionOver = 1
    subDisplayTotalRecordCount
    intMainGroup = MyCInt(txtMainGroup)
    If (intMainGroup >= 0 And intMainGroup < 60001) Then
        Set rsArt = MyDB.OpenRecordset("tblSystemAsciiPix", dbOpenTable)
        lblArtMsg.Caption = "~Writing Main Group " & intMainGroup & "~"
        DoEvents
        MyDB.Execute "DELETE * FROM tblSystemAsciiPix WHERE MainGroup=" & intMainGroup & ";", dbFailOnError
        DoEvents
        iLine = 0
        vPictureLine = txtCanvass.Text
        If (Len(vPictureLine) > 2) Then
            If (Mid(vPictureLine, Len(vPictureLine) - 1, 1) <> vbCr And Mid(vPictureLine, Len(vPictureLine) - 1, 1) <> vbLf) Then vPictureLine = vPictureLine & vbCrLf 'we require an end-of-file vbcrlf
            Do While (InStr(vPictureLine, vbCrLf) > 0)
                iLine = iLine + 1
                rsArt.AddNew
                rsArt!SearchKeyTitle = zKeepLettersOnly(txtTitle.Text)
                rsArt!MainGroup = intMainGroup
                rsArt!GroupOrder = iLine
                zUseLine = Mid(RTrim(Mid(vPictureLine, 1, InStr(vPictureLine, vbCrLf) - 1)), 1) 'we force it to work for telnet
                rsArt!PictureLine = Mid(zUseLine, intSavePositionOver)
                rsArt!RndChoice = (MyCInt(chkRndChoice.Value) <> 0)
                rsArt!GloryPayOut = MyCInt(txtGloryPayOut.Text)
                rsArt.Update
                vPictureLine = Mid(vPictureLine, InStr(vPictureLine, vbCrLf) + 2)
            Loop
            lblArtMsg.Caption = "~Written Main Group " & intMainGroup & "~"
        Else
            lblArtMsg.Caption = "Main Group " & intMainGroup & " has no information to write!"
        End If
        Set rsArt = Nothing
    Else
        txtMainGroup.Text = intMainGroup
        lblArtMsg.Caption = "Main Group " & intMainGroup & " is invalid!"
        txtTitle.Text = ""
    End If
    
    If (intSavePositionOver > 1) Then lblArtMsg.Caption = "You need to update to see your move of " & intSavePositionOver
    
    subDisplayTotalRecordCount
    picbSaving.Visible = False: DoEvents
    Exit Sub
Err_Art:
    lblArtMsg.Caption = "Error writing the record!"
    picbSaving.Visible = False: DoEvents
End Sub
Private Sub Form_Load()
On Error GoTo Err_Art
    Dim rsArt As Recordset
    gblbAsciiFormActive = True
    subDisplayTotalRecordCount
    txtCanvass.Text = ""
    Set rsArt = MyDB.OpenRecordset("SELECT * FROM tblSystemAsciiPix WHERE MainGroup=1 ORDER BY MainGroup, GroupOrder;", dbOpenSnapshot)
    If (Not rsArt.EOF) Then
        lblArtMsg.Caption = "Found first file!"
        txtMainGroup.Text = MyCInt(rsArt!MainGroup)
        txtTitle.Text = MyCStr(rsArt!SearchKeyTitle)
        txtGloryPayOut.Text = MyCInt(rsArt!GloryPayOut)
        Select Case (MyCInt(rsArt!RndChoice) <> 0)
            Case True
                chkRndChoice.Value = 1
            Case False
                chkRndChoice.Value = 0
        End Select

        Do While (Not rsArt.EOF)
            txtCanvass.Text = txtCanvass.Text & rsArt!PictureLine & vbCrLf
            rsArt.MoveNext
        Loop
    Else
        lblArtMsg.Caption = "Main Group 1 record not found!"
    End If
    Set rsArt = Nothing
    Exit Sub
Err_Art:
    lblArtMsg.Caption = "Error loading first record!"
End Sub
Private Sub txtMainGroup_KeyUp(KeyCode As Integer, Shift As Integer)
On Error GoTo Err_Art
    Dim rsArt As Recordset
    Dim intMainGroup As Integer
    
    intMainGroup = MyCInt(txtMainGroup)
    If (KeyCode = 13) Then
        subDisplayTotalRecordCount
        txtTitle.Text = ""
        txtCanvass.Text = ""
        If (intMainGroup > 0 And intMainGroup < 60001) Then
            Set rsArt = MyDB.OpenRecordset("SELECT * FROM tblSystemAsciiPix WHERE MainGroup=" & intMainGroup & " ORDER BY MainGroup, GroupOrder;", dbOpenSnapshot)
            If (Not rsArt.EOF) Then
                lblArtMsg.Caption = "Main Group " & intMainGroup & " WAS found!"
                txtTitle.Text = MyCStr(rsArt!SearchKeyTitle)
                txtMainGroup.Text = MyCInt(rsArt!MainGroup)
                Select Case (MyCInt(rsArt!RndChoice) <> 0)
                    Case True
                        chkRndChoice.Value = 1
                    Case False
                        chkRndChoice.Value = 0
                End Select
                Do While (Not rsArt.EOF)
                    txtCanvass.Text = txtCanvass.Text & rsArt!PictureLine & vbCrLf
                    rsArt.MoveNext
                Loop
            Else
                lblArtMsg.Caption = "Main Group " & intMainGroup & " record not found!"
            End If
            Set rsArt = Nothing
        Else
            txtMainGroup.Text = ""
            lblArtMsg.Caption = "Main Group " & intMainGroup & " is invalid!"
        End If
    End If
    Exit Sub
Err_Art:
    lblArtMsg.Caption = "Error loading record!"
End Sub
