Attribute VB_Name = "modCommandFleet"
Option Explicit
Public Sub subFleetCommand(zCommand As String, zX As String, zY As String, zZ As String, zPortID As String)
On Error GoTo Err_Check 'See Also: EXCHANGE command
    'Dim lErrorFind As Long
    Dim lSSPowerLevel As Long
    Dim lFuelCost As Long
    Dim rsMines As Recordset
    Dim lSSAreaDX As Long
    Dim lSSAreaDY As Long
    Dim lSSAreaDZ As Long
    Dim zExtraMsg As String
    Dim rsSSArea As Recordset
    Dim bDrunkChanged As Boolean
    Dim bCorrecting As Boolean 'used to correct for ss navig
    Dim zTargetPortID As String
    Dim lHoldColonistsNumber As Long
    Dim zSQL As String
    Dim lColonistCalcu As Long
    Dim rsSS As Recordset
    Dim rsSSPMines As Recordset
    Dim rsBeamArea As Recordset
    Dim rsPlayer As Recordset
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lNX As Long
    Dim lNY As Long
    Dim lNZ As Long
    Dim lCX As Long 'Set entered coordinates
    Dim lCY As Long
    Dim lCZ As Long
    Dim zPlayerName As String
    Dim lPGold As Long
    Dim bShowCommands As Boolean
    Dim rsObject As Recordset
    Dim bPurchased As Boolean
    Dim lDistanceToGo As Long
    Dim lWeaponsSoulBet As Long
    Dim lSSHullIntegrity As Long
    Dim lSSLaserLevel As Long
    Dim lParsecs As Long
    Dim iArrived As Integer
    Dim lColonistsFarm As Long
    Dim lColonistsFactory As Long
    Dim lAmount As Long
    Dim bFirePhasers As Boolean
    
    'Dummy variables
    Dim zMsg As String
    Dim lRollA As Long
    Dim lRollB As Long
    
    Dim lPlayerID As Long
    Dim lStatus As Long
    Dim lPlayerLevel As Long
    Dim lStarshipCommandDelay As Long
    Dim lJailDuration As Long
    Dim zGender As String
    Dim lAreaTrapDuration As Long
    Dim lMana As Long
    Dim lEssence As Long
    Dim lSoul As Long
    Dim lMove As Long
    Dim lDrunkLevel As Long
    Dim lDrunkDuration As Long
    Dim lLearnPoints As Long
    Dim lImmortalLevel As Long
    Dim lAreaTrapID As Long
    Dim lWhereID As Long
    Dim lBlindDuration As Long
    Dim lStunDuration As Long
    Dim lSleepDuration As Long
    Dim zErrorMessage As String
    Dim bFound As Boolean
    
    'lErrorFind = 0 'this is for strange errors
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT SleepDuration, StunDuration, BlindDuration, JailDuration, WhereID, X, Y, Z, AreaTrapID, PlayerName, Gold, PlayerID, Status, PlayerLevel, CMana, CEssence, CSoul, CMove, Gender, DrunkLevel, DrunkDuration, StarshipCommandDelay, LearnPoints, ImmortalLevel, AreaTrapDuration FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lJailDuration = MyCLng(rsPlayer!JailDuration)
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
        lWhereID = MyCLng(rsPlayer!WhereID)
        lPGold = MyCLng(rsPlayer!Gold)
        
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lStatus = MyCLng(rsPlayer!Status)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lAreaTrapID = MyCLng(rsPlayer!AreaTrapID)
        lAreaTrapDuration = MyCLng(rsPlayer!AreaTrapDuration)
        lMana = MyCLng(rsPlayer!CMana)
        lEssence = MyCLng(rsPlayer!CEssence)
        lSoul = MyCLng(rsPlayer!CSoul)
        lMove = MyCLng(rsPlayer!CMove)
        zGender = MyCStr(rsPlayer!Gender)
        lDrunkLevel = MyCLng(rsPlayer!DrunkLevel)
        lDrunkDuration = MyCLng(rsPlayer!DrunkDuration)
        lStarshipCommandDelay = MyCLng(rsPlayer!StarshipCommandDelay)
        lLearnPoints = MyCLng(rsPlayer!LearnPoints)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
    If (lSleepDuration + lBlindDuration + lStunDuration = 0) Then
    If (lJailDuration = 0) Then
        If (lAreaTrapDuration = 0) Then
            bShowCommands = False
            If (iCombatPlayerStatus(zPortID) = cstiStatusNotInBattleMode) Then '0=available battle cell 10=battle mode mob, 15=battlemode player
                If (lStatus <> 50 And lStatus <> 20) Then 'not sleeping not sitting
                    If (Len(zCommand) > 0) Then
                        If (lDrunkLevel > 29) Then
                            If (lRandom(5) < 3) Then subSendMsg "&M*you are the onboard drunk*", zPortID
                            Select Case lRandom(9)
                                Case 1
                                    subSendMsgAreaAll "&RMedical bot says, 'um, " & zPlayerName & " is drunk everyone.'", lPX, lPY, lPZ
                                Case 2
                                    subSendMsgAreaAll "&RMedical bot says, 'ah, " & zPlayerName & "'s blood alchol level is quite high!'", lPX, lPY, lPZ
                                Case 3
                                    subSendMsgAreaAll "&RMedical bot confirms, 'I give permission for anyone to relieve " & zPlayerName & ".'", lPX, lPY, lPZ
                            End Select
                        End If
                        
                        lAmount = MyCLng(zX)
                        
                        'Set entered coordinates
                        If (Len(zX) > 8) Then zX = "0"
                        If (Len(zY) > 8) Then zY = "0"
                        If (Len(zZ) > 8) Then zZ = "0"
                        lCX = MyCLng(zX)
                        If (lCX > 1000000) Then lCX = 1000000
                        If (lCX < -1000000) Then lCX = -1000000
                        lCY = MyCLng(zY)
                        If (lCY > 1000000) Then lCY = 1000000
                        If (lCY < -1000000) Then lCY = -1000000
                        lCZ = MyCLng(zZ)
                        If (lCZ > 1000000) Then lCZ = 1000000
                        If (lCZ < -1000000) Then lCZ = -1000000
                        
                        If (Len(zX) = 0 And Len(zY) = 0 And Len(zZ) = 0) Then
                            lCX = lPX 'no coordinates given? just default to the player then
                            lCY = lPY
                            lCZ = lPZ
                        End If
                        
                        If (lDrunkDuration + lDrunkLevel > 30 And lRandom(5) < 4) Then
                            bDrunkChanged = False
                            Select Case lRandom(5)
                                Case 1
                                    bDrunkChanged = True
                                    lCX = lCX + lRandom(3)
                                Case 2
                                    bDrunkChanged = True
                                    lCX = lCX - lRandom(3)
                            End Select
                            Select Case lRandom(5)
                                Case 1
                                    bDrunkChanged = True
                                    lCY = lCY + lRandom(3)
                                Case 2
                                    bDrunkChanged = True
                                    lCY = lCY - lRandom(3)
                            End Select
                            Select Case lRandom(5)
                                Case 1
                                    bDrunkChanged = True
                                    lCZ = lCZ + lRandom(3)
                                Case 2
                                    bDrunkChanged = True
                                    lCZ = lCZ - lRandom(3)
                            End Select
                            
                            If (bDrunkChanged) Then
                                subSendMsg "&M*hic*", zPortID
                                subSendMsgAreaAll "&RNavigational computer wonders if you meant something else.", lPX, lPY, lPZ
                            Else
                                subSendMsg "&M*you manage the drunken task perfectly*", zPortID
                            End If
                        End If
                        
                        lParsecs = Abs(lCX - lPX) + Abs(lCY - lPY) + Abs(lCZ - lPZ)
                        
                        Select Case UCase(Mid(zCommand, 1, 4))
                            Case "BUY"
                                subStarshipBuy zPortID
                                subLoadPlayerOwnsStarshipDetails MyCLng(zPortID), lPlayerID
                            Case "REPA"
                                Set rsSS = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z, SSScanLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
                                If (Not rsSS.EOF) Then
                                    subFleetStarportRepair MyCStr(rsSS!AreaName), lPlayerID
                                Else
                                    subSendMsg "&gYou need to be aboard your starship to order repairs from a starport.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "PARS"
                                subStarshipParsecs zPortID, lCX, lCY, lCZ, lPX, lPY, lPZ
                            Case "PING", "SS", "STAR"
                                subFleetPingStarships lPX, lPY, lPZ, lPlayerLevel, lEssence, lMana, lPlayerID, zX, lStarshipCommandDelay, 2, zPortID
                            Case "SCAN"
                                subFleetPingStarships lPX, lPY, lPZ, lPlayerLevel, lEssence, lMana, lPlayerID, zX, lStarshipCommandDelay, 3, zPortID
                            Case "WORL", "CONT" 'works from a house or a starship
                                Select Case UCase(Mid(zX, 1, 4))
                                    Case "LOCA", "SCAN"
                                        Set rsSS = MyDB.OpenRecordset("SELECT X, Y, Z, SSScanLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
                                        If (Not rsSS.EOF) Then
                                            subSendMsg "&Wnavigation officer reports, 'Scanners are Adequate at " & MyCLng(rsSS!SSScanLevel) & "parsecs',", zPortID
                                            subFleetDeepSpaceScanMyWorlds MyCLng(rsSS!SSScanLevel), lPX, lPY, lPZ, lEssence, lMana, lPlayerID, False
                                        Else
                                            subSendMsg "&gYou need to be aboard your starship to view your controlled world.", zPortID
                                        End If
                                        Set rsSS = Nothing
                                    Case Else
                                        Set rsSS = MyDB.OpenRecordset("SELECT X, Y, Z, SSScanLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
                                        If (Not rsSS.EOF) Then
                                            subSendMsg "&wcommunications officer reports, 'Scanners...inadequate...however, transferring to...full-subspace comm-sweeps, Sir!',", zPortID
                                            subFleetDeepSpaceScanMyWorlds 99999, lPX, lPY, lPZ, lEssence, lMana, lPlayerID, True
                                        Else
                                            subSendMsg "&gYou need to be aboard your starship to view your controlled world.", zPortID
                                        End If
                                        Set rsSS = Nothing
                                End Select
                            Case "LOCA" 'location in space allowed for houses so we dont set PlayerType=2
                                subStarshipLocationXYZ zPortID, lPX, lPY, lPZ
                            Case "NAVI"
                                If (bNavigationSafe(lCX, lCY, lCZ)) Then
                                If (Len(zX) > 0 And Len(zY) > 0 And Len(zZ) > 0) Then
                                    If (lngSQLRecordCount("SELECT AreaID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);") <> 0) Then
                                        bCorrecting = False
                                        If (bCheckAreaExists(zPortID, lCX, lCY, lCZ, False)) Then 'try 1
                                            bCorrecting = True
                                            'there is a mass in the way - we try to correct it
                                            subSendMsgAreaAll "&a'Mass is in the way, attempting correction-course'", lPX, lPY, lPZ
                                            lCZ = lCZ - (10 + lRandom(10))
                                        End If
                                        
                                        If (bCheckAreaExists(zPortID, lCX, lCY, lCZ, False)) Then 'try 2
                                            bCorrecting = True
                                            'there is a mass in the way - we try to correct it
                                            lCZ = lCZ - (10 + lRandom(20))
                                        End If
                                        
                                        If (Not bCheckAreaExists(zPortID, lCX, lCY, lCZ, False) And Not bCheckDoorExists("", lCX, lCY, lCZ)) Then
                                            Set rsSS = MyDB.OpenRecordset("SELECT AreaName, SSScanLevel, SSEngineCruise, SSEngineLevel, CloakingDeviceLevel, CloakingDeviceDuration, SSN, SSNX, SSNY, SSNZ FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                            If (Not rsSS.EOF) Then
                                                If (bCorrecting) Then subSendMsgAreaAll "&a'Course redirection successful'", lPX, lPY, lPZ
                                                subShipSignature "", MyCStr(rsSS!AreaName) & " [navigating]" & vbCrLf & " [w" & MyCStr(rsSS!SSEngineCruise) & "] [d" & MyCStr(Abs(lPX - lCX) + Abs(lPY - lCY) + Abs(lPZ - lCZ)) & "] [dx" & lCX & " y" & lCY & " z" & lCZ & "]", MyCLng(MyCLng(rsSS!SSEngineCruise) / 6), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                                                rsSS.Edit
                                                rsSS!SSN = True 'we are moving to position, when reached this is set to zero
                                                rsSS!SSNX = lCX 'when the destination is reached this is set to zero again
                                                rsSS!SSNY = lCY
                                                rsSS!SSNZ = lCZ
                                                rsSS.Update
                                            Else
                                                subSendMsg "&gYou need to board your starship first.", zPortID
                                            End If
                                            Set rsSS = Nothing
                                        Else
                                            subSendMsgAreaAll "&R'Course [" & lCX & " " & lCY & " " & lCZ & "] was rejected'", lPX, lPY, lPZ
                                        End If
                                    Else
                                        subSendMsgAreaAll gblzFNGRE & "Only the captain of their starship can navigate.", lPX, lPY, lPZ
                                    End If
                                Else
                                    subSendMsg "&gSYNTAX: SS NAVI X Y Z", zPortID
                                End If
                                Else
                                    subSendMsg "&RRestricted Location Try again!" & vbCrLf & "&gSYNTAX: SS NAVI X Y Z", zPortID
                                End If
                            Case "WARP"
                                If (Len(zX) > 0) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT SSN, SSNX, SSNY, SSNZ, SSEngineLevel, SSEngineCruise, AreaName, CloakingDeviceDuration, CloakingDeviceLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                    If (Not rsSS.EOF) Then
                                        If (lCX >= MyCLng(rsSS!SSEngineLevel) Or zX = "MAX" Or zX = "FULL" Or zX = "ALL") Then
                                            lCX = MyCLng(rsSS!SSEngineLevel)
                                            subSendMsgAreaAll gblzFBYEL & "Navigational computer confirms, 'Maximum warp inputted'", lPX, lPY, lPZ
                                        End If
                                        If (lCX < 1) Then
                                            lCX = 1
                                            subSendMsgAreaAll gblzFBYEL & "Navigational computer confirms, 'Impulse drive inputted'", lPX, lPY, lPZ
                                        End If
                                        rsSS.Edit
                                        rsSS!SSEngineCruise = lCX 'when the destination is reached this is set to zero again
                                        rsSS.Update
                                        subShipSignature "", MyCStr(rsSS!AreaName) & " [Navigation] [w" & MyCLng(rsSS!SSEngineCruise) & "] [d" & Abs(lPX - MyCLng(rsSS!SSNX)) + Abs(lPY - MyCLng(rsSS!SSNY)) + Abs(lPZ - MyCLng(rsSS!SSNZ)) & "]", MyCLng(MyCLng(rsSS!SSEngineCruise) / 6), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lPX, lPY, lPZ, False 'bAllowMobShipReactSig
                                    Else
                                        subSendMsg "&gYou need to board your starship first.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsg "&gSYNTAX: SS WARP NUMBER", zPortID
                                End If
                            Case "GO", "ENGA"
                                subStarshipControlEngage zPortID, "G", lPlayerID, lPX, lPY, lPZ
                            Case "STOP", "HOLD", "HALT", "CEAS"
                                subStarshipControlEngage zPortID, "S", lPlayerID, lPX, lPY, lPZ
                            Case "CHAS", "FOLL", "PURS", "PERU", "PERS" 'chase or follow, pursuit (and some bad spellsings of it)
                                Set rsSS = MyDB.OpenRecordset("SELECT SSN, SSNX, SSNY, SSNZ, AreaName, SSLaserLevel, SSLaserOnline, SSPLockX, SSPLockY, SSPLockZ, SSEngineCruise, CloakingDeviceDuration, CloakingDeviceLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                If (Not rsSS.EOF) Then
                                    If (MyCLng(rsSS!SSLaserLevel) > 0) Then
                                        rsSS.Edit
                                        rsSS!SSN = True 'we are moving to position, when reached this is set to zero
                                        rsSS!SSNX = MyCLng(rsSS!SSPLockX)
                                        rsSS!SSNY = MyCLng(rsSS!SSPLockY)
                                        rsSS!SSNZ = MyCLng(rsSS!SSPLockZ)
                                        rsSS.Update
                                        subShipSignature "", MyCStr(rsSS!AreaName) & " [pursues] [w" & MyCLng(rsSS!SSEngineCruise) & "] [d" & Abs(lPX - MyCLng(rsSS!SSPLockX)) + Abs(lPY - MyCLng(rsSS!SSPLockY)) + Abs(lPZ - MyCLng(rsSS!SSPLockZ)) & "] [dx" & MyCLng(rsSS!SSPLockX) & " y" & MyCLng(rsSS!SSPLockY) & " z" & MyCLng(rsSS!SSPLockZ) & "]", MyCLng(rsSS!SSEngineCruise), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lPX, lPY, lPZ, False 'bAllowMobShipReactSig
                                    Else
                                        subSendMsg "&wOnboard computer reports, 'There is no phaser chassis onboard this starship.'", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYou need to be aboard your own ship to use the weapon systems.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "REPU"
                                If (lSoul >= cstlPReplicatorSoulCost) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT X, Y, Z, SSRepulsorLevel, AreaID, AreaName, CloakingDeviceDuration, CloakingDeviceLevel FROM tblArea WHERE ((PlayerID=" & lPlayerID & ") AND (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ") AND (PlayerType=2));", dbOpenSnapshot)
                                    If (Not rsSS.EOF) Then
                                        If (MyCLng(rsSS!SSRepulsorLevel) > 0) Then
                                            MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & cstlPReplicatorSoulCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            subSendMsgAreaAll "&wThe repulsor beam activates!", lPX, lPY, lPZ
                                            Set rsSSArea = MyDB.OpenRecordset("SELECT SSShieldLevel, SSHullLevel, X, Y, Z, AreaName, CloakingDeviceDuration, CloakingDeviceLevel FROM tblArea WHERE ((PlayerID<>0 AND PlayerID<>" & lPlayerID & ") AND (X=" & lPX & " or X-1=" & lPX & " or X+1=" & lPX & ") AND (Y=" & lPY & " or Y-1=" & lPY & " or Y+1=" & lPY & ") AND (Z=" & lPZ & " or Z-1=" & lPZ & " or Z+1=" & lPZ & ") AND (PlayerType=2)) ORDER BY AreaName;", dbOpenDynaset)
                                            If (Not rsSSArea.EOF) Then
                                                    Do While (Not rsSSArea.EOF)
                                                        lRollA = lRandom(MyCLng(rsSS!SSRepulsorLevel))
                                                        lRollB = lRandom(MyCLng(rsSSArea!SSShieldLevel))
                                                        zMsg = "Repulsor " & lRollA & " vs Shield " & lRollB & "/" & MyCLng(rsSSArea!SSShieldLevel) & vbCrLf
                                                        If (lRollA > lRollB) Then
                                                            lSSAreaDX = MyCLng(rsSSArea!x)
                                                            lSSAreaDY = MyCLng(rsSSArea!y)
                                                            lSSAreaDZ = MyCLng(rsSSArea!z)
                                                            
                                                            Select Case lRandom(3)
                                                                Case 1
                                                                    lSSAreaDX = lSSAreaDX + lRandom(3)
                                                                Case 2
                                                                    lSSAreaDX = lSSAreaDX - lRandom(3)
                                                            End Select
                                                            Select Case lRandom(3)
                                                                Case 1
                                                                    lSSAreaDY = lSSAreaDY + lRandom(3)
                                                                Case 2
                                                                    lSSAreaDY = lSSAreaDY - lRandom(3)
                                                            End Select
                                                            Select Case lRandom(3)
                                                                Case 1
                                                                    lSSAreaDZ = lSSAreaDZ + lRandom(3)
                                                                Case 2
                                                                    lSSAreaDZ = lSSAreaDZ - lRandom(3)
                                                            End Select
                                                            
                                                            If (Not bCheckAreaExists(zPortID, lSSAreaDX, lSSAreaDY, lSSAreaDZ, False)) Then
                                                                'All objects, mobs, players are moved too
                                                                MyDB.Execute "UPDATE tblMob SET X = " & lSSAreaDX & ", Y = " & lSSAreaDY & ", Z = " & lSSAreaDZ & " WHERE X=" & MyCLng(rsSSArea!x) & " AND Y=" & MyCLng(rsSSArea!y) & " AND Z=" & MyCLng(rsSSArea!z) & ";", dbFailOnError
                                                                MyDB.Execute "UPDATE tblObject SET X = " & lSSAreaDX & ", Y = " & lSSAreaDY & ", Z = " & lSSAreaDZ & " WHERE X=" & MyCLng(rsSSArea!x) & " AND Y=" & MyCLng(rsSSArea!y) & " AND Z=" & MyCLng(rsSSArea!z) & ";", dbFailOnError
                                                                MyDB.Execute "UPDATE tblPlayer SET X = " & lSSAreaDX & ", Y = " & lSSAreaDY & ", Z = " & lSSAreaDZ & " WHERE X=" & MyCLng(rsSSArea!x) & " AND Y=" & MyCLng(rsSSArea!y) & " AND Z=" & MyCLng(rsSSArea!z) & ";", dbFailOnError
                                                                If (MyCLng(rsSSArea!CloakingDeviceDuration) > 1) Then
                                                                    zMsg = zMsg & MyCStr(rsSS!AreaName) & " [repulsed and decloaked] " & MyCStr(rsSSArea!AreaName) & vbCrLf & "[d" & Abs(MyCLng(rsSS!x) - lSSAreaDX) + Abs(MyCLng(rsSS!y) - lSSAreaDY) + Abs(MyCLng(rsSS!z) - lSSAreaDZ) & "] [dx" & lSSAreaDX & " y" & lSSAreaDY & " z" & lSSAreaDZ & "]"
                                                                    rsSSArea.Edit
                                                                    rsSSArea!x = lSSAreaDX
                                                                    rsSSArea!y = lSSAreaDY
                                                                    rsSSArea!z = lSSAreaDZ
                                                                    rsSSArea!CloakingDeviceDuration = 1
                                                                    rsSSArea.Update
                                                                Else
                                                                    zMsg = zMsg & MyCStr(rsSS!AreaName) & " [repulsed] " & MyCStr(rsSSArea!AreaName) & vbCrLf & "[d" & Abs(MyCLng(rsSS!x) - lSSAreaDX) + Abs(MyCLng(rsSS!y) - lSSAreaDY) + Abs(MyCLng(rsSS!z) - lSSAreaDZ) & "] [dx" & lSSAreaDX & " y" & lSSAreaDY & " z" & lSSAreaDZ & "]"
                                                                    rsSSArea.Edit
                                                                    rsSSArea!x = lSSAreaDX
                                                                    rsSSArea!y = lSSAreaDY
                                                                    rsSSArea!z = lSSAreaDZ
                                                                    rsSSArea.Update
                                                                End If
                                                            Else
                                                                zMsg = zMsg & MyCStr(rsSS!AreaName) & " [mass in the way] " & MyCStr(rsSSArea!AreaName) & vbCrLf & "[d" & Abs(MyCLng(rsSS!x) - lSSAreaDX) + Abs(MyCLng(rsSS!y) - lSSAreaDY) + Abs(MyCLng(rsSS!z) - lSSAreaDZ) & "] [dx" & lSSAreaDX & " y" & lSSAreaDY & " z" & lSSAreaDZ & "]"
                                                            End If
                                                        Else
                                                            zMsg = zMsg & MyCStr(rsSS!AreaName) & " [repulse-resisted] " & MyCStr(rsSSArea!AreaName) & vbCrLf & "[d" & Abs(MyCLng(rsSS!x) - MyCLng(rsSSArea!x)) + Abs(MyCLng(rsSS!y) - MyCLng(rsSSArea!y)) + Abs(MyCLng(rsSS!z) - MyCLng(rsSSArea!z)) & "] [dx" & MyCLng(rsSSArea!x) & " y" & MyCLng(rsSSArea!y) & " z" & MyCLng(rsSSArea!z) & "]"
                                                        End If
                                                        subShipSignature "", zMsg, 15, 0, 0, MyCLng(rsSS!x), MyCLng(rsSS!y), MyCLng(rsSS!z), False 'bAllowMobShipReactSig
                                                        rsSSArea.MoveNext
                                                    Loop
                                            Else
                                                subSendMsg "&AScience computer reports, 'There are no ships within one parsec.'", zPortID
                                            End If
                                            Set rsSSArea = Nothing
                                        Else
                                            subSendMsg "&Rcomputer reports, 'this starship is not equipped with a repulsor beam chassis.'", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou must be aboard your own starship to use the repulsor beam.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsgAreaAll "&aOnboard computer reports, 'The weapons officer is short " & (cstlPReplicatorSoulCost - lSoul) & " soul.'", lPX, lPY, lPZ
                                End If
                            Case "DROP"
                                If (lStatus = 5) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT ColonistsAboard, X, Y, Z FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                    If (Not rsSS.EOF) Then
                                        If (MyCLng(rsSS!ColonistsAboard) > 0) Then
                                            Set rsBeamArea = MyDB.OpenRecordset("SELECT TOP 1 ColonistAllowed, ColonistsPlayerID, ColonistsNumber, ColonistsFarm, ColonistsFactory, AreaName, X, Y, Z, WhereID, AreaTrapID FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z>" & lPZ & " AND Z<" & lPZ + cstlBeamDistance & ") ORDER BY Z;", dbOpenDynaset)
                                            If (Not rsBeamArea.EOF) Then 'this also checks doors
                                                zTargetPortID = zReturnPortID(MyCLng(rsBeamArea!ColonistsPlayerID))
                                                lColonistsFarm = MyCLng(rsBeamArea!ColonistsFarm)
                                                lColonistsFactory = MyCLng(rsBeamArea!ColonistsFactory)
                                                If (MyCInt(rsBeamArea!ColonistAllowed) <> 0) Then
                                                    If (lAmount < 1 Or lAmount > MyCLng(rsSS!ColonistsAboard) Or zX = "MAX" Or zX = "FULL" Or zX = "ALL") Then lAmount = MyCLng(rsSS!ColonistsAboard)
                                                    
                                                    If (MyCLng(rsBeamArea!ColonistsPlayerID) = lPlayerID) Then
                                                        rsBeamArea.Edit 'add men to the area
                                                        rsBeamArea!ColonistsPlayerID = lPlayerID
                                                        rsBeamArea!ColonistsNumber = MyCLng(rsBeamArea!ColonistsNumber) + lAmount
                                                        rsBeamArea.Update
                                                        
                                                        subSendMsg "&WYou safely beam down " & lAmount & " colonists!", zPortID
                                                        subSendMsgAreaExcept2 "&W" & zPlayerName & " beams down " & lAmount & " colonists!", lPX, lPY, lPZ, zPortID, ""
                                                        subSendMsgAreaExcept2 "&W" & zPlayerName & " beams " & lAmount & " colonists into the area!", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                    Else
                                                        lHoldColonistsNumber = MyCLng(rsBeamArea!ColonistsNumber)
                                                        lColonistCalcu = lHoldColonistsNumber - lAmount
                                                        
                                                        'messages
                                                        subSendMsg "&RYou beam down " & lAmount & " colonists! WAR!!!", zPortID
                                                        subSendMsgAreaExcept2 "&R" & zPlayerName & " beams down " & lAmount & " colonists! WAR!!!", lPX, lPY, lPZ, zPortID, ""
                                                        subSendMsgAreaExcept2 "&R" & zPlayerName & " beams " & lAmount & " colonists into the area! WAR!!!", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                        
                                                        If (lColonistCalcu > 0) Then
                                                            'we send a message to the defender owner of the colony underattack
                                                            subSendMsg "&W(COLONY WARS) " & gblzFBGRE & MyCStr(rsBeamArea!AreaName) & "[" & MyCStr(rsBeamArea!x) & " " & MyCStr(rsBeamArea!y) & " " & MyCStr(rsBeamArea!z) & "] [troop attack] [-c" & lAmount & "] [c" & lColonistCalcu & "] [DEFENDED] [" & zPlayerName & "]", zTargetPortID
                                                            'send message to attacker
                                                            subSendMsg "&R" & MyCStr(rsBeamArea!AreaName) & " [def" & lHoldColonistsNumber & "] [enemy ground held] [att" & lAmount & "] [left " & lColonistCalcu & "]", zPortID
                                                            'message to all the other players onboard
                                                            subSendMsgAreaExcept2 "&R" & zPlayerName & " lost " & lAmount & " beamed down colonists to the war!", lPX, lPY, lPZ, zPortID, ""
                                                            'message to the area underattack
                                                            subSendMsgAreaExcept2 gblzFBGRE & zPlayerName & " lost " & lAmount & " beamed down colonists to the war!", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                        Else
                                                            'we send a message to the owner of the colony underattack
                                                            subSendMsg "&W(COLONY WARS) " & "&R" & MyCStr(rsBeamArea!AreaName) & "[" & MyCStr(rsBeamArea!x) & " " & MyCStr(rsBeamArea!y) & " " & MyCStr(rsBeamArea!z) & "] [troop attack] [-c" & lHoldColonistsNumber & "] [LAND SIEZED] [" & zPlayerName & "]", zTargetPortID
                                                            'send message to attacker
                                                            subSendMsg "&GYou take possession of the land! [+c" & Abs(lColonistCalcu) & "]", zPortID
                                                            'message to all the other players onboard
                                                            subSendMsgAreaExcept2 gblzFBGRE & zPlayerName & " takes possession of the land! [+c" & Abs(lColonistCalcu) & "]", lPX, lPY, lPZ, zPortID, ""
                                                            'message to the area underattack
                                                            subSendMsgAreaExcept2 "&R" & zPlayerName & " takes possession of the land! [+c" & Abs(lColonistCalcu) & "]", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                        End If
                                                        
                                                        rsBeamArea.Edit
                                                        If (lColonistCalcu < 1) Then
                                                            If (lColonistsFarm > 0) Then
                                                                If (lRandom(10) < lRandom(20)) Then
                                                                    lColonistsFarm = MyCLng(lColonistsFarm / 2)
                                                                    subSendMsg "&RHalf the farms were destroyed!", zPortID
                                                                    If (lColonistsFarm < 1) Then lColonistsFarm = 0
                                                                    rsBeamArea!ColonistsFarm = lColonistsFarm
                                                                End If
                                                            End If
                                                            If (lColonistsFactory > 0) Then
                                                                If (lRandom(10) < lRandom(40)) Then 'Factories are nortoroious targets
                                                                    lColonistsFactory = MyCLng(lColonistsFactory / 2)
                                                                    subSendMsg "&RHalf the factories were destroyed!", zPortID
                                                                    If (lColonistsFactory < 1) Then lColonistsFactory = 0
                                                                    rsBeamArea!ColonistsFactory = lColonistsFactory
                                                                End If
                                                            End If
                                                            rsBeamArea!ColonistsPlayerID = lPlayerID 'Switch owner flags
                                                        End If
                                                        
                                                        rsBeamArea!ColonistsNumber = Abs(lColonistCalcu)
                                                        rsBeamArea.Update
                                                    End If
                                                    rsSS.Edit
                                                    rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) - lAmount
                                                    rsSS.Update
                                                Else
                                                    subSendMsg "&gComputer reports, 'that mass not suitable for colonization.'", zPortID
                                                End If
                                            Else
                                                subSendMsg "&gThe transporter computer doesn't detect any land masses below your ship within [" & cstlBeamDistance & "] parsecs", zPortID
                                                subSendMsgAreaExcept2 gblzFNGRE & zPlayerName & " works with the transporter system, then gives up.", lPX, lPY, lPZ, zPortID, ""
                                            End If
                                            Set rsBeamArea = Nothing
                                        Else
                                            subSendMsg "&Rcomputer reports, 'there are no colonists aboard the ship.'", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not aboard your starship.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsg "&wYou have to stand to use that command.", zPortID
                                End If
                            Case "COLO"
                                If (lStatus = 5) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT ColonistsAboard, X, Y, Z FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                    If (Not rsSS.EOF) Then
                                        zSQL = "SELECT TOP 1 ColonistAllowed, ColonistsPlayerID, ColonistsNumber, AreaName, X, Y, Z, WhereID, AreaTrapID FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z>" & lPZ & " AND Z<" & lPZ + cstlBeamDistance & ") ORDER BY Z;"  'beam down fight
                                        Set rsBeamArea = MyDB.OpenRecordset(zSQL, dbOpenDynaset) 'any player can beam down from another's starship
                                        If (Not rsBeamArea.EOF) Then 'this also checks doors
                                            If (MyCInt(rsBeamArea!ColonistAllowed) <> 0) Then
                                                If (MyCLng(rsBeamArea!ColonistsPlayerID) = lPlayerID) Then
                                                    If (MyCLng(rsBeamArea!ColonistsNumber) > 0) Then
                                                        rsBeamArea.Edit
                                                        rsBeamArea!ColonistsPlayerID = lPlayerID
                                                        If (lAmount < 1 Or lAmount > MyCLng(rsBeamArea!ColonistsNumber) Or zX = "MAX" Or zX = "FULL" Or zX = "ALL") Then lAmount = MyCLng(rsBeamArea!ColonistsNumber)
                                                        rsBeamArea!ColonistsNumber = MyCLng(rsBeamArea!ColonistsNumber) - lAmount
                                                        rsBeamArea.Update
                                                        rsSS.Edit
                                                        rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) + lAmount
                                                        rsSS.Update
                                                        
                                                        If (lAmount = MyCLng(rsBeamArea!ColonistsNumber)) Then
                                                            subSendMsg "&WYou safely beam up all your colonists out of the area!", zPortID
                                                            subSendMsgAreaExcept2 "&W" & zPlayerName & " beams up all of " & zTranslateGender(zGender, 2) & " colonists out of the area!", lPX, lPY, lPZ, zPortID, ""
                                                            subSendMsgAreaExcept2 "&W" & zPlayerName & " beams all of " & zTranslateGender(zGender, 2) & " colonists out of the area!", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                        Else
                                                            subSendMsg "&WYou safely beam up " & lAmount & " colonists!", zPortID
                                                            subSendMsgAreaExcept2 "&W" & zPlayerName & " beams up " & lAmount & " of " & zTranslateGender(zGender, 2) & " colonists!", lPX, lPY, lPZ, zPortID, ""
                                                            subSendMsgAreaExcept2 "&W" & zPlayerName & " beams up " & lAmount & " of " & zTranslateGender(zGender, 2) & " colonists out of the area!", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                        End If
                                                    Else
                                                        subSendMsg "&RComputer informs, 'There are no colonists to beam up, at x" & MyCLng(rsBeamArea!x) & " y" & MyCLng(rsBeamArea!y) & " z" & MyCLng(rsBeamArea!z) & "'", zPortID
                                                        subSendMsgAreaExcept2 "&RComputer informs " & zPlayerName & " that there are no" & vbCrLf & "colonists at x" & MyCLng(rsBeamArea!x) & " y" & MyCLng(rsBeamArea!y) & " z" & MyCLng(rsBeamArea!z), lPX, lPY, lPZ, zPortID, ""
                                                    End If
                                                Else
                                                    subSendMsg "&RComputer informs, 'There are no colonists to beam up, at x" & MyCLng(rsBeamArea!x) & " y" & MyCLng(rsBeamArea!y) & " z" & MyCLng(rsBeamArea!z) & "'", zPortID
                                                    subSendMsgAreaExcept2 "&RComputer informs " & zPlayerName & " that there are no" & vbCrLf & "colonists at x" & MyCLng(rsBeamArea!x) & " y" & MyCLng(rsBeamArea!y) & " z" & MyCLng(rsBeamArea!z), lPX, lPY, lPZ, zPortID, ""
                                                End If
                                            Else
                                                subSendMsg "&Rcomputer reports, 'that mass not suitable for colonization.'", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gThe transporter computer doesn't detect any land masses below your ship within [" & cstlBeamDistance & "] parsecs", zPortID
                                            subSendMsgAreaExcept2 gblzFNGRE & zPlayerName & " works with the transporter system, then gives up.", lPX, lPY, lPZ, zPortID, ""
                                        End If
                                        Set rsBeamArea = Nothing
                                    Else
                                        subSendMsg "&gYou are not aboard your starship.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsg "&wYou have to stand to use that command.", zPortID
                                End If
                            Case "FIGH", "DEFE", "HOME"
                                If (lStatus = 5) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT ColonistsPlayerID, ColonistAllowed, ColonistsAboard, ColonistsNumber, X, Y, Z FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                    If (Not rsSS.EOF) Then
                                        If (MyCInt(rsSS!ColonistAllowed) <> 0) Then
                                            If (MyCLng(rsSS!ColonistsPlayerID) <> lPlayerID) Then
                                                If (lAmount < 1 Or lAmount > MyCLng(rsSS!ColonistsAboard) Or zX = "MAX" Or zX = "FULL" Or zX = "ALL") Then lAmount = MyCLng(rsSS!ColonistsAboard)
                                                If (lAmount > 0) Then
                                                    rsSS.Edit
                                                    lColonistCalcu = MyCLng(rsSS!ColonistsNumber) - lAmount
                                                    rsSS!ColonistsNumber = Abs(lColonistCalcu)
                                                    rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) - lAmount
                                                    
                                                    If (lColonistCalcu >= 0) Then
                                                        subSendMsg "&RYou loose all your men in the conflict!", zPortID
                                                        subSendMsgAreaExcept2 "&R" & zPlayerName & " lost all the beamed down colonists to the war!", lPX, lPY, lPZ, zPortID, ""
                                                        subSendMsgAreaExcept2 "&R" & zPlayerName & " lost all the beamed down colonists to the war!", MyCLng(rsSS!x), MyCLng(rsSS!y), MyCLng(rsSS!z), zPortID, ""
                                                    End If
                                                    If (lColonistCalcu < 1) Then
                                                        subSendMsg "&RWAR! You safely win with " & lAmount & " colonists!", zPortID
                                                        subSendMsgAreaExcept2 "&RWAR! " & zPlayerName & " fights with " & lAmount & " colonists!", lPX, lPY, lPZ, zPortID, ""
                                                        If (MyCLng(rsSS!ColonistsPlayerID) <> lPlayerID) Then
                                                            rsSS!ColonistsPlayerID = lPlayerID
                                                            subSendMsg "&GYou liberate your homeworld!", zPortID
                                                            subSendMsgAreaExcept2 gblzFBGRE & zPlayerName & " won the war and liberates " & zTranslateGender(zGender, 2) & " homeworld!", lPX, lPY, lPZ, zPortID, ""
                                                        End If
                                                    End If
                                                    rsSS.Update
                                                Else
                                                    subSendMsgAreaExcept2 "&rWar Room reports, 'There are no colonists aboard to fight with!'", lPX, lPY, lPZ, "", ""
                                                End If
                                            Else 'easy transfer
                                                If (lAmount < 1 Or lAmount > MyCLng(rsSS!ColonistsAboard) Or zX = "MAX" Or zX = "FULL" Or zX = "ALL") Then lAmount = MyCLng(rsSS!ColonistsAboard)
                                                If (lAmount > 0) Then
                                                    lColonistCalcu = MyCLng(rsSS!ColonistsNumber) + lAmount
                                                    rsSS.Edit
                                                    rsSS!ColonistsNumber = lColonistCalcu
                                                    rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) - lAmount
                                                    rsSS.Update
                                                    subSendMsg "&GYou transfer " & lAmount & " colonists to your homeworld.", zPortID
                                                    subSendMsgAreaExcept2 gblzFBGRE & zPlayerName & " transfers " & lAmount & " colonists to " & zTranslateGender(zGender, 2) & " homeworld.", lPX, lPY, lPZ, zPortID, ""
                                                Else
                                                    subSendMsg "&RYou have no colonists aboard.", zPortID
                                                End If
                                            End If
                                        Else
                                            subSendMsg "&Rcomputer reports, 'that mass not suitable for colonization.'", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not aboard your starship.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsg "&wYou have to stand to use that command.", zPortID
                                End If
                            Case "XFER", "TRAN"
                                If (lStatus = 5) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT ColonistsPlayerID, ColonistAllowed, ColonistsAboard, ColonistsNumber, X, Y, Z FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                    If (Not rsSS.EOF) Then
                                        If (MyCInt(rsSS!ColonistAllowed) <> 0) Then
                                            If (MyCLng(rsSS!ColonistsPlayerID) = lPlayerID) Then
                                                If (MyCLng(rsSS!ColonistsNumber) > 0) Then
                                                    rsSS.Edit
                                                    If (lAmount < 1 Or lAmount > MyCLng(rsSS!ColonistsNumber) Or zX = "MAX" Or zX = "FULL" Or zX = "ALL") Then lAmount = MyCLng(rsSS!ColonistsNumber)
                                                    lColonistCalcu = MyCLng(rsSS!ColonistsNumber) - lAmount
                                                    rsSS!ColonistsNumber = lColonistCalcu
                                                    rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) + lAmount
                                                    
                                                    subSendMsg "&WYou transfer " & lAmount & " colonists aboard from your homeworld.", zPortID
                                                    subSendMsgAreaExcept2 "&W" & zPlayerName & " transfers " & lAmount & " colonists aboard from " & zTranslateGender(zGender, 2) & " homeworld.", lPX, lPY, lPZ, zPortID, ""
                                                    rsSS.Update
                                                Else
                                                    subSendMsg "&RComputer informs, 'You have no colonists aboard your homeword.'", zPortID
                                                    subSendMsgAreaExcept2 "&RComputer informs " & zPlayerName & " that " & zTranslateGender(zGender, 50) & " has no available homeworld colonists.", lPX, lPY, lPZ, zPortID, ""
                                                End If
                                            Else
                                                subSendMsgAreaExcept2 "&RINTRUDER ALERT ON HOMEWORLD!", lPX, lPY, lPZ, "", ""
                                            End If
                                        Else
                                            subSendMsg "&Rcomputer reports, 'that mass not suitable for colonization.'", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not aboard your starship.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsg "&wYou have to stand to use that command.", zPortID
                                End If
                            Case "WORT", "HOWM", "VALU", "GOLD", "MONE", "APPR" 'worth/value/gold appraisal ship status - shows all levels and fuel
                                Set rsSS = MyDB.OpenRecordset("SELECT CloakingDeviceLevel, ColonistsAboard, SSRepulsorLevel, SSScanLevel, SSLaserOnline, SSPowerLevel, SSBatteryLevel, AreaName, X, Y, Z, SSFuel, SSEngineLevel, SSEngineCruise, SSLaserLevel, SSMinesLevel, SSNX, SSNY, SSNZ, SSN, SSPLockX, SSPLockY, SSPLockZ, SSTLockX, SSTLockY, SSTLockZ, SSShieldLevel, SSShieldIntegrity, SSHullLevel, SSHullIntegrity FROM tblArea WHERE (PlayerID<>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
                                If (Not rsSS.EOF) Then
                                    lDistanceToGo = Abs(MyCLng(rsSS!SSNX) - MyCLng(rsSS!x)) + Abs(MyCLng(rsSS!SSNY) - MyCLng(rsSS!y)) + Abs(MyCLng(rsSS!SSNZ) - MyCLng(rsSS!z))
                                    iArrived = (MyCLng(rsSS!x) = MyCLng(rsSS!SSNX) And MyCLng(rsSS!y) = MyCLng(rsSS!SSNY) And MyCLng(rsSS!z) = MyCLng(rsSS!SSNZ))
                                    subSendMsgAreaAll "&W" & MyCStr(rsSS!AreaName) & " value," & vbCrLf & "&wHull      $" & (MyCLng(rsSS!SSHullLevel) * gbllSSGoldCostHullUpgrade) & vbCrLf & "Scanner   $" & (MyCLng(rsSS!SSScanLevel) * gbllSSGoldCostScanUpgrade) & vbCrLf & "Shields   $" & (MyCLng(rsSS!SSShieldLevel) * gbllSSGoldCostShieldUpgrade) & vbCrLf & "Phasers   $" & (MyCLng(rsSS!SSLaserLevel) * gbllSSGoldCostLaserUpgrade) & vbCrLf & "Cloaking  $" & (MyCLng(rsSS!CloakingDeviceLevel) * gbllSSGoldCostCloakingUpgrade) & vbCrLf & "Power Lvs $" & (MyCLng(rsSS!SSPowerLevel) * gbllSSGoldCostPowerLevelUpgrade) & vbCrLf & "Battery   $" & (MyCLng(rsSS!SSBatteryLevel) * gbllSSGoldCostBatteryUpgrade) & vbCrLf & "Repulsor  $" & (MyCLng(rsSS!SSRepulsorLevel) * gbllSSGoldCostRepulsorUpgrade) & vbCrLf _
                                        & "Mine      $" & (MyCLng(rsSS!SSMinesLevel) * gbllSSGoldCostPMinesUpgrade) & vbCrLf & "Engine    $" & (MyCLng(rsSS!SSEngineLevel) * gbllSSGoldCostEngineUpgrade) _
                                        & vbCrLf & "==============================" & vbCrLf & "Total     " & Format(MyCStr((MyCLng(rsSS!SSBatteryLevel) * gbllSSGoldCostBatteryUpgrade) + (MyCLng(rsSS!SSPowerLevel) * gbllSSGoldCostPowerLevelUpgrade) + MyCLng(rsSS!SSHullLevel) * gbllSSGoldCostHullUpgrade) + (MyCLng(rsSS!SSScanLevel) * gbllSSGoldCostScanUpgrade) + (MyCLng(rsSS!SSShieldLevel) * gbllSSGoldCostShieldUpgrade) + (MyCLng(rsSS!SSLaserLevel) * gbllSSGoldCostLaserUpgrade) + (MyCLng(rsSS!SSMinesLevel) * gbllSSGoldCostPMinesUpgrade) + (MyCLng(rsSS!SSEngineLevel) * gbllSSGoldCostEngineUpgrade) + (MyCLng(rsSS!CloakingDeviceLevel) * gbllSSGoldCostCloakingUpgrade) + (MyCLng(rsSS!SSRepulsorLevel) * gbllSSGoldCostRepulsorUpgrade), "CURRENCY"), lPX, lPY, lPZ
                                    'If (MyCLng(rsSS!SSLaserOnline) <> 0) Then subSendMsgAreaAll gblzFNYEL & MyCStr(rsSS!AreaName) & " has her phasers trained on x" & MyCLng(rsSS!SSPLockX) & " y" & MyCLng(rsSS!SSPLockY) & " z" & MyCLng(rsSS!SSPLockZ) & ".", lPX, lPY, lPZ
                                Else
                                    subSendMsg "&gYou need to be aboard a starship to see its value.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "FAST", "FREE", "BATT", "RECH", "DELA", "COMM"
                                'lPlayerID
                                If (lStarshipCommandDelay > 0) Then
                                    If (lLearnPoints > 0) Then
                                        lStarshipCommandDelay = 0
                                        MyDB.Execute "UPDATE tblPlayer SET StarshipCommandDelay=0, LearnPoints=[LearnPoints]-1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        subSendMsg "&A'[-1lps] Your starship battery is now fully recharged!'", zPortID
                                    Else
                                        subSendMsg "&gYou require one learnpoint to fully recharge your starship battery!", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYour starship battery is already fully recharged and ready, Sir!", zPortID
                                End If
                            Case "STAT" 'ship status - shows all levels and fuel
                                Set rsSS = MyDB.OpenRecordset("SELECT PlayerID, SSMobShipHostileTotal, SSGloryTotal, SSMobShipKillTotal, SSPowerLevel, SSBatteryLevel, SSRepulsorLevel, CloakingDeviceLevel, CloakingDeviceDuration, ColonistsAboard, SSRepulsorLevel, SSScanLevel, SSLaserOnline, AreaName, X, Y, Z, SSFuel, SSEngineLevel, SSEngineCruise, SSLaserLevel, SSMinesLevel, SSNX, SSNY, SSNZ, SSN, SSPLockX, SSPLockY, SSPLockZ, SSTLockX, SSTLockY, SSTLockZ, SSShieldLevel, SSShieldIntegrity, SSHullLevel, SSHullIntegrity FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
                                If (Not rsSS.EOF) Then
                                    lDistanceToGo = Abs(MyCLng(rsSS!SSNX) - MyCLng(rsSS!x)) + Abs(MyCLng(rsSS!SSNY) - MyCLng(rsSS!y)) + Abs(MyCLng(rsSS!SSNZ) - MyCLng(rsSS!z))
                                    iArrived = (MyCLng(rsSS!x) = MyCLng(rsSS!SSNX) And MyCLng(rsSS!y) = MyCLng(rsSS!SSNY) And MyCLng(rsSS!z) = MyCLng(rsSS!SSNZ))
                                    lSSHullIntegrity = MyCLng(rsSS!SSHullIntegrity)
                                    lSSLaserLevel = MyCLng(rsSS!SSLaserLevel)
                                    
                                    zMsg = "&W" & MyCStr(rsSS!AreaName) & "&w [glory(" & MyCLng(rsSS!SSGloryTotal) & ") mobships(" & MyCLng(rsSS!SSMobShipKillTotal) & ") hostiles(" & MyCLng(rsSS!SSMobShipHostileTotal) & ")]" & vbCrLf
                                    Select Case (lSSHullIntegrity)
                                        Case 1 To 20
                                            zMsg = zMsg & "&wHull Level       " & MyCLng(rsSS!SSHullLevel) & " [" & "&R" & lSSHullIntegrity & "%&w] [CRIPPLED]" & vbCrLf
                                        Case 21 To 79
                                            zMsg = zMsg & "&wHull Level       " & MyCLng(rsSS!SSHullLevel) & " [&Y" & lSSHullIntegrity & "%&w] [DAMAGED]" & vbCrLf
                                        Case 80 To 100
                                            zMsg = zMsg & "&wHull Level       " & MyCLng(rsSS!SSHullLevel) & " [" & gblzFBGRE & lSSHullIntegrity & "&w%]" & vbCrLf
                                        Case Else
                                            zMsg = zMsg & "&wHull Level       " & MyCLng(rsSS!SSHullLevel) & " [" & "&R" & lSSHullIntegrity & "%&w] [REPAIR AT 0 0 -705]" & vbCrLf
                                    End Select
                                    lRollA = MyCLng(MyCLng(rsSS!SSScanLevel) / 15) - MyCLng(rsSS!CloakingDeviceLevel)
                                    zMsg = zMsg & "Scanner Level    " & MyCLng(rsSS!SSScanLevel)
                                    If (lRollA < 9) Then
                                        zMsg = zMsg & " [s9"
                                    Else
                                        zMsg = zMsg & " [s" & lRollA
                                    End If
                                    Select Case MyCLng(MyCLng(rsSS!SSScanLevel) / 15)
                                        Case 0 To 8
                                            zMsg = zMsg & "/9%]" & vbCrLf
                                        Case Else
                                            zMsg = zMsg & "/" & MyCLng(MyCLng(rsSS!SSScanLevel) / 15) & "%]" & vbCrLf
                                    End Select
                                    zMsg = zMsg & "Cloaking Device  " & MyCLng(rsSS!CloakingDeviceLevel) & " - " & MyCLng(rsSS!CloakingDeviceDuration) & " rnds " & vbCrLf
                                    
                                    lStarshipCommandDelay = lReturnStarshipCommandDelay(MyCLng(rsSS!PlayerID))
                                    If (MyCLng(rsSS!SSPowerLevel) <= MyCLng(rsSS!SSBatteryLevel)) Then
                                        'Good power flow
                                        zMsg = zMsg & "Power Level      " & MyCLng(rsSS!SSPowerLevel) & "&g [good power flow]&w" & vbCrLf
                                        zMsg = zMsg & "Battery Level    " & MyCLng(rsSS!SSBatteryLevel)
                                    Else
                                        zMsg = zMsg & "&yPower Level      " & strForceSize(MyCStr(rsSS!SSPowerLevel), 9, " ", "A") & " [system is drawing too much power]&w" & vbCrLf
                                        zMsg = zMsg & "&rBattery Level    " & strForceSize(MyCStr(rsSS!SSBatteryLevel), 9, " ", "A") & " [starship requires " & (MyCLng(rsSS!SSPowerLevel) - MyCLng(rsSS!SSBatteryLevel)) & " more battery components]"
                                    End If
                                    Select Case (lStarshipCommandDelay > 0)
                                        Case True
                                            zMsg = zMsg & "&B 50[~" & MyCLng((lStarshipCommandDelay * 100) / 50) & "%]&w" & vbCrLf
                                        Case Else
                                            zMsg = zMsg & "&G (^)&w" & vbCrLf
                                    End Select
                                    zMsg = zMsg & "Repulsor Level   " & MyCLng(rsSS!SSRepulsorLevel)
                                    subSendMsgAreaAll zMsg, lPX, lPY, lPZ
                                    
                                    zMsg = "Shields Level    "
                                    If (lngSQLRecordCount("SELECT TOP 1 AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE ((Len(DamageEmote)>0) AND (XS<=" & lPX & " AND XE>=" & lPX & ") AND (YS<=" & lPY & " AND YE>=" & lPY & ") AND (ZS<=" & lPZ & " AND ZE>=" & lPZ & ") AND (RepairPort=False));") > 0) Then
                                        zMsg = zMsg & lElementalResistance(MyCLng(rsSS!SSShieldLevel), cstlMaxStarshipShieldNebularHullIntegrityDamage) & "/" & MyCLng(rsSS!SSShieldLevel) & " [nebular-ions]" & vbCrLf
                                    Else
                                        zMsg = zMsg & MyCLng(rsSS!SSShieldLevel) & vbCrLf
                                    End If
                                    
                                    zMsg = zMsg & "Phasers Level    "
                                    If (lngSQLRecordCount("SELECT TOP 1 AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE ((Len(DamageEmote)>0) AND (XS<=" & lPX & " AND XE>=" & lPX & ") AND (YS<=" & lPY & " AND YE>=" & lPY & ") AND (ZS<=" & lPZ & " AND ZE>=" & lPZ & ") AND (RepairPort=False));") > 0) Then
                                        lSSLaserLevel = lElementalResistance(lSSLaserLevel, (100 - lSSHullIntegrity)) 'lasers will only function as good as the hull lets them
                                        zMsg = zMsg & lSSLaserLevel & "/" & MyCLng(rsSS!SSLaserLevel)
                                    Else
                                        If (lSSHullIntegrity <= cstlMaxStarshipPhaserHullIntegrityDamage) Then
                                            lSSLaserLevel = lElementalResistance(lSSLaserLevel, (100 - lSSHullIntegrity)) 'lasers will only function as good as the hull lets them
                                            zMsg = zMsg & lSSLaserLevel & "/" & MyCLng(rsSS!SSLaserLevel)
                                        Else
                                            zMsg = zMsg & lSSLaserLevel
                                        End If
                                    End If
                                    lRollA = MyCLng(lSSLaserLevel / cstlLaserReducedSigDivider) - MyCLng(rsSS!CloakingDeviceLevel)
                                    If (lRollA < 9) Then
                                        zMsg = zMsg & " [lock s9%]" & vbCrLf
                                    Else
                                        zMsg = zMsg & " [lock s" & lRollA & "%]" & vbCrLf
                                    End If
                                    
                                    zMsg = zMsg & "Proxy Mine Level " & MyCLng(rsSS!SSMinesLevel) & " [s0%]" & vbCrLf
                                    lRollA = MyCLng(rsSS!SSEngineLevel) - MyCLng(rsSS!CloakingDeviceLevel)
                                    zMsg = zMsg & "Engine Level     " & MyCLng(rsSS!SSEngineLevel)
                                    If (lRollA < 9) Then
                                        zMsg = zMsg & " [s9% when cloaked]" & vbCrLf
                                    Else
                                        zMsg = zMsg & " [s" & lRollA & "%]" & vbCrLf
                                    End If
                                    zMsg = zMsg & "      Warp Speed " & MyCLng(rsSS!SSEngineCruise) & vbCrLf
                                    zMsg = zMsg & "[dest x" & MyCStr(rsSS!SSNX) & " y" & MyCStr(rsSS!SSNY) & " z" & MyCStr(rsSS!SSNZ) & "] d[" & MyCStr(lDistanceToGo) & "] ARRIVED(" & basBoolean(iArrived) & ")" & vbCrLf
                                    zMsg = zMsg & "[loca x" & MyCStr(rsSS!x) & " y" & MyCStr(rsSS!y) & " z" & MyCStr(rsSS!z) & "]      MOVING(" & basBoolean((MyCInt(rsSS!SSN) <> 0)) & ")" & vbCrLf
                                    zMsg = zMsg & "Colonists Aboard " & MyCLng(rsSS!ColonistsAboard) & vbCrLf
                                    zMsg = zMsg & "Deuterium Fuel   " & MyCLng(rsSS!SSFuel)
                                    subSendMsgAreaAll zMsg, lPX, lPY, lPZ
                                    
                                    If (MyCInt(rsSS!SSLaserOnline) <> 0) Then
                                        subSendMsgAreaAll "&yPhasers [locked] " & MyCStr(zReturnAreaNameXYZ(MyCLng(rsSS!SSPLockX), MyCLng(rsSS!SSPLockY), MyCLng(rsSS!SSPLockZ)) & " [d") & lReturnDistanceSpacial(lPX, lPY, lPZ, MyCLng(rsSS!SSPLockX), MyCLng(rsSS!SSPLockY), MyCLng(rsSS!SSPLockZ)) & "] [" & MyCLng(rsSS!SSPLockX) & " " & MyCLng(rsSS!SSPLockY) & " " & MyCLng(rsSS!SSPLockZ) & "]", lPX, lPY, lPZ
                                    Else
                                        subSendMsgAreaAll "&yPhasers offline, more repairs may be required.", lPX, lPY, lPZ
                                    End If
                                Else
                                    subSendMsg "&gYou need to be aboard a starship to see its status.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "HEAL", "COMP", "NANI"
                                Set rsSS = MyDB.OpenRecordset("SELECT SSHullIntegrity, HeatAreaLevel, GasAreaLevelDesc, GasAreaLevel, RadiatedAreaLevel, GravityLevel, OxygenRequiredLevel, AreaName, X, Y, Z, ColonistsAboard, SSScanLevel FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType>0);", dbOpenDynaset) 'we want to be able to heal any colony targets
                                If (Not rsSS.EOF) Then
                                    Set rsObject = MyDB.OpenRecordset("SELECT tblObject.SSRepairLevel, tblObject.ObjectID, tblObject.ObjectName, tblObject.SSCryogenic, tblPlayerInventoryItems.PlayerID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.SSRepairLevel)>0) AND ((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ")) ORDER BY tblObject.ObjectName;", dbOpenSnapshot)
                                    If (Not rsObject.EOF) Then
                                        subSendMsgAreaAll "&B'Nanites absorb into " & MyCStr(rsSS!AreaName) & "'", lPX, lPY, lPZ
                                        lSSHullIntegrity = MyCLng(rsSS!SSHullIntegrity) + 1
                                        If (lSSHullIntegrity < 1) Then lSSHullIntegrity = 1
                                        If (lSSHullIntegrity > 100) Then lSSHullIntegrity = 100
                                        rsSS.Edit 'Load the Cryogenic into the space ship
                                        rsSS!SSHullIntegrity = lSSHullIntegrity
                                        If (MyCLng(rsSS!OxygenRequiredLevel) > 0) Then
                                            rsSS!OxygenRequiredLevel = MyCLng(rsSS!OxygenRequiredLevel) - 1
                                            subSendMsgAreaAll "&B'A hole through the hull seals.'", lPX, lPY, lPZ
                                        End If
                                        
                                        If (MyCLng(rsSS!RadiatedAreaLevel) > 0) Then
                                            rsSS!RadiatedAreaLevel = MyCLng(rsSS!RadiatedAreaLevel) - 1
                                            subSendMsgAreaAll "&B'The radiation in the area drops one level.'", lPX, lPY, lPZ
                                        End If
                                        
                                        If (MyCLng(rsSS!HeatAreaLevel) > 0) Then
                                            rsSS!HeatAreaLevel = MyCLng(rsSS!HeatAreaLevel) - 1
                                            Select Case (MyCLng(rsSS!HeatAreaLevel))
                                                Case 1
                                                    subSendMsgAreaAll "&B'The nanites extinguish a level one fire in the area.'", lPX, lPY, lPZ
                                                Case Else
                                                    subSendMsgAreaAll "&B'The fire in the area grows smaller.'", lPX, lPY, lPZ
                                            End Select
                                        End If
                                        
                                        Select Case (MyCLng(rsSS!GasAreaLevel))
                                            Case 0
                                            Case 1
                                                rsSS!GasAreaLevel = 0
                                                subSendMsgAreaAll "&B'Gas [" & MyCStr(rsSS!GasAreaLevelDesc) & "] is no longer in the area.'", lPX, lPY, lPZ
                                                rsSS!GasAreaLevelDesc = ""
                                            Case Else
                                                rsSS!GasAreaLevel = MyCLng(rsSS!GasAreaLevel) - 1
                                                subSendMsgAreaAll "&B'Gas [" & MyCStr(rsSS!GasAreaLevelDesc) & "] drops a level.'", lPX, lPY, lPZ
                                        End Select
                                        rsSS.Update
                                        
                                        'Remove the Cryogenic from the player's inventory
                                        MyDB.Execute "UPDATE tblObject SET SSRepairLevel=[SSRepairLevel]-1 WHERE (SSRepairLevel>0 AND ObjectID=" & MyCLng(rsObject!ObjectID) & ");", dbFailOnError
                                    Else
                                        subSendMsg "&gYou do not have any repair components in your inventory.", zPortID
                                    End If
                                    Set rsObject = Nothing
                                Else
                                    subSendMsg "&gYou need to be at a colony base to heal it.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "CRYO", "LOAD" 'this will load the ship with deuterium
                                Set rsSS = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z, ColonistsAboard, SSScanLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                If (Not rsSS.EOF) Then
                                    Set rsObject = MyDB.OpenRecordset("SELECT tblObject.ObjectID, tblObject.ObjectName, tblObject.SSCryogenic, tblPlayerInventoryItems.PlayerID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.SSCryogenic)>0) AND ((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ")) ORDER BY tblObject.ObjectName;", dbOpenSnapshot)
                                    If (Not rsObject.EOF) Then
                                        rsSS.Edit 'Load the Cryogenic into the space ship
                                        If (lRandom(MyCLng(rsSS!SSScanLevel) > lRandom(9000))) Then
                                            rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) + (MyCLng(rsObject!SSCryogenic) * 2)
                                            subSendMsgAreaAll "&wthe " & MyCStr(rsSS!AreaName) & " level " & MyCLng(rsSS!SSScanLevel) & " scanners detect" & vbCrLf & "that " & zAdverb(MyCStr(rsObject!ObjectName), 4) & zShortstop(MyCStr(rsObject!ObjectName)) & " was made for that scanner type. [x2]" & (MyCLng(rsObject!SSCryogenic) * 2) & ".", lPX, lPY, lPZ
                                        Else
                                            rsSS!ColonistsAboard = MyCLng(rsSS!ColonistsAboard) + MyCLng(rsObject!SSCryogenic)
                                        End If
                                        rsSS.Update
                                        
                                        'Remove the Cryogenic from the player's inventory
                                        MyDB.Execute "DELETE ObjectID, PlayerID FROM tblPlayerInventoryItems WHERE (ObjectID=" & MyCLng(rsObject!ObjectID) & " AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "DELETE ObjectID FROM tblObject WHERE (ObjectID=" & MyCLng(rsObject!ObjectID) & ");", dbFailOnError
                                        subSendMsgAreaAll gblzFNWHI & MyCStr(rsSS!AreaName) & " materializes " & zAdverb(MyCStr(rsObject!ObjectName), 4) & zShortstop(MyCStr(rsObject!ObjectName)) & " into the cryogenic tank.", lPX, lPY, lPZ
                                        
                                        subRecalculatePlayerEquipment lPlayerID, zPortID 'beam Cryogenic needs this to recalculate weight
                                    Else
                                        subSendMsg "&gYou do not have any cryogenic chambers with you.", zPortID
                                    End If
                                    Set rsObject = Nothing
                                Else
                                    subSendMsg "&gYou need to be on board your starship to Cryogenic it.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "FUEL", "FILL" 'this will load the ship with deuterium
                                Set rsSS = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z, SSFuel, SSEngineLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                If (Not rsSS.EOF) Then
                                    Set rsObject = MyDB.OpenRecordset("SELECT tblObject.ObjectID, tblObject.ObjectName, tblObject.SSFuel, tblPlayerInventoryItems.PlayerID, tblObject.CanSellItem FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.CanSellItem)=True) AND ((tblObject.SSFuel)>0) AND ((tblPlayerInventoryItems.PlayerID)=" & lPlayerID & ")) ORDER BY tblObject.ObjectName;", dbOpenSnapshot)
                                    If (Not rsObject.EOF) Then
                                        rsSS.Edit 'Load the fuel into the space ship
                                        If (lRandom(MyCLng(rsSS!SSEngineLevel) > lRandom(7000))) Then
                                            rsSS!SSFuel = MyCLng(rsSS!SSFuel) + (MyCLng(rsObject!SSFuel) * 2)
                                            subSendMsgAreaAll "&wthe " & MyCStr(rsSS!AreaName) & " level " & MyCLng(rsSS!SSEngineLevel) & " engines detect" & vbCrLf & "that " & zAdverb(MyCStr(rsObject!ObjectName), 4) & zShortstop(MyCStr(rsObject!ObjectName)) & " was made for that engine type. [x2]" & (MyCLng(rsObject!SSFuel) * 2) & ".", lPX, lPY, lPZ
                                        Else
                                            rsSS!SSFuel = MyCLng(rsSS!SSFuel) + MyCLng(rsObject!SSFuel)
                                        End If
                                        
                                        rsSS.Update
                                        'Remove the fuel from the player's inventory
                                        MyDB.Execute "DELETE ObjectID, PlayerID FROM tblPlayerInventoryItems WHERE (ObjectID=" & MyCLng(rsObject!ObjectID) & " AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "DELETE ObjectID FROM tblObject WHERE (ObjectID=" & MyCLng(rsObject!ObjectID) & ");", dbFailOnError
                                        subSendMsgAreaAll gblzFNWHI & MyCStr(rsSS!AreaName) & " materializes " & zAdverb(MyCStr(rsObject!ObjectName), 4) & zShortstop(MyCStr(rsObject!ObjectName)) & " into the fuel tank.", lPX, lPY, lPZ
                                        
                                        subRecalculatePlayerEquipment lPlayerID, zPortID 'beam fuel needs this to recalculate weight
                                    Else
                                        subSendMsg "&gYou do not have any deuterium fuel with you." & vbCrLf & "That or the fuel item is a KEEP item and you need to UNKEEP it.", zPortID
                                    End If
                                    Set rsObject = Nothing
                                Else
                                    subSendMsg "&gYou need to be on board your starship to fuel it.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "BOAR"
                                Select Case zAreaRules(14, lPX, lPY, lPZ)
                                    Case "0" 'No beam zone
                                        subSendMsg "&RThis is a no starship zone.", zPortID
                                    Case "1" 'Allowed
                                        Set rsSS = MyDB.OpenRecordset("SELECT X, Y, Z, WhereID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenSnapshot)
                                        If (Not rsSS.EOF) Then
                                            If (lPX = MyCLng(rsSS!x) And lPY = MyCLng(rsSS!y) And lPZ = MyCLng(rsSS!z)) Then
                                                subSendMsg "&WYou are already onboard your starship.", zPortID
                                            Else
                                                MyDB.Execute "UPDATE tblPlayer SET WhereID=" & MyCLng(rsSS!WhereID) & ", X=" & MyCLng(rsSS!x) & ", Y=" & MyCLng(rsSS!y) & ", Z=" & MyCLng(rsSS!z) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                subSendMsg "&W" & gblzMAPPEROFFCODE & " You beam aboard your starship - 'Welcome aboard captain!'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " materializes in front of you!", MyCLng(rsSS!x), MyCLng(rsSS!y), MyCLng(rsSS!z), zPortID, ""
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " dematerializes!", lPX, lPY, lPZ, zPortID, ""
                                                'subSendMsgAreaAllDISmart "&y", zOPlayerName, "%s1 stun " & zMobName & ".", "", "%s1 stuns " & zMobName & ".", lOX, lOY, lOZ
                                            End If
                                        Else
                                            subSendMsg "&gYou do not have this technology, yet.", zPortID
                                        End If
                                        Set rsSS = Nothing
                                End Select
                            Case "BEAM"
                                If (Len(zX) = 0) Then
                                    If (lStatus = 5) Then
                                        Set rsSS = MyDB.OpenRecordset("SELECT X, Y, Z FROM tblArea WHERE (PlayerID<>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot) 'any player can beam down from another's starship
                                        If (Not rsSS.EOF) Then
                                            Set rsBeamArea = MyDB.OpenRecordset("SELECT TOP 1 tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.WhereID, tblArea.AreaTrapID, tblArea.ClanID, tblArea.FlyLevel, tblArea.Underwater FROM tblArea WHERE (((tblArea.X)=" & lPX & ") AND ((tblArea.Y)=" & lPY & ") AND ((tblArea.Z)>" & lPZ & " And (tblArea.Z)<" & lPZ + cstlBeamDistance & ")) ORDER BY tblArea.Z;", dbOpenSnapshot)  'any player can beam down from another's starship
                                            If (Not rsBeamArea.EOF) Then 'this also checks doors
                                                Select Case zAreaRules(14, MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z))
                                                    Case "0" 'No beam zone
                                                        subSendMsg "&Rcomputer reports, 'that mass is a no beam zone.'", zPortID
                                                    Case "1" 'Allowed
                                                        If (bAreaIsDeadlyTrap(MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z))) Then
                                                            subSendMsg "&aABORTED - &RBeaming device detects too much danger below!", zPortID
                                                        Else
                                                        If (MyCLng(rsBeamArea!FlyLevel) = 0) Then
                                                        If (MyCLng(rsBeamArea!Underwater) = 0) Then
                                                            If (MyCLng(rsBeamArea!ClanID) = 0) Then
                                                                If (MyCLng(rsBeamArea!AreaTrapID) <> 0) Then
                                                                    MyDB.Execute "UPDATE tblPlayer SET AreaTrapID=" & MyCLng(rsBeamArea!AreaTrapID) & ", AreaTrapDuration=" & (lRandom(3) + 2) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                End If
                                                                MyDB.Execute "UPDATE tblPlayer SET WhereID=" & MyCLng(rsBeamArea!WhereID) & ", X=" & MyCLng(rsBeamArea!x) & ", Y=" & MyCLng(rsBeamArea!y) & ", Z=" & MyCLng(rsBeamArea!z) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                subSendMsg "&WYou dematerialize then beam down!", zPortID
                                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " dematerializes and beams down!", lPX, lPY, lPZ, zPortID, ""
                                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " beams into the area and materializes in front of you!", MyCLng(rsBeamArea!x), MyCLng(rsBeamArea!y), MyCLng(rsBeamArea!z), zPortID, ""
                                                                If (bPlayerOnAnyStarship(zPortID)) Then
                                                                    subSendMsg "&w" & gblzMAPPEROFFCODE & " Mapper Logging, deactivated..." & vbCrLf & "Running the mapper is not a good idea when on starships.", zPortID
                                                                Else
                                                                    subSendMsg "&w" & gblzMAPPERONCODE & " Mapper Logging, activated." & vbCrLf & "Running the mapper is not a good idea when on starships.", zPortID
                                                                End If
                                                            Else
                                                                subSendMsg "&RClanhall beaming is forboten until further notice!", zPortID
                                                            End If
                                                        Else
                                                            subSendMsg "&RBeam device is useless near water zones!", zPortID
                                                        End If
                                                        Else
                                                            subSendMsg "&RBeam device is useless near caverns!", zPortID
                                                        End If
                                                        End If 'bAreaIsDeadlyTrap
                                                End Select
                                            Else
                                                subSendMsg "&gThe transporter computer doesn't detect any land masses below your ship within [" & cstlBeamDistance & "] parsecs", zPortID
                                                subSendMsgAreaExcept2 gblzFNGRE & zPlayerName & " works with the transporter system, then gives up.", lPX, lPY, lPZ, zPortID, ""
                                            End If
                                            Set rsBeamArea = Nothing
                                        Else
                                            subSendMsg "&gYou are not aboard a starship.", zPortID
                                        End If
                                        Set rsSS = Nothing
                                    Else
                                        subSendMsg "&wYou have to stand to use that command.", zPortID
                                    End If
                                Else 'we can beam a mob aboard
                                    subSendMsg "&wUsing scan range to find a suitable target...", zPortID
                                    subFleetBeamAboard lPX, lPY, lPZ, lPlayerLevel, lEssence, lMana, lPlayerID, MyCStr(zX) + " " + MyCStr(zY) + " " + MyCStr(zZ), lStarshipCommandDelay, 1, zPortID
                                End If
                            Case "UGE" 'UpGrade Engines
                                subFleetCommandUGE zPlayerName, lCX, lPX, lPY, lPZ, lPlayerID, lPGold, gbllSSGoldCostEngineUpgrade, zPortID 'slowly moving some of this long code into its only private PROCs
                            Case "UGL", "UGP" 'UpGrade Lasers/Phasers
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'any player can beam down from another's starship
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (lCX * gbllSSGoldCostLaserUpgrade)) Then
                                            If (lngSQLRecordCount("SELECT SSLaserLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSLaserLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSLaserLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a phaser chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSLaserLevel = MyCLng(rsSS!SSLaserLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostLaserUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                    'rgsPlayer!Gold = MyCLng(rgsPlayer!Gold) - (gbllSSGoldCostLaserUpgrade * lCX)
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced phaser components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " phaser upgrades!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostLaserUpgrade * lCX & " gold to upgrade your phasers.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGM" 'UpGrade Lasers
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'any player can beam down from another's starship
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostPMinesUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT SSMinesLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSMinesLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSMinesLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a proximity mine chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSMinesLevel = MyCLng(rsSS!SSMinesLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostPMinesUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced proximity mine components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " proximity mine upgrades!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostPMinesUpgrade * lCX & " gold to upgrade your proximity mines.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGS" 'UpGrade Shield
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'any player can beam down from another's starship
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostShieldUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT SSShieldLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSShieldLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSShieldLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a shield chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSShieldLevel = MyCLng(rsSS!SSShieldLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostShieldUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced shield components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " shield upgrades!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostShieldUpgrade * lCX & " gold to upgrade your shields.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGH" 'UpGrade Hull
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'any player can beam down from another's starship
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostHullUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT SSHullLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSHullLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSHullLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a hull armour chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSHullLevel = MyCLng(rsSS!SSHullLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostHullUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced hull armour components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " hull armour upgrades!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostHullUpgrade * lCX & " gold to upgrade your hull armour.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGC" 'UpGrade Scanners
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'any player can beam down from another's starship
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostScanUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT SSScanLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSScanLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSScanLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a scanner chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSScanLevel = MyCLng(rsSS!SSScanLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostScanUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced scanning components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " scanning components!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostScanUpgrade * lCX & " gold to upgrade your scanners.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGR" 'Upgrade Repulsor gbllSSGoldCostRepulsorUpgrade SSRepulsorLevel
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'purchase starship zone
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostRepulsorUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT SSScanLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSRepulsorLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSRepulsorLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a repulsor device chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSRepulsorLevel = MyCLng(rsSS!SSRepulsorLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostRepulsorUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced repulsor device components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " repulsor device components!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostRepulsorUpgrade * lCX & " gold to upgrade your repulsor device.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGO" 'PowerLevel
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'purchase starship zone
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostPowerLevelUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSPowerLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSPowerLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a power system was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSPowerLevel = MyCLng(rsSS!SSPowerLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostPowerLevelUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced power level device components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " power level components!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostPowerLevelUpgrade * lCX & " gold to upgrade your power levels.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGB" 'Battery
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'purchase starship zone
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostBatteryUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSBatteryLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!SSBatteryLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a battery was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!SSBatteryLevel = MyCLng(rsSS!SSBatteryLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostBatteryUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced battery device components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " battery components!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostBatteryUpgrade * lCX & " gold to upgrade your power levels.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "UGK" 'UpGrade Cloaking
                                If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
                                If (lCX > 200) Then lCX = 200
                                Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'purchase starship zone
                                If (Not rsBeamArea.EOF) Then
                                    If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
                                        If (lPGold >= (gbllSSGoldCostCloakingUpgrade * lCX)) Then
                                            If (lngSQLRecordCount("SELECT PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                                                Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, CloakingDeviceLevel, CloakingDeviceDuration FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                                                If (Not rsSS.EOF) Then
                                                    rsSS.Edit
                                                    If (MyCLng(rsSS!CloakingDeviceLevel) = 0) Then
                                                        subSendMsg "&WEngineering reports, 'a cloaking device chassis was installed into your ship.'", zPortID
                                                    End If
                                                    rsSS!CloakingDeviceLevel = MyCLng(rsSS!CloakingDeviceLevel) + lCX
                                                    rsSS.Update
                                                    
                                                    MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostCloakingUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                End If
                                                Set rsSS = Nothing
                                                subSendMsg "&WEngineering reports, '" & lCX & " advanced cloaking device components were installed into your ship.'", zPortID
                                                subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " cloaking device components!", lPX, lPY, lPZ, zPortID, ""
                                            Else
                                                subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYou need " & gbllSSGoldCostCloakingUpgrade * lCX & " gold to upgrade your cloaking device.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gYou are not at a starport.", zPortID
                                    End If
                                Else
                                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                                End If
                                Set rsBeamArea = Nothing
                            Case "CLOA"
                                Set rsSS = MyDB.OpenRecordset("SELECT SSLaserOnline, SSFuel, SSEngineLevel, AreaName, SSEngineCruise, SSN, CloakingDeviceLevel, CloakingDeviceDuration, X, Y, Z FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenDynaset)
                                If (Not rsSS.EOF) Then
                                    If (MyCLng(rsSS!SSFuel) > 8) Then
                                        If (MyCLng(rsSS!CloakingDeviceLevel) > 0) Then
                                            If (MyCLng(rsSS!CloakingDeviceDuration) > 0) Then
                                                If (MyCLng(rsSS!CloakingDeviceDuration) > 9) Then
                                                    subSendMsgAreaAll "&aCloaking device is powering down...", lPX, lPY, lPZ
                                                    rsSS.Edit
                                                    rsSS!CloakingDeviceDuration = 9
                                                    rsSS.Update
                                                Else
                                                    subSendMsgAreaAll "&aCloaking device is powering down...One moment please.", lPX, lPY, lPZ
                                                End If
                                            Else
                                                If (bFleetCombatCloaking(lPlayerID, zPortID)) Then
                                                    Select Case (MyCInt(rsSS!SSN) <> 0)
                                                        Case True
                                                            subShipSignature "", MyCStr(rsSS!AreaName) & " [cloaks-warp] w[" & MyCStr(rsSS!SSEngineCruise) & "]", MyCLng(MyCLng(rsSS!SSEngineLevel) / 20), 0, 0, MyCLng(rsSS!x), MyCLng(rsSS!y), MyCLng(rsSS!z), True 'bAllowMobShipReactSig
                                                        Case Else
                                                            subShipSignature "", MyCStr(rsSS!AreaName) & " [cloaks-stationary]", MyCLng(rsSS!SSEngineLevel), 0, 0, MyCLng(rsSS!x), MyCLng(rsSS!y), MyCLng(rsSS!z), True 'bAllowMobShipReactSig
                                                    End Select
                                                    If (MyCLng(rsSS!SSLaserOnline) <> 0) Then subSendMsgAreaAll "&aPower diverted, phasers now offline.", lPX, lPY, lPZ
                                                    rsSS.Edit
                                                    rsSS!CloakingDeviceDuration = MyCLng(rsSS!CloakingDeviceLevel) + 20 + lRandom(30)
                                                    rsSS!SSFuel = MyCLng(rsSS!SSFuel) - 9
                                                    rsSS!SSLaserOnline = False
                                                    rsSS.Update
                                                Else
                                                    subSendMsgAreaAll "&aThe cloaking device is out of energy.", lPX, lPY, lPZ
                                                End If
                                            End If
                                        Else
                                            subSendMsgAreaAll "&RThis ship is not equipped with a cloaking device.", lPX, lPY, lPZ
                                        End If
                                    Else
                                        subSendMsgAreaAll "&a[Fuel short] [f" & (9 - MyCLng(rsSS!SSFuel)) & "/9]", lPX, lPY, lPZ
                                    End If
                                Else
                                    subSendMsg "&gYou need to be aboard your own starship to use cloak.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "FIRE" 'Fire phasers
                                'lErrorFind = lErrorFind + 1
                                bFirePhasers = False
                                lWeaponsSoulBet = lRandom(MyCLng(zX))
                                Set rsSS = MyDB.OpenRecordset("SELECT AreaID, SSHullIntegrity, X, Y, Z, SSFuel, CloakingDeviceDuration, SSLaserLevel, SSMinesLevel, SSLaserOnline, OxygenRequiredLevel, GravityLevel, RadiatedAreaLevel, GasAreaLevel, HeatAreaLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
                                If (Not rsSS.EOF) Then
                                    lSSHullIntegrity = MyCLng(rsSS!SSHullIntegrity)
                                    If (lSSHullIntegrity > 0) Then
                                        'lErrorFind = lErrorFind + 1
                                        If (lngSQLRecordCount("SELECT AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE ((DamageAmt>0) AND (XS<=" & lPX & " AND XE>=" & lPX & ") AND (YS<=" & lPY & " AND YE>=" & lPY & ") AND (ZS<=" & lPZ & " AND ZE>=" & lPZ & ") AND (RepairPort=False));") = 0) Then
                                            lSSLaserLevel = MyCLng(rsSS!SSLaserLevel)
                                            'lErrorFind = lErrorFind + 1
                                             
                                            If (lSSHullIntegrity <= cstlMaxStarshipPhaserHullIntegrityDamage) Then
                                                'lErrorFind = lErrorFind + 10
                                                lSSLaserLevel = lElementalResistance(lSSLaserLevel, (100 - lSSHullIntegrity)) 'lasers will only function as good as the hull lets them
                                                subSendMsgAreaAll "&r'[Phasers] [reduced range] [lv" & MyCStr(lSSLaserLevel) & "/" & MyCStr(rsSS!SSLaserLevel) & "]'", lPX, lPY, lPZ
                                            End If
                                            'lErrorFind = lErrorFind + 5
                                            If (MyCLng(rsSS!SSFuel) >= cstlPhaserFuelCost) Then
                                                'lErrorFind = lErrorFind + 100
                                                If (MyCLng(rsSS!CloakingDeviceDuration) < 1) Then
                                                    If (MyCLng(rsSS!OxygenRequiredLevel) + MyCLng(rsSS!GravityLevel) + MyCLng(rsSS!RadiatedAreaLevel) + MyCLng(rsSS!GasAreaLevel) + MyCLng(rsSS!HeatAreaLevel) < cstlMaxStarshipComponentDamage) Then
                                                        'lErrorFind = lErrorFind + 1000
                                                        'detonation splash range = playerid's playerlevel
                                                        'The distance take one movepoint each
                                                        'damage is in 4 splash ranges - area 1 away is 100%
                                                        If (MyCLng(rsSS!SSLaserLevel) > 0) Then
                                                            'lErrorFind = lErrorFind + 10000
                                                            If (MyCInt(rsSS!SSLaserOnline) <> 0) Then
                                                                'lErrorFind = lErrorFind + 100000
                                                                MyDB.Execute "UPDATE tblArea SET SSFuel=[SSFuel]-" & cstlPhaserFuelCost & " WHERE (AreaID=" & MyCLng(rsSS!AreaID) & ");", dbFailOnError
                                                                'lErrorFind = lErrorFind + 1000000
                                                                bFirePhasers = True
                                                            Else
                                                                subSendMsgAreaAll gblzFNGRE & "'Phasers are offline.'", lPX, lPY, lPZ
                                                            End If
                                                        Else
                                                            subSendMsgAreaAll gblzFNGRE & "'This starship is not equipped with phaser tubes.'", lPX, lPY, lPZ
                                                        End If
                                                    Else
                                                        subSendMsgAreaAll "&R'Argh! The starship is too damaged to fire phasers!'", lPX, lPY, lPZ
                                                    End If
                                                Else
                                                    subSendMsgAreaAll gblzFNGRE & "'The starship cannot fire her phasers while cloaked.'", lPX, lPY, lPZ
                                                End If
                                            Else
                                                If (cstlPhaserFuelCost > 0) Then
                                                    'Traced to here
                                                    zExtraMsg = "[Fuel short] [f(" & (cstlPhaserFuelCost - MyCLng(rsSS!SSFuel)) & "/" & cstlPhaserFuelCost & "]"
                                                    subSendMsgAreaAll "&a" & zExtraMsg, lPX, lPY, lPZ
                                                End If
                                            End If
                                        Else
                                            subSendMsgAreaAll "&RThe starship cannot fire her phasers within a Class B Nebula.", lPX, lPY, lPZ
                                        End If
                                    Else
                                        'rsSS.Edit
                                        'rsSS!SSLaserOnline = False
                                        'rsSS.Update
                                        subSendMsg "&R'Impossible Sir! The phasers are smashed to pieces!'", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYou need to be aboard your own ship to use the weapon systems.", zPortID
                                End If
                                Set rsSS = Nothing
                                
                                If (bFirePhasers) Then
                                    'lErrorFind = lErrorFind + 10000000
                                    subFleetCombat lPlayerID, "P", lWeaponsSoulBet
                                End If
                            Case "PHAS", "LOCK" 'SS PHASERS (player name) - player must be aboard the starship
                                Set rsSS = MyDB.OpenRecordset("SELECT SSHullIntegrity, SSMobshipKillTotal, CloakingDeviceDuration, CloakingDeviceLevel, SSEngineCruise, CloakingDeviceLevel, CloakingDeviceDuration, SSN, AreaName, SSLaserLevel, SSLaserOnline, SSPLockX, SSPLockY, SSPLockZ FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                If (Not rsSS.EOF) Then
                                    lSSHullIntegrity = MyCLng(rsSS!SSHullIntegrity)
                                    If (lSSHullIntegrity > 0) Then
                                        If (MyCLng(rsSS!CloakingDeviceDuration) = 0) Then
                                            If (MyCLng(rsSS!SSLaserLevel) > 0) Then
                                                If (lCX = lPX And lCY = lPY And lCZ = lPZ) Then
                                                    subSendMsgAreaAll "&R'Sir. . .lock onto ourselves?!'", lPX, lPY, lPZ
                                                Else
                                                    If (bFleetLockedShipAllowed(lCX, lCY, lCZ, MyCLng(rsSS!SSMobShipKillTotal))) Then
                                                        rsSS.Edit 'Phasers lock to an area and the blast distance of the game determins if you hit the ship. Ships with their captain onboard can only be hit. If there are two ships in teh area the spalsh damage is split between them.
                                                        rsSS!SSLaserOnline = True
                                                        rsSS!SSPLockX = lCX
                                                        rsSS!SSPLockY = lCY
                                                        rsSS!SSPLockZ = lCZ
                                                        rsSS.Update
                                                        
                                                        lParsecs = MyCStr(Abs(lPX - lCX) + Abs(lPY - lCY) + Abs(lPZ - lCZ))
                                                        
                                                        Select Case (MyCInt(rsSS!SSN) = 0)
                                                            Case True
                                                                subShipSignature "", MyCStr(rsSS!AreaName) & " [Phaser lock-stationary] " & vbCrLf & MyCStr(zReturnAreaNameXYZ(lCX, lCY, lCZ) & " [d" & lParsecs & "]") & " [" & MyCStr(lCX) & " " & MyCStr(lCY) & " " & MyCStr(lCZ) & "]", 9, MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                                                            Case Else
                                                                subShipSignature "", MyCStr(rsSS!AreaName) & " [Phaser lock-warp] " & vbCrLf & MyCStr(zReturnAreaNameXYZ(lCX, lCY, lCZ) & " [d" & lParsecs & "]") & " [" & MyCStr(lCX) & " " & MyCStr(lCY) & " " & MyCStr(lCZ) & "]", MyCLng(MyCLng(rsSS!SSLaserLevel) / 25), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                                                        End Select
                                                    Else
                                                        subSendMsg "&g'Your starship is too powerful to lock onto that type of mobship.'", zPortID
                                                    End If
                                                End If
                                            Else
                                                subSendMsg "&w'There is no phaser chassis onboard this starship.'", zPortID
                                            End If
                                        Else
                                            subSendMsg "&gYour cloaking device must be down to use the weapons system.", zPortID
                                        End If
                                    Else
                                        rsSS.Edit
                                        rsSS!SSLaserOnline = False
                                        rsSS.Update
                                        subSendMsg "&R'Impossible Sir! The targeting computer is smashed to pieces!'", zPortID
                                    End If
                                Else
                                    subSendMsg "&gYou need to be aboard your starship to use the weapons system.", zPortID
                                End If
                                Set rsSS = Nothing
                            Case "VIEW" 'houses can ss view its cool :)
                                subStarshipView zPortID, lPX, lPY, lPZ, True
                            Case "MINE" 'proximity mine drop
                                If (lStarshipCommandDelay = 0) Then
                                    Set rsSS = MyDB.OpenRecordset("SELECT SSFuel, AreaID, AreaName, SSMinesLevel, SSScanLevel, SSPowerLevel, SSBatteryLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenDynaset)
                                    If (Not rsSS.EOF) Then
                                        lFuelCost = (5 + (MyCLng(rsSS!SSMinesLevel) * 5))
                                        If (MyCLng(rsSS!SSFuel) >= lFuelCost) Then
                                            Set rsMines = MyDB.OpenRecordset("SELECT SSShipName FROM tblAreaProximityMines WHERE (AreaProximityMineX=" & lPX & " AND AreaProximityMineY=" & lPY & " AND AreaProximityMineZ=" & lPZ & ");", dbOpenSnapshot)
                                            If (rsMines.EOF) Then
                                                lRollA = (cstlPMinesSoulCost * MyCLng(rsSS!SSMinesLevel))
                                                If (lSoul >= lRollA) Then
                                                    If (lRollA > 0) Then
                                                        subFleetSetCommandDelay MyCLng(rsSS!SSMinesLevel), (MyCLng(rsSS!SSPowerLevel) * 2) + 3000, (MyCLng(rsSS!SSBatteryLevel) * 2) + 3000, lPlayerID
                                                        MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lRollA & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        Set rsSSPMines = MyDB.OpenRecordset("tblAreaProximityMines", dbOpenTable)
                                                        rsSSPMines.AddNew
                                                        rsSSPMines!AreaID = MyCLng(rsSS!AreaID)
                                                        rsSSPMines!SSShipName = MyCStr(rsSS!AreaName)
                                                        rsSSPMines!SSMinesLevel = MyCLng(rsSS!SSMinesLevel)
                                                        rsSSPMines!AreaProximityMineX = lPX
                                                        rsSSPMines!AreaProximityMineY = lPY
                                                        rsSSPMines!AreaProximityMineZ = lPZ
                                                        rsSSPMines!AreaProximityMineDuration = (MyCLng(rsSS!SSMinesLevel) + 25 + lRandom(25))
                                                        rsSSPMines!PlayerID = lPlayerID
                                                        rsSSPMines.Update
                                                        Set rsSSPMines = Nothing
                                                        
                                                        rsSS.Edit
                                                        rsSS!SSFuel = MyCLng(rsSS!SSFuel) - lFuelCost
                                                        rsSS.Update
                                                        subSendMsgAreaAll "&a'Proximity mine [dropped] [s0%] [d0] [" & lPX & " " & lPY & " " & lPZ & "] [-f" & lFuelCost & "]'", lPX, lPY, lPZ
                                                    Else
                                                        subSendMsg "&wOnboard computer reports, 'There is no proximity mine chassis onboard this starship.'", zPortID
                                                    End If
                                                Else
                                                    subSendMsgAreaAll "&aOnboard computer reports, 'The engineer is short " & (lRollA - lSoul) & " soul.'", lPX, lPY, lPZ
                                                End If
                                            Else
                                                subSendMsgAreaAll "&a'" & MyCStr(rsMines!SSShipName) & " Proximity mine [confirmed] [d0] [" & lPX & " " & lPY & " " & lPZ & "]'", lPX, lPY, lPZ
                                            End If
                                            Set rsMines = Nothing
                                        Else
                                            subSendMsgAreaAll "&a[Fuel short] [f" & (lFuelCost - MyCLng(rsSS!SSFuel)) & "/" & lFuelCost & "]", lPX, lPY, lPZ
                                        End If
                                    Else
                                        subSendMsg "&gYou need to be aboard your own ship to use the weapon systems.", zPortID
                                    End If
                                    Set rsSS = Nothing
                                Else
                                    subSendMsgAreaAll "&aDefense station computer reports, 'the main battery was drained, recharging in progress.'", lPX, lPY, lPZ
                                End If
                            Case Else
                                bShowCommands = True
                        End Select
                        'If (gblbClientMode(MyCLng(zPortID)) And Not gblbFilterMode(MyCLng(zPortID))) Then subSendMsg "&Y<=(=[FLEETMODE]=)=>", zPortID
                    Else
                        bShowCommands = True
                    End If
                    
                    If (bShowCommands) Then subFleetCommandHelpSyntax zPortID
                Else
                    subSendMsg "&gYou have to stand to use starship commands.", zPortID
                End If
            Else
                subSendMsg "&gYou are too busy fighting to use any starship commands.", zPortID
            End If
        Else
            subSendMsg "&RYou are trapped you cannot move!", zPortID
        End If
    Else
        subSendMsg "&g[behind bars - no escape]", zPortID
    End If
    Else
        subSendMsg "&R[cannot too Dizzy]", zPortID
    End If
    Else
        subSendMsg "&RPlayer file not found :: subFleetCommand", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetCommand," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bFleetCombatCloaking(lPlayerID As Long, zPortID As String) As Boolean
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Const cstlEssenceCost = 2000
    Const cstlManaCost = 3500
    Dim bOkay As Boolean

    bOkay = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT CEssence, CMana, CSoul, CMove FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        If (MyCLng(rsPlayer!CEssence) >= cstlEssenceCost And MyCLng(rsPlayer!CMana) >= cstlManaCost) Then
            bOkay = True
            rsPlayer.Edit
            rsPlayer!CEssence = MyCLng(rsPlayer!CEssence) - cstlEssenceCost
            rsPlayer!CMana = MyCLng(rsPlayer!CMana) - cstlManaCost
            rsPlayer.Update
        Else
            If (cstlEssenceCost - MyCLng(rsPlayer!CEssence)) > 0 Then subSendMsg "&AYou are short " & (cstlEssenceCost - MyCLng(rsPlayer!CEssence)) & " essence!", zPortID
            If (cstlManaCost - MyCLng(rsPlayer!CMana)) > 0 Then subSendMsg "&AYou are short " & (cstlManaCost - MyCLng(rsPlayer!CMana)) & " mana!", zPortID
        End If
    End If
    Set rsPlayer = Nothing
    bFleetCombatCloaking = bOkay
    Exit Function
Err_Check:
    subWriteErrorFile "bFleetCombatCloaking," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subFleetCombat(lPlayerID As Long, zWeapon As String, lWeaponsSoulBet As Long)
On Error GoTo Err_Check
    Dim lPhasersCostMove As Long '= ((lDistance * cstlMoveCost) - (lSSLaserLevel / 2))
    Const cstlSoulCost = 5
    Const cstlMoveCost = 16
    Const cstlFleeRange = 250
    Dim rsSS As Recordset
    Dim lCrownPayment As Long
    Dim lSSMobShipBonusGlory As Long
    Dim lMobSpaceShipFlee As Long
    Dim rsSSTarget As Recordset
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zSSTargetAreaName As String
    Dim lSSAreaID As Long
    Dim lDummyCalc As Long
    Dim lASSHullLevel As Long
    Dim lTargetAreaID As Long
    Dim lTSSLaserLevel As Long
    Dim lTSSEngineLevel As Long
    Dim iReturnFireType As Integer
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim zPortID As String
    Dim zShipName As String
    Dim lTargetPlayerType As Long
    Dim lLockX As Long
    Dim lLockY As Long
    Dim lLockZ As Long
    Dim lDistance As Long
    Dim lDamageRange As Long
    Dim lSSLaserLevel As Long
    Dim lSSShieldLevel As Long
    Dim lSSHullLevel As Long
    Dim lOxygenRequiredLevel As Long
    Dim lRadiatedAreaLevel As Long
    Dim lGasAreaLevel As Long
    Dim lHeatAreaLevel As Long
    Dim lTargetPlayerID As Long
    Dim lMobSpaceShipLevel As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lFleeX As Long
    Dim lFleeY As Long
    Dim lFleeZ As Long
    Dim lTSSPLockX As Long
    Dim lTSSPLockY As Long
    Dim lTSSPLockZ As Long
    Dim lPiratedGold As Long
    Dim lTotalDamage As Long
    Dim lTotalMoveCost As Long
    Dim lSSPowerLevel As Long
    Dim lSSBatteryLevel As Long
    Dim lRollA As Long
    Dim lRollB As Long
    Dim lRollC As Long
    Dim lDistanceToGo As Long
    Dim lColonistsNumberKilled  As Long
    Dim lColonistsFarmDestroied  As Long
    Dim lColonistsFactoryDestroied As Long
    Dim lColonistsNumber As Long
    Dim lTSSHullIntegrity As Long
    Dim lHostileForcesDmg As Long
    Dim lMobShipMultiplier As Long
    Dim lSSMobShipHostileTotal As Long
    Dim lSSGloryTotal As Long
    Dim lSSMobShipKillTotal As Long
    Dim bAttackerInNebula As Boolean 'If (lngSQLRecordCount("SELECT TOP 1 AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE ((Len(DamageEmote)>0) AND (XS<=" & lPX & " AND XE>=" & lPX & ") AND (YS<=" & lPY & " AND YE>=" & lPY & ") AND (ZS<=" & lPZ & " AND ZE>=" & lPZ & ") AND (RepairPort=False));") > 0) Then
    Dim bDefenderInNebula As Boolean
    Dim lASSShieldLevel As Long
    Dim lASpaceShipLevel As Long
    Dim lTSpaceShipLevel As Long
'ss status example:
'Interstellar Phoenix Traer
'The ship is loaded with 923207 deuterium isotopes.
'Hull Level       300
'Scanner Level    469
'Shields Level    700
'Phasers Level    300
'Proxy Mine Level 120
'Engine Level     1500
'      Warp Speed 1500
'Destination X0 Y-4601 Z-111 ARRIVED:Yes
'   Location X0 Y-4601 Z-111  MOVING:No
'0 parsec(s) to destination. Colonists Aboard 10
' Interstellar Phoenix Traer has her phasers trained on x-13 y4 z-111.
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, StarshipCommandDelay, PortID, CEssence, CMana, CSoul, CMove, X, Y, Z FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zPortID = MyCStr(rsPlayer!PortID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        If (MyCLng(rsPlayer!StarshipCommandDelay) = 0) Then
            Set rsSS = MyDB.OpenRecordset("SELECT SSHullIntegrity, SSGloryTotal, SSMobShipHostileTotal, SSMobShipKillTotal, SSHullLevel, SSShieldLevel, SSN, SSNX, SSNY, SSNZ, AreaID, SSEngineLevel, SSEngineCruise, CloakingDeviceLevel, CloakingDeviceDuration, AreaName, SSLaserOnline, SSPLockX, SSPLockY, SSPLockZ, SSTLockX, SSTLockY, SSTLockZ, SSLaserLevel, SSPowerLevel, SSBatteryLevel, SSMinesLevel, X, Y, Z FROM tblArea WHERE (PlayerType=2 AND PlayerID=" & lPlayerID & " AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
            If (Not rsSS.EOF) Then
                lSSAreaID = MyCLng(rsSS!AreaID)
                lASpaceShipLevel = lRandom(5) 'this is to reduce attacked target ship hull integrity
                lASSHullLevel = MyCLng(rsSS!SSHullLevel)
                lASSShieldLevel = MyCLng(rsSS!SSShieldLevel) 'attacking starship lElementalResistance(lSSEngineLevel, (100 - lSSHullIntegrity))
                zShipName = MyCStr(rsSS!AreaName)
                lSSGloryTotal = MyCLng(rsSS!SSGloryTotal)
                lSSMobShipHostileTotal = MyCLng(rsSS!SSMobShipHostileTotal)
                lSSMobShipKillTotal = MyCLng(rsSS!SSMobShipKillTotal)
                
                Select Case zWeapon
                    Case "L", "P" 'lasers/phasers
                        lSSLaserLevel = MyCLng(rsSS!SSLaserLevel)
                        lSSPowerLevel = MyCLng(rsSS!SSPowerLevel)
                        lSSBatteryLevel = MyCLng(rsSS!SSBatteryLevel)
                        lLockX = MyCLng(rsSS!SSPLockX)
                        lLockY = MyCLng(rsSS!SSPLockY)
                        lLockZ = MyCLng(rsSS!SSPLockZ)
                        lDistance = (Abs(lLockX - lX) + Abs(lLockY - lY) + Abs(lLockZ - lZ)) + 1
                        lTotalMoveCost = (lDistance * cstlMoveCost)
                        If (lTotalMoveCost > (lSSLaserLevel / 2)) Then lTotalMoveCost = (lSSLaserLevel / 2) 'we dont want to be too mean
                        lPhasersCostMove = (lDistance * cstlMoveCost) - lSSLaserLevel
                        If lPhasersCostMove < 1000 Then lPhasersCostMove = 1000
                        'If (lDistance >= 10) Then
                            If (lDistance <= lSSLaserLevel) Then
                                Set rsSSTarget = MyDB.OpenRecordset("SELECT SSHullIntegrity, SSGloryTotal, SSMobShipHostileTotal, SSMobShipKillTotal, SSEngineCruise, SSEngineLevel, SSN, SSNX, SSNY, SSNZ, SSPLockX, SSPLockY, SSPLockZ, SSLaserLevel, MobSpaceshipLevel, ColonistHostileForces, CloakingDeviceLevel, CloakingDeviceDuration, AreaID, X, Y, Z, AreaName, SSShieldLevel, SSHullLevel, ColonistsNumber, ColonistsFarm, ColonistsFactory, ColonistsPlayerID, PlayerType, PlayerID, GasAreaLevelDesc FROM tblArea WHERE (PlayerType>1 AND X=" & lLockX & " AND Y=" & lLockY & " AND Z=" & lLockZ & ");", dbOpenSnapshot)
                                If (Not rsSSTarget.EOF) Then
                                    lTSSEngineLevel = MyCLng(rsSSTarget!SSEngineLevel)
                                    lTSSHullIntegrity = MyCLng(rsSSTarget!SSHullIntegrity)
                                    lMobSpaceShipLevel = MyCLng(rsSSTarget!MobSpaceshipLevel)
                                    Select Case (lMobSpaceShipLevel)
                                        Case 0
                                            lTSpaceShipLevel = lRandom(5) 'this is to reduce attacked target ship hull
                                        Case Else
                                            lTSpaceShipLevel = lRandom(lMobSpaceShipLevel) 'this is to reduce attacked target ship hull
                                            If (lTSpaceShipLevel > 9) Then lTSpaceShipLevel = 9
                                    End Select
                                    zSSTargetAreaName = MyCStr(rsSSTarget!AreaName)
                                    lTotalDamage = 0
                                    lSSShieldLevel = MyCLng(rsSSTarget!SSShieldLevel)
                                    lSSHullLevel = MyCLng(rsSSTarget!SSHullLevel)
                                    lOxygenRequiredLevel = 0
                                    lRadiatedAreaLevel = 0
                                    lGasAreaLevel = 0
                                    lHeatAreaLevel = 0
                                    lTX = MyCLng(rsSSTarget!x) 'this is also lLockX
                                    lTY = MyCLng(rsSSTarget!y)
                                    lTZ = MyCLng(rsSSTarget!z)
                                    
                                    bAttackerInNebula = (lngSQLRecordCount("SELECT TOP 1 AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE ((Len(DamageEmote)>0) AND (XS<=" & lX & " AND XE>=" & lX & ") AND (YS<=" & lY & " AND YE>=" & lY & ") AND (ZS<=" & lZ & " AND ZE>=" & lZ & ") AND (RepairPort=False)) ORDER BY ShellGroupCode, ShellOrderFromSource;") > 0)
                                    If (bAttackerInNebula) Then lASSShieldLevel = lElementalResistance(lASSShieldLevel, 90) 'leave 10 percent of the shield level away
                                    bDefenderInNebula = (lngSQLRecordCount("SELECT TOP 1 AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE ((Len(DamageEmote)>0) AND (XS<=" & lTX & " AND XE>=" & lTX & ") AND (YS<=" & lTY & " AND YE>=" & lTY & ") AND (ZS<=" & lTZ & " AND ZE>=" & lTZ & ") AND (RepairPort=False)) ORDER BY ShellGroupCode, ShellOrderFromSource;") > 0)
                                    If (bDefenderInNebula) Then lSSShieldLevel = lElementalResistance(lSSShieldLevel, 90) 'leave 10 percent of the shield level away
                                    
                                    lTargetPlayerType = MyCLng(rsSSTarget!PlayerType)
                                    lColonistsNumber = MyCLng(rsSSTarget!ColonistsNumber)
                                    lTSSLaserLevel = MyCLng(rsSSTarget!SSLaserLevel) 'need this to return fire with range
                                    If (MyCLng(rsSSTarget!CloakingDeviceDuration) = 0) Then
                                        'lTargetPlayerID = MyCLng(rsSSTarget!PlayerID)
                                        lTargetAreaID = MyCLng(rsSSTarget!AreaID)
                                        lTSSPLockX = MyCLng(rsSSTarget!SSPLockX)
                                        lTSSPLockY = MyCLng(rsSSTarget!SSPLockY)
                                        lTSSPLockZ = MyCLng(rsSSTarget!SSPLockZ)

                                        If (MyCLng(rsPlayer!CMove) >= lPhasersCostMove) Then
                                            MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-" & lPhasersCostMove & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            If (MyCLng(rsSSTarget!ColonistsPlayerID) <> lPlayerID) Then
                                                subFleetSetCommandDelay lSSLaserLevel, lSSPowerLevel, lSSBatteryLevel, lPlayerID
                                            
                                                'subSendMsgAreaAllRange gblzFBYEL & zShipName & " fires phasers from coordinates x" & lX & " y" & lY & " z" & lZ & "!" & vbCrLf & zSSTargetAreaName & " is under attack!" & vbCrLf & "&wDistance fired " & lDistance & " parsecs.", lX, lY, lZ, 2
    '                                            If (MyCInt(rsSS!SSN) = 0) Then
    '                                                subShipSignature "", zShipName & " [fires phasers-stationary]", MyCLng(rsSS!SSLaserLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lCX, lCY, lCZ
    '                                            Else
    '                                                subShipSignature "", zShipName & " [fires phasers-warp] w[" & MyCStr(rsSS!SSEngineCruise) & "]", MyCLng(rsSS!SSLaserLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lCX, lCY, lCZ
    '                                            End If
                                                'update player stats spent
                                                'Target ship takes damage
                                                lDistanceToGo = lReturnDistanceSpacial(lX, lY, lZ, lTX, lTY, lTZ)
                                                lRollA = lRandom(lSSLaserLevel)
                                                lRollB = lRandom(lSSShieldLevel)
                                                lRollC = 0
                                                If (lRollA >= lRollB) Then
                                                    lRollC = lRandom(lSSHullLevel)
                                                    'if the shields cant stop the full attack the hull tried for each type of damage
                                                    If (lTargetPlayerType = 2) Then
                                                        If (lRandom(lSSLaserLevel) > lRollC) Then
                                                            lOxygenRequiredLevel = 1
                                                            lTotalDamage = lTotalDamage + 1
                                                        End If
                                                        If (lRandom(lSSLaserLevel) > lRollC) Then
                                                            lGasAreaLevel = 1
                                                            lTotalDamage = lTotalDamage + 1
                                                        End If
                                                    End If
                                                    If (lRandom(lSSLaserLevel) > lRollC) Then
                                                        lRadiatedAreaLevel = 1
                                                        lTotalDamage = lTotalDamage + 1
                                                    End If
                                                    If (lRandom(lSSLaserLevel) > lRollC) Then
                                                        lHeatAreaLevel = 1
                                                        lTotalDamage = lTotalDamage + 1
                                                    End If
                                                End If
                                                
                                                If (lTotalDamage > 0) Then
                                                    If (MyCInt(rsSS!SSN) = 0) Then
                                                        subShipSignature "", vbCrLf & zShipName & " [phasers HIT-stationary] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lSSShieldLevel & " and Hull " & lRollC & "/" & lSSHullLevel & "]" & vbCrLf & lTotalDamage & " targets were destroyed!", (MyCLng(rsSS!SSLaserLevel)), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, False  'bAllowMobShipReactSig
                                                    Else
                                                        subShipSignature "", vbCrLf & zShipName & " [phasers HIT-warp] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lSSShieldLevel & " and Hull " & lRollC & "/" & lSSHullLevel & "]" & vbCrLf & lTotalDamage & " targets were destroyed!", (MyCLng(rsSS!SSLaserLevel)), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, False  'bAllowMobShipReactSig
                                                    End If
                                                    
                                                    lColonistsNumberKilled = 0
                                                    lColonistsFarmDestroied = 0
                                                    lColonistsFactoryDestroied = 0
    
                                                    'kill off any colonists
                                                    Select Case lTargetPlayerType
                                                        Case 0
                                                        Case 1, 2 'hurts everything on the starship
                                                            If (MyCLng(rsSSTarget!ColonistsNumber) > 0) Then
                                                                lColonistsNumberKilled = lRandom(8)
                                                                lColonistsFarmDestroied = lRandom(4)
                                                                lColonistsFactoryDestroied = lRandom(6) + 4
    
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsNumber=[ColonistsNumber]-" & lColonistsNumberKilled & ", ColonistsFarm=[ColonistsFarm]-" & lColonistsFarmDestroied & ", ColonistsFactory=[ColonistsFactory]-" & lColonistsFactoryDestroied & " WHERE (ColonistsNumber>0 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsFarm=0 WHERE (ColonistsFarm<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsFactory=0 WHERE (ColonistsFactory<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsNumber=0, ColonistsPlayerID=" & lPlayerID & " WHERE (ColonistsNumber<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                            End If
                                                            MyDB.Execute "UPDATE tblPlayer SET CHP=[CHP]-" & lRandom(100) & " WHERE (CHP>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CEssence=[CEssence]-" & lRandom(100) & " WHERE (CEssence>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CMana=[CMana]-" & lRandom(100) & " WHERE (CMana>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CSoul=[CSoul]-" & lRandom(100) & " WHERE (CSoul>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-" & lRandom(100) & " WHERE (CMove>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                        Case 3 'hurts area and colonists
                                                            If (MyCLng(rsSSTarget!ColonistsNumber) > 0) Then
                                                                lColonistsNumberKilled = lRandom(13) + 2
                                                                lColonistsFarmDestroied = lRandom(6) + 2
                                                                lColonistsFactoryDestroied = lRandom(6) + 2
                                                                
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsNumber=[ColonistsNumber]-" & lColonistsNumberKilled & ", ColonistsFarm=[ColonistsFarm]-" & lColonistsFarmDestroied & ", ColonistsFactory=[ColonistsFactory]-" & lColonistsFactoryDestroied & " WHERE (ColonistsNumber>0 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsFarm=0 WHERE (ColonistsFarm<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsFactory=0 WHERE (ColonistsFactory<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsNumber=0, ColonistsPlayerID=" & lPlayerID & " WHERE (ColonistsNumber<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                            End If
                                                        Case Else 'hurts everything
                                                            If (MyCLng(rsSSTarget!ColonistsNumber) > 0) Then
                                                                lColonistsNumberKilled = lRandom(15) + 5
                                                                lColonistsFarmDestroied = lRandom(3)
                                                                lColonistsFactoryDestroied = lRandom(15) + 15
    
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsNumber=[ColonistsNumber]-" & lColonistsNumberKilled & ", ColonistsFarm=[ColonistsFarm]-" & lColonistsFarmDestroied & ", ColonistsFactory=[ColonistsFactory]-" & lColonistsFactoryDestroied & " WHERE (ColonistsNumber>0 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsFarm=0 WHERE (ColonistsFarm<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsFactory=0 WHERE (ColonistsFactory<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                MyDB.Execute "UPDATE tblArea SET ColonistsNumber=0, ColonistsPlayerID=" & lPlayerID & " WHERE (ColonistsNumber<1 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                            End If
                                                            MyDB.Execute "UPDATE tblPlayer SET CHP=[CHP]-" & lRandom(100) & " WHERE (CHP>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CEssence=[CEssence]-" & lRandom(100) & " WHERE (CEssence>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CMana=[CMana]-" & lRandom(100) & " WHERE (CMana>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CSoul=[CSoul]-" & lRandom(100) & " WHERE (CSoul>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-" & lRandom(100) & " WHERE (CMove>100 AND X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                    End Select
                                                    
                                                    lTSSHullIntegrity = lTSSHullIntegrity - lASpaceShipLevel
                                                    If (lTSSHullIntegrity < 0) Then lTSSHullIntegrity = 0
                                                    MyDB.Execute "UPDATE tblArea SET OxygenRequiredLevel = [OxygenRequiredLevel]+" & lOxygenRequiredLevel & ", RadiatedAreaLevel = [RadiatedAreaLevel]+" & lRadiatedAreaLevel & ", GasAreaLevelDesc='Smoking and Burning Coolant', GasAreaLevel = [GasAreaLevel]+" & lGasAreaLevel & ", HeatAreaLevel = [HeatAreaLevel]+" & lHeatAreaLevel & " WHERE (AreaID=" & lTargetAreaID & ");", dbFailOnError 'update targeted enemy ship
                                                    MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=" & lTSSHullIntegrity & " WHERE (SSHullIntegrity>0 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                    
                                                    lColonistsNumber = lColonistsNumber - lColonistsNumberKilled
                                                    
                                                    If (lColonistsNumberKilled + lColonistsFarmDestroied + lColonistsFactoryDestroied > 0) Then
                                                        subSendMsgAreaAll "&R'" & zShipName & " [phasers hit] this area! [-c" & lColonistsNumberKilled & " -farms" & lColonistsFarmDestroied & " -factories" & lColonistsFactoryDestroied & "] [c" & lColonistsNumber & "]'", lTX, lTY, lTZ
                                                        subSendMsgAreaAll "&G'Phasers hit ! ! ! [damage inflicted] [-c" & lColonistsNumberKilled & " -farms" & lColonistsFarmDestroied & " -factories" & lColonistsFactoryDestroied & "] [c" & lColonistsNumber & "]'", lX, lY, lZ
                                                    Else
                                                        subSendMsgAreaAll "&R'" & zShipName & " [phasers hit] this area! [c" & lColonistsNumber & "]'", lTX, lTY, lTZ
                                                        subSendMsgAreaAll "&G'Phasers hit ! ! ! [c" & lColonistsNumber & "]'", lX, lY, lZ
                                                    End If
                                                    
                                                    'we blow up (delete) the mobship - maybe
                                                    If (lMobSpaceShipLevel > 0) Then
                                                        If (lRandom(100) > lRandom(lTSSHullIntegrity)) Then  'percent chance to explode the mobship - mobs get a base of 6 to place odds to win more in their favour
                                                            Select Case lMobSpaceShipLevel
                                                                Case 1 To 3
                                                                    lMobShipMultiplier = 1
                                                                Case 4 To 7
                                                                    lMobShipMultiplier = 2
                                                                Case 8 To 12
                                                                    lMobShipMultiplier = lRandom(2) + 2
                                                                Case Else
                                                                    lMobShipMultiplier = 4
                                                            End Select
                                                            lMobSpaceShipLevel = 0 'this is no longer a mobship - its just space debris now
                                                            'mobiles are attracted to explosions
                                                            subShipSignature "", vbCrLf & zSSTargetAreaName & " ~!~~!EXPLODES!~~!~", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, True   'bAllowMobShipReactSig - we all mobiles to be attracted to explosions
                                                            MyDB.Execute "UPDATE tblMob SET RespawnDelay=10 WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblObject SET X = 0, Y = 0, Z = 0 WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "UPDATE tblPlayer SET CHP=0, X = 0, Y = 0, Z = -2 WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbFailOnError
                                                            MyDB.Execute "DELETE AreaID from tblArea WHERE AreaID=" & lTargetAreaID & ";", dbFailOnError
                                                            lPiratedGold = ((300 + lRandom(350) + lRandom(350))) * lMobShipMultiplier
                                                                                                                        
                                                            lDummyCalc = (lASSHullLevel - lSSHullLevel)
                                                            If (lDummyCalc < 0) Then lSSMobShipBonusGlory = lSSMobShipBonusGlory + Abs(lDummyCalc / 32)
                                                            lDummyCalc = (lASSShieldLevel - lSSShieldLevel)
                                                            If (lDummyCalc < 0) Then lSSMobShipBonusGlory = lSSMobShipBonusGlory + Abs(lDummyCalc / 32)
                                                            lCrownPayment = (9 + lSSMobShipBonusGlory + lMobShipMultiplier)
                                                            MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]+" & lCrownPayment & ", LearnPoints=[LearnPoints]+2, Gold=[Gold]+" & lPiratedGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'STARSHIP CROWNS OF STARSHIP GLORY handed out
                                                            MyDB.Execute "UPDATE tblArea SET SSGloryTotal=[SSGloryTotal]+" & lCrownPayment & ", SSMobShipKillTotal = " & (lSSMobShipKillTotal + 1) & " WHERE (AreaID=" & lSSAreaID & ");", dbFailOnError
                                                            'subSendMsg "&YYou pirated " & lCrownPayment & " glory, 2 learn points, and " & lPiratedGold & " gold.", zPortID
                                                            subSendMsgInfoChannel "&w" & zPlayerName & " &a[destroyed] &g[" & zSSTargetAreaName & "] " & zFormatGoldCofGLearnpts(lCrownPayment, "c", False) & zFormatGoldCofGLearnpts(2, "l", False) & zFormatGoldCofGLearnpts(lPiratedGold, "g", False)
                                                            'trisker work fire fight area
                                                        End If
                                                    End If
                                                Else
                                                    subSendMsgAreaAll "&G'" & zShipName & " has missed us with her phasers! [c" & lColonistsNumber & "]'", lTX, lTY, lTZ
                                                    subSendMsgAreaAll "&R'Phasers missed! [c" & lColonistsNumber & "]'", lX, lY, lZ
                                                    If (MyCInt(rsSS!SSN) = 0) Then
                                                        subShipSignature "", vbCrLf & zShipName & " [phasers MISS-stationary] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lSSShieldLevel & " and Hull " & lSSHullLevel & "]", MyCLng(rsSS!SSLaserLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, False  'bAllowMobShipReactSig
                                                    Else
                                                        subShipSignature "", vbCrLf & zShipName & " [phasers MISS-warp] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lSSShieldLevel & " and Hull " & lSSHullLevel & "]", MyCLng(rsSS!SSLaserLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, False  'bAllowMobShipReactSig
                                                    End If
                                                End If
                                                                                                
                                                If (lMobSpaceShipLevel > 0) Then 'mobship locks onto the target
                                                    If (lMobSpaceShipLevel > 1) Then 'constructors and miners dont have phasers
                                                        If (lX <> lTSSPLockX And lY <> lTSSPLockY And lZ <> lTSSPLockZ) Then
                                                            MyDB.Execute "UPDATE tblArea SET SSLaserOnline=True, SSPLockX=" & lX & ", SSPLockY=" & lY & ", SSPLockZ=" & lZ & " WHERE AreaID=" & lTargetAreaID & ";", dbFailOnError
                                                        End If
                                                    End If
                                                    
                                                    lMobSpaceShipFlee = lMobSpaceShipLevel
                                                    If (lMobSpaceShipFlee > 4) Then lMobSpaceShipFlee = 4 'we want attack vessels fleeing sometimes too
                                                    Select Case (lRandom(lMobSpaceShipFlee))
                                                        Case 1 'mobship flee
                                                            If (lMobSpaceShipFlee > 2) Then lMobSpaceShipFlee = 2
                                                            'we do nothing for passive mobships
                                                            If (lRandom(lMobSpaceShipFlee) = 1) Then
                                                                subSendMsgAreaAll "&w'Sending peaceful intentions to the attacking craft, Sir.'", lTX, lTY, lTZ
                                                                Select Case lRandom(6)
                                                                    Case 1
                                                                        subSendMsgAreaAll "&w'Incoming message from the alien craft, Sir.'" & vbCrLf & "&w'~We are a peaceful vessel, we request that you cease all hostilities.~'", lX, lY, lZ
                                                                    Case 2
                                                                        subSendMsgAreaAll "&w'Incoming message from the alien craft, Sir.'" & vbCrLf & "&w'~We are a science vessel please cease all hostilities!~'", lX, lY, lZ
                                                                    Case 3
                                                                        subSendMsgAreaAll "&w'Incoming message from the alien craft, Sir.'" & vbCrLf & "&w'~We appreciate your act of force but we will be moving on now.~'", lX, lY, lZ
                                                                    Case 4
                                                                        subSendMsgAreaAll "&w'Incoming message from the alien craft, Sir.'" & vbCrLf & "&w'~Greetings on behalf of myself and the crew, good journey! Bye for now.~'", lX, lY, lZ
                                                                    Case 5
                                                                        subSendMsgAreaAll "&w'Incoming message from the alien craft, Sir.'" & vbCrLf & "&w'~We are a friendly starcraft, please halt all attacks.~'", lX, lY, lZ
                                                                    Case 6
                                                                        subSendMsgAreaAll "&w'Incoming message from the alien craft, Sir.'" & vbCrLf & "&w'All I can make out from the message are screams and deaths, Sir!'", lX, lY, lZ
                                                                End Select
                                                                
                                                                'Stuff that cannot fight back will leave the scene.
                                                                lFleeX = lRandom(cstlFleeRange)
                                                                If (lRandom(2) = 1) Then lFleeX = lFleeX * -1
                                                                lFleeY = lRandom(cstlFleeRange)
                                                                If (lRandom(2) = 1) Then lFleeY = lFleeY * -1
                                                                lFleeZ = lRandom(cstlFleeRange)
                                                                If (lRandom(2) = 1) Then lFleeZ = lFleeZ * -1
                                                                
                                                                MyDB.Execute "UPDATE tblArea SET SSN=True, SSNX=" & lTX + lFleeX & ", SSNY=" & lTY + lFleeY & ", SSNZ=" & (lTZ - lRandom(9)) + lFleeZ & " WHERE (SSN=False AND MobSpaceshipLevel>0 AND AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                    subShipSignature "", zSSTargetAreaName & " [Flee-stationary] [w" & MyCLng(rsSSTarget!SSEngineCruise) & "] [dx" & (lTX + lFleeX) & " y" & (lTY + lFleeY) & " z" & (lTZ + lFleeZ) & "]", MyCLng(rsSSTarget!SSEngineCruise), MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False 'bAllowMobShipReactSig
                                                                Else
                                                                    subShipSignature "", zSSTargetAreaName & " [Flee-warp] [w" & MyCLng(rsSSTarget!SSEngineCruise) & "] [dx" & (lTX + lFleeX) & " y" & (lTY + lFleeY) & " z" & (lTZ + lFleeZ) & "]", MyCLng(rsSSTarget!SSEngineCruise), MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False 'bAllowMobShipReactSig
                                                                End If
                                                            End If
                                                        Case Else 'mobship return fire
                                                            'We return fire and either evade or close in
                                                            lFleeX = lRandom(cstlFleeRange)
                                                            If (lRandom(2) = 1) Then lFleeX = lFleeX * -1
                                                            lFleeY = lRandom(cstlFleeRange)
                                                            If (lRandom(2) = 1) Then lFleeY = lFleeY * -1
                                                            lFleeZ = lRandom(cstlFleeRange)
                                                            If (lRandom(2) = 1) Then lFleeZ = lFleeZ * -1
                                                            
                                                            Select Case lRandom(6)
                                                                Case 1 To 2 'Stay still and wait for another attack
                                                                    iReturnFireType = 0
                                                                Case 3 'now we set up to fire and run
                                                                    iReturnFireType = 1
                                                                    MyDB.Execute "UPDATE tblArea SET SSN=True, SSNX=" & lTX + lFleeX & ", SSNY=" & lTY + lFleeY & ", SSNZ=" & (lTZ - lRandom(9)) + lFleeZ & " WHERE (AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                                Case Else 'fire and close in
                                                                    iReturnFireType = 2
                                                                    MyDB.Execute "UPDATE tblArea SET SSN=True, SSNX=" & lX + MyCLng(lFleeX / 6) & ", SSNY=" & lY + MyCLng(lFleeY / 6) & ", SSNZ=" & (lZ - lRandom(9)) + MyCLng(lFleeZ / 6) & " WHERE (AreaID= " & lTargetAreaID & ");", dbFailOnError
                                                            End Select
                                                            
                                                            'subdShipSignature "", vbCrLf & zSSTargetAreaName & " [fires phasers] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", MyCLng(rsSS!SSEngineLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ
                                                            If (lTSSLaserLevel > 0) Then
                                                                If (lTSSLaserLevel >= lDistanceToGo) Then 'we are within range
                                                                    lRollA = lRandom(lTSSLaserLevel)
                                                                    lRollB = lRandom(lASSShieldLevel)
                                                                    If (lRollA > lRollB) Then
                                                                        If (lRandom(lTSSLaserLevel) > lRandom(MyCLng(rsSS!SSHullLevel))) Then
                                                                            lTotalDamage = 1
                                                                            Select Case (iReturnFireType)
                                                                                Case 1
                                                                                    If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers HIT evading-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lASSShieldLevel & " and Hull " & MyCLng(rsSS!SSHullLevel) & "]" & vbCrLf & lTotalDamage & " targets were destroyed!", MyCLng(rsSSTarget!SSLaserLevel), MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False 'bAllowMobShipReactSig
                                                                                    Else
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers HIT evading-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lASSShieldLevel & " and Hull " & MyCLng(rsSS!SSHullLevel) & "]" & vbCrLf & lTotalDamage & " targets were destroyed!", MyCLng(rsSSTarget!SSLaserLevel), MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False 'bAllowMobShipReactSig
                                                                                    End If
                                                                                Case 2
                                                                                    If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers HIT closing-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lASSShieldLevel & " and Hull " & MyCLng(rsSS!SSHullLevel) & "]" & vbCrLf & lTotalDamage & " targets were destroyed!", MyCLng(rsSSTarget!SSLaserLevel), MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, True 'bAllowMobShipReactSig
                                                                                    Else
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers HIT closing-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [Phasers " & lRollA & " vs Shield " & lRollB & "/" & lASSShieldLevel & " and Hull " & MyCLng(rsSS!SSHullLevel) & "]" & vbCrLf & lTotalDamage & " targets were destroyed!", MyCLng(rsSSTarget!SSLaserLevel), MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, True 'bAllowMobShipReactSig
                                                                                    End If
                                                                            End Select
                                                                            
                                                                            Select Case lRandom(4)
                                                                                Case 1
                                                                                    subSendMsgAreaAll "&R'A fire explodes from one of the consoles!'", lX, lY, lZ
                                                                                    MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=[SSHullIntegrity]-" & lTSpaceShipLevel & ", HeatAreaLevel=[HeatAreaLevel]+1 WHERE (AreaID=" & lSSAreaID & ");", dbFailOnError
                                                                                Case 2
                                                                                    subSendMsgAreaAll "&R'Radiation is spreading throughout the starship!'", lX, lY, lZ
                                                                                    MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=[SSHullIntegrity]-" & lTSpaceShipLevel & ", RadiatedAreaLevel=[RadiatedAreaLevel]+1 WHERE (AreaID=" & lSSAreaID & ");", dbFailOnError
                                                                                Case 3
                                                                                    subSendMsgAreaAll "&R'A coolant tube explodes and poisonous gas is spreading throughout the starship!'", lX, lY, lZ
                                                                                    MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=[SSHullIntegrity]-" & lTSpaceShipLevel & ", GasAreaLevelDesc='Smoking and Burning Coolant', GasAreaLevel=[GasAreaLevel]+1 WHERE (AreaID=" & lSSAreaID & ");", dbFailOnError
                                                                                Case Else
                                                                                    subSendMsgAreaAll "&R'There is an explosion which causes a breach in the hull!'", lX, lY, lZ
                                                                                    MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=[SSHullIntegrity]-" & lTSpaceShipLevel & ", OxygenRequiredLevel=[OxygenRequiredLevel]+1 WHERE (AreaID=" & lSSAreaID & ");", dbFailOnError
                                                                            End Select
                                                                            MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=0 WHERE (SSHullIntegrity<0 AND AreaID=" & lSSAreaID & ");", dbFailOnError
                                                                        Else 'miss hull
                                                                            Select Case (iReturnFireType)
                                                                                Case 1 'flee
                                                                                    If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Hull evading-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                    Else
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Hull evading-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                    End If
                                                                                Case 2 'close in
                                                                                    If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Hull closing-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                    Else
                                                                                        subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Hull closing-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                    End If
                                                                            End Select
                                                                        End If
                                                                    Else 'miss shields
                                                                        Select Case (iReturnFireType)
                                                                            Case 1 'flee
                                                                                If (MyCInt(rsSSTarget!SSN) = 0) Then '[Phasers " & lRollA & " vs Shield " & lRollB & "/" & lASSShieldLevel & " and Hull " & MyCLng(rsSS!SSHullLevel) & "]" & vbCrLf & lTotalDamage & " targets were destroyed!"
                                                                                    subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Shields evading-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                Else
                                                                                    subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Shields evading-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                End If
                                                                            Case 2 'close in
                                                                                If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                    subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Shields closing-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                Else
                                                                                    subShipSignature "", vbCrLf & zSSTargetAreaName & " [phasers MISS Shields closing-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                                End If
                                                                        End Select
                                                                    End If
                                                                Else 'not in phaser range
                                                                    Select Case (iReturnFireType)
                                                                        Case 1 'flee
                                                                            If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                subShipSignature "", vbCrLf & zSSTargetAreaName & " [*not in phaser range* evading-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                            Else
                                                                                subShipSignature "", vbCrLf & zSSTargetAreaName & " [*not in phaser range* evading-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                            End If
                                                                        Case 2 'close in
                                                                            If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                                subShipSignature "", vbCrLf & zSSTargetAreaName & " [*not in phaser range* closing-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                            Else
                                                                                subShipSignature "", vbCrLf & zSSTargetAreaName & " [*not in phaser range* closing-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                            End If
                                                                    End Select
                                                                End If
                                                            Else 'no phasers
                                                                Select Case (iReturnFireType)
                                                                    Case 1 'flee
                                                                        If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                            subShipSignature "", vbCrLf & zSSTargetAreaName & " [no phasers fleeing-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                        Else
                                                                            subShipSignature "", vbCrLf & zSSTargetAreaName & " [no phasers fleeing-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                        End If
                                                                    Case 2 'close in
                                                                        If (MyCInt(rsSSTarget!SSN) = 0) Then
                                                                            subShipSignature "", vbCrLf & zSSTargetAreaName & " [no phasers closing-stationary] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                        Else
                                                                            subShipSignature "", vbCrLf & zSSTargetAreaName & " [no phasers closing-warp] " & zShipName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "]", lTSSEngineLevel, MyCLng(rsSSTarget!CloakingDeviceDuration), MyCLng(rsSSTarget!CloakingDeviceLevel), lTX, lTY, lTZ, False   'bAllowMobShipReactSig
                                                                        End If
                                                                End Select
                                                            End If
                                                    End Select
                                                End If
                                            Else 'The player attacks a hostile force on a planet
                                                If (MyCLng(rsSSTarget!ColonistHostileForces) = 0) Then
                                                    subSendMsgAreaAll "&R'Cancelled! Unable to fire upon a friendly colony base. [c" & lColonistsNumber & "]'", lX, lY, lZ
                                                Else
                                                    subFleetSetCommandDelay lSSLaserLevel, lSSPowerLevel, lSSBatteryLevel, lPlayerID
                                                    
                                                    lHostileForcesDmg = lRandom(9) + 1
                                                    If (MyCLng(rsSSTarget!ColonistHostileForces) - lHostileForcesDmg < 1) Then
                                                        'reward - give glory to the player that cleared the hostile forces
                                                        subSendMsgInfoChannel "&w" & zPlayerName & " &a[liberated] &g[" & zSSTargetAreaName & "] &w[+1glory, +3lps]"
                                                        If (MyCInt(rsSS!SSN) = 0) Then
                                                            subShipSignature "", vbCrLf & zShipName & " [world liberated-stationary] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [-h" & lHostileForcesDmg & "] [h" & MyCLng(rsSSTarget!ColonistHostileForces) - lHostileForcesDmg & "]", MyCLng(MyCLng(rsSS!SSLaserLevel) / 4), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, True 'bAllowMobShipReactSig
                                                        Else
                                                            subShipSignature "", vbCrLf & zShipName & " [world liberated-warp] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [-h" & lHostileForcesDmg & "] [h" & MyCLng(rsSSTarget!ColonistHostileForces) - lHostileForcesDmg & "]", MyCLng(MyCLng(rsSS!SSLaserLevel) / 4), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, True 'bAllowMobShipReactSig
                                                        End If
                                                        MyDB.Execute "UPDATE tblArea SET SSGloryTotal=" & (lSSGloryTotal + 1) & ", SSMobShipHostileTotal = " & (lSSMobShipHostileTotal + 1) & " WHERE (AreaID=" & lSSAreaID & ");", dbFailOnError
                                                        MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]+1, LearnPoints=[LearnPoints]+3 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                        MyDB.Execute "UPDATE tblArea SET ColonistHostileForces=0 WHERE (AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                    Else
                                                        'subSendMsgAreaAll "&GPhasers hit! &g'[-h" & lHostileForcesDmg & "] [status] [h" & MyCLng(rsSSTarget!ColonistHostileForces) - lHostileForcesDmg & "]'", lX, lY, lZ
                                                        If (MyCInt(rsSS!SSN) = 0) Then
                                                            subShipSignature "", vbCrLf & zShipName & " [phasers HIT-stationary] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [-h" & lHostileForcesDmg & "] [h" & MyCLng(rsSSTarget!ColonistHostileForces) - lHostileForcesDmg & "]", MyCLng(rsSS!SSLaserLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, True 'bAllowMobShipReactSig
                                                        Else
                                                            subShipSignature "", vbCrLf & zShipName & " [phasers HIT-warp] " & zSSTargetAreaName & vbCrLf & "[d" & lDistanceToGo & "] [dx" & lTX & " y" & lTY & " z" & lTZ & "] [-h" & lHostileForcesDmg & "] [h" & MyCLng(rsSSTarget!ColonistHostileForces) - lHostileForcesDmg & "]", MyCLng(rsSS!SSLaserLevel), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, True 'bAllowMobShipReactSig
                                                        End If
                                                        MyDB.Execute "UPDATE tblArea SET ColonistHostileForces=[ColonistHostileForces]-" & lHostileForcesDmg & " WHERE (AreaID=" & lTargetAreaID & ");", dbFailOnError
                                                    End If
                                                End If
                                            End If
                                        Else
                                            subSendMsgAreaAll "&a'Phasers are short " & lPhasersCostMove & " move. [c" & lColonistsNumber & "]'", lX, lY, lZ
                                        End If
                                    Else
                                        subSendMsgAreaAll gblzFNGRE & "'Sensors cannot get an accurate fix on the cloaked target.'", lX, lY, lZ
                                    End If
                                Else
                                    subSendMsgAreaAll gblzFNGRE & "'Our phasers are not locked onto a suitable target.'", lX, lY, lZ
                                End If
                                Set rsSSTarget = Nothing
                            Else
                                subSendMsg "&gThe distance to fire is " & (lDistance - lSSLaserLevel) & " parsecs over phaser level capabilities.", zPortID
                            End If
                        'Else
                        '    subSendMsg "&gYou must be at least ten parsec(s away from the target to fire safely.", zPortID
                        'End If
                End Select
            Else
                subSendMsg "&gYou need to be aboard your own ship to use the weapon systems.", zPortID
            End If
            Set rsSS = Nothing
        Else
            subSendMsg "&ADefense station computer reports, " & vbCrLf & "'the main battery was drained, recharging in progress.'", zPortID
        End If
    End If
    Set rsPlayer = Nothing
    
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetCombat," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subFleetDeepSpaceScan(lSSScanLevel As Long, lCloakingDeviceDuration As Long, lCloakingDeviceLevel As Long, lPX As Long, lPY As Long, lPZ As Long, lEssence As Long, lMana As Long, lPlayerID As Long)
On Error GoTo Err_Check
    Const cstlManaCost = 150
    Const cstlEssenceCost = 300
    Dim lTWormHoles As Long
    Dim lTAreaMasses As Long
    Dim lTBioMasses As Long
    Dim lTPlayerMasses As Long
    Dim lTFuelMasses As Long
    Dim lCalcuScanLevel As Long
    Dim lCalcuDistance As Long
    Dim lCalcuWHDistanceStart As Long
    Dim lCalcuWHDistanceStop As Long
    Dim bScan As Boolean
    Dim lCounter As Long
    Dim zMarker As String
    Dim zFertility As String
    Dim rsLocation As Recordset
    Dim lCX As Long
    Dim lCY As Long
    Dim lCZ As Long
    
    lCalcuScanLevel = lSSScanLevel
    'Debug.Print lCalcuScanLevel
    lCalcuDistance = (Abs(lPX - lCX) + Abs(lPY - lCY) + Abs(lPZ - lCZ))
    'Debug.Print lCalcuDistance
    bScan = True
    If ((lCalcuScanLevel * 10) < lCalcuDistance) Then bScan = False
    
    If (bScan) Then
        If (lEssence >= cstlEssenceCost) Then
            If (lMana >= cstlManaCost) Then
                lTWormHoles = lngSQLRecordCount("SELECT AreaSpaceFlightEmoteID FROM tblAreaSpaceFlightEmote WHERE (DStatus<>0) AND (XS>" & lCX & "-" & lCalcuScanLevel & " And XE<" & lCX & "+" & lCalcuScanLevel & ") AND (YS>" & lCY & "-" & lCalcuScanLevel & " And YE<" & lCY & "+" & lCalcuScanLevel & ") AND (ZS>" & lCZ & "-" & lCalcuScanLevel & " And ZE<" & lCZ & "+" & lCalcuScanLevel & ");")
                lTAreaMasses = lngSQLRecordCount("SELECT X, Y, Z, MapAvailable FROM tblArea WHERE (X>" & lCX & "-" & lCalcuScanLevel & " And X<" & lCX & "+" & lCalcuScanLevel & ") AND (Y>" & lCY & "-" & lCalcuScanLevel & " And Y<" & lCY & "+" & lCalcuScanLevel & ") AND (Z>" & lCZ & "-" & lCalcuScanLevel & " And Z<" & lCZ & "+" & lCalcuScanLevel & ") AND (MapAvailable<>0);")
                lTBioMasses = lngSQLRecordCount("SELECT X, Y, Z FROM tblMob WHERE (X>" & lCX & "-" & lCalcuScanLevel & " And X<" & lCX & "+" & lCalcuScanLevel & ") AND (Y>" & lCY & "-" & lCalcuScanLevel & " And Y<" & lCY & "+" & lCalcuScanLevel & ") AND (Z>" & lCZ & "-" & lCalcuScanLevel & " And Z<" & lCZ & "+" & lCalcuScanLevel & ");")
                lTPlayerMasses = lngSQLRecordCount("SELECT X, Y, Z FROM tblPlayer WHERE (X>" & lCX & "-" & lCalcuScanLevel & " And X<" & lCX & "+" & lCalcuScanLevel & ") AND (Y>" & lCY & "-" & lCalcuScanLevel & " And Y<" & lCY & "+" & lCalcuScanLevel & ") AND (Z>" & lCZ & "-" & lCalcuScanLevel & " And Z<" & lCZ & "+" & lCalcuScanLevel & ");")
                lTFuelMasses = lngSQLRecordCount("SELECT X, Y, Z FROM tblObject WHERE (X>" & lCX & "-" & lCalcuScanLevel & " And X<" & lCX & "+" & lCalcuScanLevel & ") AND (Y>" & lCY & "-" & lCalcuScanLevel & " And Y<" & lCY & "+" & lCalcuScanLevel & ") AND (Z>" & lCZ & "-" & lCalcuScanLevel & " And Z<" & lCZ & "+" & lCalcuScanLevel & ") And (SSFuel>0) And (Status=0 OR Status=1 OR Status=3);")
                
                subSendMsgAreaAll "&aOnboard computer deep space ping confirms," & vbCrLf & "'" & lTWormHoles & " wormhole particles and " & vbCrLf & lTAreaMasses & " land-masses and " & lTBioMasses & " bio-masses and " & lTPlayerMasses & " player-masses" & vbCrLf & "in a " & lCalcuScanLevel & " parsecs scan surrounding location X" & lCX & " Y" & lCY & " Z" & lCZ & "'", lPX, lPY, lPZ
                
                If (lTFuelMasses > 0) Then subSendMsgAreaAll "&yOnboard computer reports, deep space pings confirms," & vbCrLf & "'" & lTFuelMasses & " fuel-masses inside the " & lCalcuScanLevel & " parsecs scan area of X" & lCX & " Y" & lCY & " Z" & lCZ & "'", lPX, lPY, lPZ
                
                lCounter = 0
                Set rsLocation = MyDB.OpenRecordset("SELECT * FROM tblAreaSpaceFlightEmote WHERE (DStatus<>0) AND (XS>" & lCX & "-" & lCalcuScanLevel & " And XE<" & lCX & "+" & lCalcuScanLevel & ") AND (YS>" & lCY & "-" & lCalcuScanLevel & " And YE<" & lCY & "+" & lCalcuScanLevel & ") AND (ZS>" & lCZ & "-" & lCalcuScanLevel & " And ZE<" & lCZ & "+" & lCalcuScanLevel & ") ORDER BY ZE DESC;", dbOpenSnapshot)
                Do While (Not rsLocation.EOF)
                    lCounter = lCounter + 1
                    lCalcuWHDistanceStart = Abs(lCX - MyCLng(rsLocation!XS)) + Abs(lCY - MyCLng(rsLocation!YS)) + Abs(lCZ - MyCLng(rsLocation!zS))
                    lCalcuWHDistanceStop = Abs(lCX - MyCLng(rsLocation!DX)) + Abs(lCY - MyCLng(rsLocation!DY)) + Abs(lCZ - MyCLng(rsLocation!DZ))
                    subSendMsgAreaAll "&a" & strForceSize(lCounter, 5, " ", "A") & " Wormhole spans from XS" & MyCLng(rsLocation!XS) & " to XE" & MyCLng(rsLocation!XE) & vbCrLf & "                          YS" & MyCLng(rsLocation!YS) & " to YE" & MyCLng(rsLocation!YE) & vbCrLf & "                          ZS" & MyCLng(rsLocation!zS) & " to ZE" & MyCLng(rsLocation!zE) & " d[" & lCalcuWHDistanceStart & "]" & vbCrLf & "                    EXITS X:" & MyCLng(rsLocation!DX) & " Y:" & MyCLng(rsLocation!DY) & " Z:" & MyCLng(rsLocation!DZ) & " d[" & lCalcuWHDistanceStop & "]", lPX, lPY, lPZ
                    rsLocation.MoveNext
                Loop
                Set rsLocation = Nothing
                
'                Set rsLocation = MyDB.OpenRecordset("SELECT tblArea.ColonistsPlayerID, tblArea.AreaSpeciesFertilityPercent, tblArea.AreaName, tblObject.ObjectName, tblObject.SSScanLevel, tblObject.X, tblObject.Y, tblObject.Z FROM tblObject INNER JOIN tblArea ON (tblObject.Z = tblArea.Z) AND (tblArea.Y = tblObject.Y) AND (tblObject.X = tblArea.X) WHERE (((tblObject.SSScanLevel)>0) AND ((tblObject.X)>" & lCX & "-" & lCalcuScanLevel & " And (tblObject.X)<" & lCX & "+" & lCalcuScanLevel & ") AND ((tblObject.Y)>" & lCY & "-" & lCalcuScanLevel & " And (tblObject.Y)<" & lCY & "+" & lCalcuScanLevel & ") AND ((tblObject.Z)>" & lCZ & "-" & lCalcuScanLevel & " And (tblObject.Z)<" & lCZ & "+" & lCalcuScanLevel & ")) ORDER BY tblObject.Z DESC;", dbOpenSnapshot) 'this select statement requires an object to scan, this way other things around the universe can be found.
'                Do While (Not rsLocation.EOF)
'                    lCounter = lCounter + 1
'
'                    zMarker = " "
'                    If (MyCLng(rsLocation!ColonistsPlayerID) = lPlayerID) Then
'                        zMarker = "+"
'                    Else
'                        If (MyCLng(rsLocation!ColonistsPlayerID) <> 0) Then
'                            zMarker = " - " & zReturnPlayerName(MyCLng(rsLocation!ColonistsPlayerID)) & ":" & vbCrLf
'                        End If
'                    End If
'
'                    zFertility = ""
'                    If (MyCLng(rsLocation!AreaSpeciesFertilityPercent) <> 0) Then
'                        zFertility = ", fertility " & MyCLng(rsLocation!AreaSpeciesFertilityPercent)
'                    End If
'                    subSendMsgAreaAll "&a" & strForceSize(lCounter, 5, " ", "A") & zMarker & strForceSize(MyCStr(rsLocation!AreaName), 35, " ", "A") & " - X" & MyCLng(rsLocation!X) & " Y" & MyCLng(rsLocation!Y) & " Z" & MyCLng(rsLocation!Z) & zFertility, lPX, lPY, lPZ
'                    rsLocation.MoveNext
'                Loop
'                Set rsLocation = Nothing
                
'                If (bCheckAreaExists("", lCX, lCY, lCZ, False)) Then
'                    subSendMsgAreaAll "&aDeep space ping confirmed, 'there is a mass at X" & lCX & " Y" & lCY & " Z" & lCZ & "'", lPX, lPY, lPZ
'                    'subSendMsgAreaAll gblzFBYEL & "The wind picks up and the area is illuminated, then all is quiet a moment later.", lCX, lCY, lCZ
'                End If
                
                MyDB.Execute "UPDATE tblPlayer SET CEssence = [CEssence]-" & cstlEssenceCost & ", CMana = [CMana]-" & cstlManaCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            Else
                subSendMsgAreaAll "&aOnboard computer reports, 'The navigator is short " & (cstlManaCost - lMana) & " mana.'", lPX, lPY, lPZ
            End If
        Else
            subSendMsgAreaAll "&aOnboard computer reports, 'The navigator is short " & (cstlEssenceCost - lEssence) & " essence.'", lPX, lPY, lPZ
        End If
    Else
        subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'X" & lCX & " Y" & lCY & " Z" & lCZ & " is " & lCalcuDistance - (lCalcuScanLevel * 10) & " parsecs " & vbCrLf & "over level " & lCalcuScanLevel & " scanner capabilities.'", lPX, lPY, lPZ
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetDeepSpaceScan," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subFleetDeepSpaceScanMyWorlds(lSSScanLevel As Long, lPX As Long, lPY As Long, lPZ As Long, lEssence As Long, lMana As Long, lPlayerID As Long, Optional bOverride As Boolean)
On Error GoTo Err_Check 'SS WORLD SCAN
    Const cstlManaCost = 150
    Const cstlEssenceCost = 2250
    Dim lTWormHoles As Long
    Dim lTAreaMasses As Long
    Dim lTBioMasses As Long
    Dim lTPlayerMasses As Long
    Dim lTFuelMasses As Long
    Dim lCalcuScanLevel As Long
    Dim bScan As Boolean
    Dim lCounter As Long
    Dim rsLocation As Recordset
    Dim zAreaName As String
    Dim lDX As Long
    Dim lDY As Long
    Dim lDZ As Long
    Dim lCalcuWHDistanceStart As Long 'Dim lCalcuWHDistanceStop As Long
    
    lCalcuScanLevel = lSSScanLevel
    bScan = True
    If (lEssence >= cstlEssenceCost) Then
        If (lMana >= cstlManaCost) Then
            Set rsLocation = MyDB.OpenRecordset("SELECT CLNG(SQR(Abs([X]-" & lPX & ") * Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")*Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") * Abs([Z]-" & lPZ & "))) AS DistanceToGo, tblArea.ColonistHostileForces, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.ColonistsNumber, tblArea.AreaSpeciesFertilityPercent, tblArea.ColonistsPlayerID FROM tblArea WHERE (((tblArea.ColonistsPlayerID)=" & lPlayerID & ")) ORDER BY (Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ")), tblArea.AreaName;", dbOpenSnapshot)
            If (Not rsLocation.EOF) Then
                Do While (Not rsLocation.EOF)
                    lDX = MyCLng(rsLocation!x)
                    lDY = MyCLng(rsLocation!y)
                    lDZ = MyCLng(rsLocation!z)
                    lCalcuWHDistanceStart = lReturnDistanceSpacial(lPX, lPY, lPZ, lDX, lDY, lDZ)
                    lCounter = lCounter + 1
                    zAreaName = MyCStr(rsLocation!AreaName)
                    Do While (InStr(zAreaName, " ") > 0 And Len(zAreaName) > 30)
                        zAreaName = zDropFirstWordCleanLine(zAreaName)
                    Loop
                    Select Case (MyCLng(rsLocation!ColonistHostileForces) > 0)
                        Case True
                            subSendMsgAreaAll "&a" & strForceSize(lCounter, 5, " ", "A") & strForceSize(zAreaName, 30, " ", "A") & " [d" & MyCStr(rsLocation!DistanceToGo) & "] [" & MyCLng(rsLocation!x) & " " & MyCLng(rsLocation!y) & " " & MyCLng(rsLocation!z) & "] [g" & MyCLng(rsLocation!AreaSpeciesFertilityPercent) & "] [c" & MyCLng(rsLocation!ColonistsNumber) & "] &R[h!" & MyCLng(rsLocation!ColonistHostileForces) & "]", lPX, lPY, lPZ
                        Case Else
                            subSendMsgAreaAll "&a" & strForceSize(lCounter, 5, " ", "A") & strForceSize(zAreaName, 30, " ", "A") & " [d" & MyCStr(rsLocation!DistanceToGo) & "] [" & MyCLng(rsLocation!x) & " " & MyCLng(rsLocation!y) & " " & MyCLng(rsLocation!z) & "] [g" & MyCLng(rsLocation!AreaSpeciesFertilityPercent) & "] [c" & MyCLng(rsLocation!ColonistsNumber) & "]", lPX, lPY, lPZ
                    End Select
                    rsLocation.MoveNext
                Loop
                Set rsLocation = Nothing
            Else
                subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'No colonies detected.'", lPX, lPY, lPZ
            End If
            Set rsLocation = Nothing
            
            MyDB.Execute "UPDATE tblPlayer SET CEssence = [CEssence]-" & cstlEssenceCost & ", CMana = [CMana]-" & cstlManaCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
        Else
            subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'The navigator is short " & (cstlManaCost - lMana) & " mana.'", lPX, lPY, lPZ
        End If
    Else
        subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'The navigator is short " & (cstlEssenceCost - lEssence) & " essence.'", lPX, lPY, lPZ
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetDeepSpaceScanMyWorlds," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subShipSignature(zFailedMsg As String, zDetectedMsg As String, lRange As Long, lCloakingDeviceDuration As Long, lCloakingDeviceLevel As Long, lX As Long, lY As Long, lZ As Long, bAllowMobShipReactSig As Boolean)
On Error GoTo Err_Check
'This procedure is only used to send a message from a point and beyond according to the cloaking device and Range.
'Range can be scanner range level or engine movement level etc...
'The exact location of lX lY lZ will not recieve a message.
'Used in subStarshipMovement, subFleetPingStarships
    Dim rsScan As Recordset
    Dim lAX As Long
    Dim lAY As Long
    Dim lAZ As Long
    Dim lDetected As Long 'number of starships that detected us
    Dim lPulseRange As Long
    Dim lDistanceToGo As Long
    Dim lHouseDetected As Long
    Dim lSSDetected As Long
    Dim lColonyDetected As Long
    Dim lMilitaryDetected As Long
    Dim zInfo As String
    Dim lSSAreaID As Long
    Dim lSSHullIntegrity As Long
    Dim zMainAreaName As String
    Dim lMainSSHullIntegrity As Long
    
    'this creates a message signature
    'all messages will end with a coordinate ie:
    'YOURMESSAGEx0 y-1 z0
    
    'Someone with a very powerful scan range will be detected unless they have
    'and equal amount of cloak on.
    'This binds area and player together
    'Signature will not be counted if a player is not online in that room
    lDetected = -1 'minus our starship which is always detected
    lHouseDetected = 0
    lSSDetected = 0 'minus our starship which is always detected
    lColonyDetected = 0
    lMilitaryDetected = 0
    
    If (lCloakingDeviceDuration > 0) Then 'if the cloaking device is on then we reduce the starships signature
        lPulseRange = (lRange - lCloakingDeviceLevel)
    Else
        lPulseRange = lRange
    End If
    If (lPulseRange < 9) Then lPulseRange = 9
    If (lRange < 9) Then lRange = 9 'everyone can see everyone from eye distance away.
    
    'this will also pick our own starship up which is good
    Set rsScan = MyDB.OpenRecordset("SELECT SSHullIntegrity, AreaName FROM tblArea WHERE (X=" & lX & " And Y=" & lY & " AND Z=" & lZ & " AND PlayerType>0);", dbOpenSnapshot)
    If (Not rsScan.EOF) Then 'this is the ship that caused the signature, the main ship
        zMainAreaName = MyCStr(rsScan!AreaName)
        lMainSSHullIntegrity = MyCLng(rsScan!SSHullIntegrity)
    End If
    Set rsScan = Nothing
    
    Set rsScan = MyDB.OpenRecordset("SELECT SSHullIntegrity, AreaID, MobSpaceshipLevel, X, Y, Z, AreaName, PlayerType FROM tblArea WHERE (X>=" & lX - lPulseRange & " And X<=" & lX + lPulseRange & " AND Y>=" & lY - lPulseRange & " And Y<=" & lY + lPulseRange & " AND Z>=" & lZ - lPulseRange & " And Z<=" & lZ + lPulseRange & " AND PlayerType>0);", dbOpenSnapshot)
    Do While (Not rsScan.EOF)
        lSSAreaID = MyCLng(rsScan!AreaID)
        lAX = MyCLng(rsScan!x)
        lAY = MyCLng(rsScan!y)
        lAZ = MyCLng(rsScan!z)
        lSSHullIntegrity = MyCLng(rsScan!SSHullIntegrity)
        lDistanceToGo = Abs(lX - lAX) + Abs(lY - lAY) + Abs(lZ - lAZ) 'distance from the ship that detected the signature and the target ship
        If (lngSQLRecordCount("SELECT Count(tblPlayer.PlayerID) AS CountOfPlayerID From tblPlayer GROUP BY Len([PortID]), tblPlayer.X, tblPlayer.Y, tblPlayer.Z HAVING (((Len([PortID]))>1) AND ((tblPlayer.X)=" & lAX & ") AND ((tblPlayer.Y)=" & lAY & ") AND ((tblPlayer.Z)=" & lAZ & "));") <> 0) Then 'if there is a player on any of the houses, mobships, colony, military areas they get chance to see the signature
            If (lDistanceToGo > 0) Then
                lDetected = lDetected + 1
                Select Case MyCLng(rsScan!PlayerType)
                    Case 1
                        lHouseDetected = lHouseDetected + 1
                    Case 2
                        lSSDetected = lSSDetected + 1
                    Case 3
                        lColonyDetected = lColonyDetected + 1
                    Case 4
                        lMilitaryDetected = lMilitaryDetected + 1
                End Select
                
                'we report the signature the distance and the location of the spied ship
                subSendMsgAreaAllNotBM "&B[SIG-DETECTED] &a" & vbCrLf & zDetectedMsg & vbCrLf & "Signature data [h" & lMainSSHullIntegrity & " s" & lPulseRange & "/" & lRange & "%] [d" & lDistanceToGo & "] [detected] [cx" & lX & " y" & lY & " z" & lZ & "]", lAX, lAY, lAZ
            Else 'different events for own starship
                subSendMsgAreaAllNotBM "&B[STARSHIP STATUS] &a" & vbCrLf & zDetectedMsg & vbCrLf & "Signature data [h" & lMainSSHullIntegrity & " s" & lPulseRange & "/" & lRange & "%] [d" & lDistanceToGo & "] [detected] [cx" & lX & " y" & lY & " z" & lZ & "]", lAX, lAY, lAZ
            End If
        End If
        
        If (lDistanceToGo > 0) Then 'doesnt have to be a player onboard
            If (bAllowMobShipReactSig) Then 'mobs in the area react to certain sigs
                If (MyCLng(rsScan!MobSpaceshipLevel) > 0) Then 'if a mob ship saw the signature it will head there
                    MyDB.Execute "UPDATE tblArea SET SSN=True, SSNX=" & lX & ", SSNY=" & lY & ", SSNZ=" & (lZ - lRandom(9)) & " WHERE (SSN=False AND MobSpaceshipLevel>" & lRandom(10) & " AND AreaID=" & lSSAreaID & ");", dbFailOnError
                End If
            End If
        End If
        rsScan.MoveNext
    Loop
    Set rsScan = Nothing
    
    If (lDetected > 0) Then
        If (Len(zFailedMsg) > 0) Then subSendMsgAreaAll "&a" & zFailedMsg, lX, lY, lZ
        zInfo = ""
        If (lHouseDetected > 0) Then zInfo = zInfo & "[houses " & MyCLng(lHouseDetected) & "] "
        If (lSSDetected > 0) Then zInfo = zInfo & "[sships " & MyCLng(lSSDetected) & "] "
        If (lColonyDetected > 0) Then zInfo = zInfo & "[colonies " & MyCLng(lColonyDetected) & "] "
        If (lMilitaryDetected > 0) Then zInfo = zInfo & "[military " & MyCLng(lMilitaryDetected) & "] "

        Select Case lDetected
            Case 1
                subSendMsgAreaAll "&r*We were Detected* &a" & zInfo, lX, lY, lZ
            Case Else
                subSendMsgAreaAll "&r*We were Detected* &a" & zInfo & "[=" & lDetected & "]", lX, lY, lZ
        End Select
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subShipSignature," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lAreaStarshipBoardedXYZ(lScanX As Long, lScanY As Long, lScanZ As Long) As Long
On Error GoTo Err_Check
    lAreaStarshipBoardedXYZ = lngSQLRecordCount("SELECT tblArea.AreaName FROM tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X) GROUP BY tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblPlayer.PortID HAVING (((tblArea.X)=" & lScanX & ") AND ((tblArea.Y)=" & lScanY & ") AND ((tblArea.Z)=" & lScanZ & ") AND ((tblPlayer.PortID)<>'0'));")
    Exit Function
Err_Check:
    subWriteErrorFile "lAreaStarshipBoardedXYZ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lAreaStarshipMobsInAreaXYZ(lScanX As Long, lScanY As Long, lScanZ As Long, lPlayerLevel As Long) As Long
On Error GoTo Err_Check
    lAreaStarshipMobsInAreaXYZ = lngSQLRecordCount("SELECT MobName FROM tblMob WHERE (X=" & lScanX & " AND Y=" & lScanY & " AND Z=" & lScanZ & " AND RespawnDelay=0 AND Beamable<" & lPlayerLevel & ");")
    Exit Function
Err_Check:
    subWriteErrorFile "lAreaStarshipMobsInAreaXYZ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Function lMaxStarshipCommandDelay(lCalc As Long) As Long
'Chart StarshipCommandDelay
On Error Resume Next
    Const cstiBalance = 5
    Dim lReturn As Long
    Select Case lCalc
        Case 0 To 25
            lReturn = 143
        Case 26 To 50
            lReturn = 128
        Case 51 To 100
            lReturn = 112
        Case 101 To 200
            lReturn = 96
        Case 201 To 600
            lReturn = 80
        Case 601 To 1200
            lReturn = 64
        Case 1201 To 2000
            lReturn = 48
        Case 2001 To 3000
            lReturn = 32
        Case 3001 To 5000
            lReturn = 16
        Case 5001 To 7000
            lReturn = 8
        Case 7001 To 9000
            lReturn = 4
        Case Else
            lReturn = 2
    End Select
    lMaxStarshipCommandDelay = lReturn + cstiBalance
End Function
Public Sub subFleetSetCommandDelay(lSSRangeLevel As Long, lSSPowerLevel As Long, lSSBatteryLevel As Long, lPlayerID As Long)
On Error GoTo Err_Check
    Dim lCalcPowerLevel As Long
    Dim bGoodPower As Boolean
    Dim lRollA As Long
    Dim lRollB As Long
    'This is used when any system that needs to draw power is used
    'This is to help prevent players from over using some starship commands.
    
    bGoodPower = (lSSPowerLevel <= lSSBatteryLevel)
    lCalcPowerLevel = MyCLng(lSSPowerLevel / 4)
    If (bGoodPower) Then 'Good power means there is lots of battery reserve to keep fluxuations away
        lRollA = MyCLng(lSSRangeLevel / 4) + (lCalcPowerLevel) + (lCalcPowerLevel) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + MyCLng(lSSBatteryLevel / lRandom(2))
        lRollB = MyCLng(lSSRangeLevel / 4) + (lCalcPowerLevel) + (lCalcPowerLevel) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + MyCLng(lSSBatteryLevel / lRandom(2))
    Else
        'all this does is fluxes the power levels
        lRollA = MyCLng(lSSRangeLevel / 4) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + MyCLng(lSSBatteryLevel / lRandom(3))
        lRollB = MyCLng(lSSRangeLevel / 4) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + lRandom(lCalcPowerLevel) + MyCLng(lSSBatteryLevel / lRandom(3))
    End If
    'Set the player up so that he cannot spam ping
    MyDB.Execute "UPDATE tblPlayer SET StarshipCommandDelay=" & (lMaxStarshipCommandDelay(lRollA) + (lRandom(lMaxStarshipCommandDelay(lRollB)))) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetSetCommandDelay," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lReturnDistanceSpacial(x1 As Long, y1 As Long, z1 As Long, x2 As Long, y2 As Long, z2 As Long) As Long
    Dim lReturn As Long 'starship distance calculation
    lReturn = Sqr(Abs(x2 - x1) * Abs(x2 - x1) + Abs(y2 - y1) * Abs(y2 - y1) + Abs(z2 - z1) * Abs(z2 - z1))
    lReturnDistanceSpacial = lReturn
End Function
Private Sub subFleetPingStarships(lPX As Long, lPY As Long, lPZ As Long, lPlayerLevel As Long, lEssence As Long, lMana As Long, lPlayerID As Long, zTargetShipName As String, lStarshipCommandDelay As Long, lMatchPlayerType As Long, zPortID As String)
On Error GoTo Err_Check
'StarshipCommandDelay
    'Grid
    Const cstcharColonyOwnership = "O"
    Const cstcharColonyTarget = "C"
    
    Const cstlManaCost = 850
    Const cstlEssenceCost = 1250
    Dim lScanRange As Long
    Dim rsSS As Recordset
    Dim rsScan As Recordset
    Dim zShipLocations As String
    Dim lTStarships As Long
    Dim iShipLocations As Integer
    Dim lPulseRange As Long
    Dim lScanX As Long
    Dim lScanY As Long
    Dim lScanZ As Long
    Dim zAdditionalMsg As String
    Dim lGetAreaStarshipBoardedXYZ As Long
    Dim zSQL As String
    Dim lDistanceToGo As Long
    Dim zAreaName As String
    Dim rsLocation As Recordset
    Dim lCounter As Long
    
    Dim zStarShipName As String
    Dim lSSPowerLevel As Long
    Dim lSSBatteryLevel As Long
    Dim lSSScanLevel As Long
    Dim lCloakingDeviceDuration As Long
    Dim lCloakingDeviceLevel As Long
    Dim lPowerBonus As Long
    Dim lCalcuWHDistanceStart As Long
    Dim lCalcuWHDistanceStop As Long
    
    Dim lSSHullIntegrity As Long
    
    Set rsSS = MyDB.OpenRecordset("SELECT SSPowerLevel, SSBatteryLevel, SSScanLevel, X, Y, Z, CloakingDeviceDuration, CloakingDeviceLevel, AreaName FROM tblArea WHERE (SSScanLevel>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType>1);", dbOpenSnapshot) 'we are on our starship
    If (Not rsSS.EOF) Then
        lSSScanLevel = MyCLng(rsSS!SSScanLevel) 'this is the true scan range
        lScanRange = MyCLng(lSSScanLevel / 15) 'this is so ships close by can detect the ship using this scan proc.
        lCounter = 0
        'first we show any wormholes in the area
        Set rsLocation = MyDB.OpenRecordset("SELECT * FROM tblAreaSpaceFlightEmote WHERE (DStatus<>0) AND (XS>" & lPX - lSSScanLevel & " And XE<" & lPX + lSSScanLevel & ") AND (YS>" & lPY - lSSScanLevel & " And YE<" & lPY + lSSScanLevel & ") AND (ZS>" & lPZ - lSSScanLevel & " And ZE<" & lPZ + lSSScanLevel & ") ORDER BY ZE DESC;", dbOpenSnapshot)
        Do While (Not rsLocation.EOF)
            lCounter = lCounter + 1
            lCalcuWHDistanceStart = lReturnDistanceSpacial(lPX, lPY, lPZ, MyCLng(rsLocation!XS), MyCLng(rsLocation!YS), MyCLng(rsLocation!zS)) 'Abs(lPX - MyCLng(rsLocation!XS)) + Abs(lPY - MyCLng(rsLocation!YS)) + Abs(lPZ - MyCLng(rsLocation!ZS))
            lCalcuWHDistanceStop = lReturnDistanceSpacial(lPX, lPY, lPZ, MyCLng(rsLocation!DX), MyCLng(rsLocation!DY), MyCLng(rsLocation!DZ)) 'Abs(lPX - MyCLng(rsLocation!DX)) + Abs(lPY - MyCLng(rsLocation!DY)) + Abs(lPZ - MyCLng(rsLocation!DZ))
            subSendMsgAreaAll "&a" & strForceSize(lCounter, 5, " ", "A") & " Wormhole spans from XS" & MyCLng(rsLocation!XS) & " to XE" & MyCLng(rsLocation!XE) & vbCrLf & "                          YS" & MyCLng(rsLocation!YS) & " to YE" & MyCLng(rsLocation!YE) & vbCrLf & "                          ZS" & MyCLng(rsLocation!zS) & " to ZE" & MyCLng(rsLocation!zE) & " d[" & lCalcuWHDistanceStart & "]" & vbCrLf & "                    EXITS X:" & MyCLng(rsLocation!DX) & " Y:" & MyCLng(rsLocation!DY) & " Z:" & MyCLng(rsLocation!DZ) & " d[" & lCalcuWHDistanceStop & "]", lPX, lPY, lPZ
            rsLocation.MoveNext
        Loop
        Set rsLocation = Nothing
        zStarShipName = MyCStr(rsSS!AreaName)
        lSSPowerLevel = MyCLng(rsSS!SSPowerLevel)
        lSSBatteryLevel = MyCLng(rsSS!SSBatteryLevel)
        
        lCloakingDeviceDuration = MyCLng(rsSS!CloakingDeviceDuration)
        lCloakingDeviceLevel = MyCLng(rsSS!CloakingDeviceLevel)
        'now we use the pulse range to see starships and they might eye me
        If (lStarshipCommandDelay = 0) Then
            If (lEssence >= cstlEssenceCost) Then
                If (lMana >= cstlManaCost) Then
                    Select Case lMatchPlayerType
                        Case 0
                            lPowerBonus = 2500
                            subShipSignature "", zStarShipName & vbCrLf & " [Area scan]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                        Case 1
                            lPowerBonus = 3000
                            subShipSignature "", zStarShipName & vbCrLf & " [House scan]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                        Case 2
                            lPowerBonus = 3500
                            subShipSignature "", zStarShipName & vbCrLf & " [ping]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                        Case 3
                            lPowerBonus = 5000
                            subShipSignature "", zStarShipName & vbCrLf & " [scan]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                        Case Else
                            lPowerBonus = 900
                            subShipSignature "", zStarShipName & vbCrLf & " [Military scan]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                    End Select
                    
                    lTStarships = 0
                    'lParsecs = Abs(lCX - lPX) + Abs(lCY - lPY) + Abs(lCZ - lPZ)
                    Select Case lMatchPlayerType
                        Case 0
                            Select Case (IsNumeric(zTargetShipName) Or zTargetShipName = "")
                                Case True 'search around the ship
                                    zSQL = "SELECT TOP 15 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblArea.SSHullIntegrity, tblArea.ColonistHostileForces, tblArea.PlayerID, tblArea.ColonistsPlayerID, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.SSN, tblArea.SSNX, tblArea.SSNY, tblArea.SSNZ, tblArea.AreaSpeciesFertilityPercent FROM tblArea WHERE (((tblArea.X)>" & lPX - lSSScanLevel & " And (tblArea.X)<" & lPX + lSSScanLevel & ") AND ((tblArea.Y)>" & lPY - lSSScanLevel & " And (tblArea.Y)<" & lPY + lSSScanLevel & ") AND ((tblArea.Z)>" & lPZ - lSSScanLevel & " And (tblArea.Z)<" & lPZ + lSSScanLevel & ") AND ((tblArea.PlayerType)=" & lMatchPlayerType & ") AND ((tblArea.CloakingDeviceDuration)=0)) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblArea.AreaName;"
                                Case False 'check for a ship name
                                    zSQL = "SELECT TOP 15 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblArea.SSHullIntegrity, tblArea.ColonistHostileForces, tblArea.PlayerID, tblArea.ColonistsPlayerID, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.SSN, tblArea.SSNX, tblArea.SSNY, tblArea.SSNZ, tblArea.AreaSpeciesFertilityPercent FROM tblArea WHERE ((AreaName Like '*" & zTargetShipName & "*') AND ((tblArea.X)>" & lPX - lSSScanLevel & " And (tblArea.X)<" & lPX + lSSScanLevel & ") AND ((tblArea.Y)>" & lPY - lSSScanLevel & " And (tblArea.Y)<" & lPY + lSSScanLevel & ") AND ((tblArea.Z)>" & lPZ - lSSScanLevel & " And (tblArea.Z)<" & lPZ + lSSScanLevel & ") AND ((tblArea.PlayerType)=" & lMatchPlayerType & ") AND ((tblArea.CloakingDeviceDuration)=0)) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblArea.AreaName;"
                            End Select
                        Case 1 To 2
                            Select Case (IsNumeric(zTargetShipName) Or zTargetShipName = "")
                                Case True 'search around the ship
                                    zSQL = "SELECT TOP 40 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblArea.SSHullIntegrity, tblArea.ColonistHostileForces, tblArea.PlayerID, tblArea.ColonistsPlayerID, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.SSN, tblArea.SSNX, tblArea.SSNY, tblArea.SSNZ, tblArea.AreaSpeciesFertilityPercent FROM tblArea WHERE (((tblArea.X)>" & lPX - lSSScanLevel & " And (tblArea.X)<" & lPX + lSSScanLevel & ") AND ((tblArea.Y)>" & lPY - lSSScanLevel & " And (tblArea.Y)<" & lPY + lSSScanLevel & ") AND ((tblArea.Z)>" & lPZ - lSSScanLevel & " And (tblArea.Z)<" & lPZ + lSSScanLevel & ") AND ((tblArea.PlayerType)=" & lMatchPlayerType & ") AND ((tblArea.CloakingDeviceDuration)=0)) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblArea.AreaName;"
                                Case False 'check for a ship name
                                    zSQL = "SELECT TOP 40 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblArea.SSHullIntegrity, tblArea.ColonistHostileForces, tblArea.PlayerID, tblArea.ColonistsPlayerID, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.SSN, tblArea.SSNX, tblArea.SSNY, tblArea.SSNZ, tblArea.AreaSpeciesFertilityPercent FROM tblArea WHERE ((AreaName Like '*" & zTargetShipName & "*') AND ((tblArea.X)>" & lPX - lSSScanLevel & " And (tblArea.X)<" & lPX + lSSScanLevel & ") AND ((tblArea.Y)>" & lPY - lSSScanLevel & " And (tblArea.Y)<" & lPY + lSSScanLevel & ") AND ((tblArea.Z)>" & lPZ - lSSScanLevel & " And (tblArea.Z)<" & lPZ + lSSScanLevel & ") AND ((tblArea.PlayerType)=" & lMatchPlayerType & ") AND ((tblArea.CloakingDeviceDuration)=0)) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblArea.AreaName;"
                            End Select
                        Case Else
                            Select Case (IsNumeric(zTargetShipName) Or zTargetShipName = "")
                                Case True 'search around the ship
                                    zSQL = "SELECT TOP 40 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblArea.SSHullIntegrity, tblArea.ColonistHostileForces, tblArea.PlayerID, tblArea.ColonistsPlayerID, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.SSN, tblArea.SSNX, tblArea.SSNY, tblArea.SSNZ, tblArea.AreaSpeciesFertilityPercent FROM tblArea WHERE (((tblArea.X)>" & lPX - lSSScanLevel & " And (tblArea.X)<" & lPX + lSSScanLevel & ") AND ((tblArea.Y)>" & lPY - lSSScanLevel & " And (tblArea.Y)<" & lPY + lSSScanLevel & ") AND ((tblArea.Z)>" & lPZ - lSSScanLevel & " And (tblArea.Z)<" & lPZ + lSSScanLevel & ") AND ((tblArea.PlayerType)>=" & lMatchPlayerType & ") AND ((tblArea.CloakingDeviceDuration)=0)) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblArea.AreaName;"
                                Case False 'check for a ship name
                                    zSQL = "SELECT TOP 40 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblArea.SSHullIntegrity, tblArea.ColonistHostileForces, tblArea.PlayerID, tblArea.ColonistsPlayerID, tblArea.AreaName, tblArea.X, tblArea.Y, tblArea.Z, tblArea.SSN, tblArea.SSNX, tblArea.SSNY, tblArea.SSNZ, tblArea.AreaSpeciesFertilityPercent FROM tblArea WHERE ((AreaName Like '*" & zTargetShipName & "*') AND ((tblArea.X)>" & lPX - lSSScanLevel & " And (tblArea.X)<" & lPX + lSSScanLevel & ") AND ((tblArea.Y)>" & lPY - lSSScanLevel & " And (tblArea.Y)<" & lPY + lSSScanLevel & ") AND ((tblArea.Z)>" & lPZ - lSSScanLevel & " And (tblArea.Z)<" & lPZ + lSSScanLevel & ") AND ((tblArea.PlayerType)>=" & lMatchPlayerType & ") AND ((tblArea.CloakingDeviceDuration)=0)) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblArea.AreaName;"
                            End Select
                    End Select
                    Set rsScan = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                    If (Not rsScan.EOF) Then
                        rsScan.MoveLast
                        lTStarships = rsScan.RecordCount
                        rsScan.MoveFirst
                        
                        If (lCloakingDeviceDuration > 0) Then 'if the cloaking device is on then we reduce the starships signature
                            lPulseRange = (lScanRange - lCloakingDeviceLevel)
                            'zAdditionalMsg = "&a[Cloaked] "
                        Else
                            lPulseRange = lScanRange
                            'zAdditionalMsg = ""
                        End If
                        If (lPulseRange < 9) Then lPulseRange = 9
                        
                        iShipLocations = 0
                        zShipLocations = ""
                        zAdditionalMsg = "        "
                        'we now get the info from the ping
                        Do While (Not rsScan.EOF)
                            lSSHullIntegrity = MyCLng(rsScan!SSHullIntegrity)
                            lScanX = MyCLng(rsScan!x)
                            lScanY = MyCLng(rsScan!y)
                            lScanZ = MyCLng(rsScan!z)
                            
                            If (lScanX <> lPX Or lScanY <> lPY Or lScanZ <> lPZ) Then 'we leave out our own ship
                                lDistanceToGo = (MyCLng(rsScan!OrderDistance))
                                'mark ships in range or detect us or dont detect us at all
                                If (lScanX > lPX - lPulseRange And lScanX < lPX + lPulseRange And lScanY > lPY - lPulseRange And lScanY < lPY + lPulseRange And lScanZ > lPZ - lPulseRange And lScanZ < lPZ + lPulseRange) Then
                                    'in here are all the in range players that saw who just did this ss ping
                                    lGetAreaStarshipBoardedXYZ = lAreaStarshipBoardedXYZ(lScanX, lScanY, lScanZ)
                                    Select Case lGetAreaStarshipBoardedXYZ
                                        Case 0
                                            zAdditionalMsg = "(range) "
                                        Case Else
                                            zAdditionalMsg = "D!" & strForceSize(MyCStr(lGetAreaStarshipBoardedXYZ) & "CU", 6, " ", "A")
                                    End Select
                                Else
                                    zAdditionalMsg = "  (ok)  "
                                End If
                                
                                'we have different marker types for colonists
                                If (MyCLng(rsScan!ColonistsPlayerID) = 0) Then
                                    zAdditionalMsg = zAdditionalMsg & "  "
                                Else
                                    If (MyCLng(rsScan!ColonistsPlayerID) = lPlayerID) Then
                                        zAdditionalMsg = zAdditionalMsg & cstcharColonyOwnership & " "
                                    Else
                                        zAdditionalMsg = zAdditionalMsg & cstcharColonyTarget & " "
                                    End If
                                End If
                                
                                Select Case (lSSHullIntegrity > 97)
                                    Case True
                                        zAdditionalMsg = zAdditionalMsg & "     "
                                    Case False
                                        zAdditionalMsg = zAdditionalMsg & " " & strForceSize(MyCStr(lSSHullIntegrity), 2, " ", "B") & "% "
                                End Select
                                
                                zAreaName = MyCStr(rsScan!AreaName)
                                Do While (InStr(zAreaName, " ") > 0 And Len(zAreaName) > 30)
                                    zAreaName = zDropFirstWordCleanLine(zAreaName)
                                Loop
                                zShipLocations = zShipLocations & zAdditionalMsg & " " & strForceSize(zAreaName, 30, " ", "A") & " d[" & lDistanceToGo & "] [" & lScanX & " " & lScanY & " " & lScanZ & "]"
                                If (MyCLng(rsScan!AreaSpeciesFertilityPercent) <> 0) Then zShipLocations = zShipLocations & " [g" & MyCStr(rsScan!AreaSpeciesFertilityPercent) & "]"
                                
                                Select Case (MyCLng(rsScan!ColonistHostileForces) > 0)
                                    Case True
                                        zShipLocations = zShipLocations & " [h!" & MyCLng(rsScan!ColonistHostileForces) & "]"
                                End Select
                                zShipLocations = zShipLocations & vbCrLf
                                iShipLocations = iShipLocations + 1
                                If (iShipLocations > 9) Then
                                    subSendMsgAreaAll zShipLocations, lPX, lPY, lPZ
                                    zShipLocations = ""
                                    iShipLocations = 0
                                End If
                            End If
                            rsScan.MoveNext
                        Loop
                        If (iShipLocations > 0) Then
                            subSendMsgAreaAll zShipLocations, lPX, lPY, lPZ
                            zShipLocations = ""
                            iShipLocations = 0
                        End If
                    Else
                        subSendMsg "&g'We are in deep space, no objects scanned.'", zPortID
                    End If
                    Set rsScan = Nothing
                    subFleetSetCommandDelay lSSScanLevel, (lSSPowerLevel * 4) + 3000 + lPowerBonus, (lSSBatteryLevel * 4) + 2000 + lPowerBonus, lPlayerID
                    MyDB.Execute "UPDATE tblPlayer SET CEssence = [CEssence]-" & cstlEssenceCost & ", CMana = [CMana]-" & cstlManaCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                Else
                    subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'The navigator is short " & (cstlManaCost - lMana) & " mana.'", lPX, lPY, lPZ
                End If
            Else
                subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'The navigator is short " & (cstlEssenceCost - lEssence) & " essence.'", lPX, lPY, lPZ
            End If
        Else
            subSendMsgAreaAll "&aDefense station computer reports, 'the main battery was drained, recharging in progress.'", lPX, lPY, lPZ
        End If
    Else
        subSendMsg "&gThis area has no scanners to use.", zPortID
    End If
    Set rsSS = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetPingStarships," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subFleetBeamAboard(lPX As Long, lPY As Long, lPZ As Long, lPlayerLevel As Long, lEssence As Long, lMana As Long, lPlayerID As Long, zBeamUpTarget As String, lStarshipCommandDelay As Long, lMatchPlayerType As Long, zPortID As String)
On Error GoTo Err_Check
'StarshipCommandDelay
    'Gride
    Const cstlManaCost = 250
    Const cstlEssenceCost = 350
    Dim lScan As Long
    Dim lBeamableMobID As Long
    Dim lBeamableMobX As Long
    Dim lBeamableMobY As Long
    Dim lBeamableMobZ As Long
    Dim lScanRange As Long
    Dim rsSS As Recordset
    Dim rsScan As Recordset
    Dim zBeamablesLocations As String
    Dim lTBeamableTargets As Long
    Dim iShipLocations As Integer
    Dim lPulseRange As Long
    Dim lScanX As Long
    Dim lScanY As Long
    Dim lScanZ As Long
    Dim zAdditionalMsg As String
    Dim lGetAreaMobTotalXYZ As Long
    Dim zSQL As String
    Dim lDistanceToGo As Long
    Dim zMobName As String
    Dim rsLocation As Recordset
    Dim lCounter As Long
    Dim bBeamScan As Boolean
    
    Dim zStarShipName As String
    Dim lSSPowerLevel As Long
    Dim lSSBatteryLevel As Long
    Dim lSSScanLevel As Long
    Dim lCloakingDeviceDuration As Long
    Dim lCloakingDeviceLevel As Long
    Dim lPowerBonus As Long
    Dim lCalcuWHDistanceStart As Long
    Dim lCalcuWHDistanceStop As Long
    
    bBeamScan = (LCase(zBeamUpTarget) = "scan")
    
    Set rsSS = MyDB.OpenRecordset("SELECT SSPowerLevel, SSBatteryLevel, SSScanLevel, X, Y, Z, CloakingDeviceDuration, CloakingDeviceLevel, AreaName FROM tblArea WHERE (SSScanLevel>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType>1);", dbOpenSnapshot) 'we are on a starship
    If (Not rsSS.EOF) Then
        lSSScanLevel = MyCLng(rsSS!SSScanLevel) 'this is the true scan range
        lScanRange = MyCLng(lSSScanLevel / 15) 'this is so ships close by can detect the ship using this scan proc.
        lCounter = 0
        zStarShipName = MyCStr(rsSS!AreaName)
        lSSPowerLevel = MyCLng(rsSS!SSPowerLevel)
        lSSBatteryLevel = MyCLng(rsSS!SSBatteryLevel)
        lCloakingDeviceDuration = MyCLng(rsSS!CloakingDeviceDuration)
        lCloakingDeviceLevel = MyCLng(rsSS!CloakingDeviceLevel)
        'now we use the pulse range to see starships and they might eye me
        If (lStarshipCommandDelay = 0) Then
            If (lEssence >= cstlEssenceCost) Then
                If (lMana >= cstlManaCost) Then
                    Select Case lMatchPlayerType
                        Case 1
                            lPowerBonus = 300
                        Case Else
                            lPowerBonus = 425
                    End Select
                    
                    If (bBeamScan) Then
                        lCloakingDeviceLevel = lCloakingDeviceLevel * 2 'this is a narrowed scan and harder to detect
                        subShipSignature "", zStarShipName & vbCrLf & " [focused-ground-scan]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                    Else
                        subShipSignature "", zStarShipName & vbCrLf & " [beaming]", lScanRange, lCloakingDeviceDuration, lCloakingDeviceLevel, lPX, lPY, lPZ, True 'bAllowMobShipReactSig
                    End If
                    
                    lTBeamableTargets = 0
                    'lParsecs = Abs(lCX - lPX) + Abs(lCY - lPY) + Abs(lCZ - lPZ)
                    zSQL = "SELECT TOP 15 Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & ") AS OrderDistance, tblMob.MobName, tblMob.MobID, tblMob.X, tblMob.Y, tblMob.Z FROM tblMob WHERE (((tblMob.Beamable)>0 And (tblMob.Beamable)<=" & lPlayerLevel & " And (tblMob.X)>" & lPX - lSSScanLevel & " And (tblMob.X)<" & lPX + lSSScanLevel & ") AND ((tblMob.Y)>" & lPY - lSSScanLevel & " And (tblMob.Y)<" & lPY + lSSScanLevel & ") AND ((tblMob.Z)>" & lPZ - lSSScanLevel & " And (tblMob.Z)<" & lPZ + lSSScanLevel & ")) ORDER BY Abs([X]-" & lPX & ")+Abs([Y]-" & lPY & ")+Abs([Z]-" & lPZ & "), tblMob.MobName;"
                    Set rsScan = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                    If (Not rsScan.EOF) Then
                        rsScan.MoveLast
                        lTBeamableTargets = rsScan.RecordCount
                        rsScan.MoveFirst
                        
                        If (lCloakingDeviceDuration > 0) Then 'if the cloaking device is on then we reduce the starships signature
                            lPulseRange = (lScanRange - lCloakingDeviceLevel)
                            'zAdditionalMsg = "&a[Cloaked] "
                        Else
                            lPulseRange = lScanRange
                            'zAdditionalMsg = ""
                        End If
                        If (lPulseRange < 9) Then lPulseRange = 9
                        
                        iShipLocations = 0
                        zBeamablesLocations = ""
                        zAdditionalMsg = "        "
                        'we now get the info from the ping
                        lBeamableMobID = 0
                        Do While (Not rsScan.EOF)
                            lScanX = MyCLng(rsScan!x)
                            lScanY = MyCLng(rsScan!y)
                            lScanZ = MyCLng(rsScan!z)
                            
                            If (lScanX <> lPX Or lScanY <> lPY Or lScanZ <> lPZ) Then 'we leave out our own location x y z
                                'Now we try to bring one of the creatures aboard
                                zMobName = LCase(MyCStr(rsScan!MobName)) 'lcase to make matching easier
                                If (Not bBeamScan) Then
                                    If (lBeamableMobID = 0) Then 'short circuit if a mob was found
                                        If (InStr(zMobName, LCase(MyCStr(zBeamUpTarget))) <> 0) Then
                                            lBeamableMobID = rsScan!MobID
                                            lBeamableMobX = rsScan!x
                                            lBeamableMobY = rsScan!y
                                            lBeamableMobZ = rsScan!z
                                        End If
                                    End If
                                End If

                                lDistanceToGo = (MyCLng(rsScan!OrderDistance))
                                'mark ships in range or detect us or dont detect us at all
                                If (lScanX > lPX - lPulseRange And lScanX < lPX + lPulseRange And lScanY > lPY - lPulseRange And lScanY < lPY + lPulseRange And lScanZ > lPZ - lPulseRange And lScanZ < lPZ + lPulseRange) Then
                                    'in here are all the in range players that saw who just did this ss ping
                                    lGetAreaMobTotalXYZ = lAreaStarshipMobsInAreaXYZ(lScanX, lScanY, lScanZ, lPlayerLevel)
                                    Select Case lGetAreaMobTotalXYZ
                                        Case 0
                                            zAdditionalMsg = "(range) "
                                        Case Else
                                            zAdditionalMsg = "D!" & strForceSize(MyCStr(lGetAreaMobTotalXYZ) & "CU", 6, " ", "A")
                                    End Select
                                Else
                                    zAdditionalMsg = "  (ok)  "
                                End If

                                zBeamablesLocations = zBeamablesLocations & zAdditionalMsg & " " & strForceSize(zMobName, 30, " ", "A") & " d[" & lDistanceToGo & "] [" & lScanX & " " & lScanY & " " & lScanZ & "]"
                                zBeamablesLocations = zBeamablesLocations & vbCrLf
                                iShipLocations = iShipLocations + 1
                                If (iShipLocations > 9) Then
                                    subSendMsgAreaAll zBeamablesLocations, lPX, lPY, lPZ
                                    zBeamablesLocations = ""
                                    iShipLocations = 0
                                End If
                            End If
                            rsScan.MoveNext
                        Loop
                        If (iShipLocations > 0) Then
                            subSendMsgAreaAll zBeamablesLocations, lPX, lPY, lPZ
                            zBeamablesLocations = ""
                            iShipLocations = 0
                        End If
                        
                        If (lBeamableMobID <> 0) Then 'Beam the qualifying mob aboard !
                            subSendMsgAreaAll "&W" & "There is a bright FLASH in the room, something disappeared!", lBeamableMobX, lBeamableMobY, lBeamableMobZ
                            subSendMsgAreaAll "&W" & "There is a bright FLASH in the room, something appeared!", lPX, lPY, lPZ
                            'We turn off combat if the mob is in combat
                            For lScan = cstlMinPort To cstlMaxPort 'we go though all the ports for group attackers
                                If (rMCombat(lScan).lID = lBeamableMobID) Then 'make sure it is the correct mob
                                    subCombatEndedInitializeCombatCellsPortID lScan
                                End If
                            Next lScan
                            MyDB.Execute "UPDATE tblMob SET X=" & lPX & ", Y=" & lPY & ", Z=" & lPZ & " WHERE (MobID=" & lBeamableMobID & ");", dbFailOnError
                        End If
                    Else
                        subSendMsg "&g'We are in deep space, no objects scanned.'", zPortID
                    End If
                    Set rsScan = Nothing
                    subFleetSetCommandDelay lSSScanLevel, (lSSPowerLevel * 4) + 3000 + lPowerBonus, (lSSBatteryLevel * 4) + 2000 + lPowerBonus, lPlayerID
                    MyDB.Execute "UPDATE tblPlayer SET CEssence = [CEssence]-" & cstlEssenceCost & ", CMana = [CMana]-" & cstlManaCost & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                Else
                    subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'The navigator is short " & (cstlManaCost - lMana) & " mana.'", lPX, lPY, lPZ
                End If
            Else
                subSendMsgAreaAll "&aOnboard computer reports, " & vbCrLf & "'The navigator is short " & (cstlEssenceCost - lEssence) & " essence.'", lPX, lPY, lPZ
            End If
        Else
            subSendMsgAreaAll "&aDefense station computer reports, 'the main battery was drained, recharging in progress.'", lPX, lPY, lPZ
        End If
    Else
        subSendMsg "&gThis area has no scanners to use.", zPortID
    End If
    Set rsSS = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetBeamAboard," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subFleetStarportRepair(zShipName As String, lPlayerID As Long)
On Error GoTo Err_Check
    Const cstlStarshipCostPerDmg = 15
    Const cstlStarshipCostPerIntegrity = 30
    Dim rsPlayer As Recordset
    Dim rsStarport As Recordset
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lTotalDmg As Long
    Dim lSSHullIntegrity As Long
    Dim lSSLeftHullIntegrity As Long
    Dim rsStarship As Recordset
    Dim lGold As Long
    Dim lGoldCost As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT X, Y, Z, PortID, Gold, PlayerName FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
        lTotalDmg = 0
        lSSHullIntegrity = 0
        lSSLeftHullIntegrity = 100
        Set rsStarport = MyDB.OpenRecordset("SELECT FlightDesc, DX, DY, DZ, DStatus FROM tblAreaSpaceFlightEmote WHERE (RepairPort=True) AND (XS<=" & lPX & " AND XE>=" & lPX & ") AND (YS<=" & lPY & " AND YE>=" & lPY & ") AND (ZS<=" & lPZ & " AND ZE>=" & lPZ & ") ORDER BY ShellGroupCode, ShellOrderFromSource;", dbOpenSnapshot)
        If (Not rsStarport.EOF) Then
            Set rsStarship = MyDB.OpenRecordset("SELECT SSHullIntegrity, OxygenRequiredLevel, GravityLevel, RadiatedAreaLevel, GasAreaLevel, HeatAreaLevel FROM tblArea WHERE (PlayerType=2 AND PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
            If (Not rsStarship.EOF) Then
                lSSHullIntegrity = MyCLng(rsStarship!SSHullIntegrity)
                lSSLeftHullIntegrity = (100 - lSSHullIntegrity)
                lTotalDmg = lTotalDmg + MyCLng(rsStarship!OxygenRequiredLevel)
                lTotalDmg = lTotalDmg + MyCLng(rsStarship!GravityLevel)
                lTotalDmg = lTotalDmg + MyCLng(rsStarship!RadiatedAreaLevel)
                lTotalDmg = lTotalDmg + MyCLng(rsStarship!GasAreaLevel)
                lTotalDmg = lTotalDmg + MyCLng(rsStarship!HeatAreaLevel)
            End If
            Set rsStarship = Nothing
            
            lGold = MyCLng(rsPlayer!Gold)
            lGoldCost = ((cstlStarshipCostPerDmg * lTotalDmg) + (lSSLeftHullIntegrity * cstlStarshipCostPerIntegrity)) + 999 + lRandom(201) 'base of 1000 to 200
            If (lGold >= lGoldCost) Then
                If (lTotalDmg + lSSLeftHullIntegrity > 0) Then
                    rsPlayer.Edit
                    rsPlayer!Gold = lGold - lGoldCost
                    rsPlayer.Update
                    MyDB.Execute "UPDATE tblArea SET SSHullIntegrity=100, OxygenRequiredLevel = 0, GravityLevel = 0, RadiatedAreaLevel = 0, GasAreaLevel = 0, GasAreaLevelDesc = '', HeatAreaLevel = 0 WHERE (PlayerType=2 AND PlayerID=" & lPlayerID & ");", dbFailOnError 'repair all ships
                    subSendMsgAreaAllRange "&G[g-" & lGoldCost & "]" & zShipName & " " & (MyCStr(rsStarport!FlightDesc)), lPX, lPY, lPZ, 20
                Else
                    subSendMsgAreaAll gblzFNGRE & "This starship does not require repair, it is not damaged.", lPX, lPY, lPZ
                End If
            Else
                subSendMsgAreaAll gblzFNGRE & "You are short " & (lGoldCost - lGold) & " gold.", lPX, lPY, lPZ
            End If
        Else
            subSendMsgAreaAll gblzFNGRE & "You need to repair your starship near a starport.", lPX, lPY, lPZ
        End If
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetStarportRepair," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bAboardStarship(lPX As Long, lPY As Long, lPZ As Long) As Boolean
On Error GoTo Err_Check
    Dim rsSS As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    Set rsSS = MyDB.OpenRecordset("SELECT AreaID FROM tblArea WHERE (PlayerType>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot)
    bReturn = (Not rsSS.EOF)
    Set rsSS = Nothing
    bAboardStarship = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bAboardStarship," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bOwnsStarship(lPlayerID As Long) As Boolean
On Error GoTo Err_Check
    Const cstlType = 2 'starship - player can only have one of these
    Dim rsSS As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    Set rsSS = MyDB.OpenRecordset("SELECT AreaID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=" & cstlType & ");", dbOpenSnapshot)
    bReturn = (Not rsSS.EOF)
    Set rsSS = Nothing
    bOwnsStarship = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bOwnsStarship," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bOwnsHouse(lPlayerID As Long) As Boolean
On Error GoTo Err_Check
    Const cstlType = 1 'house
    Dim rsSS As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    Set rsSS = MyDB.OpenRecordset("SELECT AreaID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=" & cstlType & ");", dbOpenSnapshot)
    bReturn = (Not rsSS.EOF)
    Set rsSS = Nothing
    bOwnsHouse = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bOwnsHouse," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subStarshipParsecs(zPortID As String, lDX As Long, lDY As Long, lDZ As Long, lPX As Long, lPY As Long, lPZ As Long)
On Error GoTo Err_Check
    Dim rsSS As Recordset
    Dim lParsecs As Long
    lParsecs = lReturnDistanceSpacial(lPX, lPY, lPZ, lDX, lDY, lDZ) '= Abs(lCX - lPX) + Abs(lCY - lPY) + Abs(lCZ - lPZ)
    Set rsSS = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z, SSScanLevel FROM tblArea WHERE (PlayerID<>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND PlayerType=2);", dbOpenSnapshot)
    If (Not rsSS.EOF) Then
        subSendMsgAreaAll gblzFBYEL & "Navigational computer confirms," & vbCrLf & "'from x" & lPX & " y" & lPY & " z" & lPZ & " to x" & lDX & " y" & lDY & " z" & lDZ & " measures a " & lParsecs & " parsecs spread'", lPX, lPY, lPZ
    Else
        subSendMsg "&gYou need to be aboard a starship to do that.", zPortID
    End If
    Set rsSS = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subStarshipParsecs," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subStarshipView(zPortID As String, lPX As Long, lPY As Long, lPZ As Long, bOveride As Boolean)
On Error GoTo Err_Check
    Dim rsSS As Recordset
    
    Set rsSS = MyDB.OpenRecordset("SELECT AreaID, AreaName, SSMinesLevel FROM tblArea WHERE (PlayerType>0 AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot)
    If (Not rsSS.EOF) Then
        subShowSpaceTravel zPortID, lPX, lPY, lPZ, lPX, lPY, lPZ, 0, True, MyCStr(rsSS!AreaName), bOveride
    Else
        subSendMsg "&gYou need to be aboard a starship to use the viewer.", zPortID
    End If
    Set rsSS = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subStarshipView," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subStarshipBuy(zPortID As String)
On Error GoTo Err_Check
    Dim rsSS As Recordset
    Dim rsPlayer As Recordset
    Dim lPlayerLevel As Long
    Dim lPlayerID As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lNX As Long
    Dim lNY As Long
    Dim lNZ As Long
    Dim lPGold As Long
    Dim bPurchased As Boolean
    Dim zPlayerName As String
    Dim lSSPowerLevel As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, WhereID, Gold, X, Y, Z, PlayerLevel, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
        lPGold = MyCLng(rsPlayer!Gold)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        If (lPlayerLevel > 39) Then
            'If (Not bPartOfAuction(zPortID, lPlayerID)) Then
                Set rsSS = MyDB.OpenRecordset("SELECT * FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenDynaset)
                If (Not rsSS.EOF) Then
                    If (MyCInt(rsSS!PurchaseSS) <> 0) Then
                        If (lPGold >= gbllSSGoldCost) Then
                            If (lngSQLRecordCount("SELECT PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 0) Then
                                'place the starship somewhere where there is nothing
                                'randomize -100 to +100 for X Y Z and keep repeating until no area is found, then make a starship area
                                'mark the area with the PlayerID
                                'move the player to the starship
                                'subtract the gbllSSGoldCost from the player
                                bPurchased = False
                                Do While (Not bPurchased)
                                    lNX = lRandom(100)
                                    lNY = lRandom(100)
                                    lNZ = lRandom(100)
                                    If (lRandom(2) = 1) Then lNX = lNX * -1
                                    If (lRandom(2) = 1) Then lNY = lNY * -1
                                    If (lRandom(2) = 1) Then lNZ = lNZ * -1
                                    If (Not bCheckAreaExists(zPortID, lNX, lNY, lNZ, False) And Not bCheckDoorExists("", lNX, lNY, lNZ)) Then
                                        bPurchased = True
                                        rsSS.AddNew
                                        rsSS!PlayerID = lPlayerID
                                        rsSS!PlayerType = 2
                                        rsSS!MapAvailable = False
                                        rsSS!NoQuestZone = True
                                        rsSS!ColonistAllowed = True
                                        rsSS!ColonistsPlayerID = lPlayerID
                                        rsSS!ColonistsAboard = 7500 + lRandom(2500)
                                        rsSS!ColonistsNumber = 4500 + lRandom(1500)
                                        rsSS!AreaSpeciesFertilityPercent = 2 + lRandom(2)
                                        rsSS!AreaType = 29
                                        Select Case lRandom(9)
                                            Case 1
                                                rsSS!AreaName = "ISS Dreadnought " & zPlayerName
                                                rsSS!CloakingDeviceLevel = 5 + lRandom(5)
                                                rsSS!SSMinesLevel = 0
                                                rsSS!SSLaserLevel = 12 + lRandom(26)
                                                rsSS!SSScanLevel = 30 + lRandom(35)
                                                rsSS!SSEngineLevel = 7 + lRandom(3)
                                                rsSS!SSFuel = lRandom(9150) + 6600
                                                rsSS!AreaDescDay = "You have purchased a great buy! You are onboard the Interstellar Dreadnought " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device."
                                                rsSS!AreaDescNight = "You have purchased a great buy! You are onboard the Interstellar Dreadnought " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device. Blinking lights are obvious on the dimly lit bridge."
                                            Case 2
                                                rsSS!AreaName = "ISS Nemesis " & zPlayerName
                                                rsSS!CloakingDeviceLevel = 15 + lRandom(15)
                                                rsSS!SSMinesLevel = 0
                                                rsSS!SSLaserLevel = 23 + lRandom(25)
                                                rsSS!SSScanLevel = 40 + lRandom(65)
                                                rsSS!SSEngineLevel = 15 + lRandom(4)
                                                rsSS!SSFuel = lRandom(9350) + 6500
                                                rsSS!AreaDescDay = "You have purchased a great buy! You are onboard the Interstellar Nemesis " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device."
                                                rsSS!AreaDescNight = "You have purchased a great buy! You are onboard the Interstellar Nemesis " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device. Blinking lights are obvious on the dimly lit bridge."
                                            Case 3
                                                rsSS!AreaName = "ISS Wraith " & zPlayerName
                                                rsSS!CloakingDeviceLevel = 75 + lRandom(15)
                                                rsSS!SSMinesLevel = 0
                                                rsSS!SSLaserLevel = 22 + lRandom(33)
                                                rsSS!SSScanLevel = 40 + lRandom(75)
                                                rsSS!SSEngineLevel = 17 + lRandom(4)
                                                rsSS!SSFuel = lRandom(2750) + 5500
                                                rsSS!AreaDescDay = "You have purchased a great buy! You are onboard the Interstellar Wraith " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device."
                                                rsSS!AreaDescNight = "You have purchased a great buy! You are onboard the Interstellar Wraith " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device. Blinking lights are obvious on the dimly lit bridge."
                                            Case 4
                                                rsSS!AreaName = "ISS Phoenix " & zPlayerName
                                                rsSS!SSMinesLevel = 0
                                                rsSS!CloakingDeviceLevel = 25 + lRandom(15)
                                                rsSS!SSLaserLevel = 10 + lRandom(45)
                                                rsSS!SSScanLevel = 60 + lRandom(215)
                                                rsSS!SSEngineLevel = 20 + lRandom(4)
                                                rsSS!SSFuel = lRandom(9999) + 21500
                                                rsSS!AreaDescDay = "You have purchased a great buy! You are onboard the Interstellar Phoenix " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device."
                                                rsSS!AreaDescNight = "You have purchased a great buy! You are onboard the Interstellar Phoenix " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device. Blinking lights are obvious on the dimly lit bridge."
                                            Case 5
                                                rsSS!AreaName = "ISS Phantom " & zPlayerName
                                                rsSS!SSMinesLevel = 0
                                                rsSS!SSLaserLevel = 12 + lRandom(45)
                                                rsSS!CloakingDeviceLevel = 65 + lRandom(5)
                                                rsSS!SSScanLevel = 55 + lRandom(125)
                                                rsSS!SSEngineLevel = 30 + lRandom(15)
                                                rsSS!SSFuel = lRandom(4750) + 6500
                                                rsSS!AreaDescDay = "The sleekness of black metal wraps around you in the form of the Interstellar Starship " & zPlayerName & "'s Phantom. In the centre of the bridge a Matrix generator projects a 3 dimensional map of the known regions between its imaging projectors. The large view screens of the ceiling, walls and floors are blacked out by huge armoured screens stopping the unfiltered UV of the many suns and also for the Captain of this ship flies by instruments alone. At the back of the bridge, is a communication station."
                                                rsSS!AreaDescNight = "The sleekness of black metal wraps around you in the form of the Interstellar Starship " & zPlayerName & "'s Phantom. In the centre of the bridge a Matrix generator projects a 3 dimensional map of the known regions between its imaging projectors. The large view screens of the ceiling, walls and floors are blacked out by huge armoured screens stopping the unfiltered UV of the many suns and also for the Captain of this ship flies by instruments alone. At the back of the bridge, is a communication station."
                                            Case 6
                                                rsSS!AreaName = "ISS Matrix " & zPlayerName
                                                rsSS!CloakingDeviceLevel = 65 + lRandom(55)
                                                rsSS!SSMinesLevel = 0
                                                rsSS!SSLaserLevel = 52 + lRandom(56)
                                                rsSS!SSScanLevel = 50 + lRandom(35)
                                                rsSS!SSEngineLevel = 57 + lRandom(3)
                                                rsSS!SSFuel = lRandom(9150) + 3600
                                                rsSS!AreaDescDay = "You have purchased a great buy! You are onboard the Interstellar Matrix " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device."
                                                rsSS!AreaDescNight = "You have purchased a great buy! You are onboard the Interstellar Matrix " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device. Blinking lights are obvious on the dimly lit bridge."
                                            Case Else
                                                'Other ships you have to first fit the weapons for a level 1
                                                rsSS!AreaName = "ISS Starship " & zPlayerName
                                                rsSS!CloakingDeviceLevel = 5 + lRandom(10)
                                                rsSS!SSMinesLevel = 0
                                                rsSS!SSScanLevel = 50 + lRandom(35)
                                                rsSS!SSLaserLevel = 25 + lRandom(25)
                                                rsSS!SSEngineLevel = 25 + lRandom(35)
                                                rsSS!SSFuel = lRandom(5250) + 4500
                                                rsSS!AreaDescDay = "You are onboard the Interstellar Starship " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device."
                                                rsSS!AreaDescNight = "You are onboard the Interstellar Starship " & zPlayerName & ". There is also an onboard computer with a liquid crystal display at its centre. Surrounding the walls, floor, and ceiling is a giant viewscreen. The main viewscreen shows hundreds of stars. The floor and ceiling has a white aura about it, a matter to energy transporter device. Blinking lights are obvious on the dimly lit bridge."
                                        End Select
                                        rsSS!WhereID = 175 'this is HARDCODED so all ships are the same.
                                        rsSS!x = lNX
                                        rsSS!y = lNY
                                        rsSS!z = lNZ
                                        rsSS!SSHullIntegrity = 100
                                        rsSS!ColonistHostileForces = 0
                                        rsSS!AreaRules = "111101111111111" '1 and 12 when flipped on will prevent summon to a starship - we need summon - we block portals to starships since when the ship moves we have a problem, pirate ships and so on should be blocked too
                                        rsSS!BlockedExits = "1111111111"
                                        rsSS!SSEngineCruise = rsSS!SSEngineLevel
                                        lSSPowerLevel = 250 + lRandom(250)
                                        rsSS!SSPowerLevel = lSSPowerLevel
                                        rsSS!SSBatteryLevel = 150 + lRandom(150) + lSSPowerLevel
                                        rsSS!SSGloryTotal = 0
                                        rsSS!SSMobShipKillTotal = 0
                                        rsSS.Update
                                        
                                        rsPlayer.Edit
                                        rsPlayer!Gold = MyCLng(rsPlayer!Gold) - gbllSSGoldCost
                                        rsPlayer!x = lNX
                                        rsPlayer!y = lNY
                                        rsPlayer!z = lNZ
                                        rsPlayer!WhereID = 175 'HARDCODED
                                        rsPlayer.Update
                                        subSendMsg "&GYou purchase a starship and are beamed aboard!", zPortID
                                        subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases a starship and is transported aboard!", lPX, lPY, lPZ, zPortID, ""
                                    End If
                                Loop
                            Else
                                subSendMsg "&gYou already own a starship, you may upgrade it." & vbCrLf & "Type SS BOARD to beam to your starship.", zPortID
                            End If
                        Else
                            subSendMsg "&gTo buy a Starship you need " & gbllSSGoldCost & " gold.", zPortID
                        End If
                    Else
                        subSendMsg "&gYou cannot purchase a starship here.", zPortID
                    End If
                Else
                    subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
                End If
                Set rsSS = Nothing
            'Else
                'subSendMsg "&RYou cannot purchase a starship when are participating in an auction.", zPortID
            'End If
        Else
            subSendMsg "&gYou must be level 40 to buy a starship." & vbCrLf & "You may also talk to an immortal about purchasing a house to safely store your stuff.", zPortID
        End If
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subStarshipBuy," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subStarshipControlEngage(zPortID As String, zType As String, lPlayerID As Long, lX As Long, lY As Long, lZ As Long)
On Error GoTo Err_Check
    Dim rsSS As Recordset
    
    Select Case zType
        Case "G"
            Set rsSS = MyDB.OpenRecordset("SELECT AreaName, SSLaserOnline, SSN, SSNX, SSNY, SSNZ, SSEngineCruise, CloakingDeviceDuration, CloakingDeviceLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND PlayerType=2);", dbOpenDynaset)
            If (Not rsSS.EOF) Then
                If (MyCInt(rsSS!SSN) <> 0) Then
                    subSendMsgAreaAll gblzFBYEL & "Navigational computer confirms, 'already on course to x" & MyCLng(rsSS!SSNX) & " y" & MyCLng(rsSS!SSNY) & " z" & MyCLng(rsSS!SSNZ) & "'", lX, lY, lZ
                Else
                    rsSS.Edit
                    rsSS!SSN = True 'we turn on the warp drives
                    rsSS.Update
                    subShipSignature "", MyCStr(rsSS!AreaName) & " [Engaged] [w" & MyCLng(rsSS!SSEngineCruise) & "] [d" & Abs(lX - MyCLng(rsSS!SSNX)) + Abs(lY - MyCLng(rsSS!SSNY)) + Abs(lZ - MyCLng(rsSS!SSNZ)) & "]", MyCLng(MyCLng(rsSS!SSEngineCruise) / 6), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, True 'bAllowMobShipReactSig 'same sig as ss navig
                End If
            Else
                subSendMsg "&gYou need to board your starship first.", zPortID
            End If
            Set rsSS = Nothing
        Case Else
            Set rsSS = MyDB.OpenRecordset("SELECT AreaName, SSLaserOnline, X, Y, Z, SSN, SSNX, SSNY, SSNZ, SSEngineCruise, CloakingDeviceDuration, CloakingDeviceLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND PlayerType=2);", dbOpenDynaset)
            If (Not rsSS.EOF) Then
                If (MyCInt(rsSS!SSN) = 0) Then
                    subSendMsgAreaAll gblzFBYEL & "Navigational computer confirms, 'All stop! Ready to Engage x" & MyCLng(rsSS!SSNX) & " y" & MyCLng(rsSS!SSNY) & " z" & MyCLng(rsSS!SSNZ) & "'", lX, lY, lZ
                Else
                    rsSS.Edit
                    rsSS!SSN = False 'we turn off the warp drives
                    rsSS.Update
                    subShipSignature "", MyCStr(rsSS!AreaName) & " [All stop] [w" & MyCLng(rsSS!SSEngineCruise) & "] [d" & Abs(lX - MyCLng(rsSS!SSNX)) + Abs(lY - MyCLng(rsSS!SSNY)) + Abs(lZ - MyCLng(rsSS!SSNZ)) & "]", MyCLng(MyCLng(rsSS!SSEngineCruise) / 16), MyCLng(rsSS!CloakingDeviceDuration), MyCLng(rsSS!CloakingDeviceLevel), lX, lY, lZ, True 'bAllowMobShipReactSig
                End If
            Else
                subSendMsg "&gYou need to board your starship first.", zPortID
            End If
            Set rsSS = Nothing
    End Select
    Exit Sub
Err_Check:
    subWriteErrorFile "subStarshipControlEngage " & zType & "," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bFleetLockedShipAllowed(lCX As Long, lCY As Long, lCZ As Long, lASSMobshipKillTotal As Long) As Boolean
On Error GoTo Err_Check
    Dim rsSS As Recordset
    Dim bReturn As Boolean
    Dim lDMobSpaceshipLevel As Long
    Dim lCalcu As Long
    bReturn = True 'this function allows the noobie player starships something left over to kill
    Set rsSS = MyDB.OpenRecordset("SELECT MobSpaceshipLevel FROM tblArea WHERE (MobSpaceshipLevel>0 AND X=" & lCX & " AND Y=" & lCY & " AND Z=" & lCZ & " AND PlayerType=2);", dbOpenSnapshot)
    If (Not rsSS.EOF) Then
        lDMobSpaceshipLevel = MyCLng(rsSS!MobSpaceshipLevel)
        Select Case lDMobSpaceshipLevel
            Case 1 'these are running totals
                lCalcu = 50 'these are noobie mobships (miners and constructors(expansions, supremacies, tacticals, outposts, and generic constructors)) that do not shoot back at you - they just run away when hit or EXPLODE
            Case 2
                lCalcu = 100 'this is really 20 if they already killed 30 level 1 mobships
            Case 3
                lCalcu = 200
            Case 4
                lCalcu = 300
            Case 5
                lCalcu = 400
            Case Else
                lCalcu = 9999 'we can kill nearly an infinite hard spacemobs
        End Select
        bReturn = (lASSMobshipKillTotal <= lCalcu)
    End If
    Set rsSS = Nothing
    bFleetLockedShipAllowed = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bFleetLockedShipAllowed," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subFleetCommandHelpSyntax(zPortID As String)
On Error GoTo Err_Check
    subSendMsg "&W~STARPORT UPGRADE COMMANDS~" & vbCrLf & "&aSS BUY         - purchase your starship at a starport, $" & gbllSSGoldCost & " gold." & vbCrLf & "You can use the following commands with a value after them: (eg: SS UGE [VALUE/MAX])" & vbCrLf & "SS UGE         - upgrade your starship engines, $" & gbllSSGoldCostEngineUpgrade & " gold." & vbCrLf & "SS UGC         - upgrade your starship scanners, $" & gbllSSGoldCostScanUpgrade & " gold.", zPortID
    subSendMsg "SS UGK         - upgrade your starship cloaking device, $" & gbllSSGoldCostCloakingUpgrade & " gold." & vbCrLf & "SS UGR         - upgrade your starship repulsor device, $" & gbllSSGoldCostRepulsorUpgrade & " gold." & vbCrLf & "SS UGO         - upgrade your power levels, $" & gbllSSGoldCostPowerLevelUpgrade & " gold." & vbCrLf & "SS UGB         - upgrade your battery, $" & gbllSSGoldCostBatteryUpgrade & " gold.", zPortID
    subSendMsg "SS UGP         - upgrade your starship phasers, $" & gbllSSGoldCostLaserUpgrade & " gold." & vbCrLf & "SS UGM         - upgrade your starship proximity mines, $" & gbllSSGoldCostPMinesUpgrade & " gold." & vbCrLf & "SS UGS         - upgrade your starship shield generator, $" & gbllSSGoldCostShieldUpgrade & " gold." & vbCrLf & "SS UGH         - upgrade your starship hull armour, $" & gbllSSGoldCostHullUpgrade & " gold." & vbCrLf & "SS REPAIR      - this will repair your starship at a starport", zPortID
    subSendMsg "&W~STARSHIP ACTIVATE COMMANDS~" & vbCrLf & "&aSS BOARD       - beams you aboard your starship from anywhere" & vbCrLf & "SS BEAM        - beams you down, SS BEAM SCAN (scans for mobs)" & vbCrLf & "SS LOCATION    - the onboard starship computer will tell you your location" & vbCrLf & "SS FUEL        - this will load your spacecraft with any fuel in your inventory" & vbCrLf & "SS LOAD        - beams cryogenic chambers aboard" & vbCrLf & "SS NAVIGATION  - SYNTAX: NAVI [-/+]X [-/+]Y [-/+]Z" & vbCrLf & "SS PURSUIT     - This will chase the phaser locked target" & vbCrLf & "SS FREEFIRE    - Instant battery recharge costing [-1lps]" & vbCrLf & "SS HEAL        - Load a nanite repair component", zPortID
    subSendMsg "SS VIEWER      - Activates the viewer" & vbCrLf & "SS WARP        - SYNTAX: WARP NUMBER" & vbCrLf & "SS STOP        - all stop, see also: SS NAVIGATION" & vbCrLf & "SS STATUS      - shows the ship status" & vbCrLf & "SS PARSECS     - measures the distance" & vbCrLf & "SS PING        - starship scan" & vbCrLf & "SS SCAN        - scans the area for mineral deposits" & vbCrLf & "SS CLOAKING    - toggles your cloaking device on or off" & vbCrLf & "SS LOCK x y z  - locks phasers to target at x y z" & vbCrLf & "SS MINE        - drops a proximity mine at your location" & vbCrLf & "SS FIRE        - fires phasers" & vbCrLf & "SS VALUE       - free starship appraisal" & vbCrLf & "SS REPULSOR    - activates your starship repulsor beam", zPortID
    subSendMsg "&WColonists/Troop Commands" & vbCrLf & "&aSS DROP        - SS DROP [VALUE/MAX], starship -> colony planet" & vbCrLf & "SS COLONISTS   - SS COLO [VALUE/MAX], colony planet -> starship" & vbCrLf & "SS DEFEND      - SS DEFE [VALUE/MAX], starship -> homeworld" & vbCrLf & "SS TRANSFER    - SS TRAN [VALUE/MAX], homeworld -> starship" & vbCrLf & "SS CONTROL     - shows you all your controlled worlds", zPortID
    subSendMsg "&AEXCHANGE [SHOW (all/self/playername)/IDEN/DELE/SELL (item) ($)/BUY (item) ($)]", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subFleetCommandHelpSyntax," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subFleetCommandUGE(zPlayerName As String, lCX As Long, lPX As Long, lPY As Long, lPZ As Long, lPlayerID As Long, lPGold As Long, lSSGoldCostEngineUpgrade As Long, zPortID As String)
On Error GoTo Err_Check
    Dim rsBeamArea As Recordset
    Dim rsSS As Recordset
    If (lCX < 1) Then lCX = 1 'used to sell more components in gulps
    If (lCX > 200) Then lCX = 200
    Set rsBeamArea = MyDB.OpenRecordset("SELECT PurchaseSS FROM tblArea WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & ");", dbOpenSnapshot) 'any player can beam down from another's starship
    If (Not rsBeamArea.EOF) Then
        If (MyCInt(rsBeamArea!PurchaseSS) <> 0) Then
            If (lPGold >= (lCX * gbllSSGoldCostEngineUpgrade)) Then
                If (lngSQLRecordCount("SELECT SSEngineLevel, PlayerID FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);") = 1) Then
                    Set rsSS = MyDB.OpenRecordset("SELECT PurchaseSS, SSEngineLevel FROM tblArea WHERE (PlayerID=" & lPlayerID & " AND PlayerType=2);", dbOpenDynaset) 'any player can beam down from another's starship
                    If (Not rsSS.EOF) Then
                        rsSS.Edit
                        Select Case (MyCLng(rsSS!SSEngineLevel))
                            Case 0
                                subSendMsg "&WEngineering reports, 'a impulse drive chassis was installed into your ship.'", zPortID
                            Case 1
                                subSendMsg "&WEngineering reports, 'a sublight drive chassis was installed into your ship.'", zPortID
                            Case 2
                                subSendMsg "&WEngineering reports, 'a warp drive chassis was installed into your ship.'", zPortID
                        End Select
                        
                        rsSS!SSEngineLevel = MyCLng(rsSS!SSEngineLevel) + lCX
                        rsSS.Update
                        
                        MyDB.Execute "UPDATE tblPlayer SET Gold=" & lPGold - (gbllSSGoldCostEngineUpgrade * lCX) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        'rgsPlayer!Gold = MyCLng(rsPlagyer!Gold) - (gbllSSGoldCostEngineUpgrade * lCX)
                    End If
                    Set rsSS = Nothing
                    subSendMsg "&WEngineering reports, '" & lCX & " advanced engine components were installed into your ship.'", zPortID
                    subSendMsgAreaExcept2 "&W" & zPlayerName & " purchases " & lCX & " engine upgrades!", lPX, lPY, lPZ, zPortID, ""
                Else
                    subSendMsg "&gYou do not own a starship, you may SS BUY one.", zPortID
                End If
            Else
                subSendMsg "&gYou need " & gbllSSGoldCostEngineUpgrade * lCX & " gold to upgrade your engines.", zPortID
            End If
        Else
            subSendMsg "&gYou are not at a starport.", zPortID
        End If
    Else
        subSendMsg "&gNo area was found where you are, this is an error or you are an immortal.", zPortID
    End If
    Set rsBeamArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "bFleetCombatCloaking," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subStarshipLocationXYZ(zPortID As String, lPX As Long, lPY As Long, lPZ As Long)
On Error GoTo Err_Check
    Dim rsSS As Recordset
    Dim zName As String
    Dim lssX As Long
    Dim lssY As Long
    Dim lssZ As Long
    
    Set rsSS = MyDB.OpenRecordset("SELECT AreaName, X, Y, Z FROM tblArea WHERE (PlayerID=" & lReturnPlayerIDPortID(zPortID) & " AND PlayerType=2);", dbOpenSnapshot)
    If (Not rsSS.EOF) Then
        zName = MyCStr(rsSS!AreaName)
        lssX = MyCLng(rsSS!x)
        lssY = MyCLng(rsSS!y)
        lssZ = MyCLng(rsSS!z)
        If (lssX = lPX And lssY = lPY And lssZ = lPZ) Then 'if we are on the starship reveal to all
            subSendMsgAreaAll "&w'[x" & MyCStr(lssX) & " y" & MyCStr(lssY) & " z" & MyCStr(lssZ) & "]'", lPX, lPY, lPZ
        Else
            subSendMsg "&w'[x" & MyCStr(lssX) & " y" & MyCStr(lssY) & " z" & MyCStr(lssZ) & "]'", zPortID
        End If
    Else
        subSendMsg "&gYou need to be aboard a starship to use the onboard navigational computer.", zPortID
    End If
    Set rsSS = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subStarshipLocationXYZ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

