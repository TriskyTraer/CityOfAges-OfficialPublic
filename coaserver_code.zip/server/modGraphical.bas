Attribute VB_Name = "modGraphical"
Option Explicit
Public Declare Function BitBlt Lib "gdi32.dll" (ByVal hdcDest As Long, ByVal nXDest As Long, ByVal nYDest As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hdcSrc As Long, ByVal nXSrc As Long, ByVal nYSrc As Long, ByVal dwRop As Long) As Long
Public Function zRemoveColorCodes(zLine As String) As String 'Usage: zEventLine = zRemoveColorCodes(zRemoveCrazyChars(zOEventline))
'Note: Coder MUST use zRemoveCrazyChars before calling this function
    Dim zHoldLine As String
    Dim lLenLine As Long
    Dim lCounter As Long
    Dim lScanner As Long
    Dim zChr As String
    Dim bScan As Boolean
    zHoldLine = ""
    bScan = False
    lLenLine = Len(zLine)
    For lCounter = 1 To lLenLine
        zChr = Mid(zLine, lCounter, 1)
        If (zChr = "[") Then 'We do not detect for Chr(27) here for the ASCII colors
            lScanner = 0
            bScan = True
        End If
        If (bScan) Then lScanner = lScanner + 1
        If (lScanner = 7) Then
            bScan = False
        End If
        If (Not bScan) Then zHoldLine = zHoldLine & zChr
    Next lCounter
    zRemoveColorCodes = zHoldLine
End Function
Public Function zRemoveCRLF(zLine As String) As String 'Usage: zEventLine = zRemoveColorCodes(zRemoveCrazyChars(zOEventline))
    Dim zReturn As String
    Dim zChr As String
    Dim lCount As Long
    Dim lLen As Long
    zReturn = ""
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChr = Mid(zLine, lCount, 1)
        If (zChr <> vbCr And zChr <> vbLf) Then zReturn = zReturn & zChr
    Next lCount
    zRemoveCRLF = zReturn
End Function
Public Function zRemoveCrazyChars(zLine As String) As String 'Usage: zEventLine = zRemoveColorCodes(zRemoveCrazyChars(zOEventline))
    Dim zReturn As String
    Dim zChr As String
    Dim lCount As Long
    Dim lLen As Long
    zReturn = ""
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChr = Mid(zLine, lCount, 1)
        If (zChr <> Chr(27) And zChr <> vbCr And zChr <> vbLf) Then zReturn = zReturn & zChr
    Next lCount
    zRemoveCrazyChars = zReturn
End Function
Public Sub subGraphicalRequestCode(zPortID As String)
On Error GoTo Err_Check 'puts together the area GraphicalIDs of Players Mobs Objects the graphical ID is the true facing direction of the item
    Dim MyRS As Recordset
    Dim zSQL As String
    Dim lPlayerX As Long
    Dim lPlayerY As Long
    Dim lPlayerZ As Long
    Dim bPlayerFound As Boolean
    Dim zGraphicalMsg As String
    
    zGraphicalMsg = ""
    
    DoEvents
    
    bPlayerFound = False
    
    zGraphicalMsg = zGraphicalMsg & "[<P]"
    zSQL = "SELECT GraphicsID, X, Y, Z, Class, PlayerLevel, CHITROLL, CDAMROLL, XP, CAC, CHP, CEssence, CMana, CSoul, CMove, CSTR, CINT, CWIS, CDEX, CCON, CCHA, CLUC, NumAttRnd FROM tblPlayer WHERE (PortID='" & zPortID & "');"
    Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
    If (Not MyRS.EOF) Then
        bPlayerFound = True
        lPlayerX = MyCLng(MyRS!x)
        lPlayerY = MyCLng(MyRS!y)
        lPlayerZ = MyCLng(MyRS!z)
        
        zGraphicalMsg = zGraphicalMsg & "|" & MyRS!GraphicsID & "|" & lPlayerX & "|" & lPlayerY & "|" & lPlayerZ & "|"
    End If
    Set MyRS = Nothing
    zGraphicalMsg = zGraphicalMsg & "[P>]"
    
    If (bPlayerFound) Then
        zGraphicalMsg = zGraphicalMsg & "[<S]"
        zSQL = "SELECT GraphicsID, X, Y, Z FROM tblArea WHERE (X=" & lPlayerX & " AND Y=" & lPlayerY & " AND Z=" & lPlayerZ & ");"
        Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        If (Not MyRS.EOF) Then
            zGraphicalMsg = zGraphicalMsg & "|" & MyRS!GraphicsID & "|"
        End If
        Set MyRS = Nothing
        zGraphicalMsg = zGraphicalMsg & "[S>]"
    
        zGraphicalMsg = zGraphicalMsg & "[<M]"
        zSQL = "SELECT GraphicsID, X, Y, Z FROM tblMob WHERE (X=" & lPlayerX & " AND Y=" & lPlayerY & " AND Z=" & lPlayerZ & " AND RespawnDelay=0);"
        Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not MyRS.EOF)
            zGraphicalMsg = zGraphicalMsg & "|" & MyRS!GraphicsID & "|"
            MyRS.MoveNext
        Loop
        Set MyRS = Nothing
        zGraphicalMsg = zGraphicalMsg & "[M>]"
        
        zGraphicalMsg = zGraphicalMsg & "[<O]"
        zSQL = "SELECT GraphicsID, X, Y, Z FROM tblObject WHERE (X=" & lPlayerX & " AND Y=" & lPlayerY & " AND Z=" & lPlayerZ & " AND Burried=False AND Status=0);"
        Set MyRS = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not MyRS.EOF)
            zGraphicalMsg = zGraphicalMsg & "|" & MyRS!GraphicsID & "|"
            MyRS.MoveNext
        Loop
        Set MyRS = Nothing
        zGraphicalMsg = zGraphicalMsg & "[O>]"
    End If
    
    subSendMsg gblzGraphicalClientCode & zGraphicalMsg, zPortID 'the graphical mud just needs this to display, the rest is on the above part of the graphical client showing text
    
    DoEvents
    Exit Sub
Err_Check:
    subWriteErrorFile "subGraphicalRequestCode," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

