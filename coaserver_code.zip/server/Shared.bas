Attribute VB_Name = "modShared"
Option Explicit 'newest updates are at my facebook or Contact me at cityofages@gmail.com
'TRIGGER VARIABLES
Public Const bcstFilterCussing = False
Public gblbSystemAwake As Boolean
Public Const cstlngPlayerColour = &HFFFF00
Public Const gblcstbAntiPiracy = False 'This will activate anti-piracy through code in the registry. You must modify gblstrApplicationModifiedDate too set somewhere in this code to the compile date !!!
Public gblstrApplicationModifiedDate As String ' RELEASE DATE Use the format MMM DD, YYYY
Public gblbDemoCopy As Boolean ' DEMONSTRATION FLAG
Public gblbIgnoreSpamWarning As Boolean
'OTHER VARIABLES
Public cstREPORT_PATH As String
Public Sub subDisconnectMASSIVELYIGNOREDPlayers()
On Error GoTo Err_Check
    Const cstIgnoredCountOfPlayers = 10 '3 people times 3 connections per IP + 1 to make 4 people
    Dim rsIgnored As Recordset
    Dim zPortID As String
    
    subCheckPlayerIGNOREDClear
    
    Set rsIgnored = MyDB.OpenRecordset("SELECT Count(tblPlayer.PlayerID) AS CountOfPlayerID, tblPlayer.PlayerName, tblPlayer.PlayerID, Len([PortID]) AS OnlineTest, tblPlayer.PortID FROM tblPlayer INNER JOIN tblPlayerIgnoreCommand ON tblPlayer.PlayerID = tblPlayerIgnoreCommand.PlayerIgnoredID GROUP BY tblPlayer.PlayerName, tblPlayer.PlayerID, Len([PortID]), tblPlayer.PortID HAVING (((Len([PortID]))>1));", dbOpenSnapshot)
    Do While (Not rsIgnored.EOF)
        If (MyCLng(rsIgnored!CountOfPlayerID) >= cstIgnoredCountOfPlayers) Then 'if more than these few people in a day put this person on ignore this person has a chance to get a random d/c
            zPortID = MyCStr(rsIgnored!PortID)
            subSendMsg "&RMany players are IGNORING you, you have been warned.", zPortID
            If (lRandom(10) = 1) Then
                subSendMsg "&Rothers IGNORE List will be cleared hourly - have a nice random disconnect", zPortID
                subSendMsg "&R. . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .", zPortID
                DoEvents
                subShutdownPorts zPortID
            End If
        End If
        rsIgnored.MoveNext
    Loop
    Set rsIgnored = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subDisconnectMASSIVELYIGNOREDPlayers," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subAutomaticallyReconfigure()
On Error GoTo Err_Check
    'There are some things in the realm that can be automated to configure new mobs in the realm, these are them:
    
    'tblMOB
    'Newbie area (0,0,-10 and nearby surroundings) and mobes near it. We make them NOT QUESTABLE
    MyDB.Execute "UPDATE tblMob SET Questable=False, QuestMobNotAvailable = True WHERE ((X>-9 And X<9) AND (Y>-9 And Y<9) AND (Z>-17 And Z<-2));", dbFailOnError
    
    'Mob Names with UNDEAD in it or Skeleton, Vampire, Vampyre, Zombie etc...Get marked as undead for the Exorcist spell.
    MyDB.Execute "UPDATE tblMob SET Undead = True, MobBracketWord = '(undead)' WHERE (MobName Like '*vampire*' Or MobName Like '*vampyre*' Or MobName Like '*zombie*' Or MobName Like '*skeleton*');", dbFailOnError
    
    'Gender (Male is the default so we only need one here
    MyDB.Execute "UPDATE tblMob SET Gender = 'F' WHERE (MobName Like '*girl*' Or MobName Like '*lady*' Or MobName Like '*lassy*' Or MobName Like '*woman*' Or MobName Like '*female*');", dbFailOnError
    
    'Mobs made with 100% chance of a blind shouldnt exist in the realm
    MyDB.Execute "UPDATE tblMob SET BlindRandom = 2 WHERE (BlindRandom=1);", dbFailOnError
    
    'Strip mobs from seeking Raid areas and players
    MyDB.Execute "UPDATE tblMob SET MoveAllowed = 0, PlayerID=0 WHERE (BlindRandom=1);", dbFailOnError
    
    'Player Class Morph WitchLocke gets stripped back to their previous form
    MyDB.Execute "UPDATE tblPlayer SET Class=[BittenReservedOriginalClass] WHERE (Class='IO');", dbFailOnError 'all witches in the realm get cleared of Witchardry Warlockardry
    Exit Sub
Err_Check:
    subWriteErrorFile "subAutomaticallyReconfigure," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub

Public Function zRemoveInvalidChatChars(zLine As String) As String
On Error Resume Next
    Dim lLen As Long
    Dim lCount As Long
    Dim zChar As String
    Dim zReturn As String
    lLen = Len(zLine)
    For lCount = 1 To lLen
        zChar = Mid(zLine, lCount, 1)
        If (zChar <> "|" And zChar <> "'" And zChar <> "<" And zChar <> ">" And zChar <> "[" And zChar <> "]" And zChar <> "{" And zChar <> "}" And zChar <> "(" And zChar <> ")") Then
            zReturn = zReturn & zChar
        End If
    Next lCount
    zRemoveInvalidChatChars = zReturn
End Function
Public Function intMinutes() As Integer
On Error Resume Next
    intMinutes = MyCInt(Format(Time(), "N"))
End Function
Public Function lDoorID(lOX As Long, lOY As Long, lOZ As Long) As Long
    Dim strSQL As String
    Dim rsDoor As Recordset 'Current Area
    Dim lReturn As Long
    
    lReturn = 0
    Set rsDoor = MyDB.OpenRecordset("SELECT DoorID FROM tblDoor WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot) 'The item must be on the ground to see it
    If (Not rsDoor.EOF) Then
        lReturn = MyCLng(rsDoor!DoorID)
    End If
    Set rsDoor = Nothing
    
    lDoorID = lReturn
End Function
Public Function zDoorName(lDoorID As Long) As String
On Error GoTo Err_Check
    Dim strSQL As String
    Dim rsPlayer As Recordset
    Dim rsDoor As Recordset 'Current Area
    Dim zReturn As String
    
    zReturn = ""
    Set rsDoor = MyDB.OpenRecordset("SELECT DoorName FROM tblDoor WHERE (DoorID=" & lDoorID & ");", dbOpenSnapshot) 'The item must be on the ground to see it
    If (Not rsDoor.EOF) Then
        zReturn = MyCStr(rsDoor!DoorName)
    End If
    Set rsDoor = Nothing
    
    zDoorName = (MyCStr(zReturn))
    Exit Function
Err_Check:
    subWriteErrorFile "zDoorName," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function

Public Function zDoorLevers(lDoorID As Long) As String
On Error GoTo Err_Check
    Dim rsDoor As Recordset 'Current Area
    Dim lPrint As Long
    Dim zReturn As String
    
    zReturn = "": lPrint = 0
    Set rsDoor = MyDB.OpenRecordset("SELECT X, Y, Z FROM tblDoorLever WHERE (DoorID=" & lDoorID & ");", dbOpenSnapshot) 'The item must be on the ground to see it
    Do While (Not rsDoor.EOF)
        lPrint = lPrint + 1
        If (lPrint = 1) Then zReturn = zReturn & vbCrLf & "==================={DOOR LEVERS}==================="
        zReturn = zReturn & vbCrLf & "x" & rsDoor!x & " y" & rsDoor!y & " z" & rsDoor!z
        rsDoor.MoveNext
    Loop
    Set rsDoor = Nothing
    
    zDoorLevers = (MyCStr(zReturn))
    Exit Function
Err_Check:
    subWriteErrorFile "zDoorLevers," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function

Public Function zDoorDesc(lOX As Long, lOY As Long, lOZ As Long) As String
On Error GoTo Err_Check
    Dim rsDoor As Recordset 'Current Area
    Dim zReturn As String
    
    zReturn = ""
    Set rsDoor = MyDB.OpenRecordset("SELECT DoorName, DoorDesc FROM tblDoor WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot) 'The item must be on the ground to see it
    If (Not rsDoor.EOF) Then
        zReturn = gblzFBWHI & MyCStr(rsDoor!DoorName) & vbCrLf & gblzFBBLU & MyCStr(rsDoor!DoorDesc)
    End If
    Set rsDoor = Nothing
    
    zDoorDesc = (MyCStr(zReturn))
    Exit Function
Err_Check:
    subWriteErrorFile "zDoorDesc," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function zTelepodDesc(lOX As Long, lOY As Long, lOZ As Long) As String
On Error GoTo Err_Check
    Dim strSQL As String
    Dim rsTelepod As Recordset 'Current Area
    Dim zReturn As String
    
    zReturn = ""
    Set rsTelepod = MyDB.OpenRecordset("SELECT TelePodName FROM tblTelePod WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
    If (Not rsTelepod.EOF) Then
        zReturn = gblzFBWHI & MyCStr(rsTelepod!TelepodName)
    End If
    Set rsTelepod = Nothing
    
    zTelepodDesc = (MyCStr(zReturn))
    Exit Function
Err_Check:
    subWriteErrorFile "zTelepodDesc," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subAreaMobObjectID(lX As Long, lY As Long, lZ As Long, zPortID As String, bVerboseArea As Boolean)
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim zTag As String
    
    Set rsArea = MyDB.OpenRecordset("SELECT AreaID, AreaName, X, Y, Z FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        subSendMsg "&AArea ID#" & MyCLng(rsArea!AreaID) & " [" & lX & " " & lY & " " & lZ & "] " & MyCStr(rsArea!AreaName), zPortID
    Else
        subSendMsg "&RArea not found at this location!", zPortID
        bVerboseArea = False
    End If
    Set rsArea = Nothing
    
    If (bVerboseArea) Then
        'Where information
        Set rsArea = MyDB.OpenRecordset("SELECT tblWhere.WhereID, tblWhere.WhereWeatherType, tblWhere.TransportX, tblWhere.TransportY, tblWhere.TransportZ, tblWhere.WeatherCondition, tblWhere.WhereMidnight, tblWhere.WhereLateMorning, tblWhere.WhereDawn, tblWhere.WhereMorning, tblWhere.WhereNoon, tblWhere.WhereAfternoon, tblWhere.WhereLateAfternoon, tblWhere.WhereEvening, tblWhere.WhereLateEvening, tblWhere.WhereDusk, tblWhere.WhereTitle, tblArea.AreaName, tblArea.AreaID FROM tblArea INNER JOIN tblWhere ON tblArea.WhereID = tblWhere.WhereID WHERE (((tblArea.X)=" & lX & ") AND ((tblArea.Y)=" & lY & ") AND ((tblArea.Z)=" & lZ & "));", dbOpenSnapshot)
        If (Not rsArea.EOF) Then
            subSendMsg "&wWhereID            " & MyCStr(rsArea!WhereID), zPortID
            subSendMsg "&wWeatherCondition   " & MyCStr(rsArea!WeatherCondition), zPortID
            subSendMsg "&wWhereWeatherType   " & MyCStr(rsArea!WhereWeatherType), zPortID
            subSendMsg "&wTransportX         " & MyCStr(rsArea!TransportX), zPortID
            subSendMsg "&wTransportY         " & MyCStr(rsArea!TransportY), zPortID
            subSendMsg "&wTransportZ         " & MyCStr(rsArea!TransportZ), zPortID
            subSendMsg "&AWhereTitle         " & MyCStr(rsArea!WhereTitle), zPortID
            subSendMsg "&AWhereMidnight      " & MyCStr(rsArea!WhereMidnight), zPortID
            subSendMsg "&AWhereLateMorning   " & MyCStr(rsArea!WhereLateMorning), zPortID
            subSendMsg "&AWhereDawn          " & MyCStr(rsArea!WhereDawn), zPortID
            subSendMsg "&AWhereMorning       " & MyCStr(rsArea!WhereMorning), zPortID
            subSendMsg "&AWhereNoon          " & MyCStr(rsArea!WhereNoon), zPortID
            subSendMsg "&AWhereAfternoon     " & MyCStr(rsArea!WhereAfternoon), zPortID
            subSendMsg "&AWhereLateAfternoon " & MyCStr(rsArea!WhereLateAfternoon), zPortID
            subSendMsg "&AWhereEvening       " & MyCStr(rsArea!WhereEvening), zPortID
            subSendMsg "&AWhereLateEvening   " & MyCStr(rsArea!WhereLateEvening), zPortID
            subSendMsg "&AWhereDusk          " & MyCStr(rsArea!WhereDusk), zPortID
        End If
        Set rsArea = Nothing
    End If
    subSendMsg "&m<<<>>>         <<<>>>        <<<>>>        <<<>>>         <<<>>>         <<<>>>", zPortID
    Set rsArea = MyDB.OpenRecordset("SELECT MobName, MobID FROM tblMob Where (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ") ORDER BY MobName, MobID;", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        Do While (Not rsArea.EOF)
            subSendMsg strForceSize(MyCStr(rsArea!MobName), 60, " ", "A") & "ID#" & MyCLng(rsArea!MobID), zPortID
            rsArea.MoveNext
        Loop
    End If
    Set rsArea = Nothing
    subSendMsg "&w<<<>>>         <<<>>>        <<<>>>        <<<>>>         <<<>>>         <<<>>>", zPortID
    Set rsArea = MyDB.OpenRecordset("SELECT VisibleLevel, Burried, ObjectName, ObjectID FROM tblObject Where (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Status=0) ORDER BY Burried DESC, VisibleLevel, ObjectName, ObjectID;", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        Do While (Not rsArea.EOF)
            zTag = ""
            If (MyCInt(rsArea!Burried) <> 0) Then zTag = zTag & "(burried)"
            If (MyCLng(rsArea!VisibleLevel) <> 0) Then zTag = zTag & "(vl" & MyCLng(rsArea!VisibleLevel) & ")"
            subSendMsg strForceSize(MyCStr(rsArea!ObjectName), 45, " ", "A") & strForceSize(zTag, 15, " ", "A") & "ID#" & MyCLng(rsArea!ObjectID), zPortID
            rsArea.MoveNext
        Loop
    End If
    Set rsArea = Nothing
    subSendMsg "&A<<<>>>         <<<>>>        <<<>>>        <<<>>>         <<<>>>         <<<>>>", zPortID
    Exit Sub
Err_Check:
    subWriteErrorFile "subAreaMobObjectID," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSpecialYearlyEvents(zPortID As String, lX As Long, lY As Long, lZ As Long, bAnimate As Boolean)
On Error GoTo Err_Check
    'Paper koalas and kangaroos dangle from strings from the ceiling. Jan 26 Australian Day.
    Dim zDate As String
    Dim bStatusBM As Boolean
    Dim lPortID As Long
    
    lPortID = MyCLng(zPortID)
    If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        bStatusBM = gblbFilterMode(lPortID)
    End If
    
    zDate = Format(Date, "MMDD")
    If (bAnimate) Then
        'Only areas at the Centre of the City of Ages will see this at 0 0 0
        
        'We animate the stuff at 0 0 0 if there are people there or not to see it
        Select Case zDate 'HALLOWEEN WEEKS ie 1103 for november 03
            Case "1026", "1027", "1028", "1029", "1030", "1031", "1101", "1102", "1103", "1104", "1105"
                Select Case lRandom(7)
                    Case 1
                        subSendMsgAreaAllNotBM gblzFBYEL & "A gust of wind makes the candlelight in the pumpkin flicker a moment.", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM gblzFBMAG & "The pumpkin hisses evilly to itself.", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM "&yThe smell of pumpkin and candle wax is in the air.", 0, 0, 0
                    Case 4
                        subSendMsgAreaAllNotBM "&aYou hear the moaning of voices all about you!", 0, 0, 0
                    Case 5
                        subSendMsgAreaAllNotBM "&aYou feel scared as you hear some evil laughter!", 0, 0, 0
                    Case 6
                        subSendMsgAreaAllNotBM "&aA witch flies her broom silently overhead!", 0, 0, 0
                    Case 7
                        subSendMsgAreaAllNotBM "&aA warlock flies his broom quickly overhead!", 0, 0, 0
                End Select
                If (lRandom(12) = 1) Then subSendMsgAreaAllNotBM "&aSomething behind you yells, 'BOO!'", 0, 0, 0
                If (lRandom(12) = 1) Then subSendMsgAreaAllNotBM "&RAn evil echo cackles, 'MUHUhahahaha!!!'", 0, 0, 0
                If (lRandom(12) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "Something touches you on the shoulder!", 0, 0, 0
                If (lRandom(666) = 1) Then subSimpleRndEchoChannel "&aa shadowy ghost bobs about the room, then quickly circles you and flys away.", 88
                If (lRandom(666) = 1) Then subSimpleRndEchoChannel "&wa torso apparition floats about your feet, circles you then flys away.", 99
                If (lRandom(666) = 1) Then subSimpleRndEchoChannel "&Wa FREAKY GHOST FACE shows itself to you, and just as fast dissipates...", 99
                If (lRandom(666) = 1) Then subSimpleRndEchoChannel "&aAHHhhhhh, its a...&WGHOST FACE&A.&W.&A.&Rscarey&r!!!&w (dissipates)", 99
            Case "1215", "1216", "1217", "1218", "1219", "1220", "1221", "1222", "1223", "1224", "1225", "1226", "1227", "1228", "1229", "1230"
                Select Case lRandom(3)
                    Case 1
                        subSendMsgAreaAllNotBM gblzFBYEL & "The Christmas tree glitters and shines for all to see!", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM gblzFBWHI & "The Christmas tree is sparkling!", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM gblzFNGRE & "The scent of pine needles soothes the lungs.", 0, 0, 0
                End Select
                Select Case zDate
                    Case "1219", "1220", "1221", "1222", "1223", "1224", "1225"
                        If (lRandom(9) = 1) Then subSendMsgAreaAllNotBM "&aA voice in the background yells, 'Merry Christmas everyone!'", 0, 0, 0
                        If (lRandom(9) = 1) Then subSendMsgAreaAllNotBM "&aA different voice in the background yells, 'Merry HO HO to you all!'", 0, 0, 0
                        If (zDate = "1224") Then
                            If (lRandom(5) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "You hear the jingling of Santa's bells.", 0, 0, 0
                            If (lRandom(5) = 1) Then 'turkey yum!
                                Select Case lRandom(3)
                                    Case 1
                                        subSendMsgAreaAllNotBM "&yThe smell of Christmas turkey is wonderful.", 0, 0, 0
                                    Case 2
                                        subSendMsgAreaAllNotBM "&yThe smell of Christmas cooking and preparation makes you hungry.", 0, 0, 0
                                    Case 3
                                        subSendMsgAreaAllNotBM gblzFNWHI & "The smell of Christmas baking is delicious.", 0, 0, 0
                                End Select
                            End If
                        End If
                End Select
            Case "1231", "0101", "0125", "0126" 'New years day and Australian day
                Select Case lRandom(7)
                    Case 1
                        subSendMsgAreaAllNotBM "&aKA-BOOM!", 0, 0, 0
                        subSendMsgAreaAllNotBM "&RA mighty firework explodes overhead into a perfect green and gold sphere!", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM "&aKA-POW!", 0, 0, 0
                        subSendMsgAreaAllNotBM gblzFBYEL & "A smaller firework explodes in the sky!", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM "&aPOW!", 0, 0, 0
                        subSendMsgAreaAllNotBM "&GA tiny firework explodes in the sky and splits off into two other larger ones.", 0, 0, 0
                        subSendMsgAreaAllNotBM "&aBOOM! *delay* BOOM!", 0, 0, 0
                    Case 4
                        subSendMsgAreaAllNotBM "&aCRACKLE! POW!", 0, 0, 0
                        subSendMsgAreaAllNotBM "&RA mighty firework explodes overhead into a perfect yellow and silver sphere!", 0, 0, 0
                    Case 5
                        subSendMsgAreaAllNotBM "&aKA-BOOM!", 0, 0, 0
                        subSendMsgAreaAllNotBM "&RA mighty firework explodes overhead into a perfect blue and red sphere!", 0, 0, 0
                    Case 6
                        subSendMsgAreaAllNotBM "&aPOW! POW! CRACKLE!", 0, 0, 0
                        subSendMsgAreaAllNotBM gblzFBWHI & "A barrage of beautiful red, white, and blue fireworks crackle overhead!", 0, 0, 0
                    Case 7
                        subSendMsgAreaAllNotBM "&aSNAP! CRACKLE! POP!", 0, 0, 0
                        subSendMsgAreaAllNotBM gblzFBYEL & "A barrage of beautiful red, silver, and yellow fireworks scorches the sky!", 0, 0, 0
                End Select
                
                If (zDate = "1231") Then 'XMas only
                    If (lRandom(23) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "A voice from the background yells, 'New Years is coming!'", 0, 0, 0
                    If (lRandom(23) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "A different voice in the background yells, 'I love New Years!'", 0, 0, 0
                End If
                
                If (zDate = "0126") Then 'XMas only
                    If (lRandom(24) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "A voice in the background yells, 'Hey mate its an Australian Federation Day party!'", 0, 0, 0
                    If (lRandom(23) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "A different voice from the background yells, 'Happy Australian Day mate!'", 0, 0, 0
                    If (lRandom(23) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "Another voice from the background yells, 'Happy Australian Day bloke!'", 0, 0, 0
                    If (lRandom(24) = 1) Then subSendMsgAreaAllNotBM gblzFBMAG & "Someone faraway yells, 'Fireworks are amazing stuff, mate.'", 0, 0, 0
                End If
            Case "0317" 'st patricks day
                Select Case lRandom(3)
                    Case 1
                        subSendMsgAreaAllNotBM "&GThe Giant Clover glistens in the air.", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM gblzFBMAG & "The Giant Clover bobs in the wind above.", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM gblzFBMAG & "The Giant Clover waves to everyone with its four leafs.", 0, 0, 0
                End Select
            Case "1007", "1008", "1009", "1010", "1011", "1012", "1013", "1014", "1015", "1016", "1119", "1120", "1121", "1122", "1123", "1124", "1125", "1126", "1127", "1128"
                Select Case lRandom(3)
                    Case 1
                        subSendMsgAreaAllNotBM "&yThe turkey here makes you hungry.", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM "&yThe heaven of a roasting turkey fills you with an appetite.", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM "&yThe scent of the stuffed cooking is simply divine.", 0, 0, 0
                End Select
            Case "0412", "0413", "0414", "0415", "0416", "0417", "0418"
                Select Case lRandom(3)
                    Case 1
                        subSendMsgAreaAllNotBM "&yThe giant chocolate bunny smells sweet.", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM "&yThe chocolate bunny winks at everyone for a moment.", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM "&yThe chocolate bunny gives you the craving to bite its chocolate head clean off!", 0, 0, 0
                End Select
            Case "1111"
                Select Case lRandom(5)
                    Case 1
                        subSendMsgAreaAllNotBM gblzFNMAG & "Red poppy flowers flutter in the wind in respect.", 0, 0, 0
                    Case 2
                        subSendMsgAreaAllNotBM gblzFNMAG & "Red poppy flowers sing a rejoice of prayer for the free.", 0, 0, 0
                    Case 3
                        subSendMsgAreaAllNotBM gblzFBMAG & "You see a ferrit pounce through a grove of Red poppy flowers.", 0, 0, 0
                    Case 4
                        subSendMsgAreaAllNotBM gblzFBMAG & "You see a white bunny bounce through a grove of Red poppy flowers.", 0, 0, 0
                    Case 5
                        subSendMsgAreaAllNotBM gblzFBWHI & "A white dove circles high above for a moment.", 0, 0, 0
                End Select
        End Select
    Else
        If (Not bStatusBM) Then
            'All areas of the realm will see the following
            Select Case zDate 'ie 1103 for november 03
                Case "1026", "1027", "1028", "1029", "1030", "1031", "1101", "1102", "1103", "1104", "1105"
                    subSendMsg "&AGlowing Halloween pumpkin lanterns threaded together pass through this room!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&MAn orange grinning pumpkin has a yellow candlelit face!", zPortID
                Case "1210", "1211", "1212", "1213", "1214"
                    subSendMsg "&AChristmas lights threaded together pass through this room!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&AThere is a tree holder here waiting for the arrival of a Christmas Tree!", zPortID
                Case "1215", "1216", "1217", "1218", "1219", "1220", "1221", "1222", "1223", "1224", "1225", "1226", "1227", "1228", "1229"
                    subSendMsg "&AChristmas lights threaded together pass through this room!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&GThere is a luscious Christmas Tree sparkling away here!", zPortID
                Case "1230"
                    subSendMsg "&ATwinkling New Years Eve lights weave from room to room!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&GThere is an aging Christmas Tree sparkling away here!", zPortID
                Case "1231"
                    subSendMsg "&ATwinkling New Years Eve lights weave from room to room!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&gThere is an aging Christmas Tree here and its lights are down.", zPortID
                Case "0101"
                    subSendMsg "&AUsed New Years Eve confetti blankets everything!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&gNot much of the Christmas Tree is left and its lights are down.", zPortID
                Case "0102"
                    subSendMsg "&AUsed New Years Eve confetti dusts the ground here.", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then
                        subSendMsg "&C*It is magically cold here*", zPortID
                        subSendMsg "&BBeautiful ice sculptures of a roman man and lady are here.", zPortID
                        subSendMsg "&gPine needles are all that are left of the Christmas Tree.", zPortID
                    End If
                Case "0103"
                    If (lX = 0 And lY = 0 And lZ = 0) Then
                        subSendMsg "&C*It is magically cold here*", zPortID
                        subSendMsg "&BBeautiful ice sculptures of a roman man and lady are here.", zPortID
                    End If
                Case "0213", "0214", "0215"
                    subSendMsg "&ALittle paper hearts dangling from a string passing through this room.", zPortID
                Case "0317" 'st patricks day
                    subSendMsg "&GThere are patches of lush fresh clover everywhere!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&GThere is a Giant Four-leafed Clover hovering magically high above!", zPortID
                Case "0412", "0413", "0414", "0415", "0416", "0417", "0418"
                    subSendMsg "&yChocolate bunnies dangle on strings attached to the ceiling!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&yThere is a Giant Chocolate Bunny here!", zPortID
                Case "1007", "1008", "1009", "1010", "1011", "1012", "1013", "1014", "1015", "1016" 'canadian thanks giving
                    subSendMsg "&AThe cooking of turkey and stuffing fills the realm!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&M[&RCan&Wada" & "&M" & "] There is a large rotisserie turkey turning over the coals here!", zPortID
                Case "1119", "1120", "1121", "1122", "1123", "1124", "1125", "1126", "1127", "1128" 'americian thanks giving
                    subSendMsg "&APaper turkeys are strung together everywhere!", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&M[&RU&WS&BA" & "&M" & "] There is a large rotisserie turkey turning over the coals here!", zPortID
                Case "0120", "0121", "0122", "0123", "0124", "0125", "0126", "0127"
                    subSendMsg "&APaper koalas and kangaroos dangle from strings attached to the ceiling.", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&M[&GA&gustr&yalia&G D&ga&yy" & "&M" & "] Hundreds of people are partying everywhere!", zPortID
                Case "1108", "1109", "1110", "1111", "1112", "1113", "1114"  'remberance day
                    subSendMsg "&RRed &ypoppy &Yflow&Wers&a flow over the lands in a quiet respect.", zPortID
                    If (lX = 0 And lY = 0 And lZ = 0) Then subSendMsg "&MA wall of heros from any world war anywhere stands proudly before you!", zPortID
            End Select
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSpecialYearlyEvents," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subAreaDesc(lHallucinate As Long, lDetectInvisibilityDuration As Long, zPortID As String, lOX As Long, lOY As Long, lOZ As Long, lOPlayerLevel As Long, lOPlayerID As Long, lKnowAlignmentDuration As Long, lColourAreaDesc As Long, zRaceType As String, zClassType As String, zPlayerConfig As String, lImmortalLevel As Long, iPureLook As Integer, bStatusBM As Boolean, bStatusGUID As Boolean, zType As String)
On Error GoTo Err_Check
    Const bGrayOn = False
    Dim strSQL As String
    Dim rsArea As Recordset
    Dim zLookDesc As String
    Dim zAdminLookDesc As String
    Dim zLookHazardDesc As String
    Dim zConfig As String
    Dim lRDD As Long
    Dim lRDN As Long
    Dim iMatchRDDRDN As Integer
    Dim bAreaFound As Boolean
    Dim zLineTogether As String
    Dim lPlayerType As Long
    Dim bSpecialEventAllowed As Boolean
    Dim lUnderwater As Long
    Dim lOxygenRequiredLevel As Long
    Dim lRadiatedAreaLevel As Long
    Dim lHeightRequirement As Long
    Dim bDay As Boolean
    Dim lAreaID As Long
    Dim lGID As Long
    Dim lGamblingTotal As Long
    Dim zFactions As String
    Dim lGetDoorID As Long
    Dim zGetDoorName As String
    Dim zKeyNameExtension As String
    Dim lJumpZoneChance As Long
    Dim bPureLook As Boolean
    Dim lPentagramDuration As Long
    Dim lTornadeoDuration  As Long

    bDay = bWhenIsIt("", False)
    
    bPureLook = (iPureLook = 0)
    
    zConfig = Mid(zPlayerConfig, 3, 1)
    
    'Area Description
    zLookDesc = ""
    zAdminLookDesc = ""
    bAreaFound = False
    
    strSQL = "SELECT tblArea.PentagramDuration, tblArea.TornadeoDuration, tblArea.JumpZoneChance, tblArea.GraphicsID, tblArea.AreaType, tblArea.DamageToArea, tblArea.FactionID, tblArea.FactionGrowth, tblArea.FactionAtt, tblArea.FactionDef, tblArea.FactionPopulation, tblArea.DynamicExits, tblArea.Exits, tblArea.GamblingTotal, tblArea.ColonistHostileForces, tblArea.ClanMemberLevel, tblPlayerClan.ClanName, "
    strSQL = strSQL & "tblArea.FlyLevel, tblArea.NoQuestZone, tblArea.PlayerType, tblArea.NoFleeZone, tblWhere.WhereTitle, tblArea.AreaID, tblArea.X, tblArea.Y, tblArea.Z, tblArea.PlayerID, tblArea.SSLaserLevel, tblArea.SSMinesLevel, tblArea.SSEngineLevel, tblArea.SSScanLevel, tblArea.SSShieldLevel, tblArea.SSShieldIntegrity, tblArea.SSHullLevel, tblArea.ColonistsFarm, tblArea.ColonistsFactory, tblArea.AreaSpeciesFertilityPercent, tblArea.BlockedExits, tblArea.HiddenExits, tblArea.AreaName, tblArea.GolfDrivingRange, tblArea.GolfHoleNumber, tblArea.AreaDescDay, tblArea.AreaDescNight, tblArea.HeightRequirement, tblArea.GravityLevel, tblArea.RadiatedAreaLevel, tblArea.GasAreaLevel, tblArea.OxygenRequiredLevel, tblArea.ColonistAllowed, tblArea.ColonistsPlayerID, tblArea.ColonistsNumber, tblArea.GasAreaLevelDesc,tblArea.HeatAreaLevel,tblArea.Underwater, tblArea.AreaDayColour "
    strSQL = strSQL & "FROM (tblArea LEFT JOIN tblWhere ON tblArea.WhereID = tblWhere.WhereID) LEFT JOIN tblPlayerClan ON tblArea.ClanID = tblPlayerClan.ClanID "
    strSQL = strSQL & "WHERE (((tblArea.X)=" & lOX & ") AND ((tblArea.Y)=" & lOY & ") AND ((tblArea.Z)=" & lOZ & "));"
    
    'lPortID = MyCLng(zPortID)
    
    'Exits
    Set rsArea = MyDB.OpenRecordset(strSQL, dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        bAreaFound = True
        lAreaID = MyCLng(rsArea!AreaID)
        lPentagramDuration = MyCLng(rsArea!PentagramDuration)
        lTornadeoDuration = MyCLng(rsArea!TornadeoDuration)
        lJumpZoneChance = MyCLng(rsArea!JumpZoneChance)
        lGID = MyCLng(rsArea!GraphicsID)
        lGamblingTotal = MyCLng(rsArea!GamblingTotal)
        lPlayerType = MyCLng(rsArea!PlayerType)
        lUnderwater = MyCLng(rsArea!Underwater)
        lOxygenRequiredLevel = MyCLng(rsArea!OxygenRequiredLevel)
        lRadiatedAreaLevel = MyCLng(rsArea!RadiatedAreaLevel)
        lHeightRequirement = MyCLng(rsArea!HeightRequirement)
        bSpecialEventAllowed = (lPlayerType = 0 And lUnderwater = 0 And lOxygenRequiredLevel = 0 And lRadiatedAreaLevel = 0 And lHeightRequirement = 0)
        If (lPlayerType > 0) Then 'lPlayerType = MyCLng(rsArea!PlayerType)
            Select Case lPlayerType
                Case 1
                    zLookDesc = zLookDesc & "&a" & MyCStr("(House) " & zReturnPlayerName(MyCLng(rsArea!PlayerID)))
                Case 2
                    zLookDesc = zLookDesc & "&a" & MyCStr("<<@STARSHIP@>> " & zReturnPlayerName(MyCLng(rsArea!PlayerID)))
                Case 3
                    zLookDesc = zLookDesc & "&a~Colony~"
                Case 4
                    zLookDesc = zLookDesc & "&a~Military~"
                Case 5
                    zLookDesc = zLookDesc & "&a~Reservation~"
            End Select
            Select Case lPlayerType
                Case 0
                Case Else
                    If (MyCLng(rsArea!SSShieldLevel) + MyCLng(rsArea!SSHullLevel) > 0) Then zLookDesc = zLookDesc & " [s" & MyCLng(rsArea!SSShieldLevel) & "] [h" & MyCLng(rsArea!SSHullLevel) & "]"
                    If (lOPlayerLevel > 99) Then
                        zLookDesc = zLookDesc & " [" & MyCLng(rsArea!x) & " " & MyCLng(rsArea!y) & " " & MyCLng(rsArea!z) & "]"
                    End If
            End Select
            zLookDesc = zLookDesc & vbCrLf
        End If
        
        If (Len(rsArea!ClanName) <> 0) Then
            zLookDesc = zLookDesc & "&a(clan) " & rsArea!ClanName & vbCrLf
        End If
        
        If (MyCLng(rsArea!ClanMemberLevel) <> 0) Then
            zLookDesc = zLookDesc & "&a(rank) " & zTranslateMortalClanRanks(MyCLng(rsArea!ClanMemberLevel)) & vbCrLf
        End If
        
        If (lPlayerType = 2) Then
            Select Case (MyCLng(rsArea!SSLaserLevel) + MyCLng(rsArea!SSMinesLevel) + MyCLng(rsArea!SSEngineLevel) + MyCLng(rsArea!SSScanLevel) + MyCLng(rsArea!SSShieldLevel) + MyCLng(rsArea!SSHullLevel))
                Case 0 To 50
                    zLookDesc = zLookDesc & "&wEscape Pod "
                Case 51 To 100
                    zLookDesc = zLookDesc & "&wSmall Shuttle Craft "
                Case 101 To 150
                    zLookDesc = zLookDesc & "&wMedium Shuttle Craft "
                Case 151 To 200
                    zLookDesc = zLookDesc & "&wLarge Shuttle Craft "
                Case 201 To 250
                    zLookDesc = zLookDesc & "&wSmall Fighter Craft "
                Case 251 To 300
                    zLookDesc = zLookDesc & "&wMedium Fighter Craft "
                Case 301 To 400
                    zLookDesc = zLookDesc & "&wLarge Fighter Craft "
                Case 401 To 500
                    zLookDesc = zLookDesc & "&wSmall Troopship "
                Case 501 To 600
                    zLookDesc = zLookDesc & "&wMedium Troopship "
                Case 601 To 700
                    zLookDesc = zLookDesc & "&wLarge Troopship "
                Case 701 To 1000
                    zLookDesc = zLookDesc & "&wSmall Battle Cruiser "
                Case 1001 To 1600
                    zLookDesc = zLookDesc & "&wMedium Battle Cruiser "
                Case 1601 To 2200
                    zLookDesc = zLookDesc & "&wLarge Battle Cruiser "
                Case 2201 To 2800
                    zLookDesc = zLookDesc & "&wSmall Cruiser "
                Case 2801 To 3400
                    zLookDesc = zLookDesc & "&wMedium Cruiser "
                Case 3401 To 4000
                    zLookDesc = zLookDesc & "&wLarge Cruiser "
                Case 4001 To 5000
                    zLookDesc = zLookDesc & "&wSmall Carrier "
                Case 5001 To 7000
                    zLookDesc = zLookDesc & "&wMedium Carrier "
                Case 7001 To 9999
                    zLookDesc = zLookDesc & "&wLarge Carrier "
                Case Else
                    zLookDesc = zLookDesc & "&wDreadnought "
            End Select
            
            Select Case (MyCLng(rsArea!SSShieldLevel) + MyCLng(rsArea!SSHullLevel) / 50)
                Case 0 To 10
                    zLookDesc = zLookDesc & "class F "
                Case 11 To 20
                    zLookDesc = zLookDesc & "class E "
                Case 21 To 30
                    zLookDesc = zLookDesc & "class D "
                Case 31 To 40
                    zLookDesc = zLookDesc & "class C "
                Case 41 To 50
                    zLookDesc = zLookDesc & "class B "
                Case 51 To 60
                    zLookDesc = zLookDesc & "class A "
                Case 61 To 80
                    zLookDesc = zLookDesc & "class A+ "
                Case Else
                    zLookDesc = zLookDesc & "class A++ "
            End Select
            
            If (MyCLng(rsArea!SSLaserLevel) + MyCLng(rsArea!SSMinesLevel) > MyCLng(rsArea!SSEngineLevel) + MyCLng(rsArea!SSScanLevel)) Then
                zLookDesc = zLookDesc & "destroyer" & vbCrLf
            Else
                zLookDesc = zLookDesc & "science vessel" & vbCrLf
            End If
        End If
        
        Select Case lColourAreaDesc
            Case 0
                zLookDesc = zLookDesc & "&W"
            Case 1
                zLookDesc = zLookDesc & "&w"
            Case 2
                zLookDesc = zLookDesc & "&a"
        End Select
        
        'bStatusBM = False
        'If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
        '    bStatusBM = gblbFilterMode(lPortID)
        'End If
        If (bStatusBM And Not bStatusGUID) Then
            zLookDesc = zLookDesc & strForceSize((MyCStr(rsArea!AreaName)), 50, " ", "A") & " &A" & (MyCStr(strForceSize(MyCStr(rsArea!WhereTitle), 27, " ", "A"))) & "&A"
        Else
            zLookDesc = zLookDesc & strForceSize((MyCStr(rsArea!AreaName)), 50, " ", "A") & " &A<<" & (MyCStr(strForceSize(MyCStr(rsArea!WhereTitle), 27, " ", "A"))) & "&A>>"
        End If
        If (MyCLng(rsArea!DamageToArea) <> 0) Then
            zLookDesc = zLookDesc & vbCrLf & "&R((<CLEAN TRASH LEVEL " & MyCStr(rsArea!DamageToArea) & ">))"
        End If
        
        If (Len(zType) = 0) Then 'Normal
            If (bDay) Then
                Select Case MyCLng(rsArea!AreaDayColour)
                    Case 1 'Fire
                        Select Case lColourAreaDesc
                            Case 0
                                zLookDesc = zLookDesc & "&R"
                            Case 1
                                zLookDesc = zLookDesc & "&r"
                            Case 2
                                zLookDesc = zLookDesc & "&g"
                        End Select
                    Case 3 'Earth - Default
                        Select Case lColourAreaDesc
                            Case 0
                                zLookDesc = zLookDesc & "&Y"
                            Case 1
                                zLookDesc = zLookDesc & "&y"
                            Case 2
                                zLookDesc = zLookDesc & "&a"
                        End Select
                    Case 4 'Wind
                        Select Case lColourAreaDesc
                            Case 0
                                zLookDesc = zLookDesc & "&C"
                            Case 1
                                zLookDesc = zLookDesc & "&c"
                            Case 2
                                zLookDesc = zLookDesc & "&B"
                        End Select
                    Case 5 'Etheral
                        Select Case lColourAreaDesc
                            Case 0
                                zLookDesc = zLookDesc & "&B"
                            Case 1
                                zLookDesc = zLookDesc & "&b"
                            Case 2
                                zLookDesc = zLookDesc & "&a"
                        End Select
                    Case Else 'Sun
                        Select Case lColourAreaDesc
                            Case 0
                                zLookDesc = zLookDesc & "&Y"
                            Case 1
                                zLookDesc = zLookDesc & "&y"
                            Case 2
                                zLookDesc = zLookDesc & "&a"
                        End Select
                    End Select
                Select Case (lHallucinate > 0)
                    Case True
                        If ((bPureLook Or zConfig = "1") And (Not bStatusBM)) Or (iPureLook = -2) Then zLookDesc = zLookDesc & vbCrLf & (zHallucinate(MyCStr(rsArea!AreaDescDay)))
                    Case Else
                        If ((bPureLook Or zConfig = "1") And (Not bStatusBM)) Or (iPureLook = -2) Then zLookDesc = zLookDesc & vbCrLf & (MyCStr(rsArea!AreaDescDay))
                End Select
            Else
                If (bGrayOn) Then
                Select Case lColourAreaDesc
                    Case 0
                        zLookDesc = zLookDesc & "&a"
                    Case 1
                        zLookDesc = zLookDesc & "&a"
                    Case 2
                        zLookDesc = zLookDesc & "&g"
                End Select
                Else
                Select Case lColourAreaDesc
                    Case 0
                        zLookDesc = zLookDesc & "&b"
                    Case 1
                        zLookDesc = zLookDesc & "&B"
                    Case 2
                        zLookDesc = zLookDesc & "&g"
                End Select
                End If
                Select Case (lHallucinate > 0)
                    Case True
                        If ((bPureLook Or zConfig = "1") And (Not bStatusBM)) Or (iPureLook = -2) Then zLookDesc = zLookDesc & vbCrLf & (zHallucinate(MyCStr(rsArea!AreaDescNight)))
                    Case Else
                        If ((bPureLook Or zConfig = "1") And (Not bStatusBM)) Or (iPureLook = -2) Then zLookDesc = zLookDesc & vbCrLf & (MyCStr(rsArea!AreaDescNight))
                End Select
            End If
        Else 'Immortal wants to see both descriptions.
            Select Case lRandom(2)
                Case 1 'easier way to read it
                    subSendMsg "&g~Formatted - Block 80 - Carriage Returns and Line Feed~", zPortID
                    zLookDesc = "&y" & (MyCStr(rsArea!AreaDescDay))
                    subSendMsg zLookDesc, zPortID
                    
                    zLookDesc = "&A" & (MyCStr(rsArea!AreaDescNight))
                    subSendMsg zLookDesc, zPortID
                Case 2 'this is used to rewrite an area without removing the vbcrlf at the hidden end in zMUD
                    subSendMsg "&g~Non-Formatted - No Carriage Return or Line Feed~", zPortID
                    zLookDesc = "&y" & MyCStr(rsArea!AreaDescDay)
                    subSendMsg zLookDesc, zPortID
                    
                    zLookDesc = "&A" & MyCStr(rsArea!AreaDescNight)
                    subSendMsg zLookDesc, zPortID
            End Select
            subSendMsg "&gNote: IMMO RALL again for both random formatting views.", zPortID
            zLookDesc = ""
        End If
        
        If (zClassType = "GY" Or zClassType = "AS" Or zClassType = "GL" Or zClassType = "WA") Then
            If (lJumpZoneChance > 0) Then
                zLookDesc = zLookDesc & vbCrLf & "&GJump Chance: [" & lJumpZoneChance & "%]"
            End If
        End If
        
        If (lPentagramDuration > 0 And lTornadeoDuration > 0) Then
            zLookDesc = zLookDesc & vbCrLf & "&yPent: [" & lPentagramDuration & "] Torn: [" & lTornadeoDuration & "]"
        Else
            If (lPentagramDuration > 0) Then
                zLookDesc = zLookDesc & vbCrLf & "&yPentagram: [lv" & lPentagramDuration & "]"
            End If
            If (lTornadeoDuration > 0) Then
                zLookDesc = zLookDesc & vbCrLf & "&yTornado: [lv" & lTornadeoDuration & "]"
            End If
        End If
        'Debug.Print bPureLook & " " & zConfig & " " & bStatusBM & " " & iPureLook
        'Debug.Print ((bPureLook Or zConfig = "1") And (Not bStatusBM)) Or (iPureLook = -2)
        If (Not bStatusBM) Then '((bPureLook Or zConfig = "1") And (Not bStatusBM)) Or (iPureLook = -2) Then
            If (Len(MyCStr(rsArea!GolfHoleNumber)) > 0) Then
                zLookDesc = zLookDesc & vbCrLf & "&GGolfing hole: [" & MyCStr(rsArea!GolfHoleNumber) & "]"
            End If
            
            If (MyCLng(rsArea!GolfDrivingRange) <> 0) Then
                zLookDesc = zLookDesc & vbCrLf & "&GDriving Bonus: [" & MyCStr(rsArea!GolfDrivingRange) & "]"
            End If
        End If
        If (MyCLng(rsArea!ColonistHostileForces) > 0) Then
            If (lOPlayerLevel > 49) Then
                zLookDesc = zLookDesc & vbCrLf & "&RPhaser quest: [+h" & MyCLng(rsArea!ColonistHostileForces) & "]"
            Else
                zLookDesc = zLookDesc & vbCrLf & "&RPhaser quest: [+h" & MyCLng(rsArea!ColonistHostileForces) & "]&r(you must own the colony to ss fire on hostile forces)"
            End If
        End If
        
        If (bPureLook Or MyCLng(rsArea!FactionID) <> 0) And (Not bStatusBM) Then
            zFactions = "|" & zTranslateFactionName(MyCLng(rsArea!FactionID))
            
            If (MyCLng(rsArea!FactionGrowth) <> 0) Then
                zFactions = zFactions & "|G" & MyCLng(rsArea!FactionGrowth)
            End If
            
            If (MyCLng(rsArea!FactionAtt) <> 0) Then
                zFactions = zFactions & "|A" & MyCLng(rsArea!FactionAtt)
            End If
            
            If (MyCLng(rsArea!FactionDef) <> 0) Then
                zFactions = zFactions & "|D" & MyCLng(rsArea!FactionDef)
            End If
            
            If (MyCLng(rsArea!FactionPopulation) <> 0) Then
                zFactions = zFactions & "|P" & MyCLng(rsArea!FactionPopulation)
            End If
            
            If (Len(zFactions) <> 0) Then zLookDesc = zLookDesc & vbCrLf & "&a" & zFactions & "|"
        End If
        
        If (bPureLook Or MyCInt(rsArea!ColonistAllowed) <> 0) And (Not bStatusBM) Then
            zLookDesc = zLookDesc & "&a"
            If (MyCLng(rsArea!ColonistsPlayerID) <> 0) Then
                zLookDesc = zLookDesc & vbCrLf & "[" & zReturnPlayerName(MyCLng(rsArea!ColonistsPlayerID)) & "] c[" & MyCLng(rsArea!ColonistsNumber) & "] g[" & MyCStr(rsArea!AreaSpeciesFertilityPercent) & "]"
            Else
                zLookDesc = zLookDesc & vbCrLf & "[Primitives] c[" & MyCLng(rsArea!ColonistsNumber) & "] g[" & MyCStr(rsArea!AreaSpeciesFertilityPercent) & "]"
            End If
            zLookDesc = zLookDesc & vbCrLf & "[Farms " & MyCLng(rsArea!ColonistsFarm) & "]"
            zLookDesc = zLookDesc & " [Factories " & MyCLng(rsArea!ColonistsFactory) & "]"
        End If
        zAdminLookDesc = ""
        If (lImmortalLevel > 0) Then
            lRDD = Len(MyCStr(rsArea!AreaDescDay))
            lRDN = Len(MyCStr(rsArea!AreaDescNight))
            iMatchRDDRDN = (MyCStr(rsArea!AreaDescDay) = MyCStr(rsArea!AreaDescNight))
            zAdminLookDesc = "(EYE) AID#<" & lAreaID & "> GID#<" & zTranslateGraphicalID(lGID) & "> Flee(" & basBoolean(MyCInt(rsArea!NoFleeZone) = 0) & ")" & vbCrLf & "Quest(" & basBoolean(MyCInt(rsArea!NoQuestZone) = 0) & ") FlyLv(" & MyCLng(rsArea!FlyLevel) & ") DayNightSame(" & basBoolean(iMatchRDDRDN) & ")"
        Else
            If (gblbGraphicIDsOnOff(MyCLng(zPortID)) Or lImmortalLevel > 0) Then
                zAdminLookDesc = "AID#<" & lAreaID & "> GID#<" & zTranslateGraphicalID(lGID) & ">"
            End If
        End If
        zLookHazardDesc = ""
        If (MyCLng(rsArea!GravityLevel) > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 1
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 2
                    zLookHazardDesc = zLookHazardDesc & "&g"
            End Select
            zLookHazardDesc = zLookHazardDesc & vbCrLf & "The gravity here is " & Format(MyCLng(rsArea!GravityLevel), "FIXED") & "g."
        End If
        
        If (lRadiatedAreaLevel > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 1
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 2
                    zLookHazardDesc = zLookHazardDesc & "&g"
            End Select
            zLookHazardDesc = zLookHazardDesc & vbCrLf & "The radiation here is " & Format(MyCLng(rsArea!RadiatedAreaLevel), "FIXED") & " particles per nanosecond."
        End If
        
        If (lOxygenRequiredLevel > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookHazardDesc = zLookHazardDesc & "&a"
                Case 1
                    zLookHazardDesc = zLookHazardDesc & "&a"
                Case 2
                    zLookHazardDesc = zLookHazardDesc & "&a"
            End Select
            zLookHazardDesc = zLookHazardDesc & vbCrLf & "There isn't enough oxygen in the area to sustain life for very long."
        End If
        
        If (MyCLng(rsArea!GasAreaLevel) > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 1
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 2
                    zLookHazardDesc = zLookHazardDesc & "&g"
            End Select
            zLookHazardDesc = zLookHazardDesc & vbCrLf & "Gas Hazard [" & MyCStr(rsArea!GasAreaLevelDesc) & "] Level " & Format(MyCLng(rsArea!GasAreaLevel), "FIXED") & "."
        End If
        
        If (MyCLng(rsArea!HeatAreaLevel) > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 1
                    zLookHazardDesc = zLookHazardDesc & "&r"
                Case 2
                    zLookHazardDesc = zLookHazardDesc & "&g"
            End Select
            zLookHazardDesc = zLookHazardDesc & vbCrLf & "There is a level " & Format(MyCLng(rsArea!HeatAreaLevel), "FIXED") & " fire in the area."
        End If
        
        If (lUnderwater > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookHazardDesc = zLookHazardDesc & "&C"
                Case 1
                    zLookHazardDesc = zLookHazardDesc & "&c"
                Case 2
                    zLookHazardDesc = zLookHazardDesc & "&g"
            End Select
            If (lUnderwater < 650) Then '650cm or 23 feet abouts
                If (lUnderwater > 20) Then
                    zLookHazardDesc = zLookHazardDesc & vbCrLf & "The water here is " & Format((MyCLng(rsArea!Underwater) / 2.54) / 12, "FIXED") & " feet deep."
                Else
                    If (lUnderwater < 6) Then
                        zLookHazardDesc = zLookHazardDesc & vbCrLf & "It is moist here."
                    Else
                        zLookHazardDesc = zLookHazardDesc & vbCrLf & "The floor is moist and wet here."
                    End If
                End If
            Else
                zLookHazardDesc = zLookHazardDesc & vbCrLf & "The room is full of water!"
            End If
        End If
        
        If (lHeightRequirement > 0) Then
            Select Case lColourAreaDesc
                Case 0
                    zLookDesc = zLookDesc & gblzFBWHI
                Case 1
                    zLookDesc = zLookDesc & "&w"
                Case 2
                    zLookDesc = zLookDesc & "&g"
            End Select
            zLookDesc = zLookDesc & vbCrLf & "The ceiling here is " & Format((lHeightRequirement / 2.54) / 12, "FIXED") & " feet high."
        End If
        
        If (lGamblingTotal <> 0) Then zLookDesc = zLookDesc & vbCrLf & gblzFBYEL & "$" & lGamblingTotal
        
        subSendMsg zLookDesc & zLookHazardDesc, zPortID
        'end of part 1
        
        'second half to do now
        If (Len(zAdminLookDesc) > 0) Then subSendMsg gblzFNGRE & zAdminLookDesc, zPortID
        
        If (bSpecialEventAllowed) Then subSpecialYearlyEvents zPortID, lOX, lOY, lOZ, False
        
        zLookDesc = ""
        If (Not bStatusBM) Then
        If (gbliDayCodeTick > 3 And gbliDayCodeTick < 40) Then 'Day/Sunny AreaType
            zLookDesc = zLookDesc & "&y" 'see also: AreaHotCold
            Select Case MyCLng(rsArea!AreaType) '0=not shaded 1=freezing cold not shaded // SHADED + Roof&Area is ( 9=shaded and wet 10=leaf shaded 20=Wooden 21=Brick/Rock 22=Concrete Roof 23=jiprock 29=Tin 30=cavern 31=alien)
                Case 1 'icey area
                    zLookDesc = zLookDesc & "Sun light glints off of the ice and snow in the area." & vbCrLf
                Case 9 'Water area [Underwater depth variable]
                    zLookDesc = zLookDesc & "Water in the area keeps you cool and protected from the sun." & vbCrLf
                Case 10 'Shaded
                    zLookDesc = zLookDesc & "The large trees and their leafs shade the area from the sun." & vbCrLf
                Case 20 'Wooden Roof
                    zLookDesc = zLookDesc & "The area is shaded by a wooden roof." & vbCrLf
                Case 21 'Brick/Rock Roof
                    zLookDesc = zLookDesc & "The area is shaded by a Brick/Rock-hybrid roof." & vbCrLf
                Case 22 'Concrete Roof
                    zLookDesc = zLookDesc & "The area is shaded by a Concrete roof." & vbCrLf
                Case 28 'jiprock Roof
                    zLookDesc = zLookDesc & "Very modern jiprock roof." & vbCrLf
                Case 29 'Metal Roof
                    zLookDesc = zLookDesc & "Very modern tin roof." & vbCrLf
                Case 30 'Underground
                    zLookDesc = zLookDesc & "These cool caverns conceal you from the sun." & vbCrLf
                Case 31 'Underground
                    zLookDesc = zLookDesc & "Alien sludge covers the area." & vbCrLf
            End Select
        Else 'Night AreaType
            zLookDesc = zLookDesc & "&y"
            Select Case MyCLng(rsArea!AreaType) 'see also: AreaHotCold
                Case 1 'icey area
                    zLookDesc = zLookDesc & "Ice and snow covers the area, under the moonlight." & vbCrLf
                Case 9 'Water area [Underwater depth variable]
                    zLookDesc = zLookDesc & "Water in the area keeps you cool, the dark conceals you." & vbCrLf
                Case 10 'Shaded
                    zLookDesc = zLookDesc & "The large trees and their leafs, conceals you in the dark." & vbCrLf
                Case 20 'Wooden Roof
                    zLookDesc = zLookDesc & "The area is shaded by a wooden roof." & vbCrLf
                Case 21 'Brick/Rock Roof
                    zLookDesc = zLookDesc & "The area is shaded by a Brick/Rock-hybrid roof." & vbCrLf
                Case 22 'Concrete Roof
                    zLookDesc = zLookDesc & "The area is shaded by a Concrete roof." & vbCrLf
                Case 28 'jiprock Roof
                    zLookDesc = zLookDesc & "Very modern jiprock roof." & vbCrLf
                Case 29 'Metal Roof
                    zLookDesc = zLookDesc & "Very modern tin roof." & vbCrLf
                Case 30 'Underground
                    zLookDesc = zLookDesc & "These cool caverns and night air conceal you." & vbCrLf
                Case 31 'Underground
                    zLookDesc = zLookDesc & "Alien sludge covers the area." & vbCrLf
            End Select
        End If
        End If
        
        zLookDesc = zLookDesc & "&w"
        If (MyCInt(rsArea!DynamicExits) = 0) Then 'DYNAMIC means it is realtime/changes/recalculates when this is FALSE/NO it is faster but does not calculate the area for each LOOK.
            'If (lImmortalLevel > 0) Then zLookDesc = "<|>" 'shows the immortal that this is a dynamic exits area
            zLookDesc = zLookDesc & MyCStr(rsArea!Exits) 'since we already read the drive may as well use this
        Else
            'Areas that move you want a dynamic changing type look ability.
            zLookDesc = zLookDesc & zShowExits(lOX, lOY, lOZ)
        End If
        
        If (Len(zLookDesc) > 0) Then
            subSendMsg zLookDesc, zPortID
        Else
            subSendMsg "There are no visible exits.", zPortID
        End If
        
        zLookDesc = zAreaShowDoors(MyCStr(rsArea!HiddenExits), MyCStr(rsArea!BlockedExits), lOX, lOY, lOZ) 'doors have to be dynamic because they open and close a lot
        If (Len(zLookDesc) > 0) Then subSendMsg zLookDesc, zPortID
    Else 'inside the door?
        If (bCheckDoorExists("", lOX, lOY, lOZ)) Then
            lGetDoorID = lDoorID(lOX, lOY, lOZ)
            zGetDoorName = zShortstop(zDoorName(lGetDoorID))
            subSendMsg "&Y" & zGetDoorName & "&y DoorID#" & lGetDoorID, zPortID
            subSendMsg zDoorDesc(lOX, lOY, lOZ), zPortID
            subSendMsg zDoorLevers(lGetDoorID), zPortID
        Else
            subSendMsg "&AYou are in the Ether VOID [outerspace to mortals] use TELE X Y Z to move." & vbCrLf & "IMMO RC             (to create a room here)" & vbCrLf & "IMMO RB <dir> <+/-> (to open up portal holes)", zPortID
        End If
    End If
    Set rsArea = Nothing
    
    subShowFishingPonds zPortID, lOX, lOY, lOZ
    'basSenseForTraps lOX, lOY, lOZ, "ELF", "RA", lOPlayerID, zPortID
    subShowMobsAndObjects lDetectInvisibilityDuration, lOX, lOY, lOZ, zPortID, lOPlayerLevel, lOPlayerID, lColourAreaDesc, zRaceType, zClassType, lKnowAlignmentDuration
    subShowPlayers lDetectInvisibilityDuration, zPortID, lOX, lOY, lOZ, lOPlayerLevel, lKnowAlignmentDuration, lOPlayerID 'tblPets subShowPets
    Exit Sub
Err_Check:
    subWriteErrorFile "subAreaDesc," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zShowExits(lngX As Long, lngY As Long, lngZ As Long) As String
On Error GoTo Err_Check
    Dim strSQL As String
    Dim rsMomentum As Recordset
    Dim rsArea As Recordset 'Current Area
    Dim strBlockedExits As String
    Dim strHiddenExits As String
    Dim strExits As String
    Dim strReturn As String
    Dim bNorth As Boolean
    Dim bSouth As Boolean
    Dim bEast As Boolean
    Dim bWest As Boolean
    Dim bNW As Boolean
    Dim bNE As Boolean
    Dim bSW As Boolean
    Dim bSE As Boolean
    Dim bUp As Boolean
    Dim bDown As Boolean
    Dim zSQL As String
    Dim lAX As Long
    Dim lAY As Long
    Dim lAZ As Long
    
    strReturn = "&aYou are in the VOID. Type RC (room create) or DC (door create)" & vbCrLf & "to fill this empty matrix spot."
    
    strBlockedExits = "ALL BLOCKED"
    
    'Get Area Full Data - if you are at at door x y z we show the door desc
    Set rsArea = MyDB.OpenRecordset("SELECT X, Y, Z, BlockedExits, HiddenExits FROM tblArea WHERE (X=" & lngX & " AND Y=" & lngY & " AND Z=" & lngZ & ");", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        strReturn = "None"
        strBlockedExits = strForceSize(MyCStr(rsArea!BlockedExits), 10, "0", "A")
        strHiddenExits = strForceSize(MyCStr(rsArea!HiddenExits), 10, "0", "A")
    Else
        If (bCheckDoorExists("", lngX, lngY, lngZ)) Then
            strReturn = "&RYou are in the doorway." & vbCrLf & zDoorDesc(lngX, lngY, lngZ)
        End If
    End If
    Set rsArea = Nothing
    
    'Two areas should NEVER exist in the same spot.
    
    If (InStr(strBlockedExits, "0") <> 0) Then 'There is at least one viable exit - later we need to scan around to make sure areas exist around the location.
        strExits = ""
        'Now we scan the area around the current X, Y, Z
        zSQL = "SELECT X, Y, Z, BlockedExits, HiddenExits, PlayerID FROM tblArea "
        zSQL = zSQL & "WHERE ((X=" & lngX - 1 & " Or X=" & lngX + 1 & ") AND (Y=" & lngY & ") AND (Z=" & lngZ & ") AND (PlayerType<>2)) OR ((X=" & lngX & ") AND (Y=" & lngY - 1 & " Or Y=" & lngY + 1 & ") AND (Z=" & lngZ & ") AND (PlayerType<>2)) OR ((X=" & lngX & ") AND (Y=" & lngY & ") AND (Z=" & lngZ - 1 & " Or Z=" & lngZ + 1 & ") AND (PlayerType<>2)) OR ((X=" & lngX - 1 & ") AND "
        zSQL = zSQL & "(Y=" & lngY - 1 & ") AND (Z=" & lngZ & ") AND (PlayerType<>2)) OR ((X=" & lngX + 1 & ") AND (Y=" & lngY + 1 & ") AND (Z=" & lngZ & ") AND (PlayerType<>2)) OR ((X=" & lngX + 1 & ") AND (Y=" & lngY - 1 & ") AND (Z=" & lngZ & ") AND (PlayerType<>2)) OR ((X=" & lngX - 1 & ") AND (Y=" & lngY + 1 & ") AND (Z=" & lngZ & ") AND (PlayerType<>2)) ORDER BY X, Y, Z;"
        
        Set rsArea = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
        Do While (Not rsArea.EOF)
            lAX = MyCLng(rsArea!x)
            lAY = MyCLng(rsArea!y)
            lAZ = MyCLng(rsArea!z)
            
            'Check N Exit
            If (lAX = lngX And lAY - lngY = -1 And Mid(strBlockedExits, 1, 1) = "0" And Mid(strHiddenExits, 1, 1) = "0") Then
                If (Not bNorth) Then
                    strExits = strExits & "North, "
                    bNorth = True
                End If
            End If
            
            'Check S Exit
            If (lAX = lngX And lAY - lngY = 1 And Mid(strBlockedExits, 2, 1) = "0" And Mid(strHiddenExits, 2, 1) = "0") Then
                If (Not bSouth) Then
                    strExits = strExits & "South, "
                    bSouth = True
                End If
            End If
            
            'Check E Exit
            If (lAX - lngX = 1 And lAY = lngY And Mid(strBlockedExits, 3, 1) = "0" And Mid(strHiddenExits, 3, 1) = "0") Then
                If (Not bEast) Then
                    strExits = strExits & "East, "
                    bEast = True
                End If
            End If
            
            'Check W Exit
            If (lAX - lngX = -1 And lAY = lngY And Mid(strBlockedExits, 4, 1) = "0" And Mid(strHiddenExits, 4, 1) = "0") Then
                If (Not bWest) Then
                    strExits = strExits & "West, "
                    bWest = True
                End If
            End If
            
            'Check NE Exit
            If (lAX - lngX = 1 And lAY - lngY = -1 And Mid(strBlockedExits, 5, 1) = "0" And Mid(strHiddenExits, 5, 1) = "0") Then
                If (Not bNE) Then
                    strExits = strExits & "Northeast, "
                    bNE = True
                End If
            End If
            
            'Check NW Exit
            If (lAX - lngX = -1 And lAY - lngY = -1 And Mid(strBlockedExits, 6, 1) = "0" And Mid(strHiddenExits, 6, 1) = "0") Then
                If (Not bNW) Then
                    strExits = strExits & "Northwest, "
                    bNW = True
                End If
            End If
            
            'Check SE Exit
            If (lAX - lngX = 1 And lAY - lngY = 1 And Mid(strBlockedExits, 7, 1) = "0" And Mid(strHiddenExits, 7, 1) = "0") Then
                If (Not bSE) Then
                    strExits = strExits & "Southeast, "
                    bSE = True
                End If
            End If
            
            'Check SW Exit
            If (lAX - lngX = -1 And lAY - lngY = 1 And Mid(strBlockedExits, 8, 1) = "0" And Mid(strHiddenExits, 8, 1) = "0") Then
                If (Not bSW) Then
                    strExits = strExits & "Southwest, "
                    bSW = True
                End If
            End If
            
            'Check Up Exit
            If (lAX = lngX And lAY = lngY And lAZ - lngZ = -1 And Mid(strBlockedExits, 9, 1) = "0" And Mid(strHiddenExits, 9, 1) = "0") Then
                If (Not bUp) Then
                    strExits = strExits & "Up, "
                    bUp = True
                End If
            End If
            
            'Check Down Exit
            If (lAX = lngX And lAY = lngY And lAZ - lngZ = 1 And Mid(strBlockedExits, 10, 1) = "0" And Mid(strHiddenExits, 10, 1) = "0") Then
                If (Not bDown) Then
                    strExits = strExits & "Down, "
                    bDown = True
                End If
            End If
            
            rsArea.MoveNext
        Loop
        
        If (Len(strExits) <> 0) Then strReturn = Mid(strExits, 1, Len(strExits) - 2) 'trim off the comma + space
        
        Set rsArea = Nothing
    End If
    
    zShowExits = "Quicks: " & strReturn 'Exits is a reserved word, Quicks is good enough
    
    Exit Function
Err_Check:
    subWriteErrorFile "zShowExits," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function zAreaShowDoors(zHiddenExits As String, zBlockedExits As String, lOX As Long, lOY As Long, lOZ As Long) As String
On Error GoTo Err_Check 'See Also the controller: subrotatetheworld
    Dim rsDoor As Recordset 'Doors around area
    Dim strDoorNames As String
    Dim zNextExit As String
    Dim zDoorName As String
    Dim iPos As Integer
    Dim zHealth As String
    Dim zReturn As String
    Dim lDoorMax As Long
    Dim lDoorTries As Long
    
    'Get all the doors around the area to the N S E W and Up and Down only.
    Set rsDoor = MyDB.OpenRecordset("SELECT tblDoor.BashDoorTries, tblDoor.BashDoorMax, tblDoor.MagicDoorTries, tblDoor.MagicDoorMax, tblDoor.Status, tblDoor.X, tblDoor.Y, tblDoor.Z, tblDoor.DoorName FROM tblDoor WHERE (((tblDoor.X)=" & lOX & "-1 Or (tblDoor.X)=" & lOX & "+1) AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & "-1 Or (tblDoor.Y)=" & lOY & "+1) AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & "-1 Or (tblDoor.Z)=" & lOZ & "+1));", dbOpenSnapshot)
    If (Not rsDoor.EOF) Then
        zReturn = gblzFNYEL
        Do While (Not rsDoor.EOF) 'Unlike areas, doors are always seen if they are touching areas. Doors only work N S E W or Up and Down not on angles.
            zHealth = ""
            lDoorMax = 0
            Select Case (MyCLng(rsDoor!Status))
                Case 5, 7, 8 'bashable hinged/rusted/magnetically sealed
                    lDoorMax = MyCLng(rsDoor!BashDoorMax)
                    lDoorTries = MyCLng(rsDoor!BashDoorTries)
                Case 10, 11, 12 'majically sealed
                    lDoorMax = MyCLng(rsDoor!MagicDoorMax)
                    lDoorTries = MyCLng(rsDoor!MagicDoorTries)
            End Select
            If (lDoorMax > 0) Then
                zHealth = MyCStr(100 - MyCLng(lDoorTries * 100 / lDoorMax)) & "%" 'doors bash or majic health left if any or use lockpick or use key
            End If
            zNextExit = zTranslateMatrixDirection(MyCLng(rsDoor!x), MyCLng(rsDoor!y), MyCLng(rsDoor!z), lOX, lOY, lOZ, 1)
            iPos = iDirectionSwitchCode(zNextExit)
            If (iPos <> 0) Then
                zDoorName = zShortstop(MyCStr(rsDoor!DoorName)) & "[" & zTranslateDoorStatus(MyCInt(rsDoor!Status)) & "] " & zHealth
                If (Mid(zBlockedExits, iPos, 1) = "0" And Mid(zHiddenExits, iPos, 1) = "0") Then zReturn = zReturn & UCase(zNextExit) & ": " & zDoorName & vbCrLf
            End If
            rsDoor.MoveNext
        Loop
    Else
        zReturn = ""
    End If
    Set rsDoor = Nothing
    zAreaShowDoors = zTrimCrLf(zReturn)
    Exit Function
Err_Check:
    subWriteErrorFile "zAreaShowDoors," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subPlayerGoesToJailDoNotPassGo(lPlayerID As Long, zMobName As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zPortID As String
    Dim lLUC As Long
    Dim lCHA As Long
    Dim lAlignment As Long
    Dim lJailDuration As Long
    Dim lPortID As Long
    
    If (lRandom(30) = 1) Then
        Set rsPlayer = MyDB.OpenRecordset("SELECT WhereID, NegateDuration, Status, X, Y, Z, Alignment, CCHA, CLUC, JailDuration, PlayerName, PortID FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lLUC = MyCLng(rsPlayer!CLuc)
            lCHA = MyCLng(rsPlayer!CCHA)
            lAlignment = MyCLng(rsPlayer!Alignment)
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            zPortID = MyCStr(rsPlayer!PortID)
            lPortID = MyCLng(zPortID)
            If ((lRandom(lCHA) * 2 + lRandom(MyCLng(lLUC / 2))) + lAlignment < -550) Then
                subSendMsg "&R[A R R E S T E D &rBY " & UCase(zAdverb(zMobName, 1) & zShortstop(zMobName)) & "&R]&a al[" & lAlignment & "]", zPortID
                subSimpleEchoChannel "&a" & zAdverb(zMobName, 1) & zShortstop(zMobName) & " tosses " & zPlayerName & " into jail!"
                If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                    rPCombat(lPortID).lID = 0 'We cancel any attacking
                    rMCombat(lPortID).lID = 0
                    rSCombat(lPortID).iStatus = cstiStatusNotInBattleMode
                End If
                lJailDuration = MyCLng(Abs(lAlignment) / 20) + 15
                MyDB.Execute "UPDATE tblPlayer SET Status=5, RecallX=0, RecallY=0, RecallZ=0, ShadowCloakDuration=0, CamoflaguedDuration=0, InvisibilityDuration=0, X=-2, Y=-3, Z=0, WhereID=" & lWhereID(-2, -3, 0) & ", Alignment=" & lRandom(Abs(lAlignment)) & ", JailDuration=" & lJailDuration & ", NegateDuration=" & (lJailDuration + 50) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                If (lRandom(99) = 1) Then 'we strip their clan membership!
                    MyDB.Execute "UPDATE tblPlayer SET ClanID=0, ClanMemberLevel=0 WHERE (ImmortalLevel=0 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                    subSendMsg "&R[You were stripped of your Clan Membership] &g[You can earn one back]", zPortID
                End If
            Else
                If ((InStr(zMobName, "TECH") > 0) Or (InStr(zMobName, "CYBER") > 0) Or (InStr(zMobName, "ROBOT") > 0) Or (InStr(zMobName, "VEGI") = 0 And InStr(zMobName, "PLANT") = 0 And InStr(zMobName, "WOLF") = 0 And InStr(zMobName, "VAMPYRE") = 0 And InStr(zMobName, "VAMPIRE") = 0 And InStr(zMobName, "UNDEAD") = 0 And InStr(zMobName, "FOX") = 0 And InStr(zMobName, "BEAR") = 0 And InStr(zMobName, "PARROT") = 0 And InStr(zMobName, "BIRD") = 0 And InStr(zMobName, "MONKEY") = 0 And InStr(zMobName, "CAT") = 0 And InStr(zMobName, "DOG") <> 0)) Then  'some things like guard dogs are not allowed to speak unless it is robotic
                    If (lAlignment < -300 Or lAlignment = 0) Then
                        If (lAlignment = 0) Then
                            If (lRandom(lCHA + lLUC) < lRandom(6)) Then
                                subSendMsg "&W" & zAdverb(zMobName, 1) & zShortstop(zMobName) & " warns you, 'you never seem to change face, hmmm.'", zPortID
                            End If
                        Else
                            If (lRandom(lCHA + lLUC) < lRandom(11)) Then
                                subSendMsg "&R" & zAdverb(zMobName, 1) & zShortstop(zMobName) & " tells you, 'you are being very naughty lately. You have been warned!'", zPortID
                                subSendMsgAreaExcept2 "&R" & zAdverb(zMobName, 1) & zShortstop(zMobName) & " gives an official warning to " & zPlayerName & "!", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, ""
                            End If
                        End If
                    End If
                End If
            End If
        End If
        Set rsPlayer = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerGoesToJailDoNotPassGo," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function subShowMobsAndObjects(lDetectInvisibilityDuration As Long, lngX As Long, lngY As Long, lngZ As Long, zPortID As String, lPlayerLevel As Long, lOPlayerID As Long, lColourAreaDesc As Long, zRaceType As String, zClassType As String, lKnowAlignmentDuration As Long)
On Error GoTo Err_Check
    Dim strSQL As String
    Dim bColour As Boolean
    Dim rsMob As Recordset
    Dim rsObject As Recordset
    Dim strCompare As String
    Dim lCounter As Long
    Dim zLineDescData As String
    Dim zMarkingRune As String
    Dim zMarkingHumming As String
    Dim zMarkingGlowing As String
    Dim lWeaponName As Long
    Dim bInvisible As Boolean
    Dim zSQL As String
    Dim zPrefixLineDescData As String
    Dim bSeeTrainableMobs As Boolean
    Dim zMobNameJailGuard As String
    Dim bGuard As Boolean
    Dim bSecurity As Boolean
    Dim bJailer As Boolean
    Dim lDefeatedMobDesc As Long
    Dim zColourGlowing As String
    Dim lLocation As Long
    Dim lMHP As Long
    Dim lMHPBonus As Long
    Dim lMobMaxHP As Long
    Dim lMMobLevel As Long
    Dim lCalcuMobHPPercent As Long
    Dim lRottingRounds As Long
    Dim zMobName As String
    Dim zMobNameNight As String
    Dim lMobNameNightLen As Long
    Dim lFlyHeight As Long
    Dim lTemperatureType As Long
    Dim lEquipmentTotal As Long
    Dim bDay As Boolean

    bDay = bWhenIsIt("", False)
     
    'Elf CY CL PA all get true site to see room objects [objects have a seen level to them, player level >= seen level of the object to see it]
    zSQL = zSQL & "SELECT Count(tblObject.ObjectID) AS CountOfObjectID, tblObject.VisibleLevel, tblObject.AllowColourFormat, tblObject.ObjectName, tblObject.ReturnPlayerID, tblObject.BonusXP, tblObject.LightRadius, tblObject.Gold, tblObject.RottingRounds, tblObject.Rare, tblObject.MurderPlayerHeart, tblObject.TemperatureType, tblObject.LightProvider, tblObject.LightDuration, tblObject.MarkingRune, tblObject.ColourGlowing, tblObject.MarkingHumming, tblObject.MarkingGlowing, tblObject.Location, tblObject.QuestForGlory, tblObject.StargateStatus "
    zSQL = zSQL & "FROM tblObject "
    zSQL = zSQL & "GROUP BY tblObject.AllowColourFormat, tblObject.ObjectName, tblObject.ReturnPlayerID, tblObject.BonusXP, tblObject.LightRadius, tblObject.Gold, tblObject.RottingRounds, tblObject.Rare, tblObject.MurderPlayerHeart, tblObject.TemperatureType, tblObject.LightProvider, tblObject.LightDuration, tblObject.MarkingRune, tblObject.ColourGlowing, tblObject.MarkingHumming, tblObject.MarkingGlowing, tblObject.Location, tblObject.QuestForGlory, tblObject.StargateStatus, tblObject.X, tblObject.Y, tblObject.Z, tblObject.VisibleLevel, tblObject.PlayerID, tblObject.Status, tblObject.Burried, tblObject.ObjectID HAVING (((tblObject.X)=" & lngX & ") AND ((tblObject.Y)=" & lngY & ") AND ((tblObject.Z)=" & lngZ & ") AND ((tblObject.VisibleLevel)<999) AND ((tblObject.PlayerID)=0) AND ((tblObject.Status)=0) AND ((tblObject.Burried)=False)) "
    zSQL = zSQL & "ORDER BY tblObject.Location, tblObject.ObjectID;"
    
    'Show all objects in the Area that are not assigned to players and not burried.
    Set rsObject = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
    Do While (Not rsObject.EOF)
        If (MyCLng(rsObject!VisibleLevel) <= lPlayerLevel Or zRaceType = "ELF" Or zClassType = "CY" Or zClassType = "CL" Or zClassType = "PA") Then
        zLineDescData = ""
        lTemperatureType = MyCLng(rsObject!TemperatureType)
        lLocation = MyCLng(rsObject!Location)
        lRottingRounds = MyCLng(rsObject!RottingRounds)
        
        strCompare = MyCStr(rsObject!ObjectName)
        If (MyCInt(rsObject!AllowColourFormat) <> 0) Then 'this is just faster
            strCompare = (strCompare)
        End If
        zColourGlowing = MyCStr(rsObject!ColourGlowing)
        If (Len(zColourGlowing) <> 0) Then zColourGlowing = "&C(" & zColourGlowing & ") "
        zMarkingGlowing = MyCStr(rsObject!MarkingGlowing)
        If (Len(zMarkingGlowing) <> 0) Then zMarkingGlowing = "&B(" & zMarkingGlowing & ") "
        zMarkingHumming = MyCStr(rsObject!MarkingHumming)
        If (Len(zMarkingHumming) <> 0) Then zMarkingHumming = "&W(" & zMarkingHumming & ") "
        zMarkingRune = MyCStr(rsObject!MarkingRune)
        If (Len(zMarkingRune) <> 0) Then zMarkingRune = "&R(" & zMarkingRune & ") "
        zPrefixLineDescData = zColourGlowing & zMarkingGlowing & zMarkingHumming & zMarkingRune
        
        'select colours for certain objects
        zLineDescData = gblzFNWHI  'normal gray colour
        
        If (lRottingRounds <> 0) Then
            zLineDescData = gblzFNYEL  'anything that can rot gets brown colour
        End If
        
        Select Case lLocation
            Case 120
                zLineDescData = gblzFBYEL
            Case 121
                zLineDescData = gblzFBGRE
        End Select
        
        If (MyCLng(rsObject!QuestForGlory) <> 0 Or MyCLng(rsObject!Rare) <> 0) Then
            zLineDescData = gblzFBYEL 'we colour glory items bright yellow
        End If
        
        If (MyCLng(rsObject!MurderPlayerHeart) <> 0) Then
            zLineDescData = gblzFBRED  'anything that can rot gets brown colour
        End If
        
        Select Case MyCLng(rsObject!StargateStatus)
            Case 1
                Select Case (lRandom(50))
                    Case 1
                        zLineDescData = gblzFNCYA
                    Case 2
                        zLineDescData = gblzFBCYA
                    Case 3
                        zLineDescData = gblzFNBLU
                    Case Else
                        zLineDescData = gblzFBBLU
                End Select
            Case 2
                zLineDescData = gblzFNBLA 'we colour glory items bright yellow
        End Select
        
        If (MyCLng(rsObject!ReturnPlayerID) <> 0 And lOPlayerID <> 0) Then
            Select Case MyCLng(rsObject!ReturnPlayerID) = lOPlayerID
                Case True
                    zLineDescData = gblzFBGRE 'players item
                Case False
                    zLineDescData = "&R[" & zReturnPlayerName(MyCLng(rsObject!ReturnPlayerID)) & "] " 'to other players its a zap item
            End Select
        End If
        
        zLineDescData = zLineDescData & zAdverb(strCompare, 2) & strCompare 'We WANT to see the comma part here.
        
        If (lTemperatureType = 0) Then
            Select Case MyCInt(rsObject!LightProvider) 'this is a lamp post or maybe dangling bulbs in a city
                Case 2
                    If (bWhenIsIt("", False)) Then
                        zLineDescData = zLineDescData & "&W (unlit)"
                    Else
                        zLineDescData = zLineDescData & "&y (nightlite)"
                    End If
            End Select
        Else
            Select Case (lTemperatureType)
                Case 1
                    zLineDescData = zLineDescData & "&R (hot)"
                Case 2
                    zLineDescData = zLineDescData & "&c (cold)"
                Case 3
                    zLineDescData = zLineDescData & "&B (magical)"
                Case Else
                    zLineDescData = zLineDescData & "&w (device)"
            End Select
        End If
        
        If (lRottingRounds > 0) Then
            If (lLocation > 0) Then
                zLineDescData = zLineDescData & "&W " & zTranslateRottingContainer(lRottingRounds, 1)
            Else
                zLineDescData = zLineDescData & "&W " & zTranslateRottingContainer(lRottingRounds, 2)
            End If
        End If
        
        lCounter = MyCLng(rsObject!CountOfObjectID)
        
        If (lCounter > 1) Then
            zLineDescData = zLineDescData & " (" & lCounter & ")"
        End If
        
        subSendMsg zPrefixLineDescData & "&c" & zLineDescData, zPortID
        End If
        If (Not rsObject.EOF) Then rsObject.MoveNext
    Loop
    Set rsObject = Nothing
    
    'What Mobs are in area. This is a fast grouping SQL piece of code.
    bSeeTrainableMobs = ((zClassType = "PA") Or (zClassType = "RA") Or (zClassType = "DR") Or (zClassType = "PL"))
    zSQL = "SELECT EquipmentTotal, MoveAllowed, Count(tblMob.MobID) AS CountOfMobID, tblMob.Flys, tblMob.FlyHeight, tblMob.Alignment, tblMob.MobLevel, tblMob.MHPBonus, tblMob.MHP, tblMob.DefeatedMobDesc, tblMob.MobName, tblMob.MobNameNight, tblMob.WeaponName, tblMob.DisarmDuration, tblMob.StunDuration, tblMob.Invisible, tblMob.X, tblMob.Y, tblMob.Z, tblMob.PetClassSpecific, tblMob.PetTrainLevel, tblMob.QuestMaster, tblMob.GuideMaster, tblMob.QuestPlayerID, tblMob.MobColour, tblMob.MobBracketWord, tblMob.BittenMaster, tblMob.BittenMobBracketClass FROM tblMob GROUP BY tblMob.EquipmentTotal, tblMob.MoveAllowed, tblMob.MobBracketWord, tblMob.BittenMaster, tblMob.BittenMobBracketClass, tblMob.Flys "
    zSQL = zSQL & ", tblMob.FlyHeight, tblMob.Alignment, tblMob.MobLevel, tblMob.MHPBonus, tblMob.MHP, tblMob.DefeatedMobDesc, tblMob.MobName, tblMob.MobNameNight, tblMob.WeaponName, tblMob.DisarmDuration, tblMob.StunDuration, tblMob.Invisible, tblMob.X, tblMob.Y, tblMob.Z, tblMob.PetClassSpecific, tblMob.PetTrainLevel, tblMob.QuestMaster, tblMob.GuideMaster, tblMob.QuestPlayerID, tblMob.MobColour, tblMob.MobColour, tblMob.RespawnDelay "
    zSQL = zSQL & "HAVING (((tblMob.X)=" & lngX & ") AND ((tblMob.Y)=" & lngY & ") AND ((tblMob.Z)=" & lngZ & ") AND ((tblMob.RespawnDelay)=0)) ORDER BY tblMob.MobName;"
    bSecurity = False: bGuard = False: bJailer = False: zMobNameJailGuard = ""
    Set rsMob = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
    Do While (Not rsMob.EOF)
        zMobName = MyCStr(rsMob!MobName)
        zMobNameNight = MyCStr(rsMob!MobNameNight)
        lMobNameNightLen = Len(zMobNameNight)
        lEquipmentTotal = MyCLng(rsMob!EquipmentTotal)
        zLineDescData = ""
        bInvisible = (MyCLng(rsMob!Invisible) <> 0 And lDetectInvisibilityDuration = 0)
        If (Not bInvisible) Then
            lMMobLevel = MyCLng(rsMob!MobLevel)
            Select Case (bDay)
                Case True
                    strCompare = zMobName
                Case False
                    If (lMobNameNightLen > 0) Then
                        strCompare = zMobNameNight
                    Else
                        strCompare = zMobName
                    End If
            End Select
            
            If (MyCLng(rsMob!MoveAllowed) <> 0) Then
                zLineDescData = zLineDescData & gblzFBYEL & "[Q] "
            End If
            
            If (lKnowAlignmentDuration <> 0) Then
                If (MyCLng(rsMob!Alignment) <> 0) Then
                    zLineDescData = zLineDescData & "&B[Al" & MyCLng(rsMob!Alignment) & "] "
                End If
            End If
            
            lFlyHeight = MyCLng(rsMob!FlyHeight)
            If (MyCInt(rsMob!Flys) <> 0 Or lFlyHeight > 0) Then
                Select Case (lFlyHeight + lRandom(30))
                    Case -1 To 2
                        zLineDescData = zLineDescData & "&B(landed-flys) "
                    Case 3 To 20
                        zLineDescData = zLineDescData & "&B(floating) "
                    Case 21 To 70
                        zLineDescData = zLineDescData & "&B(hovering) "
                    Case 71 To 150
                        zLineDescData = zLineDescData & "&B(gliding) "
                    Case 151 To 300
                        zLineDescData = zLineDescData & "&B(flying) "
                    Case Else
                        zLineDescData = zLineDescData & "&B(fly" & Format((lFlyHeight + lRandom(30)) / glblCentimetreToFeetConverter, "FIXED") & "feet) " 'the random 30 is to give the appearance of variant flying
                End Select
            End If
            
            If (bSeeTrainableMobs) Then
                If (MyCLng(rsMob!PetTrainLevel) > 0) Then zLineDescData = zLineDescData & "&g(Tr," & rsMob!PetTrainLevel & ") "
            End If
            If (Len(rsMob!PetClassSpecific) > 0) Then zLineDescData = zLineDescData & "&g(Cl," & rsMob!PetClassSpecific & ") "
            
            If (MyCInt(rsMob!BittenMaster) <> 0) Then zLineDescData = zLineDescData & "&r[" & zTranslateClass(MyCStr(rsMob!BittenMobBracketClass)) & "] "
            
            If (Len(zMobNameJailGuard) = 0) Then 'if anyone of the guards in the room IS ABLE  to toss the player into jail that is all we needed to know
                bGuard = (InStr(UCase(strCompare), "GUARD") > 0)
                bSecurity = (InStr(UCase(strCompare), "SECURITY") > 0 Or InStr(UCase(strCompare), "SENTINAL") > 0 Or InStr(UCase(strCompare), "SENTRY") > 0)
                bJailer = (InStr(UCase(strCompare), "JAIL") > 0 Or InStr(UCase(strCompare), "AGENT") > 0 Or InStr(UCase(strCompare), "POLICE") > 0)
                If (bSecurity Or bGuard Or bJailer) Then zMobNameJailGuard = zMobName
            End If
            
            If (MyCLng(rsMob!Invisible) <> 0) Then
                zLineDescData = zLineDescData & "&B(i) "
            End If
            
            bColour = False
            
            If (lOPlayerID <> 0) Then 'some immortal commands use 0 for the player id so we ignore it
                If (MyCLng(rsMob!QuestPlayerID) = lOPlayerID) Then
                    bColour = True
                    zLineDescData = zLineDescData & "&R[QUEST TARGET] "
                Else
                    If (MyCInt(rsMob!QuestMaster)) Then
                        bColour = True
                        zLineDescData = zLineDescData & "&G[QUEST MASTER] "
                    End If
                    If (MyCInt(rsMob!GuideMaster) <> 0) Then
                        bColour = True
                        zLineDescData = zLineDescData & "&c[GUIDE MASTER] "
                    End If
                End If
            End If
            
            If (Len(rsMob!MobBracketWord) > 0) Then zLineDescData = zLineDescData & "&a(" & MyCStr(rsMob!MobBracketWord) & ") "
            
            If (Not bColour) Then
                If (lColourAreaDesc <> 2) Then
                    Select Case MyCLng(rsMob!MobColour)
                        Case 1 'Values: 1blue-2red-3yellow-4green-5white-6cyan-7gray-8purple
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & gblzFBBLU
                                Case 1
                                    zLineDescData = zLineDescData & gblzFNBLU
                            End Select
                        Case 2
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & gblzFBRED
                                Case 1
                                    zLineDescData = zLineDescData & "&r"
                            End Select
                        Case 3
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & gblzFBYEL
                                Case 1
                                    zLineDescData = zLineDescData & "&y"
                            End Select
                        Case 4
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & gblzFBGRE
                                Case 1
                                    zLineDescData = zLineDescData & "&g"
                            End Select
                        Case 5
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & gblzFBWHI
                                Case 1
                                    zLineDescData = zLineDescData & "&w"
                            End Select
                        Case 6
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & "&C"
                                Case 1
                                    zLineDescData = zLineDescData & "&c"
                            End Select
                        Case 7
                            zLineDescData = zLineDescData & "&a"
                        Case Else
                            Select Case lColourAreaDesc
                                Case 0
                                    zLineDescData = zLineDescData & gblzFBMAG
                                Case 1
                                    zLineDescData = zLineDescData & gblzFNMAG
                            End Select
                    End Select
                Else
                    zLineDescData = zLineDescData & "&g"
                End If
            End If
            
            If (MyCLng(rsMob!StunDuration) > 0) Then
                zLineDescData = zLineDescData & zAdverb(strCompare, 1) & zShortstop(strCompare) & ", is stunned"
            Else
                zLineDescData = zLineDescData & zAdverb(strCompare, 1) & strCompare  'Show mob and its description
            End If
            
            lWeaponName = Len(MyCStr(rsMob!WeaponName))
            If (lWeaponName > 0) Then
                If (MyCLng(rsMob!DisarmDuration) = 0) Then
                    Select Case lColourAreaDesc
                        Case 0
                            zLineDescData = zLineDescData & gblzFBRED
                        Case 1
                            zLineDescData = zLineDescData & "&r"
                        Case 2
                            zLineDescData = zLineDescData & "&g"
                    End Select
                    zLineDescData = zLineDescData & " wields " & MyCStr(rsMob!WeaponName) 'this does the/an/a but i removed this: zAdverb(MyCStr(rsMob!WeaponName), 99) &
                Else
                    Select Case lColourAreaDesc
                        Case 0
                            zLineDescData = zLineDescData & gblzFBGRE
                        Case 1
                            zLineDescData = zLineDescData & "&g"
                        Case 2
                            zLineDescData = zLineDescData & "&g"
                    End Select
                    zLineDescData = zLineDescData & " is trying to rearm " & zAdverb(MyCStr(rsMob!WeaponName), 3) & MyCStr(rsMob!WeaponName)
                End If
            End If
                    
            If (lEquipmentTotal > 0) Then zLineDescData = zLineDescData & " &Y{" & MyCStr(lEquipmentTotal) & "} "

            lMHPBonus = MyCLng(rsMob!MHPBonus)
            lMHP = MyCLng(rsMob!MHP) + lMHPBonus
            lMobMaxHP = (lMMobLevel * cstMobHPRespawn) + lMHPBonus
            lCalcuMobHPPercent = MyCLng((lMHP * 100) / lMobMaxHP)
            If (lCalcuMobHPPercent < 1) Then
                zLineDescData = zLineDescData & " &R[DYING]" '0% is DYING nearly dead
            Else
                If (lCalcuMobHPPercent < 100) Then
                    zLineDescData = zLineDescData & " &R[" & lCalcuMobHPPercent & "%]" '0% is DYING nearly dead
                End If
            End If
            
            lDefeatedMobDesc = Len(MyCStr(rsMob!DefeatedMobDesc))
            If (lDefeatedMobDesc > 0) Then
                zLineDescData = zLineDescData & vbCrLf & gblzFNMAG & "       " & MyCStr(rsMob!DefeatedMobDesc)
            End If
            
            lCounter = MyCLng(rsMob!CountOfMobID)
            
            If (lCounter > 1) Then
                zLineDescData = zLineDescData & " (" & lCounter & ")"
            End If
            
            subSendMsg "&M" & zLineDescData, zPortID
        End If
        If (Not rsMob.EOF) Then rsMob.MoveNext
    Loop
    Set rsMob = Nothing
    If (Len(zMobNameJailGuard) > 0) And (bSecurity Or bGuard Or bJailer) Then subPlayerGoesToJailDoNotPassGo lOPlayerID, zMobNameJailGuard
    Exit Function
Err_Check:
    subWriteErrorFile "strShowMobsAndObjects," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function iAreaEventZone(lAreaEventZoneID As Long, lPlayerID As Long, zPortID As String) As Integer
On Error GoTo Err_Check '0 = green safe 1 = yellow safe 2 = red and no move into spot, 3=red instant death, 4=white safe, also add random dmg to any of these
    Dim rsEDArea As Recordset
    Dim iReturn As Integer
    Dim lDamage As Long
    Dim zEventDescription As String
    Dim zChanceforRandomDamageDesc As String
    Dim lChanceforRandomDamageValue As Long
    Dim lMobID As Long
    Dim lAliveMobID As Long
    Dim bContinue As Boolean
    
    iReturn = 1 'Alias you cannot go that way <--- repeated I know so what :) Initilizaion rocks!
    If (lAreaEventZoneID <> 0) Then
    'subSendMsg "&GTEST: zEventDescription", zPortID
    Set rsEDArea = MyDB.OpenRecordset("SELECT * FROM tblAreaEventZone WHERE (AreaEventZoneID=" & lAreaEventZoneID & ");", dbOpenSnapshot) 'Destination place
    If (Not rsEDArea.EOF) Then
        lAliveMobID = MyCLng(rsEDArea!AliveMobID)
        bContinue = (lAliveMobID = 0) 'Continue if the mob is alive or dead...
        If (lAliveMobID <> 0) Then bContinue = (bMobAlive(lAliveMobID)) 'Continue only if the mob is alive and being alive is required!
        If (bContinue) Then  'If no mob is required or the mob is alive to trigger the trap on the player then continue...
            iReturn = MyCLng(rsEDArea!Colour)
            lMobID = MyCLng(rsEDArea!MobID)
            If (lMobID <> 0) Then 'If This is a value other than 0 that means the mob is now after the player, until (midnight and lrandom(20) < 3)
                MyDB.Execute "UPDATE tblMob SET PlayerID=" & lPlayerID & " WHERE (MobID=" & lMobID & " AND RespawnDelay<>0);", dbFailOnError
            End If
            lChanceforRandomDamageValue = MyCLng(rsEDArea!ChanceforRandomDamageValue)
            If (lChanceforRandomDamageValue > 0 And lRandom(lChanceforRandomDamageValue) = 1) Then
                zChanceforRandomDamageDesc = MyCStr(rsEDArea!ChanceforRandomDamageDesc)
                zChanceforRandomDamageDesc = strReplaceWordWithThisWord(zChanceforRandomDamageDesc, "*", vbCrLf)
                lDamage = lRandom(MyCLng(rsEDArea!ChanceforRandomDamageHP))
                subSendMsg "&r" & zChanceforRandomDamageDesc, zPortID
                MyDB.Execute "UPDATE tblPlayer SET tblPlayer.CHP = CHP-" & lDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                subSendMsg "&RBLOOD!!! You took " & lDamage & " damage.", zPortID
                Select Case (iPlayerHitPointTest(zPortID, False))
                    Case 1
                        iReturn = 11
                    Case Else
                        iReturn = 12
                End Select
            Else
                zEventDescription = MyCStr(rsEDArea!EventDescription)
                Select Case (iReturn)
                    Case 0 'green or 0 and allows movement
                        subSendMsg "&G" & (zEventDescription), zPortID
                    Case 1 'yellow same as 0
                        subSendMsg "&Y" & (zEventDescription), zPortID
                    Case 2 'red but cannot move to spot nothing else happens
                        subSendMsg "&R" & (zEventDescription), zPortID
                    Case 3 'player auto dies
                        subSendMsg "&R" & (zEventDescription), zPortID
                        Select Case (iPlayerHitPointTest(zPortID, True)) 'instant death
                            Case 1
                                iReturn = 13
                            Case Else
                                iReturn = 14
                        End Select
                    Case 4 'white same as 0 safe spot
                        subSendMsg "&W" & (zEventDescription), zPortID
                End Select
            End If
        End If 'Mob is not alive to trigger the trap so we ignore this
    End If
    Set rsEDArea = Nothing
    End If
    iAreaEventZone = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iAreaEventZone," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function iPlayerHitPointTest(zPortID As String, bInstantDeath As Boolean) As Integer
'See Also: subCombatPlayerDiedReset
On Error GoTo Err_Check
    Dim iReturn As Integer
    Dim rsPlayer As Recordset
    Dim zOPlayerName As String
    Dim lOPlayerID As Long
    Dim lFPlayerID As Long
    
    iReturn = 1
    Set rsPlayer = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenDynaset) 'Destination place
    If (Not rsPlayer.EOF) Then
        If (MyCLng(rsPlayer!CHP) < 1 Or bInstantDeath) Then
            'player died
            subSendMsg "&RYou died!" & vbCrLf & "&RYou arrive somewhere else!", zPortID
            subSendMsgAreaExcept2 "&R" & MyCStr(rsPlayer!PlayerName) & " died!", MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z), zPortID, ""
            rsPlayer.Edit
            rsPlayer!XP = MyCLng(rsPlayer!XP) - (50 * MyCLng(rsPlayer!PlayerLevel))
            If (rsPlayer!XP < 0) Then rsPlayer!XP = 0
            rsPlayer!CHP = 1 'punishment is low hitpoints - you have to sleep now.
            rsPlayer!Status = 5
            rsPlayer!AreaTrapID = 0
            rsPlayer!AreaTrapDuration = 0
            rsPlayer!RecallX = 0
            rsPlayer!RecallY = 0
            rsPlayer!RecallZ = -2
            rsPlayer!x = 0
            rsPlayer!y = 0
            rsPlayer!z = -2
            'we sent the durations on the player
            rsPlayer!InvisibilityDuration = 0
            rsPlayer!HideDuration = 0
            rsPlayer!CamoflaguedDuration = 0
            rsPlayer!FireshieldDuration = 0
            rsPlayer!IceshieldDuration = 0
            rsPlayer!SanctuaryDuration = 0
            rsPlayer!BarkskinDuration = 0
            rsPlayer!StoneskinDuration = 0
            rsPlayer!DragonskinDuration = 0
            rsPlayer!DemonskinDuration = 0
            rsPlayer!StunDuration = 0
            rsPlayer!BlindDuration = 0
            rsPlayer!NegateDuration = lcstNegateDuration
            DoEvents
            rsPlayer.Update
            subSendMsgAreaAll "&BYou see &Wlightning &Yflash &Ba moment in the &Wclouds &Babove you but there is no sound!", 0, 0, 0 'We hard code the sound as someone arriving from death. This also tells immortals where playes die and arrive at.
            subClearPortTotalXP MyCLng(zPortID)
            zOPlayerName = MyCStr(rsPlayer!PlayerName)
            lOPlayerID = MyCLng(rsPlayer!PlayerID)
            lFPlayerID = MyCLng(rsPlayer!FPlayerID)
            subFollowSelf zOPlayerName, lOPlayerID, lFPlayerID, False, zPortID
            iReturn = 2
        End If
    End If
    Set rsPlayer = Nothing
    iPlayerHitPointTest = iReturn
    Exit Function
Err_Check:
    subWriteErrorFile "iPlayerHitPointTest," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function zReturnTrapName(lAreaTrapID As Long) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    zReturn = ""
    Set rsData = MyDB.OpenRecordset("SELECT AreaTrapName FROM tblAreaTrap WHERE (AreaTrapID=" & lAreaTrapID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!AreaTrapName)
    End If
    Set rsData = Nothing
    zReturnTrapName = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnTrapName," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subRemovePlayerPetsThatCannotFly(lPlayerID As Long)
On Error GoTo Err_Check
    Dim lMobID As Long
    Dim rsMomentum As Recordset
    Set rsMomentum = MyDB.OpenRecordset("SELECT tblPlayerPet.MobID FROM tblPlayerPet INNER JOIN tblMob ON tblPlayerPet.MobID = tblMob.MobID WHERE (((tblMob.Flys)=False) AND ((tblPlayerPet.PlayerID)=" & lPlayerID & "));", dbOpenSnapshot)
    Do While (Not rsMomentum.EOF)
        lMobID = MyCLng(rsMomentum!MobID)
        MyDB.Execute "DELETE PlayerPetID FROM tblPlayerPet WHERE (PlayerID=" & lPlayerID & " AND MobID=" & lMobID & ");", dbFailOnError
        rsMomentum.MoveNext
    Loop
    Set rsMomentum = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subRemovePlayerPetsThatCannotFly," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zPlayerMountedMsg(lPlayerID As Long) As String 'When this has a value the PlayerIsOnAMount IsPlayerOnAMount PlayerMount (<< ez searching criteria)
On Error GoTo Err_Check
    Dim rsMomentum As Recordset
    Dim zReturn As String
    zReturn = ""
    Set rsMomentum = MyDB.OpenRecordset("SELECT PetMountMsg FROM tblPlayerPet WHERE (Mountable<>0 AND PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsMomentum.EOF) Then
        zReturn = MyCStr(rsMomentum!PetMountMsg)
        If (Len(zReturn) = 0) Then zReturn = "Travels" 'this is the default when Mounted for all mountable pets
    End If
    Set rsMomentum = Nothing
    zPlayerMountedMsg = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zPlayerMountedMsg," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function lPlayerMountedType(lPlayerID As Long) As Long
On Error GoTo Err_Check
    Dim rsMomentum As Recordset
    Dim lReturn As Long
    lReturn = 0
    Set rsMomentum = MyDB.OpenRecordset("SELECT MountableType FROM tblPlayerPet WHERE (Mountable=True AND PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsMomentum.EOF) Then
        lReturn = MyCLng(rsMomentum!MountableType) '0 no mount, 1=ground mount 2=flying mount etc...
    End If
    Set rsMomentum = Nothing
    lPlayerMountedType = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lPlayerMountedType," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bPlayerMountedOnFlyingPet(lPlayerID As Long) As Boolean
On Error GoTo Err_Check
    Dim rsMomentum As Recordset
    Dim bReturn As Boolean
    Set rsMomentum = MyDB.OpenRecordset("SELECT MountableType FROM tblPlayerPet WHERE ((Flys=True OR MountableType=2) AND (Mountable=True AND PlayerID=" & lPlayerID & "));", dbOpenSnapshot)
    bReturn = (Not rsMomentum.EOF)
    Set rsMomentum = Nothing
    bPlayerMountedOnFlyingPet = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPlayerMountedOnFlyingPet," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function lAreaTrapIDType(lAreaTrapID As Long) As Long
On Error GoTo Err_Check
    Dim rsTrapType As Recordset
    Dim lReturn As Long
    If (lAreaTrapID <> 0) Then
        Set rsTrapType = MyDB.OpenRecordset("SELECT TrapType FROM tblAreaTrap WHERE (AreaTrapID=" & lAreaTrapID & ");", dbOpenSnapshot)
        If (Not rsTrapType.EOF) Then
            lReturn = MyCLng(rsTrapType!TrapType)
        End If
        Set rsTrapType = Nothing
    Else
        lReturn = 0
    End If
    lAreaTrapIDType = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lAreaTrapIDType," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function lAreaTrapIDTypeDuration(lAreaTrapID As Long) As Long
On Error GoTo Err_Check
    Dim rsTrapType As Recordset
    Dim lReturn As Long
    If (lAreaTrapID <> 0) Then
        Set rsTrapType = MyDB.OpenRecordset("SELECT TrapTypeDuration FROM tblAreaTrap WHERE (AreaTrapID=" & lAreaTrapID & ");", dbOpenSnapshot)
        If (Not rsTrapType.EOF) Then
            lReturn = MyCLng(rsTrapType!TrapTypeDuration)
            If (lReturn < 2) Then lReturn = 2
        End If
        Set rsTrapType = Nothing
    Else
        lReturn = 0
    End If
    lAreaTrapIDTypeDuration = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lAreaTrapIDTypeDuration," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bMobIDAliveAreaTrapID(lAreaTrapID As Long) As Boolean
On Error GoTo Err_Check 'True means dead mob the trap is disarmed
    Dim rsMobAlive As Recordset
    Dim bReturn As Long
    If (lAreaTrapID <> 0) Then
        Set rsMobAlive = MyDB.OpenRecordset("SELECT tblAreaTrap.AreaTrapID, tblMob.RespawnDelay FROM tblAreaTrap INNER JOIN tblMob ON tblAreaTrap.AliveMobID = tblMob.MobID WHERE (((tblAreaTrap.AreaTrapID)=" & lAreaTrapID & ") AND ((tblMob.RespawnDelay)<>0));", dbOpenSnapshot)
        bReturn = (rsMobAlive.EOF)
        Set rsMobAlive = Nothing
    Else
        bReturn = True
    End If
    bMobIDAliveAreaTrapID = bReturn
    'checks to see if the mobid is alive or 0 both cases run this
    Exit Function
Err_Check:
    subWriteErrorFile "bMobIDAliveAreaTrapID," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bMobIDAliveAreaEventZoneID(lAreaEventZoneID As Long) As Boolean
On Error GoTo Err_Check
    Dim rsMobAlive As Recordset
    Dim bReturn As Long
    If (lAreaEventZoneID <> 0) Then
        Set rsMobAlive = MyDB.OpenRecordset("SELECT tblAreaEventZone.AreaEventZoneID, tblMob.RespawnDelay FROM tblAreaEventZone INNER JOIN tblMob ON tblAreaEventZone.AliveMobID = tblMob.MobID WHERE (((tblAreaEventZone.AreaEventZoneID)=" & lAreaEventZoneID & ") AND ((tblMob.RespawnDelay)<>0));", dbOpenSnapshot)
        bReturn = (rsMobAlive.EOF)
        Set rsMobAlive = Nothing
    Else
        bReturn = True
    End If
    bMobIDAliveAreaEventZoneID = bReturn
    'checks to see if the mobid is alive or 0 both cases run this
    Exit Function
Err_Check:
    subWriteErrorFile "bMobIDAliveAreaEventZoneID," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subCheckFishingSittingStatus(zPortID As String)
On Error GoTo Err_Check
'    Dim lPortID As Long
'    lPortID = MyCLng(zPortID)
'    If (gbllFishing(lPortID) = 0) Then
' how to use...
'    Else
'        subSendMsg "&gBut wait, you are fishing. Stand or move away first.", zPortID
'    End If
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lStatus As Long
    Dim lPortID As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, PlayerName, X, Y, Z, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then 'Login player name found
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lStatus = MyCLng(rsPlayer!Status)
        lOX = MyCLng(rsPlayer!x)
        lOY = MyCLng(rsPlayer!y)
        lOZ = MyCLng(rsPlayer!z)
    End If
    Set rsPlayer = Nothing
    
    lPortID = MyCLng(zPortID)
    If (gbllFishing(lPortID) <> 0) Then
        gbllFishing(lPortID) = 0
        'subSendMsg "&gYou stop fishing.", zPortID
        'subSendMsgAreaExcept2 gblzFNGRE & zPlayerName & " stops fishing.", lOX, lOY, lOZ, zPortID, ""
        subSendMsgAreaAllDISmart "&g", zPlayerName, "%s1 stopped fishing.", "", "%s1 enjoys %g12 time off from fishing for now.", lOX, lOY, lOZ
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCheckFishingSittingStatus," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bMobAlive(lMobID As Long) As Boolean
    Dim rsMob As Recordset
    Dim bReturn As Boolean
    bReturn = False
    Set rsMob = MyDB.OpenRecordset("SELECT RespawnDelay FROM tblMob WHERE (MobID= " & lMobID & ");", dbOpenDynaset)
    If (Not rsMob.EOF) Then
        bReturn = (MyCLng(rsMob!RespawnDelay) = 0)
    End If
    Set rsMob = Nothing
    bMobAlive = bReturn
End Function
Public Function zMobAlive(lMobID As Long) As String
    Dim rsMob As Recordset
    Dim zReturn As String
    zReturn = False
    Set rsMob = MyDB.OpenRecordset("SELECT MobName FROM tblMob WHERE (MobID= " & lMobID & ");", dbOpenDynaset)
    If (Not rsMob.EOF) Then
        zReturn = MyCStr(rsMob!MobName)
    End If
    Set rsMob = Nothing
    zMobAlive = zReturn
End Function
Public Function iMomentumEngineXYZ(zDir As String, bTryingToFlee As Boolean, bStatusBM As Boolean, bStatusGUID As Boolean, zPortID As String) As Integer
On Error GoTo Err_Check
    Dim lCCHA As Long
    Dim strSQL As String
    Dim bNormal As Boolean 'This is immersive
    Dim bCyborgPassed As Boolean 'Cyborg Morph needs to VENT command now and then
    Dim lRewardTEMP1  As Long
    Dim lRewardTEMP2  As Long
    Dim lRewardTEMP3  As Long
    Dim zMoveLogo As String
    Dim bMoveLogo As Boolean
    Dim rsFollow As Recordset
    Dim lFollowCMove As Long
    Dim lAreaEventZoneID As Long
    Dim lDAreaDamageToArea As Long
    Dim lMobHollarType As Long
    Dim rsCArea As Recordset 'Current Area
    Dim rsDArea As Recordset 'Destination Area
    Dim rsDDoor As Recordset 'Destination Door
    Dim rsMomentum As Recordset
    Dim iReturn As Integer '0 means the player can move, 1= alas cannot move that way, 2=door is locked.
    Dim intDirectionCell As Integer
    Dim strBlockedExits As String
    Dim lPlayerID As Long
    Dim lInvisibilityDuration As Long
    Dim lShadowCloakDuration As Long
    Dim lColorAreaDesc As Long
    Dim lMomentumCDEX As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lDetectInvisibilityDuration As Long
    Dim zPlayerConfig As String
    Dim lPFactionID As Long 'creates the flu
    Dim lDAreaFactionID As Long 'creates the flu
    Dim lngX As Long
    Dim lngY As Long
    Dim lngZ As Long
    Dim lTZ As Long
    Dim zSQL As String
    Dim lHallucinate As Long
    Dim lImmortalLevel As Long
    Dim bDoorLocked As Boolean
    Dim bOkay As Boolean
    Dim bFlyAreaOkay As Boolean
    Dim iClanOnlyMovement As Integer
    Dim bNoProblemToFollow As Boolean 'When people in the group follow - there are certain areas they will not follow into - like traps and clan halls
    Dim bDAreaXYZ As Boolean
    Dim zPetMountMsg As String
    Dim zExtraMovement As String
    Dim lDAreaX As Long
    Dim lDAreaY As Long
    Dim lDAreaZ As Long
    Dim lUnderwater As Long
    Dim bFlyDuration As Boolean
    Dim zDAreaRules As String
    Dim lAreaRolePlayID As Long
    Dim lFPlayerGroupStatus As Long
    Dim lAreaRolePlayLevel As Long
    Dim lDAreaWhereID As Long
    Dim lDAreaThiefChestOfGlory As Long
    Dim lDAreaThiefMobID As Long
    Dim lDAreaDXYZActive As Long
    Dim lDUnderwaterDuration As Long 'area fills with water
    Dim lDUnderwaterOriginal As Long 'area fills with water
    Dim lPAreaTrapDuration As Long
    Dim lDAreaTrapID As Long
    Dim lDAreaAreaTrapChance As Long
    Dim lDAreaAreaTrapDuration As Long
    Dim zDAreaObjectNameRequiredToPass As String
    Dim zDAreaObjectNameRequiredCanPassEmote As String
    Dim zDAreaObjectNameRequiredCantPassEmote As String
    Dim lMomentumClanID As Long
    Dim lMomentumClanMemberLevel As Long
    Dim lDAreaAreaID As Long
    Dim lDAreaClanMemberLevel As Long
    Dim lDAreaClanID As Long
    Dim lDAreaMorphType As Long
    Dim lMomentumHeight As Long
    Dim lHideDuration As Long
    Dim lCamoflaguedDuration As Long
    Dim lDAreaHeightRequirement As Long
    Dim lDAreaFlyLevel As Long
    Dim lMomentumPlayerLevel As Long
    Dim zMomentumPlayerName As String
    Dim bFPlayerGroupStatus As Boolean
    Dim lMomentumX As Long
    Dim lMomentumY As Long
    Dim lMomentumZ As Long
    Dim lDAreaDX As Long
    Dim lDAreaDY As Long
    Dim lDAreaDZ As Long
    Dim lDDoorStatus As Long
    Dim lMomentumCMove As Long
    Dim lDAreaMoveCost As Long
    Dim bDDoorEOF As Boolean
    Dim bDAreaEOF As Boolean
    Dim bCAreaEOF As Boolean
    Dim lMomentumSneakingMovesLeft As Long
    Dim lPDrunkDuration As Long
    Dim lPEntanglementDuration As Long
    Dim lPCHP As Long
    Dim lOCHP As Long
    Dim lPCSTR As Long
    Dim lPortID As Long
    Dim lPWeight As Long
    Dim zRaceType As String
    Dim zClassType As String
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim lSleepDuration As Long
    Dim lPlayerFleeDuration As Long
    Dim lStatus As Long
    Dim zFlee As String
    Dim bAreaEventZone As Boolean 'areatrap event zone
    Dim iGetAreaEventZone As Integer
    Dim lMountedType As Long
    Dim bGroundMounted As Boolean
    Dim bAirMounted As Boolean
    Dim bSneakMounted As Boolean
    Dim lTurnedIntoAnimalType As Long
    Dim bDiceRoll As Long
    'Dim lMainGroup As Long 'subPrintAnAsciiPicture(bAwardGlory As Boolean, zWord2 As String, zPortID As String)
    Dim lDMainGroup As Long
    'Dim bAlasCannotGoThatWay As Boolean
    
    subCheckFishingSittingStatus zPortID 'gbllFishing(MyCLng(zPortID)) = 0
    
    'bAlasCannotGoThatWay = False
    bNoProblemToFollow = True
    bOkay = False
    lngX = 0
    lngY = 0
    lngZ = 0
    lTZ = 0
    
    If (bTryingToFlee) Then
        zFlee = "[Panic] "
    Else
        zFlee = ""
    End If
    
    Select Case UCase(zDir) 'See also: subDirectionControl
        Case "NORTH", "N"
            lngY = -1
            intDirectionCell = 1
            bOkay = True
        Case "SOUTH", "S"
            lngY = 1
            intDirectionCell = 2
            bOkay = True
        Case "EAST", "E"
            lngX = 1
            intDirectionCell = 3
            bOkay = True
        Case "WEST", "W"
            lngX = -1
            intDirectionCell = 4
            bOkay = True
        Case "NORTHEAST", "NE"
            lngX = 1
            lngY = -1
            intDirectionCell = 5
            bOkay = True
        Case "NORTHWEST", "NW"
            lngX = -1
            lngY = -1
            intDirectionCell = 6
            bOkay = True
        Case "SOUTHEAST", "SE"
            lngX = 1
            lngY = 1
            intDirectionCell = 7
            bOkay = True
        Case "SOUTHWEST", "SW"
            lngX = -1
            lngY = 1
            intDirectionCell = 8
            bOkay = True
        Case "ABOVE", "U" 'We move up and down by two because we want a level space for emergiences to go up or down with a door
            lngZ = -2
            lTZ = -1
            intDirectionCell = 9
            bOkay = True
        Case "BELOW", "D"
            lngZ = 2
            lTZ = 1
            intDirectionCell = 10
            bOkay = True
    End Select
    
    bDAreaXYZ = False
    
    If (bOkay) Then
        lPortID = MyCLng(zPortID)
        
        strSQL = "SELECT CCHA, FactionedWith, CDEX, HideDuration, CamoflaguedDuration, TurnedIntoAnimalType, FPlayerGroupStatus, ClanMemberLevel, BlindDuration, StunDuration, SleepDuration, PlayerFleeDuration, CStr, Config, Weight, Race, Class, CHP, OHP, DetectInvisibilityDuration, ImmortalLevel, ColorAreaDesc, Hallucinate, DrunkDuration, EntanglementDuration, RolePlayID, RolePlayLevel, AreaTrapID, AreaTrapDuration, SneakingMovesLeft, Height, ClanID, FlyDuration, InvisibilityDuration, CMove, PlayerID, PlayerLevel, Status, FlyDuration, PlayerName, X, Y, Z, FlyExitMsg, WalkExitMsg, FlyEnterMsg, WalkEnterMsg, WhereID, ShadowCloakDuration FROM tblPlayer WHERE (PortID='" & zPortID & "');"
        
        bDoorLocked = False
        iReturn = 0 'We use the proc's internal error system
        lUnderwater = 0
        lAreaRolePlayID = 0
        lAreaRolePlayLevel = 0
        
'        iResultMomentumEngineXYZ = (iMomentumEngineXYZ(lPHallucinate, zPortID, "P", lPlayerID, lDetectInvisibilityDuration, UCase(zKeepLettersOnly(zWord(1))), lImmortalLevel, (lFPlayerGroupStatus <> 0), lColorAreaDesc, zClass, zRace, zConfig))
'        subMessagesMovementResult iResultMomentumEngineXYZ, zPortID
        
        Set rsMomentum = MyDB.OpenRecordset(strSQL, dbOpenSnapshot)
        If (Not rsMomentum.EOF) Then
            lCCHA = MyCLng(rsMomentum!CCHA)
            lPFactionID = MyCLng(rsMomentum!FactionedWith)
            lBlindDuration = MyCLng(rsMomentum!BlindDuration)
            If (lBlindDuration = 0) Then
                lStunDuration = MyCLng(rsMomentum!StunDuration)
                If (lStunDuration = 0) Then
                    lSleepDuration = MyCLng(rsMomentum!SleepDuration)
                    If (lSleepDuration = 0) Then
                        lPlayerFleeDuration = MyCLng(rsMomentum!PlayerFleeDuration)
                        'If (lPlayerFleeDuration = 0) Then
                            lPDrunkDuration = MyCLng(rsMomentum!DrunkDuration)
                            If (lPDrunkDuration > 0) Then
                                Select Case lRandom(4)
                                    Case 1
                                        If (lPDrunkDuration > 99) Then
                                            subSendMsg "&CWhy move?! &G[&c" & lPDrunkDuration & "&G] is over 100 rounds of more fun and more drinking it up!", zPortID
                                        Else
                                            subSendMsg "&G[&c" & lPDrunkDuration & "&G] &cIf you move you are going to be &gsick&c all over the place!", zPortID
                                        End If
                                    Case 2
                                        subSendMsg "*hic* &G[&c" & lPDrunkDuration & "&G]", zPortID
                                End Select
                            End If
                            If (lPDrunkDuration < 100) Then
                                lPEntanglementDuration = MyCLng(rsMomentum!EntanglementDuration)
                                If (lPEntanglementDuration = 0) Then
                                    lPCHP = MyCLng(rsMomentum!CHP)
                                    lOCHP = MyCLng(rsMomentum!OHP)
                                    If (lPCHP > 10) Then
                                        If (rSCombat(lPortID).iStatus = cstiStatusNotInBattleMode Or bTryingToFlee) Then
                                                lPCSTR = MyCLng(rsMomentum!CStr)
                                                lPWeight = MyCLng(rsMomentum!Weight)
                                            If (lPCSTR * gbllPlayerWeightMultiplierInGrams > lPWeight) Then
                                                lPAreaTrapDuration = MyCLng(rsMomentum!AreaTrapDuration)
                                                If (lPAreaTrapDuration = 0) Then
                                                    'everything passed testing we continue on
                                                    lPlayerID = MyCLng(rsMomentum!PlayerID)
                                                    lCamoflaguedDuration = MyCLng(rsMomentum!CamoflaguedDuration)
                                                    lHideDuration = MyCLng(rsMomentum!HideDuration)
                                                    lTurnedIntoAnimalType = MyCLng(rsMomentum!TurnedIntoAnimalType)
                                                    lInvisibilityDuration = MyCLng(rsMomentum!InvisibilityDuration)
                                                    lShadowCloakDuration = MyCLng(rsMomentum!ShadowCloakDuration)
                                                    lStatus = MyCLng(rsMomentum!Status)
                                                    lImmortalLevel = MyCLng(rsMomentum!ImmortalLevel)
                                                    zRaceType = MyCStr(rsMomentum!Race)
                                                    zClassType = MyCStr(rsMomentum!Class)
                                                    lFPlayerGroupStatus = MyCLng(rsMomentum!FPlayerGroupStatus)
                                                    bFPlayerGroupStatus = (lFPlayerGroupStatus <> 0)
                                                    lHallucinate = MyCLng(rsMomentum!Hallucinate)
                                                    lDetectInvisibilityDuration = MyCLng(rsMomentum!DetectInvisibilityDuration)
                                                    lColorAreaDesc = MyCLng(rsMomentum!ColorAreaDesc)
                                                    zPlayerConfig = MyCStr(rsMomentum!Config)
                                                    
                                                    'Main
                                                    lMomentumPlayerLevel = MyCLng(rsMomentum!PlayerLevel)
                                                    lMomentumClanID = MyCLng(rsMomentum!ClanID)
                                                    lMomentumClanMemberLevel = MyCLng(rsMomentum!ClanMemberLevel)
                                                    lMomentumHeight = MyCLng(rsMomentum!Height)
                                                    lMomentumCDEX = MyCLng(rsMomentum!CDEX)
                                                    lMomentumX = MyCLng(rsMomentum!x)
                                                    lMomentumY = MyCLng(rsMomentum!y)
                                                    lMomentumZ = MyCLng(rsMomentum!z)
                                                    lMomentumCMove = MyCLng(rsMomentum!CMove)
                                                    
                                                    lMomentumSneakingMovesLeft = MyCLng(rsMomentum!SneakingMovesLeft)
                                                    zMomentumPlayerName = MyCStr(rsMomentum!PlayerName)
                                                    
                                                    zPetMountMsg = zPlayerMountedMsg(lPlayerID)
                                                    If (Len(zPetMountMsg) <> 0) Then 'player is on a mount
                                                        zExtraMovement = zPetMountMsg
                                                        lMountedType = lPlayerMountedType(lPlayerID)
                                                        bGroundMounted = (lMountedType = 1)
                                                        bAirMounted = bPlayerMountedOnFlyingPet(lPlayerID)
                                                        bSneakMounted = (lMountedType = 6)
                                                    End If
                                                    bFlyDuration = (lTurnedIntoAnimalType = 5 Or bAirMounted Or zRaceType = "PIX" Or zClassType = "VA" Or MyCLng(rsMomentum!FlyDuration) <> 0)
                                                    
                                                    iReturn = 1 'Alas, cannot go that way. Default message.
                                                    
                                                    If (lBlindDuration = 0) Then
                                                        If (lStatus <= 5) Then
                                                            bCyborgPassed = True
                                                            If (zClassType = "CY") Then 'these require VENT command now and then to run
                                                                If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then 'lPortID = MyCLng(zPortID)
                                                                    bCyborgPassed = (gbllAngryVentingSystem(lPortID) < 100)
                                                                End If
                                                            End If
                                                            If (bCyborgPassed Or zClassType <> "CY") Then
                                                            If (zClassType = "CY") Then
                                                                If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                                                                    gbllAngryVentingSystem(lPortID) = gbllAngryVentingSystem(lPortID) + 1
                                                                End If
                                                            End If
                                                            Set rsCArea = MyDB.OpenRecordset("SELECT MainGroup, RolePlayID, RolePlayLevel, GravityLevel, Underwater, BlockedExits, HiddenExits, X,Y,Z FROM tblArea WHERE (X=" & lMomentumX & " AND Y=" & lMomentumY & " AND Z=" & lMomentumZ & ");", dbOpenSnapshot) 'Get the area information
                                                            bCAreaEOF = (rsCArea.EOF)
                                                            If (Not bCAreaEOF) Then
                                                                'lMainGroup = MyCLng(rsCArea!MainGroup)
                                                                strBlockedExits = strForceSize(MyCStr(rsCArea!BlockedExits), 10, "0", "A") 'checking for blocked exists is a must first
                                                                If (Mid(strBlockedExits, intDirectionCell, 1) = "0") Then 'A viable direction exists
                                                                    Set rsDDoor = MyDB.OpenRecordset("SELECT X,Y,Z,Status FROM tblDoor WHERE (X=" & lMomentumX + lngX & " AND Y=" & lMomentumY + lngY & " AND Z=" & lMomentumZ + lTZ & ");", dbOpenSnapshot) 'Get the door information - Must check for door first! Destination place
                                                                    bDDoorEOF = (rsDDoor.EOF)
                                                                    If (Not bDDoorEOF) Then 'If there is a door we must know where to get teh area description next
                                                                        lDDoorStatus = MyCInt(rsDDoor!Status)
                                                                        zSQL = "SELECT FactionID, MainGroup, MobHollarType, UnderwaterDuration, DamageToArea, AreaID, ThiefMobID, ThiefChestOfGlory, MorphType, AreaRules, ClanMemberLevel, AreaTrapDuration, AreaTrapChance, AreaTrapID, ObjectNameRequiredToPass, ObjectNameRequiredCantPassEmote, ObjectNameRequiredCanPassEmote, HeightRequirement, ClanID, FlyLevel, MoveCost, X,Y,Z, DXYZActive,DX,DY,DZ, WhereID, AreaEventZoneID FROM tblArea WHERE (X=" & lMomentumX + (lngX * 2) & " AND Y=" & lMomentumY + (lngY * 2) & " AND Z=" & lMomentumZ + lngZ & ");"
                                                                    Else 'If there is a door we look ahead.
                                                                        lDDoorStatus = 0
                                                                        zSQL = "SELECT FactionID, MainGroup, MobHollarType, UnderwaterDuration, DamageToArea, AreaID, ThiefMobID, ThiefChestOfGlory, MorphType, AreaRules, ClanMemberLevel, AreaTrapDuration, AreaTrapChance, AreaTrapID, ObjectNameRequiredToPass, ObjectNameRequiredCantPassEmote, ObjectNameRequiredCanPassEmote, HeightRequirement, ClanID, FlyLevel, MoveCost, X,Y,Z, DXYZActive,DX,DY,DZ, WhereID, AreaEventZoneID FROM tblArea WHERE (X=" & lMomentumX + lngX & " AND Y=" & lMomentumY + lngY & " AND Z=" & lMomentumZ + lngZ & ");"
                                                                    End If
                                                                    
                                                                    Set rsDArea = MyDB.OpenRecordset(zSQL, dbOpenSnapshot) 'Destination place
                                                                    bDAreaEOF = (rsDArea.EOF)
                                                                    
                                                                    If (Not bDAreaEOF) Then 'Checking the area behind the doors aswell
                                                                        lDAreaFactionID = MyCLng(rsDArea!FactionID)
                                                                        lDMainGroup = MyCLng(rsDArea!MainGroup)
                                                                        lMobHollarType = MyCLng(rsDArea!MobHollarType)
                                                                        If (lMobHollarType > 5) Then lMobHollarType = 5
                                                                        lDAreaAreaID = rsDArea!AreaID
                                                                        If (lPortID > 1) Then
                                                                        If (gbllQuestGuardAreaID(lPortID) <> 0) Then
                                                                            If (gbllQuestGuardAreaID(lPortID) = lDAreaAreaID) Then 'Glory Event, move into area to guard it complete!
                                                                                gbllQuestGuardFailCount(lPortID) = 0
                                                                                gbllQuestGuardAreaID(lPortID) = 0
                                                                                lRewardTEMP1 = lRandom(10)
                                                                                lRewardTEMP2 = 222 + lRandom(228)
                                                                                lRewardTEMP3 = lRandom(3)
                                                                                Select Case lRandom(10)
                                                                                    Case 9, 10
                                                                                        lRewardTEMP1 = 10 'we control the payout a bit
                                                                                        lRewardTEMP1 = lRewardTEMP1 + lRandom(2)
                                                                                        If lRandom(2) = 1 Then lRewardTEMP1 = lRewardTEMP1 + lRandom(2) + 1
                                                                                        If lRandom(3) = 1 Then lRewardTEMP1 = lRewardTEMP1 + lRandom(5)
                                                                                        subSendMsgInfoChannel "&W" & zMomentumPlayerName & " &wHONORED" & vbCrLf & "[&g" & gblzQuestGuardAreaDesc(lPortID) & "&w] " & zFormatGoldCofGLearnpts(lRewardTEMP1, "c", True) & " " & zFormatGoldCofGLearnpts(lRewardTEMP3, "l", True) & " " & zFormatGoldCofGLearnpts(lRewardTEMP2, "g", True)
                                                                                    Case Else
                                                                                        subSendMsgInfoChannel "&W" & zMomentumPlayerName & " &wGUARDED" & vbCrLf & "[&g" & gblzQuestGuardAreaDesc(lPortID) & "&w] " & zFormatGoldCofGLearnpts(lRewardTEMP1, "c", True) & " " & zFormatGoldCofGLearnpts(lRewardTEMP3, "l", True) & " " & zFormatGoldCofGLearnpts(lRewardTEMP2, "g", True)
                                                                                End Select
                                                                                MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]+" & lRewardTEMP1 & ", Gold=[Gold]+" & lRewardTEMP2 & ", LearnPoints=[LearnPoints]+" & lRewardTEMP3 & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                gblzQuestGuardAreaDesc(lPortID) = "" 'MUST GO AFTER
                                                                            End If
                                                                            If (gbllQuestGuardAreaID(lPortID) <> 0) Then
                                                                                If (lRandom(999 + lCCHA + lReturnTranslateCharismaticBonus(zRaceType, zClassType)) = 1) Then
                                                                                    gbllQuestGuardAreaID(lPortID) = 0
                                                                                    gblzQuestGuardAreaDesc(lPortID) = ""
                                                                                    gbllQuestGuardFailCount(lPortID) = gbllQuestGuardFailCount(lPortID) + 1
                                                                                    subSendMsg "&RAdventurer, position " & gblzQuestGuardAreaDesc(lPortID) & " was filled on you, and cancelled.", zPortID
                                                                                End If
                                                                            End If
                                                                        End If
                                                                        End If
                                                                        lAreaEventZoneID = MyCLng(rsDArea!AreaEventZoneID)
                                                                        lDAreaMorphType = MyCLng(rsDArea!MorphType)
                                                                        zDAreaRules = MyCStr(rsDArea!AreaRules)
                                                                        lDAreaFlyLevel = MyCLng(rsDArea!FlyLevel)
                                                                        lDAreaHeightRequirement = MyCLng(rsDArea!HeightRequirement)
                                                                        lDAreaClanID = MyCLng(rsDArea!ClanID)
                                                                        lDAreaClanMemberLevel = MyCLng(rsDArea!ClanMemberLevel)
                                                                        lDAreaDamageToArea = MyCLng(rsDArea!DamageToArea)
                                                                        lDAreaX = MyCLng(rsDArea!x)
                                                                        lDAreaY = MyCLng(rsDArea!y)
                                                                        lDAreaZ = MyCLng(rsDArea!z)
                                                                        lDAreaDX = MyCLng(rsDArea!DX)
                                                                        lDAreaDY = MyCLng(rsDArea!DY)
                                                                        lDAreaDZ = MyCLng(rsDArea!DZ)
                                                                        lDAreaWhereID = MyCLng(rsDArea!WhereID)
                                                                        lDAreaDXYZActive = MyCInt(rsDArea!DXYZActive)
                                                                        bDAreaXYZ = True
                                                                        lDAreaTrapID = MyCLng(rsDArea!AreaTrapID)
                                                                        zDAreaObjectNameRequiredToPass = MyCStr(rsDArea!ObjectNameRequiredToPass)
                                                                        lDAreaThiefChestOfGlory = MyCLng(rsDArea!ThiefChestOfGlory)
                                                                        lDAreaThiefMobID = MyCLng(rsDArea!ThiefMobID)
                                                                        
                                                                        If (lMomentumPlayerLevel > 29) Then 'it is assumed highlevel characters have move bulk and more EQ weight
                                                                            lDAreaMoveCost = MyCLng(rsDArea!MoveCost) + (lDAreaDamageToArea * (lMomentumPlayerLevel / 2))
                                                                        Else
                                                                            lDAreaMoveCost = MyCLng(rsDArea!MoveCost) + lDAreaDamageToArea
                                                                        End If
                                                                        
                                                                        If (lTurnedIntoAnimalType = 7 Or lTurnedIntoAnimalType = 8 Or lTurnedIntoAnimalType = 9) Then lDAreaMoveCost = MyCLng(lDAreaMoveCost / 2)
                                                                        If (lTurnedIntoAnimalType = 1 Or lTurnedIntoAnimalType = 2 Or lTurnedIntoAnimalType = 3) Then lDAreaMoveCost = MyCLng(lDAreaMoveCost * 3)
                                                                        
                                                                        If (lMobHollarType <> 0) Then
                                                                            If (lRandom(12) > 2) Then 'sometimes the siren trap just fails right out
                                                                                subTitleBar "", zPortID
                                                                                bDiceRoll = (lRandom(100) <= lRandom(lMomentumCDEX))
                                                                                If (bDiceRoll Or lMomentumSneakingMovesLeft > 0 Or zClassType = "GY" Or zRaceType = "PIX") Then
                                                                                    If (bDiceRoll) Then
                                                                                        subSendMsg "&GDexterity FTW! You do not set off a siren-trip-wire, but its there.", zPortID
                                                                                    Else
                                                                                        If (zRaceType = "PIX") Then
                                                                                            subSendMsg "&GYou look down and notice a siren-trip-wire here, you fly over it.", zPortID
                                                                                        Else
                                                                                            subSendMsg "&GP h e w! You notice a siren-trip-wire here and sneak past it.", zPortID
                                                                                        End If
                                                                                    End If
                                                                                Else
                                                                                    MyDB.Execute "UPDATE tblMob SET PlayerID=" & lPlayerID & " WHERE X>=" & (lMomentumX - lMobHollarType) & " AND X<=" & (lMomentumX + lMobHollarType) & " AND Y>=" & (lMomentumY - lMobHollarType) & " AND Y<=" & (lMomentumY + lMobHollarType) & " AND Z=" & lMomentumZ & ";", dbFailOnError
                                                                                    subSendMsgAreaAll "&RE N E M Y  A L E R T !!! A loud siren goes off! Now they come for you!", lMomentumX, lMomentumY, lMomentumZ
                                                                                End If
                                                                                subTitleBar "", zPortID
                                                                            End If
                                                                        End If
                                                                        
                                                                        If ((lDAreaTrapID <> 0) And (lRandom(9) = 1 Or lHideDuration = 0) And (lRandom(10) < 4 Or lCamoflaguedDuration = 0)) Then 'we need to check if rb allows this you can get trapped through walls.
                                                                            lDAreaAreaTrapChance = MyCLng(rsDArea!AreaTrapChance)
                                                                            lDAreaAreaTrapDuration = MyCLng(rsDArea!AreaTrapDuration)
                                                                            If (lRandom(lDAreaAreaTrapChance) = 1) Then
                                                                                If (bMobIDAliveAreaTrapID(lDAreaTrapID)) Then 'checks to see if the mobid is alive or 0 both cases run this
                                                                                    MyDB.Execute "UPDATE tblPlayer SET AreaTrapID=" & lDAreaTrapID & ", AreaTrapDuration=" & lDAreaAreaTrapDuration & " WHERE PlayerID=" & lPlayerID & ";", dbFailOnError
                                                                                    subSendMsgAreaAll "&R" & zReturnTrapName(lDAreaTrapID) & " is a trap and goes off!", lMomentumX, lMomentumY, lMomentumZ
                                                                                    'check for tblArea special traps
                                                                                    Select Case (lAreaTrapIDType(lDAreaTrapID))
                                                                                        Case 1 'room fills with water
                                                                                            MyDB.Execute "UPDATE tblArea SET Underwater=999, UnderwaterDuration=" & lAreaTrapIDTypeDuration(lDAreaTrapID) & " WHERE AreaID=" & lDAreaAreaID & ";", dbFailOnError
                                                                                            subSendMsgAreaAll "&B** Water is rushing in from all sides! Run! No one can stop water!", lMomentumX, lMomentumY, lMomentumZ
                                                                                    End Select
                                                                                End If
                                                                            End If
                                                                        End If
                                                                        
                                                                        'THIEF CHEST OF GLORY
                                                                        If (lDAreaThiefChestOfGlory > 0) Then
                                                                            If (Not bMobAlive(lDAreaThiefMobID)) Then
                                                                                gbllQuestGuardAreaID(lPortID) = 0
                                                                                gblzQuestGuardAreaDesc(lPortID) = ""
                                                                                gbllQuestGuardFailCount(lPortID) = 0
                                                                                
                                                                                subSendMsgInfoChannel "&W" & zMomentumPlayerName & " &Y[&yTHIEFs TREASURE CHEST&Y] &w[" & zWhereID(lDAreaWhereID) & "&w] " & zFormatGoldCofGLearnpts(lDAreaThiefChestOfGlory, "c", True) & " " & zFormatGoldCofGLearnpts(1333 + (lDAreaThiefChestOfGlory * 220), "g", True)
                                                                                MyDB.Execute "UPDATE tblPlayer SET Gold=[Gold]+" & 1333 + (lDAreaThiefChestOfGlory * 220) & ", Crown=[Crown]+" & lDAreaThiefChestOfGlory & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                MyDB.Execute "UPDATE tblArea SET ThiefMobID=0, ThiefChestOfGlory=0 WHERE (AreaID=" & lDAreaAreaID & ");", dbFailOnError
                                                                            Else
                                                                                subSendMsg "&RWOWEE! &ya &Y[&yTHIEFs TREASURE CHEST&Y] &yis hidden RIGHT here !", zPortID
                                                                                subSendMsg "&g  type &GMARK &ghere and now, then seek, find, and kill thief &G[&g" & zShortstop(zMobAlive(lDAreaThiefMobID)) & "&G]", zPortID
                                                                            End If
                                                                        End If
                                                                        
                                                                        If (Len(zDAreaObjectNameRequiredToPass) > 0) Then
                                                                            Select Case (bPlayerCarriesObjectName(zDAreaObjectNameRequiredToPass, lPlayerID))
                                                                                Case True
                                                                                    zDAreaObjectNameRequiredCanPassEmote = MyCStr(rsDArea!ObjectNameRequiredCanPassEmote)
                                                                                    subSendMsg "&Y" & zDAreaObjectNameRequiredCanPassEmote, zPortID
                                                                                Case False
                                                                                    zDAreaObjectNameRequiredCantPassEmote = MyCStr(rsDArea!ObjectNameRequiredCantPassEmote)
                                                                                    subSendMsg "&Y" & zDAreaObjectNameRequiredCantPassEmote, zPortID
                                                                                    iReturn = 40
                                                                            End Select
                                                                        End If
                                                                        
                                                                        If (lDAreaMorphType <> 0 And lDAreaMorphType <> lTurnedIntoAnimalType) Then
                                                                            subSendMsg "&gYou need to be a " & zTranslatePoofAnimalTypes(1, lDAreaMorphType) & " to go into there.", zPortID
                                                                            iReturn = 400
                                                                        End If
                                                                        
                                                                        If (lDAreaDamageToArea <> 0) Then 'display a message to low levels and randomly to high levels
                                                                            If (lMomentumPlayerLevel < 20 Or lRandom(8) = 1) Then subSendMsg "&gThis area is not CLEAN at all, you keep tripping over strewn garbage.", zPortID 'slows down botters makes raided areas more realistic
                                                                        End If
                                                                        
                                                                        iClanOnlyMovement = 0
                                                                        If (lDAreaClanID <> 0) Then
                                                                            If (lMomentumClanID = lDAreaClanID) Then
                                                                                iClanOnlyMovement = 1 'Passed
                                                                            Else
                                                                                bNoProblemToFollow = False
                                                                                iClanOnlyMovement = 2 'Failed
                                                                                iReturn = 20
                                                                            End If
                                                                        End If
                                                                        
                                                                        If (lDAreaClanMemberLevel <> 0) Then
                                                                            bNoProblemToFollow = False 'this is needed because we dont want people following people places they can only go
                                                                            If (lMomentumClanMemberLevel < lDAreaClanMemberLevel) Then
                                                                                iReturn = 19
                                                                            End If
                                                                        End If
                                                                        
                                                                        'Too tall? This is the code that does this.
                                                                        If (lDAreaHeightRequirement > 0) Then
                                                                            If (lDAreaHeightRequirement < lMomentumHeight And Not bShortTurnedIntoAnimalType(lTurnedIntoAnimalType)) Then  'TurnedIntoAnimalType is frog mouse cat dog lizard etc....
                                                                                bNoProblemToFollow = False 'cant follow the person in there
                                                                                iReturn = 30
                                                                            End If
                                                                        End If
                                                                        
                                                                        If (iReturn = 1) Then 'Still cannot move then we keep checking
                                                                            If (iClanOnlyMovement <> 2) Then
                                                                                If (bAirMounted Or bGroundMounted) Then lDAreaMoveCost = ((lDAreaMoveCost + 2) / 2) 'it costs 2 pts to hang onto the mount
                                                                                
                                                                                If (lMomentumCMove >= lDAreaMoveCost) Then
                                                                                    If (lAreaEventZoneID <> 0) Then
                                                                                        If (bMobIDAliveAreaEventZoneID(lAreaEventZoneID)) Then 'checks to see if the mobid is alive or 0 both cases run this
                                                                                            iGetAreaEventZone = iAreaEventZone(lAreaEventZoneID, lPlayerID, zPortID)
                                                                                        End If
                                                                                    End If
                                                                                    bAreaEventZone = (bFlyDuration And iGetAreaEventZone = 2) Or (iGetAreaEventZone = 0 Or iGetAreaEventZone = 1 Or iGetAreaEventZone = 11 Or iGetAreaEventZone = 4) 'if you have fly on it overrides some types of traps
                                                                                    If (bFlyDuration And iGetAreaEventZone = 2) Then subSendMsg "&B...but you glide safely across...", zPortID
                                                                                    
                                                                                    If (bAreaEventZone) Then
                                                                                        If (Not bCAreaEOF) Then
                                                                                            lAreaRolePlayID = MyCLng(rsCArea!RolePlayID)
                                                                                            lAreaRolePlayLevel = MyCLng(rsCArea!RolePlayLevel)
                                                                                            lUnderwater = MyCLng(rsCArea!Underwater)
                                                                                            If (Not bDDoorEOF Or Not bDAreaEOF) Then 'An area exists at the current location and for the destination.
                                                                                                'strBlockedExits = strForceSize(MyCStr(rsCArea!BlockedExits), 10, "0", "A") moved this up which was more imporant
                                                                                                'If (Mid(strBlockedExits, intDirectionCell, 1) = "0") Then 'A viable direction exists
                                                                                                '0 = Open, 1 = Unlocked but closed, 2 = Locked, 3=open but is lock/pickable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and not lockable, 7 = Bashed closed, 8=Bashable 10=magic open 11=magic closed 12=magically locked
                                                                                                If (Not bDDoorEOF) Then
                                                                                                    Select Case lDDoorStatus
                                                                                                        Case 2, 4
                                                                                                            iReturn = 2 'Locked door error
                                                                                                        Case 1, 6, 7, 8, 11, 12
                                                                                                            iReturn = 3 'Door is not open!
                                                                                                        Case Else
                                                                                                            iReturn = 0
                                                                                                    End Select
                                                                                                Else
                                                                                                    iReturn = 0
                                                                                                End If
                                                                                                'Else
                                                                                                '    'bAlasCannotGoThatWay = True
                                                                                                '    If (lImmortalLevel >= 10 And Not bDDoorEOF) Then
                                                                                                '        subSendMsg "&GIMMORTAL MESSAGE ONLY: Possible design flaw," & vbCrLf & "The area on the otherside of the door is not reachable." & vbCrLf & "You may of also discovered a trap door in the floor or ceiling, in which case ignore this message." & vbCrLf & "See Also: RB/RH [direction] [+/-]" & vbCrLf & "      RC or DC", zPortID
                                                                                                '    End If
                                                                                                'End If
                                                                                            End If
                                                                                        End If
                                                                                        
                                                                                        If (lDMainGroup <> 0) Then subPrintAnAsciiPicturebyMainGroup lDMainGroup, zPortID
                                                                                        
                                                                                        'We need fly to go to some areas.
                                                                                        If (lDAreaFlyLevel <> 0) Then
                                                                                            If (Not bFlyDuration) Then
                                                                                                iReturn = 10
                                                                                            Else
                                                                                                If (lDAreaFlyLevel > lMomentumPlayerLevel) Then
                                                                                                    subSendMsg "&gYou are not level " & lDAreaFlyLevel & " or higher.", zPortID
                                                                                                    iReturn = 11
                                                                                                End If
                                                                                            End If
                                                                                        End If
                                                                                        
                                                                                        If (iReturn = 0) Then
                                                                                            If (lInvisibilityDuration > 0 Or lShadowCloakDuration > 0) Then
                                                                                                If (Mid(zDAreaRules, 2, 1) = "0") Then 'turn off invisible moving into the room
                                                                                                    subSendMsg "&RA spell in the area reveals your true form to everyone here!", zPortID
                                                                                                    MyDB.Execute "UPDATE tblPlayer SET InvisibilityDuration=0, ShadowCloakDuration=0 WHERE PlayerID=" & lPlayerID & ";", dbFailOnError
                                                                                                End If
                                                                                            End If
                                                                                            
                                                                                            If (Not bFlyDuration) Then
                                                                                                lMomentumCMove = (lMomentumCMove - lDAreaMoveCost)
                                                                                                Select Case lDAreaMoveCost
                                                                                                    Case 1 To 9
                                                                                                    Case 10 To 15
                                                                                                        subSendMsg "&Ghuff puff", zPortID
                                                                                                    Case 16 To 32
                                                                                                        subSendMsg "&GHuff Puff", zPortID
                                                                                                    Case 33 To 50
                                                                                                        subSendMsg "&GHuff! Puff!", zPortID
                                                                                                    Case 51 To 100
                                                                                                        subSendMsg "&GHuff!!! Puff!!!", zPortID
                                                                                                    Case 101 To 150
                                                                                                        subSendMsg "&GHUFF PUFF", zPortID
                                                                                                    Case 151 To 300
                                                                                                        subSendMsg "&GHUFF! PUFF!", zPortID
                                                                                                    Case 301 To 500
                                                                                                        subSendMsg "&RHUFF!! PUFF!!", zPortID
                                                                                                    Case 501 To 999
                                                                                                        subSendMsg "&RHUFF!!! PUFF!!!", zPortID
                                                                                                    Case Else
                                                                                                        subSendMsg "&R!?!HUFF!?!PUFF!?! GARBAGE EVERYWHERE!", zPortID
                                                                                                End Select
                                                                                            Else
                                                                                                'flying helps to save movement points and huff puff spam
                                                                                                lMomentumCMove = (lMomentumCMove - MyCLng(lDAreaMoveCost / 4))
                                                                                            End If
                                                                                            
                                                                                            If (Not bDDoorEOF) Then 'move through the door and into the other area.
                                                                                                lngX = lngX * 2
                                                                                                lngY = lngY * 2
                                                                                                lngZ = lngZ * 1
                                                                                            End If
                                                                                            
                                                                                            'Save original spot before move.
                                                                                            lOX = lMomentumX
                                                                                            lOY = lMomentumY
                                                                                            lOZ = lMomentumZ
                                                                                            
                                                                                            If (lDAreaDXYZActive = 1) Then
                                                                                                'Some areas teleport to destination areas
                                                                                                lMomentumX = lDAreaDX
                                                                                                lMomentumY = lDAreaDY
                                                                                                lMomentumZ = lDAreaDZ
                                                                                                lDAreaWhereID = lWhereID(lDAreaDX, lDAreaDY, lDAreaDZ) 'get the telport destination where id
                                                                                            Else
                                                                                                lMomentumX = lMomentumX + lngX
                                                                                                lMomentumY = lMomentumY + lngY
                                                                                                lMomentumZ = lMomentumZ + lngZ
                                                                                            End If
                                                                                            
                                                                                            'If (lMomentumX = -1 And lMomentumY = -1 And lMomentumZ = -10) Then
                                                                                            '    subRealmRules zPortID, 0, 2 'we force them to read the short form of the realm rules
                                                                                            '    subSendMsg "&g                ~HELP RULES, FOR A VERBOSE DESCRIPTION~", zPortID
                                                                                            'End If
                                                                                            
                                                                                            'MyDB.Execute "UPDATE tblPlayer INNER JOIN tblArea ON (tblPlayer.Z = tblArea.Z) AND (tblArea.Y = tblPlayer.Y) AND (tblPlayer.X = tblArea.X) SET tblPlayer.WhereID = [tblArea].[WhereID] WHERE (((tblPlayer.PlayerID)=" & lOPlayerID & "));", dbFailOnError
                                                                                            
                                                                                            If (lFPlayerGroupStatus = 1) Then 'Am I the Leader?
                                                                                                'If (lImmortalLevel >= 90) Then
                                                                                                    'SUMMON FOLLOW: Move all god's followers to their spot whereever that is, only if they are following.
                                                                                                '    MyDB.Execute "UPDATE tblPlayer SET X=" & lMomentumX & ", Y=" & lMomentumY & ", Z=" & lMomentumZ & " WHERE (FPlayerID=" & lOPlayerID & ");", dbFailOnError
                                                                                                'Else
                                                                                                If (lDAreaClanID = 0 And bNoProblemToFollow) Then 'cant follow people into clans and other places like ranked areas
                                                                                                    'So thats the follow being cancelled for the majority of the areas
                                                                                                    'Now we check each Follwer to make sure they can follow.
                                                                                                    Set rsFollow = MyDB.OpenRecordset("SELECT PlayerName, PortID, X, Y, Z, CMove, Status, Height, FPlayerID, BlindDuration, StunDuration, EntanglementDuration, WhereID FROM tblPlayer WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND FPlayerID=" & lPlayerID & ");", dbOpenDynaset)
                                                                                                    Do While (Not rsFollow.EOF)
                                                                                                        If (MyCLng(rsFollow!Height) <= lDAreaHeightRequirement Or lDAreaHeightRequirement < 1) Then
                                                                                                        If (MyCLng(rsFollow!BlindDuration) = 0 And MyCLng(rsFollow!StunDuration) = 0 And MyCLng(rsFollow!EntanglementDuration) = 0 And MyCLng(rsFollow!Status) = 5) Then
                                                                                                        If (MyCLng(rsFollow!CMove) >= lDAreaMoveCost) Then
                                                                                                        If (rSCombat(MyCLng(rsFollow!PortID)).iStatus = cstiStatusNotInBattleMode) Then
                                                                                                            rsFollow.Edit
                                                                                                            rsFollow!WhereID = lDAreaWhereID
                                                                                                            rsFollow!x = lMomentumX
                                                                                                            rsFollow!y = lMomentumY
                                                                                                            rsFollow!z = lMomentumZ
                                                                                                            lFollowCMove = MyCLng(rsFollow!CMove) - lDAreaMoveCost
                                                                                                            If (lFollowCMove < 0) Then lFollowCMove = 0
                                                                                                            rsFollow!CMove = lFollowCMove
                                                                                                            rsFollow.Update
                                                                                                            'TRISKER: Need AREASMARTID for invis or leave it as they were grouped so the leader would know.
                                                                                                            subSendMsg "&gYou follow " & zMomentumPlayerName & " " & zTranslateDirection(zDir, 2) & ".", MyCStr(rsFollow!PortID)
                                                                                                            subSendMsg gblzFNGRE & MyCStr(rsFollow!PlayerName) & " follows you " & zTranslateDirection(zDir, 2) & ".", zPortID
                                                                                                            subSendMsgAreaExcept2 gblzFNGRE & MyCStr(rsFollow!PlayerName) & " follows " & zMomentumPlayerName & " " & zTranslateDirection(zDir, 2) & ".", lOX, lOY, lOZ, zPortID, MyCStr(rsFollow!PortID)
                                                                                                            subSendMsgAreaExcept2 gblzFNGRE & MyCStr(rsFollow!PlayerName) & " follows " & zMomentumPlayerName & " in from " & zTranslateDirection(zDir, 1) & ".", lMomentumX, lMomentumY, lMomentumZ, zPortID, MyCStr(rsFollow!PortID)
                                                                                                            'Subtract their move
                                                                                                            'MyDB.Execute "UPDATE tblPlayer SET tblPlayer.CMove = [CMove]-" & lDAreaMoveCost & " WHERE (((tblPlayer.X)=" & lOX & ") AND ((tblPlayer.Y)=" & lOY & ") AND ((tblPlayer.Z)=" & lOZ & ") AND ((tblPlayer.CMove)>0) AND ((tblPlayer.BlindDuration)=0) AND ((tblPlayer.StunDuration)=0) AND ((tblPlayer.FPlayerID)=" & lOPlayerID & "));", dbFailOnError
                                                                                                            'MyDB.Execute "UPDATE tblPlayer SET tblPlayer.CMove = 0 WHERE (((tblPlayer.CMove)<1) AND ((tblPlayer.FPlayerID)=" & lOPlayerID & "));", dbFailOnError
                                                                                                            'REAL FOLLOW if they were at my oringal location only: Move all player's followers to that spot if they are following.
                                                                                                            'MyDB.Execute "UPDATE tblPlayer SET tblPlayer.X = " & lMomentumX & ", tblPlayer.Y = " & lMomentumY & ", tblPlayer.Z = " & lMomentumZ & " WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND (Status=3 OR Status=5) AND (BlindDuration=0) AND (StunDuration=0) AND (CMove>0) AND FPlayerID=" & lOPlayerID & ");", dbFailOnError
                                                                                                        Else
                                                                                                            subSendMsg "&gYou are too busy fighting to go anywhere!", MyCStr(rsFollow!PortID)
                                                                                                        End If
                                                                                                        Else
                                                                                                            subSendMsg "&gYou are short movement points...", MyCStr(rsFollow!PortID)
                                                                                                        End If
                                                                                                        Else
                                                                                                            subSendMsg "&gYou are too confused to follow right now...", MyCStr(rsFollow!PortID)
                                                                                                        End If
                                                                                                        Else
                                                                                                            subSendMsg "&gYour current height doesn't permit you to go in there...", MyCStr(rsFollow!PortID)
                                                                                                        End If
                                                                                                        rsFollow.MoveNext
                                                                                                    Loop
                                                                                                    Set rsFollow = Nothing
                                                                                                End If
                                                                                                'End If
                                                                                            End If
                                                                                            If (lMomentumPlayerLevel < 20) Then
                                                                                                If (lMomentumX = 0 And lMomentumY = 0 And lMomentumZ = 0) Then
                                                                                                    subSendMsg "&RCREE!!" & vbCrLf & "Your orders are to proceed to the west and take down the farm animal infest!", zPortID
                                                                                                End If
                                                                                            End If
                                                                                            bNormal = True
                                                                                            If (lPCHP < MyCLng(lOCHP / 2)) Then
                                                                                                If (lRandom(20) = 1) Then
                                                                                                    subSendMsg "&rPAIN!! Bruises, Cuts! Combat stress!! Ahhhhh!", zPortID
                                                                                                    bNormal = False
                                                                                                End If
                                                                                            End If
                                                                                            If (bNormal) Then 'This is immersive for the player
                                                                                                MyDB.Execute "UPDATE tblPlayer SET RolePlayID=" & lAreaRolePlayID & ", RolePlayLevel=" & lAreaRolePlayLevel & ", WhereID=" & lDAreaWhereID & ", X=" & lMomentumX & ", Y=" & lMomentumY & ", Z=" & lMomentumZ & ", CMove=" & lMomentumCMove & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                            Else
                                                                                                MyDB.Execute "UPDATE tblPlayer SET RolePlayID=" & lAreaRolePlayID & ", RolePlayLevel=" & lAreaRolePlayLevel & ", WhereID=" & lDAreaWhereID & ", X=" & lMomentumX & ", Y=" & lMomentumY & ", Z=" & lMomentumZ & ", CMove=" & lMomentumCMove & ", StunDuration=" & lRandom(2) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                                            End If
                                                                                        End If
                                                                                    End If 'we stop checking the areas destination status
                                                                                Else
                                                                                    subSendMsg "&gYou are too tired to move there." & vbCrLf & "You may need to CLEAN the raided damaged areas around you.", zPortID
                                                                                End If '(lMomentumCMove >= lDAreaMoveCost)
                                                                            End If
                                                                        End If
                                                                    End If
                                                                    Set rsDArea = Nothing
                                                                    Set rsDDoor = Nothing
                                                                End If
                                                            End If
                                                            Set rsCArea = Nothing
                                                            Else
                                                                iReturn = 666
                                                            End If
                                                        Else
                                                            iReturn = 70
                                                        End If
                                                    Else
                                                        iReturn = 80
                                                    End If
                                                    
                                                    If (iReturn = 0) Then 'Perfect!
                                                        If (lPFactionID <> lDAreaFactionID) Then
                                                            If (lRandom(2222 + lMomentumPlayerLevel) < 13) Then
                                                                MyDB.Execute "UPDATE tblPlayer SET PandemicLevel=" & lRandom(60) + 5 & ", PandemicDuration=" & lRandom(99) + 20 & " WHERE (Class<>'BA' AND Race<>'UND' AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                                            End If
                                                        End If
                                                        If (bFPlayerGroupStatus) Then
                                                            subGroupForceLookFollowers lPlayerID, lMomentumX, lMomentumY, lMomentumZ, zClassType
                                                        End If

                                                        'After move.
                                                        If (lTurnedIntoAnimalType > 0) Then zExtraMovement = zTranslatePoofAnimalTypes(3, lTurnedIntoAnimalType)
                                                        If (Len(zExtraMovement) <> 0) Then zExtraMovement = "*" & zExtraMovement & "* "
                                                        If (bSneakMounted = False And lMomentumSneakingMovesLeft = 0 And lCamoflaguedDuration = 0) Then
                                                            If (lUnderwater < 120) Then
                                                                Select Case (bFlyDuration)
                                                                    Case True 'flying
                                                                        subSendMsgAreaAllDISmart "&m", zMomentumPlayerName, "", "", zFlee & zExtraMovement & "%s1 " & MyCStr(rsMomentum!FlyExitMsg) & " " & zTranslateDirection(zDir, 2) & ".", lOX, lOY, lOZ
                                                                        subSendMsgAreaAllDISmart "&m", zMomentumPlayerName, zFlee & zExtraMovement & "You coast in from " & zTranslateDirection(zDir, 1) & ".", "", zFlee & zExtraMovement & "%s1 " & MyCStr(rsMomentum!FlyEnterMsg) & " " & zTranslateDirection(zDir, 1) & ".", lMomentumX, lMomentumY, lMomentumZ
                                                                    Case False 'walking
                                                                        subSendMsgAreaAllDISmart "&m", zMomentumPlayerName, "", "", zFlee & zExtraMovement & "%s1 " & MyCStr(rsMomentum!WalkExitMsg) & " to " & zTranslateDirection(zDir, 10) & ".", lOX, lOY, lOZ
                                                                        subSendMsgAreaAllDISmart "&m", zMomentumPlayerName, zFlee & zExtraMovement & "You wander in from " & zTranslateDirection(zDir, 1) & ".", "", zFlee & zExtraMovement & "%s1 " & MyCStr(rsMomentum!WalkEnterMsg) & " " & zTranslateDirection(zDir, 1) & ".", lMomentumX, lMomentumY, lMomentumZ
                                                                End Select
                                                            Else
                                                                subSendMsgAreaAllDISmart "&m", zMomentumPlayerName, "", "", zFlee & zExtraMovement & "%s1 [swimming] " & MyCStr(rsMomentum!WalkExitMsg) & " to " & zTranslateDirection(zDir, 10) & ".", lOX, lOY, lOZ
                                                                subSendMsgAreaAllDISmart "&m", zMomentumPlayerName, zFlee & zExtraMovement & "You [swimming] " & MyCStr(rsMomentum!WalkEnterMsg) & " " & zTranslateDirection(zDir, 1) & ".", "", zFlee & zExtraMovement & "%s1 [swimming] " & MyCStr(rsMomentum!WalkEnterMsg) & " " & zTranslateDirection(zDir, 1) & ".", lMomentumX, lMomentumY, lMomentumZ
                                                            End If
                                                        Else
                                                            zMoveLogo = ""
                                                            If (lUnderwater > 120) Then zMoveLogo = zMoveLogo & "underwater"
                                                            bMoveLogo = (Len(zMoveLogo) > 0)
                                                            If (bFlyDuration) Then
                                                                If (bMoveLogo) Then zMoveLogo = zMoveLogo & " and "
                                                                zMoveLogo = zMoveLogo & "flying"
                                                                bMoveLogo = True
                                                            End If
                                                            
                                                            If (bSneakMounted) Then lMomentumSneakingMovesLeft = 1
                                                            If (lMomentumSneakingMovesLeft > 0) Then
                                                                lMomentumSneakingMovesLeft = (lMomentumSneakingMovesLeft - 1) 'reduce the sneaking amount
                                                                MyDB.Execute "UPDATE tblPlayer SET SneakingMovesLeft=" & lMomentumSneakingMovesLeft & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                                                If (bMoveLogo) Then
                                                                    subSendMsg gblzFNGRE & zFlee & zExtraMovement & "You sneak [" & zMoveLogo & "] in from " & zTranslateDirection(zDir, 1) & ". [" & lMomentumSneakingMovesLeft & "]", zPortID
                                                                Else
                                                                    If (lMomentumSneakingMovesLeft <> 0) Then
                                                                        subSendMsg gblzFNGRE & zFlee & zExtraMovement & "You sneak in from " & zTranslateDirection(zDir, 1) & ". [" & lMomentumSneakingMovesLeft & "]", zPortID
                                                                    Else
                                                                        subSendMsg gblzFNGRE & zFlee & zExtraMovement & "You sneak in from " & zTranslateDirection(zDir, 1) & ".", zPortID
                                                                    End If
                                                                End If
                                                            Else
                                                                If (bMoveLogo) Then
                                                                    subSendMsg gblzFNGRE & zFlee & zExtraMovement & "You sneak [" & zMoveLogo & "] in from " & zTranslateDirection(zDir, 1) & ".", zPortID
                                                                Else
                                                                    subSendMsg gblzFNGRE & zFlee & zExtraMovement & "You sneak in from " & zTranslateDirection(zDir, 1) & ".", zPortID
                                                                End If
                                                            End If
                                                        End If
                                                        
                                                        'Print the area
                                                        subAreaDesc lHallucinate, lDetectInvisibilityDuration, zPortID, lMomentumX, lMomentumY, lMomentumZ, lMomentumPlayerLevel, lPlayerID, 0, lColorAreaDesc, zRaceType, zClassType, zPlayerConfig, 0, -1, bStatusBM, bStatusGUID, ""
                                                        basSenseForTraps lDAreaX, lDAreaY, lDAreaZ, zRaceType, zClassType, lPlayerID, zPortID
                                                        basSenseForGloryMobs lDAreaX, lDAreaY, lDAreaZ, zRaceType, zClassType, lPlayerID, zPortID
                                                        basSenseForGloryObjects lDAreaX, lDAreaY, lDAreaZ, zRaceType, zClassType, lPlayerID, zPortID
                                                        basSenseForConstructs lDAreaX, lDAreaY, lDAreaZ, zRaceType, zClassType, lPlayerID, zPortID
                                                        If (bDAreaXYZ) Then 'We force talking mobs to try and speak
                                                            subRotateMobSpeak lDAreaX, lDAreaY, lDAreaZ, True
                                                        End If
                                                    End If
                                                Else 'Player Trapped
                                                    subSendMsg "&RYou are trapped you cannot move!", zPortID
                                                End If
                                            Else 'Weight
                                                subSendMsg "&RYou are too heavy to move, seek out more strength items to wear!", zPortID
                                            End If
                                        Else 'cstiStatusNotInBattleMode
                                            subSendMsg "&gYou cannot move while you are fighting!", zPortID
                                        End If
                                    Else 'lPCHP
                                        subSendMsg "&RYOU DRIP BLOOD! You are in too much pain to move!", zPortID
                                    End If
                                Else 'EntanglementDuration
                                    subSendMsg "&yYou are too entangled to do that.", zPortID
                                End If
                            Else 'lPDrunkDuration
                                subSendMsg "&CWhy move?! &G[&c" & lPDrunkDuration & "&G]&c is over &M100 &crounds of more fun and more drinking it up!", zPortID
                            End If
                        'Else 'flee
                            'subSendMsg "&RYou are too scared to do that right now!", zPortID
                        'End If
                    Else 'sleep
                        subSendMsg "&RYou are too sleepy to walk around!", zPortID
                    End If
                Else 'stun
                    subSendMsg "&RYou are too stunned to move!", zPortID
                End If
            Else 'blind
                subSendMsg "&RYou are blind and cannot see to move!", zPortID
            End If
        End If 'rsMomentum
        Set rsMomentum = Nothing
    End If 'bOkay
    
    iMomentumEngineXYZ = iReturn
    
    Exit Function
Err_Check:
    subWriteErrorFile "subMomentumEngineXYZ," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subDirectionControlAdd(ByRef lTX As Long, ByRef lTY As Long, ByRef lTZ As Long, ByVal lOX As Long, ByVal lOY As Long, ByVal lOZ As Long, zDir As String, lAdd As Integer)
On Error Resume Next
'See also: bMomentumEngineXYZ
    lTX = lOX
    lTY = lOY
    lTZ = lOZ
    Select Case UCase(zDir)
        Case "U", "UP"
            lTZ = lOZ - lAdd
        Case "D", "DOWN"
            lTZ = lOZ + lAdd
        Case "N", "NORTH"
            lTY = lOY - lAdd
        Case "S", "SOUTH"
            lTY = lOY + lAdd
        Case "E", "EAST"
            lTX = lOX + lAdd
        Case "W", "WEST"
            lTX = lOX - lAdd
        Case "NE", "NORTHEAST"
            lTX = lOX + lAdd
            lTY = lOY - lAdd
        Case "NW", "NORTHWEST"
            lTX = lOX - lAdd
            lTY = lOY - lAdd
        Case "SE", "SOUTHEAST"
            lTX = lOX + lAdd
            lTY = lOY + lAdd
        Case "SW", "SOUTHWEST"
            lTX = lOX - lAdd
            lTY = lOY + lAdd
    End Select
End Sub
Public Sub subDirectionControl(ByRef lTX As Long, ByRef lTY As Long, ByRef lTZ As Long, ByVal lOX As Long, ByVal lOY As Long, ByVal lOZ As Long, zDir As String)
On Error Resume Next
'See also: bMomentumEngineXYZ
    lTX = lOX
    lTY = lOY
    lTZ = lOZ
    
    Select Case UCase(zDir)
        Case "U", "UP", "ABOVE", "A"
            lTZ = lOZ - 1
        Case "D", "DOWN", "BELOW", "B"
            lTZ = lOZ + 1
        Case "N", "NORTH"
            lTY = lOY - 1
        Case "S", "SOUTH"
            lTY = lOY + 1
        Case "E", "EAST"
            lTX = lOX + 1
        Case "W", "WEST"
            lTX = lOX - 1
        Case "NE", "NORTHEAST"
            lTX = lOX + 1
            lTY = lOY - 1
        Case "NW", "NORTHWEST"
            lTX = lOX - 1
            lTY = lOY - 1
        Case "SE", "SOUTHEAST"
            lTX = lOX + 1
            lTY = lOY + 1
        Case "SW", "SOUTHWEST"
            lTX = lOX - 1
            lTY = lOY + 1
    End Select
End Sub
Public Function zTranslateDoorStatus(iType As Integer) As String
On Error Resume Next
    Dim zReturn As String
    zReturn = ""
    Select Case iType
        Case 0 'open not lockable - a regular door
            zReturn = "open"
        Case 6 'closed not lockable - a regular door
            zReturn = "closed and not lockable"
        Case 1 'unlocked
            zReturn = "key-unlocked"
        Case 2 'locked
            zReturn = "key-locked"
        Case 3 'lockable-door
            zReturn = "key-lockable"
        Case 5 'bashed open
            zReturn = "bashed open"
        Case 7 'bashed closed
            zReturn = "bashed closed"
        Case 8 'bashable [aka. locked]
            zReturn = "bashable"
        Case 10 'open but majikally lockable
            zReturn = "majik-open"
        Case 11 'closed but majikally lockable
            zReturn = "majik-closed"
        Case 12 'majikally locked
            zReturn = "majik-sealed"
        Case Else
            zReturn = "Err-iType" & iType
    End Select
    zTranslateDoorStatus = zReturn
End Function
Public Sub subBridgeRaiseLower(zPortID As String)
On Error GoTo Err_Check 'Draw bridge raise and lower areas
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim zPlayerName As String
    Dim rsBridgeCount As Recordset
    Dim lBridgeCount As Long
    Dim rsBridge As Recordset
    Dim lAreaBridgeID As Long
    Dim lAreaID As Long
    Dim lAreaBridgeOX As Long
    Dim lAreaBridgeOY As Long
    Dim lAreaBridgeOZ As Long
    Dim lAreaBridgeDX As Long
    Dim lAreaBridgeDY As Long
    Dim lAreaBridgeDZ As Long
    Dim rsArea As Recordset
    Dim lAreaX As Long
    Dim lAreaY As Long
    Dim lAreaZ As Long
    Dim bAreaO As Boolean
    Dim bAreaD As Boolean
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, X, Y, Z, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
    End If
    Set rsPlayer = Nothing

    Set rsBridge = MyDB.OpenRecordset("SELECT AreaBridgeID, AreaBridgeTimer, AreaID, AreaBridgeOX, AreaBridgeOY, AreaBridgeOZ, AreaBridgeDX, AreaBridgeDY, AreaBridgeDZ, AreaBridgeTriggerX, AreaBridgeTriggerY, AreaBridgeTriggerZ FROM tblAreaBridge WHERE (AreaBridgeTriggerX>=" & lPX - 2 & " AND AreaBridgeTriggerX<=" & lPX + 2 & " AND AreaBridgeTriggerY>=" & lPY - 2 & " AND AreaBridgeTriggerY<=" & lPY + 2 & " AND AreaBridgeTriggerZ>=" & lPZ - 2 & " AND AreaBridgeTriggerZ<=" & lPZ + 2 & ");", dbOpenSnapshot)
    If (Not rsBridge.EOF) Then
        subSendMsgAreaAll gblzFBMAG & "The draw bridge man signals your area.", lPX, lPY, lPZ
        Do While (Not rsBridge.EOF)
            lAreaBridgeID = MyCLng(rsBridge!AreaBridgeID)
            lAreaID = MyCLng(rsBridge!AreaID)
            lAreaBridgeOX = MyCLng(rsBridge!AreaBridgeOX)
            lAreaBridgeOY = MyCLng(rsBridge!AreaBridgeOY)
            lAreaBridgeOZ = MyCLng(rsBridge!AreaBridgeOZ)
            lAreaBridgeDX = MyCLng(rsBridge!AreaBridgeDX)
            lAreaBridgeDY = MyCLng(rsBridge!AreaBridgeDY)
            lAreaBridgeDZ = MyCLng(rsBridge!AreaBridgeDZ)
            
            lBridgeCount = 0
            Set rsBridgeCount = MyDB.OpenRecordset("SELECT Count(tblPlayer.PlayerID) AS CountOfPlayerID FROM tblPlayer INNER JOIN tblAreaBridge ON (tblPlayer.Z = tblAreaBridge.AreaBridgeDZ) AND (tblPlayer.Y = tblAreaBridge.AreaBridgeDY) AND (tblPlayer.X = tblAreaBridge.AreaBridgeDX);", dbOpenSnapshot)
            If (Not rsBridgeCount.EOF) Then
                lBridgeCount = rsBridgeCount!CountOfPlayerID
            End If
            Set rsBridgeCount = Nothing
            
            If (lBridgeCount = 0) Then 'no players on the bridge, logged in or off? Then continue!
                Set rsArea = MyDB.OpenRecordset("SELECT X, Y, Z FROM tblArea WHERE (AreaID=" & lAreaID & ");", dbOpenSnapshot)
                Do While (Not rsArea.EOF)
                    lAreaX = MyCLng(rsArea!x)
                    lAreaY = MyCLng(rsArea!y)
                    lAreaZ = MyCLng(rsArea!z)
                    bAreaO = (lAreaX = lAreaBridgeOX And lAreaY = lAreaBridgeOY And lAreaZ = lAreaBridgeOZ)
                    bAreaD = (lAreaX = lAreaBridgeDX And lAreaY = lAreaBridgeDY And lAreaZ = lAreaBridgeDZ)
                    If (Not bAreaO And Not bAreaD) Then 'This may fix mistakes does nothing else
                        MyDB.Execute "UPDATE tblArea SET X=" & lAreaBridgeOX & " AND Y=" & lAreaBridgeOY & " AND Z=" & lAreaBridgeOZ & " WHERE (AreaID=" & lAreaID & ");", dbFailOnError
                    Else 'Found the area at one of the two positions
                        If (bAreaD) Then
                            subSendMsgAreaAll gblzFBMAG & "The draw bridge man raises the draw-bridge.", lPX, lPY, lPZ
                            MyDB.Execute "UPDATE tblArea SET X=" & lAreaBridgeOX & ", Y=" & lAreaBridgeOY & ", Z=" & lAreaBridgeOZ & " WHERE (AreaID=" & lAreaID & ");", dbFailOnError
                        Else
                            subSendMsgAreaAll gblzFBMAG & "The draw bridge man lowers the draw-bridge.", lPX, lPY, lPZ
                            MyDB.Execute "UPDATE tblArea SET X=" & lAreaBridgeDX & ", Y=" & lAreaBridgeDY & ", Z=" & lAreaBridgeDZ & " WHERE (AreaID=" & lAreaID & ");", dbFailOnError
                            MyDB.Execute "UPDATE tblAreaBridge SET AreaBridgeTimer = 4 WHERE (AreaBridgeID=" & lAreaBridgeID & ");", dbFailOnError 'So we can reset the drawbridge to raised position see also: subRotateTheWorld
                        End If
                    End If
                    rsArea.MoveNext
                Loop
                Set rsArea = Nothing
            Else 'If there are players even ones logged off at this spot we move them to the Bridge Trigger position
                subSendMsgAreaAll gblzFBMAG & "The draw bridge man calls out, 'The bridge is out for a few rounds!'", lPX, lPY, lPZ
                MyDB.Execute "UPDATE tblAreaBridge SET AreaBridgeTimer = 4 WHERE (AreaBridgeID=" & lAreaBridgeID & ");", dbFailOnError
            End If
            rsBridge.MoveNext
        Loop
    Else
        subSendMsg "&MThere is no visible drawbridge in the area.", zPortID
    End If
    Set rsBridge = Nothing

    Exit Sub
Err_Check:
    subWriteErrorFile "subBridgeRaiseLower," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSabotage(zPortID As String)
On Error GoTo Err_Check 'Gypsy Power skill
    Dim bSuccessWithAtLeastOneTarget As Boolean
    
    Dim rsPlayer As Recordset
    Dim lPPlayerID As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lStatus As Long
    Dim zPClass As String
    Dim zPPlayerName As String
    Dim lPCINT As Long
    Dim lPPlayerLevel As Long
    Dim lPCMove As Long
    Dim lPCSoul As Long
    
    Dim rsTarget As Recordset
    Dim lTPlayerID As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim zTClass As String
    Dim zTPlayerName As String
    Dim lTCINT As Long
    Dim lTPlayerLevel As Long
    
    zPClass = ""
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Status, CMove, CSoul, PlayerLevel, PlayerID, Class, PlayerName, CINT, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPPlayerID = MyCLng(rsPlayer!PlayerID)
        lStatus = MyCLng(rsPlayer!Status)
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
        zPClass = MyCStr(rsPlayer!Class)
        zPPlayerName = MyCStr(rsPlayer!PlayerName)
        lPCINT = MyCLng(rsPlayer!CInt)
        lPCMove = MyCLng(rsPlayer!CMove)
        lPCSoul = MyCLng(rsPlayer!CSoul)
        lPPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
    End If
    Set rsPlayer = Nothing
    
    If (lStatus <> 50) Then
    If (zPClass = "GY" Or zPClass = "IO") Then 'Try to Sabotage Players then Mobs In the Area
        If (lPCMove > 999 And lPCSoul > 499) Then
            MyDB.Execute "UPDATE tblPlayer SET CMove=CMove-1000, CSoul=CSoul-500 WHERE (PlayerID=" & lPPlayerID & ");"
            subSendMsg "&gYou blink your eyelids twelve times in a particular order and call upon the" & vbCrLf & "eagle-eye of sabotage. All shields and all skill delays will reset" & vbCrLf & "within this room. Those affected will be blinded by the Eagle-eye.", zPortID
            subSendMsgAreaExcept2 "&GThe eye of an eagle beams over head then flys off in pure lightning!", lPX, lPY, lPZ, zPortID, ""
            
            bSuccessWithAtLeastOneTarget = False
            Set rsTarget = MyDB.OpenRecordset("SELECT PlayerID, Class, PlayerName, CINT, X, Y, Z, PlayerLevel FROM tblPlayer WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND Len(PortID)=4 AND PlayerID<>" & lPPlayerID & ");", dbOpenSnapshot)
            Do While (Not rsTarget.EOF)
                lTPlayerID = MyCLng(rsTarget!PlayerID)
                lTX = MyCLng(rsTarget!x)
                lTY = MyCLng(rsTarget!y)
                lTZ = MyCLng(rsTarget!z)
                zTClass = MyCStr(rsTarget!Class) 'Warriors can bash twice as hard!
                zTPlayerName = MyCStr(rsTarget!PlayerName)
                lTCINT = MyCLng(rsTarget!CInt)
                lTPlayerLevel = MyCLng(rsTarget!PlayerLevel)
                If (lRandom(lPCINT + lPPlayerLevel) > lRandom(lTCINT + lTPlayerLevel) + 5) Then
                    MyDB.Execute "UPDATE tblPlayer SET ImaginaryDuration=0, BlindDuration=2, StunInterruption=3, DisarmInterruption=3, SleepSpellInterruption=3, FireballInterruption=3, FireshieldDuration=0, IceshieldDuration=0, ChaosshieldDuration=0, StaticshieldDuration=0, SanctuaryDuration=0, NegateDuration=0, BarkskinDuration=0, StoneskinDuration=0, DragonskinDuration=0, DemonskinDuration=0, SneakingMovesLeft=0, BeserkDuration=0, DoublePunchDuration=0, DropKickDuration=0, HeadButtDuration=0, ElbowDuration=0, KneeDuration=0, ClawHandDuration=0, KnifeHandDuration=0, DragonUppercutDuration=0, PowerKickDuration=0, HurricaneKickDuration=0, ShadowCloakDuration=0, Hallucinate=20 WHERE (PlayerID=" & lTPlayerID & ");"
                    bSuccessWithAtLeastOneTarget = True
                End If 'any fail just falls into silence
                rsTarget.MoveNext
            Loop
            Set rsTarget = Nothing
            
            Set rsTarget = MyDB.OpenRecordset("SELECT MobID, MobName, X, Y, Z, MobLevel FROM tblMob WHERE (X= " & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND RespawnDelay=0);", dbOpenSnapshot)
            Do While (Not rsTarget.EOF)
                lTPlayerID = MyCLng(rsTarget!MobID)
                lTX = MyCLng(rsTarget!x)
                lTY = MyCLng(rsTarget!y)
                lTZ = MyCLng(rsTarget!z)
                zTClass = ""
                zTPlayerName = zShortstop(MyCStr(rsTarget!MobName))
                lTCINT = MyCLng(rsTarget!MobLevel)
                lTPlayerLevel = MyCLng(rsTarget!MobLevel)
                If (lRandom(lPCINT + lPPlayerLevel) > lRandom(lTCINT + lTPlayerLevel) + 5) Then
                    MyDB.Execute "UPDATE tblMob SET ShockshieldDuration=0, SanctuaryDuration=0, BlindDuration=3 WHERE (MobID=" & lTPlayerID & ");"
                    bSuccessWithAtLeastOneTarget = True
                End If 'any fail just falls into silence
                rsTarget.MoveNext
            Loop
            Set rsTarget = Nothing
            
            If (bSuccessWithAtLeastOneTarget) Then
                subSendMsgAreaAllDISmart "&R", zPPlayerName, "%s1 look around with sly eyes.", "", "%s1 looks around with sly eyes.", lPX, lPY, lPZ
            Else
                subSendMsg "&rThe Eagle-eye in the sky fails to sabotage anything in the area.", zPortID
            End If
        Else
            subSendMsg "&rYou need at least 1000 move and 500 soul to attempt a sabotage.", zPortID
        End If
    Else
        subSendMsg "&rOnly a Gypsy can Sabotage the area.", zPortID
    End If
    Else
        subSendMsg "&gYou are sleeping and cannot do that at this time.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSabotage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBashInTheDoor(zDir As String, zPortID As String)
On Error GoTo Err_Check 'See Also: zAreaShowDoors
    Dim lBX As Long
    Dim lBY As Long
    Dim lBZ As Long

    Dim rsDoor As Recordset
    Dim lStatus As Long
    Dim lBashLevel As Long
    Dim zDoorName As String
    Dim lDoorID As Long
    Dim lDX As Long
    Dim lDY As Long
    Dim lDZ As Long
    Dim lBashDoorTries As Long
    Dim lBashDoorMax As Long

    Dim lEDmg As Long 'extra dmg
    Dim lDmg As Long
    Dim rsPlayer As Recordset
    Dim zClass As String
    Dim zMessage As String
    Dim zPlayerResult As String
    Dim zPlayerName As String
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lPlayerLevel As Long
    Dim lPlayerID As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCHP As Long
    Dim lOHP As Long
    
    lBX = 0: lBY = 0: lBZ = 0
    Select Case zDir 'we do not do doors ne nw se sw it would look odd
        Case "N", "NORTH"
            lBY = -1
        Case "S", "SOUTH"
            lBY = 1
        Case "W", "WEST"
            lBX = -1
        Case "E", "EAST"
            lBX = 1
        Case "U", "UP"
            lBZ = -1
        Case "D", "DOWN"
            lBZ = 1
    End Select
    
    If (lBX + lBY + lBZ = 0) Then
        subSendMsg "&gBash which Door? Where? BASH <N/S/E/W/U/D>", zPortID
    Else
        Set rsPlayer = MyDB.OpenRecordset("SELECT OHP, Class, PlayerName, PlayerLevel, InvisibilityDuration, PlayerID, CSTR, CINT, CHP, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lPX = MyCLng(rsPlayer!x)
            lPY = MyCLng(rsPlayer!y)
            lPZ = MyCLng(rsPlayer!z)
            zClass = MyCStr(rsPlayer!Class) 'Warriors can bash twice as hard!
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lCStr = MyCLng(rsPlayer!CStr)
            lCINT = MyCLng(rsPlayer!CInt)
            lCHP = MyCLng(rsPlayer!CHP)
            lOHP = MyCLng(rsPlayer!OHP)
        End If
        Set rsPlayer = Nothing
        
        If (lCHP < 100 And lCHP < MyCLng(lOHP / 4)) Then
            subSendMsg "&RYou are in too much agony to even try bashing.", zPortID
        Else
            Set rsDoor = MyDB.OpenRecordset("SELECT BashLevel, Status, DoorName, DoorID, X, Y, Z, BashDoorTries, BashDoorMax FROM tblDoor WHERE (X=" & (lPX + lBX) & " AND Y=" & (lPY + lBY) & " AND Z=" & (lPZ + lBZ) & ");", dbOpenSnapshot)
            If (Not rsDoor.EOF) Then
                lDoorID = MyCLng(rsDoor!DoorID)
                lStatus = MyCLng(rsDoor!Status)
                lBashLevel = MyCLng(rsDoor!BashLevel)
                lBashDoorTries = MyCLng(rsDoor!BashDoorTries)
                lBashDoorMax = MyCLng(rsDoor!BashDoorMax)
                zDoorName = zShortstop(MyCStr(rsDoor!DoorName))
                lDX = MyCLng(rsDoor!x)
                lDY = MyCLng(rsDoor!y)
                lDZ = MyCLng(rsDoor!z)
            End If
            Set rsDoor = Nothing
            
            If (lStatus <> 5 And lStatus <> 7 And lStatus <> 8) Then 'is it a bashable type door?
                subSendMsg "&MYou can only bash a door that is weak at the hinges.", zPortID
            Else
                If (lBashLevel <= lPlayerLevel) Then
                    If (lBashDoorMax = 0) Then 'not a bashable door
                        subSendMsg "&CYou need a key or combination:" & vbCrLf & "&a  ...the Door is magnetically sealed at the hinges.", zPortID
                    Else
                        lEDmg = 8
                        If (zClass = "WA") Then
                            'subSendMsg "&yYou [Warrior] *BASH* into the [" & zDoorName & "] " & zPlayerResult & "!", zPortID
                            'Better INVIS sub: subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 close the " & zDoor & ".", "", "%s1 closed the " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOX, lOY, lOZ
                            'subSendMsgAreaAllInvisibility gblzFNYEL, zPlayerName, lPlayerLevel, lInvisibilityDuration, lCINT, lPlayerID, " Warrior *BASHES* at the [" & zDoorName & "] " & zPlayerResult & "!", lPX, lPY, lPZ
                            subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 *bashes* the " & zDoorName & ".", "", "%s1 *bashes* the " & zTranslateDirection(zDir, 10) & " " & zDoorName & ".", lPX, lPY, lPZ
                            lEDmg = 4
                        Else
                            'subSendMsg "&yYou slam into the [" & zDoorName & "] " & zPlayerResult & "!", zPortID
                            subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 slam into the " & zDoorName & ".", "", "%s1 slams into the " & zTranslateDirection(zDir, 10) & " " & zDoorName & ".", lPX, lPY, lPZ
                        End If
                        subSendMsgAreaAll "&y*BASH* The [" & zDoorName & "] is being broken into.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                        
                        lBashDoorTries = lBashDoorTries + (lRandom(MyCLng(lCStr / lEDmg)) + 1)
                        lCHP = lCHP - (lBashDoorTries + 30)
                        If (lCHP < 1) Then lCHP = 1
                        MyDB.Execute "UPDATE tblPlayer SET CHP=" & lCHP & " WHERE (PlayerID=" & lPlayerID & ");"
                        MyDB.Execute "UPDATE tblDoor SET BashDoorTries=" & lBashDoorTries & " WHERE (BashDoorTries<BashDoorMax AND DoorID=" & lDoorID & ");"
                        
                        If (lBashDoorTries >= lBashDoorMax) Then 'Door flys open and off its hinges
                            Select Case lStatus
                                Case 5
                                    subSendMsgAreaAll "&yThe [" & zDoorName & "] bashes back closed.", lPX, lPY, lPZ
                                    subSendMsgAreaAll "&y*SURPRIZED* The [" & zDoorName & "] bashes closed.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                                Case 7
                                    subSendMsgAreaAll "&yThe [" & zDoorName & "] bashes back open.", lPX, lPY, lPZ
                                    subSendMsgAreaAll "&y*SURPRIZED* The [" & zDoorName & "] bashes back open.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                                Case 8
                                    subSendMsgAreaAll "&yS U C C E S S! The [" & zDoorName & "] flys open and off its hinges!", lPX, lPY, lPZ
                                    subSendMsgAreaAll "&y*SURPRIZED* The [" & zDoorName & "] flys open with a WhAcK n BaSh.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                            End Select
                            subImmortalOpenDoor lDoorID, lStatus
                        End If
                    End If
                Else
                    subSendMsg "&CBash level [" & lBashLevel & "] is higher than your level [" & lPlayerLevel & "]", zPortID
                End If
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subBashInTheDoor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subMagicInTheDoor(zDir As String, zPortID As String)
On Error GoTo Err_Check 'See Also: zAreaShowDoors
    Dim lBX As Long
    Dim lBY As Long
    Dim lBZ As Long

    Dim rsDoor As Recordset
    Dim lStatus As Long
    Dim lMagicLevel As Long
    Dim zDoorName As String
    Dim lDoorID As Long
    Dim lDX As Long
    Dim lDY As Long
    Dim lDZ As Long
    Dim lMagicDoorTries As Long
    Dim lMagicDoorMax As Long

    Dim lEDmg As Long 'extra dmg
    Dim lDmg As Long
    Dim rsPlayer As Recordset
    Dim zClass As String
    Dim zMessage As String
    Dim zPlayerResult As String
    Dim zPlayerName As String
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lPlayerLevel As Long
    Dim lPlayerID As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCMana As Long
    Dim lOMANA As Long
    
    lBX = 0: lBY = 0: lBZ = 0
    Select Case zDir 'we do not do doors ne nw se sw it would look odd
        Case "N", "NORTH"
            lBY = -1
        Case "S", "SOUTH"
            lBY = 1
        Case "W", "WEST"
            lBX = -1
        Case "E", "EAST"
            lBX = 1
        Case "U", "UP"
            lBZ = -1
        Case "D", "DOWN"
            lBZ = 1
    End Select
    
    If (lBX + lBY + lBZ = 0) Then
        subSendMsg "&gMagik which Door? Where? Magic <N/S/E/W/U/D>", zPortID
    Else
        Set rsPlayer = MyDB.OpenRecordset("SELECT OMANA, Class, PlayerName, PlayerLevel, InvisibilityDuration, PlayerID, CSTR, CINT, CMANA, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            lPX = MyCLng(rsPlayer!x)
            lPY = MyCLng(rsPlayer!y)
            lPZ = MyCLng(rsPlayer!z)
            zClass = MyCStr(rsPlayer!Class) 'Warriors can Magic twice as hard!
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lCStr = MyCLng(rsPlayer!CStr)
            lCINT = MyCLng(rsPlayer!CInt)
            lCMana = MyCLng(rsPlayer!CMana)
            lOMANA = MyCLng(rsPlayer!OMANA)
        End If
        Set rsPlayer = Nothing
        
        If (zClass = "GY" Or zClass = "CL" Or zClass = "MO" Or zClass = "MA" Or zClass = "KN" Or zClass = "BA") Then
            If (lCMana < 100 And lCMana < MyCLng(lOMANA / 4)) Then
                subSendMsg "&RYour Mana is depleted too much to try an Majic-unseal.", zPortID
            Else
                Set rsDoor = MyDB.OpenRecordset("SELECT MagicLevel, Status, DoorName, DoorID, X, Y, Z, MagicDoorTries, MagicDoorMax FROM tblDoor WHERE (X=" & (lPX + lBX) & " AND Y=" & (lPY + lBY) & " AND Z=" & (lPZ + lBZ) & ");", dbOpenSnapshot)
                If (Not rsDoor.EOF) Then
                    lDoorID = MyCLng(rsDoor!DoorID)
                    lStatus = MyCLng(rsDoor!Status)
                    lMagicLevel = MyCLng(rsDoor!MagicLevel)
                    lMagicDoorTries = MyCLng(rsDoor!MagicDoorTries)
                    lMagicDoorMax = MyCLng(rsDoor!MagicDoorMax)
                    zDoorName = zShortstop(MyCStr(rsDoor!DoorName))
                    lDX = MyCLng(rsDoor!x)
                    lDY = MyCLng(rsDoor!y)
                    lDZ = MyCLng(rsDoor!z)
                End If
                Set rsDoor = Nothing
                
                If (lStatus <> 10 And lStatus <> 11 And lStatus <> 12) Then 'is it a Magicable type door?
                    subSendMsg "&MYou can only Majic unseal a door that you can overpower.", zPortID
                Else
                    If (lMagicLevel <= lPlayerLevel) Then
                        If (lMagicDoorMax = 0) Then 'not a Magical door
                            subSendMsg "&CYou need a key or combination:" & vbCrLf & "&a  ...the Door is magically sealed!", zPortID
                        Else
                            lEDmg = 8
                            If (zClass = "MA" Or zClass = "CL" Or zClass = "BA") Then
                                'subSendMsg "&yYou [Warrior] *Magic* into the [" & zDoorName & "] " & zPlayerResult & "!", zPortID
                                'Better INVIS sub: subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 close the " & zDoor & ".", "", "%s1 closed the " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOX, lOY, lOZ
                                'subSendMsgAreaAllInvisibility gblzFNYEL, zPlayerName, lPlayerLevel, lInvisibilityDuration, lCINT, lPlayerID, " Warrior *Majics* at the [" & zDoorName & "] " & zPlayerResult & "!", lPX, lPY, lPZ
                                subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 *Majics* the " & zDoorName & ".", "", "%s1 *Majics* the " & zTranslateDirection(zDir, 1) & " " & zDoorName & ".", lPX, lPY, lPZ
                                lEDmg = 4
                            Else
                                'subSendMsg "&yYou slam into the [" & zDoorName & "] " & zPlayerResult & "!", zPortID
                                subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 cast-unseal at the " & zDoorName & ".", "", "%s1 cast-unseal at the " & zTranslateDirection(zDir, 1) & " " & zDoorName & ".", lPX, lPY, lPZ
                            End If
                            subSendMsgAreaAll "&y*Magic* The [" & zDoorName & "] is being broken into.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                            
                            lMagicDoorTries = lMagicDoorTries + (lRandom(MyCLng(lCStr / lEDmg)) + 1)
                            lCMana = lCMana - (lMagicDoorTries + 30)
                            If (lCMana < 1) Then lCMana = 1
                            MyDB.Execute "UPDATE tblPlayer SET CMANA=" & lCMana & " WHERE (PlayerID=" & lPlayerID & ");"
                            MyDB.Execute "UPDATE tblDoor SET MagicDoorTries=" & lMagicDoorTries & " WHERE (MagicDoorTries<MagicDoorMax AND DoorID=" & lDoorID & ");"
                            
                            If (lMagicDoorTries >= lMagicDoorMax) Then 'Door flys open and off its hinges
                                Select Case lStatus
                                    Case 10
                                        subSendMsgAreaAll "&yThe [" & zDoorName & "] Majics back closed.", lPX, lPY, lPZ
                                        subSendMsgAreaAll "&y*SURPRIZED* The [" & zDoorName & "] Majics closed.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                                    Case 11
                                        subSendMsgAreaAll "&yThe [" & zDoorName & "] Majics back open.", lPX, lPY, lPZ
                                        subSendMsgAreaAll "&y*SURPRIZED* The [" & zDoorName & "] Majics back open.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                                    Case 12
                                        subSendMsgAreaAll "&yS U C C E S S! The [" & zDoorName & "] is Magically unsealed!", lPX, lPY, lPZ
                                        subSendMsgAreaAll "&y*SURPRIZED* The [" & zDoorName & "] Majically sealed door is no longer glowing.", lPX + lBX + lBX, lPY + lBY + lBY, lPZ + lBZ + lBZ
                                End Select
                                subImmortalOpenDoor lDoorID, lStatus
                            End If
                        End If
                    Else
                        subSendMsg "&CMagic level [" & lMagicLevel & "] is higher than your level [" & lPlayerLevel & "]", zPortID
                    End If
                End If
            End If
        Else
            subSendMsg "&COnly GYPSY, CLERIC, MAGE, MONK, BARD, or a KNIGHT can try to majically unseal a door.", zPortID
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subMagicInTheDoor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalOpenDoor(lDoorID As Long, lStatus As Long)
'See also: zTranslateDoorStatus
On Error GoTo Err_Check
    Dim lNewStatus As Long
    Dim lNewResetTimer As Long
    
    lNewStatus = lStatus
    lNewResetTimer = 4 'we reset doors after 15 mins * this long

    '0 = Always Open, 1 = Unlocked, 2 = Locked, 3=open but is locakable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and not lockable, 7 = Bashed closed, 8 = Bashable (meaning cannot open)
    Select Case lNewStatus
        Case 5 'bashed open so we bash it back closed
            lNewStatus = 7
            MyDB.Execute "UPDATE tblDoor SET Status=" & lNewStatus & ", ResetTimer=" & lNewResetTimer & " WHERE (DoorID=" & lDoorID & ");"
        Case 7 'bashed closed so we bash it back open
            lNewStatus = 5
            MyDB.Execute "UPDATE tblDoor SET Status=" & lNewStatus & ", ResetTimer=" & lNewResetTimer & " WHERE (DoorID=" & lDoorID & ");"
        Case 8 'bashable, so we bash it open and off its hinges
            lNewStatus = 5
            MyDB.Execute "UPDATE tblDoor SET BashDoorTries=BashDoorMax, Status=" & lNewStatus & ", ResetTimer=" & lNewResetTimer & " WHERE (DoorID=" & lDoorID & ");"
        Case 10 'opened with Majic, waste of mana, and we majically close it but let the server seal it in a few mins
            lNewStatus = 11
            MyDB.Execute "UPDATE tblDoor SET Status=" & lNewStatus & ", ResetTimer=" & lNewResetTimer & " WHERE (DoorID=" & lDoorID & ");"
        Case 11 'closed with Majic, waste of mana, majically opens, server will seal it in a few mins
            lNewStatus = 10
            MyDB.Execute "UPDATE tblDoor SET Status=" & lNewStatus & ", ResetTimer=" & lNewResetTimer & " WHERE (DoorID=" & lDoorID & ");"
        Case 12 'Majically Sealed that will be unsealed
            lNewStatus = 10
            MyDB.Execute "UPDATE tblDoor SET BashDoorTries=BashDoorMax, Status=" & lNewStatus & ", ResetTimer=" & lNewResetTimer & " WHERE (DoorID=" & lDoorID & ");"
    End Select

    'subRotateTheWorld resets all doors ie. 5 and 7 both reset to 8 so its rebashable
    Exit Sub
Err_Check:
    subWriteErrorFile "subBashInTheDoor," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subUseUnlock(zWord2 As String, zWord3 As String, zWord4 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lInvisibilityDuration As Long
    Dim lLockPickToolBonus As Long
    Dim lStatus As Long
    Dim lPlayerLevel As Long
    Dim lCCHA As Long
    Dim lCDEX As Long
    Dim lCSoul As Long
    Dim lCMove As Long
    Dim zClass As String
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,PlayerName,X,Y,Z,Status,InvisibilityDuration,LockPickToolBonus, PlayerLevel, Class, CDEX, CSoul, CMove, CCHA FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lStatus = MyCLng(rsPlayer!Status)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lLockPickToolBonus = MyCLng(rsPlayer!LockPickToolBonus)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        zClass = MyCStr(rsPlayer!Class)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lCMove = MyCLng(rsPlayer!CMove)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        If (lStatus <> 50) Then
            If (Len(zWord3) > 0) Then
                Select Case MyCStr(Mid(UCase(zWord2), 1, 3))
                    Case "LEV", "KNO", "BUT" 'USE LEVER or KNOB or BUTTON in room
                        subDoorLever zPortID, zPlayerName, zWord3, lX, lY, lZ, lPlayerID, lInvisibilityDuration
                    Case "KEY", "PIC" 'keyring keys pick lock key
                        subDoorUseKey zPortID, zPlayerName, zWord3, lX, lY, lZ, lPlayerID, MyCStr(Mid(UCase(zWord2), 1, 4)), lLockPickToolBonus, lPlayerLevel, zClass, lCDEX, lCSoul, lCMove, lInvisibilityDuration, lCCHA
                    Case "COM"
                        subObjectUseCombo zPortID, zPlayerName, zWord3, zWord4, lX, lY, lZ, lPlayerID
                    Case Else
                        subSendMsg "&GUse what?", zPortID
                End Select
            Else
                subSendMsg "&GCOMMAND: USE LEVER (lever name)" & vbCrLf & "         USE KNOB (knob name)" & vbCrLf & "         USE KEY (direction)" & vbCrLf & "         USE Combination (object name) (combination code)" & vbCrLf & "         USE PICK (direction)", zPortID
            End If
        Else
            subSendMsg "&GYou dream of doing stuff.", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subUseUnlock", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subUseUnlock," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDoorUseKey(zPortID As String, zPlayerName As String, zDir As String, lOX As Long, lOY As Long, lOZ As Long, lOPlayerID As Long, zType As String, lLockPickToolBonus As Long, lOPlayerLevel As Long, zOClass As String, lCDEX As Long, lCSoul As Long, lCMove As Long, lInvisibilityDuration As Long, lCCHA As Long)
On Error GoTo Err_Check
    Dim rsDoor As Recordset
    Dim rsCArea As Recordset
    Dim rsKey As Recordset
    Dim lStatus As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lOSX As Long 'Other side of the door
    Dim lOSY As Long
    Dim lOSZ As Long
    Dim bWeHaveKey As Boolean
    Dim bPickLock As Boolean
    Dim lCostSoul As Long
    Dim lCostMove As Long
    Dim zDoor As String
    Dim zColourObjectName As String
    Dim zColourDoorName As String
    Dim zSearchDir As String
    Dim bOpenPassage As Boolean
    Dim zSearchDoorName As String
    Dim bFoundDoor As Boolean
    
    zSearchDoorName = UCase(zDir)
    zSearchDir = zTranslateDirection(zSearchDoorName, 0)
    
    'Debug.Print zSearchDir & " " & zSearchDoorName
    'subSendMsgAreaAllDISmart "&B", zOPlayerName, "%s1 unlock " & zDoorName & ".", "", "%s1 unlocks " & zDoorName & ".", lOX, lOY, lOZ
    If (Len(zSearchDoorName) > 0) Then
        'Check doors first
        Select Case zSearchDir
            Case "N", "S", "E", "W", "U", "D" 'doors shouldnt go diagnal
                bFoundDoor = True
            Case Else
                'we find the direction with the door name
                'the user didn't provide the direction OPEN DIRECTION so we try to come up with one
                Set rsDoor = MyDB.OpenRecordset("SELECT * FROM tblDoor WHERE (((tblDoor.DoorName) Like '*" & zSearchDoorName & "*') AND ((tblDoor.X)=" & lOX & " Or (tblDoor.X)=" & lOX & "-1 Or (tblDoor.X)=" & lOX & "+1) AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.DoorName) Like '*" & zSearchDoorName & "*') AND ((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & " Or (tblDoor.Y)=" & lOY & "-1 Or (tblDoor.Y)=" & lOY & "+1) AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.DoorName) Like '*" & zSearchDoorName & "*') AND ((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & "-1 Or (tblDoor.Z)=" & lOZ & "+1)) ORDER BY tblDoor.DoorName;", dbOpenSnapshot)
                bFoundDoor = (Not rsDoor.EOF)
                If (bFoundDoor) Then
                    lTX = rsDoor!x
                    lTY = rsDoor!y
                    lTZ = rsDoor!z
                End If
                Set rsDoor = Nothing
                
                If (bFoundDoor) Then
                    If (lTX < lOX) Then zSearchDir = "W"
                    If (lTX > lOX) Then zSearchDir = "E"
                    If (lTY < lOY) Then zSearchDir = "N"
                    If (lTY > lOY) Then zSearchDir = "S"
                    If (lTZ < lOZ) Then zSearchDir = "U"
                    If (lTZ > lOZ) Then zSearchDir = "D"
                End If
        End Select
        
        If (bFoundDoor) Then
            subDirectionControl lTX, lTY, lTZ, lOX, lOY, lOZ, zSearchDir
            subDirectionControl lOSX, lOSY, lOSZ, lTX, lTY, lTZ, zSearchDir

            Set rsDoor = MyDB.OpenRecordset("SELECT * FROM tblDoor WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbOpenDynaset)
            If (Not rsDoor.EOF) Then
                Set rsCArea = MyDB.OpenRecordset("SELECT HiddenExits, BlockedExits FROM tblArea WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
                If (Not rsCArea.EOF) Then
                    'HiddenExits BlockedExits
                    '1N 2S 3E 4W 5NE 6NW 7SE 8SW 9U 10D
                    Select Case zTranslateDirection(zSearchDir, 0) 'First we check to see if its hidden
                        Case "N"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 1, 1) <> "1")
                        Case "S"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 2, 1) <> "1")
                        Case "E"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 3, 1) <> "1")
                        Case "W"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 4, 1) <> "1")
                        Case "NE"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 5, 1) <> "1")
                        Case "NW"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 6, 1) <> "1")
                        Case "SE"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 7, 1) <> "1")
                        Case "SW"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 8, 1) <> "1")
                        Case "U"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 9, 1) <> "1")
                        Case "D"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 10, 1) <> "1")
                    End Select
                    
                    If (bOpenPassage) Then 'Now we check for blocked
                        Select Case zTranslateDirection(zSearchDir, 0)
                            Case "N"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 1, 1) <> "1")
                            Case "S"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 2, 1) <> "1")
                            Case "E"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 3, 1) <> "1")
                            Case "W"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 4, 1) <> "1")
                            Case "NE"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 5, 1) <> "1")
                            Case "NW"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 6, 1) <> "1")
                            Case "SE"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 7, 1) <> "1")
                            Case "SW"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 8, 1) <> "1")
                            Case "U"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 9, 1) <> "1")
                            Case "D"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 10, 1) <> "1")
                        End Select
                    End If
                End If
                Set rsCArea = Nothing
                
                If (bOpenPassage) Then
                    zDoor = zShortstop(MyCStr(rsDoor!DoorName))
                    If (MyCLng(rsDoor!LockPickBrokenLockDuration) = 0) Then
                        bWeHaveKey = False
                        bPickLock = False
                        
                        'We check to see if we have a key that fits that door and we make sure the key is equipped.
                        Select Case zType
                            Case "PICK"
                                lCostSoul = (MyCLng(rsDoor!LockPickPlayerChance) * (15 - lTranslateThiefPickLock(zOClass)))
                                lCostMove = (MyCLng(rsDoor!LockPickPlayerChance) * (25 - lTranslateThiefPickLock(zOClass)))
                                If (lLockPickToolBonus > 0) Then
                                    If (lCMove >= lCostMove) Then
                                        If (lCSoul >= lCostSoul) Then
                                            MyDB.Execute "UPDATE tblPlayer SET CSoul = [CSoul]-" & lCostSoul & ", CMove = [CMove]-" & lCostMove & " WHERE (PlayerID=" & lOPlayerID & ");", dbFailOnError
                                            If (MyCLng(rsDoor!LockPickPlayerChance) > 0) Then
                                                If (lRandom(lCDEX + (lRandom(lLockPickToolBonus) * lTranslateThiefPickLock(zOClass)) + lOPlayerLevel) > lRandom(MyCLng(rsDoor!LockPickPlayerChance))) Then
                                                    bPickLock = True
                                                    'subSendMsg "&GYou masterfully - P I C K E D - the lock on the " & zDoor & "!", zPortID
                                                    'subSendMsgAreaExcept2 gblzFBGRE & zOPlayerName & " masterfully - P I C K E D - the lock on the " & zDoor & "!", lOSX, lOSY, lOSZ, zPortID, ""
                                                    subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 pick the lock on the " & zDoor & ".", "", "%s1 picks the lock on the " & zDoor & ".", lOX, lOY, lOZ
                                                Else
                                                    If (lRandom(lCDEX + (lRandom(lLockPickToolBonus) * lTranslateThiefPickLock(zOClass)) + lOPlayerLevel) < lRandom(MyCLng(rsDoor!LockPickPlayerChance))) Then 'We try not to bust the lock with the same skill roll.
                                                        rsDoor.Edit
                                                        rsDoor!LockPickBrokenLockDuration = 5
                                                        rsDoor.Update
                                                        subSendMsgAreaAllDISmart "&R", zPlayerName, "During a picklock %s1 busted the lock on the " & zDoor & ".", "", "During a picklock %s1 busted the lock on the " & zDoor & ".", lOX, lOY, lOZ
                                                        'subSendMsg "&RYou - B U S T E D - the door knob and lock on the " & zDoor & "!", zPortID
                                                        'subSendMsgAreaExcept2 "&R" & zOPlayerName & " - B U S T E D - the door knob and lock on the " & zDoor & ".", lOSX, lOSY, lOSZ, zPortID, ""
                                                    Else
                                                        subSendMsgAreaAllDISmart "&g", zPlayerName, "%s1 fooled with the lock on the " & zDoor & ". Nothing.", "", "%s1 fooled with the lock on the " & zDoor & ". Nothing.", lOX, lOY, lOZ
                                                        'subSendMsg "&yYou work with the door knob and lock and nothing is happening.", zPortID
                                                        'subSendMsgAreaExcept2 gblzFNYEL & zOPlayerName & " failed to pick the lock of the " & MyCStr(rsDoor!DoorName) & ".", lOSX, lOSY, lOSZ, zPortID, ""
                                                    End If
                                                End If
                                            Else
                                                subSendMsgAreaAllDISmart "&g", zPlayerName, "%s1 realize the lock on the " & zDoor & " is not pickable.", "", "%s1 realizes that the lock on the " & zDoor & " is not pickable.", lOX, lOY, lOZ
                                                'subSendMsg "&gThe lock on the " & zDoor & " is not pickable.", zPortID
                                                'subSendMsgAreaExcept2 gblzFNYEL & zOPlayerName & " notices no possible way to pick the lock on the " & zDoor & ".", lOSX, lOSY, lOSZ, zPortID, ""
                                            End If
                                        Else
                                            subSendMsg "&gTo pick the " & zDoor & " you need " & (lCostSoul - lCSoul) & " more soul points.", zPortID
                                        End If
                                    Else
                                        subSendMsg "&gTo pick the " & zDoor & " you need " & (lCostMove - lCMove) & " more move points.", zPortID
                                    End If
                                Else
                                    subSendMsg "&RYou require a set of lock picks to do that.", zPortID
                                End If
                            Case "KEY"
                                Set rsKey = MyDB.OpenRecordset("SELECT tblObject.DoorID, tblPlayerInventoryItems.PlayerID FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblObject.DoorID)=" & MyCLng(rsDoor!DoorID) & ") AND ((tblPlayerInventoryItems.PlayerID)=" & lOPlayerID & "));", dbOpenSnapshot)
                                bWeHaveKey = (Not rsKey.EOF)
                                Set rsKey = Nothing
                                If (Not bWeHaveKey) Then 'check inventory
                                    Set rsKey = MyDB.OpenRecordset("SELECT tblObject.DoorID, tblPlayerInventoryItems.PlayerID FROM tblPlayerInventoryItems INNER JOIN (tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ObjectID) ON tblPlayerInventoryItems.ObjectID = tblPlayerContainer.ContainerObjectID WHERE (((tblObject.DoorID)=" & MyCLng(rsDoor!DoorID) & ") AND ((tblPlayerInventoryItems.PlayerID)=" & lOPlayerID & "));", dbOpenSnapshot)
                                    bWeHaveKey = (Not rsKey.EOF)
                                    Set rsKey = Nothing
                                    
                                    If (Not bWeHaveKey) Then 'check key in a container in inventory
                                        Set rsKey = MyDB.OpenRecordset("SELECT tblObject.DoorID, tblPlayerInventoryItems.PlayerID FROM tblPlayerInventoryItems INNER JOIN (tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ObjectID) ON tblPlayerInventoryItems.ObjectID = tblPlayerContainer.ContainerObjectID WHERE (((tblObject.DoorID)=" & MyCLng(rsDoor!DoorID) & ") AND ((tblPlayerInventoryItems.PlayerID)=" & lOPlayerID & "));", dbOpenSnapshot)
                                        bWeHaveKey = (Not rsKey.EOF)
                                        Set rsKey = Nothing
                                    End If
                                    
                                    If (Not bWeHaveKey) Then
                                        subSendMsg "&yYou do not have the right key in your inventory for the " & MyCStr(rsDoor!DoorName) & ".", zPortID
                                    End If
                                End If
                        End Select
                        
                        If (bWeHaveKey Or bPickLock) Then
                            rsDoor.Edit
                            lStatus = MyCLng(rsDoor!Status)
                            rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                            Select Case lStatus '0 = Always Open, 1 = Unlocked, 2 = Locked, 3=open but is locakable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and not lockable, 7 = Bashed closed, 8 = Bashable (meaning cannot open)
                                Case 1, 3 'Door is unlocked
                                    rsDoor!Status = 2 'Lock door
                                    If (lStatus = 3) Then
                                        subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 close the " & zDoor & ".", "", "%s1 closed the " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOX, lOY, lOZ
                                        'subSendMsg "&gYou close the " & zDoor & ".", zPortID
                                        'subSendMsgAreaExcept2 gblzFNGRE & zOPlayerName & " closes " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOSX, lOSY, lOSZ, zPortID, ""
                                    End If
                                    'subSendMsg "&gYou lock the " & zDoor & ".", zPortID
                                    'subSendMsgAreaExcept2 gblzFNGRE & zOPlayerName & " locks the " & zTranslateDirection(zSearchDir, 3) & " " & zDoor & ".", lOX, lOY, lOZ, zPortID, ""
                                    subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 lock the " & zDoor & ".", "", "%s1 locks the " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOX, lOY, lOZ
                                    subSendMsgAreaAll gblzFNGRE & "You hear a click from " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOSX, lOSY, lOSZ
                                Case 2 'Door is locked
                                    rsDoor!Status = 1 'Unlock door
                                    subSendMsgAreaAllDISmart "&a", zPlayerName, "%s1 unlock the " & zDoor & ".", "", "%s1 unlocked the " & zTranslateDirection(zSearchDir, 3) & " " & zDoor & ".", lOX, lOY, lOZ
                                    'subSendMsg "&gYou unlock the " & zDoor & ".", zPortID
                                    'subSendMsgAreaExcept2 gblzFNGRE & zOPlayerName & " unlocks the " & zTranslateDirection(zSearchDir, 3) & " " & zDoor & ".", lOX, lOY, lOZ, zPortID, ""
                                    subSendMsgAreaAll gblzFNGRE & "You hear a click from " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOSX, lOSY, lOSZ
                                Case Else
                                    subSendMsgAreaAllDISmart "&g", zPlayerName, "%s1 try some keys on the " & zDoor & ". No luck.", "", "%s1 tried some keys on the " & zTranslateDirection(zSearchDir, 3) & " " & zDoor & ". No Luck.", lOX, lOY, lOZ
                                    'subSendMsg "&gThere is nothing on you that fits the " & zDoor & ".", zPortID
                                    'subSendMsgAreaExcept2 gblzFNGRE & zOPlayerName & " pulls on the " & zTranslateDirection(zSearchDir, 3) & " " & zDoor & " in frustration.", lOX, lOY, lOZ, zPortID, ""
                                    subSendMsgAreaAll gblzFNGRE & "You hear a gingling noise coming from " & zTranslateDirection(zSearchDir, 1) & " " & zDoor & ".", lOSX, lOSY, lOSZ
                            End Select
                            rsDoor.Update
                        End If
                    Else
                        subSendMsg "&RThe door knob and lock are - B U S T E D - you will have to try again later!", zPortID
                    End If
                Else
                    subSendMsg "&gYou do not see a door there.", zPortID
                End If
            Else
                subSendMsg "&gYou do not see a door there.", zPortID
                bFoundDoor = False
            End If
        End If
        
        If (Not bFoundDoor) Then
            'Now try to open an object on the ground, it has to be on the gound to open it.
            Set rsDoor = Nothing
            Set rsDoor = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, LockStatus FROM tblObject WHERE (LockStatus <> 0 AND X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND ObjectName Like ""*" & zSearchDoorName & "*"") ORDER BY ObjectName;", dbOpenDynaset)
            If (Not rsDoor.EOF) Then
                zColourDoorName = zShortstop((MyCStr(rsDoor!ObjectName)))
                'We check for an inventory key that fits the object.
                Set rsKey = MyDB.OpenRecordset("SELECT tblPlayerInventoryItems.PlayerID, tblObject.ObjectName, tblObject.ObjectID  FROM tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lOPlayerID & ") AND ((tblObject.LockKeyID)=" & MyCLng(rsDoor!ObjectID) & "));", dbOpenSnapshot)
                Select Case MyCLng(rsDoor!LockStatus)
                    Case 20, 30 'already open
                        subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourDoorName & " is already open.", "", "%s1 realizes the " & zColourDoorName & " is already open.", lOX, lOY, lOZ, "", False
                    Case 21 'closed (unlocked) and can be opened
                        If (Not rsKey.EOF) Then
                            zColourObjectName = (zShortstop(MyCStr(rsKey!ObjectName)))
                            rsDoor.Edit
                            rsDoor!LockStatus = 22 'Closed and locked
                            rsDoor.Update
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " locks the " & zColourDoorName & ".", "", "%s1 turns the " & zColourObjectName & " and locks the " & zColourDoorName & ".", lOX, lOY, lOZ, "", False
                        Else
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourDoorName & " is key lockable but you are not holding the key.", "", "%s1 looks quizzically at the locked " & zColourDoorName & ".", lOX, lOY, lOZ, "", False
                        End If
                    Case 22 'use key required
                        'We check to see if we have a key that fits that chest and we make sure the key is equipped.
                        If (Not rsKey.EOF) Then
                            zColourObjectName = (zShortstop(MyCStr(rsKey!ObjectName)))
                            rsDoor.Edit
                            rsDoor!LockStatus = 21 'Closed and unlocked
                            rsDoor.Update
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " unlocks the " & zColourDoorName & ".", "", "%s1 turns the " & zColourObjectName & " and unlocks the " & zColourDoorName & ".", lOX, lOY, lOZ, "", False
                            If (lRandom(lCCHA) < lRandom(500)) Then
                                MyDB.Execute "UPDATE tblObject SET ObjectName='used key, rests here', LockKeyID=0 WHERE (ObjectID=" & MyCLng(rsKey!ObjectID) & ");", dbFailOnError
                            Else
                                subSendMsg "&GYour charisma preserves the key for another use!", zPortID
                            End If
                        Else
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "You are not holding the key for the " & zColourDoorName & ".", "", "%s1 is looking for a key to the " & zColourDoorName & ".", lOX, lOY, lOZ, "", False
                        End If
                    Case 31, 32 'use combination required
                        subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourDoorName & " is combination locked.", "", "%s1 looks quizzically at the combination locked " & zColourDoorName & ".", lOX, lOY, lOZ, "", False
                    Case Else 'not a container
                        subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourDoorName & " is not a container.", "", "%s1 looks quizzically at the " & zColourDoorName & ".", lOX, lOY, lOZ, "", False
                End Select
                Set rsKey = Nothing
            Else
                subSendMsg "&gThat doesn't seem to be in the area.", zPortID
            End If
        End If
        Set rsDoor = Nothing
    Else
        subSendMsg "&GCOMMAND: USE KEY [direction]" & vbCrLf & "The key object must be equipped.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDoorUseKey," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDoorOpen(zPortID As String, zPlayerName As String, zDir As String, lOX As Long, lOY As Long, lOZ As Long, lPlayerID As Long, lStatus As Long)
On Error GoTo Err_Check
    Dim rsCArea As Recordset
    Dim rsDoor As Recordset
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lOSX As Long 'Other side of the door
    Dim lOSY As Long
    Dim lOSZ As Long
    Dim bOpenPassage As Boolean
    Dim zColourObjectName As String
    Dim bFoundDoor As Boolean
    Dim zSearchObjectName As String
    Dim zSearchDir As String
    Dim zDoorName As String
    
    'The massive black door to the north swings open. Standing on the other side is Trisker.
    zSearchObjectName = zDir
    zSearchDir = zDir
    If (lStatus <> 50) Then
        If (Len(zSearchDir) > 0) Then
            bOpenPassage = False
            
            Select Case zTranslateDirection(zSearchDir, 0)
                Case "N", "S", "E", "W", "U", "D" 'doors shouldnt go diagnal
                Case Else
                    'the user didn't provide the direction OPEN DIRECTION so we try to come up with one
                    Set rsDoor = MyDB.OpenRecordset("SELECT * FROM tblDoor WHERE (((tblDoor.DoorName) Like '*" & zSearchDir & "*') AND ((tblDoor.X)=" & lOX & " Or (tblDoor.X)=" & lOX & "-1 Or (tblDoor.X)=" & lOX & "+1) AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.DoorName) Like '*" & zSearchDir & "*') AND ((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & " Or (tblDoor.Y)=" & lOY & "-1 Or (tblDoor.Y)=" & lOY & "+1) AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.DoorName) Like '*" & zSearchDir & "*') AND ((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & "-1 Or (tblDoor.Z)=" & lOZ & "+1)) ORDER BY tblDoor.DoorName;", dbOpenSnapshot)
                    bFoundDoor = (Not rsDoor.EOF)
                    If (bFoundDoor) Then
                        lTX = rsDoor!x
                        lTY = rsDoor!y
                        lTZ = rsDoor!z
                        
                        If (lTX < lOX) Then zSearchDir = "WEST"
                        If (lTX > lOX) Then zSearchDir = "EAST"
                        If (lTY < lOY) Then zSearchDir = "NORTH"
                        If (lTY > lOY) Then zSearchDir = "SOUTH"
                        If (lTZ < lOZ) Then zSearchDir = "UP"
                        If (lTZ > lOZ) Then zSearchDir = "DOWN"
                    End If
                    Set rsDoor = Nothing
            End Select
            
            subDirectionControl lTX, lTY, lTZ, lOX, lOY, lOZ, zSearchDir 'use opening side of the door
            subDirectionControl lOSX, lOSY, lOSZ, lTX, lTY, lTZ, zSearchDir 'other side of the door
            
            Set rsDoor = MyDB.OpenRecordset("SELECT * FROM tblDoor WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ") ORDER BY DoorName;", dbOpenDynaset)
            If (Not rsDoor.EOF) Then
                Set rsCArea = MyDB.OpenRecordset("SELECT HiddenExits, BlockedExits FROM tblArea WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
                If (Not rsCArea.EOF) Then
                    'HiddenExits BlockedExits
                    '1N 2S 3E 4W 5NE 6NW 7SE 8SW 9U 10D
                    Select Case zTranslateDirection(zSearchDir, 0) 'First we check to see if its hidden
                        Case "N"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 1, 1) <> "1")
                        Case "S"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 2, 1) <> "1")
                        Case "E"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 3, 1) <> "1")
                        Case "W"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 4, 1) <> "1")
                        Case "NE"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 5, 1) <> "1")
                        Case "NW"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 6, 1) <> "1")
                        Case "SE"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 7, 1) <> "1")
                        Case "SW"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 8, 1) <> "1")
                        Case "U"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 9, 1) <> "1")
                        Case "D"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 10, 1) <> "1")
                    End Select
                    
                    If (bOpenPassage) Then 'Now we check for blocked
                        Select Case zTranslateDirection(zSearchDir, 0)
                            Case "N"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 1, 1) <> "1")
                            Case "S"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 2, 1) <> "1")
                            Case "E"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 3, 1) <> "1")
                            Case "W"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 4, 1) <> "1")
                            Case "NE"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 5, 1) <> "1")
                            Case "NW"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 6, 1) <> "1")
                            Case "SE"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 7, 1) <> "1")
                            Case "SW"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 8, 1) <> "1")
                            Case "U"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 9, 1) <> "1")
                            Case "D"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 10, 1) <> "1")
                        End Select
                    End If
                End If
                Set rsCArea = Nothing
                
                If (bOpenPassage) Then
                    Do While (Not rsDoor.EOF)
                        zDoorName = zShortstop(MyCStr(rsDoor!DoorName))
                        Select Case MyCInt(rsDoor!Status) '0 = Open and not lockable, 1 = Unlocked, 2 = Locked, 3=open but is locakable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed but not lockable, 7 = Bashed Closed, 8=Bashable [closed/locked]
                            Case 6 'regular door
                                rsDoor.Edit
                                rsDoor!Status = 0
                                rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "You swing open the " & zDoorName & ".", "", "%s1 swings open the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " swings open." & vbCrLf & "Standing on the other side is %s1.", lOSX, lOSY, lOSZ, "", False
                                subLookPeek zPortID, zSearchDir, False
                            Case 1 'lockable
                                rsDoor.Edit
                                rsDoor!Status = 3
                                rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "You swing open the " & zDoorName & ".", "", "%s1 swings open the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " swings open." & vbCrLf & "Standing on the other side is %s1.", lOSX, lOSY, lOSZ, "", False
                                subLookPeek zPortID, zSearchDir, False
                            Case 7 'bashed closed, subRotateTheWorld resets 5 or 7 back to 8 [bashable]
                                rsDoor.Edit
                                rsDoor!Status = 5 'we open it
                                rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "You kick open the " & zDoorName & ".", "", "%s1 kicks open the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is kicked open." & vbCrLf & "Standing on the other side is %s1.", lOSX, lOSY, lOSZ, "", False
                                subLookPeek zPortID, zSearchDir, False
                            Case 5 'bashed open, subRotateTheWorld resets 5 or 7 back to 8 [bashable]
                                subSendMsgAreaAllDISmart "&M", zPlayerName, zDoorName & " is already bashed open after a kick from you.", "", "%s1 kicks the already open " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                'subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is already bashed open." & vbCrLf & "Standing on the other side is %s1.", lOSX, lOSY, lOSZ, "", False
                                subLookPeek zPortID, zSearchDir, False
                            Case 8 'Bashable [closed n locked]
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zDoorName & " is bashable.", "", "%s1 realizes the " & zDoorName & " is bashable.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is being kicked by someone.", lOSX, lOSY, lOSZ, "", False
                            Case 11 'magically closed
                                rsDoor.Edit
                                rsDoor!Status = 10 'once magically unlocked you can just open and close it
                                rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, zDoorName & " is no longer magically sealed.", "", "%s1 heaves open the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is already bashed open." & vbCrLf & "Standing on the other side is %s1.", lOSX, lOSY, lOSZ, "", False
                                subLookPeek zPortID, zSearchDir, False
                            Case 12 'Magically sealed [closed n locked]
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zDoorName & " is magically sealed.", "", "%s1 realizes the " & zDoorName & " is magically sealed.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is making magical-sealed noises.", lOSX, lOSY, lOSZ, "", False
                            Case 2, 4
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zDoorName & " is locked.", "", "%s1 realizes the " & zDoorName & " is locked.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is making noises.", lOSX, lOSY, lOSZ, "", False
                            Case Else
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zDoorName & " is already open.", "", "%s1 realizes the " & zDoorName & " is already open.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is making noises.", lOSX, lOSY, lOSZ, "", False
                        End Select
                        rsDoor.MoveNext
                    Loop
                Else
                    subSendMsg "&gYou do not see a door there.", zPortID
                End If
            Else
                'Now try to open an object container in the area
                Set rsDoor = Nothing
                Set rsDoor = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, LockStatus FROM tblObject WHERE (Burried=False) AND (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ") AND (ObjectName Like '*" & zSearchObjectName & "*') AND (Status=0) AND (Len([LockCombo])<>0 OR LockKeyID<>0 OR LockStatus<>0 OR WeightMax<>0 OR VisibleLevel=0);", dbOpenDynaset)
                If (Not rsDoor.EOF) Then
                    Do While (Not rsDoor.EOF)
                        zColourObjectName = (zShortstop(MyCStr(rsDoor!ObjectName)))
                        Select Case MyCLng(rsDoor!LockStatus)
                            Case 10, 20, 30 'already open
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is already open.", "", "%s1 realizes the " & zColourObjectName & " is already open.", lOX, lOY, lOZ, "", False
                            Case 21 'closed (unlocked) but can be opened
                                rsDoor.Edit
                                rsDoor!LockStatus = 20
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " swings open.", "", "%s1 swings open the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                            Case 31 'closed (unlocked) but can be opened
                                rsDoor.Edit
                                rsDoor!LockStatus = 30
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " swings open.", "", "%s1 swings open the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                            Case 22 'use key required
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is key locked.", "", "%s1 glances a moment at the lock on the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                            Case 32 'use combination required
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is combination locked.", "", "%s1 glances a moment at the combination lock on the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                            Case Else 'not a container
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is not a container.", "", "%s1 looks over the " & zColourObjectName & " for an opening.", lOX, lOY, lOZ, "", False
                        End Select
                        rsDoor.MoveNext
                    Loop
                Else
                    subSendMsg "&GThere is nothing here to open like that.", zPortID
                End If
            End If
            Set rsDoor = Nothing
        Else
            subSendMsg "&GCOMMAND: OPEN (object/door direction)", zPortID
        End If
    Else
        subSendMsg "&GYou dream of opening and closing doors.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDoorOpen," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDoorClose(zPortID As String, zPlayerName As String, zDir As String, lOX As Long, lOY As Long, lOZ As Long, lPlayerID As Long, lStatus As Long)
On Error GoTo Err_Check
    Dim bFoundDoor As Boolean
    Dim rsCArea As Recordset
    Dim rsDoor As Recordset
    Dim bOpenPassage As Boolean
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lOSX As Long 'Other side of the door
    Dim lOSY As Long
    Dim lOSZ As Long
    Dim zColourObjectName As String
    Dim zSearchObjectName As String
    Dim zSearchDir As String
    Dim zDoorName As String
    
    zSearchObjectName = zDir
    zSearchDir = zDir
    
    If (lStatus <> 50) Then
        If (Len(zSearchDir) > 0) Then
            Select Case zTranslateDirection(zSearchDir, 0)
                Case "N", "S", "E", "W", "U", "D" 'doors shouldnt go diagnal
                Case Else
                    'the user didn't provide the direction OPEN DIRECTION so we try to come up with one
                    Set rsDoor = MyDB.OpenRecordset("SELECT * FROM tblDoor WHERE (((tblDoor.DoorName) Like '*" & zSearchDir & "*') AND ((tblDoor.X)=" & lOX & " Or (tblDoor.X)=" & lOX & "-1 Or (tblDoor.X)=" & lOX & "+1) AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.DoorName) Like '*" & zSearchDir & "*') AND ((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & " Or (tblDoor.Y)=" & lOY & "-1 Or (tblDoor.Y)=" & lOY & "+1) AND ((tblDoor.Z)=" & lOZ & ")) OR (((tblDoor.DoorName) Like '*" & zSearchDir & "*') AND ((tblDoor.X)=" & lOX & ") AND ((tblDoor.Y)=" & lOY & ") AND ((tblDoor.Z)=" & lOZ & "-1 Or (tblDoor.Z)=" & lOZ & "+1)) ORDER BY tblDoor.DoorName;", dbOpenSnapshot)
                    bFoundDoor = (Not rsDoor.EOF)
                    If (bFoundDoor) Then
                        lTX = rsDoor!x
                        lTY = rsDoor!y
                        lTZ = rsDoor!z
                        
                        If (lTX < lOX) Then zSearchDir = "WEST"
                        If (lTX > lOX) Then zSearchDir = "EAST"
                        If (lTY < lOY) Then zSearchDir = "NORTH"
                        If (lTY > lOY) Then zSearchDir = "SOUTH"
                        If (lTZ < lOZ) Then zSearchDir = "UP"
                        If (lTZ > lOZ) Then zSearchDir = "DOWN"
                    End If
                    Set rsDoor = Nothing
            End Select
            
            subDirectionControl lTX, lTY, lTZ, lOX, lOY, lOZ, zSearchDir 'we find the door at ltx lty ltz
            subDirectionControl lOSX, lOSY, lOSZ, lTX, lTY, lTZ, zSearchDir 'we now find the other side of the door where someone might be
            
            Set rsDoor = MyDB.OpenRecordset("SELECT * FROM tblDoor WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ") ORDER BY DoorName;", dbOpenDynaset)
            If (Not rsDoor.EOF) Then
                zDoorName = zShortstop(MyCStr(rsDoor!DoorName))
                Set rsCArea = MyDB.OpenRecordset("SELECT HiddenExits, BlockedExits FROM tblArea WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
                If (Not rsCArea.EOF) Then
                    'HiddenExits BlockedExits
                    '1N 2S 3E 4W 5NE 6NW 7SE 8SW 9U 10D
                    Select Case zTranslateDirection(zSearchDir, 0) 'First we check to see if its hidden
                        Case "N"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 1, 1) <> "1")
                        Case "S"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 2, 1) <> "1")
                        Case "E"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 3, 1) <> "1")
                        Case "W"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 4, 1) <> "1")
                        Case "NE"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 5, 1) <> "1")
                        Case "NW"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 6, 1) <> "1")
                        Case "SE"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 7, 1) <> "1")
                        Case "SW"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 8, 1) <> "1")
                        Case "U"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 9, 1) <> "1")
                        Case "D"
                            bOpenPassage = (Mid(MyCStr(rsCArea!HiddenExits), 10, 1) <> "1")
                    End Select
                    
                    If (bOpenPassage) Then 'Now we check for blocked
                        Select Case zTranslateDirection(zSearchDir, 0)
                            Case "N"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 1, 1) <> "1")
                            Case "S"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 2, 1) <> "1")
                            Case "E"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 3, 1) <> "1")
                            Case "W"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 4, 1) <> "1")
                            Case "NE"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 5, 1) <> "1")
                            Case "NW"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 6, 1) <> "1")
                            Case "SE"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 7, 1) <> "1")
                            Case "SW"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 8, 1) <> "1")
                            Case "U"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 9, 1) <> "1")
                            Case "D"
                                bOpenPassage = (Mid(MyCStr(rsCArea!BlockedExits), 10, 1) <> "1")
                        End Select
                    End If
                End If
                Set rsCArea = Nothing
                
                If (bOpenPassage) Then
                    Do While (Not rsDoor.EOF)
                        Select Case MyCInt(rsDoor!Status) '0 = Always Open, 1 = Unlocked, 2 = Locked, 3=open but is locakable, 4=Magically Locked, 5 = Bashed Open, 6 = Closed and no lockable, 7=Bashed Closed
                            Case 0
                                rsDoor.Edit
                                rsDoor!Status = 6
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "You shut the " & zDoorName & ".", "", "%s1 shuts the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", zDoorName & " is shut by %s1 standing on the other side.", lOSX, lOSY, lOSZ, "", False
                            Case 3
                                rsDoor.Edit
                                rsDoor!Status = 1
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "You shut the " & zDoorName & ".", "", "%s1 shuts the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", zDoorName & " is shut by %s1 standing on the other side.", lOSX, lOSY, lOSZ, "", False
                            Case 5 'bashed open, subRotateTheWorld resets 5 or 7 back to 8 [bashable]
                                rsDoor.Edit
                                rsDoor!Status = 7 'we close it
                                rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "[bashed] You bash closed the " & zDoorName & ".", "", "[bashed] %s1 bashes closed the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "[bashed] The " & zDoorName & " is shut by %s1.", lOSX, lOSY, lOSZ, "", False
                            Case 7 'bashed already closed, subRotateTheWorld resets 5 or 7 back to 8 [bashable]
                                subSendMsgAreaAllDISmart "&M", zPlayerName, zDoorName & " is already bashed closed.", "", "%s1 kicks the " & zDoorName & " which is already closed.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is being kicked.", lOSX, lOSY, lOSZ, "", False
                            Case 8 'Bashable [closed n locked]
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zDoorName & " is bashable sealed already.", "", "%s1 realizes the " & zDoorName & " is bashable but sealed.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is being kicked.", lOSX, lOSY, lOSZ, "", False
                            Case 10 'magically closed
                                rsDoor.Edit
                                rsDoor!Status = 11 'once magically unlocked you can just open and close it
                                rsDoor!ResetTimer = 4 'we reset doors after 15 mins * this long
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, zDoorName & " is no longer magically sealed.", "", "%s1 magically opens the " & zDoorName & ".", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is making magical sounds.", lOSX, lOSY, lOSZ, "", False
                            Case 12 'Magically sealed [closed n locked]
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zDoorName & " is magically sealed.", "", "%s1 realizes the " & zDoorName & " is magically sealed.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "The " & zDoorName & " to " & zTranslateDirection(zSearchDir, 1) & " is making magical sounds.", lOSX, lOSY, lOSZ, "", False
                            Case 2, 4
                                subSendMsgAreaAllDISmart "&M", zPlayerName, zDoorName & " is locked.", "", "%s1 realizes the " & zDoorName & " is locked.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", zDoorName & " is making rattling noises.", lOSX, lOSY, lOSZ, "", False
                            Case Else
                                subSendMsgAreaAllDISmart "&M", zPlayerName, zDoorName & " is already closed.", "", "%s1 realizes the " & zDoorName & " is already closed.", lOX, lOY, lOZ, "", False
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", zDoorName & " is making rattling noises.", lOSX, lOSY, lOSZ, "", False
                        End Select
                        rsDoor.MoveNext
                    Loop
                Else
                    subSendMsg "&gYou do not see a door there.", zPortID
                End If
            Else
                'Now try to close an object in the area
                Set rsDoor = Nothing
                Set rsDoor = MyDB.OpenRecordset("SELECT ObjectID, ObjectName, LockStatus FROM tblObject WHERE (Burried=False) AND (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ") AND (ObjectName Like '*" & zSearchObjectName & "*') AND (Status=0) AND (Len([LockCombo])<>0 OR LockKeyID<>0 OR LockStatus<>0 OR WeightMax<>0 OR VisibleLevel=0);", dbOpenDynaset)
                If (Not rsDoor.EOF) Then
                    Do While (Not rsDoor.EOF)
                        zColourObjectName = (zShortstop(MyCStr(rsDoor!ObjectName)))
                        Select Case MyCLng(rsDoor!LockStatus)
                            Case 10
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " has no door to close.", "", "%s1 realizes the " & zColourObjectName & " has no door to close.", lOX, lOY, lOZ, "", False
                            Case 20 'opened
                                rsDoor.Edit
                                rsDoor!LockStatus = 21
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " swings closed.", "", "%s1 swings closed the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                            Case 30 'opened
                                rsDoor.Edit
                                rsDoor!LockStatus = 31
                                rsDoor.Update
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " swings closed.", "", "%s1 swings closed the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                            Case 21, 31
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is already closed.", "", "%s1 realizes the " & zColourObjectName & " is already closed.", lOX, lOY, lOZ, "", False
                            Case 22 'use key required
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is closed and key locked.", "", "%s1 realizes the " & zColourObjectName & " is closed and key locked.", lOX, lOY, lOZ, "", False
                            Case 32 'use combination required
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is closed and combination locked.", "", "%s1 realizes the " & zColourObjectName & " is closed and combination locked.", lOX, lOY, lOZ, "", False
                            Case Else 'not a container
                                subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is not a container.", "", "%s1 looks over the " & zColourObjectName & " for an opening.", lOX, lOY, lOZ, "", False
                        End Select
                        rsDoor.MoveNext
                    Loop
                Else
                    subSendMsg "&GThere is nothing here like that to close.", zPortID
                End If
            End If
            Set rsDoor = Nothing
        Else
            subSendMsg "&GCOMMAND: CLOSE (object/door direction)", zPortID
        End If
    Else
        subSendMsg "&GYou dream of opening and closing doors.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDoorClose," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subObjectUseCombo(zPortID As String, zPlayerName As String, zOObjectName As String, zCombonation As String, lOX As Long, lOY As Long, lOZ As Long, lOPlayerID As Long)
On Error GoTo Err_Check
    Dim lLockStatus As Long
    Dim zColourObjectName As String
    Dim rsDoor As Recordset
    If (Len(zCombonation) > 0) Then
        'Now try to open an object in the area with a combonation code.
        
        Set rsDoor = MyDB.OpenRecordset("SELECT ObjectName, LockStatus, LockCombo FROM tblObject WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND ObjectName Like ""*" & zAntiSQLCrash(zOObjectName) & "*"" AND Status=0) ORDER BY ObjectName;", dbOpenDynaset)
        If (Not rsDoor.EOF) Then
            zColourObjectName = (zShortstop(MyCStr(rsDoor!ObjectName)))
            lLockStatus = MyCLng(rsDoor!LockStatus)
            If (lLockStatus = 30 Or lLockStatus = 31 Or lLockStatus = 32) Then
                If (zCombonation = rsDoor!LockCombo) Then
                    Select Case lLockStatus
                        Case 30 'open
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is already open and must be closed to use the combination.", "", "%s1 realizes the " & zColourObjectName & " is already open and requires a combination to lock.", lOX, lOY, lOZ, "", False
                        Case 31 'use combination required
                            rsDoor.Edit
                            rsDoor!LockStatus = 32
                            rsDoor.Update
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is now combination locked.", "", "%s1 combination locks the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                        Case 32 'use combination required
                            rsDoor.Edit
                            rsDoor!LockStatus = 31
                            rsDoor.Update
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is now combination unlocked.", "", "%s1 combination unlocks the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
                        Case Else 'not a container
                            subSendMsgAreaAllDISmart "&M", zPlayerName, "The " & zColourObjectName & " is not a container.", "", "%s1 realizes the " & zColourObjectName & " is not a container.", lOX, lOY, lOZ, "", False
                    End Select
                Else
                    subSendMsgAreaAllDISmart "&M", zPlayerName, "The spin the combination " & LCase(zCombonation) & " on the " & zColourObjectName & " and nothing happens.", "", "%s1 spins the combination " & LCase(zCombonation) & " on the " & zColourObjectName & " and nothing happens.", lOX, lOY, lOZ, "", False
                End If
            Else
                subSendMsgAreaAllDISmart "&M", zPlayerName, "You do not see a combination lock anywhere on the " & zColourObjectName & ".", "", "%s1 does not see a combination lock on the " & zColourObjectName & ".", lOX, lOY, lOZ, "", False
            End If
        Else
            subSendMsg "&gThat doesn't seem to be in the area.", zPortID
        End If
        Set rsDoor = Nothing
    Else
        subSendMsg "&GCOMMAND: USE COMBO (object name) (combination code)", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subObjectUseCombo," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImaginaryStats(zPortID As String)
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lStatus As Long
    Dim lImaginaryDuration As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName, PlayerID, PlayerLevel, Status, ImaginaryDuration, X, Y, Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then 'Login player name found
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lStatus = MyCLng(rsPlayer!Status)
        lImaginaryDuration = MyCLng(rsPlayer!ImaginaryDuration)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
    End If
    Set rsPlayer = Nothing
    
    If (lStatus <> 50) Then
        If (lImaginaryDuration = 0) Then
            MyDB.Execute "UPDATE tblPlayer SET ImaginaryDuration=" & 500 + (lPlayerLevel * 2) & "  WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            subRecalculatePlayerEquipment lPlayerID, zPortID
            subSendMsgAreaAllDISmart "&M", zPlayerName, "%s1 cast imaginary stats upon yourself.", "", "%s1 cast imaginary stats upon %g13.", lX, lY, lZ, "", False
        Else
            subSendMsg "&gYou already have imaginary stats cast upon yourself.", zPortID
        End If
    Else
        subSendMsg "&gYou have happy dreams based on your imagination.", zPortID
    End If
End Sub
Public Function subLookPeek(zPortID As String, zDir As String, bXRay As Boolean) As String
On Error GoTo Err_Check
    Const cstlMoveCost = 100
    Dim rsData As Recordset
    Dim rsPlayer As Recordset
    Dim zSQL As String
    Dim zStartMsg As String
    Dim zReturn As String
    Dim zDoorInWayMsg As String
    Dim iDoorOpen As Integer
    Dim bAreaAhead As Boolean
    Dim lStatus As Long
    Dim lOX As Long
    Dim lOY As Long
    Dim lOZ As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim lHX As Long
    Dim lHY As Long
    Dim lHZ As Long
    Dim lPlayerID As Long
    Dim zAreaName As String
    Dim zRoomDir As String
    Dim zPlayerName As String
    Dim lPlayerLevel As Long
    Dim zRoomDirT As String
    Dim bAreaCheck As Boolean
    Dim bDoorCheck As Boolean
    Dim zShowExits As String
    Dim lCMove As Long
    Dim zClass As String
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT Race, Class, PlayerID, CMove, PlayerName, PortID, PlayerLevel, X, Y, Z, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then 'Login player name found
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zClass = MyCStr(rsPlayer!Class)
        lStatus = MyCLng(rsPlayer!Status)
        lOX = MyCLng(rsPlayer!x)
        lOY = MyCLng(rsPlayer!y)
        lOZ = MyCLng(rsPlayer!z)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lCMove = MyCLng(rsPlayer!CMove)
    End If
    Set rsPlayer = Nothing

    If (lStatus <> 50) Then
        If (lPlayerLevel > 9) Then 'Level to use
            If (zTranslateDirection(zDir, 3) <> "?Dir=?") Then
                If (lCMove >= cstlMoveCost) Then
                    If (zClass <> "RA" And zClass <> "BA" And zClass <> "DR") Then 'ranger and druid are the best peekers and bards too
                        If ((lRandom(222) = 1) Or (zClass = "MA" And lRandom(20) = 1)) Then
                            'nail the area around the hoser
                            MyDB.Execute "UPDATE tblPlayer SET BlindDuration=10+" & lRandom(20) & ", StunInterruption=3, Hallucinate=20+" & lRandom(20) & " WHERE (PlayerID=" & lPlayerID & ");"
                            
                            Select Case lRandom(3)
                                Case 1
                                    subSendMsg "&y*area dusted*", zPortID
                                Case 2
                                    subSendMsg "&y*branch to the head*", zPortID
                                Case Else
                                    subSendMsg "&y*prickle bush in da EYE*", zPortID
                            End Select
                        End If
                    End If
                    zShowExits = ""
                    subDirectionControl lTX, lTY, lTZ, lOX, lOY, lOZ, zDir
                    bAreaCheck = bAreaMovementAllowedPEEK(lTX, lTY, lTZ, lOX, lOY, lOZ, 0)
                    bDoorCheck = bAreaMovementDoorAllowed(lTX, lTY, lTZ)
                    If (lOX <> lTX Or lOY <> lTY Or lOZ <> lTZ) Then
                        If (bXRay Or bDoorCheck Or bAreaCheck) Then
                            zRoomDir = zTranslateDirection(zDir, 3)
                            zRoomDirT = zTranslateDirection(zDir, 11)
                            
                            If (bDoorCheck Or lTZ <> lOZ) Then 'peek though a door or up or down
                                lHX = lTX: lHY = lTY: lHZ = lTZ
                                Select Case (zTranslateDirection(zDir, 0))
                                    Case "N"
                                        lHY = lHY - 1
                                    Case "S"
                                        lHY = lHY + 1
                                    Case "E"
                                        lHX = lHX + 1
                                    Case "W"
                                        lHX = lHX - 1
                                    Case "NE"
                                        lHX = lHX + 1
                                        lHY = lHY - 1
                                    Case "NW"
                                        lHX = lHX - 1
                                        lHY = lHY - 1
                                    Case "SE"
                                        lHX = lHX + 1
                                        lHY = lHY + 1
                                    Case "SW"
                                        lHX = lHX - 1
                                        lHY = lHY + 1
                                    Case "U"
                                        lHZ = lHZ - 1
                                    Case "D"
                                        lHZ = lHZ + 1
                                End Select
                                'If (bAreaExists(lHX, lHY, lHZ)) Then zShowExits = vMemoryAreaJustExitsXYZ(lHX, lHY, lHZ, True)
                                
                                If (bXRay) Then
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "[xray-eyes]You peek into the " & zRoomDir & " room.", "", "[xray-eyes]%s1 peeked into the " & zRoomDir & " room.", lOX, lOY, lOZ, "", False
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "[xray-eyes]%s1 peeked into the room from " & zRoomDirT & ".", lHX, lHY, lHZ, "", False
                                Else
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "You peek into the " & zRoomDir & " room.", "", "%s1 peeked into the " & zRoomDir & " room.", lOX, lOY, lOZ, "", False
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "%s1 peeked into the room from " & zRoomDirT & ".", lHX, lHY, lHZ, "", False
                                End If
                            Else
                                'If (bAreaExists(lTX, lTY, lTZ)) Then zShowExits = vMemoryAreaJustExitsXYZ(lTX, lTY, lTZ, True)
                                If (bXRay) Then
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "[xray-eyes]You peek into the " & zRoomDir & " room.", "", "[xray-eyes]%s1 peeked into the " & zRoomDir & " room.", lOX, lOY, lOZ, "", False
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "[xray-eyes]%s1 peeked into the room from " & zRoomDirT & ".", lTX, lTY, lTZ, "", False
                                Else
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "You peek into the " & zRoomDir & " room.", "", "%s1 peeked into the " & zRoomDir & " room.", lOX, lOY, lOZ, "", False
                                    subSendMsgAreaAllDISmart "&M", zPlayerName, "", "", "%s1 peeked into the room from " & zRoomDirT & ".", lTX, lTY, lTZ, "", False
                                End If
                            End If
                            
                            If (zRoomDir <> "?Dir=?") Then
                                zReturn = ""
                                zDoorInWayMsg = ""
                                iDoorOpen = 0 'No door
                                Set rsData = MyDB.OpenRecordset("SELECT DoorID, Status, DoorHasWindow FROM tblDoor WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbOpenSnapshot)
                                If (Not rsData.EOF) Then
                                    iDoorOpen = 1 'Close and no window
                                    If (bAmong(MyCInt(rsData!Status), 0, 3, 5, 8)) Then
                                        iDoorOpen = 2 'Open door
                                        subDirectionControl lTX, lTY, lTZ, lTX, lTY, lTZ, zDir
                                        zDoorInWayMsg = "Looking through the open doorway you can see," & vbCrLf
                                    Else
                                        If (MyCInt(rsData!DoorHasWindow) <> 0) Then
                                            iDoorOpen = 3 'Door has a window we can see through
                                            subDirectionControl lTX, lTY, lTZ, lTX, lTY, lTZ, zDir
                                            zDoorInWayMsg = "You peek through a simple bar window to see," & vbCrLf
                                        End If
                                    End If
                                End If
                                Set rsData = Nothing
                                
                                If (iDoorOpen <> 1) Then
                                    zAreaName = ""
                                    If (bDoorCheck Or lTZ <> lOZ) Then 'peek though a door or up or down
                                        zSQL = "SELECT BlockedExits, AreaID, AreaName, HeightRequirement FROM tblArea WHERE (X=" & lHX & " AND Y=" & lHY & " AND Z=" & lHZ & ");"
                                    Else
                                        zSQL = "SELECT BlockedExits, AreaID, AreaName, HeightRequirement FROM tblArea WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");"
                                    End If
                                    Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                    If (Not rsData.EOF) Then
                                        bAreaAhead = True
                                        zAreaName = MyCStr(rsData!AreaName)
                                        If (Len(zAreaName) > 0) Then zReturn = zReturn & gblzFBWHI & LCase(zAreaName)
                                        If (MyCLng(rsData!HeightRequirement) > 0) Then zReturn = zReturn & vbCrLf & gblzFBWHI & Format((MyCLng(rsData!HeightRequirement) / 2.54) / 12, "FIXED") & " foot high ceiling."
                                    End If
                                    Set rsData = Nothing
                                    
                                    If (bAreaAhead) Then
                                        'Lets look for mobs
                                        If (bDoorCheck Or lTZ <> lOZ) Then 'peek though a door or up or down
                                            zSQL = "SELECT MobName FROM tblMob WHERE (X=" & lHX & " AND Y=" & lHY & " AND Z=" & lHZ & " AND RespawnDelay=0 AND Invisible=0);"
                                        Else
                                            zSQL = "SELECT MobName FROM tblMob WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & " AND RespawnDelay=0 AND Invisible=0);"
                                        End If
                                        'Look for Mobiles
                                        Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                        Do While (Not rsData.EOF)
                                            zReturn = zReturn & vbCrLf & gblzFNMAG & MyCStr(rsData!MobName)
                                            rsData.MoveNext
                                        Loop
                                        Set rsData = Nothing
                                        
                                        'Look for Players
                                        If (bDoorCheck Or lTZ <> lOZ) Then 'peek though a door or up or down
                                            zSQL = "SELECT tblPlayer.PlayerName FROM tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PlayerName = tblPlayerLoggedIn.PlayerName WHERE (((tblPlayer.X)=" & lHX & ") AND ((tblPlayer.Y)=" & lHY & ") AND ((tblPlayer.Z)=" & lHZ & ") AND ((tblPlayer.InvisibilityDuration)=0) AND ((tblPlayer.CamoflaguedDuration)=0));"
                                        Else
                                            zSQL = "SELECT tblPlayer.PlayerName FROM tblPlayer INNER JOIN tblPlayerLoggedIn ON tblPlayer.PlayerName = tblPlayerLoggedIn.PlayerName WHERE (((tblPlayer.X)=" & lTX & ") AND ((tblPlayer.Y)=" & lTY & ") AND ((tblPlayer.Z)=" & lTZ & ") AND ((tblPlayer.InvisibilityDuration)=0) AND ((tblPlayer.CamoflaguedDuration)=0));"
                                        End If
                                        Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                                        Do While (Not rsData.EOF)
                                            zReturn = zReturn & vbCrLf & "&c" & MyCStr(rsData!PlayerName)
                                            rsData.MoveNext
                                        Loop
                                        Set rsData = Nothing
                                        
                                        If (Len(zReturn) = 0) Then zDoorInWayMsg = "You don't see anything in particular there." & vbCrLf
                                    Else
                                        zStartMsg = ""
                                        zDoorInWayMsg = "You see nothing special when looking " & zTranslateDirection(zDir, 2) & "." & vbCrLf
                                    End If
                                Else
                                    zStartMsg = ""
                                    zDoorInWayMsg = "The door is closed and has no window." & vbCrLf
                                End If
                            Else
                                zStartMsg = "&WType LOOK when you are in the same room you want to peek in."
                            End If
                            subSendMsg "&w" & zStartMsg & zDoorInWayMsg & zShowExits & zReturn, zPortID
                        Else
                            subSendMsg "&gThat's a nice wall there isn't it?", zPortID
                        End If
                    Else
                        subSendMsg "&RA magical force stops you from doing that!", zPortID 'this is actually a conceled error report
                    End If
                    'costs the player some move for roleplay
                    lCMove = lCMove - cstlMoveCost
                    MyDB.Execute "UPDATE tblPlayer SET CMove=" & (lCMove) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                Else
                    subSendMsg "&gUnable to peek, you are short " & (cstlMoveCost - lCMove) & " movement points.", zPortID
                End If
            Else
                subSendMsg "&gWhich way?", zPortID
            End If
        Else
            subSendMsg zReturnPlayerLevelAscii(10) & "&gYou cannot peek into other rooms, just yet.", zPortID
        End If
    Else
        subSendMsg "&gYou cannot peek when you are asleep.", zPortID
    End If
    Exit Function
Err_Check:
    subWriteErrorFile "subLookPeek," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subObjectContents(zPortID As String, lObjectID As Long, zTitle As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zObjectDetails As String
    Dim intCounter As Integer
    Dim strCompare As String
    Dim zCount As String
    
    Set rsData = MyDB.OpenRecordset("SELECT Count(tblObject.ObjectID) AS CountOfObjectID, tblObject.ObjectName FROM tblObject INNER JOIN tblPlayerContainer ON tblObject.ObjectID = tblPlayerContainer.ObjectID GROUP BY tblObject.ObjectName, tblPlayerContainer.ContainerObjectID HAVING (((tblPlayerContainer.ContainerObjectID)=" & lObjectID & ")) ORDER BY Last(tblObject.ObjectID);", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        If (Len(zTitle) > 0) Then subSendMsg "&w" & zTitle, zPortID
        Do While (Not rsData.EOF)
            zCount = ""
            If MyCLng(rsData!CountOfObjectID) > 1 Then zCount = "(" & MyCStr(rsData!CountOfObjectID) & ") "
            strCompare = MyCStr(rsData!ObjectName)
            zObjectDetails = gblzFNWHI & zCount & zAdverb(strCompare, 1) & strCompare
            
            subSendMsg zObjectDetails, zPortID
            rsData.MoveNext
        Loop
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subObjectContents," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zPercentChance(lMagicFind As Long, lHoldRareRandom As Long) As String
On Error GoTo Err_Check
    Dim zReturn As String
    Dim lValue As Long
    
    lValue = MyCLng((lMagicFind * 100) / lHoldRareRandom)
    
    zReturn = MyCStr(Format(lValue, "FIXED")) & "% CHANCE"
    
    If (lValue > 80) Then zReturn = "GOOD CHANCE"
    If (lValue > 100) Then zReturn = "GREAT CHANCE"
    If (lValue > 200) Then zReturn = "SUPER CHANCE"
    If (lValue > 300) Then zReturn = "GODLY CHANCE"
    If (lValue < 20) Then zReturn = "SMALL CHANCE"
    If (lValue < 1) Then zReturn = "SLIM CHANCE"
    
    zPercentChance = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zPercentChance," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subMobContents(zPortID As String, zTitle As String, lMobID As Long, lMagicFind As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lHoldRareRandom As Long
    Set rsData = MyDB.OpenRecordset("SELECT tblObject.ObjectID, tblObject.ObjectName, tblObject.Location, tblMobEquipmentItems.LocationLR FROM tblMobEquipmentItems INNER JOIN tblObject ON tblMobEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblMobEquipmentItems.MobID)=" & lMobID & "));", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        If (Len(zTitle) > 0) Then
            subSendMsg "&Y" & zTitle, zPortID
            Do While (Not rsData.EOF)
                lHoldRareRandom = lReturnObjectRareRandom(MyCLng(rsData!ObjectID))
                subSendMsg gblzFNYEL & strForceSize(UCase(zTranslateLocation(MyCLng(rsData!Location), MyCStr(rsData!LocationLR))), 15, " ", "B") & "|" & zShortstop(rsData!ObjectName) & " (" & lMagicFind & "/" & lHoldRareRandom & " - " & zPercentChance(lMagicFind, lHoldRareRandom) & ")", zPortID 'LCase(zTranslateRareRandom(MyCLng(rsData!ObjectID))) & " - " &
                rsData.MoveNext
            Loop
        End If
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subMobContents," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zReturnMobIDName(lMobID As Long) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    zReturn = ""
    Set rsData = MyDB.OpenRecordset("SELECT MobName FROM tblMob WHERE (MobID=" & lMobID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!MobName)
    End If
    Set rsData = Nothing
    zReturnMobIDName = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zReturnMobIDName," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function lTop(ByRef zLine As String) As Long
On Error Resume Next
    Dim lReturn As Long
    lReturn = 1
    If (IsNumeric(Mid(zLine, 1, 1))) Then
        lReturn = MyCLng(Mid(zLine, 1, 1))
        If (IsNumeric(Mid(zLine, 1, 2))) Then
            lReturn = MyCLng(Mid(zLine, 1, 2))
            zLine = MyCStr(Mid(zLine, 3)) 'we cut out the number
        Else
            zLine = MyCStr(Mid(zLine, 2)) 'we cut out the number
        End If
    End If
    If (lReturn < 1) Then lReturn = 1
    
    Do While (Mid(zLine, 1, 1) = ".")
        zLine = Mid(zLine, 2, Len(zLine) - 1)
    Loop
    lTop = lReturn
End Function
Public Function zTranslateHitpointLookDifference(lCHP As Long, lOHP As Long)
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = ""
    Select Case MyCLng(lCHP * 100 / lOHP)
        Case 1 To 10
            zReturn = "&Rand is near death!"
        Case 11 To 20
            zReturn = "&Rand knows death is just around the corner!"
        Case 21 To 30
            zReturn = "&Rand is only at twenty five percent full health."
        Case 31 To 40
            zReturn = gblzFNRED & "and is only at thirty three percent full health."
        Case 41 To 50
            zReturn = gblzFNRED & "and is just less than fifty percent full health."
        Case 51 To 60
            zReturn = gblzFNRED & "and is only at fifty percent full health."
        Case 61 To 70
            zReturn = gblzFNGRE & "and is just over fifty percent full health."
        Case 71 To 80
            zReturn = gblzFNGRE & "and is safely at seventy five percent full health."
        Case 81 To 90
            zReturn = "&Gand is starting to feel the deep bruises."
        Case 90 To 95
            zReturn = "&Gand is marred with a few scratches."

    End Select
    zTranslateHitpointLookDifference = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zTranslateHitpointLookDifference," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subObjectPeer(lPlayerID As Long, zPlayerName As String, zObjectName As String, lX As Long, lY As Long, lZ As Long, zPortID As String, bVerbose As Boolean)
On Error GoTo Err_Check
    Dim rsPeer As Recordset
    Dim zAreaDesc As String
    Dim zCount As String
    Dim zInfo As String
    Dim zLine As String
    Dim zMagicRunes As String
    
    If (bVerbose) Then
        subSendMsgAreaExcept2 gblzFBMAG & zPlayerName & "&y peers into " & zAdverb(zObjectName, 4) & (zShortstop(zObjectName)) & ".", lX, lY, lZ, zPortID, ""
        subSendMsg "&MPeering into " & zAdverb(zObjectName, 4) & (zShortstop(zObjectName)) & " [x" & MyCStr(lX) & " y" & MyCStr(lY) & " z" & MyCStr(lZ) & "]", zPortID
    End If
    
    zInfo = "(no area name - report to an immortal)"
    'Peer area - this better be there ;)
    Set rsPeer = MyDB.OpenRecordset("SELECT AreaName, AreaDescDay, AreaDescNight FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    If (Not rsPeer.EOF) Then
        If (bWhenIsIt("", False)) Then
            zAreaDesc = "&y" & (MyCStr(rsPeer!AreaDescDay))
        Else
            zAreaDesc = "&B" & (MyCStr(rsPeer!AreaDescNight))
        End If
        subSendMsg "&w" & MyCStr(rsPeer!AreaName) & vbCrLf & zAreaDesc, zPortID
        If (lPlayerID <> 0) Then zInfo = gblzFNWHI & MyCStr(rsPeer!AreaName) & vbCrLf & zAreaDesc
    End If
    Set rsPeer = Nothing
    
    'Peer Players
    Set rsPeer = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Len([PortID])>1) ORDER BY PlayerName;", dbOpenSnapshot)
    Do While (Not rsPeer.EOF)
        subSendMsg gblzFNCYA & MyCStr(rsPeer!PlayerName), zPortID
        If (lPlayerID <> 0) Then zInfo = zInfo & vbCrLf & "&c" & MyCStr(rsPeer!PlayerName)
        rsPeer.MoveNext
    Loop
    Set rsPeer = Nothing
    
    'Peer Mobs
    Set rsPeer = MyDB.OpenRecordset("SELECT Count(tblMob.MobID) AS CountOfMobID, tblMob.MobName FROM tblMob GROUP BY tblMob.MobName, tblMob.MobDesc, tblMob.X, tblMob.Y, tblMob.Z, tblMob.RespawnDelay HAVING (((tblMob.X)=" & lX & ") AND ((tblMob.Y)=" & lY & ") AND ((tblMob.Z)=" & lZ & ") AND ((tblMob.RespawnDelay)=0)) ORDER BY tblMob.MobName;", dbOpenSnapshot)
    Do While (Not rsPeer.EOF)
        zCount = ""
        If (MyCLng(rsPeer!CountOfMobID) > 1) Then zCount = "(" & MyCStr(rsPeer!CountOfMobID) & ") "
        subSendMsg "&m" & zCount & MyCStr(rsPeer!MobName), zPortID
        If (lPlayerID <> 0) Then zInfo = zInfo & vbCrLf & gblzFNMAG & zCount & MyCStr(rsPeer!MobName)
        rsPeer.MoveNext
    Loop
    Set rsPeer = Nothing
    
    'Peer Objects
    Set rsPeer = MyDB.OpenRecordset("SELECT Count(tblObject.ObjectID) AS CountOfObjectID, tblObject.ColourGlowing, tblObject.MarkingGlowing, tblObject.MarkingHumming, tblObject.MarkingRune, tblObject.ObjectName, tblObject.Burried, tblObject.Status, tblObject.VisibleLevel FROM tblObject GROUP BY tblObject.ColourGlowing, tblObject.MarkingGlowing, tblObject.MarkingHumming, tblObject.MarkingRune, tblObject.ObjectName, tblObject.Burried, tblObject.Status, tblObject.X, tblObject.Y, tblObject.Z, tblObject.VisibleLevel HAVING (((tblObject.Burried)=False) AND ((tblObject.Status)=0) AND ((tblObject.X)=" & lX & ") AND ((tblObject.Y)=" & lY & ") AND ((tblObject.Z)=" & lZ & ") AND ((tblObject.VisibleLevel)=0)) ORDER BY tblObject.ObjectName;", dbOpenSnapshot)
    Do While (Not rsPeer.EOF)
        zCount = ""
        zLine = ""
        If (MyCLng(rsPeer!CountOfObjectID) > 1) Then zCount = "(" & MyCStr(rsPeer!CountOfObjectID) & ") "
        zMagicRunes = MyCStr(rsPeer!ColourGlowing)
        If (Len(zMagicRunes) > 0) Then zLine = zLine & zMagicRunes & " "
        zMagicRunes = MyCStr(rsPeer!MarkingGlowing)
        If (Len(zMagicRunes) > 0) Then zLine = zLine & zMagicRunes & " "
        zMagicRunes = MyCStr(rsPeer!MarkingHumming)
        If (Len(zMagicRunes) > 0) Then zLine = zLine & zMagicRunes & " "
        zMagicRunes = MyCStr(rsPeer!MarkingRune)
        If (Len(zMagicRunes) > 0) Then zLine = zLine & zMagicRunes & " "
        zLine = zLine & MyCStr(rsPeer!ObjectName)
        subSendMsg "&w" & zCount & zLine, zPortID
        If (lPlayerID <> 0) Then zInfo = zInfo & vbCrLf & "&w" & zCount & (MyCStr(rsPeer!ObjectName))
        rsPeer.MoveNext
    Loop
    Set rsPeer = Nothing
    
    If (lPlayerID <> 0 And Len(zInfo) <> 0) Then 'we use peer object to look at a guide location
        Set rsPeer = MyDB.OpenRecordset("SELECT QuestMissionLog FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");", dbOpenDynaset)
        If (Not rsPeer.EOF) Then
            rsPeer.Edit
            rsPeer!QuestMissionLog = zTrimCrLf(zInfo) & vbCrLf & "[x" & lX & " y" & lY & " z" & lZ & "]"
            rsPeer.Update
        End If
        Set rsPeer = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subObjectPeer," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zLanguageMessage(lLanguageMessageID As Long, zLanguagesKnown As String) As String
On Error GoTo Err_Check
    Dim rsLanguageMsg As Recordset
    Dim lLanguageCell As Long
    Dim zReturn As String
    zReturn = ""
    Set rsLanguageMsg = MyDB.OpenRecordset("SELECT LanguageCell, LanguageEmote, LanguageMessage FROM tblLanguageMessage WHERE (LanguageMessageID=" & lLanguageMessageID & ");", dbOpenSnapshot)
    If (Not rsLanguageMsg.EOF) Then
        lLanguageCell = MyCLng(rsLanguageMsg!LanguageCell)
        
        zReturn = zReturn & "&Bin " & LCase(zTranslateLanguage(lLanguageCell)) & " the inscription reads," & vbCrLf
        If (Len(MyCStr(rsLanguageMsg!LanguageEmote)) > 0) Then zReturn = gblzFBMAG & (MyCStr(rsLanguageMsg!LanguageEmote)) & vbCrLf
        
        If (Mid(zLanguagesKnown, lLanguageCell, 1) = "1" Or lLanguageCell = 99) Then
            zReturn = zReturn & gblzFBYEL & "'" & (MyCStr(rsLanguageMsg!LanguageMessage)) & gblzFBYEL & "'"
        Else
            zReturn = zReturn & gblzFBYEL & "'&w" & zScrambleLanguage(MyCStr(rsLanguageMsg!LanguageMessage)) & gblzFBYEL & "'"
        End If
        
    End If
    Set rsLanguageMsg = Nothing
    zLanguageMessage = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zLanguageMessage," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function zObjectWearRequirements(lObjectID As Long) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zWearReq As String
    
    zWearReq = ""
    Set rsData = MyDB.OpenRecordset("SELECT ObjectName, LevelRequirement, Rare, Treasure, WearReqSTR, WearReqINT, WearReqWIS, WearReqDEX, WearReqCON, WearReqCHA, WearReqLUC, WearReqAC, WearReqHP, WearReqEssence, WearReqMana, WearReqSoul, WearReqMove FROM tblObject WHERE (ObjectID=" & lObjectID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        If (MyCLng(rsData!LevelRequirement) <> 0) Then zWearReq = zWearReq & " Lv[" & MyCLng(rsData!LevelRequirement) & "]"
        If (MyCLng(rsData!Rare) <> 0) Then zWearReq = zWearReq & " R[" & MyCLng(rsData!Rare) & "]"
        If (MyCLng(rsData!Treasure) <> 0) Then zWearReq = zWearReq & " T[" & MyCLng(rsData!Treasure) & "]"
        If (MyCLng(rsData!WearReqSTR) <> 0) Then zWearReq = zWearReq & " STR[" & MyCLng(rsData!WearReqSTR) & "]"
        If (MyCLng(rsData!WearReqINT) <> 0) Then zWearReq = zWearReq & " INT[" & MyCLng(rsData!WearReqINT) & "]"
        If (MyCLng(rsData!WearReqWIS) <> 0) Then zWearReq = zWearReq & " WIS[" & MyCLng(rsData!WearReqWIS) & "]"
        If (MyCLng(rsData!WearReqDEX) <> 0) Then zWearReq = zWearReq & " DEX[" & MyCLng(rsData!WearReqDEX) & "]"
        If (MyCLng(rsData!WearReqCON) <> 0) Then zWearReq = zWearReq & " CON[" & MyCLng(rsData!WearReqCON) & "]"
        If (MyCLng(rsData!WearReqCHA) <> 0) Then zWearReq = zWearReq & " CHA[" & MyCLng(rsData!WearReqCHA) & "]"
        If (MyCLng(rsData!WearReqLUC) <> 0) Then zWearReq = zWearReq & " LUC[" & MyCLng(rsData!WearReqLUC) & "]"
        
        If (MyCLng(rsData!WearReqAC) <> 0) Then zWearReq = zWearReq & " AC[" & MyCLng(rsData!WearReqAC) & "]"
        If (MyCLng(rsData!WearReqHP) <> 0) Then zWearReq = zWearReq & " CHP[" & MyCLng(rsData!WearReqHP) & "]"
        If (MyCLng(rsData!WearReqEssence) <> 0) Then zWearReq = zWearReq & " CEsse[" & MyCLng(rsData!WearReqEssence) & "]"
        If (MyCLng(rsData!WearReqMana) <> 0) Then zWearReq = zWearReq & " CMana[" & MyCLng(rsData!WearReqMana) & "]"
        If (MyCLng(rsData!WearReqSoul) <> 0) Then zWearReq = zWearReq & " CSoul[" & MyCLng(rsData!WearReqSoul) & "]"
        If (MyCLng(rsData!WearReqMove) <> 0) Then zWearReq = zWearReq & " CMove[" & MyCLng(rsData!WearReqMove) & "]"
    End If
    Set rsData = Nothing
    zObjectWearRequirements = MyCStr(zWearReq)
    Exit Function
Err_Check:
    subWriteErrorFile "zObjectWearRequirements," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function lReturnMobTotalPhrases(lID As Long) As Long
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lReturn As Long
    lReturn = 0
    Set rsData = MyDB.OpenRecordset("SELECT Count(tblMobPhrase.MobID) AS CountOfMobID FROM tblMobPhrase GROUP BY tblMobPhrase.MobID HAVING (((tblMobPhrase.MobID)=" & lID & "));", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        lReturn = rsData!CountOfMobID
    End If
    Set rsData = Nothing
    lReturnMobTotalPhrases = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lReturnMobTotalPhrases," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subShowMyExits(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer  As Recordset
    Set rsPlayer = MyDB.OpenRecordset("SELECT X,Y,Z FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        subSendMsg "&G" & zShowExits(MyCLng(rsPlayer!x), MyCLng(rsPlayer!y), MyCLng(rsPlayer!z)), zPortID
    Else
        subSendMsg "no playerfile.", zPortID
    End If
    Set rsPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subShowMyExits," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLookAreaDesc(zPortID As String, zPromptOriginal As String, zWord2 As String, zWord3 As String, zWord4 As String, bStatusBM As Boolean, bStatusGUID As Boolean)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim zRace As String
    Dim zClass As String
    Dim lImmortalLevel As Long
    Dim lPlayerLevel As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCCHA As Long
    Dim lCLuc As Long
    Dim lStatus As Long
    Dim lBlindDuration As Long
    Dim lStunDuration As Long
    Dim lSleepDuration As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lInvisibilityDuration As Long
    Dim lKnowAlignmentDuration As Long
    Dim lHeight As Long
    Dim lColorAreaDesc As Long
    Dim lMagicFind As Long
    Dim zConfig As String
    Dim zLanguagesKnown As String
    Dim lCHITROLL As Long
    Dim lCAC As Long
    
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID, LanguagesKnown, Config, MagicFind, SleepDuration, StunDuration, BlindDuration, ColorAreaDesc, Height, Race, Class, X, Y, Z, CHITROLL, CAC, KnowAlignmentDuration, DetectInvisibilityDuration, InvisibilityDuration, CCHA, CLuc, PlayerName, ImmortalLevel, PlayerLevel, Status, DetectInvisibilityDuration FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zRace = MyCStr(rsPlayer!Race)
        zClass = MyCStr(rsPlayer!Class)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lStatus = MyCLng(rsPlayer!Status)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lSleepDuration = MyCLng(rsPlayer!SleepDuration)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lCHITROLL = MyCLng(rsPlayer!CHITROLL)
        lCAC = MyCLng(rsPlayer!CAC)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lCLuc = MyCLng(rsPlayer!CLuc)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lKnowAlignmentDuration = MyCLng(rsPlayer!KnowAlignmentDuration)
        lHeight = MyCLng(rsPlayer!Height)
        lColorAreaDesc = MyCLng(rsPlayer!ColorAreaDesc)
        lMagicFind = MyCLng(rsPlayer!MagicFind)
        zConfig = MyCStr(rsPlayer!Config)
        zLanguagesKnown = MyCStr(rsPlayer!LanguagesKnown)
    End If
    Set rsPlayer = Nothing
    
    If (lSleepDuration = 0) Then
        If (lStunDuration = 0) Then
            If (lStatus <> 50) Then
                If (lBlindDuration = 0) Then 'stun is taken care of at the top
                    If (Len(zWord2) > 0) Then
                        subLook lImmortalLevel, lDetectInvisibilityDuration, lInvisibilityDuration, zPortID, lPlayerID, zPlayerName, (lCCHA + lCLuc + lPlayerLevel), lX, lY, lZ, lHeight, zCleanChatMessage(Mid(zPromptOriginal, InStr(zPromptOriginal, " ") + 1)), zLanguagesKnown, zWord3, zWord4, lMagicFind, lPlayerLevel, lCHITROLL, lCAC, lStatus, zRace, zClass
                    Else
                        Dim iTest As Integer
                        iTest = Len(zWord2 & zWord3 & zWord4)
                        If (iTest = 0) Then iTest = -2
                        subAreaDesc 0, lDetectInvisibilityDuration, zPortID, lX, lY, lZ, lPlayerLevel, lPlayerID, lKnowAlignmentDuration, lColorAreaDesc, zRace, zClass, zConfig, lImmortalLevel, iTest, bStatusBM, bStatusGUID, ""  'puremode is when there is no atribs after LOOK
                    End If
                Else
                    subSendMsg "&rYou are blind and cannot see a thing!", zPortID
                End If
            Else
                subSendMsg "&gYou are asleep you cannot see anything other than the back of your eyelids.", zPortID
            End If
        Else
            subSendMsg "&rYou are too stunned and dazed to see much at all.", zPortID
        End If
    Else
        subSendMsg "&rShhhhh, you are sleeping under a spell.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subLookAreaDesc," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLook(lImmortalLevel As Long, lDetectInvisibilityDuration As Long, lInvisibilityDuration As Long, zPortID As String, lOPlayerID As Long, zOPlayerName As String, lPlayerStealPeekLevel As Long, lngX As Long, lngY As Long, lngZ As Long, lHeight As Long, zObject As String, zLanguagesKnown As String, zWord3 As String, zWord4 As String, lMagicFind As Long, lPlayerLevel As Long, lCHITROLL As Long, lCAC As Long, lStatus As Long, zPlayerRace As String, zPlayerClass As String)
On Error GoTo Err_Check
    Dim rsScan As Recordset
    Dim rsData As Recordset
    Dim lObjectID As Long
    Dim zImmortalMsg As String
    Dim zRace As String
    Dim zClass As String
    Dim bOkay As Boolean
    Dim lMainGroup As Long
    Dim lTX As Long
    Dim lTY As Long
    Dim lTZ As Long
    Dim bInvisible As Boolean
    Dim zGender As String
    Dim zGetAdditionalInfo As String
    Dim lTopObject As Long
    Dim zFilteredObject As String
    Dim zAdVerbName As String
    Dim zScarToShow As String
    Dim zTransformed As String
    Dim lRatio As Long
    Dim lShadowCloakDuration As Long
    Dim lThingsToSay As Long
    Dim lID As Long
    Dim lGID As Long
    Dim zWearReq As String
    Dim zSQL As String
    Dim lWeightFull As Long
    Dim lWeightMax As Long
    Dim lWeightFullPercent As Long
    Dim lLocation As Long
    Dim lRottingRounds As Long
    Dim lLookPlayerID As Long
    Dim lLookInvisibilityDuration As Long
    Dim lFlyHeight As Long
    Dim lTurnedIntoAnimalType As Long
    Dim zDoorName As String
    Dim rsDoorTest As Recordset
    Dim bDoorTest As Boolean
    'Dim lDoorID As Long
    Dim lDX As Long
    Dim lDY As Long
    Dim lDZ As Long
    
    zFilteredObject = zAntiSQLCrash(zObject)
    
    If (UCase(zFilteredObject) = "SELF") Then zFilteredObject = zOPlayerName
    If (InStr(UCase(zFilteredObject), " ") > 0) Then zFilteredObject = MyCStr(Mid(zFilteredObject, 1, InStr(UCase(zFilteredObject), " ")))
    lTopObject = lTop(zFilteredObject)
    
    bOkay = False
    
    subDirectionControl lTX, lTY, lTZ, lngX, lngY, lngZ, zObject
    zGender = "M" 'everything is male unless female
    'Look at the Door for a door anyways and find its doordescription
    If (Not bOkay) Then
        'lDoorID = 0
        zDoorName = zObject
        bDoorTest = False
        'zDoorName = MyCStr(Mid(zDoorName, 1, InStr(zDoorName, "[") - 1))
        If (lTX = lngX And lTY = lngY And lTZ = lngZ) Then 'door name not the direction
            Set rsDoorTest = MyDB.OpenRecordset("SELECT DoorID, X, Y, Z FROM tblDoor WHERE (DoorName LIKE '*" & zDoorName & "*') AND (X=" & lngX & " or Y=" & lngY & ") ORDER BY DoorID;", dbOpenSnapshot)
            If (Not rsDoorTest.EOF) Then 'a door by that name is nearby?
                'lDoorID = MyCLng(rsDoorTest!DoorID)
                lDX = MyCLng(rsDoorTest!x)
                lDY = MyCLng(rsDoorTest!y)
                lDZ = MyCLng(rsDoorTest!z)
                bDoorTest = (Abs(lDX - lngX) + Abs(lDY - lngY) + Abs(lDZ - lngZ)) = 1
            End If
            Set rsDoorTest = Nothing
        End If
        
        If (bDoorTest) Then
            lTX = lDX
            lTY = lDY
            lTZ = lDZ
        End If
        
        Set rsData = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " DoorName, DoorDesc, DoorHasWindow, Status, X, Y, Z FROM tblDoor WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbOpenSnapshot)
        If (Not rsData.EOF) Then
            rsData.MoveLast
            If (bAreaMovementAllowed(MyCLng(rsData!x), MyCLng(rsData!y), MyCLng(rsData!z), lngX, lngY, lngZ, 0)) Then 'can we see the door though a RB?
            zAdVerbName = zAdverb(MyCStr(rsData!DoorName), 4) & zShortstop(MyCStr(rsData!DoorName))
            subSendMsg "&MYou look at " & zAdVerbName & "." & vbCrLf & gblzFNMAG & (MyCStr(rsData!DoorDesc)) & vbCrLf & "&y" & zLockIndicator(MyCStr(rsData!Status)) & vbCrLf & zDoorHasWindowIndicator(MyCInt(rsData!DoorHasWindow)), zPortID
            'subSendMsgAreaExcept2 gblzFBWHI & zOPlayerName & gblzFNMAG & " looks at the " & zShortstop(MyCStr(rsData!DoorName)) & ".", lngX, lngY, lngZ, zPortID, ""
            zAdVerbName = zShortstop(MyCStr(rsData!DoorName))
            subSendMsgAreaAllDetectInvisibility gblzFNMAG, lOPlayerID, _
                "Someone looks at " & zAdVerbName & ".", _
                zOPlayerName & " looks at " & zAdVerbName & ".", _
                "", _
                "", _
                lngX, lngY, lngZ, (lInvisibilityDuration <> 0), ""
            bOkay = True
            End If
        End If
        Set rsData = Nothing
    End If
    
    
    If (Not bOkay) Then 'Look at mob
        zGetAdditionalInfo = ""
        Set rsData = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " Gender, MainGroup, GraphicsID, Flys, FlyHeight, Invisible, MobID, MobName, MobDesc, MobLevel FROM tblMob WHERE (RespawnDelay=0 AND X=" & lngX & " AND Y=" & lngY & " AND Z=" & lngZ & " AND MobName Like '*" & zFilteredObject & "*') ORDER BY MobID;", dbOpenSnapshot)
        If (Not rsData.EOF) Then
            rsData.MoveLast
            lMainGroup = MyCLng(rsData!MainGroup)
            zGender = MyCStr(rsData!Gender)
            lID = MyCLng(rsData!MobID)
            lGID = MyCLng(rsData!GraphicsID)
            lFlyHeight = MyCLng(rsData!FlyHeight)
            bInvisible = (MyCInt(rsData!Invisible) <> 0 And lDetectInvisibilityDuration = 0)
            If (Not bInvisible) Then
                lThingsToSay = lReturnMobTotalPhrases(lID)
                rsData.MoveLast
                zAdVerbName = zAdverb(MyCStr(rsData!MobName), 2) & zShortstop(MyCStr(rsData!MobName))
                bOkay = True
                subPrintAnAsciiPicturebyMainGroup lMainGroup, zPortID
                subSendMsgAreaAllDISmart "&M", zOPlayerName, "You look at " & zAdVerbName & ".", zAdVerbName, "%s1 looks at %s2.", lngX, lngY, lngZ, "", MyCInt(rsData!Invisible)
                If (Len(MyCStr(rsData!MobDesc)) > 0) Then
                    subSendMsg "&m" & (MyCStr(rsData!MobDesc)), zPortID
                Else
                    subSendMsg "&gThere is nothing special about " & zAdVerbName & ".", zPortID
                End If
                Select Case (lFlyHeight)
                    Case 0 To 1 'not noticable (this is in centremetres)
                    Case 2 To 30 'up to 1 foot is hovering
                        subSendMsg "&wft[hovering near you@" & Format((lFlyHeight / glblCentimetreToFeetConverter), "FIXED") & "]", zPortID
                    Case Else
                        subSendMsg "&wft[high above you flying@" & Format((lFlyHeight / glblCentimetreToFeetConverter), "FIXED") & "]", zPortID
                End Select
                If (lThingsToSay <> 0) Then subSendMsg gblzFNBLU & zAdVerbName & " knows " & lThingsToSay & " phrases.", zPortID
                subMobContents zPortID, "Additionally you see,", lID, lMagicFind
                subConsiderTarget zPortID, lPlayerLevel, lCHITROLL, lCAC, "", lngX, lngY, lngZ, lStatus, lDetectInvisibilityDuration, lID
                If (gblbGraphicIDsOnOff(MyCLng(zPortID)) Or lImmortalLevel > 0) Then
                    subSendMsg "&r" & zAdVerbName & " is level " & MyCLng(rsData!MobLevel) & ", MID#<" & lID & "> GID#<" & zTranslateGraphicalID(lGID) & ">", zPortID
                Else
                    subSendMsg "&r" & zAdVerbName & " is level " & MyCLng(rsData!MobLevel), zPortID
                End If
            'Else
                'subSendMsg "&BSomething invisible is distorting what you are trying to look at.", zPortID
            End If
        End If
        Set rsData = Nothing
    End If
    
    'Pets see also subShowPets
    If (Not bOkay) Then
        Set rsData = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " tblPlayer.InvisibilityDuration, tblPlayer.PlayerName, tblPlayer.PortID, tblMob.MobName, tblMob.MobID, tblMob.MobDesc, tblPlayerPet.PetName, tblPlayerPet.Mountable FROM (tblPlayer INNER JOIN tblPlayerPet ON tblPlayer.PlayerID = tblPlayerPet.PlayerID) INNER JOIN tblMob ON tblPlayerPet.MobID = tblMob.MobID WHERE (((tblPlayerPet.PetName) Like '*" & zFilteredObject & "*') AND ((tblPlayer.X)=" & lngX & ") AND ((tblPlayer.Y)=" & lngY & ") AND ((tblPlayer.Z)=" & lngZ & ") AND ((tblPlayer.PortID) Is Not Null And (tblPlayer.PortID)<>'' And (tblPlayer.PortID)<>'0'));", dbOpenSnapshot)
        If (Not rsData.EOF) Then
            rsData.MoveLast
            zAdVerbName = zShortstop(MyCStr(rsData!PetName))
            zAdVerbName = zAdverb(zAdVerbName, 4) & zAdVerbName
            If (lImmortalLevel > 0) Then zImmortalMsg = "&r(EYE) &WID &a" & MyCLng(rsData!MobID)
            If (MyCInt(rsData!Mountable) <> 0) Then
                subSendMsgAreaAllDISmart "&M", zOPlayerName, "You look at (mounted) " & zAdVerbName & " " & zImmortalMsg & vbCrLf & gblzFNMAG & (MyCStr(rsData!MobDesc)), zAdVerbName, "%s1 looks at (mounted) %s2", lngX, lngY, lngZ, "", MyCLng(rsData!InvisibilityDuration)
            Else
                subSendMsgAreaAllDISmart "&M", zOPlayerName, "You look at " & zAdVerbName & " " & zImmortalMsg & vbCrLf & gblzFNMAG & (MyCStr(rsData!MobDesc)), zAdVerbName, "%s1 looks at %s2", lngX, lngY, lngZ, "", MyCLng(rsData!InvisibilityDuration)
            End If
            bOkay = True
        End If
        Set rsData = Nothing
    End If
       
    If (Not bOkay) Then
        lShadowCloakDuration = 0
        'look at a Player
        Set rsData = Nothing
        Set rsData = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " TurnedIntoAnimalType, SleepDuration, BlindDuration, ShadowCloakDuration, Status, StunDuration, PortID, Height, PlayerID, PlayerName, PlayerDesc, Gender, Class, Race, PlayerLevel, CDEX, CINT, CHP, OHP, InvisibilityDuration FROM tblPlayer WHERE (PlayerName Like """ & zFilteredObject & "*"" AND X=" & lngX & " AND Y=" & lngY & " AND Z=" & lngZ & " AND Len([PortID])>1) ORDER BY PlayerID;", dbOpenSnapshot)
        If (Not rsData.EOF) Then
            rsData.MoveLast
            zGender = MyCStr(rsData!Gender)
            zRace = MyCStr(rsData!Race)
            zClass = MyCStr(rsData!Class)
            lTurnedIntoAnimalType = MyCLng(rsData!TurnedIntoAnimalType)
            lLookPlayerID = MyCLng(rsData!PlayerID)
            lShadowCloakDuration = MyCLng(rsData!ShadowCloakDuration)
            lLookInvisibilityDuration = MyCLng(rsData!InvisibilityDuration)
            'subSendMsgAreaAll "&B^&g" & zPlayerName & "<" & lPlayerLevel & "> [" & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & "]", lX, lY, lZ
            If (lDetectInvisibilityDuration <> 0 Or lLookInvisibilityDuration = 0) Then
                zAdVerbName = MyCStr(rsData!PlayerName)
                Set rsScan = MyDB.OpenRecordset("SELECT PlayerScarDesc FROM tblPlayerScar WHERE (PlayerID=" & MyCLng(rsData!PlayerID) & ");", dbOpenSnapshot)
                If (Not rsScan.EOF) Then
                    zScarToShow = vbCrLf & "&y"
                    Do While (Not rsScan.EOF)
                        zScarToShow = zScarToShow & MyCStr(rsScan!PlayerScarDesc) & vbCrLf
                        rsScan.MoveNext
                    Loop
                    zScarToShow = (zTrimCrLf(zScarToShow))
                End If
                Set rsScan = Nothing
                
                rsData.MoveLast
                lRatio = MyCLng(rsData!Height)
                If (lRatio < 1) Then lRatio = 1 'prevents div by 0 err
                lRatio = (lHeight * 100) / lRatio
                If (lTurnedIntoAnimalType > 0) Then
                    zTransformed = " and transformed into a " & zTranslatePoofAnimalTypes(1, lTurnedIntoAnimalType) & "."
                Else
                    zTransformed = "."
                End If
                
                subSendMsg "&W--------------------------------------------------------------------------------", zPortID
                subSendMsg "&M" & MyCStr(rsData!PlayerName) & " is a " & zTranslateGender(zGender, 31) & " " & zTranslateRace(MyCStr(rsData!Race)) & " " & zTranslateClass(MyCStr(rsData!Class)) & zTransformed & zScarToShow, zPortID
                'this works but too spammy to look at, subSendMsg "&m"  & zTranslatePlayerBeauty(MyCStr(rsData!PlayerBeauty)), zPortID
                subSendMsg gblzFNYEL & (MyCStr(rsData!PlayerDesc)), zPortID
                If (bShortTurnedIntoAnimalType(lTurnedIntoAnimalType)) Then 'TurnedIntoAnimalType is the variable morph into a frog or bull etc..
                    subSendMsg "&W" & MyCStr(rsData!PlayerName) & " has no height to speak of " & zTranslateHitpointLookDifference(MyCLng(rsData!CHP), MyCLng(rsData!OHP)), zPortID
                Else
                    subSendMsg "&W" & zTranslateHeightDifference(lRatio) & vbCrLf & zTranslateHitpointLookDifference(MyCLng(rsData!CHP), MyCLng(rsData!OHP)), zPortID
                End If
                
                If gbllWITCHLOCKPlayerID <> MyCLng(rsData!PlayerID) Then
                    If (lTurnedIntoAnimalType = 0 Or lTurnedIntoAnimalType = 7) Then 'bulls and normal people have eq and inventory
                        If (lShadowCloakDuration = 0) Then
                            subPlayerEquipmentList zPortID, zWord3, zWord4, MyCLng(rsData!PlayerID)
                        Else
                            subSendMsg "&a" & MyCStr(rsData!PlayerName) & "'s equipment is concealed in shadows.", zPortID
                        End If
                        If (lRandom(lPlayerStealPeekLevel) > lRandom(MyCLng(rsData!PlayerLevel) + lRandom(MyCLng(rsData!CDEX)))) Then
                            If (lShadowCloakDuration = 0) Then
                                subSendMsg "&G" & vbCrLf & "You peek at the inventory of " & MyCStr(rsData!PlayerName) & ".", zPortID
                                subPlayerInventoryList zPortID, MyCLng(rsData!PlayerID)
                            Else
                                subSendMsg "&a" & MyCStr(rsData!PlayerName) & "'s inventory is concealed in shadows.", zPortID
                            End If
                        Else
                            subSendMsg gblzFNGRE & vbCrLf & "You fail to peek at the inventory of " & MyCStr(rsData!PlayerName) & ".", zPortID
                        End If
                    Else
                        subSendMsg "&mEverything the person was wearing is distorted and twisted looking.", zPortID
                    End If
                Else
                    Select Case zGender
                        Case "F"
                            subSendMsg "&mWOW, sooooooo beautiful.", zPortID
                        Case Else
                            subSendMsg "&mWOW, sooooooo handsom.", zPortID
                    End Select
                End If
                
                If (lImmortalLevel >= 1) Then
                    subSendMsg "&r(EYE) " & MyCStr(rsData!PlayerName) & " is level " & MyCLng(rsData!PlayerLevel) & ", ID#" & MyCLng(rsData!PlayerID), zPortID
                End If
                
                'If (MyCLng(rsData!Status) <> 50 And MyCLng(rsData!BlindDuration) = 0 And MyCLng(rsData!StunDuration) = 0 And MyCLng(rsData!SleepDuration) = 0) Then
                '    subSendMsg "&M"  & zOPlayerName & " looks at you.", MyCStr(rsData!PortID)
                'End If
                'subSendMsgAreaExcept2 gblzFBWHI & zOPlayerName & gblzFNMAG & " looks at " & zAdVerbName & ".", lngX, lngY, lngZ, zPortID, MyCStr(rsData!PortID)
                'subSendMsgAreaAllDetectInvisibility gblzFNMAG, lOPlayerID, _
                    "Someone looks at " & zAdVerbName & ".", _
                    zOPlayerName & " looks at " & zAdVerbName & ".", _
                    gblzFBMAG & "You look at " & zAdVerbName & ".", _
                    gblzFBMAG & "You look at " & zAdVerbName & ".", _
                    lngX, lngY, lngZ, (lLookInvisibilityDuration <> 0), MyCStr(rsData!PortID)
                
                subSendMsgAreaAllDetectInvisibility gblzFNMAG, lLookPlayerID, _
                    "Someone looks at " & zAdVerbName & ".", _
                    zOPlayerName & " looks at " & zAdVerbName & ".", _
                    gblzFBMAG & "Someone looks at you.", _
                    gblzFBMAG & zOPlayerName & " looks at you.", _
                    lngX, lngY, lngZ, (lInvisibilityDuration <> 0), zPortID
                bOkay = True
            End If
        End If
        Set rsData = Nothing
    End If
    
    If (Not bOkay) Then
        zGetAdditionalInfo = ""
        'Look at an object on the ground first
        Set rsData = MyDB.OpenRecordset("SELECT TOP " & lTopObject & " MainGroup, Height, Width, Length, HeightRequirement, Location, LevelRequirement, WeightMax, WeightFull, Treasure, Rare, WearReqSTR, WearReqINT, WearReqWIS, WearReqDEX, WearReqCON, WearReqCHA, WearReqLUC, WearReqAC, WearReqHP, WearReqEssence, WearReqMana, WearReqSoul, WearReqMove, ObjectID, ObjectName, ObjectDesc, LockStatus, RottingRounds, DurabilityBroken, DurabilityMAX, MissileGroupAmount, PeerAllowed, PeerX, PeerY, PeerZ, LanguageMessageID, AllAttributes FROM tblObject WHERE (X=" & lngX & " AND Y=" & lngY & " AND Z=" & lngZ & " AND Burried=False AND Status=0 AND ObjectName Like ""*" & zFilteredObject & "*"") ORDER BY ObjectID;", dbOpenSnapshot)
        If (rsData.EOF) Then
            Set rsData = Nothing
            zSQL = "SELECT TOP " & lTopObject & " tblObject.MainGroup, tblObject.Height, tblObject.Width, tblObject.Length, tblObject.HeightRequirement, tblObject.Treasure, tblObject.WeightMax, tblObject.WeightFull, tblObject.Location, tblObject.LevelRequirement,tblObject.Rare, tblObject.WearReqSTR, tblObject.WearReqINT, tblObject.WearReqWIS, tblObject.WearReqDEX, tblObject.WearReqCON, tblObject.WearReqCHA, tblObject.WearReqLUC, tblObject.WearReqAC, tblObject.WearReqHP, tblObject.WearReqEssence, tblObject.WearReqMana, tblObject.WearReqSoul, tblObject.WearReqMove, tblPlayerInventoryItems.PlayerID, tblObject.PeerAllowed, tblObject.PeerX, tblObject.PeerY, tblObject.PeerZ, tblObject.LockStatus, tblObject.ObjectID, tblObject.LanguageMessageID, tblObject.ObjectName, tblObject.ObjectDesc, tblObject.RottingRounds, tblObject.DurabilityBroken, tblObject.DurabilityMAX, tblObject.MissileGroupAmount, tblObject.AllAttributes FROM "
            zSQL = zSQL & "tblObject INNER JOIN tblPlayerInventoryItems ON tblObject.ObjectID = tblPlayerInventoryItems.ObjectID WHERE (((tblPlayerInventoryItems.PlayerID)=" & lOPlayerID & ") AND ((tblObject.ObjectName) Like ""*" & zFilteredObject & "*"")) ORDER BY tblObject.ObjectID;"
            'Okay, the object is not on the ground, try in inventory.
            Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            If (rsData.EOF) Then
                Set rsData = Nothing
                'Try looking at the equipment (last resort)
                zSQL = "SELECT TOP " & lTopObject & " tblObject.MainGroup, tblObject.Height, tblObject.Width, tblObject.Length, tblObject.HeightRequirement, tblObject.LevelRequirement, tblObject.WeightMax, tblObject.WeightFull, tblObject.Location, tblObject.Treasure, tblObject.Rare, "
                zSQL = zSQL & "tblObject.WearReqSTR, tblObject.WearReqINT, tblObject.WearReqWIS, tblObject.WearReqDEX, tblObject.WearReqCON, tblObject.WearReqCHA, tblObject.WearReqLUC, tblObject.WearReqAC, tblObject.WearReqHP, tblObject.WearReqEssence, tblObject.WearReqMana, tblObject.WearReqSoul, tblObject.WearReqMove, tblPlayerEquipmentItems.PlayerID, tblObject.PeerAllowed, tblObject.PeerX, tblObject.LanguageMessageID, tblObject.PeerY, tblObject.PeerZ, tblObject.ObjectID, tblObject.LockStatus, tblObject.RottingRounds, tblObject.ObjectName, tblObject.ObjectDesc, tblObject.DurabilityBroken, tblObject.DurabilityMAX, tblObject.MissileGroupAmount, tblObject.AllAttributes FROM tblObject INNER JOIN tblPlayerEquipmentItems ON tblObject.ObjectID = tblPlayerEquipmentItems.ObjectID "
                zSQL = zSQL & "WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lOPlayerID & ") AND ((tblObject.ObjectName) Like ""*" & zFilteredObject & "*"")) ORDER BY tblPlayerEquipmentItems.ObjectID;"
                Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                If (Not rsData.EOF) Then
                    zGetAdditionalInfo = "equipment"
                End If
            Else
                zGetAdditionalInfo = "inventory"
            End If
        Else
            'Height 180cm is about 6 feet in height - place shop signs at around 300 and benchs at 0 to 40
            Select Case (MyCLng(rsData!Location) = 0)
                Case True
                    zGetAdditionalInfo = zTranslateHeightLocationZero(MyCLng(rsData!Height))
                Case False
                    zGetAdditionalInfo = "ground"
            End Select
        End If
        
        If (Not rsData.EOF) Then
            rsData.MoveLast
            bOkay = True
            zWearReq = ""
            Do While (Not rsData.EOF)
                lObjectID = MyCLng(rsData!ObjectID)
                lLocation = MyCLng(rsData!Location)
                lRottingRounds = MyCLng(rsData!RottingRounds)
                If (lLocation <> 0) Then 'we dont show requirements for grounded objects like a chair or a safe
                    If (bReturnAppraiserCheckRaceClass(zPlayerRace, zPlayerClass)) Then
                        subIdentifyObjectID lObjectID, zPortID, False
                    End If
                    lWeightMax = MyCLng(rsData!WeightMax)
                    If (lWeightMax <> 0) Then 'its a container then
                        lWeightFull = MyCLng(rsData!WeightFull)
                        lWeightFullPercent = MyCLng((lWeightFull * 100) / lWeightMax)
                        Select Case lWeightFullPercent
                            Case 0
                                zWearReq = zWearReq & " [Empty]"
                            Case 1 To 10
                                zWearReq = zWearReq & " [Some Contents]"
                            Case 89 To 98
                                zWearReq = zWearReq & " [Nearly Full]"
                            Case 99 To 100
                                zWearReq = zWearReq & " [Full]"
                            Case Else
                                zWearReq = zWearReq & " [" & lWeightFullPercent & "% full]"
                        End Select
                    End If
                    If (MyCLng(rsData!HeightRequirement) > 0) Then zWearReq = zWearReq & " HeightReq[" & Format((MyCLng(rsData!HeightRequirement) / glblCentimetreToFeetConverter), "FIXED") & "]"
                    If (MyCLng(rsData!Height) > 0) Then zWearReq = zWearReq & " H[" & Format((MyCLng(rsData!Height) / glblCentimetreToFeetConverter), "FIXED") & "]"
                    If (MyCLng(rsData!Width) > 0) Then zWearReq = zWearReq & " W[" & Format((MyCLng(rsData!Width) / glblCentimetreToFeetConverter), "FIXED") & "]"
                    If (MyCLng(rsData!Length) > 0) Then zWearReq = zWearReq & " L[" & Format((MyCLng(rsData!Length) / glblCentimetreToFeetConverter), "FIXED") & "]"
                    If (MyCLng(rsData!LevelRequirement) <> 0) Then zWearReq = zWearReq & " Lv[" & MyCLng(rsData!LevelRequirement) & "]"
                    If (MyCLng(rsData!Rare) <> 0) Then zWearReq = zWearReq & " R[" & MyCLng(rsData!Rare) & "]"
                    If (MyCLng(rsData!Treasure) <> 0) Then zWearReq = zWearReq & " T[" & MyCLng(rsData!Treasure) & "]"
                    If (MyCLng(rsData!WearReqSTR) <> 0) Then zWearReq = zWearReq & " STR[" & MyCLng(rsData!WearReqSTR) & "]"
                    If (MyCLng(rsData!WearReqINT) <> 0) Then zWearReq = zWearReq & " INT[" & MyCLng(rsData!WearReqINT) & "]"
                    If (MyCLng(rsData!WearReqWIS) <> 0) Then zWearReq = zWearReq & " WIS[" & MyCLng(rsData!WearReqWIS) & "]"
                    If (MyCLng(rsData!WearReqDEX) <> 0) Then zWearReq = zWearReq & " DEX[" & MyCLng(rsData!WearReqDEX) & "]"
                    If (MyCLng(rsData!WearReqCON) <> 0) Then zWearReq = zWearReq & " CON[" & MyCLng(rsData!WearReqCON) & "]"
                    If (MyCLng(rsData!WearReqCHA) <> 0) Then zWearReq = zWearReq & " CHA[" & MyCLng(rsData!WearReqCHA) & "]"
                    If (MyCLng(rsData!WearReqLUC) <> 0) Then zWearReq = zWearReq & " LUC[" & MyCLng(rsData!WearReqLUC) & "]"
                    If (MyCLng(rsData!WearReqAC) <> 0) Then zWearReq = zWearReq & " AC[" & MyCLng(rsData!WearReqAC) & "]"
                    If (MyCLng(rsData!WearReqHP) <> 0) Then zWearReq = zWearReq & " CHP[" & MyCLng(rsData!WearReqHP) & "]"
                    If (MyCLng(rsData!WearReqEssence) <> 0) Then zWearReq = zWearReq & " CEsse[" & MyCLng(rsData!WearReqEssence) & "]"
                    If (MyCLng(rsData!WearReqMana) <> 0) Then zWearReq = zWearReq & " CMana[" & MyCLng(rsData!WearReqMana) & "]"
                    If (MyCLng(rsData!WearReqSoul) <> 0) Then zWearReq = zWearReq & " CSoul[" & MyCLng(rsData!WearReqSoul) & "]"
                    If (MyCLng(rsData!WearReqMove) <> 0) Then zWearReq = zWearReq & " CMove[" & MyCLng(rsData!WearReqMove) & "]"
                End If
                
                zAdVerbName = (zAdverb(MyCStr(rsData!ObjectName), 4) & zShortstop(MyCStr(rsData!ObjectName)))
                If (Len(MyCStr(rsData!ObjectDesc)) > 0) Then
                    subSendMsg "&MYou look at [" & zGetAdditionalInfo & "] " & zAdVerbName & "." & vbCrLf & gblzFNMAG & (MyCStr(rsData!ObjectDesc)), zPortID
                Else
                    subSendMsg "&gThere is nothing special about [" & zGetAdditionalInfo & "] " & zAdVerbName & ".", zPortID
                End If
                                
                If (Len(MyCStr(rsData!AllAttributes)) > 0) Then subSendMsg "&B" & (MyCStr(rsData!AllAttributes)), zPortID
                If (Len(zWearReq) > 0) Then subSendMsg "&B" & (zWearReq), zPortID
                
                If (MyCLng(rsData!LanguageMessageID) <> 0) Then
                    subSendMsg "&BThere is special writing on the " & zShortstop(MyCStr(rsData!ObjectName)) & "." & vbCrLf & zLanguageMessage(MyCLng(rsData!LanguageMessageID), zLanguagesKnown), zPortID
                End If
                
                If (MyCLng(rsData!PeerAllowed) <> 0) Then subObjectPeer 0, zOPlayerName, MyCStr(rsData!ObjectName), MyCLng(rsData!PeerX), MyCLng(rsData!PeerY), MyCLng(rsData!PeerZ), zPortID, True
                
                If (MyCLng(rsData!MissileGroupAmount) > 0) Then subSendMsg gblzFNYEL & zAdVerbName & " has " & MyCLng(rsData!MissileGroupAmount) & " round(s) left.", zPortID
                
                If (lRottingRounds > 0) Then
                    If (lLocation > 0) Then
                        subSendMsg gblzFNYEL & zAdVerbName & " " & zTranslateRottingContainer(lRottingRounds, 1), zPortID
                    Else
                        subSendMsg gblzFNYEL & zAdVerbName & " " & zTranslateRottingContainer(lRottingRounds, 2), zPortID
                    End If
                End If
                
                If (MyCInt(rsData!LockStatus) > 0 And MyCLng(rsData!RottingRounds) = 0) Then subSendMsg gblzFNYEL & zAdVerbName & " " & zTranslateObjectLockIndicator(MyCInt(rsData!LockStatus)), zPortID
                
                If (MyCInt(rsData!LockStatus) = 10 Or MyCInt(rsData!LockStatus) = 20 Or MyCInt(rsData!LockStatus) = 30) Then
                    subObjectContents zPortID, MyCLng(rsData!ObjectID), "Inside you see,"
                Else
                    If (lRottingRounds = 0) Then subSendMsg gblzFNYEL & zAdVerbName & " " & zTranslateObjectDurability(MyCLng(rsData!DurabilityBroken), MyCLng(rsData!DurabilityMAX)), zPortID
                End If
                
                subSendMsgAreaAllDetectInvisibility gblzFNMAG, lOPlayerID, _
                    "Someone looks at " & zAdVerbName & ".", _
                    zOPlayerName & " looks at " & zAdVerbName & ".", _
                    "", _
                    "", _
                    lngX, lngY, lngZ, (lInvisibilityDuration <> 0), ""
                If (gblbGraphicIDsOnOff(MyCLng(zPortID)) Or lImmortalLevel > 0) Then
                    subSendMsg gblzFNGRE & zAdVerbName & " OID#<" & MyCLng(rsData!ObjectID) & ">  GID#<" & zTranslateGraphicalID(lGID) & ">", zPortID
                End If
                rsData.MoveNext
            Loop
        End If
        Set rsData = Nothing
    End If
    
    If (Not bOkay) Then
        subSendMsg "&gYou do not see that here.", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subLook," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bAreaExists(lngX As Long, lngY As Long, lngZ As Long) As Boolean
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bReturn As Boolean
    
    Set rsData = MyDB.OpenRecordset("SELECT AreaID FROM tblArea WHERE (X=" & lngX & " AND Y=" & lngY & " AND (Z=" & lngZ & "));", dbOpenSnapshot)
    bReturn = (Not rsData.EOF)
    Set rsData = Nothing
    
    bAreaExists = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaExists," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bAreaMovementDoorAllowed(lTX As Long, lTY As Long, lTZ As Long)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bReturn As Boolean
    
    Set rsData = MyDB.OpenRecordset("SELECT DoorID FROM tblDoor WHERE (X=" & lTX & " AND Y=" & lTY & " AND Z=" & lTZ & ");", dbOpenSnapshot)
    bReturn = (Not rsData.EOF)
    Set rsData = Nothing
    bAreaMovementDoorAllowed = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaMovementDoorAllowed," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bAreaMovementAllowedPEEK(lTX As Long, lTY As Long, lTZ As Long, lOX As Long, lOY As Long, lOZ As Long, lMobType As Long)
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim rsData As Recordset
    
    If (lMobType <> 1) Then 'Ghost?
        bReturn = False
        
        '(1=N, 2=S, 3=E, 4=W, 5=NE, 6=NW, 7=SE, 8=SW) 1 = Blocked, 0 = Not blocked This prevents touching areas to go to eachother. This can be used to create one way entries to the area too.  BlockExits can be used for one way traveling which is similar.
        If (Abs(lTX - lOX) <= 1 Or Abs(lTY - lOY) <= 1 Or Abs(lTZ - lOZ) <= 1) Then 'at least one touching area to save load time
            Set rsData = MyDB.OpenRecordset("SELECT BlockedExits FROM tblArea WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND Z mod 2 = 0);", dbOpenSnapshot)
            If (Not rsData.EOF) Then 'This also double checks to make sure the area still exists.
                'Debug.Print zTranslateMatrixDirection(lTX, lTY, lTZ, lOX, lOY, lOZ, 1) & " = " & rsData!BlockedExits
                'All mobs know where the hidden exits are and are not affected by area telepods (see also RXYZ command)
                Select Case zTranslateMatrixDirection(lTX, lTY, lTZ, lOX, lOY, lOZ, 1)
                    Case "north"
                        bReturn = (Mid(rsData!BlockedExits, 1, 1) = "0")
                    Case "south"
                        bReturn = (Mid(rsData!BlockedExits, 2, 1) = "0")
                    Case "east"
                        bReturn = (Mid(rsData!BlockedExits, 3, 1) = "0")
                    Case "west"
                        bReturn = (Mid(rsData!BlockedExits, 4, 1) = "0")
                    Case "northeast"
                        bReturn = (Mid(rsData!BlockedExits, 5, 1) = "0")
                    Case "northwest"
                        bReturn = (Mid(rsData!BlockedExits, 6, 1) = "0")
                    Case "southeast"
                        bReturn = (Mid(rsData!BlockedExits, 7, 1) = "0")
                    Case "southwest"
                        bReturn = (Mid(rsData!BlockedExits, 8, 1) = "0")
                    Case "above"
                        bReturn = (Mid(rsData!BlockedExits, 9, 1) = "0")
                    Case "below"
                        bReturn = (Mid(rsData!BlockedExits, 10, 1) = "0")
                End Select
            End If
            Set rsData = Nothing
        End If
    Else
        subSendMsgAreaAll "                 &G ~ ~ ~ ectoplasm drips down the walls ~ ~ ~", lOX, lOY, lOZ
    End If
    bAreaMovementAllowedPEEK = (bReturn Or lMobType = 1)
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaMovementAllowedPEEK," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bAreaMovementAllowed(lTX As Long, lTY As Long, lTZ As Long, lOX As Long, lOY As Long, lOZ As Long, lMobType As Long)
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim rsData As Recordset
    
    If (lMobType <> 1) Then 'Ghost?
        bReturn = False
        
        '(1=N, 2=S, 3=E, 4=W, 5=NE, 6=NW, 7=SE, 8=SW) 1 = Blocked, 0 = Not blocked This prevents touching areas to go to eachother. This can be used to create one way entries to the area too.  BlockExits can be used for one way traveling which is similar.
        If (Abs(lTX - lOX) <= 1 Or Abs(lTY - lOY) <= 1 Or Abs(lTZ - lOZ) <= 1) Then 'at least one touching area to save load time
            Set rsData = MyDB.OpenRecordset("SELECT BlockedExits FROM tblArea WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & " AND FallToDeathSpot=0 AND AreaEventZoneID=0 AND FlyLevel=0 AND AreaTrapID=0 AND PlayerID=0 AND NoQuestZone=False AND DXYZActive<>1 AND PlayerType=0 AND ClanID=0 AND MobSpaceShipLevel=0 AND Z mod 2 = 0);", dbOpenSnapshot)
            If (Not rsData.EOF) Then 'This also double checks to make sure the area still exists.
                'Debug.Print zTranslateMatrixDirection(lTX, lTY, lTZ, lOX, lOY, lOZ, 1) & " = " & rsData!BlockedExits
                'All mobs know where the hidden exits are and are not affected by area telepods (see also RXYZ command)
                Select Case zTranslateMatrixDirection(lTX, lTY, lTZ, lOX, lOY, lOZ, 1)
                    Case "north"
                        bReturn = (Mid(rsData!BlockedExits, 1, 1) = "0")
                    Case "south"
                        bReturn = (Mid(rsData!BlockedExits, 2, 1) = "0")
                    Case "east"
                        bReturn = (Mid(rsData!BlockedExits, 3, 1) = "0")
                    Case "west"
                        bReturn = (Mid(rsData!BlockedExits, 4, 1) = "0")
                    Case "northeast"
                        bReturn = (Mid(rsData!BlockedExits, 5, 1) = "0")
                    Case "northwest"
                        bReturn = (Mid(rsData!BlockedExits, 6, 1) = "0")
                    Case "southeast"
                        bReturn = (Mid(rsData!BlockedExits, 7, 1) = "0")
                    Case "southwest"
                        bReturn = (Mid(rsData!BlockedExits, 8, 1) = "0")
                    Case "above"
                        bReturn = (Mid(rsData!BlockedExits, 9, 1) = "0")
                    Case "below"
                        bReturn = (Mid(rsData!BlockedExits, 10, 1) = "0")
                End Select
            End If
            Set rsData = Nothing
        End If
    Else
        subSendMsgAreaAll "                 &G ~ ~ ~ ectoplasm drips down the walls ~ ~ ~", lOX, lOY, lOZ
    End If
    bAreaMovementAllowed = (bReturn Or lMobType = 1)
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaMovementAllowed," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function bAreaMovementAllowedBLOCKEDONLY(lTX As Long, lTY As Long, lTZ As Long, lOX As Long, lOY As Long, lOZ As Long, lMobType As Long)
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim rsData As Recordset
    
    If (lMobType <> 1) Then 'Ghost?
        bReturn = False
        
        '(1=N, 2=S, 3=E, 4=W, 5=NE, 6=NW, 7=SE, 8=SW) 1 = Blocked, 0 = Not blocked This prevents touching areas to go to eachother. This can be used to create one way entries to the area too.  BlockExits can be used for one way traveling which is similar.
        If (Abs(lTX - lOX) <= 1 Or Abs(lTY - lOY) <= 1 Or Abs(lTZ - lOZ) <= 1) Then
            Set rsData = MyDB.OpenRecordset("SELECT BlockedExits FROM tblArea WHERE (X=" & lOX & " AND Y=" & lOY & " AND Z=" & lOZ & ");", dbOpenSnapshot)
            If (Not rsData.EOF) Then 'This also double checks to make sure the area still exists.
                'Debug.Print zTranslateMatrixDirection(lTX, lTY, lTZ, lOX, lOY, lOZ, 1) & " = " & rsData!BlockedExits
                'All mobs know where the hidden exits are and are not affected by area telepods (see also RXYZ command)
                Select Case zTranslateMatrixDirection(lTX, lTY, lTZ, lOX, lOY, lOZ, 1)
                    Case "north"
                        bReturn = (Mid(rsData!BlockedExits, 1, 1) = "0")
                    Case "south"
                        bReturn = (Mid(rsData!BlockedExits, 2, 1) = "0")
                    Case "east"
                        bReturn = (Mid(rsData!BlockedExits, 3, 1) = "0")
                    Case "west"
                        bReturn = (Mid(rsData!BlockedExits, 4, 1) = "0")
                    Case "northeast"
                        bReturn = (Mid(rsData!BlockedExits, 5, 1) = "0")
                    Case "northwest"
                        bReturn = (Mid(rsData!BlockedExits, 6, 1) = "0")
                    Case "southeast"
                        bReturn = (Mid(rsData!BlockedExits, 7, 1) = "0")
                    Case "southwest"
                        bReturn = (Mid(rsData!BlockedExits, 8, 1) = "0")
                    Case "above"
                        bReturn = (Mid(rsData!BlockedExits, 9, 1) = "0")
                    Case "below"
                        bReturn = (Mid(rsData!BlockedExits, 10, 1) = "0")
                End Select
            End If
            Set rsData = Nothing
        End If
    Else
        subSendMsgAreaAll "                 &G ~ ~ ~ ectoplasm drips down the walls ~ ~ ~", lOX, lOY, lOZ
    End If
    bAreaMovementAllowedBLOCKEDONLY = (bReturn Or lMobType = 1)
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaMovementAllowed," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Function strPlayerPrompt(lngPlayerID As Long) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim strReturn As String
    
    strReturn = ""
    
    Set rsData = MyDB.OpenRecordset("SELECT NumberOfAttacksPerRound, BlindDuration, CEssence, CMana, OEssence, OMana, X, Y, Z FROM tblPlayer WHERE (PlayerID=" & lngPlayerID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        strReturn = strForceSize(MyCStr(rsData!CEssence), 3, " ", "A") & "/ " & strForceSize(MyCStr(rsData!OEssence), 3, " ", "A") & " " & strForceSize(MyCStr(rsData!CMana), 3, " ", "A") & "/" & strForceSize(MyCStr(rsData!OMANA), 3, " ", "A") & "  X:" & strForceSize(MyCStr(rsData!x), 5, " ", "A") & " Y:" & strForceSize(MyCStr(rsData!y), 5, " ", "A") & " Z:" & strForceSize(MyCStr(rsData!z), 5, " ", "A")
    End If
    Set rsData = Nothing
    
    strPlayerPrompt = strReturn
    Exit Function
Err_Check:
    subWriteErrorFile "strPlayerPrompt," & vbCrLf & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subSetFleeDuration(iFlow As Integer, lDuration As Long, zPlayerName As String)
On Error GoTo Err_Check
    If (iFlow > 99) Then 'if the person is fully connected then we have to punish them for spamming
        MyDB.Execute "UPDATE tblPlayer SET PlayerFleeDuration=" & lDuration & " WHERE (PlayerName='" & zPlayerName & "');", dbFailOnError
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSetFleeDuration," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subCompleteBadPersonPoints(iFlow As Integer, zRemoteHostIP As String, iBadPersonPoints As Integer)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    If (iFlow < 100) Then 'we only do this at the logon ports - not while the player plays
        Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerRemoteHostCompletelyBanned WHERE (RemoteHostIP='" & zKeepRealNumbersOnly(zRemoteHostIP) & "');", dbOpenDynaset)
        If (Not rsData.EOF) Then
            rsData.Edit
            rsData!BadPersonPoints = MyCLng(rsData!BadPersonPoints) + iBadPersonPoints
            rsData!LastAttempt = Now()
            rsData.Update
        Else
            rsData.AddNew
            rsData!RemoteHostIP = Mid(zKeepRealNumbersOnly(zRemoteHostIP), 1, 15)
            rsData!BadPersonPoints = iBadPersonPoints
            rsData!Created = Now()
            rsData!LastAttempt = Now()
            rsData.Update
        End If
        Set rsData = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCompleteBadPersonPoints," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lLoginCompletelyBannedIP(zRemoteHostIP As String) As Long
'See Also: lLoginBannedIP 'If (lRandom(4) = 1) Then subSendMsg "&RCITIZEN - IP BANNED - DISCONNECTED - WAIT 2 HOURS!", zPortID
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lReturn As Long
    
    Set rsData = MyDB.OpenRecordset("SELECT BadPersonPoints, RemoteHostIP FROM tblPlayerRemoteHostCompletelyBanned WHERE (RemoteHostIP='" & zKeepRealNumbersOnly(zRemoteHostIP) & "');", dbOpenSnapshot)
    lReturn = 0
    If (Not rsData.EOF) Then
        lReturn = (MyCLng(rsData!BadPersonPoints))
    End If
    Set rsData = Nothing
    lLoginCompletelyBannedIP = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lLoginCompletelyBannedIP," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lCountMatchingPorts(zRemoteHostIP As String) As Long
'See also: basCloseOffMatchingPorts
On Error Resume Next ''xOn Error GoTo Err_Check 'there is no reason to trap this bLocalPorts = (Mid(zRemoteHostIP, 1, 4) = "127." Or Mid(zRemoteHostIP, 1, 4) = "192.")
    Dim bSkipPort As Boolean
    Dim vEachPort As Variant
    Dim rsData As Recordset
    Dim zRemoteHost As String
    Dim lCount As Long
    Dim frmPort20XX As Form
    Dim zGetPortID As String
    Dim lMaxPort As Long
    Dim lReturn As Long
    
    lReturn = 0
    'first we tell them how fast we are processing
    If (gblbAlternateConnectPortsEnabled) Then
        lMaxPort = cstlMaxPort
    Else
        lMaxPort = cstlWin9xMaxPort 'Windows 9x mode
    End If
    
    For lCount = cstlMinPort To lMaxPort
        zGetPortID = lCount
        Set frmPort20XX = fPortXXXX(zGetPortID)

        zRemoteHost = MyCStr(frmPort20XX!lblRemoteHost.Caption)
        If (Mid(UCase(zRemoteHost), 1, 2) = "IP") Then zRemoteHost = Mid(UCase(zRemoteHost), 3)
        
        If (frmPort20XX!ctlServer.State = sckConnected) Then
            If (zRemoteHost = zRemoteHostIP) Then lReturn = lReturn + 1
        End If
    Next lCount
    lCountMatchingPorts = lReturn
    Exit Function
'Err_Check:
'    subWriteErrorFile "lCountMatchingPorts," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub basCloseOffMatchingPorts(zRemoteHostIP As String)
'See also: lCountMatchingPorts
On Error Resume Next
    Dim bSkipPort As Boolean
    Dim vEachPort As Variant
    Dim rsData As Recordset
    Dim zRemoteHost As String
    Dim lCount As Long
    Dim frmPort20XX As Form
    Dim zGetPortID As String
    Dim lMaxPort As Long
    
    'first we tell them how fast we are processing
    If (gblbAlternateConnectPortsEnabled) Then
        lMaxPort = cstlMaxPort
    Else
        lMaxPort = cstlWin9xMaxPort 'Windows 9x mode
    End If
    
    For lCount = cstlMinPort To lMaxPort
        zGetPortID = lCount
        Set frmPort20XX = fPortXXXX(zGetPortID)

        zRemoteHost = MyCStr(frmPort20XX!lblRemoteHost.Caption)
        If (Mid(UCase(zRemoteHost), 1, 2) = "IP") Then zRemoteHost = Mid(UCase(zRemoteHost), 3)
        If (frmPort20XX!ctlServer.State = sckConnected) Then
            If (zRemoteHost = zRemoteHostIP) Then subSendMsg cstzTimerControlQuit, zGetPortID 'we close down their port
        End If
    Next lCount
    'Exit Sub
'Err_Check:
'    subWriteErrorFile "basCloseOffMatchingPorts," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoginEditRemoveCompletelyBannedIP(zRemoteHostIP As String, zSortOrder As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bReturn As Boolean
    Dim zSQL As String
    
    If (UCase(zRemoteHostIP) = "CLEAR") Then
        MyDB.Execute "DELETE RemoteHostIP FROM tblPlayerRemoteHostCompletelyBanned;", dbFailOnError
        subSendMsg "&GCompletely banned list cleared!&g", zPortID
    Else
        If (UCase(zRemoteHostIP) = "ALL" Or zRemoteHostIP = "LIST") Then
            'Print the complete list
            subSendMsg "&GIMMO COMPLETELY LIST of the BANNED    IMMO SET-LV[" & lgblCompletelyBannedMAX & "+] IMMO SPAM-EAR[" & gbllImmortalPortEAR & "]&g", zPortID
            Select Case UCase(Mid(zSortOrder, 1, 1))
                Case "H", "R", "I"
                    zSQL = "SELECT RemoteHostIP, Created, LastAttempt, BadPersonPoints FROM tblPlayerRemoteHostCompletelyBanned WHERE (BadPersonPoints > 10) ORDER BY LastAttempt DESC, RemoteHostIP, BadPersonPoints DESC;"
                Case "B", "P"
                    zSQL = "SELECT RemoteHostIP, Created, LastAttempt, BadPersonPoints FROM tblPlayerRemoteHostCompletelyBanned WHERE (BadPersonPoints > 10) ORDER BY BadPersonPoints DESC, LastAttempt DESC, RemoteHostIP;"
                Case Else
                    zSQL = "SELECT RemoteHostIP, Created, LastAttempt, BadPersonPoints FROM tblPlayerRemoteHostCompletelyBanned WHERE (BadPersonPoints > 10) ORDER BY LastAttempt DESC, BadPersonPoints DESC, RemoteHostIP;"
            End Select
            
            Set rsData = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
            Do While (Not rsData.EOF)
                subSendMsg strForceSize(MyCStr(rsData!RemoteHostIP), 15, " ", "A") & "|C" & Format(rsData!Created, "mmm dd, yyyy hh:nn") & "|LA" & Format(rsData!LastAttempt, "mmm dd, yyyy hh:nn") & "|" & MyCStr(rsData!BadPersonPoints), zPortID
                rsData.MoveNext
            Loop
            Set rsData = Nothing
        Else
            If (InStr(zRemoteHostIP, ".") <> 0) Then
                Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerRemoteHostCompletelyBanned WHERE (RemoteHostIP='" & zKeepRealNumbersOnly(zRemoteHostIP) & "');", dbOpenDynaset)
                If (Not rsData.EOF) Then
                    rsData.Delete
                    subSendMsg "&G" & zRemoteHostIP & " REMOVED from COMPLETE BAN - you can now use never ban", zPortID
                Else
                    rsData.AddNew
                    rsData!Created = Now()
                    rsData!LastAttempt = Now()
                    rsData!RemoteHostIP = Mid(zKeepRealNumbersOnly(zRemoteHostIP), 1, 15)
                    rsData!BadPersonPoints = 30
                    rsData.Update
                    subSendMsg "&R" & zRemoteHostIP & " ADDED TO COMPLETE BAN - never ban won't even help that port now.", zPortID
                    basCloseOffMatchingPorts zRemoteHostIP
                End If
                Set rsData = Nothing
            Else
                subSendMsg "&gSYNTAX: IMMO COMPLETE xxx.xxx.xxx.xxx" & vbCrLf & "SYNTAX: IMMO COMPLETE LIST" & vbCrLf & "SYNTAX: IMMO COMPLETE LIST [H/B]  - H or B sorts the report differently for you." & vbCrLf & "IMMO COMPLETE CLEAR  - will clear this list.", zPortID
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginEditRemoveCompletelyBannedIP," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lLoginBannedIP(zRemoteHostIP As String) As Long
On Error GoTo Err_Check
'bLoginCompletelyBannedIP
'if the person is marked never ban then they can get past these
    Dim rsData As Recordset
    Dim lReturn As Long
    Dim zPartialRemoteHostIP As String
    
    lReturn = 0
    Set rsData = MyDB.OpenRecordset("SELECT RemoteHostID FROM tblPlayerRemoteHost WHERE (RemoteHostID='" & zRemoteHostIP & "' AND BannedIP=True);", dbOpenSnapshot)
    If (Not rsData.EOF) Then lReturn = 1 'banned by the full ip in the tblPlayerRemoteHost
    Set rsData = Nothing
    
    If (lReturn = 0) Then 'Network level ban
        If (lngSQLRecordCount("SELECT NetworkBansAllowed FROM tblSystemConfig WHERE (NetworkBansAllowed=True);") > 0) Then
            zPartialRemoteHostIP = zRemoteHostIP
            If (lInStrIterations(zPartialRemoteHostIP, ".") > 1) Then
                zPartialRemoteHostIP = Mid(zPartialRemoteHostIP, 1, lInStrOccurance(zPartialRemoteHostIP, ".", 2))
                'first try network ip ban
                Set rsData = MyDB.OpenRecordset("SELECT TOP 1 RemoteHostID FROM tblPlayerRemoteHost WHERE (RemoteHostID Like '" & zPartialRemoteHostIP & "*' AND BannedIP=True);", dbOpenSnapshot)
                If (Not rsData.EOF) Then lReturn = 3 'banned by the partial ip in the tblPlayerRemoteHost
                Set rsData = Nothing
                
                'second try network ip ban
                If (lReturn = 0) Then
                    Set rsData = MyDB.OpenRecordset("SELECT TOP 1 RemoteHostIP FROM tblPlayerRemoteHostCompletelyBanned WHERE (BadPersonPoints >= " & lgblCompletelyBannedMAX & " AND RemoteHostIP Like '" & zPartialRemoteHostIP & "*');", dbOpenSnapshot)
                    If (Not rsData.EOF) Then lReturn = 3 'banned by the partial ip in the tblPlayerRemoteHostCompletelyBanned
                    Set rsData = Nothing
                End If
            End If
        End If
    End If
    
    lLoginBannedIP = lReturn 'never bans can get through this banning step
    Exit Function
Err_Check:
    subWriteErrorFile "lLoginBannedIP," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subLoginAddPlayerName(zPortID As String, zPlayerName As String, zPlayerRemoteIP As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'New Login Player Name
    Set rsData = MyDB.OpenRecordset("SELECT PortID, PlayerName, RemoteHostID FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (rsData.EOF) Then 'if this port is available - connect the player
        rsData.AddNew
        rsData!PortID = zPortID
        rsData!PlayerName = zNameFormat(zPlayerName)
        rsData!RemoteHostID = Mid(MyCStr(zPlayerRemoteIP), 1, 30)
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginAddPlayerName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoginAddPassword(zPortID As String, strPassword As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'New Login Player Name
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!Password = zKeepLettersLightAscii(MyCStr(UCase(strPassword)))
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginAddPassword," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoginAddConfirmPassword(zPortID As String, zConfirmPassword As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'New Login Player Name
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!ConfirmPassword = MyCStr(UCase(zConfirmPassword))
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginAddConfirmPassword," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoginAddGender(zPortID As String, zGender As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'New Login Player Gender
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!Gender = MyCStr(UCase(zGender))
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginAddGender," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoginAddRace(zPortID As String, zRace As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'New Login Player Race
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!Race = MyCStr(UCase(zRace))
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginAddRace," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subLoginAddClass(zPortID As String, zClass As String)
On Error GoTo Err_Check
    Dim rsData As Recordset
    
    'New Login Player Name
    Set rsData = MyDB.OpenRecordset("SELECT * FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenDynaset)
    If (Not rsData.EOF) Then
        rsData.Edit
        rsData!Class = UCase(zClass)
        rsData!BittenReservedOriginalClass = UCase(zClass)
        rsData.Update
    End If
    Set rsData = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subLoginAddClass," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bAllowNewPlayerName(zUserData As String, zPortID As String) As Boolean
'See Also: zCleanOutCussingToo
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zTestString As String
    Dim bReturn As Boolean
    
    zTestString = zKeepLettersOnly(zUserData)
    bReturn = True
    If (gblbFilterPlayerNames) Then
        subSendMsgNoPortCheck "&GVerifing player name...", zPortID
        DoEvents
                
        'its much faster to run this though memory
        zTestString = strReplaceWordWithThisWord(zTestString, "ENAB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JAP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PAK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PAC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JEW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JOO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CHIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "UNT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CCEP", "") 'accept - a bad connection that comes from a http://coa.servegame.com:23 request and not a telnet
        zTestString = strReplaceWordWithThisWord(zTestString, "KLIE", "") 'klientpo from a telnet client we dont want
        zTestString = strReplaceWordWithThisWord(zTestString, "CYNT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HEAP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BRAI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DODO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ORAC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "REPL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ORAC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ASTE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QUES", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUCK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "VCK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FVK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FVC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KUM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TION", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SION", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ADMIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOGIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOGON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "VITE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ELN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OSE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PRE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TEC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OPER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ITUP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NAB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SUP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SMOK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BUST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TOOB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TOBE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NAZI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NATZ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GURL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AAA", "") 'voul
        zTestString = strReplaceWordWithThisWord(zTestString, "BBB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CCC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DDD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EEE", "") 'voul
        zTestString = strReplaceWordWithThisWord(zTestString, "FFF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GGG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HHH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "III", "") 'voul
        zTestString = strReplaceWordWithThisWord(zTestString, "JJJ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KKK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LLL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MMM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NNN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OOO", "") 'voul
        zTestString = strReplaceWordWithThisWord(zTestString, "PPP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QQQ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RRR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SSS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TTT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "UUU", "") 'voul
        zTestString = strReplaceWordWithThisWord(zTestString, "VVV", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WWW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "XXX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YYY", "") 'sometimes voul
        zTestString = strReplaceWordWithThisWord(zTestString, "ZZZ", "")
        
        zTestString = strReplaceWordWithThisWord(zTestString, "IDIO", "") 'idiot
        zTestString = strReplaceWordWithThisWord(zTestString, "CANA", "") 'Canada
        zTestString = strReplaceWordWithThisWord(zTestString, "USA", "") 'USA
        zTestString = strReplaceWordWithThisWord(zTestString, "HTTP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "REDE", "") 'redemption and stuff like that
        zTestString = strReplaceWordWithThisWord(zTestString, "CECT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SECT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CEST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SEST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CHIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WREC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WRET", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WET", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BORN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PISS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "URIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KAKA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KOC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KOK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KOX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EPSI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SIC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EVER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MIND", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HIND", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EDUC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BATE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ASTA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STUP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STOO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SLOW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LAG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GAY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GAEY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GEY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GAEY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FAG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FAEG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FEAG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SVK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SVX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SUK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SUX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DIX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FYC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SUC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SLUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SHIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DINK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DIC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DIK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DICK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CUNT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CVN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AGIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LICK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LIK", "") 'licker
        zTestString = strReplaceWordWithThisWord(zTestString, "LIC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FREA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FRAE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FREE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MOTH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NEW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JAC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JAK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HAND", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SOLO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MTHR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOOO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WAD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ASS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AZZ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOLE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SNOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RAPE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HATE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOVE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BLOW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FKR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FKAR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FKER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FKU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PHK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PHU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CHU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MORON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MARON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MORAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MARAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DRINK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KISS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IMMO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GOD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DOG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUSS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUSI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LORD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LADY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GIRL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MAID", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GAL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WISE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GUY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ORGA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WALK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RUN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FAST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SPEE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SPRE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DRESS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CROSS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WOMB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FACE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BEER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WINE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ALCH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PIMP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ASHO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PIG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CHIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BAR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DRIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DORK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NERD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RETA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RATE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HANG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HIM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HED", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COOL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BAD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HORE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BUM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ANAL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JOB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THRO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MEAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CODE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GLOR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CROW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SCRE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DOO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HEAD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MOUTH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SMEL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TURD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "POO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QUEE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KING", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SEX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUBI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MASTE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BALL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SACK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUDG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HACK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TROJ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COND", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CUM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COME", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KUNT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HUMP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SLAP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SHYT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KILL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THEY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THEM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THOS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HIM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DUM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MOM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DAD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SIST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BROT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GRAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BEEP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YOU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STFU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BLAH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BLEH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SOIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PANT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CRAC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SEE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SAW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SMEL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOOB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TITS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BREA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CHES", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PIEC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SLAP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PERV", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PROC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUNC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LONG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SMAL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RAMB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CLAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HURT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QUOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LORD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MAJO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PRAY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AUCT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DUCT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DUST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MUSI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IGNO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DONT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HAVE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CLUE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LESS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BYE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HELL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FELL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MAIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SAIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WEED", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COFF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LIKE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FLOO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CEIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOUR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MINI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SECO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MONTH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SKIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MOUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TEET", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COMM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YELL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TELL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SAY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IRAQ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HITL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SADA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OSMA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LADE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STAL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OIC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TYVM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "URA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ISSO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HIKE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WITH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TTI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TTYL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TONG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MUSC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BIRD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HIGH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BABY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BABE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HARD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AMER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YANK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NIG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "INSI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STAR", "") 'as in starwars star trek
        zTestString = strReplaceWordWithThisWord(zTestString, "WANT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DAWG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DAMN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YUM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CLIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BLAS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SPER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LMAO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TOP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUMP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MOLE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ANIS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GREA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MONK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WAR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LIFE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ARCH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SATA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SANT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SAIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "INSA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SAID", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "REDO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HELP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QUIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FUEL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COLO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ISAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DILD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TRIP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STRA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OLD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YOUN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LEAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FART", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOUD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FLUC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DONK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SEAS", "") 'Disease
        zTestString = strReplaceWordWithThisWord(zTestString, "RRHE", "") 'Diarrhea
        zTestString = strReplaceWordWithThisWord(zTestString, "DIAR", "") 'Diary
        zTestString = strReplaceWordWithThisWord(zTestString, "GUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DEEP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOOK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BULL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ORCE", "") 'forces
        zTestString = strReplaceWordWithThisWord(zTestString, "DARY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DARR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ESBI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LORY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LORI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LAUR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ODOM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SEMA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STIC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TUFF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AID", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HEAL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IGHT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ITE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EIGH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ALRI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BACK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LEVE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ELVE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TEEN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ENTY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HUND", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OUSA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TRY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EYE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MERL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WIZ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WANG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BROW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LEAC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LEEC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LECH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LACH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LETC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WACK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ULTI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SSIV", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PISS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONME", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ELLO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ELO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ZIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OULT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WORK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PEE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONHE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "INHE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EAR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DESI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ESPA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OOD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ANUR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOMB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "THIS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OUGH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CANT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "APE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EPA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "URGE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DIE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OOL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RAP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DUMB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOMO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ESBI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LESB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HING", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HEX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NGIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DIAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ATIV", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JERK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JARK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RIST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ESUS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OFA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BYCH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ITCH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KLIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PET", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KIT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CITY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AGE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IDDL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROCK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROLL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IRON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GOLD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RECT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "AKE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BODY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RUB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MUD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SELF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EASL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HILD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KID", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROAK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ORM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OPEN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CLOS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YRS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OUR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WAK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OFF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ALOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YAP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOON", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FEG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ANUC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "UDE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GET", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IVE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ARMO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OINT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ESTE", "") 'infested
        zTestString = strReplaceWordWithThisWord(zTestString, "OOF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FOOK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FOK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FAK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ASTE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ESTI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KEY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DING", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DONG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MOFO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BIOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUNE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TANG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ENIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "COOC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "OUCH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ANK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "INGE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IVAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BONG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DOOM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DOYOU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DOU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PECK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONDL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QUER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JAB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HINC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PLUG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "UNK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROCH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BIN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IANT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PENU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ANUS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PLUG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PENI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PINI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HINC", "") 'as in sphincter
        zTestString = strReplaceWordWithThisWord(zTestString, "BEAN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DOPH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ORNO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PORN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FOCK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "IRGI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "REAK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CRAB", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BANG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BOOM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LUV", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SWAL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DUMP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOOT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DROP", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BRAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MEN", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HONG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KONG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "CHOK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ICKE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HAG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "INMY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ONMY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SHUT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MPHO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HAS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STIF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JIZZ", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JISS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "REEF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PIPE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ROKE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "POLE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MALE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JELL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JALL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TAIL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TANK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SWIM", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FIRE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WATER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "EARTH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NATC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LAY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BEST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PORK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "POKE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RUST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ENJOY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WILD", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LESH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ARS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MYA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MIA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KOAF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YAA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WHO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WHAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HERE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WHY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HOW", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "QWE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "KWE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SOUL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SOLE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PUSY", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PIER", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PEIR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SHT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "NETA", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RUSH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "TEST", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HUCK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "SIZE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PHAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "FAT", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "HUK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "WRNK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PNIS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PNES", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DUSH", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BAG", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BONR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "BONE", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "RINK", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STYL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "LOOS", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "ABC", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "DEF", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "GHI", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "JKL", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "MNO", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "PQR", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "STU", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "VWX", "")
        zTestString = strReplaceWordWithThisWord(zTestString, "YZ", "")
        DoEvents
        bReturn = (UCase(zTestString) = UCase(zUserData)) 'they should match or else someone is swearing or not using a roleplay name
    End If

    If (Not bReturn) Then 'Swearing / non-roleplay check
        If (Len(MyCStr(zTestString)) = 0) Then
            subSendMsgNoPortCheck "&RInvalid word in the player name!" & vbCrLf & "&GValid letters in " & "&R" & UCase(zUserData) & "&G are: &g[NO LETTER PATTERNS QUALIFIED!]&Y" & vbCrLf & "We do this to help facilitate roleplay at " & gblzMUDName & ". Try again.", zPortID
        Else
            subSendMsgNoPortCheck "&RInvalid word in the player name!" & vbCrLf & "&GValid letters in " & "&R" & UCase(zUserData) & "&G are: &g" & UCase(zTestString) & "&Y" & vbCrLf & "We do this to help facilitate roleplay at " & gblzMUDName & ". Try again.", zPortID
        End If
    End If
    
    'We have other checks however
    If (bReturn) Then
        zTestString = UCase(zTestString)
        
        Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (((InStr('" & zTestString & "',[PlayerName]))>0));", dbOpenSnapshot)
        bReturn = (rsData.EOF)
        Set rsData = Nothing
        If (Not bReturn) Then subSendMsgNoPortCheck "&RA existing player name in the realm is not to match your new player name!&Y" & vbCrLf & "Try again.", zPortID
    End If
    
    If (bReturn) Then
        DoEvents
        Set rsData = MyDB.OpenRecordset("SELECT LearnName FROM tblPlayerLearn WHERE (TargetID=0 AND LearnName Like '*" & zTestString & "*');", dbOpenSnapshot)
        bReturn = (rsData.EOF)
        Set rsData = Nothing
        If (Not bReturn) Then subSendMsgNoPortCheck "&RA spell name in the realm matches that player name!", zPortID
    End If
    
    If (bReturn) Then
        DoEvents
        Set rsData = MyDB.OpenRecordset("SELECT KeywordCommand FROM tblChartEmote WHERE (KeywordCommand Like '*" & zTestString & "*');", dbOpenSnapshot)
        bReturn = (rsData.EOF)
        Set rsData = Nothing
        If (Not bReturn) Then subSendMsgNoPortCheck "&RA social in the realm matches that player name!", zPortID
    End If
    
    If (bReturn) Then
        DoEvents
        Set rsData = MyDB.OpenRecordset("SELECT MobName FROM tblMob WHERE (MobName Like '*" & zTestString & "*');", dbOpenSnapshot)
        bReturn = (rsData.EOF)
        Set rsData = Nothing
        If (Not bReturn) Then subSendMsgNoPortCheck "&RA NPC/creature in the realm matches that player name!", zPortID
    End If
    
    If (bReturn) Then
        DoEvents
        Set rsData = MyDB.OpenRecordset("SELECT ObjectName FROM tblObject WHERE (Status=1 AND Gold=0 AND QuestForGlory=0 AND Location<>0 AND ObjectName Like '*" & zTestString & "*');", dbOpenSnapshot)
        bReturn = (rsData.EOF)
        Set rsData = Nothing
        If (Not bReturn) Then subSendMsgNoPortCheck "&RAn object in the realm matches that player name!", zPortID
    End If
    
    bAllowNewPlayerName = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bAllowNewPlayerName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
'bIsAnyoneIgnoringPlayerID(lPlayerID)
Public Function bIsAnyoneIgnoringPlayerID(lPlayerID As Long) As Boolean
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerIgnoredID FROM tblPlayerIgnoreCommand WHERE (PlayerIgnoredID=" & lPlayerID & ");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        bReturn = True
    End If
    Set rsData = Nothing
    
    bIsAnyoneIgnoringPlayerID = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bIsAnyoneIgnoringPlayerID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bPlayerNameExists(zPlayerName As String) As Boolean
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (PlayerName='" & zPlayerName & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        bReturn = True
    End If
    Set rsData = Nothing
    
    bPlayerNameExists = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPlayerNameExists," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bPlayerNameExistsLoggedIn(zPlayerName As String) As Boolean
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
       
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayerLoggedIn WHERE (PlayerName='" & zPlayerName & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        bReturn = True
    End If
    Set rsData = Nothing
    
    bPlayerNameExistsLoggedIn = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPlayerNameExistsLoggedIn," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zLoggingInPlayerName(zPortID As String) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    zReturn = ""
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!PlayerName)
    End If
    Set rsData = Nothing
    zLoggingInPlayerName = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zLoggingInPlayerName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lPlayerXYZNameMatch(lX As Long, lY As Long, lZ As Long, zPlayerName As String) As Long
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim lReturn As Long
    
    lReturn = 0
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (X = " & lX & ", Y = " & lY & ", Z = " & lZ & ", PlayerName LIKE ""*" & zPlayerName & "*"");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        lReturn = MyCLng(rsData!PlayerID)
    End If
    Set rsData = Nothing
    
    lPlayerXYZNameMatch = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lPlayerXYZNameMatch," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zPlayerXYZNameMatch(lX As Long, lY As Long, lZ As Long, zPlayerName As String) As String
On Error GoTo Err_Check
    Dim rsData As Recordset
    Dim zReturn As String
    
    zReturn = ""
    
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayer WHERE (X = " & lX & ", Y = " & lY & ", Z = " & lZ & ", PlayerName LIKE ""*" & zPlayerName & "*"");", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zReturn = MyCStr(rsData!PlayerName)
    End If
    Set rsData = Nothing
    
    zPlayerXYZNameMatch = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zPlayerXYZNameMatch," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bLoginPlayerNameExistsAndCorrectPassword(zPortID As String, strPassword As String) As Boolean
On Error GoTo Err_Check
    Dim rsLoginPlayer As Recordset
    Dim rsPlayerPassword As Recordset
    Dim zOPlayerName As String
    Dim zOPassword As String
    Dim bReturn As Boolean
    
    bReturn = False
    Set rsLoginPlayer = MyDB.OpenRecordset("SELECT PortID, PlayerName, Password FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsLoginPlayer.EOF) Then 'Login player name found
        zOPlayerName = zKeepLettersOnly(MyCStr(rsLoginPlayer!PlayerName))
        zOPassword = zKeepLettersOnly(strPassword)
        Set rsPlayerPassword = MyDB.OpenRecordset("SELECT Password FROM tblPlayer WHERE (PlayerName=""" & zOPlayerName & """ AND Password=""" & zOPassword & """);", dbOpenSnapshot)
        If (Not rsPlayerPassword.EOF) Then
            bReturn = True
        End If
    End If
    
    Set rsLoginPlayer = Nothing
    Set rsPlayerPassword = Nothing
    bLoginPlayerNameExistsAndCorrectPassword = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bLoginPlayerNameExistsAndCorrectPassword," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bLoginPlayerDoesPasswordMatchConfirm(zPortID As String) As Boolean
On Error GoTo Err_Check
    Dim rsLoginPlayer As Recordset
    Dim bReturn As Boolean
    
    bReturn = False
    Set rsLoginPlayer = MyDB.OpenRecordset("SELECT PlayerName, Password, ConfirmPassword FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsLoginPlayer.EOF) Then 'Login player name found
        If (MyCStr(UCase(rsLoginPlayer!Password)) = MyCStr(UCase(rsLoginPlayer!ConfirmPassword))) Then
            bReturn = True
        End If
    End If
    
    Set rsLoginPlayer = Nothing
    bLoginPlayerDoesPasswordMatchConfirm = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bLoginDoesPasswordMatchConfirm," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function lRankLevel(zClanMemberLevel As String) As Long
On Error Resume Next
'see also: zTranslateMortalClanRanks, subInductionSetClanMemberLevel
    Dim lClanMemberLevel As Long
    Select Case Mid(UCase(zClanMemberLevel), 1, 5)
        Case "BAN", "REMOV", "REMO", "REM", "BANN", "BANNE", "R", "RO", "ROG", "ROGU", "ROGUE", "STOP", "OFF", "DONE", "CLEAR", "CLOSE", "UNIND", "UNIN", "SHUTU", "SHUT"
            lClanMemberLevel = 0
        Case "B", "BR", "BRO", "BROT", "BROTH", "CIV", "CIVI", "CIVIL"
            lClanMemberLevel = 1
        Case "SO", "SOL", "SOLD", "SOLDI"
            lClanMemberLevel = 2
        Case "BO", "BOO", "BOOT", "BOOTC", "BRO", "BROTH", "I", "IN", "INT", "INTE", "INTEG" 'inducted integral soldier
            lClanMemberLevel = 3
        Case "Y", "YE", "YEO", "YEOM", "YEOMA" 'yeoman
            lClanMemberLevel = 4
        Case "C", "CO", "COR", "CORP", "CORPO" 'corporal
            lClanMemberLevel = 5
        Case "S", "SE", "SER", "SERG", "SERGE" 'sergeant
            lClanMemberLevel = 6
        Case "LI", "LIE", "LIU", "LUT", "LUE", "LIEU", "LEIU", "LUEI", "LUET", "LUIT", "LIEUT", "LEIUT", "LUTEN", "LUETE" 'lieutenant - officer
            lClanMemberLevel = 7
        Case "COMMA" 'commander - officer
            lClanMemberLevel = 8
        Case "CA", "CAP", "CAPT", "CAPTA" 'captain - officer
            lClanMemberLevel = 9
        Case "M", "MA", "MAJ", "MAJO", "MAJOR" 'major - officer
            lClanMemberLevel = 10
        Case "COLO", "COLON" 'colonel - officer
            lClanMemberLevel = 11
        Case "BRI", "BRIG", "BRIGA" 'brigadier
            lClanMemberLevel = 12
        Case "G", "GE", "GEN", "GENE", "GENER" 'general - officer
            lClanMemberLevel = 13
        Case "A", "AD", "ADV", "ADVI", "ADVIS" 'advisor - officer
            lClanMemberLevel = 14
        Case "COMMO" 'commodore - officer
            lClanMemberLevel = 15
        Case "AD", "ADM", "ADMI", "ADMIR" 'admiral - officer
            lClanMemberLevel = 16
        Case "L", "LE", "LEA", "LEAD", "LEADE" 'leader - officer
            lClanMemberLevel = 17
        Case "SP", "SPI", "SPIR", "SPIRI", "ENTIT", "E", "EN", "ENT", "ENTI", "DEITY", "CLAN" 'clan deity - officer (demi-god)
            lClanMemberLevel = 18
        Case Else 'its probably a number or else we set it to zero
            lClanMemberLevel = MyCLng(zClanMemberLevel)
    End Select
    lRankLevel = lClanMemberLevel
End Function
Public Function zTranslateMortalClanRanks(lClanMemberLevel As Long) As String
On Error Resume Next
'see also: lRankLevel
    Dim zReturn As String
    Select Case lClanMemberLevel
        Case 1
            zReturn = "     (civilian)" 'bootcamp
        Case 2
            zReturn = "      (soldier)"
        Case 3
            zReturn = "     (integral)"
        Case 4
            zReturn = "       (yeoman)"
        Case 5
            zReturn = "     (corporal)"
        Case 6
            zReturn = "     (sergeant)"
        Case 7
            zReturn = "   *lieutenant*"
        Case 8
            zReturn = "    *commander*"
        Case 9
            zReturn = "      *captain*"
        Case 10
            zReturn = "        *major*"
        Case 11
            zReturn = "      *colonel*"
        Case 12
            zReturn = "    *brigadier*"
        Case 13
            zReturn = "      *general*"
        Case 14
            zReturn = "      *advisor*"
        Case 15
            zReturn = "    *commodore*"
        Case 16
            zReturn = "      *admiral*"
        Case 17
            zReturn = "       *leader*"
        Case 18
            zReturn = "     +-entity-+"
        Case 19
            zReturn = "     ++entity++"
        Case 20
            zReturn = "     -=entity=-"
        Case 21
            zReturn = "     +=entity=+"
        Case Else
            zReturn = "   ~adventurer~"
    End Select
    
    zTranslateMortalClanRanks = zReturn
End Function
Public Function zImmortalLevelRank(zGender As String, lImmortalLevel As Long, lClanMemberLevel As Long) As String
On Error Resume Next
    Dim zReturn As String
    Select Case lImmortalLevel '  "               " - this wide is required.
        Case 0
            zReturn = zTranslateMortalClanRanks(lClanMemberLevel)
        Case 1 'immortal level overrides ranks
            Select Case zGender
                Case "M"
                    zReturn = gblzFNMAG & "lesser god     " 'lesser immortal, demigod, apprentice, hero, others used
                Case "F"
                    zReturn = gblzFNMAG & "lesser goddess " 'lesser immortal, demigod, apprentice, hero, others used
            End Select
        Case 2
            Select Case zGender
                Case "M"
                    zReturn = gblzFNGRE & "demi-god       " 'champion
                Case "F"
                    zReturn = gblzFNMAG & "demi-goddess   " 'lesser immortal, demigod, apprentice, hero, others used
            End Select
        Case 3
            zReturn = "&yarchduke       "
        Case 4
            zReturn = gblzFNRED & "legend         "
        Case 5
            zReturn = "&cmagee          "
        Case 6
            zReturn = gblzFNGRE & "earth maker    "
        Case 7
            zReturn = "&yair maker      "
        Case 8
            zReturn = gblzFNRED & "fire maker     "
        Case 9
            zReturn = "&cwater maker    "
        Case 10
            zReturn = "&cJustice        "
        Case 40
            zReturn = "&RMacrocosm      "
        Case 41
            zReturn = "&RBeliever       "
        Case 90
            zReturn = gblzFBMAG & "Campfire Singer"
        Case 91
            zReturn = gblzFBMAG & "Astral         "
        Case 92
            zReturn = gblzFBMAG & "Lunar          "
        Case 93
            zReturn = gblzFBMAG & "Solar          "
        Case 94
            zReturn = gblzFBMAG & "Celestial      "
        Case 95
            zReturn = "&RMacrocosm      "
        Case 96
            zReturn = gblzFBMAG & "Peace Keeper   "
        Case 97
            zReturn = "&RC H A O S      "
        Case 98
            zReturn = gblzFNBLU & "D E A T H      "
        Case 99
            zReturn = "&aS H A D O W    "
        Case 100
            zReturn = "&wS &aE T &wH        "
        Case 101
            zReturn = "&WO R D E R      "
        Case 102
            zReturn = "&WT E M P L A R  "
        Case 103 'this is a hidden immortal
            zReturn = gblzFNGRE & "   ~adventurer~"
        Case Else 'hidden immortal
            zReturn = gblzFNGRE & "       *leader*"
    End Select
    zImmortalLevelRank = zReturn
End Function
Public Sub subUpdatePlayerPortID(zPortID As String)
On Error GoTo Err_Check
    'This should only be called after the player has logged in
    Dim rsLoginPlayer As Recordset
    
    'First, we make sure there is no mistake about who is on what port
    MyDB.Execute "UPDATE tblPlayer SET PortID = '0' WHERE (PortID='" & zPortID & "');", dbFailOnError
    
    'Second, we date the entry
    Set rsLoginPlayer = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsLoginPlayer.EOF) Then 'Login player name found
        MyDB.Execute "UPDATE tblPlayer SET LastPlayed = '" & Format(Now(), "mmm dd, yyyy hh:nn") & "', PortID = '" & zPortID & "' WHERE (PlayerName=""" & MyCStr(rsLoginPlayer!PlayerName) & """);", dbFailOnError
    End If
    Set rsLoginPlayer = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subUpdatePlayerPortID," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function zNameFormat(zUserData As String) As String
    Dim zReturn As String
    zReturn = Mid(UCase(Mid(zUserData, 1, 1)) & LCase(Mid(zUserData, 2)), 1, 15)
    If (InStr(zReturn, " ") > 0) Then zReturn = Mid(zReturn, 1, InStr(zReturn, " ") - 1)
    zNameFormat = MyCStr(zReturn)
End Function
Public Function bPlayerAlreadyLoggedIn(zPortID As String) As Boolean
On Error GoTo Err_Check
    Dim rsLoginPlayer As Recordset
    Dim bReturn As Boolean
    Dim zPlayerName As String
    Dim rsData As Recordset
    
    zPlayerName = ""
    
    'We get the logged in player name
    Set rsData = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayerLoggedIn WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsData.EOF) Then
        zPlayerName = MyCStr(rsData!PlayerName)
    End If
    Set rsData = Nothing
    
    Set rsLoginPlayer = MyDB.OpenRecordset("SELECT PlayerName FROM tblPlayerLoggedIn WHERE (PlayerName='" & zKeepLettersOnly(zPlayerName) & "' AND PortID<>'" & zPortID & "');", dbOpenSnapshot)
    bReturn = (Not rsLoginPlayer.EOF) 'Login player name found
    Set rsLoginPlayer = Nothing
    
    bPlayerAlreadyLoggedIn = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPlayerAlreadyLoggedIn," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zCleanEngageBackspace(zMessage As String) As String
On Error Resume Next
    'zCleanEngageBackspace(abc(chr8)defg(chr8)hijk) becomes abdefhijk
    Dim zEditLine As String
    Dim zReturn As String
    Dim iScan As Integer
    Dim iCount As Integer
    
    iCount = Len(zMessage)
    zReturn = ""
    iScan = 0
    
    If (iCount > 0) Then
        Do While (iScan <= iCount)
            iScan = iScan + 1
            If (iScan <= iCount) Then
                If (Mid(zMessage, iScan, 1) <> "") Then
                    'Debug.Print "1 CHAR = " & Asc(Mid(zMessage, iScan, 1)) & " " & Mid(zMessage, iScan, 1)
                    'Debug.Print "2 CHAR = " & Asc(Mid(zMessage, iScan + 1, 1)) & " " & Mid(zMessage, iScan + 1, 1)
                    If (Mid(zMessage, iScan + 1, 1) <> Chr(8)) Then 'we look ahead and if there is no backspace we get the character
                        zReturn = zReturn & Mid(zMessage, iScan, 1)
                        'Debug.Print zReturn
                    Else
                        iScan = iScan + 1
                    End If
                End If
            End If
        Loop
    End If
    zCleanEngageBackspace = zReturn
End Function
Public Function zCleanChatMessage(zMessage As String) As String
On Error GoTo Err_Check
    Dim iScan As Integer
    Dim zReturn As String
    Dim zChar As String
    Dim zEditLine As String
    Dim iChr8S As Integer
    Dim iChr8E As Integer
    Dim iEditLineLen As Integer
    
    zEditLine = zMessage
    
    zReturn = ""
    
    iEditLineLen = Len(zEditLine)
    
    'We remove return codes and we backspace automatically
    For iScan = 1 To iEditLineLen
        zChar = (Mid(zEditLine, iScan, 1))
        If (zChar <> Chr(8)) Then
            If (Mid(zEditLine, iScan + 1, 1) <> Chr(8)) Then
                If (zChar <> vbLf And zChar <> vbCr) Then  'we ignore 10 lf and 13 return and 8 backspace on the ascii table
                    zReturn = zReturn & zChar
                End If
            End If
        End If
    Next iScan
    
    zCleanChatMessage = zReturn 'DO NOT PUT A CSTR function anywhere in this module
    Exit Function
Err_Check:
    subWriteErrorFile "zCleanChatMessage," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function iTotalWordsInLine(zLine As String) As Integer
On Error Resume Next
    Dim iCount As Integer
    Dim iReturn As Integer
    iReturn = 0
    If (Len(zLine) > 1) Then
        iReturn = 1 'There is at least one word
        For iCount = 1 To Len(zLine)
            If (Mid(zLine, iCount, 1) = " ") Then iReturn = iReturn + 1
        Next iCount
    End If
    iTotalWordsInLine = iReturn
End Function
Public Function Line(zLine As String, iLen As Integer) As String
On Error Resume Next
'This will take a sentence and format it to the length of iLen and fill with spaces.
    Dim iScan As Integer
    Dim zHoldLine As String
    Dim bOkay As Boolean
    zHoldLine = MyCStr(zLine)
    iScan = 0: bOkay = False
    If (iTotalWordsInLine(zLine) > 3) Then 'If there are not at least 4 words in the sentence we dont even bother to look at it.
        Do While (Len(zHoldLine) < iLen)
            iScan = iScan + 1
            If (Mid(zHoldLine, iScan, 1) = " ") Then
                bOkay = (Not bOkay) 'We skip every odd blank - this line of code require at least 2 words in zLine to work.
                If (bOkay) Then
                    zHoldLine = Mid(zHoldLine, 1, iScan) & Mid(zHoldLine, iScan) 'Add a blank by coping the zHoldLine.
                    iScan = iScan + 1 'We add a blank and then we move on
                End If
            End If
            If (iScan > iLen) Then iScan = 0 'Go back to the beginning and fill in more blanks
        Loop
    End If
    Line = zHoldLine
End Function
Public Function zTranslateCussing(zWord As String) As String
On Error Resume Next
    Dim zReturn As String
    Dim zLetter As String
    Dim lCount As Long
    
    zReturn = ""
    For lCount = 1 To Len(zWord)
        zLetter = UCase(Mid(zWord, lCount, 1))
        Select Case zLetter
            Case "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"
                zReturn = zReturn & zLetter
            Case "1", "|", ":", ";", "^"
                zReturn = zReturn & "i"
            Case "0", "*", "+", "@"
                zReturn = zReturn & "o"
            Case "$"
                zReturn = zReturn & "s"
        End Select
    Next lCount
    
    zTranslateCussing = zReturn
End Function
Public Function zCleanOutCussingToo(zMsg As String) As String
On Error GoTo Err_Check
    Dim zReturn As String
    zReturn = zTranslateDropColours(zMsg)
    If (bcstFilterCussing) Then
        zReturn = strReplaceWordWithThisWord(zReturn, "FAG", "!#^")
        zReturn = strReplaceWordWithThisWord(zReturn, "FUK", "!#$")
        zReturn = strReplaceWordWithThisWord(zReturn, "CUNT", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "FUCK", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "ORNY", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "SHIT", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "SLUT", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "ASSH", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "JERK", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "NIGG", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "JERK", "!#$^")
        zReturn = strReplaceWordWithThisWord(zReturn, "SCREW", "!#$^%")
        zReturn = strReplaceWordWithThisWord(zReturn, "WHORE", "!#$^%")
        zReturn = strReplaceWordWithThisWord(zReturn, "BITCH", "!#$^$")
        zReturn = strReplaceWordWithThisWord(zReturn, "B|TCH", "!#$^$")
        zReturn = strReplaceWordWithThisWord(zReturn, "LOOSER", "!#$^!#")
        zReturn = strReplaceWordWithThisWord(zReturn, "L00SER", "!#$^!#")
        zReturn = strReplaceWordWithThisWord(zReturn, "L0OSER", "!#$^!#")
        zReturn = strReplaceWordWithThisWord(zReturn, "LO0SER", "!#$^!#")
    End If
    zCleanOutCussingToo = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zCleanOutCussingToo," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zCleanOutCussing(zMsg As String) As String
On Error GoTo Err_Check
    Dim lCount As Long
    Dim zWorkWord As String
    Dim zWord As String
    Dim zReturn As String
    Dim lMsg As Long
    Dim zCheckWord As String
    
    zReturn = ""
    zWorkWord = " "
    lMsg = Len(zMsg)
    For lCount = 1 To lMsg
        zWorkWord = Mid(zMsg, lCount, 1)
        zWord = zWord & zWorkWord
        zCheckWord = zTranslateCussing(zWord) 'makes words like B|TCH search as BITCH
        Select Case UCase(zCheckWord)
            Case "CUNT", "SHIT", "FUCK", "COCK", "SUCK", "SUK", "FUK", "FUCU", "ASSH", "AHOLE", "ASHOLE", "MTHR", "LOSER", "BITCH", "BASTARD", "BASTRD", "RETARD", "NIGG", "NIGGA", "BITHC", "BITHC", "B1THC", "FAG", "SPERM", "COCK", "WH0RE", "WHOR", "SCREW", "SCRW", "BORED"
                Select Case Len(zCheckWord)
                    Case 2
                        zWord = "#!"
                    Case 3
                        zWord = "$^!"
                    Case 4
                        zWord = "$^#!"
                    Case 5
                        zWord = "$^#!%"
                    Case 6
                        zWord = "$^#!$%"
                    Case 7
                        zWord = "$^#!&$%"
                    Case Else
                        zWord = "$^#!"
                End Select
        End Select
        If (zWorkWord = " " Or lCount = lMsg) Then
            zReturn = zReturn & zWord
            zWord = ""
        End If
    Next lCount
    zCleanOutCussing = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zCleanOutCussing," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function zDrunkLevel(zPromptMessage As String, lDrunkLevel As Long) As String
On Error GoTo Err_Check
    Dim zReturn As String
    Dim zChar As String
    Dim iCount As Integer
    Dim zOriginal As String
    
    zReturn = ""
    If (lDrunkLevel > 0 And Len(zPromptMessage) > 0) Then
        zOriginal = zPromptMessage
        For iCount = 1 To Len(zOriginal)
            zChar = Mid(zOriginal, iCount, 1)
            If (zChar <> " ") Then
                If (lRandom(lDrunkLevel) > lRandom(12)) Then 'if the player is drunk enough they mess up some words
                    Select Case UCase(zChar)
                        Case "A"
                            zChar = "Ae"
                            Select Case lRandom(5)
                                Case 1
                                    zChar = "a"
                                Case 2
                                    zChar = "A"
                                Case 3
                                    zChar = "Oa"
                                Case 4
                                    zChar = "oA"
                            End Select
                        Case "E"
                            zChar = "Ea"
                            Select Case lRandom(3)
                                Case 1
                                    zChar = "ee"
                                Case 2
                                    zChar = "eE"
                            End Select
                        Case "I"
                            zChar = "ei"
                            Select Case lRandom(3)
                                Case 1
                                    zChar = "e"
                                Case 2
                                    zChar = "E"
                            End Select
                        Case "O"
                            zChar = "Oo"
                            Select Case lRandom(4)
                                Case 1
                                    zChar = "o"
                                Case 2
                                    zChar = "O"
                                Case 3
                                    zChar = "oU"
                            End Select
                        Case "U"
                            zChar = "Uu"
                            Select Case lRandom(3)
                                Case 1
                                    zChar = "u"
                                Case 2
                                    zChar = "U"
                            End Select
                        Case "Y"
                            zChar = "i"
                            Select Case lRandom(5)
                                Case 1
                                    zChar = "y"
                                Case 2
                                    zChar = "Y"
                                Case 3
                                    zChar = "w"
                                Case 4
                                    zChar = "W"
                            End Select
                        Case "D"
                            zChar = "Ed"
                            Select Case lRandom(5)
                                Case 1
                                    zChar = "da"
                                Case 2
                                    zChar = "de"
                                Case 3
                                    zChar = "Da"
                                Case 4
                                    zChar = "De"
                            End Select
                        Case "R"
                            zChar = "aR"
                            Select Case lRandom(5)
                                Case 1
                                    zChar = "r"
                                Case 2
                                    zChar = "Rr"
                                Case 3
                                    zChar = "wW"
                                Case 4
                                    zChar = "ww"
                            End Select
                        Case "S"
                            zChar = "Ss"
                            Select Case lRandom(3)
                                Case 1
                                    zChar = "s"
                                Case 2
                                    zChar = "S"
                            End Select
                        Case "X"
                            zChar = "eX"
                            Select Case lRandom(3)
                                Case 1
                                    zChar = "x"
                                Case 2
                                    zChar = "X"
                            End Select
                    End Select
                End If
            End If
            
            If (lRandom(16) = 1) Then zChar = "" 'missing letters affect
            
            zReturn = zReturn & zChar
        Next iCount
    Else
        zReturn = zPromptMessage
    End If
    zDrunkLevel = zReturn
    Exit Function
Err_Check:
    subWriteErrorFile "zDrunkLevel," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Function bAreaForgeSpot(lX As Long, lY As Long, lZ As Long) As Boolean
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim bReturn As Boolean
    bReturn = False
    Set rsArea = MyDB.OpenRecordset("SELECT ForgeArea FROM tblArea WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbOpenSnapshot)
    If (Not rsArea.EOF) Then
        bReturn = MyCInt(rsArea!ForgeArea)
    End If
    Set rsArea = Nothing
    bAreaForgeSpot = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bAreaForgeSpot," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function

Public Sub subAreasCleanOddLevels()
On Error GoTo Err_Check
    Dim rsArea As Recordset
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    
    Set rsArea = MyDB.OpenRecordset("SELECT X, Y, Z FROM tblArea;", dbOpenSnapshot)
    Do While (Not rsArea.EOF)
        lZ = MyCLng(rsArea!z)
        If (bOdd(rsArea!z)) Then 'odd plains areas are only used as seperators to another area so we clear them and make sure no mobs exist at them
            lX = MyCLng(rsArea!x)
            lY = MyCLng(rsArea!y)
            MyDB.Execute "UPDATE tblArea SET WhereID=0 WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
            MyDB.Execute "UPDATE tblMob SET X=0, Y=0, Z=0, RespawnX=0, RespawnY=0, RespawnZ=0 WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ");", dbFailOnError
        End If
        rsArea.MoveNext
    Loop
    Set rsArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subAreasCleanOddLevels," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subAreaTransferXYZ()
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zPortID As String
    Dim lPlayerID As Long
    Dim lStunDuration As Long
    Dim lCHP As Long
    Dim rsArea As Recordset
    Dim lAX As Long
    Dim lAY As Long
    Dim lAZ As Long
    Dim lATransferX As Long
    Dim lATransferY As Long
    Dim lATransferZ As Long
    Dim lATransferDmgPercent As Long
    Dim zATransferMsg As String
    Dim zDir As String
    
    Set rsArea = MyDB.OpenRecordset("SELECT X, Y, Z, TransferX, TransferY, TransferZ, TransferDmgPercent, TransferMsg FROM tblArea WHERE (Len(TransferMsg) > 1);", dbOpenSnapshot)
    Do While (Not rsArea.EOF) 'get all the transfer areas
        If (lRandom(3) = 1) Then
            lAX = MyCLng(rsArea!x)
            lAY = MyCLng(rsArea!y)
            lAZ = MyCLng(rsArea!z)
            lATransferX = MyCLng(rsArea!TransferX)
            lATransferY = MyCLng(rsArea!TransferY)
            lATransferZ = MyCLng(rsArea!TransferZ)
            zDir = ""
            If (lAY < lATransferY) Then zDir = zDir & "south"
            If (lAY > lATransferY) Then zDir = zDir & "north"
            If (lAX < lATransferX) Then zDir = zDir & "east"
            If (lAX > lATransferX) Then zDir = zDir & "west"
            If (lAZ < lATransferZ) Then
                If (Len(zDir) <> 0) Then zDir = zDir & "-"
                zDir = zDir & "down"
            End If
            If (lAZ > lATransferZ) Then
                If (Len(zDir) <> 0) Then zDir = zDir & "-"
                zDir = zDir & "up"
            End If
            lATransferDmgPercent = MyCLng(rsArea!TransferDmgPercent)
            zATransferMsg = MyCStr(rsArea!TransferMsg)
            
            Set rsPlayer = MyDB.OpenRecordset("SELECT ImmortalLevel, StunDuration, CHP, PortID, PlayerID, PlayerName FROM tblPlayer WHERE (X=" & lAX & " AND Y=" & lAY & " AND Z=" & lAZ & ");", dbOpenSnapshot)
            Do While (Not rsPlayer.EOF) 'get the players in the transfer areas
                zPortID = MyCStr(rsPlayer!PortID)
                zPlayerName = MyCStr(rsPlayer!PlayerName)
                lCHP = MyCLng(rsPlayer!CHP)
                lStunDuration = MyCLng(rsPlayer!StunDuration)
                If (lATransferDmgPercent > 0) Then lCHP = lCHP - MyCLng(lCHP * (lATransferDmgPercent / 100))
                If (lATransferDmgPercent > 20) Then lStunDuration = lStunDuration + lRandom(3) - 1
                lPlayerID = MyCLng(rsPlayer!PlayerID)
                subSendMsg "&BYou flow " & zDir & "." & vbCrLf & "&M" & zATransferMsg, zPortID
                subSendMsgAreaAllDISmart "&B", zPlayerName, "%s1 flow " & zDir & ".", "", "%s1 flows " & zDir & ".", lATransferX, lATransferY, lATransferZ
                MyDB.Execute "UPDATE tblPlayer SET StunDuration=" & lStunDuration & ", CHP=" & lCHP & ", X=" & lATransferX & ", Y=" & lATransferY & ", Z=" & lATransferZ & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                MyDB.Execute "UPDATE tblPlayer SET CHP=[OHP] WHERE (CHP>[OHP] AND PlayerID=" & lPlayerID & ");", dbFailOnError
                MyDB.Execute "UPDATE tblPlayer SET CHP=1 WHERE (CHP<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                rsPlayer.MoveNext
            Loop
            Set rsPlayer = Nothing
        End If
        rsArea.MoveNext
    Loop
    Set rsArea = Nothing
    Exit Sub
Err_Check:
    subWriteErrorFile "subAreaTransferXYZ," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subShowtimePlayer(zPortID As String, zWord1 As String, zWord2 As String)
    Dim lBid As Long
    Dim lPortID As Long
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lLearnPoints As Long
    Dim iCount As Integer
    If (gbllQuestShowtimeDuration > 0) Then
        lPortID = MyCLng(zPortID)
        If (lPortID > 1) Then
            For iCount = 1 To 9
                If (gbllQuestShowtimeObjectValue(iCount) > 0) Then
                    Select Case iCount
                        Case 1
                            subSendMsg "&WSHOWTIME GUESS OBJECTs: &y" & gblzQuestShowtimeObjectName(iCount), zPortID
                        Case Else
                            subSendMsg "&y                        " & gblzQuestShowtimeObjectName(iCount), zPortID
                    End Select
                End If
            Next iCount
            
            lPlayerID = 0
            Set rsPlayer = MyDB.OpenRecordset("SELECT LearnPoints, PlayerID, PlayerName FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
            If (Not rsPlayer.EOF) Then
                lPlayerID = MyCLng(rsPlayer!PlayerID)
                zPlayerName = MyCStr(rsPlayer!PlayerName)
                lLearnPoints = MyCLng(rsPlayer!LearnPoints)
            End If
            Set rsPlayer = Nothing
            lBid = gbllQuestShowtimeBID(lPortID)
            If (((lLearnPoints > 0 And gbllQuestShowtimeBID(lPortID) = 0)) Or ((MyCLng(zWord1) + MyCLng(zWord2)) > 0 And (gbllQuestShowtimeBID(lPortID) > 0))) Then
                If (lLearnPoints > 0 And gbllQuestShowtimeBID(lPortID) = 0 And MyCLng(zWord1) + MyCLng(zWord2) > 0) Then
                    If (gbllQuestShowtimeBID(lPortID) = 0) Then
                        MyDB.Execute "UPDATE tblPlayer SET LearnPoints=[LearnPoints]-1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        subSendMsg "&gUse the command, SHOWTIME VALUE. VALUE being your grand total guess of the above items, after a guess please wait a few seconds, further guesses are at no extra cost.", zPortID
                    End If
                Else
                    If (gbllQuestShowtimeBID(lPortID) <> 0) Then
                        subSendMsg "&gYou change your showtime guess value at no charge.", zPortID
                    Else
                        subSendMsg "&gNo value inputted. That was great, thank you!", zPortID
                    End If
                End If
                lBid = MyCLng(zWord1) + MyCLng(zWord2)
                If (lBid <> 0) Then gbllQuestShowtimeBID(lPortID) = lBid
                'check for a winner if their bid changes
                If (cstbQuestShowTimeSingleWinnerMode) Then
                    subShowtimeCheck 'check right after
                Else
                    subSendMsg gblzSHOWTIMEGameName & " will calculate your value in a moment.", zPortID
                End If
            End If
            subSendMsg "&G[" & gbllQuestShowtimeDuration * 3 & "secs left] Your showtime bid is $" & lBid, zPortID
        End If
    Else
        subSendMsg gblzSHOWTIMEGameName & " &wis &ynot currently &wrunning", zPortID
        Select Case lRandom(20)
            Case 1
                subSendMsg "...with your fridge down the street har har, rated arrrr", zPortID
        End Select
    End If
End Sub
Public Function bUncertainityValue(lBid As Long, lTotal As Long, lPercent As Long) As Boolean
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim lBA As Long
    Dim lBB As Long
    Dim lU As Long
    lU = (lBid * (lPercent / 100))
    lBA = lBid - lU
    If (lBA < 5) Then lBA = lRandom(5)
    lBB = lBid + lU
    If (lBA > 9999) Then lBA = 9994 + lRandom(5)
    bReturn = (lBA <= lTotal And lBB >= lTotal)
    bUncertainityValue = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bUncertainityValue," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subShowtimeCheck()
On Error GoTo Err_Check
    Dim iCount As Integer
    Dim iIndex As Integer
    Dim lTotal As Long
    Dim zPortID As String
    Dim bWinner As Boolean
    bWinner = False
    If (gbllQuestShowtimeDuration > 0) Then
        lTotal = 0
        For iCount = 1 To 9
            lTotal = lTotal + gbllQuestShowtimeObjectValue(iCount)
        Next iCount
         
        If (lRandom(20) > 16) Then subSimpleQuestChannel gblzSHOWTIMEGameName & "'s &WBIG! BADDA! SHARED HINT" & vbCrLf & " " & zFormatGoldCofGLearnpts(MyCLng((lRandom(lTotal) + lRandom(lTotal) + lRandom(lTotal) + lRandom(lTotal)) / 4), "G", False) & " [nearest answer wins - keep guessing]"
        
        For iIndex = cstlMinPort To cstlMaxPort
            If (gbllQuestShowtimeBID(iIndex) > 0) Then
            zPortID = MyCStr(iIndex)
            
            Select Case lRandom(35)
                Case 1, 2, 29
                    subSendMsg gblzSHOWTIMEGameName & " &WHINT &Y$" & MyCLng(lTotal / 4) + MyCLng(lTotal / 6) + MyCLng(lTotal / 3) + 1 & "&W] [interesting]", zPortID
                Case 3, 4, 30
                    subSendMsg gblzSHOWTIMEGameName & " &WHINT &Y$" & MyCLng(lTotal / 4) + lRandom(MyCLng(lTotal / 4)) + lRandom(MyCLng(lTotal / 2)) & "&W] [facinating]", zPortID
                Case 10, 11, 12, 13
                    subSendMsg gblzSHOWTIMEGameName & " &WHINT &Y$" & lRandom(lTotal) & "&W] [nearest answer wins - keep guessing]", zPortID
            End Select
            
            If bUncertainityValue(gbllQuestShowtimeBID(iIndex), lTotal, 15) Then
                gbllQuestShowtimeDuration = 0
                If (Not bWinner) Then
                    MyDB.Execute "UPDATE tblPlayer SET Crown=[Crown]+9 WHERE (PortID='" & zPortID & "');", dbFailOnError
                    subSimpleEchoChannel "&YWE HAVE OUR " & gblzSHOWTIMEGameName & " &YGUESSER! " & zFormatGoldCofGLearnpts(9, "c", True) & " [&y" & zReturnPlayerNamePort(zPortID) & "&W]"
                    For iCount = 1 To 9
                        If (gbllQuestShowtimeObjectValue(iCount) > 0) Then
                            Select Case iCount
                                Case 1
                                    subSimpleQuestChannel gblzSHOWTIMEGameName & " &WRESULTs&w: &y" & gblzQuestShowtimeObjectName(iCount) & " &Y$&y" & gbllQuestShowtimeObjectValue(iCount)
                                Case Else
                                    subSimpleQuestChannel "                  &y" & gblzQuestShowtimeObjectName(iCount) & " &Y$&y" & gbllQuestShowtimeObjectValue(iCount)
                            End Select
                        End If
                        gbllQuestShowtimeObjectID(iCount) = 0 'defunt now
                        gblzQuestShowtimeObjectName(iCount) = "" 'defunt now
                        gbllQuestShowtimeObjectValue(iCount) = 0 'defunt now
                    Next iCount
                    subSimpleQuestChannel "&W             SHOW&wTI&aME &wANSWER &W[&Y$&y" & lTotal & "&W]"
                    If (cstbQuestShowTimeSingleWinnerMode) Then 'stop anyone else from winning
                        bWinner = True
                        For iCount = cstlMinPort To cstlMaxPort
                            gbllQuestShowtimeBID(iCount) = 0 'clear this iCount port's player bid value
                        Next iCount
                    End If
                End If
            End If
            End If
        Next iIndex
    End If
    
    If (gbllQuestShowtimeDuration > 0) Then
        gbllQuestShowtimeDuration = gbllQuestShowtimeDuration - 1
        If (gbllQuestShowtimeDuration = 0) Then
            lTotal = 0
            For iCount = 1 To 9
                lTotal = lTotal + gbllQuestShowtimeObjectValue(iCount)
            Next iCount
            subSimpleQuestChannel "&G************************************"
            subSimpleQuestChannel "&G*&YGAME OVER &Y$&y" & strForceSize(MyCStr(lTotal), 7, " ", "A") & "  &WI&wts &WS&whow &WT&wime!&G*"
            subSimpleQuestChannel "&G************************************"
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subShowtimeCheck," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subShowtime(lChance As Long)
On Error GoTo Err_Check
    Dim zMAreaName As String
    Dim iCount As Integer
    Dim rsMessage As Recordset
    Dim lReturned As Long
    Dim lMAreaID As Long
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim zMsg As String

    subShowtimeCheck 'each second this goes off

    If (lRandom(lChance) = 1) Then
        If (gbllQuestShowtimeDuration = 0) Then
            subSimpleQuestChannel "&G************************************"
            subSimpleQuestChannel "&G*&YSTARTING RIGHT AWAY!&WI&wts &WS&whow &WT&wime!&G*"
            subSimpleQuestChannel "&G************************************"
            gbllQuestShowtimeDuration = 20 'about 45 seconds game
            For iCount = cstlMinPort To cstlMaxPort
                gbllQuestShowtimeBID(iCount) = 0
            Next iCount
            For iCount = 1 To 9
                gbllQuestShowtimeObjectID(iCount) = 0
                gbllQuestShowtimeObjectValue(iCount) = 0
                gblzQuestShowtimeObjectName(iCount) = ""
            Next iCount
            gbllQuestShowtimeItemsCount = lRandom(9)
            For iCount = 1 To gbllQuestShowtimeItemsCount
                lReturned = lngSQLRecordCount("SELECT ObjectID FROM tblObject WHERE (CaptureFlagClanID=0 AND Cursed=0 AND PlayerID=0 AND ReturnPlayerID=0 AND (Status=1 OR Status=2) AND ExplodeDuration=0);")
                Set rsMessage = MyDB.OpenRecordset("SELECT TOP " & lRandom(lReturned) & " ObjectID, ObjectName FROM tblObject WHERE (CaptureFlagClanID=0 AND Cursed=0 AND PlayerID=0 AND ReturnPlayerID=0 AND (Status=1 OR Status=2) AND ExplodeDuration=0);", dbOpenSnapshot)
                If (Not rsMessage.EOF) Then
                    rsMessage.MoveLast
                    gbllQuestShowtimeObjectID(iCount) = MyCLng(rsMessage!ObjectID)
                    gblzQuestShowtimeObjectName(iCount) = zShortstop(MyCStr(rsMessage!ObjectName))
                    gbllQuestShowtimeObjectValue(iCount) = vReturnObjectValue(MyCLng(rsMessage!ObjectID), 4) + lRandom(3) + 2 'compaired with gbllQuestShowtimeBID(iCount)
                    subSimpleQuestChannel "&W" & iCount & "&w:&y" & gblzQuestShowtimeObjectName(iCount)
                End If
                Set rsMessage = Nothing
            Next iCount
            'below could be a subSimpleQuestChannel but its nice to know its running.
            subSimpleEchoChannel "&gRules, cast a single learn point to set your SHOWTIME guess value. You can type SHOWTIME VALUE and change your answer at anytime at no extra cost. After a guess please wait a few seconds."
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subShowtime," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bSetHarassANearbyRandomPlayerMS() As Long 'see also subHarassANearbyRandomPlayer
On Error GoTo Err_Check
    Dim lScanPortID As Long
    Dim bReturn As Boolean
    bReturn = False
    lScanPortID = cstlMinPort - 1
    Do While (Not bReturn And lScanPortID < cstlMaxPort)
        lScanPortID = lScanPortID + 1
        If (gblbScareMode(lScanPortID)) Then
            bReturn = True
        End If
    Loop
    bSetHarassANearbyRandomPlayerMS = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bSetHarassANearbyRandomPlayerMS," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subHarassANearbyRandomPlayer(lChance As Long) ' see also bSetHarassANearbyRandomPlayerMS
On Error GoTo Err_Check
    Dim rsMob As Recordset
    Dim lHuntedPlayerID As Long
    Dim lMobID As Long
    Dim zMobName As String
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lMobIDSkip As Long
    
    Dim bStatusSM As Boolean
    Dim lPortID As Long
    
    If (gblbHarassANearbyRandomPlayerMS Or gbllMoon = -5 Or UCase(Format(Now(), "MMM DD")) = "OCT 31") Then 'skullmoon and halloween day force allows this//anyone playing mob harassment for fun? yes? continue
    If (lRandom(lChance) = 1) Then
        lMobIDSkip = 0
        lHuntedPlayerID = 0
        'We find a special mob that doesnt already Autoattack and set it to hunt a nearby player
        Set rsMob = MyDB.OpenRecordset("SELECT MobID, X, Y, Z, MobName, MobAutoAttacks, MobAutoAttacksDuration, PlayerID FROM tblMob WHERE (BittenMaster=True OR SpecialSelfDeleting=True) AND (MobAutoAttacks=False) ORDER BY MobID;", dbOpenSnapshot)
        Do While (Not rsMob.EOF) 'try to set MobAutoAttacksDuration=999 and turn MobAutoAttacks=true and PlayerID=<to the below found player> [when the duration hits 0 we turn them all off]
            lMobID = MyCLng(rsMob!MobID)
            lHuntedPlayerID = MyCLng(rsMob!PlayerID)
            If ((lMobIDSkip <> lMobID) And (lHuntedPlayerID = 0 Or lRandom(2) = 1)) Then
                lMX = MyCLng(rsMob!x)
                lMY = MyCLng(rsMob!y)
                lMZ = MyCLng(rsMob!z)
                zMobName = MyCStr(rsMob!MobName)
                Set rsPlayer = MyDB.OpenRecordset("SELECT PortID, PlayerName, PlayerID, X, Y, Z FROM tblPlayer WHERE ( (Len(PortID)>1) AND ( (Class='IO') OR (CamoflaguedDuration=0 AND ShadowCloakDuration=0 AND BittenDuration=0 AND SneakingMovesLeft=0 AND InvisibilityDuration=0 AND FlyDuration=False AND Race<>'PIX') ) );", dbOpenSnapshot)
                Do While (Not rsPlayer.EOF)
                    lPlayerID = MyCLng(rsPlayer!PlayerID)
                    lPortID = MyCLng(rsPlayer!PortID) 'already confirmed sql checks for a valid portid
                    bStatusSM = gblbScareMode(lPortID)
                    If (bStatusSM Or gbllMoon = -5 Or UCase(Format(Now(), "MMM DD")) = "OCT 31") Then
                        If (lPlayerID <> lHuntedPlayerID) Then  'already being hunted by this mob
                            lPX = MyCLng(rsPlayer!x)
                            lPY = MyCLng(rsPlayer!y)
                            lPZ = MyCLng(rsPlayer!z)
                            
                            If (Abs(lMX - lPX) < 6 And Abs(lMY - lPY) < 6 And lMZ = lPZ) Then
                                zPlayerName = MyCStr(rsPlayer!PlayerName)
                                'If (lHuntedPlayerID <> 0) Then subSendMsgInfoChannel "&a" & zAdverb(zMobName, 1) & zShortstop(zMobName) & " *is no longer hunting* " & zReturnPlayerName(lHuntedPlayerID) & "."gk
                                subSendMsgInfoChannel "&a" & zAdverb(zMobName, 1) & zShortstop(zMobName) & " *is now hunting* " & zPlayerName & "!"
                                MyDB.Execute "UPDATE tblMob SET MobAutoAttacks=True, MobAutoAttacksDuration=999, PlayerID=" & lPlayerID & " WHERE (MobID=" & lMobID & ");", dbFailOnError
                                If (lRandom(3) = 1) Then lMobIDSkip = lMobID
                            End If
                        End If
                    End If
                    rsPlayer.MoveNext
                Loop
                Set rsPlayer = Nothing
            End If
            rsMob.MoveNext
        Loop
        Set rsMob = Nothing
    End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subHarassANearbyRandomPlayer," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

