VERSION 5.00
Begin VB.UserControl uc_systray 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   CanGetFocus     =   0   'False
   ClientHeight    =   1050
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   1545
   ClipBehavior    =   0  'None
   ClipControls    =   0   'False
   HitBehavior     =   0  'None
   InvisibleAtRuntime=   -1  'True
   Picture         =   "systray.ctx":0000
   ScaleHeight     =   70
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   103
   Begin VB.Timer Timer 
      Enabled         =   0   'False
      Interval        =   500
      Left            =   480
      Top             =   0
   End
End
Attribute VB_Name = "uc_systray"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = True
Attribute VB_PredeclaredId = False
Attribute VB_Exposed = False
Option Explicit
Private Enum str_nim
    NIM_ADD = &H0
    NIM_MODIFY = &H1
    NIM_DELETE = &H2
End Enum
Private Enum str_nif
    NIF_MESSAGE = &H1
    NIF_ICON = &H2
    NIF_TIP = &H4
End Enum
Private Enum str_wm
    WM_MOUSEMOVE = &H200
    wm_ldouble = &H203
    wm_ldown = &H201
    wm_lup = &H202
    wm_rdouble = &H206
    wm_rdown = &H204
    wm_rup = &H205
End Enum
Private Type str_notify
    cbSize As Long
    hWnd As Long
    uId As Long
    uFlags As str_nif
    uCallBackMessage As str_wm
    hIcon As Long
    szTip As String * 64
End Type
Private Type str_point
    x As Long
    y As Long
End Type

Private Declare Function GetCursorPos Lib "user32" (lpPoint As str_point) As Long
Private Declare Function Shell_NotifyIcon Lib "shell32" Alias "Shell_NotifyIconA" (ByVal dwMessage As str_nim, pnid As str_notify) As Boolean
Private Declare Function GetSystemMenu Lib "user32" (ByVal hWnd As Long, ByVal bRevert As Long) As Long
Private Declare Function TrackPopupMenu Lib "user32" (ByVal hMenu As Long, ByVal wFlags As Long, ByVal x As Long, ByVal y As Long, ByVal nReserved As Long, ByVal hWnd As Long, ByVal lprc As Long) As Long

Dim go_icon As str_notify

Dim gs_tooltip As String
Dim gb_visible As Boolean
Dim gb_show As Boolean
Dim gb_sysmenu As Boolean

Event MouseMove()
Event MouseDown(ai_button As Integer)
Event MouseUp(ai_button As Integer)
Event DblClick(ai_button As Integer)
Event Click(ai_button As Integer)
Event SingleClick(ai_button As Integer)
Public Property Get ToolTipText() As String
On Error Resume Next
    gs_tooltip = go_icon.szTip
End Property
Public Property Let ToolTipText(ByVal as_tooltip As String)
On Error Resume Next
    gs_tooltip = as_tooltip
    go_icon.szTip = gs_tooltip + Chr(0)
    PropertyChanged "ToolTipText"
    If gb_show Then Shell_NotifyIcon NIM_MODIFY, go_icon
End Property
Public Property Get Icon() As StdPicture
On Error Resume Next
    Set Icon = Picture
End Property
Public Property Set Icon(ByVal ao_icon As StdPicture)
On Error Resume Next
    Set Picture = ao_icon
    PropertyChanged "Icon"
    go_icon.hIcon = ao_icon.Handle
    If gb_show Then Shell_NotifyIcon NIM_MODIFY, go_icon
End Property
Public Property Get Visible() As Boolean
On Error Resume Next
    Visible = gb_visible
End Property
Public Property Let Visible(ByVal ab_visible As Boolean)
On Error Resume Next
    gb_visible = ab_visible
    PropertyChanged "Visible"
    Show gb_visible
End Property
Public Property Get SysMenu() As Boolean
On Error Resume Next
    SysMenu = gb_sysmenu
End Property
Public Property Let SysMenu(ByVal ab_sysmenu As Boolean)
On Error Resume Next
    gb_sysmenu = ab_sysmenu
    PropertyChanged "SysMenu"
End Property
Private Sub Timer_Timer()
On Error Resume Next
    Timer.Enabled = False
    RaiseEvent SingleClick(1)
End Sub
Private Sub UserControl_Initialize()
On Error Resume Next
    go_icon.cbSize = Len(go_icon)
    go_icon.hWnd = hWnd
    go_icon.uId = vbNull
    go_icon.uFlags = NIF_ICON Or NIF_TIP Or NIF_MESSAGE
    go_icon.uCallBackMessage = WM_MOUSEMOVE
End Sub
Private Sub UserControl_MouseMove(ai_button As Integer, ai_shift As Integer, ag_x As Single, ag_y As Single)
On Error Resume Next
    Select Case ag_x
    Case WM_MOUSEMOVE: RaiseEvent MouseMove
    Case wm_ldouble: RaiseEvent DblClick(1)
    Case wm_ldown: RaiseEvent MouseDown(1)
    Case wm_lup:
        RaiseEvent MouseUp(1)
        RaiseEvent Click(1)
        Timer.Enabled = Not Timer.Enabled
    Case wm_rdouble: RaiseEvent DblClick(2)
    Case wm_rdown: RaiseEvent MouseDown(2)
    Case wm_rup:
        If gb_sysmenu Then
            ShowSysMenu
        Else
            RaiseEvent MouseUp(2): RaiseEvent Click(2)
        End If
    End Select
End Sub
Private Sub UserControl_ReadProperties(ao_prop As PropertyBag)
On Error Resume Next
    gs_tooltip = ao_prop.ReadProperty("ToolTipText", "")
    go_icon.szTip = gs_tooltip + Chr(0)
    Set Picture = ao_prop.ReadProperty("Icon", Nothing)
    gb_visible = ao_prop.ReadProperty("Visible", False)
    gb_sysmenu = ao_prop.ReadProperty("SysMenu", True)
    go_icon.hIcon = Picture.Handle
    If Ambient.UserMode Then Show gb_visible
End Sub
Private Sub UserControl_Resize()
On Error Resume Next
    Width = 480
    Height = 480
End Sub
Private Sub UserControl_Terminate()
On Error Resume Next
    If gb_show Then Show False
End Sub
Private Sub UserControl_WriteProperties(ao_prop As PropertyBag)
On Error Resume Next
    ao_prop.WriteProperty "ToolTipText", gs_tooltip, ""
    ao_prop.WriteProperty "Icon", Picture, Nothing
    ao_prop.WriteProperty "Visible", gb_visible, False
    ao_prop.WriteProperty "SysMenu", gb_sysmenu, True
End Sub
Private Sub Show(Optional ByVal ab_show As Boolean = True)
On Error Resume Next
    If ab_show And gb_show = False Then
        If Ambient.UserMode Then
            Shell_NotifyIcon NIM_ADD, go_icon
            gb_show = True
        End If
    ElseIf ab_show = False And gb_show = True Then
        Shell_NotifyIcon NIM_DELETE, go_icon
        gb_show = False
    End If
End Sub
Public Sub ShowSysMenu(Optional ByVal al_hwnd As Long)
On Error Resume Next
    Dim pos As str_point

    If al_hwnd = 0 Then al_hwnd = Parent.hWnd
    GetCursorPos pos
    TrackPopupMenu GetSystemMenu(al_hwnd, False), &H200, pos.x, pos.y, al_hwnd, al_hwnd, 0
End Sub
