VERSION 5.00
Object = "{48E59290-9880-11CF-9754-00AA00C00908}#1.0#0"; "MSINET.OCX"
Begin VB.Form frmCoaFTP 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Send Files"
   ClientHeight    =   525
   ClientLeft      =   45
   ClientTop       =   435
   ClientWidth     =   3660
   Icon            =   "frmCoAFTP.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   525
   ScaleWidth      =   3660
   Begin VB.Timer tAutoreset 
      Interval        =   63000
      Left            =   1800
      Top             =   120
   End
   Begin InetCtlsObjects.Inet ITC 
      Left            =   120
      Top             =   120
      _ExtentX        =   1005
      _ExtentY        =   1005
      _Version        =   393216
      RequestTimeout  =   50
   End
End
Attribute VB_Name = "frmCoaFTP"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub Form_Load()
    subMakeConnection
    subFTPUpload "c:", "coawhois.htm", gblzFTPServerDirectory
End Sub
Private Sub subMakeConnection()
On Error GoTo Err_Check
    If (gbllFTPProxyServer > 0) Then ITC.Proxy = gbllFTPProxyServer
    'If no server or password is specified exit the sub
    If (gblzFTPServerURL = "") Then
        Me.Caption = "Connect to?"
    Else
        'Set status label
        Me.Caption = "FTP Connecting..."
        
        'Set protocol and server
        ITC.Protocol = icFTP
        ITC.URL = gblzFTPServerURL
        
        'If no username is entered default to anonymous
        If (gblzFTPUserName = "") Then
            ITC.UserName = "anonymous"
        Else
            ITC.UserName = gblzFTPUserName
        End If
        
        ITC.Cancel
        
        'Set the password and connect
        ITC.Password = gblzFTPUserPassword
        ITC.RequestTimeout = 40
        'ITC.Execute , "DIR"
        'Do While ITC.StillExecuting
        '    DoEvents: DoEvents: DoEvents
        'Loop
        'Set status label, disable the log on button, and enable the log off button
        Me.Caption = "Connected"
    End If
    Exit Sub
Err_Check:
    'If logon fails alert the user
    Me.Caption = "Connection failure"
    ITC.Cancel
End Sub
Private Sub subFTPUpload(zPath As String, zFilename As String, zFTPServerDirectory As String)
On Error GoTo Err_Check
    Dim lErrorNumber As Long
    'Send the file and update the remote file list box
    ITC.Execute , "PUT " & Chr(34) & zPath & "\" & zFilename & Chr(34) & " " & Chr(34) & zFTPServerDirectory & zFilename & Chr(34)
    Do Until (Not ITC.StillExecuting)
        DoEvents: DoEvents: DoEvents: DoEvents
    Loop
    'ITC.Execute , "DIR"
    Me.Caption = "File sent successfully."
    Exit Sub
Err_Check:
    'If logon fails alert the user 35764
    lErrorNumber = Err.Number
    Select Case (lErrorNumber)
        Case 35764
            Me.Caption = "Request was terminated..."
        Case Else
            Me.Caption = "File not found (" & Err.Description & ")"
    End Select
    ITC.Cancel
End Sub
Private Sub ITC_StateChanged(ByVal iState As Integer)
On Error GoTo Err_Check
'Check the state of the itc, and change the status accordingly
    Select Case (iState)
        Case icResolvingHost
            Me.Caption = "Finding Host IP Address"
        Case icHostResolved
            Me.Caption = "IP Address Found"
        Case icConnecting
            Me.Caption = "Connecting To Host"
        Case icConnected
            Me.Caption = "Connected"
        Case icRequesting
            Me.Caption = "Sending Request"
        Case icRequestSent
            Me.Caption = "Request Sent"
        Case icReceivingResponse
            Me.Caption = "Receiving Response"
        Case icResponseReceived
            Me.Caption = "Response Received"
        Case icDisconnecting
            Me.Caption = "Disconnecting"
        Case icDisconnected
            Me.Caption = "Not Connected"
        Case icError
            If (ITC.ResponseCode = 12030) Then
                Me.Caption = "Not Connected"
                ITC.Cancel
            End If
            If (ITC.ResponseCode <> 87) Then
                Me.Caption = ITC.ResponseCode & " " & ITC.ResponseInfo
            End If
        Case (icResponseCompleted)
            'loop until you get all data
            'Do While True
            '    Data1 = ITC.GetChunk(4096, icString)
            '    If Len(Data1) = 0 Then Exit Do
            '    DoEvents
            '    RemoteFiles = RemoteFiles & Data1
            'Loop
    End Select
    DoEvents
    Exit Sub
Err_Check:
End Sub
Private Sub tAutoreset_Timer()
On Error Resume Next
    tAutoreset.Interval = 0
    DoEvents
    Unload Me
End Sub
