Attribute VB_Name = "modCombatPvM"
Option Explicit
Public Sub subFactionGenesis()
On Error GoTo Err_Check 'retest but this is for kill stastics
'ie. tblPlayerFactionSummaryReport lMobID, lPlayerID, "K" or tblPlayerFactionSummaryReport lMobID, lPlayerID, "T" or tblPlayerFactionSummaryReport lMobID, lPlayerID, "B"
    Dim rsPlyr As Recordset
    Dim lSQLCount As Long
    lSQLCount = lngSQLRecordCount("SELECT DateDiff('d',[FactionYearlyResetMidnight],Format(Now(),'mmm dd, yyyy')) FROM tblSystemConfig WHERE (((DateDiff('d',[FactionYearlyResetMidnight],Format(Now(),'mmm dd, yyyy')))>360));")
    If (lSQLCount <> 0) Then
        MyDB.Execute "UPDATE tblSystemConfig SET FactionYearlyResetMidnight = Format(Now(),'mmm dd, yyyy') WHERE (((DateDiff('d', [FactionYearlyResetMidnight], Format(Now(),'mmm dd, yyyy')))>360));", dbFailOnError
        Set rsPlyr = MyDB.OpenRecordset("SELECT PlayerType, Z, FactionID, FactionGrowth, FactionAtt, FactionDef, FactionPopulation FROM tblArea;", dbOpenDynaset)
        Do While (Not rsPlyr.EOF)
            If (MyCLng(rsPlyr!PlayerType) = 0 And Not bOdd(MyCLng(rsPlyr!z))) Then
                rsPlyr.Edit
                rsPlyr!FactionID = lRandom(9)
                rsPlyr!FactionGrowth = lRandom(5)
                rsPlyr!FactionAtt = lRandom(40) + 10
                rsPlyr!FactionDef = lRandom(40) + 10
                rsPlyr!FactionPopulation = lRandom(900) + 99
                rsPlyr.Update
            Else
                rsPlyr.Edit
                rsPlyr!FactionID = 0
                rsPlyr!FactionGrowth = 0
                rsPlyr!FactionAtt = 0
                rsPlyr!FactionDef = 0
                rsPlyr!FactionPopulation = 0
                rsPlyr.Update
            End If
            rsPlyr.MoveNext
        Loop
        Set rsPlyr = Nothing
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subFactionGenesis," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subPlayerRecordFactionCommand(lPassMobID As Long, lPassPlayerID As Long, zPassActivityType As String, lPassFactionID As Long)
On Error GoTo Err_Check 'retest but this is for kill stastics
'ie. tblPlayerFactionSummaryReport lMobID, lPlayerID, "K" or tblPlayerFactionSummaryReport lMobID, lPlayerID, "T" or tblPlayerFactionSummaryReport lMobID, lPlayerID, "B"
    Dim lSQLCount As Long
    lSQLCount = lngSQLRecordCount("SELECT PlayerID FROM tblPlayerFactionSummaryReport WHERE (ActivityType='" & UCase(Mid(zPassActivityType, 1, 1)) & "' AND FactionID=" & lPassFactionID & " AND PlayerID=" & lPassPlayerID & ");")
    If (lSQLCount > 0) Then
        MyDB.Execute "UPDATE tblPlayerFactionSummaryReport SET NumOfTimes=[NumOfTimes]+1 WHERE (ActivityType='" & zPassActivityType & "' AND FactionID=" & lPassFactionID & " AND PlayerID=" & lPassPlayerID & ");", dbFailOnError
    Else
        MyDB.Execute "INSERT INTO tblPlayerFactionSummaryReport(CreatedDate, NumOfTimes, MobID, PlayerID, ActivityType, FactionID) SELECT '" & MyCStr(Format(Now(), "mmm dd, yyyy hh:nn")) & "', 1, " & lPassMobID & ", " & lPassPlayerID & ", '" & zPassActivityType & "', " & lPassFactionID & ";", dbFailOnError
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerRecordFactionCommand," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDISABLEDPlayerRecordMobDetails(lPassMobID As Long, lPassPlayerID As Long, zPassActivityType As String)
On Error GoTo Err_Check 'retest but this is for kill stastics
'ie. subPlayerRecordMobDetails lMobID, lPlayerID, "K" or subPlayerRecordMobDetails lMobID, lPlayerID, "T" or subPlayerRecordMobDetails lMobID, lPlayerID, "B"
    'Dim lSQLCount As Long
    'lSQLCount = lngSQLRecordCount("SELECT PlayerID FROM tblPlayerRecordMobDetails WHERE (ActivityType='" & UCase(Mid(zPassActivityType, 1, 1)) & "' AND MobID=" & lPassMobID & " AND PlayerID=" & lPassPlayerID & ");")
    'If (lSQLCount > 0) Then
    '    MyDB.Execute "UPDATE tblPlayerRecordMobDetails SET NumOfTimes=[NumOfTimes]+1 WHERE (ActivityType='" & zPassActivityType & "' AND MobID=" & lPassMobID & " AND PlayerID=" & lPassPlayerID & ");", dbFailOnError
    'Else
    '    MyDB.Execute "INSERT INTO tblPlayerRecordMobDetails(CreatedDate, NumOfTimes, MobID, PlayerID, ActivityType) SELECT '" & MyCStr(Format(Now(), "mmm dd, yyyy hh:nn")) & "', 1, " & lPassMobID & ", " & lPassPlayerID & ", '" & zPassActivityType & "';", dbFailOnError
    'End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subPlayerRecordMobDetails," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lReturnPlayerPetCount(lOPlayerID As Long) As Long
    lReturnPlayerPetCount = lngSQLRecordCount("SELECT PlayerPetID FROM tblPlayerPet WHERE (PlayerID=" & lOPlayerID & ");")
End Function

Public Sub subCombatWorldVsPets(lPlayerID As Long, iType As Integer, zPetOwnerName As String, zTargetName As String, lTargetLevel As Long, lOX As Long, lOY As Long, lOZ As Long, zClass As String, zRace As String, lFlyDuration As Long, bVerbose As Boolean, bAllowFullBattleText As Boolean, zPAPortID As String, zPDPortID As String)
            'subCombatWorldVsPets lPlayerID, 1, zPlayerName, zMobName, lMLevel, lPX, lPY, lPZ, zClass, zRace, lFlyDuration, bVerbose, zPortID, ""
On Error GoTo Err_Check 'Pets are being attacked, World vs Pets Mob vs Pets
'iType of 1 = mob, iType of 2 = player
    Dim zPetName As String
    Dim lDamageToPet As Long
    Dim lPetLevel As Long
    Dim lMobLevel As Long
    Dim rsPets As Recordset
    Dim lTotalDamageToPlayer As Long
    Dim lPetsTotalHits As Long
    Dim lPetsTotalMisses As Long
    Dim zPetHitMsg As String
    Dim zPetMissedMsg As String
    Dim bPetDied As Boolean
    Dim bDmgPet As Boolean
    Dim lPetHitPoints As Long
    Dim lPetEvolve As Long
    Dim lPetHPBonus As Long
    Dim lPetDRBonus As Long
    Dim lPetHRBonus As Long
    Dim lPetACBonus As Long
    Dim zPetBreath As String
    Dim lPetSpecialType As Long
    Dim zPetClassSpecific As String
    
    bPetDied = False
    Set rsPets = MyDB.OpenRecordset("SELECT * FROM tblPlayerPet WHERE (PlayerID=" & lPlayerID & ");", dbOpenDynaset)
    If (Not rsPets.EOF) Then
        lPetsTotalHits = 0
        lPetsTotalMisses = 0
        lTotalDamageToPlayer = 0
        zPetHitMsg = " " & zTargetName & " hits:"
        zPetMissedMsg = " " & zTargetName & " misses:"
        Do While (Not rsPets.EOF)
            zPetName = MyCStr(rsPets!PetName)
            lPetSpecialType = MyCLng(rsPets!PetSpecialType)
            zPetName = zShortstop(zPetName)
            lPetEvolve = MyCLng(rsPets!PetEvolve)
            lPetHPBonus = MyCLng(rsPets!PetHPBonus)
            lPetDRBonus = MyCLng(rsPets!PetDRBonus)
            lPetHRBonus = MyCLng(rsPets!PetHRBonus)
            lPetACBonus = MyCLng(rsPets!PetACBonus)
            zPetBreath = MyCStr(rsPets!PetBreath)
            lMobLevel = MyCLng(rsPets!MobLevel)
            lPetLevel = MyCLng(rsPets!PetLevel)
            zPetClassSpecific = MyCStr(rsPets!PetClassSpecific)
            lPetHitPoints = MyCLng(rsPets!PetHitPoints)
            If (lRandom(lTargetLevel + 1) > lRandom(lMobLevel + lPetLevel + lPetACBonus)) Then
                lDamageToPet = lRandom(MyCLng(lTargetLevel / 2) + 9) + 1
                If (lRandom(20) = 20) Then lDamageToPet = lDamageToPet * 2 'double damage
                lTotalDamageToPlayer = lTotalDamageToPlayer + lDamageToPet
                
                rsPets.Edit

                bDmgPet = True
                If (zClass = "KN") Then 'knights can shift their pets death into force-spirts - we do this before they actually die
                    If (lPetSpecialType <> 1) Then 'pet never got shifted to a sprit yet
                        If (lRandom(9) < 6) Then
                            If (lPetHitPoints - lDamageToPet < 1) Then
                                bDmgPet = False 'pet mutated to the force
                                lPetHitPoints = 900 + (lPetLevel * 500) + (lPetHPBonus * lPetEvolve)
                                zPetName = "::" & zPetName & "::" 'pets get a sprit life with knights
                                rsPets!PetName = zPetName
                                rsPets!PetSpecialType = 1 'even if they were some other special type they are now Spiritual because they died
                            End If
                        End If
                    End If
                End If

                If (bDmgPet) Then
                    If (zPetClassSpecific = "PA" And lRandom(3) = 1) Then 'Paladins can shield a pet from dmg
                        subSendMsg "&WYou help &w[" & zPetName & "] &Wdeflect " & lDamageToPet & " damage.", zPAPortID 'we dont record the damage to the pet
                    Else
                        lPetHitPoints = lPetHitPoints - lDamageToPet
                    End If
                End If
                rsPets!PetHitPoints = lPetHitPoints
                
                rsPets.Update
                
                lPetsTotalHits = lPetsTotalHits + 1
                zPetHitMsg = zPetHitMsg & " " & zPetName & "(" & lDamageToPet & ")"
            Else
                lPetsTotalMisses = lPetsTotalMisses + 1
                zPetMissedMsg = zPetMissedMsg & " " & zPetName
            End If
            
            If (lPetHitPoints < 1) Then
                bPetDied = True
                rsPets.Delete
                zPetHitMsg = zPetHitMsg & " " & zPetName & "(DIED)"
            End If
            
            rsPets.MoveNext
        Loop
        
        If (lPetsTotalHits > 0) Then
            If (bVerbose) Then subSendMsgAreaAll gblzFBRED & "[" & lPetsTotalHits & "&r" & zPetHitMsg & ".", lOX, lOY, lOZ
        End If
        
        If (lPetsTotalMisses > 0) Then
            If (bVerbose) Then subSendMsgAreaAll gblzFBGRE & "[" & lPetsTotalMisses & "&y" & zPetMissedMsg & ".", lOX, lOY, lOZ
        End If
    End If
    Set rsPets = Nothing
    
    If (bPetDied) Then
        If (lFlyDuration = 0) Then
            If (zRace <> "PIX") Then
                If (Not bPlayerMountedOnFlyingPet(lPlayerID)) Then
                    If (bAreaFallSpot(lOX, lOY, lOZ)) Then
                        subRemovePlayerPetsThatCannotFly lPlayerID
                        subSendMsgAreaAllDISmart "&y", zPetOwnerName, "You fall off your mount!", "", "%s1 dismounts suddenly to the ground!", lOX, lOY, lOZ
                        If (iPlayerHitPointTest(zPAPortID, True) = 2) Then
                            subSendMsgAreaAllDISmart "&R", zPetOwnerName, "AHHHHHhhhhhhhhhhhhhhhhh!", "", "%s1 falls twirling to the ground below. &M*SPLAT*", lOX, lOY, lOZ
                            subSendMsg "&RYou fell to your DEATH and only flying pets survived! *SPLAT*", zPAPortID
                        End If
                    End If
                End If
            End If
        End If
    End If
    
    'If (lTotalDamageToPlayer > 0) Then
    '    If (bVerbose) Then subSendMsg "&W[&wpet-assist&W] &rYou take [&R" & lTotalDamageToPlayer & " dmg&r] defending your pets.", zPAPortID
    'End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatWorldVsPets," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function lCombatPetsVsWorld(lPlayerID As Long, lAllPetCHABonus As Long, zClass As String, iType As Integer, zPetOwnerName As String, zTargetName As String, lTargetLevel As Long, lOX As Long, lOY As Long, lOZ As Long, bVerbose As Boolean, bAllowFullBattleText As Boolean, zPAPortID As String, Optional zPDPortID As String) As Long 'returns Pet Damage Pets are attacking, Pets vs World
On Error GoTo Err_Check 'See Also: lPetXPGainMath
'iType of 1 = mob, iType of 2 = player
    Dim rsPets As Recordset
    Dim lReturn As Long
    Dim zPetName As String
    Dim zOriginalPetName As String
    Dim lPetLevel As Long
    Dim lMobLevel As Long
    Dim lPetDamage As Long
    Dim bPetGainedALevel As Boolean
    Dim lTranslateCPPAllowed As Long
    Dim lPetsTotalHits As Long
    Dim lPetsTotalMisses As Long
    Dim zPetHitMsg As String
    Dim zPetMissedMsg As String
    Dim lPetXP As Long
    Dim lHoldValue As Long
    Dim lPetEvolve As Long
    Dim lPetHPBonus As Long
    Dim lPetDRBonus As Long
    Dim lPetHRBonus As Long
    Dim lPetACBonus As Long
    Dim lPetXPGain As Long
    Dim zPetBreath As String
    Dim lPetSpecialType As Long
    Dim bEvolves As Boolean
    
    lReturn = 0
    If (Not cstbFastPets) Then
        Set rsPets = MyDB.OpenRecordset("SELECT * FROM tblPlayerPet WHERE (PlayerID=" & lPlayerID & ");", dbOpenDynaset)
        If (Not rsPets.EOF) Then
            lPetsTotalHits = 0
            lPetsTotalMisses = 0
            zPetHitMsg = " " & zTargetName & " was *hit* by:"
            zPetMissedMsg = " " & zTargetName & " was *missed* by:"
            
            Do While (Not rsPets.EOF)
                zPetName = MyCStr(rsPets!PetName)
                lPetSpecialType = MyCLng(rsPets!PetSpecialType)
                bEvolves = (lPetSpecialType <> 1 And lPetEvolve < 17) 'not a knight sprit pet and not fully evolved
                zOriginalPetName = zPetName
                zPetName = zShortstop(zPetName)
                lPetEvolve = MyCLng(rsPets!PetEvolve)
                lPetLevel = MyCLng(rsPets!PetLevel)
                lMobLevel = MyCLng(rsPets!MobLevel)
                lPetXPGain = lPetXPGainMath(lAllPetCHABonus, lMobLevel, lPetLevel) '(cstlPetLevelXP * lMobLevel * lPetLevel)
                lPetHPBonus = MyCLng(rsPets!PetHPBonus)
                lPetDRBonus = MyCLng(rsPets!PetDRBonus)
                lPetHRBonus = MyCLng(rsPets!PetHRBonus)
                lPetACBonus = MyCLng(rsPets!PetACBonus)
                zPetBreath = MyCStr(rsPets!PetBreath)
                
                'Mob hit the creature?
                If (lRandom(lPetLevel + lPetHRBonus) + lAllPetCHABonus > lRandom(lTargetLevel)) Then
                    lPetXP = MyCLng(rsPets!PetXP)
                    lPetDamage = lRandom(MyCLng(rsPets!PetDamage))  'Damage of lPetDRBonus was saved on first leveling of pet
                    If (Len(zPetBreath) > 0) Then
                        If (lRandom(lPetLevel + lPetHRBonus) > lRandom(100)) Then
                            lPetDamage = lPetDamage * 2
                            If (gblbClientMode(MyCLng(zReturnPortIDByPlayerID(lPlayerID)))) Then subSendMsgAreaAll "&m" & zPetName & " &a blasts " & zPetBreath & " everwhere", lOX, lOY, lOZ
                        End If
                    End If
                    lReturn = lReturn + lPetDamage
                    
                    rsPets.Edit
                    'Pet gains XP
                    lPetXP = lPetXP + (MyCLng(lTargetLevel / 2) + lRandom(MyCLng(lTargetLevel / 2))) + 1 + lRandom(lAllPetCHABonus)
                    'Pet gained a level?
                    bPetGainedALevel = False
                    If (lPetXP >= lPetXPGain) Then
                        bPetGainedALevel = True 'pet gained a level
                        lPetLevel = lPetLevel + 1
                        
                        If (bEvolves) Then 'Can this pet evolve?
                            If (lRandom(lAllPetCHABonus) > lRandom(999 + (lPetEvolve * 5)) Or lRandom(lPetLevel + lPetEvolve) = 1) Then 'Yes?
                                If (lPetEvolve < 18) Then lPetEvolve = lPetEvolve + 1
                                subSendMsgAreaAll gblzFBWHI & "     * * * " & UCase(zPetName) & "  E V O L V E D * * *", lOX, lOY, lOZ
                                zOriginalPetName = MyCStr(zStripEvolveNames(zOriginalPetName))
                                rsPets!PetName = zTranslatePetEvolve(lPetEvolve) & " " & zOriginalPetName
                                lPetHPBonus = lPetHPBonus + lRandom(5) + 5
                                lPetDRBonus = lPetDRBonus + lRandom(5) + 1
                                lPetHRBonus = lPetHRBonus + lRandom(5) + 1
                                lPetACBonus = lPetACBonus + lRandom(5) + 1
                                rsPets!PetHPBonus = lPetHPBonus
                                rsPets!PetDRBonus = lPetDRBonus
                                rsPets!PetHRBonus = lPetHRBonus
                                rsPets!PetACBonus = lPetACBonus
                            End If
                        End If

                        lTranslateCPPAllowed = lTranslateClassPlayerPetsAllowed(zClass)
                        
                        rsPets!PetEvolve = lPetEvolve
                        rsPets!PetLevel = lPetLevel
                        
                        lHoldValue = (lMobLevel * (MyCLng(cstlPetHPMultiplier / 2) + 1)) + (lPetLevel * cstlPetHPMultiplier) + 1 + lTranslateCPPAllowed
                        If (lHoldValue > 99999) Then lHoldValue = 99999
                        rsPets!PetHitPoints = lHoldValue + lPetHPBonus
                        
                        lHoldValue = (lMobLevel) + (lPetLevel * cstlPetDmgMultiplier) + 1 + lTranslateCPPAllowed
                        If (lHoldValue > 999 + lMobLevel + lPetLevel) Then lHoldValue = 999 + lMobLevel + lPetLevel
                        rsPets!PetDamage = lHoldValue + lPetDRBonus
                        
                        lPetXP = lPetXPGain - lPetXP 'might be XP residue left over
                    End If
                    rsPets!PetXP = lPetXP
                    rsPets.Update
                    
                    lPetsTotalHits = lPetsTotalHits + 1
                    zPetHitMsg = zPetHitMsg & " " & zPetName & "(" & lPetDamage & ")"
                    If (bPetGainedALevel) Then subSendMsg "&m" & zPetName & " &A[+level]", zPAPortID
                Else
                    lPetsTotalMisses = lPetsTotalMisses + 1
                    zPetMissedMsg = zPetMissedMsg & " " & zPetName
                End If
                rsPets.MoveNext
            Loop
            
            If (bVerbose) Then
                If (lPetsTotalHits > 0) Then
                    subSendMsgAreaAll gblzFBGRE & "[" & lPetsTotalHits & "&r" & zPetHitMsg & ".", lOX, lOY, lOZ
                End If
                
                If (lPetsTotalMisses > 0) Then
                    subSendMsgAreaAll gblzFBRED & "[" & lPetsTotalMisses & "&y" & zPetMissedMsg & ".", lOX, lOY, lOZ
                End If
            End If
        End If
        Set rsPets = Nothing
    End If
    lCombatPetsVsWorld = lReturn
    Exit Function
Err_Check:
    subWriteErrorFile "lCombatPetsVsWorld," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subCombatPvM(lPortID As Long) 'Player vs Enviroment aka. CombatPvE subSpellListAttackSpells
On Error GoTo Err_Check 'See also: iPlayerHitPointTest bCombatMvP subCombatPvM subCombatPvP lCombatPetsVsWorld + subCombatWorldVsPets
    Const cstbMorphElementalDmgON = False
    Const cstlLeechingMax = 100 'this can never be 0!
    Const cstlChance = 10
    Const cstlSlayValue = 600
    Dim bAllowFullBattleText As Boolean
    Dim bVerbose As Boolean
    Dim lCountOfPlayerFactionsInArea As Long
    Dim lNeverAttackable As Long
    Dim lDummy As Long
    Dim lImmunitySlayLevel As Long
    Dim lMInitativeChance As Long
    Dim lMAntiMoveDuration As Long
    Dim lMoveCostIIAdditional As Long
    Dim lMStunDuration As Long
    Dim bNewbie As Boolean
    Dim lLearnPercent As Long
    Dim bOverKill As Boolean
    Dim lRollIC As Long
    Dim rsLearn As Recordset
    Dim rsPlayer As Recordset
    Dim rsPlayerWeapons As Recordset
    Dim bDoubleSlash As Boolean
    Dim lPlayerID As Long
    Dim lQuestMobID As Long
    Dim lQuestXPBonus As Long
    Dim lFactionXPBonus As Long
    Dim lIASChance As Long
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim lCalcuBonusTNL As Long
    Dim lCalcuBonusDmg As Long
    Dim lTMove As Long 'Tired and move was lost during battle
    Dim lCMove As Long
    Dim lOMove As Long
    Dim lWhereID As Long
    Dim zPlayerName As String
    Dim lClawHandDuration As Long
    Dim lKnifeHandDuration As Long
    Dim lDragonUppercutDuration As Long
    Dim lPowerKickDuration As Long
    Dim lHurricaneKickDuration As Long
    Dim lDoublePunchDuration As Long
    Dim lDropKickDuration As Long
    Dim lHeadButtDuration As Long
    Dim lElbowDuration As Long
    Dim lHideDuration As Long
    Dim lKneeDuration As Long
    Dim lStatus As Long
    Dim zClass As String
    Dim zBittenReservedOriginalClass As String
    Dim zRace As String
    Dim lPlayerLevel As Long
    Dim lCDAMROLL As Long
    Dim lCHITROLL As Long
    Dim lCAC As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lCDEX As Long
    Dim lCCon As Long
    Dim lCCHA As Long 'Dim lCHA As Long 'lCHA = MyCLng(rsPlayer!CCHA)
    Dim lCLuc As Long
    Dim zObjectName As String
    Dim lPlayerTotalStats As Long
    Dim lNumAttRndMax As Long
    Dim lNumAttRndCount As Long
    Dim lNumAttRnd As Long
    Dim lInertShield As Long
    Dim lTotalPossibleElementalDmg As Long
    Dim lLightningElementalDamage As Long
    Dim lColdElementalDamage As Long
    Dim lFireElementalDamage As Long
    Dim lPoisonElementalDamage As Long
    Dim lSlayChance As Long
    Dim lWeaponSkillBackStabClassLevel As Long
    Dim lWeaponSkillMissileRangeClassLevel As Long
    Dim lTotalBerserkDmg As Long
    Dim lTotalBerserkDmgMax As Long
    Dim lBackStabTotalDamage As Long
    Dim lBackStabTotalDamageMax As Long
    Dim bIAS As Boolean
    Dim lSanctuaryDuration As Long
    Dim lFireshieldDuration As Long
    Dim lIceshieldDuration As Long
    Dim lChaosshieldDuration As Long
    Dim lStaticshieldDuration As Long
    Dim lBeserkDuration As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lInvisibilityDuration As Long
    Dim lCamoflaguedDuration As Long
    Dim lSlayKills As Long
    Dim lXP As Long
    Dim lMartialArtsKungPowLevel As Long
    Dim lMartialArtsLungingElbowsLevel As Long
    Dim lMartialArtsTigerFistsLevel As Long
    Dim lMartialArtsTuskPunchLevel As Long
    Dim lMartialArtsKungPowXP As Long
    Dim lMartialArtsLungingElbowsXP As Long
    Dim lMartialArtsTigerFistsXP As Long
    Dim lMartialArtsTuskPunchXP As Long
    Dim lEntanglementDuration As Long
    Dim zEntanglementDesc As String
    Dim lStunDuration As Long
    Dim lBlindDuration As Long
    Dim lMagicFind As Long
    Dim lMagicFindBase As Long
    Dim zPortID As String
    Dim lAlignment As Long
    Dim zCriticalText(1 To 2) As String
    Dim lCriticalHRCount As Long
    Dim lCriticalHRTotal As Long
    Dim lCriticalDRCount As Long
    Dim lCriticalDRTotal As Long
    Dim zPlayerWeapon(1 To 2) As String
    Dim zPlayerWeaponType(1 To 2) As String
    Dim bWeaponCellHit(1 To 2) As Boolean
    Dim lWeaponBlind(1 To 2) As Long
    Dim lPlayerWeaponCount As Long
    Dim lWeaponHR(1 To 2) As Long
    Dim lWeaponDR(1 To 2) As Long
    Dim lCriticalHR(1 To 2) As Long
    Dim lCriticalHRChance(1 To 2) As Long
    Dim lCriticalDR(1 To 2) As Long
    Dim lCriticalDRChance(1 To 2) As Long
    Dim lCriticalBlindChance(1 To 2) As Long
    Dim lIndestructibleMobLv(1 To 2) As Long
    Dim lWeaponDamage(1 To 2) As Long
    Dim iStatus As Integer
    Dim bBlindFight As Boolean
    Dim bStunFight As Boolean
    Dim bEndCombat As Boolean
    Dim lShadowCloakDuration As Boolean
    Dim lMartialArtsBarehandedHRCalcu As Long
    Dim lMartialArtsBarehandedDRCalcu As Long
    Dim bBarehandedNoMartialArts As Boolean
    Dim bBarehandedWithMartialArts As Boolean
    Dim lDamage As Long 'this is the total ddamage inflicted on the mob
    Dim lTotalDamage As Long 'this is the total ddamage inflicted on the mob
    Dim lHoldDamage As Long
        
    Dim lGainXP As Long
    
    Dim lCHP As Long
    Dim lOHP As Long
    Dim lCMana As Long
    Dim lOMANA As Long
    Dim lCEssence As Long
    Dim lOEssence As Long
    Dim lCSoul As Long
    Dim lOSoul As Long
    
    Dim rsMob As Recordset
    Dim lMX As Long
    Dim lMY As Long
    Dim lMZ As Long
    Dim lMWimpyHP As Long
    Dim lMWimpyChance As Long
    Dim lMHerdMobID As Long
    Dim lMSanctuaryChance As Long
    Dim lMSanctuaryDamageReduction As Long
    Dim lMSanctuaryDuration As Long
    Dim lMHPBonus As Long
    Dim lMACBonus As Long
    Dim lStoreMobReducationTotalDmg As Long
    Dim lMobReducationTotalDmg As Long
    Dim lMResPhysicalDamage As Long
    Dim lMResLightningElementalDamage As Long
    Dim lMResColdElementalDamage As Long
    Dim lMResFireElementalDamage As Long
    Dim lMCHITROLL As Long
    Dim lMCDAMROLL As Long
    Dim lMHP As Long
    Dim lMAC As Long
    Dim zMobName As String
    Dim zUMobName As String
    Dim lMLevel As Long
    Dim lMLevelSlayChance As Long
    Dim lMobID As Long
    Dim lHitThisRound As Long
    Dim lMobWeaponHit As Long
    Dim lLearnSkillsHit As Long
    Dim lLearnSkillsLeveled As Long
    Dim bMobDied As Boolean
    Dim lMMaxXPValue As Long '(Level * cstMobHPRespawn) + MHPBonus
    Dim bMobInvisible As Boolean
    Dim lMEntanglementDuration As Long
    Dim lMAlignment As Long
    Dim lMShockshieldDuration As Long
    Dim zMDefeatedMobDesc As String
    Dim bMSpecialSelfDeleting As Boolean
    Dim lMMoveAllowed As Long
    Dim lMSpecialGloryPlayerAmt As Long
    
    Dim lMNumAttRnd As Long
    Dim bBounty As Boolean
    
    Dim lElementalHits As Long
    Dim lElementalDmg As Long
    Dim lWearSkillsHit As Long
    Dim lWearSkillsTotalDmg As Long
    Dim lPetDamage As Long
    
    Dim bSlayChance As Boolean
    
    Dim lMoveReductionInertialInhibitor As Long
    Dim lMoveCostInertialInhibitor As Long

    Dim lLeechingHP As Long
    Dim lLeechingEssence As Long
    Dim lLeechingSoul As Long
    Dim lLeechingMana As Long
    Dim lLeechingMove As Long
    
    Dim lCalcuLeechingHP As Long
    Dim lCalcuLeechingEssence As Long
    Dim lCalcuLeechingSoul As Long
    Dim lCalcuLeechingMana As Long
    Dim lCalcuLeechingMove As Long
    Dim lFlyDuration As Long
    
    Dim lCriticalHRHoldDamage As Long
    Dim lCriticalDRHoldDamage As Long
    Dim zElementalText As String
    Dim zBattleText As String
    Dim lBattleText As Long 'this is to format it long length
    Dim lFireElementalDmg As Long
    Dim lLightningElementalDmg As Long
    Dim lPoisonElementalDmg As Long
    Dim lColdElementalDmg As Long
    Dim lArmourAbsorbtionChance As Long
    Dim lGoldDropChance As Long
    Dim lHoldGold As Long
    Dim lMGold As Long
    Dim zGoldMsg As String
    Dim lGold As Long
    Dim lGoldMiserDropChance As Long
    Dim bMUndead As Boolean
    Dim bMBittenMaster As Boolean
    Dim bDay As Boolean
    Dim lMobKills As Long
    Dim lTurnedIntoAnimalType As Long
    Dim lMForceInterrupt As Long
    Dim lSneakingMovesLeft As Long
    Dim bStatusBM As Boolean
    Dim lManashieldDuration As Long
    Dim lPFactionID As Long
    Dim lAFactionID As Long
    Dim lStatusMounted As Long
    
    bDay = bWhenIsIt("", False)
    
    lFireElementalDmg = 0
    lLightningElementalDmg = 0
    lPoisonElementalDmg = 0
    lColdElementalDmg = 0
    lStoreMobReducationTotalDmg = 0
    lMobReducationTotalDmg = 0
    lLeechingHP = 0
    lLeechingEssence = 0
    lLeechingSoul = 0
    lLeechingMana = 0
    lLeechingMove = 0
    lTotalBerserkDmg = 0
    lBackStabTotalDamage = 0
    lCountOfPlayerFactionsInArea = 0
    lTMove = 0
    bBounty = False

    lPlayerID = 0
    bAllowFullBattleText = False
    bSlayChance = False: lMLevelSlayChance = 2
    
    lStatusMounted = 0
    
    'Get player data
    Set rsPlayer = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PlayerID=" & rPCombat(lPortID).lID & " AND Len(PortID)>1);", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        lManashieldDuration = MyCLng(rsPlayer!ManashieldDuration)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        bStatusBM = gblbFilterMode(lPortID)
        If (Len(MyCStr(rsPlayer!Config)) > 1) Then
            'if this is true we allow the player to see full battle text
            bAllowFullBattleText = (Mid(MyCStr(rsPlayer!Config), 2, 1) = "1")  'if cell 2 is set to 0 then we want to use the simple combat battle text
        End If
        bVerbose = (Not bStatusBM) 'bVerbose True shows everything
        lFlyDuration = MyCInt(rsPlayer!FlyDuration)
        
        zClass = MyCStr(rsPlayer!Class)
        zRace = MyCStr(rsPlayer!Race)
        
        lGoldMiserDropChance = lReturnTranslateGoldMiserRaceClass(zRace, zClass)
        lGoldDropChance = gbllGoldDropChance(lPortID)
        lShadowCloakDuration = MyCLng(rsPlayer!ShadowCloakDuration)
        zPortID = MyCStr(rsPlayer!PortID)
        lPX = MyCLng(rsPlayer!x)
        lPY = MyCLng(rsPlayer!y)
        lPZ = MyCLng(rsPlayer!z)
        
        lPFactionID = MyCLng(rsPlayer!FactionedWith)
        If (lPlayerLevel < cstFACTIONSAFEPlayerLevel) Then
            lCountOfPlayerFactionsInArea = 0 'no penality
        Else
            lAFactionID = lReturnAreaFaction(lPX, lPY, lPZ)
            If (lAFactionID = lPFactionID) Then
                lCountOfPlayerFactionsInArea = 1
            Else
                lCountOfPlayerFactionsInArea = -1 'error, lReturnCountOfPlayerFactions2x2(lPFactionID)
            End If
        End If
        
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        
        lQuestMobID = MyCLng(rsPlayer!QuestMobID)
        iStatus = MyCInt(rsPlayer!Status)

        If (iStatus <> 0) Then
            gbllFishing(lPortID) = 0 'fishing gets cancelled
            If (bAllowFullBattleText) Then
            Select Case (lFlyDuration > 0 Or zClass = "VA" Or zRace = "PIX")
                Case True
                    If bVerbose Then subSendMsg "&R<<You hover into the air and prepare to Attack>>", zPortID
                    If bVerbose Then subSendMsgAreaExcept2 "&R<<" & zPlayerName & " hovers to Attack>>", lPX, lPY, lPZ, zPortID, ""
                Case Else
                    If bVerbose Then subSendMsg "&R<<You slide low into a Battle Stance>>", zPortID
                    If bVerbose Then subSendMsgAreaExcept2 "&R<<" & zPlayerName & " takes a Battle Stance>>", lPX, lPY, lPZ, zPortID, ""
            End Select
            End If
            MyDB.Execute "UPDATE tblPlayer SET Status = 0, SitObjectID = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
        End If
        
        'Get the players weapon names
        zPlayerWeapon(1) = ""
        zPlayerWeapon(2) = ""
        lPlayerWeaponCount = 0
        Set rsPlayerWeapons = MyDB.OpenRecordset("SELECT tblPlayerEquipmentItems.PlayerID, tblPlayerEquipmentItems.Location, tblObject.ObjectName, tblObject.WeaponType, tblObject.CriticalHR, tblObject.CriticalHRChance, tblObject.CriticalDR, tblObject.CriticalDRChance, tblObject.CriticalBlindChance, tblObject.IndestructibleMobLv, tblObject.CHITROLL, tblObject.AverageDamage FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerEquipmentItems.Location)=20) AND ((tblObject.WeaponType)<>'' And (tblObject.WeaponType) Is Not Null));", dbOpenSnapshot) 'destiny weapons and weapontype weapons count as weapons only - this way a player can forcus on a weapon and hold a shield
        Do While (Not rsPlayerWeapons.EOF And lPlayerWeaponCount < 2)
            lPlayerWeaponCount = lPlayerWeaponCount + 1
            If (lShadowCloakDuration <> 0) Then
                Select Case lRandom(5)
                    Case 1
                        zPlayerWeapon(lPlayerWeaponCount) = "++cloaked weapon of shadows++"
                    Case 2
                        zPlayerWeapon(lPlayerWeaponCount) = "++flowing shadow weapon++"
                    Case 3
                        zPlayerWeapon(lPlayerWeaponCount) = "++concealed weapon wrapped in shadows++"
                    Case 4
                        zPlayerWeapon(lPlayerWeaponCount) = "++darkforce of shadows++"
                    Case 5
                        zPlayerWeapon(lPlayerWeaponCount) = "++power of shadows++"
                End Select
            Else
                zObjectName = MyCStr(rsPlayerWeapons!ObjectName)
                zPlayerWeapon(lPlayerWeaponCount) = zAdverb(zObjectName, 2) & zShortstop(zObjectName)
            End If
            'Well the below isnt used too much but I tossed in here in case anyone of you wanted to make my dream player vs mob where each hand is completely seperate :)
            zPlayerWeaponType(lPlayerWeaponCount) = MyCStr(rsPlayerWeapons!WeaponType)
            lWeaponHR(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!CHITROLL)
            lWeaponDR(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!AverageDamage)
            lCriticalHR(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!CriticalHR)
            lCriticalHRChance(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!CriticalHRChance)
            lCriticalDR(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!CriticalDR)
            lCriticalDRChance(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!CriticalDRChance)
            lCriticalBlindChance(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!CriticalBlindChance)
            lIndestructibleMobLv(lPlayerWeaponCount) = MyCLng(rsPlayerWeapons!IndestructibleMobLv)
            rsPlayerWeapons.MoveNext
        Loop
        Set rsPlayerWeapons = Nothing
        'Load information
        lAlignment = MyCLng(rsPlayer!Alignment)
        lXP = MyCLng(rsPlayer!XP)
        lGold = MyCLng(rsPlayer!Gold)
        lHoldGold = 0
        lMobKills = MyCLng(rsPlayer!MobKills)
        lSlayKills = MyCLng(rsPlayer!SlayKills)
        lMartialArtsKungPowLevel = MyCLng(rsPlayer!MartialArtsKungPowLevel)
        lMartialArtsLungingElbowsLevel = MyCLng(rsPlayer!MartialArtsLungingElbowsLevel)
        lMartialArtsTigerFistsLevel = MyCLng(rsPlayer!MartialArtsTigerFistsLevel)
        lMartialArtsTuskPunchLevel = MyCLng(rsPlayer!MartialArtsTuskPunchLevel)
        lMartialArtsKungPowXP = MyCLng(rsPlayer!MartialArtsKungPowXP)
        lMartialArtsLungingElbowsXP = MyCLng(rsPlayer!MartialArtsLungingElbowsXP)
        lMartialArtsTigerFistsXP = MyCLng(rsPlayer!MartialArtsTigerFistsXP)
        lMartialArtsTuskPunchXP = MyCLng(rsPlayer!MartialArtsTuskPunchXP)
        
        lMagicFind = MyCLng(rsPlayer!MagicFind)
        lMagicFindBase = MyCLng(rsPlayer!MagicFindBase)
        
        lStatusMounted = MyCLng(rsPlayer!StatusMounted)
        lBeserkDuration = MyCLng(rsPlayer!BeserkDuration)
        If (zRace = "ELF" Or zClass = "PA" Or zClass = "CL") Then 'special classes get berserk when mounted
            If lStatusMounted <> 0 Then lBeserkDuration = 1
        End If
        lPowerKickDuration = MyCLng(rsPlayer!PowerKickDuration)
        lClawHandDuration = MyCLng(rsPlayer!ClawHandDuration)
        lKnifeHandDuration = MyCLng(rsPlayer!KnifeHandDuration)
        If (zClass = "AS") Then
            lPowerKickDuration = 1
            lClawHandDuration = 1
            lKnifeHandDuration = 1
        End If
        lDragonUppercutDuration = MyCLng(rsPlayer!DragonUppercutDuration)
        If (zRace = "DRA") Then lDragonUppercutDuration = 1
        lHurricaneKickDuration = MyCLng(rsPlayer!HurricaneKickDuration)
        lDoublePunchDuration = MyCLng(rsPlayer!DoublePunchDuration)
        lDropKickDuration = MyCLng(rsPlayer!DropKickDuration)
        lHeadButtDuration = MyCLng(rsPlayer!HeadButtDuration)
        lElbowDuration = MyCLng(rsPlayer!ElbowDuration)
        lKneeDuration = MyCLng(rsPlayer!KneeDuration)
        lStatus = MyCLng(rsPlayer!Status)
        zBittenReservedOriginalClass = MyCStr(rsPlayer!BittenReservedOriginalClass)
        lWhereID = MyCLng(rsPlayer!WhereID)
        
        'load stats
        lCAC = MyCLng(rsPlayer!CAC)
        If (Not bDay) Then 'When night time
            If (gbllMoon < 4) Then
                Select Case zRace
                    Case "UND"
                        lCAC = lCAC + 300
                End Select
            End If
            If (gbllMoon = 3) Then
                Select Case zClass 'when full moon only
                    Case "VA"
                        lCAC = lCAC + 1200
                    Case "WE"
                        lCAC = lCAC + 1500
                End Select
            End If
            If (gbllMoon = 3 Or gbllMoon = 4 Or gbllMoon = 5) Then
                Select Case zRace
                    Case "DRA"
                        lCAC = lCAC + 3000
                End Select
            End If
            If (gbllMoon < 0 Or gbllMoon = 4 Or gbllMoon = 5) Then
                Select Case zRace
                    Case "ORC"
                        lCAC = lCAC + 1000
                    Case "TRO"
                        lCAC = lCAC + 2000
                    Case "OGR"
                        lCAC = lCAC + 1500
                End Select
            End If
        Else
            Select Case zClass 'when day time
                Case "VA"
                    lCAC = lCAC - MyCLng(lCAC / (3 + lRandom(3)))
                Case "WE"
                    lCAC = lCAC - MyCLng(lCAC / (5 + lRandom(3)))
            End Select
        End If
        If (lCAC < 10) Then lCAC = 10
        
        lCHP = MyCLng(rsPlayer!CHP)
        lOHP = MyCLng(rsPlayer!OHP)
        lCMana = MyCLng(rsPlayer!CMana)
        lOMANA = MyCLng(rsPlayer!OMANA)
        lCEssence = MyCLng(rsPlayer!CEssence)
        lOEssence = MyCLng(rsPlayer!OEssence)
        lCSoul = MyCLng(rsPlayer!CSoul)
        lOSoul = MyCLng(rsPlayer!OSoul)
        'hr dr is dependant on move
        lCMove = MyCLng(rsPlayer!CMove)
        lOMove = MyCLng(rsPlayer!OMove)
        lCDAMROLL = MyCLng(MyCLng(rsPlayer!CDAMROLL) * (lCMove / lOMove)) 'move is very important to the value of dr and hr
        lCHITROLL = MyCLng(MyCLng(rsPlayer!CHITROLL) * (lCMove / lOMove))
        lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
        'end hr dr is dependant on move
        lCStr = MyCLng(rsPlayer!CStr)
        lCINT = MyCLng(rsPlayer!CInt)
        lCWIS = MyCLng(rsPlayer!CWIS)
        lCDEX = MyCLng(rsPlayer!CDEX)
        lCCon = MyCLng(rsPlayer!CCon)
        lCCHA = MyCLng(rsPlayer!CCHA)
        lCLuc = MyCLng(rsPlayer!CLuc)
        'end load stats
        
        lPlayerTotalStats = lCStr + lCINT + lCWIS + lCDEX + lCCon + lCCHA + lCLuc + lPlayerLevel
        
        lNumAttRndMax = MyCLng(rsPlayer!NumAttRnd) 'we random so there is a decent average if the player has 13 attacks a round - less lag
        lNumAttRnd = lRandom(lNumAttRndMax)
        If (lNumAttRnd < 1) Then lNumAttRnd = 1
        If (zClass = "CY") Then
            If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                If (gbllAngryVentingSystem(lPortID) < 100) Then
                    gbllAngryVentingSystem(lPortID) = gbllAngryVentingSystem(lPortID) + lRandom(lNumAttRnd)
                    If (gbllAngryVentingSystem(lPortID) > 100) Then gbllAngryVentingSystem(lPortID) = 100
                End If
            End If
        End If
        'lInertShield = MyCLng(rsPlayer!InertShield) 'Reduces physical skill damage, like sanc but for only learn combat skills
        lSanctuaryDuration = MyCLng(rsPlayer!SanctuaryDuration)
        lFireshieldDuration = MyCLng(rsPlayer!FireshieldDuration)
        lIceshieldDuration = MyCLng(rsPlayer!IceshieldDuration)
        lStaticshieldDuration = MyCLng(rsPlayer!StaticshieldDuration)
        lChaosshieldDuration = MyCLng(rsPlayer!ChaosshieldDuration)
        lLightningElementalDamage = MyCLng(rsPlayer!LightningElementalDamage)
        lColdElementalDamage = MyCLng(rsPlayer!ColdElementalDamage)
        lPoisonElementalDamage = MyCLng(rsPlayer!PoisonElementalDamage)
        lFireElementalDamage = MyCLng(rsPlayer!FireElementalDamage)
        lTotalPossibleElementalDmg = ((lLightningElementalDamage + lColdElementalDamage + lPoisonElementalDamage + lFireElementalDamage) * lNumAttRndMax)
        If (cstbMorphElementalDmgON) Then 'this is very powerful
            Select Case zClass 'we give the player an automatic elemental bonus for certain morph classes
                Case "WE"
                    lFireElementalDamage = lFireElementalDamage + (3 * MyCLng(lPlayerLevel / 2)) + lRandom(lPlayerLevel)
                Case "VA"
                    lColdElementalDamage = lColdElementalDamage + (3 * MyCLng(lPlayerLevel / 2)) + lRandom(lPlayerLevel)
                Case "PL"
                    lFireElementalDamage = lFireElementalDamage + (3 * MyCLng(lPlayerLevel / 2)) + lRandom(lPlayerLevel)
                Case "CY"
                    lLightningElementalDamage = lLightningElementalDamage + (3 * lPlayerLevel) + lRandom(lPlayerLevel)
            End Select
        End If
        lSlayChance = MyCLng(rsPlayer!SlayChance)
        If (zClass = "KN") Then 'Knights have a better chance to slay!
            lMLevelSlayChance = 4
            If (lRandom(100) < lRandom(MyCLng(lPlayerLevel / 2)) + 9) Then
                lSlayChance = lSlayChance + lRandom(50 + lPlayerLevel) + 100
                If (bAllowFullBattleText) Then
                If bVerbose Then subSendMsg "&AYou lash about the area with your -=&Ylite&Wsabre&a=-", zPortID
                End If
            End If
        End If
        lSlayChance = lRandom(lSlayChance) 'we make slay so it isnt a powerful exploit
        
        lIASChance = MyCLng(rsPlayer!IASChance)
        lWeaponSkillBackStabClassLevel = MyCLng(rsPlayer!WeaponSkillBackStabClassLevel)
        lWeaponSkillMissileRangeClassLevel = MyCLng(rsPlayer!WeaponSkillMissileRangeClassLevel)
        lStunDuration = MyCLng(rsPlayer!StunDuration)
        lBlindDuration = MyCLng(rsPlayer!BlindDuration)
        lEntanglementDuration = MyCLng(rsPlayer!EntanglementDuration)
        zEntanglementDesc = MyCStr(rsPlayer!EntanglementDesc)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
        
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        If (lInvisibilityDuration > 0) Then
            lInvisibilityDuration = 0
            If (bAllowFullBattleText) Then
            If bVerbose Then subSendMsg "&wYou fade into existence.", zPortID
            If bVerbose Then subSendMsgAreaExcept2 gblzFNWHI & zPlayerName & " fades into existence.", lPX, lPY, lPZ, zPortID, ""
            End If
            MyDB.Execute "UPDATE tblPlayer SET InvisibilityDuration = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
        End If
        
        lCamoflaguedDuration = MyCLng(rsPlayer!CamoflaguedDuration)
        If (lCamoflaguedDuration > 0) Then
            lCamoflaguedDuration = 0
            If (bAllowFullBattleText) Then
            If bVerbose Then subSendMsg "&wYou break your camouflage.", zPortID
            If bVerbose Then subSendMsgAreaExcept2 gblzFNWHI & zPlayerName & " breaks out of camouflage mode.", lPX, lPY, lPZ, zPortID, ""
            End If
            MyDB.Execute "UPDATE tblPlayer SET CamoflaguedDuration = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
        End If
                
        lSneakingMovesLeft = MyCLng(rsPlayer!SneakingMovesLeft)
        If (lSneakingMovesLeft > 0) Then
            lSneakingMovesLeft = 0
            If (bAllowFullBattleText) Then
            If bVerbose Then subSendMsg "&wYou break your sneaking.", zPortID
            If bVerbose Then subSendMsgAreaExcept2 gblzFNWHI & zPlayerName & " breaks out of sneak mode.", lPX, lPY, lPZ, zPortID, ""
            End If
            MyDB.Execute "UPDATE tblPlayer SET SneakingMovesLeft = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
        End If
        
        lHideDuration = MyCLng(rsPlayer!HideDuration)
        If (lHideDuration > 0) Then
            lHideDuration = 0
            If (bAllowFullBattleText) Then
            If bVerbose Then subSendMsg "&wYou come out of hiding!", zPortID
            If bVerbose Then subSendMsgAreaExcept2 gblzFNWHI & zPlayerName & " breaks out of hiding.", lPX, lPY, lPZ, zPortID, ""
            End If
            MyDB.Execute "UPDATE tblPlayer SET HideDuration = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
        End If
        
        bBlindFight = (MyCInt(rsPlayer!BlindFight) <> 0)
        bStunFight = (MyCInt(rsPlayer!StunFight) <> 0)
        
        lMoveReductionInertialInhibitor = MyCLng(rsPlayer!MoveReductionInertialInhibitor)
        Select Case lIASChance
            Case 0 To 49
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 5
            Case 50 To 99
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 8
            Case 100 To 199
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 11
            Case 200 To 325
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 14
            Case Else
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 20
        End Select
        Select Case lCCHA
            Case 0 To 99
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 1
            Case Else
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 5
        End Select
        Select Case lCDEX
            Case 1 To 50
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 2
            Case 51 To 125
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 2
            Case Else
                lMoveReductionInertialInhibitor = lMoveReductionInertialInhibitor + 8
        End Select
        
        lMoveCostIIAdditional = 0
        If (gblbRealmAdditionalMoveCosts) Then
            If (lPlayerLevel > 49) Then
                If (MyCLng(rsPlayer!PandemicDuration) > 0) Then
                    lMoveCostIIAdditional = (MyCLng(rsPlayer!PandemicLevel) * 3) + MyCLng(MyCLng(rsPlayer!PandemicDuration) / 4)
                End If
            End If
        End If
 
        lLeechingHP = MyCLng(rsPlayer!LeechingHP)
        lLeechingEssence = MyCLng(rsPlayer!LeechingEssence)
        lLeechingSoul = MyCLng(rsPlayer!LeechingSoul)
        lLeechingMana = MyCLng(rsPlayer!LeechingMana)
        lLeechingMove = MyCLng(rsPlayer!LeechingMove)
        
        If (lTurnedIntoAnimalType > 0) Then 'all morphs are weak
            lCDAMROLL = 10 * lTurnedIntoAnimalType
            lCHITROLL = 15 * lTurnedIntoAnimalType
            lCAC = 10 * lTurnedIntoAnimalType
            lCStr = lTurnedIntoAnimalType
            lCINT = lTurnedIntoAnimalType
            lCWIS = lTurnedIntoAnimalType
            lCDEX = lTurnedIntoAnimalType
            lCCon = lTurnedIntoAnimalType
            lCCHA = lTurnedIntoAnimalType
            lCLuc = lTurnedIntoAnimalType
        End If
        
        bNewbie = (bNewbieArea(lPlayerLevel, lWhereID)) Or (gblConstructorlMode = 2)
    End If
    Set rsPlayer = Nothing
    
    If (lCountOfPlayerFactionsInArea > -1) Then  'everything loaded for the player?
        If (lPlayerLevel > 19) Then
            If (gbllQuestGuardFailCount(lPortID) >= cstlQuestGuardFailCountMAX) Then
                If (MyCLng(lPlayerLevel / 8) + lRandom(lCDEX) + lRandom(lReturnTranslateCharismaticBonus(zRace, zClass)) + lRandom(lCCHA * 3) + lRandom(lPlayerLevel) <= (gbllQuestGuardFailCount(lPortID) * 2) + lRandom(75) + lRandom(50) + lRandom((5 + cstlQuestGuardFailCountMAX) * (lRandom(gbllQuestGuardFailCount(lPortID) - (cstlQuestGuardFailCountMAX - 1))))) Then
                    'NOT DOING YOUR GUARDING?! ANTI-BOT
                    'EntanglementDesc 'EntanglementDuration
                    lCAC = 1
                    lCStr = 1
                    lCCon = 1
                    If (bAllowFullBattleText) Then
                    If lRandom(9) = 1 Then subSendMsg "&RATTENTION! SLEEPY GUARD! Your NEKKED, go guard! DREAM!", zPortID
                    If lRandom(9) = 1 Then subSendMsg "&RATTENTION! SLEEPY GUARD! Move out! type DREAM, PAGE QUEST and MAP!", zPortID
                    End If
                    If (lRandom(99) = 1) Then
                        gbllQuestGuardFailCount(lPortID) = lRandom(gbllQuestGuardFailCount(lPortID))
                        If (bAllowFullBattleText) Then
                        If lRandom(3) = 1 Then subSendMsg "&RATTENTION! SLEEPY GUARD! Your penality was reduced if you do your guarding! type PAGE QUEST and MAP!", zPortID '
                        End If
                    Else
                        If (lRandom(50) = 1) Then subSendMsg "&RATTENTION! SLEEPY GUARD! Please use your MAP and why not type PAGE QUEST, and guard the realm soldier! Take down whatever gets in your way!", zPortID
                    End If
                End If
            End If
        End If 'pl>19
        bEndCombat = False
        'Get mob battle data
        lMobID = 0
        Set rsMob = MyDB.OpenRecordset("SELECT NeverAttackable, Gold, ImmunitySlayLevel, AntiMoveDuration, StunDuration, ForceInterrupt, InitativeChance, BittenMaster, Undead, X, Y, Z, NumAttRnd, WimpyHP, WimpyChance, HerdMobID, ResPhysicalDamage, MoveCostInertialInhibitor, SanctuaryChance, SanctuaryDamageReduction, SanctuaryDuration, MHPBonus, MACBonus, ResLightningElementalDamage, ResColdElementalDamage, ResFireElementalDamage, MoveAllowed, SpecialGloryPlayerAmt, SpecialSelfDeleting, DefeatedMobDesc, ShockshieldDuration, MobID, Invisible, MobName, Alignment, MHP, MobLevel, MAC, CHITROLLBase, CDAMROLLBase, EntanglementDuration FROM tblMob WHERE (MobID=" & rMCombat(lPortID).lID & " AND X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND RespawnDelay=0);", dbOpenSnapshot)
        If (Not rsMob.EOF) Then
            lMGold = MyCLng(rsMob!Gold)
            lNeverAttackable = MyCLng(rsMob!NeverAttackable)
            lImmunitySlayLevel = MyCLng(rsMob!ImmunitySlayLevel)
            If (lSlayChance > 199) Then lSlayChance = lSlayChance - lImmunitySlayLevel
            
            lMForceInterrupt = MyCLng(rsMob!ForceInterrupt) 'we force interrupt the player just before the turn begins lol
            bMBittenMaster = (MyCInt(rsMob!BittenMaster) <> 0)
            bMUndead = (MyCInt(rsMob!Undead) <> 0)
            zMobName = MyCStr(rsMob!MobName)
            zMobName = zAdverb(zMobName, 2) & zShortstop(zMobName)
            'zUMobName = UCase(zMobName)
            lMobID = MyCLng(rsMob!MobID)
            lMLevel = MyCLng(rsMob!MobLevel)
            lMInitativeChance = MyCLng(rsMob!InitativeChance)
            lMAntiMoveDuration = MyCLng(rsMob!AntiMoveDuration)
            lMStunDuration = MyCLng(rsMob!StunDuration)
            If (lMInitativeChance < 0) Then lMInitativeChance = 0
            lMHP = MyCLng(rsMob!MHP)
            lMHPBonus = MyCLng(rsMob!MHPBonus) 'this is added to the MHP when the mob respawns not here
            lMACBonus = MyCLng(rsMob!MACBonus)
            lMMaxXPValue = (lMHPBonus) + (lMLevel * cstMobHPRespawn)
            lMHerdMobID = MyCLng(rsMob!HerdMobID)
            lMEntanglementDuration = MyCLng(rsMob!EntanglementDuration)
            lMX = MyCLng(rsMob!x)
            lMY = MyCLng(rsMob!y)
            lMZ = MyCLng(rsMob!z)
            lMWimpyHP = MyCLng(rsMob!WimpyHP)
            lMWimpyChance = MyCLng(rsMob!WimpyChance)
            
            lMSanctuaryChance = MyCLng(rsMob!SanctuaryChance)
            lMSanctuaryDamageReduction = MyCLng(rsMob!SanctuaryDamageReduction)
            If (lMSanctuaryDamageReduction > 0 And lMSanctuaryDamageReduction < 10) Then lMSanctuaryDamageReduction = 10
            lMSanctuaryDuration = MyCLng(rsMob!SanctuaryDuration)
            
            lMCHITROLL = MyCLng(rsMob!CHITROLLBase)
            lMCDAMROLL = MyCLng(rsMob!CDAMROLLBase)
            lMResPhysicalDamage = MyCLng(rsMob!ResPhysicalDamage)
            lMResLightningElementalDamage = MyCLng(rsMob!ResLightningElementalDamage)
            lMResColdElementalDamage = MyCLng(rsMob!ResColdElementalDamage)
            lMResFireElementalDamage = MyCLng(rsMob!ResFireElementalDamage)
            
            lMAC = MyCLng(rsMob!Mac)
            If (bMUndead) Then
                lMResPhysicalDamage = 75
                If (Not bDay) Then
                    If (gbllMoon = 3) Then  'fullmoon or bitten masters get ac bonus at night
                        lMAC = lMAC * 3
                    Else
                        lMAC = lMAC * 2
                    End If
                End If
            End If
            
            If (bMBittenMaster) Then lMAC = (lMAC * 5) + 2000
            lMAC = lMAC + lMACBonus
            
            If (lPlayerLevel > 19) Then 'The Skull Moon will not affect the new players
                'NOTE: we let poison dmg do pure dmg - poison cuts though armours
                If (gbllMoon = -5) Then 'makes mobs very hard to hit during a "skull moon"
                    lMResPhysicalDamage = lRandom(40) + 50 'the skull moon makes the mobs of the realm phase shift
                    lMResLightningElementalDamage = lRandom(40) + 50
                    lMResColdElementalDamage = lRandom(40) + 50
                    lMResFireElementalDamage = lRandom(40) + 50
                    lMAC = lMAC * 50
                    lMCHITROLL = lMCHITROLL * 5
                    lMCDAMROLL = lMCDAMROLL * 3
                End If
            End If
            
            lMAlignment = MyCLng(rsMob!Alignment)
            bMobInvisible = (MyCLng(rsMob!Invisible) > 0)
            lMShockshieldDuration = MyCLng(rsMob!ShockshieldDuration)
            zMDefeatedMobDesc = MyCStr(rsMob!DefeatedMobDesc)
            bMSpecialSelfDeleting = (MyCInt(rsMob!SpecialSelfDeleting) <> 0)
            lMSpecialGloryPlayerAmt = MyCLng(rsMob!SpecialGloryPlayerAmt) 'glory mob!!
            lMMoveAllowed = MyCLng(rsMob!MoveAllowed) 'more XP chance for learn points and a very very low chance for a glory
            
            bBounty = (Len(MyCStr(rsMob!DefeatedMobDesc)) > 0)
            
            lMoveCostInertialInhibitor = MyCLng(rsMob!MoveCostInertialInhibitor) + MyCLng(lMLevel / 8) + lMoveCostIIAdditional
            If (lMoveCostInertialInhibitor < 1) Then lMoveCostInertialInhibitor = 1 'this is the min move cost
            If (lMoveCostInertialInhibitor > 999) Then lMoveCostInertialInhibitor = 999
            
            lMNumAttRnd = MyCLng(rsMob!NumAttRnd)
            If (lMNumAttRnd < 1) Then lMNumAttRnd = 1
            
            'Quest mobs are a little harder
            If (lQuestMobID = lMobID) Then
                If (lPlayerLevel > 49) Then
                    If (lMNumAttRnd < 3) Then lMNumAttRnd = lMNumAttRnd + 1 'give the mob a fighting chance
                    lMAC = lMAC + lRandom(lMAC) 'a chance to double its armour class
                End If
                lQuestXPBonus = (lMNumAttRnd * lMLevel) * 5
            Else
                lQuestXPBonus = 0
            End If
            
            'We are fighting in the same area as our faction - some lag to get the areafaction id
            'If (lPFactionID = lAFactionID) Then
            '    lFactionXPBonus = (lMNumAttRnd * lMLevel) + 20
            'Else
            '    lFactionXPBonus = 0
            'End If
            
            'all mobs can eventually try to flee even if the mud doesn't have it set
            If (lMLevel > 49) Then
                If (lMWimpyChance = 0) Then
                    If (lRandom(4) = 1) Then
                        lMWimpyHP = lRandom(lMHP)
                        lMWimpyChance = lRandom(70) + 30
                    End If
                End If
            End If
        End If
        Set rsMob = Nothing
        
        If (lMobID <> 0) Then 'mob loaded okay?
        If (lNeverAttackable = 0) Then
            'Newbie in a newbie area?
            If (bNewbie) Then 'we make it so the newbie cant really die
                lCHITROLL = lCHITROLL + 100
                lCDAMROLL = lCDAMROLL + 100
                lMCHITROLL = 10
                lMCDAMROLL = 10
                lMAC = 10
            End If
            
            'We now reduce the values
            If (lStunDuration > 0 Or lBlindDuration > 0 Or bMobInvisible Or lEntanglementDuration > 0) Then
                If (bMobInvisible) Then
                    If (lDetectInvisibilityDuration = 0) Then
                        lCHITROLL = lCHITROLL / 4
                        lCDAMROLL = lCDAMROLL / 2
                    End If
                End If
                
                If (lStunDuration > 0) Then
                    If (Not bStunFight) Then
                        lCHITROLL = lCHITROLL - (lCHITROLL / 2)
                        lCDAMROLL = lCDAMROLL - (lCDAMROLL / 3)
                    Else
                        lCHITROLL = lCHITROLL - (lCDAMROLL / 4)
                        lCDAMROLL = lCDAMROLL - (lCDAMROLL / 5)
                    End If
                End If
                
                If (lBlindDuration > 0) Then
                    If (Not bBlindFight) Then
                        lCHITROLL = MyCLng(lCHITROLL - (lCHITROLL / 3))
                        lCDAMROLL = MyCLng(lCDAMROLL - (lCDAMROLL / 4))
                    Else
                        lCHITROLL = MyCLng(lCHITROLL - (lCHITROLL / 5))
                        lCDAMROLL = MyCLng(lCDAMROLL - (lCDAMROLL / 6))
                    End If
                End If
                
                If (lEntanglementDuration > 0) Then
                    lCHITROLL = lCHITROLL - (lCHITROLL / 10)
                    lCDAMROLL = lCDAMROLL - (lCDAMROLL / 10)
                    lTMove = lTMove + (lRandom(lMLevel) + lRandom(lMLevel))
                End If
                
                If (lStunDuration > 0 And lBlindDuration > 0) Then 'group if both
                    lTMove = lTMove + (lRandom(lMLevel) / 2)
                Else
                    If (lStunDuration > 0) Then
                        lTMove = lTMove + (lRandom(lMLevel / 3))
                    End If
                    
                    If (lBlindDuration > 0) Then
                        lTMove = lTMove + (lRandom(lMLevel / 3))
                    End If
                End If
                
                If (lCHITROLL < 10) Then lCHITROLL = 10
                If (lCDAMROLL < 10) Then lCDAMROLL = 10
            End If
            
            bMobDied = False
            
            'calculate move reduction
            lMoveCostInertialInhibitor = lMoveCostInertialInhibitor - lMoveReductionInertialInhibitor
            If (lMoveCostInertialInhibitor < 1) Then lMoveCostInertialInhibitor = 1
            If (lPlayerLevel < 20) Then lMoveCostInertialInhibitor = 0
            
            'Init. Variables
            lDamage = 0
            lTotalDamage = 0
            lCalcuBonusDmg = 0 'now we let this possible accelerate in damage depending on the next loop of dmg
            lElementalHits = 0
            lElementalDmg = 0
            lMobWeaponHit = 0
            
            lWeaponDamage(1) = 0
            lWeaponDamage(2) = 0
            zBattleText = ""
            lLearnSkillsHit = 0
            lCalcuLeechingHP = 0
            lCalcuLeechingMana = 0
            lCalcuLeechingEssence = 0
            lCalcuLeechingSoul = 0
            lCalcuLeechingMove = 0
            bBarehandedNoMartialArts = False
            bBarehandedWithMartialArts = False
            zCriticalText(1) = ""
            zCriticalText(2) = ""

            '-----------------------------------------------------------------------------
            'Weapons Battle
            lWeaponBlind(1) = 0: lWeaponBlind(2) = 0
            lGainXP = 0
            bIAS = False
            bWeaponCellHit(1) = False: bWeaponCellHit(2) = False
            lWearSkillsHit = 0: lWearSkillsTotalDmg = 0
            lRollIC = ((lMInitativeChance) - lRandom(lTranslateInitiativeBonus(zClass, zRace, "B")))
            If (lPortID >= cstlMinPort And lPortID <= cstlMaxPort) Then
                lRollIC = (lRollIC - lRandom(gbllInitativeChance(lPortID)))
            End If
            If (lRollIC < 0) Then lRollIC = 0
            
            lHitThisRound = 0
            lNumAttRndCount = 0
            lHoldDamage = 0
            
            If (lRandom(lRollIC) < lRandom(100)) Then 'if what is left over for the mob beats the random100 then the player skips their turn
            If (lRandom(lMForceInterrupt) > lRandom(100)) Then subForceInterrupt lIASChance, zPortID, "", 1
            
            Do While (lNumAttRndCount < lNumAttRnd And Not bMobDied)
                lHitThisRound = 0
                lNumAttRndCount = lNumAttRndCount + 1
                lHoldDamage = 0
                lCriticalHRCount = 0
                lCriticalHRTotal = 0
                lCriticalDRCount = 0
                lCriticalDRTotal = 0
                
                Select Case (lNumAttRndCount) 'on first attack there is a chance pets will fight
                    Case 1 'learn skills and pets
                        If (lRandom(lCCHA) < lRandom(40)) Then subCombatWorldVsPets lPlayerID, 1, zPlayerName, zMobName, lMLevel, lPX, lPY, lPZ, zClass, zRace, lFlyDuration, bVerbose, bAllowFullBattleText, zPortID, ""  'pets get attacked
                        If (lRandom(lCCHA) > lRandom(5)) Then lPetDamage = lCombatPetsVsWorld(lPlayerID, lCCHA, zClass, 1, zPlayerName, zMobName, lMLevel, lPX, lPY, lPZ, bVerbose, bAllowFullBattleText, zPortID) 'pets attack
                        'if (bAllowFullBattleText) then
                        lDamage = lDamage + lPetDamage
                        'Player learn skill damage
                        If (lRandom(lTranslateClassLearnPointPercentChance(zClass)) > lRandom(100)) Then 'just to see if there is a chance to use any of them
                            Set rsLearn = MyDB.OpenRecordset("SELECT LearnName, LearnDamage, LearnPercent FROM tblPlayerLearn WHERE (ActivateCommand=0 AND LearnDamage>0 AND TargetID=" & lPlayerID & " AND LearnStatus=2) ORDER BY LearnName;", dbOpenDynaset)
                            If (Not rsLearn.EOF) Then
                                Do While (Not rsLearn.EOF)
                                    lLearnPercent = MyCLng(rsLearn!LearnPercent)
                                    If (lRandom(lLearnPercent) > (lRandom(50 + lMLevel))) Then
                                        lLearnSkillsHit = lLearnSkillsHit + 1
                                        'zBattleText = zBattleText & MyCStr(rsLearn!LearnName) & "(" & MyCLng(rsLearn!LearnDamage) + lPlayerLevel & ") "
                                        lDamage = lDamage + MyCLng(rsLearn!LearnDamage) + lPlayerLevel
                                        'Bonus XP for using a skill
                                        If (lLearnPercent < 50 + lTranslateLearnPointsSkill(zClass)) Then
                                            If (lRandom(lCINT + lCWIS) + lRandom(lPlayerLevel) > lRandom(200 + lMLevel)) Then
                                                lLearnSkillsLeveled = lLearnSkillsLeveled + 1
                                                rsLearn.Edit
                                                rsLearn!LearnPercent = lLearnPercent + 1
                                                rsLearn.Update
                                                lGainXP = lGainXP + (lTranslateClassLearnPointPercentChance(zClass) * 10) + 1000 + lRandom(lCCHA / 2) + (lCCHA / 2)
                                                'zLearnBonusDesc = "&w1000 experience bonus!" & vbCrLf & "You get a bonus percent from successfully using " & MyCStr(rsLearn!LearnName) & "."
                                            End If
                                        End If
                                    End If
                                    rsLearn.MoveNext
                                Loop
                            End If
                            Set rsLearn = Nothing
                        End If
                End Select

                Select Case (lPlayerWeaponCount)
                    Case 1 'One WeaponType other hand could be a shield or another type of Orb
                        lTMove = lTMove + lMoveCostInertialInhibitor
                        If (lRandom(lNumAttRndCount) < 8) Then 'single weapons are focused and hit more often
                            lCriticalHRHoldDamage = 0
                            If (lCriticalHR(1) <> 0) Then
                                If (lRandom(80 + lCriticalHRChance(1)) > lRandom(100)) Then
                                    lCriticalHRCount = lCriticalHRCount + 1
                                    lCriticalHRHoldDamage = lAvgRandom(MyCLng(lCHITROLL * (lCriticalHR(1) / 100)))
                                    lCriticalHRTotal = lCriticalHRHoldDamage
                                End If
                            End If
                            
                            lCriticalDRHoldDamage = 0
                            If (lCriticalDR(1) <> 0) Then
                                If (lRandom(80 + lCriticalDRChance(1)) > lRandom(100)) Then
                                    lCriticalDRCount = lCriticalDRCount + 1
                                    lCriticalDRHoldDamage = lAvgRandom(MyCLng(lCDAMROLL * (lCriticalDR(1) / 100)))
                                    lCriticalDRTotal = lCriticalDRHoldDamage
                                End If
                            End If
                            
                            If ((lRandom(lCHITROLL) + lCriticalHRTotal + lRandom(lCDEX / 2) + lRandom(lCLuc / 4)) > (lRandom(lMAC))) Then 'Can we hit it?
                                bWeaponCellHit(1) = True
                                lMobWeaponHit = lMobWeaponHit + 1
                                lHitThisRound = lHitThisRound + 1
                                lHoldDamage = lRandom(lCDAMROLL / 2) + lCriticalDRTotal + (lCDAMROLL / 2) + lRandom(lCStr) 'Calculate damage
                                If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                                lDamage = lDamage + lHoldDamage
                                lWeaponDamage(1) = lWeaponDamage(1) + lHoldDamage
                            End If
                            
                            zCriticalText(1) = ""
                            If (lCriticalHRHoldDamage > 0 Or lCriticalDRHoldDamage > 0) Then zCriticalText(1) = zCriticalText(1) & " c.{"
                            If (lCriticalHRHoldDamage > 0) Then zCriticalText(1) = zCriticalText(1) & "hr" & lCriticalHRHoldDamage & " "
                            If (lCriticalDRHoldDamage > 0) Then zCriticalText(1) = zCriticalText(1) & "dr" & lCriticalDRHoldDamage
                            If (lCriticalHRHoldDamage > 0 Or lCriticalDRTotal > 0) Then zCriticalText(1) = MyCStr(zCriticalText(1)) & "}"
                        End If
                    Case 2 'Dueling weapons split the hit chance and the damage
                        lTMove = lTMove + (lMoveCostInertialInhibitor * 2) 'we spit the move cost between swings
                        'Hit with first weapon
                        If (lRandom(lNumAttRndCount) < 4) Then
                            lCriticalHRHoldDamage = 0
                            If (lCriticalHR(1) <> 0) Then
                                If (lRandom(20 + lCriticalHRChance(1)) > lRandom(100)) Then
                                    lCriticalHRCount = lCriticalHRCount + 1
                                    lCriticalHRHoldDamage = lAvgRandom(MyCLng(lCHITROLL * (lCriticalHR(1) / 100)))
                                    lCriticalHRTotal = lCriticalHRHoldDamage
                                End If
                            End If
                            
                            lCriticalDRHoldDamage = 0
                            If (lCriticalDR(1) <> 0) Then
                                If (lRandom(20 + lCriticalDRChance(1)) > lRandom(100)) Then
                                    lCriticalDRCount = lCriticalDRCount + 1
                                    lCriticalDRHoldDamage = lAvgRandom(MyCLng(lCDAMROLL * (lCriticalDR(1) / 100)))
                                    lCriticalDRTotal = lCriticalDRHoldDamage
                                End If
                            End If
                            
                            zCriticalText(1) = ""
                            If (lCriticalHRHoldDamage > 0 Or lCriticalDRHoldDamage > 0) Then zCriticalText(1) = zCriticalText(1) & " c.{"
                            If (lCriticalHRHoldDamage > 0) Then zCriticalText(1) = zCriticalText(1) & "hr" & lCriticalHRHoldDamage & " "
                            If (lCriticalDRHoldDamage > 0) Then zCriticalText(1) = zCriticalText(1) & "dr" & lCriticalDRHoldDamage
                            If (lCriticalHRHoldDamage > 0 Or lCriticalDRTotal > 0) Then zCriticalText(1) = MyCStr(zCriticalText(1)) & "}"
                            
                            If (((lCHITROLL / 2) + lCriticalHRTotal + lRandom(lCHITROLL / 4) + lRandom(lCDEX * 3) + lRandom(lCLuc * 2)) > (lRandom(lMAC / 4) + lRandom(lMAC / 4) + lRandom(lMAC / 4) + lRandom(lMAC / 4))) Then  'Can we hit it?
                                bWeaponCellHit(1) = True
                                lMobWeaponHit = lMobWeaponHit + 1
                                lHitThisRound = lHitThisRound + 1
                                lHoldDamage = lRandom(lCDAMROLL / 4) + lCriticalDRTotal + lRandom(lCDAMROLL / 4) + (lCDAMROLL / 4) + lRandom(lCStr)  'Calculate damage
                                If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                                lDamage = lDamage + lHoldDamage
                                lWeaponDamage(1) = lWeaponDamage(1) + lHoldDamage
                            End If
                        End If
                        
                        If (lRandom(lNumAttRndCount) < 4) Then 'Hit with second weapon
                            lCriticalHRHoldDamage = 0
                            If (lCriticalHR(2) <> 0) Then
                                If (lRandom(20 + lCriticalHRChance(2)) > lRandom(100)) Then
                                    lCriticalHRCount = lCriticalHRCount + 1
                                    lCriticalHRHoldDamage = lAvgRandom(MyCLng(lCHITROLL * (lCriticalHR(2) / 100)))
                                    lCriticalHRTotal = lCriticalHRHoldDamage
                                End If
                            End If
                            
                            lCriticalDRHoldDamage = 0
                            If (lCriticalDR(2) <> 0) Then
                                If (lRandom(20 + lCriticalDRChance(2)) > lRandom(100)) Then
                                    lCriticalDRCount = lCriticalDRCount + 1
                                    lCriticalDRHoldDamage = lAvgRandom(MyCLng(lCDAMROLL * (lCriticalDR(2) / 100)))
                                    lCriticalDRTotal = lCriticalDRHoldDamage
                                End If
                            End If
                            
                            If (((lCHITROLL / 2) + lCriticalHRTotal + lRandom(lCHITROLL / 4) + lRandom(lCDEX * 3) + lRandom(lCLuc * 2)) > (lRandom(lMAC / 4) + lRandom(lMAC / 4) + lRandom(lMAC / 4) + lRandom(lMAC / 4))) Then   'Can we hit it?
                                bWeaponCellHit(2) = True
                                lMobWeaponHit = lMobWeaponHit + 1
                                lHitThisRound = lHitThisRound + 1
                                lHoldDamage = lRandom(lCDAMROLL / 4) + lCriticalDRTotal + lRandom(lCDAMROLL / 4) + (lCDAMROLL / 4) + lRandom(lCStr)  'Calculate damage
                                lDamage = lDamage + lHoldDamage
                                lWeaponDamage(2) = lWeaponDamage(2) + lHoldDamage
                            End If
                            
                            zCriticalText(2) = ""
                            If (lCriticalHRHoldDamage > 0 Or lCriticalDRHoldDamage > 0) Then zCriticalText(2) = zCriticalText(2) & " c.{"
                            If (lCriticalHRHoldDamage > 0) Then zCriticalText(2) = zCriticalText(2) & "hr" & lCriticalHRHoldDamage & " "
                            If (lCriticalDRHoldDamage > 0) Then zCriticalText(2) = zCriticalText(2) & "dr" & lCriticalDRHoldDamage
                            If (lCriticalHRHoldDamage > 0 Or lCriticalDRTotal > 0) Then zCriticalText(2) = MyCStr(zCriticalText(2)) & "}"
                        End If
                    Case Else 'Martial Arts: player is fighting with no weapons
                        lTMove = lTMove + (lMoveCostInertialInhibitor * 6) 'takes more to hit with hands
                        If (lRandom(lNumAttRndCount) < 8) Then
                            lMartialArtsBarehandedHRCalcu = lTranslateMartialArtsBarehandedHR(zClass, lCHITROLL, lCCHA, lCLuc, lCDEX, "R")
                            If (lMartialArtsBarehandedHRCalcu > lRandom(lMAC)) Then      'Can we hit it?
                                lMartialArtsBarehandedDRCalcu = lTranslateMartialArtsBarehandedDR(zClass, lCDAMROLL, lCCHA, lCCon, lPlayerLevel, lCStr, "R")
                                lMobWeaponHit = lMobWeaponHit + 1
                                lHitThisRound = lHitThisRound + 1
                                'Barehanded damage
                                lHoldDamage = lHoldDamage + lMartialArtsBarehandedDRCalcu 'lRandom(lCDAMROLL / 4) + (lRandom(lCStr / 2) + lRandom(lCStr / 2) + lRandom(lCCon / 8) + lRandom(lCCha)) + lRandom(lPlayerLevel * lTranslateClassPlayerLevelBarehandsBonus(zClass))
                                
                                If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage)) 'we let the bonus xp eat though the resist physical of the mob later on in the code
                                
                                Select Case zClass
                                    Case "MO", "BA", "VA", "WE"
                                        lCalcuBonusTNL = cstlMartialArts + (lPlayerLevel * 5) 'till next level
                                        
                                        'EXTRA Barehanded damage for specific classes
                                        lHoldDamage = lHoldDamage + ((lRandom(lCStr) + lRandom(lCCon)) * lTranslateClassPlayerLevelBarehandsBonus(zClass))
                                        
                                        'Now we try to add extra damage
                                        Select Case lRandom(1 + lTranslateClassMartialArtsChance(zClass))
                                            Case 1
                                                bBarehandedWithMartialArts = True
                                                lMartialArtsKungPowXP = lMartialArtsKungPowXP + 3 + lRandom(7) + lRandom(5)
                                                Select Case zClass
                                                    Case "MO"
                                                        lMartialArtsKungPowXP = lMartialArtsKungPowXP + 5 + lRandom(5)
                                                    Case "BA"
                                                        lMartialArtsKungPowXP = lMartialArtsKungPowXP + 2 + lRandom(8)
                                                    Case "VA"
                                                        lMartialArtsKungPowXP = lMartialArtsKungPowXP + 3 + lRandom(7)
                                                End Select
                                                If (lMartialArtsKungPowXP > lCalcuBonusTNL) Then
                                                    lMartialArtsKungPowXP = 0
                                                    lMartialArtsKungPowLevel = lMartialArtsKungPowLevel + 1
                                                    'zScript1p = zScript1p & vbCrLf & "&GYou gained a kung pow mantra!"
                                                End If
                                                lCalcuBonusDmg = lRandom(lCalcuBonusDmg) + (lMartialArtsKungPowLevel * 20)
                                                lHoldDamage = lHoldDamage + lCalcuBonusDmg
                                                zBattleText = zBattleText & "&aKungpow(" & lHoldDamage & ")(" & lCalcuBonusDmg & ")"
                                            Case 2
                                                bBarehandedWithMartialArts = True
                                                lMartialArtsLungingElbowsXP = lMartialArtsLungingElbowsXP + 3 + lRandom(7) + lRandom(5)
                                                Select Case zClass
                                                    Case "BA"
                                                        lMartialArtsLungingElbowsXP = lMartialArtsLungingElbowsXP + 5 + lRandom(5)
                                                    Case "MO"
                                                        lMartialArtsLungingElbowsXP = lMartialArtsLungingElbowsXP + 4 + lRandom(6)
                                                    Case "VA"
                                                        lMartialArtsLungingElbowsXP = lMartialArtsLungingElbowsXP + 2 + lRandom(8)
                                                End Select
                                                If (lMartialArtsLungingElbowsXP > lCalcuBonusTNL) Then
                                                    lMartialArtsLungingElbowsXP = 0
                                                    lMartialArtsLungingElbowsLevel = lMartialArtsLungingElbowsLevel + 1
                                                    'zScript1p = zScript1p & vbCrLf & "&GYou gained a lunging elbow mantra!"
                                                End If
                                                lCalcuBonusDmg = lRandom(lCalcuBonusDmg) + (lMartialArtsLungingElbowsLevel * 17)
                                                lHoldDamage = lHoldDamage + lCalcuBonusDmg
                                                zBattleText = zBattleText & "&aElbow(" & lHoldDamage & ")(" & lCalcuBonusDmg & ")"
                                            Case 3
                                                bBarehandedWithMartialArts = True
                                                lMartialArtsTigerFistsXP = lMartialArtsTigerFistsXP + 3 + lRandom(7) + lRandom(5)
                                                Select Case zClass
                                                    Case "MO"
                                                        lMartialArtsTigerFistsXP = lMartialArtsTigerFistsXP + 5 + lRandom(5)
                                                    Case "BA"
                                                        lMartialArtsTigerFistsXP = lMartialArtsTigerFistsXP + 2 + lRandom(8)
                                                    Case "VA"
                                                        lMartialArtsTigerFistsXP = lMartialArtsTigerFistsXP + 1 + lRandom(9)
                                                End Select
                                                If (lMartialArtsTigerFistsXP > lCalcuBonusTNL) Then
                                                    lMartialArtsTigerFistsXP = 0
                                                    lMartialArtsTigerFistsLevel = lMartialArtsTigerFistsLevel + 1
                                                    'zScript1p = zScript1p & vbCrLf & "&GYou gained a tiger fists mantra!"
                                                End If
                                                lCalcuBonusDmg = lRandom(lCalcuBonusDmg) + (lMartialArtsTigerFistsLevel * 30)
                                                lHoldDamage = lHoldDamage + lCalcuBonusDmg
                                                zBattleText = zBattleText & "&aFists(" & lHoldDamage & ")(" & lCalcuBonusDmg & ")"
                                            Case 4
                                                bBarehandedWithMartialArts = True
                                                lMartialArtsTuskPunchXP = lMartialArtsTuskPunchXP + 3 + lRandom(7) + lRandom(5)
                                                Select Case zClass
                                                    Case "BA"
                                                        lMartialArtsTuskPunchXP = lMartialArtsTuskPunchXP + 3 + lRandom(7)
                                                    Case "MO"
                                                        lMartialArtsTuskPunchXP = lMartialArtsTuskPunchXP + 5 + lRandom(5)
                                                    Case "VA"
                                                        lMartialArtsTuskPunchXP = lMartialArtsTuskPunchXP + 6 + lRandom(4)
                                                End Select
                                                If (lMartialArtsTuskPunchXP > lCalcuBonusTNL) Then
                                                    lMartialArtsTuskPunchXP = 0
                                                    lMartialArtsTuskPunchLevel = lMartialArtsTuskPunchLevel + 1
                                                    'zScript1p = zScript1p & vbCrLf & "&GYou gained a tusk-knuckle punch mantra!"
                                                End If
                                                lCalcuBonusDmg = lRandom(lCalcuBonusDmg) + (lMartialArtsTuskPunchLevel * 25)
                                                lHoldDamage = lHoldDamage + lCalcuBonusDmg
                                                zBattleText = zBattleText & "&aTusk(" & lHoldDamage & ")(" & lCalcuBonusDmg & ")"
                                            Case Else
                                                bBarehandedNoMartialArts = True
                                                If (lShadowCloakDuration <> 0) Then
                                                    zBattleText = zBattleText & "&aShadowboxing(" & lHoldDamage & ")" ', class boxer level " & lTranslateClassHitRollBarehandsBonus(zClass) + lTranslateClassHitRoll(zClass, zRace) + lTranslateClassPlayerLevelBarehandsBonus(zBittenReservedOriginalClass)
                                                Else
                                                    zBattleText = zBattleText & "&aBarehanded(" & lHoldDamage & ")" ', class boxer level " & lTranslateClassHitRollBarehandsBonus(zClass) + lTranslateClassHitRoll(zClass, zRace) + lTranslateClassPlayerLevelBarehandsBonus(zBittenReservedOriginalClass)
                                                End If
                                        End Select
                                    Case Else
                                        bBarehandedNoMartialArts = True
                                        If (lShadowCloakDuration <> 0) Then
                                            zBattleText = zBattleText & "&aShadowboxing(" & lHoldDamage & ")" ', class boxer level " & lTranslateClassHitRollBarehandsBonus(zClass) + lTranslateClassHitRoll(zClass, zRace) + lTranslateClassPlayerLevelBarehandsBonus(zBittenReservedOriginalClass)
                                        Else
                                            zBattleText = zBattleText & "&aBarehanded(" & lHoldDamage & ")" ', class boxer level " & lTranslateClassHitRollBarehandsBonus(zClass) + lTranslateClassHitRoll(zClass, zRace) + lTranslateClassPlayerLevelBarehandsBonus(zBittenReservedOriginalClass)
                                        End If
                                End Select
                                lDamage = lDamage + lHoldDamage 'Calculate damage
                                lWeaponDamage(1) = lWeaponDamage(1) + lHoldDamage
                            End If
                        End If
                End Select
                
                If (lHitThisRound > 0) Then   'ANY WEAPON HIT EVEN BAREHANDS
                    'some weapons have blind on them
                    If (lRandom(lCriticalBlindChance(1) > lRandom(100))) Then
                        lWeaponBlind(1) = lWeaponBlind(1) + lRandom(4)
                    End If
                    If (lRandom(lCriticalBlindChance(2) > lRandom(100))) Then
                        lWeaponBlind(2) = lWeaponBlind(2) + lRandom(4)
                    End If
                    
                    'Elemental Damage
                    If (lRandom(lNumAttRndCount) < 4) Then
                        If (lFireElementalDamage > 0) Then
                            lElementalHits = lElementalHits + 1
                            lHoldDamage = (lElementalResistance(lFireElementalDamage, lMResFireElementalDamage) / 2) + lRandom((lElementalResistance(lFireElementalDamage, lMResFireElementalDamage) / 2))
                            lDamage = lDamage + lHoldDamage
                            lFireElementalDmg = lFireElementalDmg + lHoldDamage
                        End If
                    End If
                    If (lRandom(lNumAttRndCount) < 3) Then
                        If (lLightningElementalDamage > 0) Then
                            lElementalHits = lElementalHits + 1
                            lHoldDamage = (lElementalResistance(lLightningElementalDamage, lMResLightningElementalDamage) / 2) + lRandom((lElementalResistance(lLightningElementalDamage, lMResLightningElementalDamage) / 2))
                            lDamage = lDamage + lHoldDamage
                            lLightningElementalDmg = lLightningElementalDmg + lHoldDamage
                        End If
                    End If
                    If (lRandom(lNumAttRndCount) < 2) Then
                        If (lPoisonElementalDamage > 0) Then
                            lElementalHits = lElementalHits + 1
                            lHoldDamage = (lPoisonElementalDamage / 2) + lRandom(lPoisonElementalDamage / 2)
                            lPoisonElementalDmg = lPoisonElementalDmg + lHoldDamage
                            lDamage = lDamage + lHoldDamage
                        End If
                    End If
                    If (lRandom(lNumAttRndCount) < 4) Then
                        If (lColdElementalDamage > 0) Then
                            lElementalHits = lElementalHits + 1
                            lHoldDamage = (lElementalResistance(lColdElementalDamage, lMResColdElementalDamage) / 2) + lRandom((lElementalResistance(lColdElementalDamage, lMResColdElementalDamage) / 2))
                            lColdElementalDmg = lColdElementalDmg + lHoldDamage
                            lDamage = lDamage + lHoldDamage
                        End If
                    End If
                    'end Elemental Damage
                End If
                
                If (lRandom(lNumAttRndCount) <= lBackStabAttacksLevel(zClass)) Then 'Backstab is powerful and can hit more often
                    'Wear Skill hit chance and damage
                    If (lWeaponSkillBackStabClassLevel > 0) Then 'Can player backstab?
                        If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                            lWearSkillsHit = lWearSkillsHit + 1
                            lBackStabTotalDamageMax = (75 + (lWeaponSkillBackStabClassLevel * lPlayerLevel))
                            lHoldDamage = (25 + lRandom(50) + (lWeaponSkillBackStabClassLevel * lRandom(lPlayerLevel)))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            'lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                            lBackStabTotalDamage = lHoldDamage
                            lDamage = lDamage + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                        If (lDoublePunchDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillDoublePunchDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                        If (lHeadButtDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillHeadButtDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > (lRandom(lMLevel) * 2)) Then
                        If (lKnifeHandDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillKnifeHandDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > (lRandom(lMLevel) * 3)) Then
                        If (lClawHandDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillClawHandDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > (lRandom(lMLevel) * 5)) Then
                        If (lDragonUppercutDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillDragonUppercutDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > (lRandom(lMLevel) * 5)) Then
                        If (lPowerKickDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillPowerKickDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > (lRandom(lMLevel) * 6)) Then
                        If (lHurricaneKickDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillHurricaneKickDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                        If (lElbowDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillElbowDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                        If (lKneeDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillKneeDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                
                If (lRandom(lNumAttRndCount) = 1) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                        If (lDropKickDuration <> 0) Then
                            lHoldDamage = (lRandom(lPlayerLevel) + lTranslateSkillDropKickDamage(zClass))
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lWearSkillsHit = lWearSkillsHit + 1
                            lDamage = lDamage + lHoldDamage
                            lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                End If
                                
                If (lNumAttRndCount < 4 And lMobWeaponHit > 0) Then
                    If (lRandom(lTranslateSkillPhysicalCombatHitBonus(zClass) + lPlayerLevel) > lRandom(lMLevel)) Then
                        If (lBeserkDuration <> 0) Then 'We add 33% to the damage.
                            'Berserk bonus damage
                            lWearSkillsHit = lWearSkillsHit + 1
                            lTotalBerserkDmgMax = lPlayerLevel + (lWeaponDamage(1) + lWeaponDamage(2))
                            lHoldDamage = lRandom(lPlayerLevel) + MyCLng((lWeaponDamage(1) / lRandom(2)) + (lWeaponDamage(2) / lRandom(4))) 'one is the strong hand the other is the available hand which is a bit harder to hit twice as hard
                            If (lMResPhysicalDamage <> 0) Then lHoldDamage = (lElementalResistance(lHoldDamage, lMResPhysicalDamage))
                            lTotalBerserkDmg = lHoldDamage
                            lDamage = lDamage + lHoldDamage  'with out the myclng here you get a expression too complex error!
                            'lWearSkillsTotalDmg = lWearSkillsTotalDmg + lHoldDamage
                        End If
                    End If
                    
                    If (lSlayChance > 0) Then
                        If (lPlayerLevel > (lMLevel / lMLevelSlayChance)) Then  'Players cannot slay mobs that are way to powerful for them
                            If (lRandom(lSlayChance) > lRandom(cstlSlayValue + (lMLevel))) Then
                                bSlayChance = True
                                lDamage = lMHP 'we set the damage to full damage to slay the mob
                            End If
                        End If
                    End If
                End If
                If (lDamage > 0) Then 'Did player inflict any damage?
                    If (lMSanctuaryDuration > 0) Then 'is mob sanc up?
                        'DAMAGE REDUCTION
                        lMobReducationTotalDmg = MyCLng(lDamage * (lMSanctuaryDamageReduction / 100))
                        lStoreMobReducationTotalDmg = lStoreMobReducationTotalDmg + lMobReducationTotalDmg
                        lDamage = (lDamage - lMobReducationTotalDmg) 'if sanc is 100 percent there there will be little dmg done to the mobile
                        If (lDamage < 0) Then lDamage = 1 'prevents mob from sanc healing
                    End If
                End If
                'Debug.Print "(lMHP[" & lMHP & "] - lDamage[" & lDamage & "]): " & (lMHP - lDamage)
                bMobDied = ((lMHP - lDamage) < 1)
            Loop 'Do While (lNumAttRndCount < lNumAttRnd And Not bMobDied)
            Else
                zBattleText = zBattleText & "&a" & zMobName & " gains initiative."
            End If
            '-----------------------------------------------------------------------------
            
            'We take any shockshield damage from the mob for hitting it
            If (lMShockshieldDuration > 0) Then
                lCHP = lCHP - (lMLevel + lRandom(lMLevel / 4)) + 1
                If (lCHP < 1) Then lCHP = 1
            End If
            
            'We calculate damage
            If (lDamage > 0 Or bMobDied) Then 'Did player inflict any damage?
                lTotalDamage = lDamage
                'calculate mob dmg
                If (bMobDied) Then
                    lDamage = lMHP 'we give the max xp left on the mob
                    lMHP = 0
                Else
                    lMHP = lMHP - lDamage
                End If
                lGainXP = lGainXP + lDamage
                
                'This is a description of how hard a player hit the mob
                Select Case MyCLng(lDamage * 100 / (lMHP + 1)) '+1 for div zero protection
                    Case 0 To 15
                        zBattleText = zBattleText & "nick"
                    Case 16 To 30
                        zBattleText = zBattleText & "bruise"
                    Case 31 To 50
                        zBattleText = zBattleText & "wound"
                    Case 51 To 80
                        zBattleText = zBattleText & "injure"
                    Case 81 To 115
                        zBattleText = zBattleText & "crush"
                    Case 116 To 150
                        zBattleText = zBattleText & "demolish"
                    Case 151 To 175
                        zBattleText = zBattleText & "massacre"
                    Case 176 To 200
                        zBattleText = zBattleText & "slaughter"
                    Case 201 To 225
                        zBattleText = zBattleText & "PULVERIZE"
                    Case 226 To 250
                        zBattleText = zBattleText & "OBLITERATE"
                    Case 251 To 300
                        zBattleText = zBattleText & "ANNIHILATE"
                    Case Else
                        zBattleText = zBattleText & zLastHitPlayer(zClass, 1)
                End Select
                zBattleText = "&a[" & zBattleText & "]"
                'Check for Gains
                If ((lMLevel * 2) + 4 < lPlayerLevel) Then
                    bOverKill = True
                    lGainXP = MyCLng(lGainXP / 4)  'we do not want high level players leveling lots off of low level mobs - we want the players to move on
                Else
                    bOverKill = False
                End If
                
                'is this the player's quest mob
                If (lQuestMobID = lMobID) Then lGainXP = lGainXP + lQuestXPBonus
                If (bOverKill) Then
                    If (lQuestMobID = lMobID) Then 'is this the player's quest mob
                        If (bAllowFullBattleText) Then zBattleText = zBattleText & "&a[overkill(xp/4)+BXP" & lQuestXPBonus & "]"
                    Else
                        If (bAllowFullBattleText) Then zBattleText = zBattleText & "&a[overkill(xp/4)]"
                    End If
                End If
                'is the player in a factions zone
                'If (lFactionXPBonus > 0) Then
                '    lGainXP = lGainXP + lFactionXPBonus
                '    If (bAllowFullBattleText) Then zBattleText = zBattleText & "&a[Faction+" & lFactionXPBonus & "]"
                'End If
                
                If (lPlayerLevel > 30) Then lTMove = lTMove + (lWearSkillsHit * 12) + (lMobWeaponHit * 9) 'its hard enough to swing a sword let alone a whole load of moves
                lCMove = lCMove - lTMove
                
                'Leeching
                If (lPlayerLevel < lMLevel + 50) Then 'player cannot leech off of tiny mobs
                    If (lLeechingHP > 0 Or lLeechingMana > 0 Or lLeechingEssence > 0 Or lLeechingMove > 0 Or lLeechingSoul > 0) Then
                        If (lRandom(8) < 7) Then
                            lCalcuLeechingHP = lCalcuLeechingHP + lRandom(MyCLng(lGainXP * (lLeechingHP / cstlLeechingMax)))
                            'If (lLeechingHP > 0 And lCalcuLeechingHP < 9) Then lCalcuLeechingHP = 8 + lRandom(20) 'REROLLS
                            
                            lCalcuLeechingMana = lCalcuLeechingMana + lRandom(MyCLng(lGainXP * (lLeechingMana / cstlLeechingMax)))
                            'If (lLeechingMana > 0 And lCalcuLeechingMana < 9) Then lCalcuLeechingMana = 8 + lRandom(20)
                            
                            lCalcuLeechingEssence = lCalcuLeechingEssence + lRandom(MyCLng(lGainXP * (lLeechingEssence / cstlLeechingMax)))
                            'If (lLeechingEssence > 0 And lCalcuLeechingEssence < 9) Then lCalcuLeechingEssence = 8 + lRandom(20)
                            
                            lCalcuLeechingSoul = lCalcuLeechingSoul + lRandom(MyCLng(lGainXP * (lLeechingSoul / cstlLeechingMax)))
                            'If (lLeechingSoul > 0 And lCalcuLeechingSoul < 9) Then lCalcuLeechingSoul = 8 + lRandom(20)
                            
                            lCalcuLeechingMove = lCalcuLeechingMove + lRandom(MyCLng(lGainXP * (lLeechingMove / cstlLeechingMax)))
                            'If (lLeechingMove > 0 And lCalcuLeechingMove < 9) Then lCalcuLeechingMove = 8 + lRandom(20)
                            
                            If (bVerbose And bAllowFullBattleText) Then
                                If (lLeechingHP + lLeechingMana + lLeechingEssence + lLeechingSoul + lLeechingMove > 0) Then 'make a new line if we can leech anything
                                    zBattleText = zBattleText & vbCrLf & "&ML&meeching&M["
                                End If
                                If (lLeechingHP > 0) Then
                                    zBattleText = zBattleText & "&yHP(" & lCalcuLeechingHP & ")"
                                    'zResult3p = zResult3p & "&y LHP(" & lCalcuLeechingHP & ")"
                                End If
                                If (lLeechingMana > 0) Then
                                    zBattleText = zBattleText & "&mMa(" & lCalcuLeechingMana & ")"
                                    'zResult3p = zResult3p & "&r" & " LMa(" & lCalcuLeechingMana & ")"
                                End If
                                If (lLeechingEssence > 0) Then
                                    zBattleText = zBattleText & "&cEs(" & lCalcuLeechingEssence & ")"
                                    'zResult3p = zResult3p & "&c LEs(" & lCalcuLeechingEssence & ")"
                                End If
                                If (lLeechingSoul > 0) Then
                                    zBattleText = zBattleText & "&rSo(" & lCalcuLeechingSoul & ")"
                                    'zResult3p = zResult3p & "&r" & " LSo(" & lCalcuLeechingSoul & ")"
                                End If
                                If (lLeechingMove > 0) Then
                                    zBattleText = zBattleText & "&gMv(" & lCalcuLeechingMove & ")"
                                    'zResult3p = zResult3p & "&g LMv(" & lCalcuLeechingMove & ")"
                                End If
                                If (lLeechingHP + lLeechingMana + lLeechingEssence + lLeechingSoul + lLeechingMove > 0) Then 'EOL
                                    zBattleText = zBattleText & "&M]"
                                End If
                            End If
                        End If
                    End If
                End If
                
                If (lGainXP < 1) Then lGainXP = 1
                gbllPortTotalXP(lPortID) = gbllPortTotalXP(lPortID) + lGainXP 'this shows the total XP() value after the mob is killed
                'Debug.Print gbllPortTotalXP(lPortID)
            End If 'If (lGainXP > 0) Then
            
            If (bMobDied) Then
                'subPlayerRecordMobDetails lMobID, lPlayerID, "K"
                lMobKills = lMobKills + 1
                subCheckArmageddonKillThisManyMobs zPlayerName, lPortID
                
                'MoveAllowed is about raiding and faction questing not moving type moving around like to make them interesting type moving
                Select Case (lMLevel) 'this allows players in the newbie zone to level quickly
                    Case 1 To 9
                        MyDB.Execute "UPDATE tblMob SET MoveAllowed=0, MHP=0, BlindDuration=0, LastDeathDateTime='" & Now() & "', RespawnDelay=1, DefeatedMobDesc='' WHERE (MobID=" & lMobID & ");", dbFailOnError
                    Case Else
                        If (lPlayerLevel > 99) Then 'the random for respawndelay throws trigger botting off.
                            MyDB.Execute "UPDATE tblMob SET MoveAllowed=0, MHP=0, BlindDuration=0, LastDeathDateTime='" & Now() & "', RespawnDelay=" & (cstlMobileRespawnDelay + lRandom(3)) & ", DefeatedMobDesc='' WHERE (MobID=" & lMobID & ");", dbFailOnError
                        Else
                            MyDB.Execute "UPDATE tblMob SET MoveAllowed=0, MHP=0, BlindDuration=0, LastDeathDateTime='" & Now() & "', RespawnDelay=" & (cstlMobileRespawnDelay) & ", DefeatedMobDesc='' WHERE (MobID=" & lMobID & ");", dbFailOnError
                        End If
                End Select
                
                If (zClass <> "VA" And zRace <> "UND") Then 'undeads do not get affected by alignment change
                    lAlignment = lAlignment + lMAlignment 'good mobs are assigned a negative lMAlignment, which adds to the lAlignment causing it to fall (killed a good mob)
                    If (lAlignment > 1000) Then lAlignment = 1000
                    If (lAlignment < -1000) Then lAlignment = -1000
                    If (lAlignment <> -1000) Then
                        If (lMAlignment < 0) And (zClass = "KN" Or zClass = "CL" Or zClass = "PA") Then   'good aligned mob was attack by a holy player
                            If (lRandom(9) = 1) Then lAlignment = -1000
                            If (lAlignment <> -1000) Then 'forcing shortciruit logic just in case
                                zUMobName = UCase(zMobName)
                                If (InStr(zUMobName, "CLERIC") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "PRINCE") <> 0) Then lAlignment = -1000 'prince/ss
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "PALADIN") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "PRIEST") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "HORSE") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "TEMPLAR") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "DRAGON") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "KNIGHT") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, " BARD") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, " MARE") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, " KING") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, " ELF") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "DWARF") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "QUEEN") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "ADMIRAL") <> 0) Then lAlignment = -1000
                            End If
                            If (lAlignment <> -1000) Then
                                If (InStr(zUMobName, "GENERAL") <> 0) Then lAlignment = -1000
                            End If
                            If (bAllowFullBattleText And bVerbose And lAlignment = -1000) Then zBattleText = zBattleText & "&R[&rVOTUM DEHONESTATIO&R]"
                        End If
                    End If
                'Else
                    'lAlignment = 0 'this actually makes it harder to wear cursed items
                End If
                
                subCombatEndedInitializeCombatCellsMobID lMobID
                If (lMGold > 0) Then
                    If (MyCLng(lCCHA / 6) + lRandom(lCLuc) + lRandom(lPlayerLevel) > lRandom(lMLevel * 4)) Or (lRandom(lMLevel * 5) < lRandom(9)) Or (lRandom(lGoldDropChance + lGoldMiserDropChance) > lRandom(100)) Then
                        lHoldGold = lHoldGold + (MyCLng(lMGold / 4) * lRandom(4)) + 1
                        If (lRandom(lGoldDropChance + lGoldMiserDropChance) > lRandom(100)) Then  'bonus gold
                            lDummy = 0
                            If (lRandom(lCCHA) > lRandom(333) + 33) Then
                                lDummy = lRandom(4)
                            End If
                            Select Case lDummy
                                Case 1, 2, 3
                                    lHoldGold = lHoldGold + 2
                                    If (lRandom(3) = 1) Then
                                        lHoldGold = lHoldGold + 8
                                        zGoldMsg = " &y[zatzi]"
                                    End If
                                Case 4
                                    lHoldGold = lHoldGold + 5
                                    If (lRandom(3) = 1) Then
                                        lHoldGold = lHoldGold + MyCLng(lHoldGold / 4) + 20
                                        zGoldMsg = " &y[ZATZI]"
                                    End If
                            End Select
                        End If
                        lGold = lGold + lHoldGold
                        zBattleText = zBattleText & zFormatGoldCofGLearnpts(lHoldGold, "g", True) & zGoldMsg
                        lHoldGold = 0
                    End If
                End If
                subMakeCorpse zPortID, lPlayerID, lPlayerLevel, lMobID, "M", lMagicFind, lMagicFindBase, lCLuc
                bEndCombat = True

                'Check for completed quests bounty raids and glory mobs
                'Debug.Print "PLAYER GOLD  IN: " & lHoldGold & " Gold" & lGold
                subPlayerQuest zPlayerName, lPlayerID, lPlayerLevel, lQuestMobID, zMobName, lMobID, lMLevel, bBounty, zPortID, lPX, lPY, lPZ, lHoldGold, lMMoveAllowed
                If (lHoldGold <> 0) Then lGold = lGold + lHoldGold
                'Debug.Print "PLAYER GOLD OUT: " & lHoldGold & " Gold" & lGold
                'We now auto-look, this is disabled - if someone bots then this slows the computer down
                If (bMSpecialSelfDeleting) Then
                    MyDB.Execute "DELETE MobID FROM tblMob WHERE (MobID=" & lMobID & ");", dbFailOnError
                    'RULE: Careful to NEVER give a deleting mob equipment to drop or sell
                End If

                If (lMSpecialGloryPlayerAmt > 0) Then
                    gbllQuestGuardAreaID(lPortID) = 0 'clear lazyguard
                    gblzQuestGuardAreaDesc(lPortID) = ""
                    gbllQuestGuardFailCount(lPortID) = 0
                
                    If (lPlayerTotalStats > (lMLevel * 3)) Then 'this keeps the exploit of high levels killing all mobs
                        If (bVerbose And bAllowFullBattleText) Then subSendMsg "&M[EASY] Congratulations! You defeated " & zMobName & ".", zPortID
                    Else
                        If (bVerbose And bAllowFullBattleText) Then subSendMsg "&W[HARD] Congratulations! You heroically defeated " & zMobName & "!", zPortID
                    End If
                    subSendMsgInfoChannel "[" & zWhereName(lPX, lPY, lPZ) & "&g] &w" & zPlayerName & " &a[defeated] &g[" & zMobName & "] " & zFormatGoldCofGLearnpts(lMSpecialGloryPlayerAmt, "c", True)
                    MyDB.Execute "UPDATE tblPlayer SET QuestMissionLog='', Crown=[Crown]+" & lMSpecialGloryPlayerAmt & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                End If
                subMobSpeakDeathScene lMobID
                'We now check to see if this mob is part of a quest herd
                If (lMHerdMobID <> 0) Then subQuestHerdMob lMHerdMobID, zPlayerName, lPlayerID, lMagicFind, lMagicFindBase, lPlayerLevel, False, zPortID
                'Any eq the mob stole is dropped to the ground
                subMobEquipmentStolenReturned lMobID, zPortID
            Else
                'If (bVerbose And bAllowFullBattleText) Then zBattleText = zBattleText & vbCrLf & "&y" & zMobName & zConvertHitPoints(lMHP, lMHPBonus, lMLevel, 2) & "&a"
                'we keep the database updated for this creature
                MyDB.Execute "UPDATE tblMob SET MHP=" & lMHP & ", BlindDuration=[BlindDuration]+" & (lWeaponBlind(1) + lWeaponBlind(2)) & " WHERE (MobID=" & lMobID & ");", dbFailOnError
                
                'See if mob attacks now
                If (lMLevel > 5) Then 'mobs over level 5 only attack
                    bIAS = lRandom(lIASChance) > lRandom(20 * (lMLevel))
                    If (bIAS) Then
                        'we skip the mobs chance to do anything
                        bIAS = True
                        If (bVerbose And bAllowFullBattleText) Then
                            'zBattleText = zRemoveCRLF(zBattleText)
                            zBattleText = zBattleText & "&W[IAS]"
                        End If
                    End If
                End If
            End If
            
            'Add up the XP first
            lXP = lXP + lGainXP
            
            'P R I N T  O U T  R E S U L T S  second . . .
            'check formatd
            If (bVerbose And lLearnSkillsHit > 0) Then zBattleText = zBattleText & vbCrLf & "&wPassiveSkillsHit[" & lLearnSkillsHit & "]"
            If (bVerbose And lLearnSkillsLeveled > 0) Then zBattleText = zBattleText & " &wPassiveSkillsLeveled[" & lLearnSkillsLeveled & "]"
            
            'Wear skills is a bit harder to put together but its strait forward that we broke out a few of the wear skills and left them counted only - this is so players can get a fell for Berserk and Backstab
            If (bVerbose And lWearSkillsHit > 0) Then zBattleText = zBattleText & vbCrLf & "&mWearSkills["
            If (bAllowFullBattleText) Then
                If (bVerbose And lBackStabTotalDamage <> 0) Then zBattleText = zBattleText & "&RBS(" & lBackStabTotalDamage & "/" & lBackStabTotalDamageMax & "dmg) "
                If (bVerbose And lTotalBerserkDmg <> 0) Then zBattleText = zBattleText & "&gBerserk(" & lTotalBerserkDmg & "/" & lTotalBerserkDmgMax & "dmg) "
            Else
                lWearSkillsTotalDmg = lWearSkillsTotalDmg + lTotalBerserkDmg + lBackStabTotalDamage
            End If
            If (bVerbose And lWearSkillsHit > 0) Then zBattleText = zBattleText & gblzFNMAG & "t(" & lWearSkillsHit & "hit"
            If (bVerbose And lWearSkillsTotalDmg > 0) Then zBattleText = zBattleText & "/" & lWearSkillsTotalDmg & "dmg"
            If (bVerbose And lWearSkillsHit > 0) Then zBattleText = zBattleText & ")]"
            
            'Elemental
            If ((lElementalHits + lElementalDmg) > 0) Then
                zElementalText = ""
                lElementalDmg = (lFireElementalDmg + lLightningElementalDmg + lPoisonElementalDmg + lColdElementalDmg)
                If (bAllowFullBattleText) Then
                    If (lFireElementalDmg > 0) Then zElementalText = zElementalText & "&Rf(" & lFireElementalDmg & ")"
                    If (lLightningElementalDmg > 0) Then zElementalText = zElementalText & "&Wl(" & lLightningElementalDmg & ")"
                    If (lPoisonElementalDmg > 0) Then zElementalText = zElementalText & "&gp(" & lPoisonElementalDmg & ")"
                    If (lColdElementalDmg > 0) Then zElementalText = zElementalText & "&Cc(" & lColdElementalDmg & ")"
                Else
                    If (lFireElementalDmg > 0) Then zElementalText = zElementalText & "&Rf"
                    If (lLightningElementalDmg > 0) Then zElementalText = zElementalText & "&Wl"
                    If (lPoisonElementalDmg > 0) Then zElementalText = zElementalText & "&gp"
                    If (lColdElementalDmg > 0) Then zElementalText = zElementalText & "&cc"
                End If
                If (bVerbose) Then zBattleText = zBattleText & vbCrLf & "&c[Elemental{" & zElementalText & "&c}(" & lElementalHits & "hits|" & lElementalDmg & "/" & lTotalPossibleElementalDmg & "dmg)]"
            End If
            
            If (lPlayerWeaponCount > 0) Then 'Is the player holding a weapon?
                If (bVerbose) Then
                    If (lMobWeaponHit > 0) Then zBattleText = zBattleText & vbCrLf & "&yHit[" & lMobWeaponHit & "-" & lPlayerWeaponCount & "]"
                End If
                If (bWeaponCellHit(1)) Then
                    If (bVerbose) Then zBattleText = zBattleText & zPlayerWeapon(1) & "[" & zCombatWeaponEmoteDesc(zPlayerWeaponType(1))
                    If (bVerbose And lWeaponBlind(1) > 0) Then zBattleText = zBattleText & "&a *" & lWeaponBlind(1) & "B*"
                    If (bVerbose) Then zBattleText = zBattleText & "&a(" & lWeaponDamage(1) & ")&y]"
                    If (bVerbose) Then zBattleText = zBattleText & zCriticalText(1) '& vbCrLf
                End If
                If (bWeaponCellHit(2)) Then
                    If (bVerbose) Then zBattleText = zBattleText & zPlayerWeapon(2) & "[" & zCombatWeaponEmoteDesc(zPlayerWeaponType(2))
                    If (bVerbose And lWeaponBlind(2) > 0) Then zBattleText = zBattleText & "&a *" & lWeaponBlind(2) & "B*"
                    If (bVerbose) Then zBattleText = zBattleText & "&a(" & lWeaponDamage(2) & ")&y]"
                    If (bVerbose) Then zBattleText = zBattleText & zCriticalText(2) '& vbCrLf
                End If
            Else
                If (bAllowFullBattleText And bVerbose) Then
                    If (Not bBarehandedNoMartialArts And Not bBarehandedWithMartialArts) Then
                        If (lDamage > 0) Then 'we want to know always if we are barehanded attacking its a warning
                            zBattleText = zBattleText & vbCrLf & "&yHit[" & lMobWeaponHit & "-BH(" & lDamage & ")]"
                        End If
                    End If
                End If
                If (lDamage < 1) Then 'this is meant to be an error catch only!! if you like spam initiate this.
                    Select Case (lNumAttRndMax > 1)
                        Case True
                            zBattleText = zBattleText & vbCrLf & "&r[" & zPlayerName & " missed " & zMobName & " " & lNumAttRndMax & " times]"
                        Case False
                            zBattleText = zBattleText & vbCrLf & "&r[" & zPlayerName & " missed " & zMobName & "]"
                    End Select
                End If
            End If
            
            If (bAllowFullBattleText And bVerbose And lStoreMobReducationTotalDmg > 0) Then
                zBattleText = zBattleText & vbCrLf & "&W[&M" & zMobName & " &WSanc(&w" & Abs(lStoreMobReducationTotalDmg) & "&W)]"
            End If
            
            If (bSlayChance) Then
                'zBattleText = zRemoveCRLF(zBattleText)
                If (zClass = "KN") Then
                    zBattleText = zBattleText & "&r[LS-SLAY]"
                Else
                    zBattleText = zBattleText & "&r[SLAY]"
                End If
                lSlayKills = lSlayKills + 1
            End If
            'We use one line of sql to update the player file
            'This MUST go before the mob has a turn to attack
            lCHP = lCHP + lCalcuLeechingHP
            If (lCHP > lOHP) Then lCHP = lOHP
            lCMana = lCMana + lCalcuLeechingMana
            If (lCMana > lOMANA) Then lCMana = lOMANA
            lCEssence = lCEssence + lCalcuLeechingEssence
            If (lCEssence > lOEssence) Then lCEssence = lOEssence
            lCSoul = lCSoul + lCalcuLeechingSoul
            If (lCSoul > lOSoul) Then lCSoul = lOSoul
            lCMove = lCMove + lCalcuLeechingMove
            If (lCMove > lOMove) Then lCMove = lOMove
            If (lCMove < 0) Then lCMove = 0
            
            MyDB.Execute "UPDATE tblPlayer SET Gold=" & lGold & ", MartialArtsTuskPunchXP=" & lMartialArtsTuskPunchXP & ", MartialArtsTuskPunchLevel=" & lMartialArtsTuskPunchLevel & ", MartialArtsTigerFistsXP=" & lMartialArtsTigerFistsXP & ", MartialArtsTigerFistsLevel=" & lMartialArtsTigerFistsLevel & ", MartialArtsKungPowXP=" & lMartialArtsKungPowXP & ", MartialArtsKungPowLevel=" & lMartialArtsKungPowLevel & ", MartialArtsLungingElbowsXP=" & lMartialArtsLungingElbowsXP & ", MartialArtsLungingElbowsLevel=" & lMartialArtsLungingElbowsLevel & ", CHP=" & lCHP & ", CEssence=" & lCEssence & ", CSoul=" & lCSoul & ", CMana=" & lCMana & ", CMove=" & lCMove & ", XP=" & lXP & ", Alignment=" & lAlignment & ", MobKills=" & lMobKills & ", SlayKills=" & lSlayKills & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            
            If (bMobDied) Then
                'If (Not bVerbose) Then zBattleText = zBattleText & "&GYOU WIN, Mob Died."
                zBattleText = zBattleText & vbCrLf
                zBattleText = zBattleText & "&a[" & zPlayerName & "] "
                If (lPlayerLevel < 11) Then 'We allow some ez botting text at first.
                    zBattleText = zBattleText & "&RYou defeated " & zMobName & "!"
                Else 'Turn on more anti-botting, this one defeats the triggering method.
                    Select Case lRandom(4)
                        Case 1
                            zBattleText = zBattleText & "&R" & zMobName
                        Case 2
                            zBattleText = zBattleText & "&RThe creature"
                        Case 3
                            zBattleText = zBattleText & "&RThe monster"
                        Case Else
                            zBattleText = zBattleText & "&RThe critter"
                    End Select
                    
                    Select Case lRandom(11)
                        Case 1
                            zBattleText = zBattleText & " dies with a final and swift strike!"
                        Case 2
                            zBattleText = zBattleText & " hits the ground DEAD!"
                        Case 3
                            zBattleText = zBattleText & " falls down into a bloody heap!"
                        Case 4
                            zBattleText = zBattleText & " falls hard to a mighty blow!"
                        Case 5
                            zBattleText = zBattleText & " falls to the ground DEAD!"
                        Case 6
                            zBattleText = zBattleText & " was killed!"
                        Case 7
                            zBattleText = zBattleText & " was defeated!"
                        Case 8
                            zBattleText = zBattleText & " falls down dead!"
                        Case 9
                            zBattleText = zBattleText & " slumps to the ground, DEAD!!"
                        Case 10
                            zBattleText = zBattleText & " is SUBDUED!"
                        Case Else
                            zBattleText = zBattleText & " no longer walks this plane of existance!"
                    End Select
                End If
                  
                If (bVerbose) Then
                    If (lQuestXPBonus > 0) Then
                        If (bOverKill) Then
                            zBattleText = zBattleText & zFormatGoldCofGLearnpts(MyCLng(lMMaxXPValue / 4), "P", True) & zFormatGoldCofGLearnpts(MyCLng(lQuestXPBonus / 4), "X", True)
                        Else
                            zBattleText = zBattleText & zFormatGoldCofGLearnpts(lMMaxXPValue, "P", True) & zFormatGoldCofGLearnpts(MyCLng(lQuestXPBonus / 4), "X", True)
                        End If
                    Else
                        If (bOverKill) Then
                            zBattleText = zBattleText & zFormatGoldCofGLearnpts(MyCLng(lMMaxXPValue / 4), "P", True)
                        Else
                            zBattleText = zBattleText & zFormatGoldCofGLearnpts(lMMaxXPValue, "P", True)
                        End If
                    End If
                End If
                gbllPortTotalXP(lPortID) = 0
                If (bVerbose And lTotalDamage > 0) Then zBattleText = zTrimCrLf(zBattleText) & zFormatGoldCofGLearnpts(lTotalDamage, "T", False) '  " &atd[" & lTotalDamage & "]"
                'Print the battle results
                subSendMsgAreaAll "&a[" & zPlayerName & "] " & zTrimCrLf(zBattleText), lPX, lPY, lPZ
            Else
                If (Not bVerbose And bAllowFullBattleText) Then zBattleText = zBattleText & vbCrLf & "&G[BATTLE GOES ON]"
                'Print the battle results
                If (bVerbose And lTotalDamage > 0) Then zBattleText = zTrimCrLf(zBattleText) & zFormatGoldCofGLearnpts(lTotalDamage, "T", False)
                subSendMsgAreaAll "&a[" & zPlayerName & "] " & zTrimCrLf(zBattleText), lPX, lPY, lPZ

                If (Not bIAS) Then  'Mob is still alive!
                    'lMobLevel * cstMobHRRespawn is the mobs full hps
                    If (lMWimpyHP <= lMHP) Then
                        bEndCombat = bCombatMvP(lPlayerID, lMobID, lQuestMobID, bVerbose, lPortID) 'mobs always hit lastTrue
                    Else
                        'See if the mob flees cause the Wimpy HPs are less than the mobs hps.
                        If (lMAntiMoveDuration = 0 And lRandom(lMWimpyChance) > lRandom(100)) Then
                            'MOB ATTEMPTED A FLEE
                            If (lMEntanglementDuration = 0 And lMStunDuration = 0) Then bEndCombat = bMobFleesFromCombat(zMobName, lMobID, lMX, lMY, lMZ, lWhereID, "FN") 'mobs dont flee if they are webbed / trapped
                            
                            If (Not bEndCombat) Then
                                bEndCombat = bCombatMvP(lPlayerID, lMobID, lQuestMobID, bVerbose, lPortID) 'cant flee may as well attack
                            Else
                                'all players attacking the mob - no longer attack now
                                subCombatEndedInitializeCombatCellsMobID lMobID
                            End If
                        Else
                            If (bAllowFullBattleText) Then subSendMsgAreaAllNotBM gblzFNYEL & zMobName & " attempted to flee.", lPX, lPY, lPZ
                            bEndCombat = bCombatMvP(lPlayerID, lMobID, lQuestMobID, bVerbose, lPortID) 'cant flee may as well attack
                        End If
                    End If
                End If
            End If
            If (lDamage > 0 And lXP > lTranslateRequiredForNextLevel(lPlayerLevel)) Then subPlayerGains lPlayerID
        Else
            bEndCombat = True 'subCombatEndedInitializeCombatCells lMobID
        End If
        Else
            bEndCombat = True 'subCombatEndedInitializeCombatCells lMobID
        End If 'MobID <> 0
    Else
        bEndCombat = True 'subCombatEndedInitializeCombatCells lMobID
    End If  'lCountOfPlayerFactionsInArea > -1
    'bConfigSpam = (Mid(MyCStr(rsPlr!Config), 2, 1) = "1") 'verbose with mob details
    If (bEndCombat) Then
        If (lNeverAttackable <> 0) Then subSendMsg "&gInvalid Target try something else.", zPortID
        If (lCountOfPlayerFactionsInArea < 0) Then subSendMsg "&gFirst you need to &GFACTION COMMAND", zPortID
    
        subCombatEndedInitializeCombatCellsPortID lPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCombatPvM," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bCombatMvP(lPlayerID As Long, lMobID As Long, lQuestMobID As Long, bVerbose As Boolean, lPortID As Long) As Boolean 'Mob vs Player MvP
On Error GoTo Err_Check 'See also: iPlayerHitPointTest bCombatMvP subCombatPvM subCombatPvP subMobDurationCountdown
    Const cstObjectWeaponBlockCounterMAX = 6 'This is PvE too but the other way around
    Const cstbCanFailQuest = False 'system setting, when a player fails their quest it can be a small punishment when true
    Dim rsPlayer As Recordset
    Dim zUMobName As String
    Dim lWBP As Long
    Dim lOWBP As Long
    Dim lMWBP As Long
    Dim lMWBPMax As Long
    Dim lTotalWOBP As Long
    Dim lTotalWOBPMsgctrl As Long
    Dim zWeaponsBlockedMsgTimes As String
    Dim rsPlayerWeapons As Recordset
    Dim zCastEntanglementDesc As String
    Dim lCastEntanglementChance As Long
    Dim lCurseChancePlayerFleeDuration As Long
    Dim bMHoldingWeapon As Boolean
    Dim lWeaponBlockPercent As Long
    Dim lWeaponBlockXP As Long
    Dim lBlindDuration As Long
    Dim lPlayerDodge As Long
    Dim lPlayerParry As Long
    Dim zDamageEmote As String
    Dim lPX As Long
    Dim lPY As Long
    Dim lPZ As Long
    Dim zPlayerName As String
    Dim zGender As String
    Dim lClawHandDuration As Long
    Dim bDodge As Boolean
    Dim bParry As Boolean
    Dim lDodgePercent As Long
    Dim lDodgeXP As Long
    Dim lParryPercent As Long
    Dim lParryXP As Long
    Dim lKnifeHandDuration As Long
    Dim lDragonUppercutDuration As Long
    Dim lPowerKickDuration As Long
    Dim lHurricaneKickDuration As Long
    Dim lDoublePunchDuration As Long
    Dim lDropKickDuration As Long
    Dim lHeadButtDuration As Long
    Dim lElbowDuration As Long
    Dim lKneeDuration As Long
    Dim lMMorphType As Long
    Dim lMMorphChance As Long
    Dim lStatus As Long
    Dim zClass As String
    Dim lFlyDuration As Long
    Dim zRace As String
    Dim bRPEq As Boolean
    Dim lPlayerLevel As Long
    Dim lCDAMROLL As Long
    Dim lCHITROLL As Long
    Dim lCAC As Long
    Dim lCPAC As Long
    Dim lCDamageReduction As Long
    Dim lCHP As Long
    Dim lCStr As Long
    Dim lCINT As Long
    Dim lCWIS As Long
    Dim lCDEX As Long
    Dim lCCon As Long
    Dim lCCHA As Long
    Dim lCLuc As Long
    Dim lAntiSmashBonus As Long
    Dim lNumAttRndCount As Long
    Dim lNumAttRnd As Long
    Dim lInertShield As Long
    Dim lSanctuaryDuration As Long
    Dim lLightningElementalDamage As Long
    Dim lColdElementalDamage As Long
    Dim lFireElementalDamage As Long
    Dim lSlayChance As Long
    Dim lWeaponSkillBackStabClassLevel As Long
    Dim lWeaponSkillMissileRangeClassLevel As Long
    Dim lMobSpellUnderwaterDuration As Long
    Dim lFireshieldDuration As Long
    Dim lStaticshieldDuration As Long
    Dim lChaosshieldDuration As Long
    Dim lIceshieldDuration As Long
    Dim lBeserkDuration As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lInvisibilityDuration As Long
    Dim lXP As Long
    Dim lStunDuration As Long
    Dim lMagicFind As Long
    Dim zPortID As String
    Dim lPlayerWeaponCount As Long
    Dim lPlayerShieldCount As Long
    Dim zPlayerWeapon(1 To 2) As String
    Dim zPlayerWeaponType(1 To 2) As String
    Dim bWeaponBlockPercent As Boolean
    Dim lObjectWeaponBlockDurability(1 To 5) As Long
    Dim lObjectWeaponBlockDurabilityBroken(1 To 5) As Long 'see also subCombatPlayerDurabilityLoss
    Dim lObjectWeaponBlockObjectID(1 To 5) As Long
    Dim lObjectWeaponBlockDurabilityMAX(1 To 5) As Long
    Dim zObjectWeaponBlockPercent(1 To 5) As String
    Dim lObjectWeaponBlockPercent(1 To 5) As Long
    Dim lObjectWeaponBlockCounter As Long
    Dim lObjectWeaponBlockCounterMAX As Long
    Dim lAlignment As Long
    Dim iStatus As Integer
    Dim bEndCombat As Boolean
    Dim lPoisionDuration As Long
    Dim lGold As Long
    Dim lArmourAbsorbtionChance As Long
    Dim bHPShieldUpdated As Boolean
    Dim bBlindFight As Boolean
    Dim bStunFight As Boolean
    Dim lSleepDuration As Long
    Dim lGrip As Long
    'Dim lResPhysicalDamage As Long
    'Dim zPBittenReservedOriginalClass As String
    Dim lPBittenDuration As Long
    
    Dim rsMob As Recordset
    'Dim bMobHitPlayer As Boolean
    Dim lMCriticalDmgChance As Long
    Dim lMCriticalDmgBonus  As Long
    Dim zMCriticalDmgMsg  As String
    Dim lMNumAttRndCntr As Long
    Dim lMNumAttRnd As Long
    Dim zDefeatedMobDesc As String
    
    Dim lMCHITROLLBase As Long
    Dim lMCDAMROLLBase  As Long
    Dim zMobName As String
    Dim bMWeaponName As Boolean
    Dim zMWeaponName As String
    Dim lMHP  As Long
    Dim lMHPMAX As Long
    Dim lMLevel  As Long
    Dim lMAC  As Long
    Dim lMAlignment  As Long
    Dim lMPoisionDuration As Long
    Dim bMobInvisible As Boolean
    Dim lMDisarmPlayerChance As Long
    Dim bMPoisonOkay As Boolean
    Dim lMStunRandom As Long
    Dim lMBlindRandom As Long
    Dim lMEntanglementDuration As Long
    Dim zMEntanglementDesc As String
    Dim lMBlindDuration As Long
    Dim lMMobSpellDefensiveNo  As Long
    Dim lMMobSpellDefensiveChance As Long
    Dim lMMobSpellOffensiveNo As Long
    Dim lMMobSpellOffensiveChance As Long
    Dim lMShockshieldDuration As Long
    Dim lMPoisionChance As Long
    Dim lMPoisionStrength As Long
    Dim lMStunDuration As Long
    Dim lMDisarmDuration As Long
    Dim lMQuestPlayerID As Long
    Dim lMSanctuaryChance As Long
    Dim lMSanctuaryDuration As Long
    Dim lMResPhysicalDamage As Long
    Dim lMResLightningElementalDamage As Long
    Dim lMResColdElementalDamage As Long
    Dim lMResFireElementalDamage As Long
    Dim zMobKillPlayerDesc As String
    Dim zMStunEmoteFirstPerson As String
    Dim zMStunEmoteThirdPerson As String
    Dim zMBlindEmoteFirstPerson As String
    Dim zMBlindEmoteThirdPerson As String
    Dim lMEssence As Long
    Dim lMEssenceMax As Long
    Dim lMMana As Long
    Dim lMManaMax As Long
    Dim lMSoul As Long
    Dim lMSoulMax As Long
    Dim bMBittenMaster As Boolean
    'Dim lMBittenDuration As Long
    Dim zMBittenMobBracketClass As String
    
    Dim lPlayerDamage As Long 'total damage
    Dim lPlayerXPBonus As Long 'this is also mob damage
    Dim lHoldDamage As Long 'this is just used to calculate the player dmg
    Dim bPoisoned As Boolean
    Dim lPlayerHit As Long
    Dim lPlayerCriticalHit As Long
    Dim lPlayerCriticalHitDamage As Long
    Dim lPlayerTotalHitDamage As Long
    Dim bPlayerDied As Boolean
    
    Dim zScript1p As String
    Dim zScript3p As String
    Dim zScriptXP1p As String
    Dim zScriptXP3p As String
    Dim zObjectName As String
    Dim zConfigSpam As String
    Dim lShieldDefend As Long
    Dim zStar As String
    Dim zSQL As String
    Dim lWhereID As Long
    Dim bDay As Boolean
    Dim lTurnedIntoAnimalType As Long 'Works with tblMob.MorphType tblMob.MorphChance
    Dim lMoveCostIIAdditional As Long
    Dim lCMana As Long
    Dim lManashieldDuration As Long
    Dim lManashieldTotal As Long
    Dim lCSoul As Long
    Dim lSoulshieldDuration As Long
    Dim lSoulshieldTotal As Long
    Dim bStatusBM As Boolean
    Dim zDummy As String
    Dim lDummy As Long
    
    bDay = bWhenIsIt("", False)
    bStatusBM = gblbFilterMode(lPortID)
    If (rSCombat(lPortID).iStatus = cstiStatusPlayerIgnoredVsMob) Then
        If (Not bMobInBattle(lMobID)) Then
            'the leader seems to of died, appoint the next leader to die ;)
            rSCombat(lPortID).iStatus = cstiStatusPlayerVsMob 'make this player the new leader
            rMCombat(lPortID).lID = lMobID
            rPCombat(lPortID).lID = lPlayerID
        End If
    End If
    
    bRPEq = False
    bEndCombat = False
    If (rSCombat(lPortID).iStatus = cstiStatusPlayerVsMob) Then 'mobs will only attack the leaders in a many player vs Mob.
        bPlayerDied = False
        lPlayerXPBonus = 0
        lHoldDamage = 0
        'Get player data
        Set rsPlayer = MyDB.OpenRecordset("SELECT * FROM tblPlayer WHERE (PlayerID=" & lPlayerID & " AND Len([PortID])>1);", dbOpenSnapshot)
        If (Not rsPlayer.EOF) Then
            'must stay ontop!
            lMoveCostIIAdditional = 0
            lManashieldDuration = MyCLng(rsPlayer!ManashieldDuration)
            lSoulshieldDuration = MyCLng(rsPlayer!SoulshieldDuration)
            lCSoul = MyCLng(rsPlayer!CSoul)
            lCMana = MyCLng(rsPlayer!CMana)
            lTurnedIntoAnimalType = MyCLng(rsPlayer!TurnedIntoAnimalType)
            lWhereID = MyCLng(rsPlayer!WhereID)
            lGrip = MyCLng(rsPlayer!Grip)
            lPlayerID = MyCLng(rsPlayer!PlayerID)
            lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            zClass = MyCStr(rsPlayer!Class)
            lFlyDuration = MyCLng(rsPlayer!FlyDuration)
            'end must stay ontop
            
            lWeaponBlockPercent = MyCLng(rsPlayer!WeaponBlockPercent)
            Select Case zClass
                Case "MO" 'monks block only with hands
                    lWeaponBlockPercent = lWeaponBlockPercent + 20
                Case "GL" 'gladiators rock with shield block
                    lWeaponBlockPercent = lWeaponBlockPercent + 15
                Case "WA", "BA", "VA"
                    lWeaponBlockPercent = lWeaponBlockPercent + 10
            End Select
            lWeaponBlockXP = MyCLng(rsPlayer!WeaponBlockXP)
            lDodgePercent = MyCLng(rsPlayer!DodgePercent)
            lDodgeXP = MyCLng(rsPlayer!DodgeXP)
            lParryPercent = MyCLng(rsPlayer!ParryPercent)
            lParryXP = MyCLng(rsPlayer!ParryXP)
            zPortID = MyCStr(rsPlayer!PortID)
            lPX = MyCLng(rsPlayer!x)
            lPY = MyCLng(rsPlayer!y)
            lPZ = MyCLng(rsPlayer!z)
            If (Len(MyCStr(rsPlayer!Config)) > 0) Then
                zConfigSpam = (Mid(MyCStr(rsPlayer!Config), 2, 1))  'if cell 2 is set to 0 then we want to use the combat in non spam mode
            End If
            'lResPhysicalPlayerDamage = MyCLng(rsPlayer!lResPhysicalDamage)
            zPlayerName = MyCStr(rsPlayer!PlayerName)
            zGender = MyCStr(rsPlayer!Gender)
            lPBittenDuration = MyCLng(rsPlayer!BittenDuration)
            iStatus = MyCInt(rsPlayer!Status)
            If (iStatus <> 0) Then
               zScript1p = zScript1p & gblzFBMAG & "You move into a battle stance." & vbCrLf
                zScript3p = zScript3p & gblzFBMAG & zPlayerName & " takes a battle stance." & vbCrLf
                MyDB.Execute "UPDATE tblPlayer SET Status = 0, SitObjectID = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
            End If
            
            'init array
            lObjectWeaponBlockCounter = 0
            For lObjectWeaponBlockCounter = 1 To 5
                zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = ""
                lObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = 0
            Next lObjectWeaponBlockCounter
            If (zClass = "MO" Or zClass = "BA" Or zClass = "VA") Then
                For lObjectWeaponBlockCounter = 1 To 5
                    lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) = 100
                    lObjectWeaponBlockObjectID(lObjectWeaponBlockCounter) = 0
                    lObjectWeaponBlockDurabilityMAX(lObjectWeaponBlockCounter) = 100
                    Select Case lRandom(4) 'no gaps between arrays allowed
                        Case 1
                            lObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = lRandom(lPlayerLevel)
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = "blocking claw"
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = zAdverb(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter), 2) & zShortstop(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter))
                        Case 2
                            lObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = lRandom(MyCLng(lPlayerLevel / 2))
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = "catching blow"
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = zAdverb(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter), 2) & zShortstop(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter))
                        Case 3
                            lObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = lRandom(MyCLng(lPlayerLevel / 3))
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = "flow with damage"
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = zAdverb(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter), 2) & zShortstop(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter))
                        Case 4
                            lObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = lRandom(MyCLng(lPlayerLevel / 4))
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = "dual fists"
                            zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = zAdverb(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter), 2) & zShortstop(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter))
                    End Select
                Next lObjectWeaponBlockCounter
                lObjectWeaponBlockCounter = 5
            Else
                Select Case zClass
                    Case "GL", "WA", "KN", "PA", "TH", "RA"
                        'Some classes can naturally block with any weapon or any object with a WeaponBlockPercent
                        zSQL = "SELECT tblObject.ObjectID, tblObject.ObjectName, tblObject.DurabilityBroken, tblObject.DurabilityMAX, tblObject.WeaponBlockPercent FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblObject.WeaponBlockPercent)<>0) AND ((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ")) OR (((tblObject.WeaponType) Is Not Null And (tblObject.WeaponType)<>'') AND ((tblPlayerEquipmentItems.Location)=20 Or (tblPlayerEquipmentItems.Location)=21) AND ((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.DurabilityBroken)>0)) ORDER BY WeaponBlockPercent DESC;"
                    Case Else
                        zSQL = "SELECT tblObject.ObjectID, tblObject.ObjectName, tblObject.DurabilityBroken, tblObject.DurabilityMAX, tblObject.WeaponBlockPercent FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblObject.WeaponBlockPercent)<>0) AND ((tblObject.DurabilityBroken)>0)) ORDER BY WeaponBlockPercent DESC;"
                End Select
                lObjectWeaponBlockCounter = 0
                Set rsPlayerWeapons = MyDB.OpenRecordset(zSQL, dbOpenSnapshot)
                Do While (Not rsPlayerWeapons.EOF And lObjectWeaponBlockCounter < 5)
                    lObjectWeaponBlockCounter = lObjectWeaponBlockCounter + 1
                    lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) = MyCLng(rsPlayerWeapons!DurabilityBroken)
                    lObjectWeaponBlockObjectID(lObjectWeaponBlockCounter) = MyCLng(rsPlayerWeapons!ObjectID)
                    lObjectWeaponBlockDurabilityMAX(lObjectWeaponBlockCounter) = MyCLng(rsPlayerWeapons!DurabilityMAX)
                    lObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = MyCLng(rsPlayerWeapons!WeaponBlockPercent)
                    zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = MyCStr(rsPlayerWeapons!ObjectName)
                    zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) = zAdverb(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter), 2) & zShortstop(zObjectWeaponBlockPercent(lObjectWeaponBlockCounter))
                    rsPlayerWeapons.MoveNext
                Loop
                Set rsPlayerWeapons = Nothing
            End If
            lObjectWeaponBlockCounterMAX = lObjectWeaponBlockCounter
            
            'Get the players weapon names
            'zPlayerWeapon(1) = ""
            'zPlayerWeapon(2) = ""
            'lPlayerWeaponCount = 0
            'Set rsPlayerWeapons = MyDB.OpenRecordset("SELECT tblPlayerEquipmentItems.PlayerID, tblPlayerEquipmentItems.Location, tblObject.ObjectName, tblObject.WeaponType FROM tblPlayerEquipmentItems INNER JOIN tblObject ON tblPlayerEquipmentItems.ObjectID = tblObject.ObjectID WHERE (((tblPlayerEquipmentItems.PlayerID)=" & lPlayerID & ") AND ((tblPlayerEquipmentItems.Location)=20));", dbOpenSnapshot)
            'Do While (Not rsPlayerWeapons.EOF And lPlayerWeaponCount < 2)
                'lPlayerWeaponCount = lPlayerWeaponCount + 1
                'zObjectName = MyCStr(rsPlayerWeapons!ObjectName)
                'zPlayerWeapon(lPlayerWeaponCount) = zAdverb(zObjectName, 2) & zShortstop(zObjectName)
                'zPlayerWeaponType(lPlayerWeaponCount) = MyCStr(rsPlayerWeapons!WeaponType)
                'rsPlayerWeapons.MoveNext
            'Loop
            'Set rsPlayerWeapons = Nothing
            
            'Load information
            lXP = MyCLng(rsPlayer!XP)
            lMagicFind = MyCLng(rsPlayer!MagicFind)
            lBeserkDuration = MyCLng(rsPlayer!BeserkDuration)
            lClawHandDuration = MyCLng(rsPlayer!ClawHandDuration)
            lKnifeHandDuration = MyCLng(rsPlayer!KnifeHandDuration)
            lDragonUppercutDuration = MyCLng(rsPlayer!DragonUppercutDuration)
            lPowerKickDuration = MyCLng(rsPlayer!PowerKickDuration)
            lHurricaneKickDuration = MyCLng(rsPlayer!HurricaneKickDuration)
            lDoublePunchDuration = MyCLng(rsPlayer!DoublePunchDuration)
            lDropKickDuration = MyCLng(rsPlayer!DropKickDuration)
            lHeadButtDuration = MyCLng(rsPlayer!HeadButtDuration)
            lElbowDuration = MyCLng(rsPlayer!ElbowDuration)
            lKneeDuration = MyCLng(rsPlayer!KneeDuration)
            lStatus = MyCLng(rsPlayer!Status)
            
            zRace = MyCStr(rsPlayer!Race)
            'lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
            lAlignment = MyCLng(rsPlayer!Alignment)
            lCDAMROLL = MyCLng(rsPlayer!CDAMROLL)
            lCHITROLL = MyCLng(rsPlayer!CHITROLL)
            bPoisoned = False
            lCAC = MyCLng(rsPlayer!CAC)
            lCPAC = MyCLng(rsPlayer!PAC)
            lCDamageReduction = MyCLng(rsPlayer!DamageReduction)
            'hinted at natural skill
            If (Not bDay) Then
                If (gbllMoon < 4) Then
                    Select Case zRace
                        Case "UND"
                            lCAC = lCAC + 300
                    End Select
                End If
                If (gbllMoon = 3) Then
                    Select Case zClass 'when full moon only
                        Case "VA"
                            lCAC = lCAC + 1200
                        Case "WE"
                            lCAC = lCAC + 1500
                    End Select
                End If
                If (gbllMoon = 3 Or gbllMoon = 4 Or gbllMoon = 5) Then
                    Select Case zRace
                        Case "DRA"
                            lCAC = lCAC + 3000
                    End Select
                End If
                If (gbllMoon < 0 Or gbllMoon = 4 Or gbllMoon = 5) Then
                    Select Case zRace
                        Case "ORC"
                            lCAC = lCAC + 1000
                        Case "TRO"
                            lCAC = lCAC + 2000
                        Case "OGR"
                            lCAC = lCAC + 1500
                    End Select
                End If
            End If
            
            lCHP = MyCLng(rsPlayer!CHP)
            
            If (lTurnedIntoAnimalType > 0) Then
                lCAC = 20 * lTurnedIntoAnimalType 'we are a frog or something so AC is low
                If (lCHP > 30 * lTurnedIntoAnimalType) Then lCHP = 30 * lTurnedIntoAnimalType
            End If
            
            lCStr = MyCLng(rsPlayer!CStr)
            lCINT = MyCLng(rsPlayer!CInt)
            lCWIS = MyCLng(rsPlayer!CWIS)
            lCDEX = MyCLng(rsPlayer!CDEX)
            lCCon = MyCLng(rsPlayer!CCon)
            lCCHA = MyCLng(rsPlayer!CCHA)
            lCLuc = MyCLng(rsPlayer!CLuc)
            lAntiSmashBonus = lRandom(lCLuc + lCCHA) + lRandom(MyCLng(lCINT / 4)) + lRandom(MyCLng(lCWIS / 2)) + lRandom(MyCLng(lCDEX / 2))
            lNumAttRnd = MyCLng(rsPlayer!NumAttRnd)
            If (lNumAttRnd < 1) Then lNumAttRnd = 1
            'lInertShield = MyCLng(rsPlayer!InertShield) 'Reduces physical skill damage, like sanc but for only learn combat skills
            lSanctuaryDuration = MyCLng(rsPlayer!SanctuaryDuration)
            lFireshieldDuration = MyCLng(rsPlayer!FireshieldDuration)
            lIceshieldDuration = MyCLng(rsPlayer!IceshieldDuration)
            lStaticshieldDuration = MyCLng(rsPlayer!StaticshieldDuration)
            lChaosshieldDuration = MyCLng(rsPlayer!ChaosshieldDuration)
            
            lLightningElementalDamage = MyCLng(rsPlayer!LightningElementalDamage)
            lColdElementalDamage = MyCLng(rsPlayer!ColdElementalDamage)
            lFireElementalDamage = MyCLng(rsPlayer!FireElementalDamage)
            lSlayChance = MyCLng(rsPlayer!SlayChance)
            lWeaponSkillBackStabClassLevel = MyCLng(rsPlayer!WeaponSkillBackStabClassLevel)
            lWeaponSkillMissileRangeClassLevel = MyCLng(rsPlayer!WeaponSkillMissileRangeClassLevel)
            lStunDuration = MyCLng(rsPlayer!StunDuration)
            lBlindDuration = MyCLng(rsPlayer!BlindDuration)
            lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
            lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
            If (lInvisibilityDuration > 0) Then
                zScript1p = zScript1p & gblzFBMAG & "You fade into existence." & vbCrLf
                zScript3p = zScript3p & gblzFBMAG & zPlayerName & " fades into existence." & vbCrLf
                MyDB.Execute "UPDATE tblPlayer SET InvisibilityDuration = 0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'lPlayerID
            End If
            lPoisionDuration = MyCLng(rsPlayer!PoisionDuration)
            lGold = MyCLng(rsPlayer!Gold)
            bBlindFight = (MyCInt(rsPlayer!BlindFight) <> 0)
            bStunFight = (MyCInt(rsPlayer!StunFight) <> 0)
        End If
        Set rsPlayer = Nothing
        
        lMHP = 0
        'Get mob battle data
        Set rsMob = MyDB.OpenRecordset("SELECT * FROM tblMob WHERE (X=" & lPX & " AND Y=" & lPY & " AND Z=" & lPZ & " AND MobID=" & lMobID & " AND RespawnDelay=0);", dbOpenSnapshot)
        If (Not rsMob.EOF) Then
            zDamageEmote = MyCStr(rsMob!DamageEmote)
            If (Len(zDamageEmote) = 0) Then zDamageEmote = "hits"
            lMNumAttRnd = MyCLng(rsMob!NumAttRnd)
            If (lMNumAttRnd < 1) Then lMNumAttRnd = 1
            zDefeatedMobDesc = MyCStr(rsMob!DefeatedMobDesc)
            zMobKillPlayerDesc = MyCStr(rsMob!MobKillPlayerDesc)
            lMCriticalDmgChance = MyCLng(rsMob!CriticalDmgChance)
            lMCriticalDmgBonus = MyCLng(rsMob!CriticalDmgBonus)
            'zMCriticalDmgMsg = MyCStr(rsMob!CriticalDmgMsg)
            
            lMResPhysicalDamage = MyCLng(rsMob!ResPhysicalDamage)
            lMResLightningElementalDamage = MyCLng(rsMob!ResLightningElementalDamage)
            lMResColdElementalDamage = MyCLng(rsMob!ResColdElementalDamage)
            lMResFireElementalDamage = MyCLng(rsMob!ResFireElementalDamage)
            
            lMQuestPlayerID = MyCLng(rsMob!QuestPlayerID)
            zCastEntanglementDesc = MyCStr(rsMob!CastEntanglementDesc)
            lCastEntanglementChance = MyCLng(rsMob!CastEntanglementChance)
            lCurseChancePlayerFleeDuration = MyCLng(rsMob!CurseChance)
            lMEntanglementDuration = MyCLng(rsMob!EntanglementDuration)
            zMEntanglementDesc = MyCStr(rsMob!EntanglementDesc)
            lMPoisionDuration = MyCLng(rsMob!PoisionDuration)
            lMBlindDuration = MyCLng(rsMob!BlindDuration)
            
            lSleepDuration = MyCLng(rsMob!SleepDuration)
            
            lMCHITROLLBase = MyCLng(rsMob!CHITROLLBase)
            If (lMCHITROLLBase < 20) Then lMCHITROLLBase = 20
            lMCDAMROLLBase = MyCLng(rsMob!CDAMROLLBase)
            If (lMCDAMROLLBase < 20) Then lMCDAMROLLBase = 20
            
            lMMobSpellDefensiveNo = MyCLng(rsMob!MobSpellDefensiveNo)
            lMMobSpellDefensiveChance = MyCLng(rsMob!MobSpellDefensiveChance)
            
            lMMorphType = MyCLng(rsMob!MorphType)
            lMMorphChance = MyCLng(rsMob!MorphChance)
            
            lMMobSpellOffensiveNo = MyCLng(rsMob!MobSpellOffensiveNo)
            lMMobSpellOffensiveChance = MyCLng(rsMob!MobSpellOffensiveChance)
            
            lMStunRandom = MyCLng(rsMob!StunRandom)
            lMBlindRandom = MyCLng(rsMob!BlindRandom)
            
            bMBittenMaster = (MyCInt(rsMob!BittenMaster) <> 0)
            zMBittenMobBracketClass = MyCStr(rsMob!BittenMobBracketClass)
            
            zMWeaponName = MyCStr(rsMob!WeaponName)
            bMWeaponName = (Len(zMWeaponName) > 0)
            bMHoldingWeapon = (bMWeaponName And lMDisarmDuration = 0)
            
            lMDisarmDuration = MyCLng(rsMob!DisarmDuration)
            
            If (bMWeaponName) Then
                If (lMDisarmDuration > 0) Then
                    lMMobSpellOffensiveChance = MyCLng(lMMobSpellOffensiveChance / 2) 'The mob focuses on spells if available instead
                    lMCHITROLLBase = lMCHITROLLBase - (lMCHITROLLBase / 4)
                    lMCDAMROLLBase = lMCDAMROLLBase - (lMCDAMROLLBase / 4)
                End If
            End If
            
            lMStunDuration = MyCLng(rsMob!StunDuration)
            
            If (lMStunDuration > 0) Then
                lMStunRandom = lMStunRandom * 4 'this makes it harder for the mob to stun and do other things
                lMBlindRandom = lMBlindRandom * 4
                lMMobSpellOffensiveChance = MyCLng(lMMobSpellOffensiveChance * 2)
                lMCHITROLLBase = lMCHITROLLBase - (lMCHITROLLBase / 4)
                lMCDAMROLLBase = lMCDAMROLLBase - (lMCDAMROLLBase / 4)
            End If
            
            If (lSleepDuration <> 0) Then
                lMCHITROLLBase = lMCHITROLLBase - (lMCHITROLLBase / 3)
                lMCDAMROLLBase = lMCDAMROLLBase - (lMCDAMROLLBase / 5)
            End If
            
            If (lMPoisionDuration <> 0) Then
                lMCHITROLLBase = lMCHITROLLBase - (lMCHITROLLBase / 5)
                lMCDAMROLLBase = lMCDAMROLLBase - (lMCDAMROLLBase / 5)
            End If
            
            If (lMEntanglementDuration <> 0) Then
                lMCHITROLLBase = lMCHITROLLBase - (lMCHITROLLBase / 5)
                lMCDAMROLLBase = lMCDAMROLLBase - (lMCDAMROLLBase / 5)
            End If
            
            If (lMBlindDuration <> 0) Then
                lMCHITROLLBase = lMCHITROLLBase - (lMCHITROLLBase / 5)
                lMCDAMROLLBase = lMCDAMROLLBase - (lMCDAMROLLBase / 5)
            End If
            
            If (lMQuestPlayerID <> 0) Then 'Oracle Quest mobs can hit armour class better
                lMCHITROLLBase = (lMCHITROLLBase * 4)
                'lMCDAMROLLBase = lMCDAMROLLBase + (lMCDAMROLLBase / 4)
            End If
            
            lMobID = MyCLng(rsMob!MobID)
            zMobName = zAdverb(MyCStr(rsMob!MobName), 2) & zShortstop(MyCStr(rsMob!MobName))
            zUMobName = UCase(zMobName)
            If (InStr(zUMobName, "TRAP") <> 0 Or InStr(zUMobName, "RANGER") <> 0 Or InStr(zUMobName, "ASSIN") <> 0) Then
                gblbInterruptPlayer(MyCLng(zPortID)) = (lRandom(9) = 1) 'this is per BATTLE-ON round
            End If
            lMobSpellUnderwaterDuration = MyCLng(rsMob!MobSpellUnderwaterDuration)
            lMHP = MyCLng(rsMob!MHP)
            lMHPMAX = lMHP
            lMLevel = MyCLng(rsMob!MobLevel)
            lMAC = MyCLng(rsMob!Mac)
            lMAlignment = MyCLng(rsMob!Alignment) 'evil mobs hit harder by 5%
            bMobInvisible = (MyCLng(rsMob!Invisible) > 0)
            lMDisarmPlayerChance = MyCLng(rsMob!DisarmPlayerChance)
            lMShockshieldDuration = MyCLng(rsMob!ShockshieldDuration)
            lMSanctuaryChance = MyCLng(rsMob!SanctuaryChance)
            lMSanctuaryDuration = MyCLng(rsMob!SanctuaryDuration)
            lMEssence = MyCLng(rsMob!essence)
            lMEssenceMax = MyCLng(rsMob!EssenceMAX)
            lMMana = MyCLng(rsMob!mana)
            lMManaMax = MyCLng(rsMob!ManaMAX)
            lMSoul = MyCLng(rsMob!soul)
            lMSoulMax = MyCLng(rsMob!SoulMAX)
            
            lMPoisionStrength = MyCLng(rsMob!PoisionStrength)
            lMPoisionChance = MyCLng(rsMob!PoisionChance)
            zMStunEmoteFirstPerson = MyCStr(rsMob!StunEmoteFirstPerson)
            zMStunEmoteThirdPerson = MyCStr(rsMob!StunEmoteThirdPerson)
            zMBlindEmoteFirstPerson = MyCStr(rsMob!BlindEmoteFirstPerson)
            zMBlindEmoteThirdPerson = MyCStr(rsMob!BlindEmoteThirdPerson)
            
            If (lMCHITROLLBase < 10) Then lMCHITROLLBase = 10
            If (lMCDAMROLLBase < 10) Then lMCDAMROLLBase = 10
                        
            If (lQuestMobID = lMobID) Then
                If (lMLevel > 49) Then
                    lMCHITROLLBase = lMCHITROLLBase * 3
                    lMCDAMROLLBase = lMCDAMROLLBase * 2
                    lMDisarmPlayerChance = 25 + lRandom(75)
                    lMNumAttRnd = lMNumAttRnd + lRandom(2)
                    lMCriticalDmgChance = lRandom(75) + 25
                    lMCriticalDmgBonus = lRandom(50) + 25
                End If
            End If
            If (lMNumAttRnd < 1) Then lMNumAttRnd = 1
            
            If (lPlayerLevel < 11 And lMLevel < 10) Then 'we dont want noobies dieing in the noobie areas.
                lMAC = 1
                lMCHITROLLBase = 1
                lMCDAMROLLBase = 1
                lMCriticalDmgChance = 0
                lMCriticalDmgBonus = 0
            End If
        End If
        Set rsMob = Nothing
        
        'init variables
        zScript1p = ""
        zScript3p = ""
        
        lPlayerHit = 0
        lPlayerTotalHitDamage = 0
        lPlayerCriticalHit = 0
        lPlayerCriticalHitDamage = 0
        
        lPlayerDodge = 0
        lPlayerParry = 0
        lPlayerShieldCount = 0
        lArmourAbsorbtionChance = 0
        
        'Main battle system starts here
        If (lMHP > 0) Then
            'If ((lMCHITROLLBase / 2) + lRandom(lMCHITROLLBase / 2) >= lRandom(lCAC) + lCDEX + lCCON + lCLuc) Then
                subCombatWorldVsPets lPlayerID, 1, zPlayerName, zMobName, lMLevel, lPX, lPY, lPZ, zClass, zRace, lFlyDuration, bVerbose, True, zPortID, ""
                lTotalWOBPMsgctrl = 0
                For lMNumAttRndCntr = 1 To lMNumAttRnd
                    bDodge = False
                    bParry = False
                    bWeaponBlockPercent = False
                    If (((lMCHITROLLBase / 2) + lRandom(lMCHITROLLBase / 2) >= lRandom(lCAC) + lCDEX + lCCon + lCLuc)) Then
                        'If (bMWeaponName) Then 'shield block can try and stop all attacks
                        'Get the players shield names and use each shields WeaponBlockPercent seperate
                        'For lObjectWeaponBlockCounter = 1 To lObjectWeaponBlockCounterMAX
                        'lObjectWeaponBlockCounter = 0
                        'Do While (Not bWeaponBlockPercent And lObjectWeaponBlockCounter < lObjectWeaponBlockCounterMAX)
                            'lObjectWeaponBlockCounter = lObjectWeaponBlockCounter + 1
                        If (lXP >= gblcstlDodgeParryWeaponsBlockXPMin) Then 'players can level dodge parry and weapons block when they have 1000 xp or more
                            If (lObjectWeaponBlockCounterMAX > 0 And lObjectWeaponBlockCounterMAX < cstObjectWeaponBlockCounterMAX) Then 'to make sure no crashes occur
                                lObjectWeaponBlockCounter = lRandom(lObjectWeaponBlockCounterMAX) 'find the random item that blocked
                                lWBP = lRandom(lWeaponBlockPercent)
                                lOWBP = lRandom(lObjectWeaponBlockPercent(lObjectWeaponBlockCounter))
                                lTotalWOBP = lWeaponBlockPercent + lObjectWeaponBlockPercent(lObjectWeaponBlockCounter)
                                lMWBPMax = (lWeaponBlockPercent / 6) + lMLevel + lRandom(25)
                                lMWBP = lRandom(lMWBPMax)
                                If (lWBP + lOWBP > lMWBP) Then   'is the players weapon blocking percent plus the bonus on the item better than what it takes to block (note the natural weapon blocking is very low around 5 on avg)
                                    lPlayerShieldCount = lPlayerShieldCount + 1
                                    bWeaponBlockPercent = True
                                    
                                    'cool block emotes
                                    If (gblbRealmAdditionalMoveCosts) Then
                                        If (lRandom(lCCHA) < lRandom(20)) Then lMoveCostIIAdditional = lMoveCostIIAdditional + lRandom(17) + 3
                                        If (lRandom(lCDEX) < lRandom(40)) Then lMoveCostIIAdditional = lMoveCostIIAdditional + lRandom(17) + 3
                                    End If
                                    lTotalWOBPMsgctrl = lTotalWOBPMsgctrl + 1
                                    If (Not bStatusBM And lTotalWOBPMsgctrl = 1) Then
                                        If (bMWeaponName) Then 'If the mob has a weapon we try to block that
                                            Select Case lRandom(4) 'just two different action emotes
                                                Case 1
                                                    zScript1p = zScript1p & "You use " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " [block] " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                                    'zScript3p = zScript3p & zPlayerName & " uses " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " to block the " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                                Case 2
                                                    zScript1p = zScript1p & "You swing " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " [low-repel] " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                                    'zScript3p = zScript3p & zPlayerName & " swings " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " blocking low to stop the " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf '" & zTranslateGender(zGender, 2) & "
                                                Case 3
                                                    zScript1p = zScript1p & "You block with " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " [defend] " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                                    'zScript3p = zScript3p & zPlayerName & " blocks with " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " torso high defending against the " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                                Case Else
                                                    zScript1p = zScript1p & "You swing " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " [high-repel] " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                                    'zScript3p = zScript3p & zPlayerName & " swings " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " blocking high to stop the " & zMWeaponName & ", " & (lWBP + lOWBP) & "/" & lTotalWOBP & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf '" & zTranslateGender(zGender, 2) & "
                                            End Select
                                        Else
                                            zScript1p = zScript1p & "&yYou use " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " [repel] " & (lWBP + lOWBP) & "/" & lTotalWOBP & "%" & "(vs)" & lMWBP & "/" & lMWBPMax & vbCrLf
                                            'zScript3p = zScript3p & "&y" & zPlayerName & " uses " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " [repel] " & (lWBP + lOWBP) & "/" & lTotalWOBP & "%" & vbCrLf
                                        End If
                                    End If
                                    lWeaponBlockXP = lWeaponBlockXP + lRandom(iTranslateClassWeaponBlockPercent(zClass)) + lRandom(9)
                                    'If the player doesnt level the weapons blocking percent there is a chance for damage
                                    If (lWeaponBlockXP >= iTranslateClassWeaponBlockPercentTNL(zClass)) Then
                                        lWeaponBlockXP = 0
                                        MyDB.Execute "UPDATE tblPlayer SET WeaponBlockXP=0, WeaponBlockPercent=[WeaponBlockPercent]+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError  'we level Shield Blocking
                                        zScript1p = zScript1p & "&GYou gained a shield blocking level!" & vbCrLf
                                    Else
                                        If (lRandom(100 + lAntiSmashBonus) < lRandom(50) And lObjectWeaponBlockObjectID(lObjectWeaponBlockCounter) <> 0) Then 'We try to dent or chip a weapon or dagger - 25 percent of the time the weapons take dmg
                                            lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) = lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) - 1
                                            'We damage the object here.
                                            If (lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) < 1) Then
                                                If (lRandom(lCCHA + lCLuc) > lRandom(8)) Then
                                                    zScript1p = zScript1p & "&GYou twist your weapon in a lucky way preventing it from smashing this time - REPAIR at Shadow Castle, soon!" & vbCrLf
                                                    'zScript3p = zScript3p & "&g" & zPlayerName & " twists their weapon in a lucky way preventing it from smashing this time - REPAIR at Shadow Castle, soon!" & vbCrLf
                                                Else
                                                    lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) = 0
                                                    'zScript1p = zScript1p & "&R[&r" & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " CRACKS and DENTS&R]" & vbCrLf
                                                    'zScript3p = zScript3p & "&r" & zPlayerName & "&R -=DENTS=- &r" & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & "!" & vbCrLf
                                                    'MyDB.Execute "DELETE ObjectID FROM tblPlayerEquipmentItems WHERE (ObjectID=" & lObjectWeaponBlockObjectID(lObjectWeaponBlockCounter) & ");", dbFailOnError
                                                    'MyDB.Execute "DELETE ObjectID FROM tblObject WHERE (ObjectID=" & lObjectWeaponBlockObjectID(lObjectWeaponBlockCounter) & ");", dbFailOnError
                                                End If
                                            Else
                                                zScript1p = zScript1p & "&r" & "CHIPPED! " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & " will need a repair later." & vbCrLf
                                                'zScript3p = zScript3p & "&r" & zPlayerName & " chips " & zObjectWeaponBlockPercent(lObjectWeaponBlockCounter) & "." & vbCrLf
                                                MyDB.Execute "UPDATE tblObject SET DurabilityBroken=" & lObjectWeaponBlockDurabilityBroken(lObjectWeaponBlockCounter) & " WHERE (ObjectID=" & lObjectWeaponBlockObjectID(lObjectWeaponBlockCounter) & ");", dbFailOnError
                                            End If
                                        End If
                                    End If
                                End If
                            End If
                            'Loop
                            'Next lObjectWeaponBlockCounter
                            If (lMNumAttRndCntr < iTranslateClassDodgeTimes(zClass, zRace)) Then
                                If (Not bWeaponBlockPercent And Not bMHoldingWeapon) Then  'try dodge and parry if weapon block didnt take
                                    If ((lRandom(lDodgePercent) > lRandom((lDodgePercent / 2) + 50 + lMLevel)) And (lMNumAttRndCntr > 1)) Then  'cant dodge or parry the first mob attack so players are not immune to physical
                                        bDodge = True 'dodge can stop weapon swings or base attacks
                                        lPlayerDodge = lPlayerDodge + 1
                                        'player gets a dodge xp + class level!
                                        lDodgeXP = lDodgeXP + lRandom(iTranslateClassDodgePercent(zClass)) + lRandom(9)
                                        If (lDodgeXP >= iTranslateClassDodgePercentTNL(zClass)) Then
                                            lDodgeXP = 0
                                            MyDB.Execute "UPDATE tblPlayer SET DodgeXP=0, DodgePercent=[DodgePercent]+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'we level dodge
                                            zScript1p = zScript1p & "&GYou gained a dodge level!" & vbCrLf
                                        'Else
                                        '    MyDB.Execute "UPDATE tblPlayer SET DodgeXP=" & lDodgeXP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        End If
                                    End If
                                End If
                            End If
                            
                            If (bMHoldingWeapon) Then 'parry only works if the mob has a weapon
                                If (lMNumAttRndCntr < iTranslateClassParryTimes(zClass, zRace)) Then
                                    If (lRandom(lParryPercent) > lRandom((lParryPercent / 2) + 50 + lMLevel)) Then
                                        bParry = True
                                        lPlayerParry = lPlayerParry + 1
                                        'player gets a Parry xp + class level!
                                        lParryXP = lParryXP + lRandom(iTranslateClassParryPercent(zClass)) + lRandom(9)
                                        If (lParryXP >= iTranslateClassParryPercentTNL(zClass)) Then
                                            lParryXP = 0
                                            MyDB.Execute "UPDATE tblPlayer SET ParryXP=0, ParryPercent=[ParryPercent]+1 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'we level Parry
                                            zScript1p = zScript1p & "&GYou gained a parry level!" & vbCrLf
                                        'Else
                                        '    MyDB.Execute "UPDATE tblPlayer SET ParryXP=" & lParryXP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        End If
                                    End If
                                End If
                            End If
                        End If
                        
                        'If the player was struck then we add the damage here
                        If (Not bDodge And Not bParry And Not bWeaponBlockPercent) Then 'physical hit
                            lPlayerHit = lPlayerHit + 1
                            lHoldDamage = lRandom(MyCLng(lMCDAMROLLBase / 2)) + MyCLng(lMCDAMROLLBase / 2)
                            lPlayerTotalHitDamage = lPlayerTotalHitDamage + lHoldDamage
                            lPlayerDamage = (lPlayerDamage + lHoldDamage)
                            lPlayerDamage = (lPlayerDamage - lCDamageReduction)
                            If (lPlayerDamage < 1) Then lPlayerDamage = 1
                            If (lRandom(lMCriticalDmgChance) = 1) Then
                                lPlayerCriticalHit = lPlayerCriticalHit + 1
                                lHoldDamage = lRandom(MyCLng(lMCriticalDmgBonus / 2)) + MyCLng(lMCriticalDmgBonus / 2)
                                lPlayerDamage = (lPlayerDamage + lHoldDamage)
                                lPlayerTotalHitDamage = (lPlayerTotalHitDamage + lHoldDamage)
                                lPlayerCriticalHitDamage = (lPlayerCriticalHitDamage + lHoldDamage)
                            End If
                        End If
                    End If
                Next lMNumAttRndCntr
                
                If (lWeaponBlockXP > 0 And lWeaponBlockPercent < 1000) Then MyDB.Execute "UPDATE tblPlayer SET WeaponBlockXP=" & lWeaponBlockXP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'we only level blocking so much
                If (lParryPercent + lDodgePercent < 2000 And lPlayerParry + lPlayerDodge > 0 And lParryXP + lDodgeXP > 0) Then MyDB.Execute "UPDATE tblPlayer SET DodgeXP=" & lDodgeXP & ", ParryXP=" & lParryXP & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                
                If (lPlayerHit < 1) Then
                    'I just use executive reports here. Blocking XP and Dual wield XP lag enough.
                    'player was totally missed
                    If (Not bWeaponBlockPercent) Then 'the mob physically misses but shields is an agreed hit cause it repels =P
                        If (lMNumAttRnd > 1) Then
                            If (Not bDodge And Not bParry And Not bWeaponBlockPercent) Then 'physical hit
                                zScript1p = zScript1p & "&c" & zMobName & " misses you " & lMNumAttRnd & " times!" & vbCrLf
                                zScript3p = zScript3p & "&c" & zMobName & " misses " & zPlayerName & " " & lMNumAttRnd & " times!" & vbCrLf
                            End If
                        Else
                            zScript1p = zScript1p & "&c" & zMobName & " misses you!" & vbCrLf
                            zScript3p = zScript3p & "&c" & zMobName & " misses " & zPlayerName & "!" & vbCrLf
                        End If
                    End If
                Else 'player was hit
                    zScript1p = zScript1p & "&c" & zMobName & " " & zDamageEmote & " you " & lPlayerHit & "/" & lMNumAttRnd & " (" & lPlayerTotalHitDamage & ")"
                    zScript3p = zScript3p & "&c" & zMobName & " " & zDamageEmote & " " & zPlayerName & " " & lPlayerHit & "/" & lMNumAttRnd & " (" & lPlayerTotalHitDamage & ")"
                    If (lPlayerCriticalHit > 0) Then
                        zScript1p = zScript1p & "&r" & vbCrLf & "OWE! " & lPlayerCriticalHit & " crit-hits (" & lPlayerCriticalHitDamage & ")"
                        zScript3p = zScript3p & "&r" & vbCrLf & "OWE! " & lPlayerCriticalHit & " crit-hits (" & lPlayerCriticalHitDamage & ")"
                    End If
                    zScript1p = zScript1p & vbCrLf
                    zScript3p = zScript3p & vbCrLf
                End If
                
                If (lPlayerShieldCount > 0) Then
                    zWeaponsBlockedMsgTimes = "WBlk " & lPlayerShieldCount & " "
                Else
                    zWeaponsBlockedMsgTimes = ""
                End If
                
                If (lPlayerDodge <> 0 And lPlayerParry <> 0) Then
                    zScript1p = zScript1p & "&g" & zWeaponsBlockedMsgTimes & "You dodged " & lPlayerDodge & " Parried " & lPlayerParry & " of " & lMNumAttRnd & vbCrLf
                    zScript3p = zScript3p & "&g" & zWeaponsBlockedMsgTimes & zPlayerName & " dodged " & lPlayerDodge & " parried " & lPlayerParry & " of " & lMNumAttRnd & vbCrLf
                Else
                    If (lPlayerDodge <> 0) Then
                        zScript1p = zScript1p & "&g" & zWeaponsBlockedMsgTimes & "You dodged " & lPlayerDodge & " attack(s) out of " & lMNumAttRnd & "." & vbCrLf
                        zScript3p = zScript3p & "&g" & zWeaponsBlockedMsgTimes & zPlayerName & " dodged " & lPlayerDodge & " attack(s) out of " & lMNumAttRnd & "." & vbCrLf
                    End If
                    If (lPlayerParry <> 0) Then
                        zScript1p = zScript1p & "&g" & zWeaponsBlockedMsgTimes & "You parry " & lPlayerParry & " attack(s) out of " & lMNumAttRnd & "." & vbCrLf
                        zScript3p = zScript3p & "&g" & zWeaponsBlockedMsgTimes & zPlayerName & " parried " & lPlayerParry & " attack(s) out of " & lMNumAttRnd & "." & vbCrLf
                    End If
                End If
                
                'Mob casts spell. 1/2
                If (lRandom(lMMorphChance) = 1) Then
                    Select Case (lMMorphType)
                        Case 0 To 9
                            If (lMEntanglementDuration = 0) Then subPoofPlayernameType "", MyCStr(lMMorphType), "", lPlayerID
                    End Select
                End If
                
                'Mob casts spell. 2/2
                If (lRandom(lMMobSpellDefensiveChance) = 1) Then
                    If (lMEntanglementDuration = 0) Then
                        If (lRandom(5) = 1) And (zClass = "VA" Or zClass = "WE" Or zClass = "PL" Or zClass = "CY") Then
                            Select Case zClass
                                Case "VA"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [interrupted] [-gazed]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [interrupted] gazed by " & zPlayerName & vbCrLf
                                Case "WE"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [interrupted] [-growled]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [interrupted] growled by " & zPlayerName & vbCrLf
                                Case "PL"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [interrupted] [-bamboospikes]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [interrupted] bamboo spiked by " & zPlayerName & vbCrLf
                                Case "CY"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [interrupted] [-elescanners]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [interrupted] eletronic-scanned by " & zPlayerName & vbCrLf
                            End Select
                        Else
                            Select Case lMMobSpellDefensiveNo
                                Case 1 'shockshield
                                    If (lMShockshieldDuration = 0) Then
                                        lMEssence = lMEssence - lRandom(16) + 20
                                        If (lMEssence < 0) Then lMEssence = 0
                                        If (lMEssence > 0) Then
                                            MyDB.Execute "UPDATE tblMob SET ShockshieldDuration=" & lRandom(20) + 10 & " WHERE (MobID=" & lMobID & ");", dbFailOnError
                                            zScript1p = zScript1p & gblzFBBLU & zMobName & " [shockshield] forms" & vbCrLf
                                            zScript3p = zScript3p & gblzFBBLU & zMobName & " [shockshield] forms" & vbCrLf
                                        End If
                                    End If
                                Case 2 'minor heal lMEssence lMEssenceMax
                                    If (MyCLng(lMHP * 2) + 1 < lMLevel * cstMobHPRespawn) Then
                                        lMEssence = lMEssence - lRandom(6) + 10
                                        If (lMEssence < 0) Then lMEssence = 0
                                        If (lMEssence > 0) Then
                                            lMHP = lMHP + (lRandom(lMLevel) * 3)
                                            If (lMHP > lMLevel * cstMobHPRespawn) Then
                                                lMHP = lMLevel * cstMobHPRespawn
                                            Else
                                                zScript1p = zScript1p & gblzFBBLU & zMobName & " [heals] minor wounds." & vbCrLf
                                                zScript3p = zScript3p & gblzFBBLU & zMobName & " [heals] minor wounds." & vbCrLf
                                            End If
                                        End If
                                    End If
                                Case 3 'major heal lMEssence lMEssenceMax
                                    If (MyCLng(lMHP * 2) + 1 < lMLevel * cstMobHPRespawn) Then
                                        lMEssence = lMEssence - lRandom(6) + 26
                                        If (lMEssence < 0) Then lMEssence = 0
                                        If (lMEssence > 0) Then
                                            lMHP = lMHP + (lRandom(lMLevel) * 11)
                                            If (lMHP > lMLevel * cstMobHPRespawn) Then
                                                lMHP = lMLevel * cstMobHPRespawn
                                            Else
                                                zScript1p = zScript1p & gblzFBBLU & zMobName & " [heals] major wounds." & vbCrLf
                                                zScript3p = zScript3p & gblzFBBLU & zMobName & " [heals] major wounds." & vbCrLf
                                            End If
                                        End If
                                    End If
                            End Select
                        End If
                    Else
                        zScript1p = zScript1p & gblzFBBLU & zMobName & " [" & zMEntanglementDesc & "] defensive spell cancelled!" & vbCrLf
                        zScript3p = zScript3p & gblzFBBLU & zMobName & " [" & zMEntanglementDesc & "] defensive spell cancelled!" & vbCrLf
                    End If
                End If
                
                If (lRandom(lCurseChancePlayerFleeDuration) = 1) Then
                    lDummy = lCCHA
                    zDummy = ""
                    If (zRace = "GNO") Then
                        lDummy = lDummy + 5
                        zDummy = zDummy & " Gnome"
                    End If
                    If (zRace = "OGR") Then
                        lDummy = lDummy + 9
                        zDummy = zDummy & " Ogre"
                    End If
                    If (zRace = "TRO") Then
                        lDummy = lDummy + 15 'too ugly to be scared
                        zDummy = zDummy & " Troll"
                    End If
                    If (zClass = "VA" Or zClass = "WE" Or zClass = "PL") Then lDummy = (lDummy * 2) + 5
                    If (zClass = "CY") Then lDummy = (lDummy * 3) + 15
                    Select Case zClass
                        Case "VA"
                            zDummy = zDummy & " Vampyre"
                        Case "WE"
                            zDummy = zDummy & " Werewolf"
                        Case "PL", "VE"
                            zDummy = zDummy & " Plantlife"
                        Case "CY"
                            zDummy = zDummy & " Cyborg"
                    End Select
                    If (lRandom(75) > lRandom(lDummy)) Then
                        zScript1p = zScript1p & gblzFBRED & zMobName & " *J U M P-S C A R Es* YOU!!!&g [raise your charisma]" & vbCrLf
                        zScript3p = zScript3p & gblzFBRED & zMobName & " *J U M P-S C A R Es* " & zPlayerName & "&g [raise your charisma]" & vbCrLf
                        MyDB.Execute "UPDATE tblPlayer SET PlayerFleeDuration = " & lRandom(lCurseChancePlayerFleeDuration) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                    Else
                        zScript1p = zScript1p & gblzFBRED & zMobName & " *J U M P-S C A R Es* at ~YOU~ but has no effect on your charisma!" & vbCrLf
                        zScript3p = zScript3p & gblzFBRED & zMobName & " is about to *J U M P-S C A R E* " & zPlayerName & "'s but their charisma saves them!" & vbCrLf
                    End If
                    If (Len(zDummy) <> 0) Then zScript1p = zScript1p & "&yIt Helps being a " & MyCStr(zDummy) & vbCrLf
                End If
                
                If (lRandom(lCastEntanglementChance) = 1) Then
                    If (lMEntanglementDuration = 0) Then
                        If (lRandom(2) = 1) And (zClass = "VA" Or zClass = "WE" Or zClass = "PL") Then
                            Select Case zClass
                                Case "VA"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [entangle cancelled] [-gazed]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [entangle cancelled] gazed by " & zPlayerName & vbCrLf
                                Case "WE"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [entangle cancelled] [-growled]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [entangle cancelled] growled by " & zPlayerName & vbCrLf
                                Case "PL", "VE"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " [entangle cancelled] [-bamboospikes]!" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " [entangle cancelled] bamboo spiked by " & zPlayerName & vbCrLf
                            End Select
                        Else
                            lHoldDamage = lRandom(lMLevel) + MyCLng(lMLevel / 2)
                            zScript1p = zScript1p & "&y" & zMobName & " [" & zCastEntanglementDesc & "] you! (" & lHoldDamage & ")" & vbCrLf
                            zScript3p = zScript3p & "&y" & zMobName & " [" & zCastEntanglementDesc & "] " & zPlayerName & " (" & lHoldDamage & ")" & vbCrLf
                            MyDB.Execute "UPDATE tblPlayer SET EntanglementDuration=" & lRandom(3) & ", EntanglementDesc='" & zCastEntanglementDesc & "' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            lPlayerDamage = lPlayerDamage + lHoldDamage
                        End If
                    Else
                        zScript1p = zScript1p & gblzFBBLU & zMobName & " [webbed] " & zMEntanglementDesc & vbCrLf
                        zScript3p = zScript3p & gblzFBBLU & zMobName & " [webbed] " & zMEntanglementDesc & vbCrLf
                    End If
                End If
                
                If (lMobSpellUnderwaterDuration > 0) Then
                    If (lRandom(lMLevel) > lRandom(100)) Then
                        subSetAreaUnderwaterDuration lPX, lPY, lPZ, lRandom(lMobSpellUnderwaterDuration)
                        zScript1p = zScript1p & gblzFBBLU & zMobName & " calls upon a tsunami!" & vbCrLf
                        zScript3p = zScript1p & gblzFBBLU & zMobName & " calls upon a tsunami!" & vbCrLf
                    End If
                End If
                
                If (lRandom(lMMobSpellOffensiveChance) = 1) Then
                    If (lMEntanglementDuration = 0) Then
                        If (lRandom(5) = 1) And (zClass = "VA" Or zClass = "WE" Or zClass = "PL" Or zClass = "CY") Then
                            Select Case zClass
                                Case "VA"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " fails their defensive spell [-vampygazed]" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " fails their defensive spell by " & zPlayerName & " [-vampygazed]" & vbCrLf
                                Case "WE"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " fails their defensive spell [-growled]" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " fails their defensive spell by " & zPlayerName & " [-growled]" & vbCrLf
                                Case "PL"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " fails their defensive spell [-bamboospike]" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " fails their defensive spell by " & zPlayerName & " [-bamboospike]" & vbCrLf
                                Case "CY"
                                    zScript1p = zScript1p & gblzFBBLU & zMobName & " fails their defensive spell [-powerrebooted]" & vbCrLf
                                    zScript3p = zScript3p & gblzFBBLU & zMobName & " fails their defensive spell by " & zPlayerName & " [-powerrebooted]" & vbCrLf
                            End Select
                        Else
                            Select Case lMMobSpellOffensiveNo
                                Case 1 'frost orb
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        lHoldDamage = lRandom(lMLevel + lMLevel) + lMLevel
                                        zScript1p = zScript1p & gblzFBMAG & zMobName & "&c [frostorb] &Yyou " & gblzFBMAG & "in the chest! " & "&R(" & lHoldDamage & ")" & vbCrLf
                                        zScript3p = zScript3p & gblzFBMAG & zMobName & "&c [frostorb] " & gblzFBYEL & zPlayerName & " " & gblzFBMAG & "to the chest! " & "&R(" & lHoldDamage & ")" & vbCrLf
                                        lPlayerDamage = lPlayerDamage + lHoldDamage
                                    End If
                                Case 2 'fireball
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        lHoldDamage = lRandom(lMLevel + lMLevel) + lMLevel
                                        zScript1p = zScript1p & gblzFBMAG & zMobName & "&r" & " [fireballs] &Yyou " & gblzFBMAG & "in the chest! " & "&R(" & lHoldDamage & ")" & vbCrLf
                                        zScript3p = zScript3p & gblzFBMAG & zMobName & "&r" & " [fireballs] " & gblzFBYEL & zPlayerName & " " & gblzFBMAG & "to the chest! " & "&R(" & lHoldDamage & ")" & vbCrLf
                                        lPlayerDamage = lPlayerDamage + lHoldDamage
                                    End If
                                Case 3 'energy blast
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        lHoldDamage = lRandom(lMLevel + lMLevel) + lMLevel
                                        zScript1p = zScript1p & gblzFBMAG & zMobName & "&w" & " [energy-blasts] &Yyou " & gblzFBMAG & "in the chest! " & "&R(" & lHoldDamage & ")" & vbCrLf
                                        zScript3p = zScript3p & gblzFBMAG & zMobName & "&w" & " [energy-blasts] " & gblzFBYEL & zPlayerName & " " & gblzFBMAG & "to the chest! " & "&R(" & lHoldDamage & ")" & vbCrLf
                                        lPlayerDamage = lPlayerDamage + lHoldDamage
                                    End If
                                Case 4 'drain XP
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        zScript1p = zScript1p & "&g" & zMobName & " touches you and drains life &Yfrom you!" & vbCrLf
                                        zScript3p = zScript3p & "&g" & zMobName & " touches and drains life from " & zPlayerName & "!" & vbCrLf
                                        MyDB.Execute "UPDATE tblPlayer SET XP=[XP]-" & (lRandom(lMLevel) * 5) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET XP=1 WHERE (XP<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                    End If
                                Case 5 'drain Soul
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        zScript1p = zScript1p & "&r" & zMobName & " touches you and drains " & "&Rsoul &Yfrom you!" & vbCrLf
                                        zScript3p = zScript3p & "&r" & zMobName & " touches and drains " & "&Rsoul &Yfrom " & zPlayerName & "!" & vbCrLf
                                        MyDB.Execute "UPDATE tblPlayer SET CSoul=[CSoul]-" & (lRandom(lMLevel) * 6) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET CSoul=1 WHERE (CSoul<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                    End If
                                Case 6 'drain Essence
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        zScript1p = zScript1p & "&c" & zMobName & " touches you and drains &Cessence &Yfrom you!" & vbCrLf
                                        zScript3p = zScript3p & "&c" & zMobName & " touches and drains &Cessence &Yfrom " & zPlayerName & "!" & vbCrLf
                                        MyDB.Execute "UPDATE tblPlayer SET CEssence=[CEssence]-" & (lRandom(lMLevel) * 6) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET CEssence=1 WHERE (CEssence<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                    End If
                                Case 7 'drain Mana
                                    lMMana = lMMana - lRandom(16) + 10
                                    If (lMMana < 0) Then lMMana = 0
                                    If (lMMana > 0) Then
                                        zScript1p = zScript1p & "&r" & zMobName & " touches you and drains " & gblzFBMAG & "mana &Yfrom you!" & vbCrLf
                                        zScript3p = zScript3p & "&r" & zMobName & " touches and drains " & gblzFBMAG & "mana &Yfrom " & zPlayerName & "!" & vbCrLf
                                        MyDB.Execute "UPDATE tblPlayer SET CMana=[CMana]-" & (lRandom(lMLevel) * 6) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET CMana=1 WHERE (CMana<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                    End If
                                Case 8 'arrow
                                    lMSoul = lMSoul - lRandom(16) + 10
                                    If (lMSoul < 0) Then lMSoul = 0
                                    If (lMSoul > 0) Then
                                        lHoldDamage = lRandom(lMLevel) + lRandom(lMLevel) + lRandom(lMLevel)
                                        zScript1p = zScript1p & "&y" & zMobName & " shoots you with an arrow!" & vbCrLf
                                        zScript3p = zScript3p & "&y" & zMobName & " shoots an arrow into " & zPlayerName & "!" & vbCrLf
                                        lPlayerDamage = lPlayerDamage + lHoldDamage
                                    End If
                                Case 9 'bolt
                                    lMSoul = lMSoul - lRandom(16) + 10
                                    If (lMSoul < 0) Then lMSoul = 0
                                    If (lMSoul > 0) Then
                                        lHoldDamage = lRandom(lMLevel) + lMLevel
                                        zScript1p = zScript1p & "&y" & zMobName & " shoots you with a bolt!" & vbCrLf
                                        zScript3p = zScript3p & "&y" & zMobName & " shoots a bolt into " & zPlayerName & "!" & vbCrLf
                                        lPlayerDamage = lPlayerDamage + lHoldDamage
                                    End If
                                Case 10 'gernade
                                    If (lRandom(3) = 1) Then
                                        lMSoul = lMSoul - lRandom(16) + 10
                                        If (lMSoul < 0) Then lMSoul = 0
                                        If (lMSoul > 0) Then
                                            lHoldDamage = (lRandom(lMLevel) * 7)
                                            zScript1p = zScript1p & "&r" & zMobName & " tosses a grenade at you and it goes off! (" & lHoldDamage & ")" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " explodes a grenade on " & zPlayerName & "! (" & lHoldDamage & ")" & vbCrLf
                                            lPlayerDamage = lPlayerDamage + lHoldDamage
                                        End If
                                    Else
                                        zScript1p = zScript1p & "&g" & zMobName & " tosses a grenade far past you and misses!" & vbCrLf
                                        zScript3p = zScript3p & "&g" & zMobName & " tosses a grenade far past " & zPlayerName & " and misses!" & vbCrLf
                                    End If
                                Case 11 'bullet
                                    If (lRandom(2) = 1) Then
                                        lMSoul = lMSoul - lRandom(16) + 10
                                        If (lMSoul < 0) Then lMSoul = 0
                                        If (lMSoul > 0) Then
                                            lHoldDamage = (lRandom(lMLevel) * 4)
                                            zScript1p = zScript1p & "&r" & zMobName & " pulls out a gun and shoots you! (" & lHoldDamage & ")" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " pulls out a gun and shoots " & zPlayerName & "! (" & lHoldDamage & ")" & vbCrLf
                                            lPlayerDamage = lPlayerDamage + lHoldDamage
                                        End If
                                    Else
                                        zScript1p = zScript1p & "&g" & zMobName & " pulls out a gun and misses you with a bullet!" & vbCrLf
                                        zScript3p = zScript3p & "&g" & zMobName & " pulls out a gun and fires a bullet at " & zPlayerName & " and misses!" & vbCrLf
                                    End If
                                Case 12 'Uzi
                                    If (lRandom(4) = 1) Then
                                        lMSoul = lMSoul - lRandom(16) + 10
                                        If (lMSoul < 0) Then lMSoul = 0
                                        If (lMSoul > 0) Then
                                            lHoldDamage = (lRandom(lMLevel) * 6)
                                            zScript1p = zScript1p & "&r" & zMobName & " pulls out a Uzi and sprays you with lead! (" & lHoldDamage & ")" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " pulls out a Uzi and sprays " & zPlayerName & " with lead! (" & lHoldDamage & ")" & vbCrLf
                                            lPlayerDamage = lPlayerDamage + lHoldDamage
                                        End If
                                    Else
                                        zScript1p = zScript1p & "&g" & zMobName & " pulls out a Uzi and misses you with a hail of lead!" & vbCrLf
                                        zScript3p = zScript3p & "&g" & zMobName & " pulls out a Uzi and misses " & zPlayerName & " with a hail of lead!" & vbCrLf
                                    End If
                                Case 13 'energy cell
                                    If (lRandom(2) = 1) Then
                                        lMSoul = lMSoul - lRandom(16) + 10
                                        If (lMSoul < 0) Then lMSoul = 0
                                        If (lMSoul > 0) Then
                                            lHoldDamage = (lRandom(lMLevel) * 6)
                                            zScript1p = zScript1p & "&r" & zMobName & " pulls out a energy gun and shoots you with a plasma orb! (" & lHoldDamage & ")" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " pulls out a energy gun and shoots " & zPlayerName & " with a plasma orb! (" & lHoldDamage & ")" & vbCrLf
                                            lPlayerDamage = lPlayerDamage + lHoldDamage
                                        End If
                                    Else
                                        zScript1p = zScript1p & "&g" & zMobName & " pulls out a energy gun and misses you with a static plasma orb!" & vbCrLf
                                        zScript3p = zScript3p & "&g" & zMobName & " pulls out a energy gun and fires a static plasma orb at " & zPlayerName & " and misses!" & vbCrLf
                                    End If
                                Case 14 'energy rifle
                                    If (lRandom(2) = 1) Then
                                        lMSoul = lMSoul - lRandom(16) + 10
                                        If (lMSoul < 0) Then lMSoul = 0
                                        If (lMSoul > 0) Then
                                            lHoldDamage = (lRandom(lMLevel) * 7)
                                            zScript1p = zScript1p & "&r" & zMobName & " pulls out a energy rifle and shoots you with a plasma orb! (" & lHoldDamage & ")" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " pulls out a energy rifle and shoots " & zPlayerName & " with a plasma orb! (" & lHoldDamage & ")" & vbCrLf
                                            lPlayerDamage = lPlayerDamage + lHoldDamage
                                        End If
                                    Else
                                        zScript1p = zScript1p & "&g" & zMobName & " pulls out a energy rifle and misses you with a static plasma orb!" & vbCrLf
                                        zScript3p = zScript3p & "&g" & zMobName & " pulls out a energy rifle and fires a static plasma orb at " & zPlayerName & " and misses!" & vbCrLf
                                    End If
                                Case 15 'bite, drain XP and soul and hp
                                    lMSoul = lMSoul - lRandom(16) + 10
                                    If (lMSoul < 0) Then lMSoul = 0
                                    If (lMSoul > 0) Then
                                        zScript1p = zScript1p & "&r" & zMobName & " bites and drains you!" & vbCrLf
                                        zScript3p = zScript3p & "&r" & zMobName & " bites and drains " & zPlayerName & "!" & vbCrLf
                                        MyDB.Execute "UPDATE tblPlayer SET XP=[XP]-" & (lRandom(lMLevel) * 2) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET XP=1 WHERE (XP<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET CSoul=[CSoul]-" & (lRandom(lMLevel) * 3) & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                        MyDB.Execute "UPDATE tblPlayer SET CSoul=1 WHERE (CSoul<1 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                                        lHoldDamage = (lRandom(lMLevel) * 3)
                                        lPlayerDamage = lPlayerDamage + lHoldDamage
                                    End If
                                Case 16 'zMWeaponType player can use command Disarm
                                    lHoldDamage = lRandom(lMLevel) + lRandom(lMLevel) + lRandom(lMLevel) + lRandom(lMLevel)
                                    zScript1p = zScript1p & "&y" & zMobName & " damages you with the " & zMWeaponName & "!" & vbCrLf
                                    zScript3p = zScript3p & "&y" & zMobName & " damages " & zPlayerName & " with the " & zMWeaponName & "!" & vbCrLf
                                    lPlayerDamage = lPlayerDamage + lHoldDamage
                                Case 17 'poison zMWeaponType
                                    bMPoisonOkay = True
                                    If (zRace = "DRA") Then 'dracs have poison resistance
                                        bMPoisonOkay = (lRandom(60) <= lRandom(100))
                                    End If
                                    If (bMPoisonOkay) Then 'player gets poisoned
                                        lMSoul = lMSoul - lRandom(16) + 10
                                        If (lMSoul < 0) Then lMSoul = 0
                                        If (lMSoul > 0) Then
                                            bPoisoned = True
                                            lHoldDamage = lRandom(lMLevel) + lRandom(lMLevel) + lRandom(lMLevel) + lRandom(lMLevel)
                                            zScript1p = zScript1p & "&y" & zMobName & " poisons you with the " & zMWeaponName & "!" & vbCrLf
                                            zScript3p = zScript3p & "&y" & zMobName & " poisons " & zPlayerName & " with the " & zMWeaponName & "!" & vbCrLf
                                            MyDB.Execute "UPDATE tblPlayer SET PoisionStrength=" & (lRandom(MyCLng(lMLevel / 2)) + MyCLng(lMLevel / 2)) & ", PoisionDuration=" & lRandom(10) + 5 & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            lPlayerDamage = lPlayerDamage + lHoldDamage
                                        End If
                                    End If
                            End Select
                        End If
                    Else
                        zScript1p = zScript1p & gblzFBBLU & zMobName & " is too trapped in the " & zMEntanglementDesc & " to cast an offensive spell!" & vbCrLf
                        zScript3p = zScript3p & gblzFBBLU & zMobName & " is too trapped in the " & zMEntanglementDesc & " to cast an offensive spell!" & vbCrLf
                    End If
                End If
                
                'Mob Disarms player
                If (lMDisarmPlayerChance > 0) Then
                    If (lRandom(lMDisarmPlayerChance) > lRandom(100)) Then
                        If (lMDisarmPlayerChance > lRandom(lRandom(lCDEX) + lRandom(lGrip))) Then
                            subAttackerDisarmsPlayer zMobName, zPlayerName, lPlayerID, lPX, lPY, lPZ, zPortID
                        Else
                            zScript1p = zScript1p & "&y" & zMobName & " fails to disarm you." & vbCrLf
                            zScript3p = zScript3p & "&y" & zMobName & " fails to disarm " & zPlayerName & "." & vbCrLf
                        End If
                    End If
                End If
                
                If (lPBittenDuration = 0) Then
                    If (bMBittenMaster And lRandom(lMLevel) > lRandom(lPlayerLevel)) Then
                        'FlyEnterMsg=flys in from
                        'FlyExitMsg=flys
                        'WalkEnterMsg=arrives from
                        'WalkExitMsg=leaves
                        Select Case zMBittenMobBracketClass
                            Case "VA"
                                bRPEq = True
                                zScript1p = zScript1p & "&a" & zMobName & " *BITES* morphing your class into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                zScript3p = zScript3p & "&a" & zMobName & " *BITES* morphing " & zPlayerName & " into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                MyDB.Execute "UPDATE tblPlayer SET FlyEnterMsg='swoops in from', FlyExitMsg='swoops', WalkEnterMsg='lears in from', WalkExitMsg='lears' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            Case "WE"
                                bRPEq = True
                                zScript1p = zScript1p & "&a" & zMobName & " *BITES* morphing your class into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                zScript3p = zScript3p & "&a" & zMobName & " *BITES* morphing " & zPlayerName & " into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                MyDB.Execute "UPDATE tblPlayer SET FlyEnterMsg='drifts in from', FlyExitMsg='drifts', WalkEnterMsg='pounces in from', WalkExitMsg='pounces' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            Case "PL", "VE"
                                bRPEq = True
                                zMBittenMobBracketClass = "PL"
                                zScript1p = zScript1p & "&a" & zMobName & " *INJECTS SPORES* and morphs your class into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                zScript3p = zScript3p & "&a" & zMobName & " *INJECTS SPORES* morphing " & zPlayerName & " into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                MyDB.Execute "UPDATE tblPlayer SET FlyEnterMsg='soars in from', FlyExitMsg='soars', WalkEnterMsg='roots in from', WalkExitMsg='roots' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                            Case "CY"
                                bRPEq = True
                                zScript1p = zScript1p & "&a" & zMobName & " *INJECTS NANOBOTS* and morphs your class into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                zScript3p = zScript3p & "&a" & zMobName & " *INJECTS NANOBOTS* morphing " & zPlayerName & " into a " & zTranslateClass(zMBittenMobBracketClass) & "!!!" & vbCrLf
                                MyDB.Execute "UPDATE tblPlayer SET FlyEnterMsg='hovers in from', FlyExitMsg='hovers', WalkEnterMsg='stomps in from', WalkExitMsg='stomps off' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        End Select
                        'FlyEnterMsg
                        MyDB.Execute "UPDATE tblPlayer SET BittenDuration=" & (lMLevel * 4) + lRandom(lMLevel * 3) & ", Class='" & zMBittenMobBracketClass & "' WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        'BittenReservedOriginalClass holds the real Class
                    End If
                End If
                                
                'Put up a sanctuary shield
                If (lMSanctuaryChance > 0) Then
                    If (lMSanctuaryDuration = 0) Then
                        If (lRandom(lMSanctuaryChance) = 1) Then
                            If (lMEntanglementDuration = 0) Then
                                MyDB.Execute "UPDATE tblMob SET SanctuaryDuration=" & lRandom(20) + 10 & " WHERE (MobID=" & lMobID & ");", dbFailOnError
                                zScript1p = zScript1p & gblzFBBLU & zMobName & " mutters some magic words." & vbCrLf & "&WAn aura coats around " & zMobName & "!" & vbCrLf
                                zScript3p = zScript3p & gblzFBBLU & zMobName & " mutters some magic words." & vbCrLf & "&WAn aura coats around " & zMobName & "!" & vbCrLf
                            Else
                                zScript1p = zScript1p & gblzFBBLU & zMobName & " is too trapped in the " & zMEntanglementDesc & " to cast a sanctuary spell!" & vbCrLf
                                zScript3p = zScript3p & gblzFBBLU & zMobName & " is too trapped in the " & zMEntanglementDesc & " to cast a sanctuary spell!" & vbCrLf
                            End If
                        End If
                    End If
                End If
                
                'Stun player attempted
                If (lRandom(lMStunRandom) = 1) Then
                    If (lStunDuration = 0) Then
                        If (lRandom(lRandom(lCDEX) + lRandom(lCCon)) < lRandom(lMLevel + lMStunRandom)) Then
                            If (lMBlindDuration = 0) Then
                                If (lMStunDuration = 0) Then
                                    lHoldDamage = (lRandom(3))  'rnds stunned
                                    Select Case lRandom(6)
                                        Case 1 To 2
                                            Select Case zClass
                                                Case "WA", "GL"
                                                    zScript1p = zScript1p & "&y" & zMobName & " tries to stun you but bounces off your brute force!" & vbCrLf
                                                    zScript3p = zScript3p & "&y" & zMobName & " tries to stun " & zPlayerName & " but bounces off " & zTranslateGender(zGender, 2) & " brute force!" & vbCrLf
                                                Case Else
                                                    zScript1p = zScript1p & "&r" & zMobName & " " & zMStunEmoteFirstPerson & " (" & lHoldDamage & " rnds)" & vbCrLf
                                                    zScript3p = zScript3p & "&r" & zMobName & " " & zMStunEmoteThirdPerson & " " & zPlayerName & "! (" & lHoldDamage & " rnds)" & vbCrLf
                                                    MyDB.Execute "UPDATE tblPlayer SET StunDuration=" & lHoldDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            End Select
                                        Case Else
                                            zScript1p = zScript1p & "&r" & zMobName & " " & zMStunEmoteFirstPerson & " (" & lHoldDamage & " rnds)" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " " & zMStunEmoteThirdPerson & " " & zPlayerName & "! (" & lHoldDamage & " rnds)" & vbCrLf
                                            MyDB.Execute "UPDATE tblPlayer SET StunDuration=" & lHoldDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                    End Select
                                Else
                                    zScript1p = zScript1p & "&y" & zMobName & " is trying to get up to stun you!" & vbCrLf
                                    zScript3p = zScript3p & "&y" & zMobName & " is trying to get up to to stun " & zPlayerName & "!" & vbCrLf
                                End If
                            Else
                                zScript1p = zScript1p & "&y" & zMobName & " is trying to wipe away tears to stun you!" & vbCrLf
                                zScript3p = zScript3p & "&y" & zMobName & " is trying to wipe away tears to stun " & zPlayerName & "!" & vbCrLf
                            End If
                        Else
                            zScript1p = zScript1p & "&y" & zMobName & " tries to stun you and misses." & vbCrLf
                            zScript3p = zScript3p & "&y" & zMobName & " tries to stun " & zPlayerName & " and misses." & vbCrLf
                        End If
                    End If
                End If
                
                'Blind player attempted
                If (lRandom(lMBlindRandom) = 1) Then
                    If (lBlindDuration = 0) Then
                        If (lRandom(lRandom(lCDEX) + lRandom(lCCon)) < lRandom(lMLevel) + lMBlindRandom) Then
                            If (lMBlindDuration = 0) Then
                                If (lMStunDuration = 0) Then
                                    lHoldDamage = (lRandom(3))
                                    Select Case lRandom(6)
                                        Case 1 To 2
                                            Select Case zClass
                                                Case "CL", "PA", "BA", "DR", "MO"
                                                    zScript1p = zScript1p & "&y" & zMobName & " is trying to blind you!" & vbCrLf
                                                    zScript3p = zScript3p & "&y" & zMobName & " is trying to blind " & zPlayerName & "!" & vbCrLf
                                                Case Else
                                                    zScript1p = zScript1p & "&r" & zMobName & " " & zMBlindEmoteFirstPerson & " (" & lHoldDamage & " rnds)" & vbCrLf
                                                    zScript3p = zScript3p & "&r" & zMobName & " " & zMBlindEmoteThirdPerson & " " & zPlayerName & "! (" & lHoldDamage & " rnds)" & vbCrLf
                                                    MyDB.Execute "UPDATE tblPlayer SET BlindDuration=" & lHoldDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                            End Select
                                        Case Else
                                            zScript1p = zScript1p & "&r" & zMobName & " " & zMBlindEmoteFirstPerson & " (" & lHoldDamage & " rnds)" & vbCrLf
                                            zScript3p = zScript3p & "&r" & zMobName & " " & zMBlindEmoteThirdPerson & " " & zPlayerName & "! (" & lHoldDamage & " rnds)" & vbCrLf
                                            MyDB.Execute "UPDATE tblPlayer SET BlindDuration=" & lHoldDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                    End Select
                                Else
                                    zScript1p = zScript1p & "&y" & zMobName & " is trying to get up to blind you!" & vbCrLf
                                    zScript3p = zScript3p & "&y" & zMobName & " is trying to get up to blind " & zPlayerName & "!" & vbCrLf
                                End If
                            Else
                                zScript1p = zScript1p & "&y" & zMobName & " is trying to wipe away tears to blind you!" & vbCrLf
                                zScript3p = zScript3p & "&y" & zMobName & " is trying to wipe away tears to blind " & zPlayerName & "!" & vbCrLf
                            End If
                        Else
                            zScript1p = zScript1p & "&y" & zMobName & " tries to blind you and misses." & vbCrLf
                            zScript3p = zScript3p & "&y" & zMobName & " tries to blind " & zPlayerName & " and misses." & vbCrLf
                        End If
                    End If
                End If
                
                'Poison player attempted
                If (Not bPoisoned And lPoisionDuration = 0) Then
                    If (lRandom(lMPoisionChance) = 1) Then
                        bPoisoned = True
                        If (zRace = "DRA") Then
                            If (lRandom(60) > lRandom(100)) Then 'dracs are immune to poison
                                bPoisoned = False
                            End If
                        End If
                        
                        If (bPoisoned) Then
                            zScript1p = zScript1p & "&g" & zMobName & " poisons you!" & vbCrLf
                            zScript3p = zScript3p & "&g" & zMobName & " poisoned " & zPlayerName & "!" & vbCrLf
                            lHoldDamage = lRandom(lMPoisionChance) + 1
                            If (lHoldDamage > 15) Then lHoldDamage = 15 'this would be into the minutes
                            MyDB.Execute "UPDATE tblPlayer SET PoisionStrength=" & lMPoisionStrength & ", PoisionDuration=" & lHoldDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        Else
                            zScript1p = zScript1p & "&gYour anti-venom sacks buried in your scales cures you!" & vbCrLf
                            zScript3p = zScript3p & "&g" & zPlayerName & " resists a poison attack!" & vbCrLf
                        End If
                    End If
                End If
                
                'Player has shields that do damage - shields never kill the mob just weaken it. Easier programming.
                lShieldDefend = 0
                If (lMHP > 1 And lRandom(3) = 1) Then 'if the mob is alive
                    If (lIceshieldDuration > 0) Then
                        lHoldDamage = lRandom(lPlayerLevel) + (lCINT * 2) + lRandom(lCWIS) + lCCHA
                        lHoldDamage = lElementalResistance(lHoldDamage, lMResColdElementalDamage)
                        If (zConfigSpam = "1") Then
                            lShieldDefend = lShieldDefend + 1
                            'zScript1p = zScript1p & "&cYour ice shield freezes " & zMobName & "! " & "&c(" & lHoldDamage & ")" & vbCrLf
                            'zScript3p = zScript3p & "&C" & zPlayerName & "'s ice shield freezes " & zMobName & "! " & "&c(" & lHoldDamage & ")" & vbCrLf
                            zScript1p = zScript1p & "&c(" & lHoldDamage & ") "
                            zScript3p = zScript3p & "&c(" & lHoldDamage & ") "
                        End If
                        lPlayerXPBonus = lPlayerXPBonus + lHoldDamage
                    End If
                    
                    If (lFireshieldDuration > 0) Then
                        lHoldDamage = (lRandom(lPlayerLevel) + (lCINT * 2) + lRandom(lCWIS * 2) + lCCHA) * 2
                        lHoldDamage = lElementalResistance(lHoldDamage, lMResFireElementalDamage)
                        If (zConfigSpam = "1") Then
                            lShieldDefend = lShieldDefend + 1
                            'zScript1p = zScript1p & "&RYour fire shield scorches " & zMobName & "! &r(" & lHoldDamage & ")" & vbCrLf
                            'zScript3p = zScript3p & gblzFBRED & zPlayerName & "'s fire shield scorches " & zMobName & "! &r(" & lHoldDamage & ")" & vbCrLf
                            zScript1p = zScript1p & "&R(" & lHoldDamage & ")"
                            zScript3p = zScript3p & "&R(" & lHoldDamage & ")"
                        End If
                        lPlayerXPBonus = lPlayerXPBonus + lHoldDamage
                    End If
                    
                    If (lChaosshieldDuration > 0) Then
                        lHoldDamage = lRandom(lPlayerLevel) + (lCINT * 2) + lRandom(lCWIS * 2) + lCCHA
                        lHoldDamage = lElementalResistance(lHoldDamage, lMResPhysicalDamage)
                        If (zConfigSpam = "1") Then
                            lShieldDefend = lShieldDefend + 1
                            'zScript1p = zScript1p & "&r" & "Your chaos shield repels " & zMobName & "! (" & lHoldDamage & ")" & vbCrLf
                            'zScript3p = zScript3p & "&r" & zPlayerName & "'s chaos shield repels " & zMobName & "! (" & lHoldDamage & ")" & vbCrLf
                            zScript1p = zScript1p & "&r" & "(" & lHoldDamage & ")"
                            zScript3p = zScript3p & "&r" & "(" & lHoldDamage & ")"
                        End If
                        lPlayerXPBonus = lPlayerXPBonus + lHoldDamage
                    End If
                    
                    If (lStaticshieldDuration > 0) Then
                        lHoldDamage = lRandom(lPlayerLevel) + (lCINT * 2) + lRandom(lCWIS * 2) + lCCHA
                        lHoldDamage = lElementalResistance(lHoldDamage, lMResLightningElementalDamage)
                        If (zConfigSpam = "1") Then
                            lShieldDefend = lShieldDefend + 1
                            'zScript1p = zScript1p & "&w" & "Your static shield zappps " & zMobName & "! (" & lHoldDamage & ")" & vbCrLf
                            'zScript3p = zScript3p & "&w" & zPlayerName & "'s static shield zappps " & zMobName & "! (" & lHoldDamage & ")" & vbCrLf
                            zScript1p = zScript1p & "&w" & "(" & lHoldDamage & ")"
                            zScript3p = zScript3p & "&w" & "(" & lHoldDamage & ")"
                        End If
                        lPlayerXPBonus = lPlayerXPBonus + lHoldDamage
                    End If
                    
                    If (lShieldDefend > 0) Then
                        zScript1p = zScript1p & vbCrLf
                        zScript3p = zScript3p & vbCrLf
                    End If
                End If
                
                If (lPlayerDamage > 0) Then
                    If (zClass = "WE") Then
                        If (lRandom(3) = 1) Then
                            If (zConfigSpam = "1") Then
                                zScript1p = zScript1p & "&aThe natural shadows around you absorbs damage!" & vbCrLf
                                zScript3p = zScript3p & "&aNatural shadows around " & zPlayerName & " absorbs damage!" & vbCrLf
                            End If
                            lPlayerDamage = MyCLng(lPlayerDamage / 2)
                        End If
                    End If
                    
                    If (zClass = "VA") Then
                        If (lRandom(2) = 1) Then
                            If (zConfigSpam = "1") Then
                                zScript1p = zScript1p & "&aYou bite " & zMobName & " in the neck and heal yourself!" & vbCrLf
                                zScript3p = zScript3p & "&a" & zPlayerName & " bites " & zMobName & " in the neck and heals up!" & vbCrLf
                            End If
                            lPlayerDamage = (MyCLng(lPlayerDamage / 2) + MyCLng(lPlayerDamage / 3)) + 2
                        End If
                    End If
                    
                    If (lSanctuaryDuration > 0) Then
                        If (zConfigSpam = "1") Then
                            zScript1p = zScript1p & "&W[sanctuary deflected half damage]" & vbCrLf
                            'zScript3p = zScript3p & "&WIn a &Y -=FLASH=-&W a sanctuary shield around " & zPlayerName & " absorbs damage!" & vbCrLf
                        End If
                        lPlayerDamage = MyCLng(lPlayerDamage / 2) + 2
                    End If
                    
                    'Armour Absorbtion Chance
                    If (lCAC > 0) Then 'the player must have something on
                        zStar = ""
                        lArmourAbsorbtionChance = lClassArmourAbsorbtionChance(zClass) + lRaceArmourAbsorbtionChance(zRace)
                        If (lCAC > lPlayerLevel * cstlPlayerStarAbsCalcu) Then  'bonus for keeping strong armour
                            zStar = zStar & "*"
                        End If
                        If (zRace = "DRA") Then 'bonus for keeping strong armour
                            zStar = zStar & "*"
                        End If
                        If (zClass = "WA") Then  'bonus for keeping strong armour
                            zStar = zStar & "*"
                        End If
                        Select Case Len(zStar) 'bonus percent if both match, warrior draks have nice absorbtion
                            Case 1
                                lArmourAbsorbtionChance = lArmourAbsorbtionChance + lRandom(10)
                            Case 2
                                lArmourAbsorbtionChance = lArmourAbsorbtionChance + lRandom(7) + lRandom(7) + 1
                            Case 3
                                lArmourAbsorbtionChance = lArmourAbsorbtionChance + lRandom(3) + lRandom(3) + lRandom(3) + 6
                        End Select
                        If (lRandom(9) = 1 Or lRandom(lArmourAbsorbtionChance + gbllArmourAbsorbtionChance(lPortID)) > lRandom(100)) Then lArmourAbsorbtionChance = lArmourAbsorbtionChance + gbllArmourAbsorbtionChance(lPortID) 'add in the armour bonus
                        
                        If (lRandom(lArmourAbsorbtionChance) >= lRandom(100)) Then
                            zScript1p = zScript1p & "&w" & "ABS%(" & lArmourAbsorbtionChance & ")"
                            Select Case (lRandom(100) - lRandom(lArmourAbsorbtionChance))
                                Case 11 To 33
                                    zScript1p = zScript1p & "[" & zStar & "third less damage" & zStar & "]" & vbCrLf
                                    lPlayerDamage = (lPlayerDamage - MyCLng(lPlayerDamage / 3)) + 2
                                Case 34 To 100
                                    zScript1p = zScript1p & "[" & zStar & "quarter less damage" & zStar & "]" & vbCrLf
                                    lPlayerDamage = (lPlayerDamage - MyCLng(lPlayerDamage / 4)) + 2
                                Case Else
                                    zScript1p = zScript1p & "[" & zStar & "half damage" & zStar & "]" & vbCrLf
                                    lPlayerDamage = (MyCLng(lPlayerDamage / 2)) + 2
                            End Select
                        End If
                    End If
                End If 'If (lPlayerDamage > 0)
                If (lRandom(lTranslateDurabilityControlRaceClass(zRace, zClass)) = 1) Then subCombatPlayerDurabilityLoss zPortID, lPlayerID, lPlayerDamage, lAlignment, lPX, lPY, lPZ, 350, lMLevel
            'Else
                'zScript1p = zScript1p & vbCrLf & "&c" & zMobName & " misses you!" & vbCrLf
                'zScript3p = zScript3p & vbCrLf & "&c" & zMobName & " misses " & zPlayerName & "!" & vbCrLf
            'End If
            
            If (lPlayerXPBonus > 0) Then
                lMHP = lMHP - lPlayerXPBonus 'cause mob some damage
                MyDB.Execute "UPDATE tblPlayer SET CMove=[CMove]-" & lMoveCostIIAdditional & ", XP=[XP]+" & lPlayerXPBonus & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                lMoveCostIIAdditional = 0
                If (lShieldDefend > 0) Then
                    Select Case (lShieldDefend)
                        Case 1
                            zScript1p = zScript1p & "&a[shield retaliated once for " & lPlayerXPBonus & " damage]" & vbCrLf
                        Case Else
                            zScript1p = zScript1p & "&a[shields retaliated " & lShieldDefend & " times for " & lPlayerXPBonus & " damage]" & vbCrLf
                    End Select
                Else
                    If (Not gblbFilterMode(lPortID)) Then zScript1p = zScript1p & "&a" & lPlayerXPBonus & " Bonus XP " & vbCrLf
                End If
            End If
            
            If (lMHP <> lMHPMAX) Then
                If (lMHP < 1) Then lMHP = 1 'we dont kill mobs off with shields
                MyDB.Execute "UPDATE tblMob SET MHP=" & lMHP & " WHERE (MobID=" & lMobID & ");", dbFailOnError
            End If
        End If
                
        If (lPlayerDamage > 0) Then 'then player was hit
            bHPShieldUpdated = False
            If (lManashieldDuration > 0) Then
                lManashieldTotal = MyCLng(lPlayerDamage / 2)
                If (lManashieldTotal <= lCMana) Then
                    bHPShieldUpdated = True
                    lPlayerDamage = lManashieldTotal
                    lCMana = lCMana - lManashieldTotal
                Else
                    If (lRandom(999) = 1) Then 'manashield can overload
                        MyDB.Execute "UPDATE tblPlayer SET CMana=1, ManashieldDuration=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        zScript1p = zScript1p & "&R[-Manaoverload]" & vbCrLf
                    End If
                End If
            End If
            If (lSoulshieldDuration > 0) Then
                lSoulshieldTotal = MyCLng(lPlayerDamage / 2)
                If (lSoulshieldTotal <= lCSoul) Then
                    bHPShieldUpdated = True
                    lPlayerDamage = lSoulshieldTotal
                    lCSoul = lCSoul - lSoulshieldTotal
                Else
                    If (lRandom(999) = 1) Then 'soulshield can overload
                        MyDB.Execute "UPDATE tblPlayer SET CSoul=1, SoulshieldDuration=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                        zScript1p = zScript1p & "&R[-Souloverload]" & vbCrLf
                    End If
                End If
            End If
            If (bHPShieldUpdated) Then
                MyDB.Execute "UPDATE tblPlayer SET CMana=" & lCMana & ", CSoul=" & lCSoul & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            End If
            If ((lCHP - lPlayerDamage) < 1) Then 'Player Died
                If (lQuestMobID = lMobID And cstbCanFailQuest) Then
                    'player looses thief quest to their quest mob
                    MyDB.Execute "UPDATE tblPlayer SET QuestMobID=0, CHP=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                    MyDB.Execute "UPDATE tblPlayer SET QuestDuration=300 WHERE (QuestDuration>300 AND PlayerID=" & lPlayerID & ");", dbFailOnError
                    MyDB.Execute "UPDATE tblMob SET QuestPlayerID=0 WHERE (MobID=" & lQuestMobID & ");", dbFailOnError
                    MyDB.Execute "DELETE PlayerID FROM tblMobQuestMaster WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                    zScript1p = zScript1p & "&RYou *F A I L E D* your quest!" & vbCrLf
                Else
                    MyDB.Execute "UPDATE tblPlayer SET CHP=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                End If
                
                bPlayerDied = True
                If (lPlayerLevel < 26) Then zScript1p = zScript1p & zReturnPlayerLevelAscii(25) & " &RTip&r: &YKeep mo&gv&Yement points above &Rhalf" & vbCrLf
                
                If (lPlayerLevel > 39 And lParryXP + lDodgeXP > 0) Then 'they loose all their dodge or parry xp
                    Select Case lRandom(25) 'the random also has to go with the correct XP>0 and match its rnd number
                        Case 1, 3, 5, 10, 13
                            If (lDodgeXP > 0) Then
                                lDodgeXP = 0
                                MyDB.Execute "UPDATE tblPlayer SET DodgeXP=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                zScript1p = zScript1p & "&RBAD LUCK! You lost all your gained dodge experience in the death!" & vbCrLf
                            End If
                        Case 18, 20
                            If (lParryXP > 0) Then
                                lParryXP = 0
                                MyDB.Execute "UPDATE tblPlayer SET ParryXP=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError 'we level Parry
                                zScript1p = zScript1p & "&RBAD LUCK! You lost all your gained parry experience in the death!" & vbCrLf
                            End If
                    End Select
                End If
                
                zScript3p = zScript3p & gblzFBRED & zPlayerName & " was killed by " & zMobName & "!" & vbCrLf
                
                bEndCombat = True 'we end the combat
                'The mob no longer finds the need to kill this player
                If (Len(zDefeatedMobDesc) = 0) Then
                    MyDB.Execute "UPDATE tblMob SET DefeatedMobDesc='is dragging around the corpse of " & zKeepLettersOnly(zPlayerName) & "', PlayerID=0 WHERE (MobID=" & lMobID & ");", dbFailOnError
                Else
                    MyDB.Execute "UPDATE tblMob SET PlayerID=0 WHERE (MobID=" & lMobID & ");", dbFailOnError
                End If
                
                subCombatCreatePlayerCrossOnGround zPlayerName, zMobName, lPX, lPY, lPZ
                If (lPlayerLevel > 29) Then 'we dont want people making characters and just dieing to give it to their other characters
                    If (lGold > 0) Then
                        If (Not bPartOfAuction(zPortID, lPlayerID)) Then
                            subDropGold MyCStr(lGold) & " gold left behind by " & zPlayerName, lPlayerID, lPX, lPY, lPZ, lGold
                        End If
                    End If
                End If
            Else
                MyDB.Execute "UPDATE tblPlayer SET CHP=[CHP]-" & lPlayerDamage & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            End If
        End If
        
        MyDB.Execute "UPDATE tblMob SET Soul=" & lMSoul & ", Mana=" & lMMana & ", Essence=" & lMEssence & " WHERE (MobID=" & lMobID & ");", dbFailOnError
        
        'Print all script
        If (Len(zScript1p) <> 0) Then subSendMsg zTrimCrLf(zScript1p), zPortID
        If (Len(zScript3p) <> 0) Then subSendMsgAreaExcept2 zTrimCrLf(zScript3p), lPX, lPY, lPZ, zPortID, ""
        
        If (bPlayerDied) Then
            If (Len(zDefeatedMobDesc) = 0) Then 'we dont want to spam death messages
                Select Case lRandom(8) 'Global INFO Message
                    Case 1
                        subSendMsgInfoChannel "&w" & zPlayerName & " lost to " & zMobName & "!"
                    Case 2
                        subSendMsgInfoChannel "&w" & zPlayerName & " died by the hand of " & zMobName & "!"
                    Case 3
                        subSendMsgInfoChannel "&w" & zPlayerName & " got spanked by " & zMobName & "!"
                    Case 4
                        subSendMsgInfoChannel "&w" & zPlayerName & " is slain by " & zMobName & "!"
                    Case Else 'variety
                        zMobKillPlayerDesc = basReplaceCharWithThisWord(zMobKillPlayerDesc, "%s1", zPlayerName)
                        zMobKillPlayerDesc = basReplaceCharWithThisWord(zMobKillPlayerDesc, "%s2", zMobName)
                        zMobKillPlayerDesc = basReplaceCharWithThisWord(zMobKillPlayerDesc, "*", vbCrLf)
                        
                        subSendMsgInfoChannel "&w" & zMobKillPlayerDesc 'double messages
                End Select
            End If
            subCombatPlayerDiedReset zMobName, lPlayerID 'Reset player to death x y z location.
        End If
    End If
    If (bRPEq) Then subRecalculatePlayerEquipment lPlayerID, zPortID
    
    bCombatMvP = bEndCombat
    Exit Function
Err_Check:
    subWriteErrorFile "bCombatMvP," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
