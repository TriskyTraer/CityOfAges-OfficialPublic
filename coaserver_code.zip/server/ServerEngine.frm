VERSION 5.00
Begin VB.Form frmTelnetServerEngine 
   BackColor       =   &H00C0C0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Engine"
   ClientHeight    =   2430
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   3225
   ControlBox      =   0   'False
   Icon            =   "ServerEngine.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MDIChild        =   -1  'True
   MinButton       =   0   'False
   ScaleHeight     =   2430
   ScaleWidth      =   3225
   Begin VB.PictureBox picContainer 
      Appearance      =   0  'Flat
      BackColor       =   &H00808080&
      ForeColor       =   &H80000008&
      Height          =   2295
      Left            =   0
      ScaleHeight     =   2265
      ScaleWidth      =   3225
      TabIndex        =   0
      Top             =   0
      Width           =   3255
      Begin VB.CheckBox chkMode 
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         Caption         =   "1"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   2760
         Style           =   1  'Graphical
         TabIndex        =   9
         ToolTipText     =   "Mode 1 [normal] Mode 2 [less constrictions less mob movement merchant always open stock market doesnt consider player items worn]"
         Top             =   960
         Width           =   495
      End
      Begin VB.TextBox txtWearItemMAX 
         Appearance      =   0  'Flat
         Height          =   285
         Left            =   2400
         MaxLength       =   2
         TabIndex        =   8
         Text            =   "20"
         ToolTipText     =   "Wear command setting 5-25 bonus items wearable or 52 for full access faster too"
         Top             =   960
         Width           =   375
      End
      Begin VB.CheckBox chkLastPlayedActive 
         Appearance      =   0  'Flat
         BackColor       =   &H00E0E0E0&
         Caption         =   "Turn on for Name auto delete by date"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   7
         ToolTipText     =   "Check to turn on the systems ability to clear out non playing characters, 33*level."
         Top             =   1440
         Width           =   3255
      End
      Begin VB.CheckBox chkAutoReboot 
         Appearance      =   0  'Flat
         BackColor       =   &H00E0E0E0&
         Caption         =   "Turn on activates auto DefCON reboot"
         ForeColor       =   &H80000008&
         Height          =   195
         Left            =   0
         TabIndex        =   6
         ToolTipText     =   "Turn on to allow DefCON to ACTUALLY reboot the system for you."
         Top             =   760
         Width           =   3255
      End
      Begin VB.CheckBox chkServerSteroids 
         Appearance      =   0  'Flat
         BackColor       =   &H00E0E0E0&
         Caption         =   "Turn on for Server Steroids"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   5
         ToolTipText     =   "This adds DoEvents to a few key spots, maintimer, mobmovement, and another few. Turn on for Server Steroids"
         Top             =   960
         Value           =   1  'Checked
         Width           =   2415
      End
      Begin VB.Timer ctlBattleTimer 
         Interval        =   1650
         Left            =   2760
         Top             =   360
      End
      Begin VB.Timer ctlTimer 
         Interval        =   10000
         Left            =   120
         Top             =   360
      End
      Begin VB.Timer ctlCountdownTimer 
         Interval        =   5000
         Left            =   2400
         Top             =   360
      End
      Begin VB.Timer tmrDurations 
         Interval        =   3000
         Left            =   2040
         Top             =   360
      End
      Begin VB.Timer tmrMobMove 
         Interval        =   29000
         Left            =   600
         Top             =   360
      End
      Begin VB.CheckBox chkFilterPlayerNames 
         Appearance      =   0  'Flat
         BackColor       =   &H00E0E0E0&
         Caption         =   "Turn on for login Name Filter"
         ForeColor       =   &H80000008&
         Height          =   255
         Left            =   0
         TabIndex        =   1
         ToolTipText     =   "Check to turn on the name filter at the login."
         Top             =   1200
         Value           =   1  'Checked
         Width           =   3255
      End
      Begin VB.Label lblMsg 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H00C0C0C0&
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H80000008&
         Height          =   375
         Left            =   0
         TabIndex        =   4
         Top             =   240
         Width           =   3255
      End
      Begin VB.Label lblSystemStatus 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000002&
         BorderStyle     =   1  'Fixed Single
         Caption         =   "Awake"
         ForeColor       =   &H80000004&
         Height          =   375
         Left            =   0
         TabIndex        =   3
         Top             =   1920
         Width           =   3255
      End
      Begin VB.Label lblSystemErrors 
         Alignment       =   2  'Center
         Appearance      =   0  'Flat
         BackColor       =   &H80000005&
         BorderStyle     =   1  'Fixed Single
         Caption         =   "...one moment..."
         ForeColor       =   &H00008080&
         Height          =   255
         Left            =   0
         TabIndex        =   2
         Top             =   0
         Width           =   3255
      End
   End
End
Attribute VB_Name = "frmTelnetServerEngine"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub subInitsubRecalculatePlayerEquipment()
On Error Resume Next
    Dim iIndex As Integer 'see also subRecalculatePlayerEquipment lPlayerID, zPortID
    For iIndex = cstlMinPort To cstlMaxPort
        gbllRecalculatedDelay(iIndex) = -1 '-1 means its loaded for a countdown duration
    Next iIndex
End Sub
Private Sub chkAutoReboot_Click()
    gblbAllowAutoRebooting = (frmTelnetServerEngine!chkAutoReboot.Value <> 0)
End Sub
Private Sub chkFilterPlayerNames_Click()
    gblbFilterPlayerNames = (frmTelnetServerEngine!chkFilterPlayerNames.Value <> 0)
    'If gblbFilterPlayerNames Then MsgBox "Player Filter is now ON and ACTIVE, no more rude character names.", vbOKOnly
End Sub
Private Sub chkLastPlayedActive_Click()
    gblbLastPlayedActive = (frmTelnetServerEngine!chkLastPlayedActive.Value <> 0)
End Sub
Private Sub chkMode_Click()
    gblbMOBINTELLIGENCEMODE = True
    If gblConstructorlMode = 2 Then
        gblConstructorlMode = 1 'This affects the constructor system
        gblbMOBINTELLIGENCEMODE = False
    Else
        gblConstructorlMode = 2
    End If
    chkMode.Caption = gblConstructorlMode
End Sub
Private Sub chkServerSteroids_Click()
    gblbServerSteroid = (frmTelnetServerEngine!chkServerSteroids.Value <> 0)
End Sub

Private Sub ctlTimer_Timer()
'this activates every few seconds
On Error GoTo Err_Check
    Dim lResult As Long

    ctlTimer.Interval = 0 'interval default is set to 10000
    'subTimedBackUpNoErrors
    If (Not gblbServerWillBeRightBack) Then
        If (Not gblbTiming) Then
            gblbTiming = True 'when we are timing we are doing something - True = we pause the timers
            
            gbllSystemCleanHouse = gbllSystemCleanHouse + 1 '2000 is about 5 hours
            If (gbllSystemCleanHouse > gblcstlSystemCleanHouse) Then gbllSystemCleanHouse = 0
            If (gbllDefcon > -1 And gbllPosted <> gbllDefcon) Then
                gbllPosted = gbllDefcon
                If (Not gblbSkip) Then
                    Select Case gbllDefcon
                        Case 0
                            If (gblbAllowAutoRebooting) Then subSendMsgInfoChannel "&WS&wystem &WN&wotice, lag from hardware detected."
                        Case 1
                            If (gblbAllowAutoRebooting) Then subSendMsgInfoChannel "&WS&wystem &WN&wotice, lag from hardware detected. Moving to DefCON 9"
                        Case 2
                            If (gblbAllowAutoRebooting) Then subSendMsgInfoChannel "&WS&wystem &WN&wotice, the MUD is holding at DefCON 8"
                        Case 3
                            If (gblbAllowAutoRebooting) Then subSendMsgInfoChannel "&WS&wystem &WN&wotice, the MUD is holding at DefCON 7"
                        Case 4
                            subSendMsgInfoChannel "&WS&wystem &WN&wotice, the MUD is holding at DefCON 6"
                        Case 5
                            subSendMsgInfoChannel "&WS&wystem &WN&wotice, the MUD is holding at DefCON 5"
                        Case 6
                            subSendMsgInfoChannel "&WS&wystem &WN&wotice, the MUD is holding at DefCON 4"
                        Case 7
                            If (gblbAllowAutoRebooting) Then subSimpleEchoChannel "&gINFO&G: &WS&wystem *HIGH-ALERT* &WN&wotice, 3 minutes to midnight!"
                        Case 8
                            If (gblbAllowAutoRebooting) Then subSimpleEchoChannel "&gINFO&G: &WS&wystem *HIGH-ALERT* &WN&wotice, 2 minutes to midnight!"
                        Case 9
                            If (gblbAllowAutoRebooting) Then subSimpleEchoChannel "&gINFO&G: &WS&wystem *WAR* &WN&wotice, MUD SELF PRESERVATION MODE INITIATED!"
                        Case 10 'execute reboot if gblbAllowAutoRebooting allows it
                            If (gblbAllowAutoRebooting) Then
                                subSimpleEchoChannel "&gN E W C L E A R Buuumbs L U N C H E D ! Flee Flied Lice, C U SPOON!"
                                basDelay 1000
                                subProcessCMD "shutdown.exe /r /t 0"
                                basDelay 1000
                                lResult = ExitWindowsEx(EWX_REBOOT, 0&) 'restart the computer
                                basDelay 1000
                                gbllDefcon = 1 'in case of failure try again
                            Else
                                subSimpleEchoChannel "&gNo fuel for the nuclear missiles?! ABORT! ABORT this ALERT!"
                                gbllDefcon = -1
                                gbllPosted = 0
                                gblbSkip = False
                            End If
                            
                        Case Else 'haywire then we stop n kill defcon count
                            gbllDefcon = -1
                            gbllPosted = 0
                            gblbSkip = False
                    End Select
                End If
            Else 'try to disarm the bomb
                If (gbllDefcon > -1) Then
                    If (lRandom(200) = 1) Then
                        gbllDefcon = gbllDefcon - 1
                        If (gbllDefcon = -1) Then subSendMsgInfoChannel "&WS&wystem &WN&wotice :: DefCON :: DISARMED!"
                        gblbSkip = (gbllDefcon <> -1)
                    End If
                End If
            End If
            
            If (gblbSystemAwake) Then
                If (gblbOnline) Then 'each 10 seconds
                    If (gblbServerSteroid) Then DoEvents 'SUBLOOPSystem-Tick[
                    gblzLagTimerA = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                    subRotateAreaTransit 'always move the boats 1 sec
                    Select Case gbllSystemCleanHouse ' let 1 to 97 warm up the server
                        Case 50
                            'the mud plays gAWd - with the mobs sometimes
                            If (lRandom(999999) = 1) Then
                                subSendMsgInfoChannel "&WS&wystem &WC&wlean up...&a(full mobile respawn reset)"
                                MyDB.Execute "UPDATE tblMob SET RespawnDelay=1;", dbFailOnError 'totally randomly we just reset everything - who knows maybe the releam needs a miracle once in a while
                            End If
                        Case 98
                            subSendMsgInfoChannel "&WS&wystem &WC&wlean up...&a(ground items)"
                        Case 99
                            subHandleGroundObjects
                        Case 200 'let the system run for a bit before a clean up
                            subSendMsgInfoChannel "&WS&wystem &WC&wlean up...&a(expiry dates)"
                        Case 201 'the actual clean up
                            subSystemWideUnclanByDate 'we automatically remove people from a clan if they are not playing at least once every so many days
                            subSystemWideDeleteMyselfForeverByDate 'Every 8 hours we delete inactive players when last played days is > level * 4 days.
                            subSystemWideUnDoCompleteBanByDate 'Old completely banned remote host ips that has past a 90min are deleted
                        Case Else 'normal game functions run again
                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                lResult = DateDiff("s", gblzLagTimerA, gblzLagTimerB)
                                If (lResult > 6) Then 'really laggy server is about 6
                                    subSystemMessageToImmortals gblzFNRED & "(EAR) &RN-STARTa: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    lResult = MyCLng(lResult / 5)
                                    If (lResult > 3) Then lResult = 3
                                    gbllDefcon = gbllDefcon + lResult
                                    If (gbllDefcon > 10) Then gbllDefcon = 10
                                    gblbSkip = False
                                End If
                            End If
                            subAreaTransferXYZ
                            If lRandom(2) = 1 Then subAreaHealStrength 'Heal player in the area
                            subArmageddonRealmQuest 3000
                            subShowtime 4000
                            subHarassANearbyRandomPlayer 320
                            
                            If (lRandom(20) = 1) Then subSpecialYearlyEvents "", 0, 0, 0, True
                            
                            subPlayerRegainSystems '1sec 'Hp Essence Mana Soul Movement points all go up here depending on the player's status.
                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 3) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN-STARTb: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                            End If
                            subCheckAndRunVote '1sec
                            
                            If lRandom(7) = 1 Then subRotateObjectTransit
                            
                            subHorseRaces
                            subRouletteTableRoll
                            
                            subSpecialSelfObjectMagic
                            subSpecialSelfDeletingObject
                            
                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN-STARTc: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                            End If
                            basRestAttackLevel
                            'sometimes ticking - Move these up into the new case statement
                            gbllSystemTick = gbllSystemTick + 1
                            Select Case gbllSystemTick
                                Case 1 To 15 'N2a (mob pathing) and N7 (recorded start) are the worst areas dec 2021 results
                                    Select Case gbllSystemTick
                                        Case 3, 8, 13, 14
                                            If (lRandom(7) = 1) Then subPandemicCheck
                                            subQuestGuardAreaID 99, False
                                            
                                            If lRandom(2) = 1 Then subWeaponsBoom
                                            If lRandom(2) = 1 Then subStargateDurations '1sec
                                            If lRandom(4) = 1 Then subWeatherCondition
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 3) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN1: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                            If lRandom(3) = 1 Then subRotateTheWorldLessOften
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN2a: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                            If lRandom(7) = 1 Then subColonistsBurnDown
                                            If lRandom(13) = 1 Then subAreaDurationCountdown 'witchlocks only right now
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN2b: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                    End Select
                                    
                                    Select Case gbllSystemTick
                                        Case 2, 4, 6, 8, 10, 12
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            subRunMobFacings 9
                                            'ATMOz check
                                            If (gbllAtmosphereStaticCharges > 0) Then
                                                subLightningBoltARandomPlayer False
                                                If (lRandom(9) > 2) Then gbllAtmosphereStaticCharges = gbllAtmosphereStaticCharges - lRandom(9)
                                                If (lRandom(3333) = 1) Then
                                                    'causes myst to change
                                                    subSendMsgInfoChannel "&cthe &CMyst &Rlo&rvi&Rngly &ccirculates&C over the &Catmo&Bzp&chericz&C."
                                                    gbllAtmosphereStaticCharges = 0 'grounds out
                                                End If
                                            End If
                                            If (gbllAtmosphereStaticCharges < 0) Then gbllAtmosphereStaticCharges = 0
                                            
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN5: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                            subRotateMobSpeak 0, 0, 0, False
                                            subDoorDurationCountdown
                                            subFishingDurationAllowed
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN6: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                        Case 1, 5, 7, 9, 11, 13
                                            subShowOnForm
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN3: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                            subRotateTheWorld 'can take awhile to execute see also subRotateTheWorldEverything
                                            gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                            If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                                If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN4: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                            End If
                                    End Select
                                    
                                    If (lRandom(9) > 2) Then 'MAKE REALM come ALIVE
                                        subCheckCovens 22
                                        
                                        subSafariBecon 70, False
                                        
                                        subSafariLeap 95, False
                                        
                                        subUFOAbduction 69, False
                                        If (bRegularMerchantDayTime()) Then
                                            subMobEquipmentStealsFromPlayerInventory 50
                                        Else
                                            subMobEquipmentStealsFromPlayerInventory 9
                                        End If
                                    End If
                                Case 16 'every 8 mins, world rotations help to reduce lag by quite a bit
                                    'If (lRandom(10) = 1) Then subIndicatePlayerWhereWithFlags ""
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 2) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN7: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    lblMsg.Caption = "world rotated step 1/3"
                                    If lRandom(8) = 1 Then subDisconnectMASSIVELYIGNOREDPlayers
                                    subStarshipMobshipNewNavigation 6
                                    subRotateObjectContainerRespawn 'this should be placed somewhere where it takes an hour to repopulate, like here plus the respawn time is 3, so 3 * 15 = 45 mins.
                                    subGuessWordRandomize 170
                                    subSmeagolAnkhs 375
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN7: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subTryToSendInfoLine 99
                                    subSelfDeletingObjectsAndObjectPortals
                                    subRandomPrintAnAsciiPicture 350
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN9: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subGrowFactionAreas 9
                                    subGRAMMARLYIncorrectTIME 700
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 6) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN10: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                Case 17 'each 3 mins
                                    lblMsg.Caption = "world rotated step 2/3"
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 3) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN11: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subSeeIfAMobThumpsANewDefeatedMobDesc 0, 0
                                    subSeeIfWePlantAGlorySelfDeletingOriginalMob 50
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN12: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subPlantAThiefChestOfGlory 60
                                    subFactionGeneration 3
                                    'subFactionRealmWin 99
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN13: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subColonistsPayPlayerTax 20
                                    subCorpseRottingRounds
                                    subStarshipNebulaRoast 1
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 6) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN14: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                Case 18
                                    basEQAffectsMovebyLevel
                                    gbllSystemTick = 0
                                    lblMsg.Caption = "world rotated step 3/3"
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 3) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN15: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    'subUpdateFTPHTML 1, True
                                    subFishingPondsRefresh
                                    subMobRegainSystems
                                    subFlyingBirdReality 199
                                    subEarthQuake 520
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 4) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN16: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subSeeIfWePlantAGloryItem 30
                                    subSeeIfRealmHealsEveryone 35
                                    subSystemColonistWeeklyWinner
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 5) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN17: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    If (lRandom(5) = 1) Then
                                        If (bActivate6pmSequence()) Then
                                            subREPORTCHECKS
                                        End If
                                    End If
                                    If lRandom(5) = 1 Then subAddMenToColonizies
                                    subAddColonistHostileForces 777 'everyone hates this one cuz it destroies your colonists
                                    subStarshipMobshipQuest 100
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 6) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN18: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    subSpeakOnTheAir
                                    subChanceForARaid 210
                                    subCheckMobSpaceShipFireOnPlayer 90
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 7) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN19: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                                    If (lRandom(333) = 1) Then subReturnGuardsPosition
                                    If (lRandom(20) = 1) Then subSystemWideUnDoCompleteBanByDate 'Old completely banned remote host ips that has past a week are deleted
                                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 7) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN20: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                                    End If
                            End Select
                            
                            If (gbliDayCodeTick <> iDayCode()) Then 'checks every 30 seconds
                                gbliDayCodeTick = iDayCode()
                                subSendWhereMessageAllPlayers
                            End If
                    End Select
                    gblzLagTimerB = Format(Now(), "mmm dd, yyyy hh:nn:ss")
                    If Len(gblzLagTimerA) > 0 And Len(gblzLagTimerB) > 0 Then
                        If (DateDiff("s", gblzLagTimerA, gblzLagTimerB) > 8) Then subSystemMessageToImmortals gblzFNRED & "(EAR) &RN-END: LAG SPIKE [" & DateDiff("s", gblzLagTimerA, gblzLagTimerB) & "secs] SUBLOOPSystem-Tick[" & gbllSystemTick & "] MAINLOOPClean-House[" & gbllSystemCleanHouse & "]", 1 '9+ seconds
                    End If
                End If
            End If
            gblbTiming = False
        End If
    Else
        Me.lblMsg.Caption = "ports locked...reset realm button"
    End If
    ctlTimer.Interval = 10000
    Exit Sub
Err_Check:
    subWriteErrorFile "ctlTimer_Timer::Engine Timing Error," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub Form_Load()
On Error GoTo Err_Check
    Dim iCount As Integer
    subAutomaticallyReconfigure
    subInitCombat
    gbllSystemCleanHouse = 0
    gbllDefcon = -1
    cstdtActivate6pmSequence = Format(Now(), "mmm dd, yyyy 20:59") 'each 24hrs this goes off, helps to compile reports
    gblbRealmAdditionalMoveCosts = True
    gblbMOBINTELLIGENCEMODE = True
    gbllWITCHLOCKDuration = 0
    gbllWITCHLOCKPlayerID = 0
    gbllQuestShowtimeDuration = 0
    gbllAtmosphereStaticCharges = 0
    cstAtmozDefault = 100
    lgblCompletelyBannedMAX = 15
    gbllImmortalPortEAR = 5 'max
    gbllCLOUDX1 = -10
    gbllCLOUDY1 = -10
    gbllCLOUDZ1 = -10
    gbllCLOUDX2 = 10
    gbllCLOUDY2 = 10
    gbllCLOUDZ2 = 10
    gbllWearItemMAX = MyCLng(txtWearItemMAX.Text) '52 is the MAX in the game, so add 20 plus race and class bonus
    gbllWearItemMAXAdmin = gbllWearItemMAX
    gbliMinutes = 0
    gbllSystemTick = 0
    gbliDayCodeTick = 0 'We want to trigger this right away
    gbllClearObjects = 0
    gbllFailedBackUps = 0
    'init. port variables
    For iCount = cstlMinPort To cstlMaxPort
        gbliFlow(iCount) = 0
        gblbTimerAvailable(iCount) = True
    Next iCount
    
    'basic start setup
    gblbFilterPlayerNames = (MyCLng(zSystemConfig(200)) <> 0)

    gblbOnline = True
    Me.lblMsg.BackColor = &HC0FFC0
    DoEvents
    Me.lblMsg.Caption = "opening ports..."
    DoEvents
    gblbServerSteroid = (frmTelnetServerEngine!chkServerSteroids.Value <> 0)
    gblbFilterPlayerNames = (frmTelnetServerEngine!chkFilterPlayerNames.Value <> 0)
    gblbServerWillBeRightBack = False 'turn the system back on
    
    subInitializeAnsiGraphics
    'Load port controls
    gblbConfig103 = MyCLng(zSystemConfig(103))
    gblbConfig104 = MyCLng(zSystemConfig(104))
    gblbConfig105 = MyCLng(zSystemConfig(105))
    gblbFilterPlayerNames = (MyCLng(zSystemConfig(200)) <> 0)
    subReloadPortControls
    Me.lblMsg.Caption = "ports online"
    DoEvents
    subAreasCleanOddLevels
    subCalculatePlayerStockID
    subInitsubRecalculatePlayerEquipment
    Exit Sub
Err_Check:
    subWriteErrorFile "Engine Ignition: Error," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub Form_Unload(Cancel As Integer)
On Error GoTo Err_Check
    gblbOnline = False
    Me.lblMsg.BackColor = &HFF&
    Me.Caption = "* * * * * *"
    Me.lblMsg.Caption = "closing ports..."
    'ctlTimer.Interval = 0 'Shut down timer engine
    'DoEvents
    subShutdownPorts "2011", "2012", "2013", "2014", "2015", "2016", "2017", "2018", "2019", "2020", "2021", "2022", "23", "2023", "2024", "2025", "2026", "2027", "2028", "2029", "2030", "2031", "2032", "2033", "2034", "2035", "2036", "2037", "2038", "2039", "2040", "2041", "2042", "2043", "2044", "2045", "2046", "2047", "2048", "2049", "2050", "2051", "2052", "2053", "2054", "2055", "2056", "2057", "4000", MyCStr(gbllDynamicPortID2) 'TRISKER WORK 4000 is a dynamic port now
    mdiMainMenu!lstErrorMsgs.Clear
    Exit Sub
Err_Check:
    subWriteErrorFile "Engine IgnitiOn Form_Unload Error," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub ctlBattleTimer_Timer()
On Error GoTo Err_Check
    Dim iCount As Integer
    'basRestAttackLevel
    ctlBattleTimer.Interval = 0 'Disable the timer till we are done calculating all the fighting
    If (Not gblbTiming) Then
        gblbTiming = True
    
        Select Case gblbSystemAwake 'We show the status
            Case False
                If (lblSystemStatus.Caption <> "Asleep") Then
                    lblSystemStatus.Caption = "Asleep"
                    mdiMainMenu.Caption = "Asleep"
                    
                    'we disconnect the database (not added for speed)
                    'MyDB.Close
                    'Set gblDB = Nothing
                    
                    'then we now compact and repair to make the system faster
                End If
            Case Else 'true
                If (lblSystemStatus.Caption <> "Active") Then
                    lblSystemStatus.Caption = "Active"
                    mdiMainMenu.Caption = "Active"
                    'If (gblDB Is Nothing) Then basStoreMDBLocationToMemory()
                End If
        End Select
        If (Not gblbServerWillBeRightBack) Then
            If (gblbSystemAwake) Then
                subCountdownDurations 'all of the system subPlayerDurationCountdown can we switched over to this faster method
                subCombatInTheRealm
                subArcadeEngine
            End If
        End If
        gblbTiming = False
    End If
    
    ctlBattleTimer.Interval = 1500 'we are done reactivate the timer
    Exit Sub
Err_Check:
    subWriteErrorFile "ctlBattleTimer_Timer: Engine Battle Error," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub ctlCountdownTimer_Timer()
On Error GoTo Err_Check
    Dim iCount As Integer
    'Reload port controls
    subReloadPortControls
    
    ctlCountdownTimer.Interval = 0 'Disable the timer till we are done calculating all the fighting
    If (Not gblbTiming) Then
        gblbTiming = True 'turn off all the timers
        If (Not gblbServerWillBeRightBack) Then
            If (gblbSystemAwake) Then
                subMoveMobtoXYZWhereID
                subMobHuntFleeingPlayer
                subPlayerNeedsAir
                subStarshipMovement
                subStarshipMovementMines
                subSpellAngerMobileVSMobile 5500
            End If
        End If
        gblbTiming = False
    End If
    ctlCountdownTimer.Interval = 5000 'we are done reactivate the timer
    Exit Sub
Err_Check:
    subWriteErrorFile "ctlCountdownTimer: Engine Battle Error," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subSystemWideUnclanByDate()
'we automatically remove people from a clan if they are not playing at least once every so many days
On Error GoTo Err_Check
    MyDB.Execute "UPDATE tblPlayer SET tblPlayer.ClanID = 0, tblPlayer.ClanMemberLevel = 0 WHERE (((DateDiff('d',[LastPlayed],Date()))>" & cstlRankLost & ") AND ((tblPlayer.ClanID)>0));", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subSystemWideUnclanByDate," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub

Private Sub subReturnGuardsPosition()
On Error GoTo Err_Check
    'respawn all guards
    MyDB.Execute "UPDATE tblMob SET RespawnDelay=1 WHERE lcase(MOBname) LIKE '*guard*';", dbFailOnError
    Exit Sub
Err_Check:
    subWriteErrorFile "subReturnGuardsPosition," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub tmrDurations_Timer()
On Error GoTo Err_Check
    subPlayerDurationCountdown
    subMobDurationCountdown
    Exit Sub
Err_Check:
    subWriteErrorFile "tmrDurations_Timer," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub tmrMobMove_Timer()
On Error GoTo Err_Check
    subServerGhost 111
    subCheckAndRunAuction
    subCheckMobAutoMoveNAttack
    subCheckInitiateClanning 333
    Exit Sub
Err_Check:
    subWriteErrorFile "tmrMobMove_Timer," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subServerGhost(lChance As Long)
On Error GoTo Err_Check
    Dim lObjectID As Long
    Dim rsObject As Recordset
    Dim rsPlayer As Recordset
    Dim lDay As Long
    
    If (lRandom(lChance) = 1) Then
        If (gbllServerGhostPlayerID <> 0 And lRandom(420) = 1) Then
            If (Not bObjectNamePresent(gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ, "ECTOPLASM")) Then
                Set rsObject = MyDB.OpenRecordset("tblObject", dbOpenTable)
                If (Not rsObject.EOF) Then
                    rsObject.AddNew
                    lObjectID = MyCLng(rsObject!ObjectID)
                    rsObject!ObjectName = "ECTOPLASM"
                    rsObject!x = gbllServerGhostAX
                    rsObject!y = gbllServerGhostAY
                    rsObject!z = gbllServerGhostAZ
                    rsObject!Location = 0
                    rsObject!SpecialSelfDeletingDelay = 200 'we delete it a few ticks after the spring stops gushing
                    rsObject!GroundObjectType = 1
                    rsObject!GroundObjectTypeDuration = 300
                    MyDB.Execute "INSERT INTO tblObjectSpecialSelfDeletingDelay (ObjectID) SELECT " & lObjectID & ";", dbFailOnError
                    rsObject.Update
                End If
                Set rsObject = Nothing
                subSendMsgAreaAll "&CE&cCTO&gPLASM &Cdrips down the walls!", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
            End If
        End If
        
        If (lRandom(4000) = 1 And gblbRealmGhostCemetaryAwake) Then
            subSendMsgInfoChannel "&BThis &WRealm Ghost&B has the powers of a " & gblzAsciiPoltergeist & "&B, and is haunting the realm right now!"
        End If
        
        If (lRandom(2000) = 1) Then 'just turn it off, dont want this going too crazy
            subSendMsgInfoChannel "&BThe &WRealm Ghost&B is &aslumbering&B happily back in the &aCemetary&B!"
            gbllServerGhostPlayerID = 0
            gblzServerGhostPortID = ""
            gblzServerGhostPlayerName = ""
            gblbRealmGhostCemetaryAwake = False
        End If
        
        If (gbllServerGhostPlayerID <> 0 And lRandom(220) = 1) Then 'just turn it off, dont want this going too crazy
            If (gblbRealmGhostCemetaryAwake And lRandom(55) = 1) Then subSendMsgInfoChannel "&BThe &WRealm Ghost&B is upset " & gblzServerGhostPlayerName & " disturbed its &aslumber&B!"
            gbllServerGhostX = gbllServerGhostAX 'the ghost randomly moves CLOSER to the target
            gbllServerGhostY = gbllServerGhostAY
            gbllServerGhostZ = gbllServerGhostAZ
            'randomly place the Ghost of DEATH nearby the player
            gbllServerGhostX = gbllServerGhostX - (lRandom(2) - 1)
            gbllServerGhostX = gbllServerGhostX + (lRandom(2) - 1)
            gbllServerGhostY = gbllServerGhostY - (lRandom(2) - 1)
            gbllServerGhostY = gbllServerGhostY + (lRandom(2) - 1)
            gbllServerGhostZ = gbllServerGhostZ - (lRandom(2) - 1)
            gbllServerGhostZ = gbllServerGhostZ + (lRandom(2) - 1)
        End If
        
        lDay = MyCLng(Format(Now(), "D"))
        If (lDay < 10 Or lDay > 20) Then  'just the start and very end of the month, this does halloween and winter seasons nicely
            If (gbllServerGhostPlayerID <> 0) Then
                If (lRandom(66) = 1) Then
                    gbllServerGhostPlayerID = 0
                    subSendMsg "&BYou are positive the &WRealm Ghost&B has moved on to haunt elsewhere!", gblzServerGhostPortID
                    gblzServerGhostPortID = ""
                    gblbRealmGhostCemetaryAwake = False
                    gblzServerGhostPlayerName = ""
                End If
            Else
                If (lRandom(999) = 1) Then
                    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName,PortID,PlayerID,X,Y,Z FROM tblPlayer WHERE (Len([PortID])>1);", dbOpenSnapshot)
                    Do While (Not rsPlayer.EOF)
                        If (lRandom(4) = 1) Then
                            gblzServerGhostPortID = MyCLng(rsPlayer!PortID)
                            gbllServerGhostPlayerID = MyCLng(rsPlayer!PlayerID)
                            gblzServerGhostPlayerName = MyCStr(rsPlayer!PlayerName)
                            gbllServerGhostX = MyCLng(rsPlayer!x)
                            gbllServerGhostY = MyCLng(rsPlayer!y)
                            gbllServerGhostZ = MyCLng(rsPlayer!z)
                            gbllServerGhostAX = gbllServerGhostX
                            gbllServerGhostAY = gbllServerGhostY
                            gbllServerGhostAZ = gbllServerGhostZ
                            If (gbllServerGhostDX1 <= gbllServerGhostAX And gbllServerGhostDX2 >= gbllServerGhostAX And gbllServerGhostDY1 <= gbllServerGhostAY And gbllServerGhostDY2 >= gbllServerGhostAY) Then
                                gblbRealmGhostCemetaryAwake = (gbllServerGhostAZ > -5 And gbllServerGhostAZ < 5)
                                If (gblbRealmGhostCemetaryAwake) Then
                                    subSendMsg "&BYou have woken " & gblzAsciiPoltergeist & " &WR&aealm &WG&ahost&B!", gblzServerGhostPortID
                                    subSendMsgInfoChannel "&W" & gblzServerGhostPlayerName & " &ahas unfortunately ventured into the Cemetary!"
                                End If
                            Else
                                subSendMsg "&BThe &WRealm Ghost&B knows of your existance!", gblzServerGhostPortID
                            End If
                            subSendMsgAreaAll "&GS&atrange &GG&aoo is showing up on the &gwalls &aaround you.", gbllServerGhostX, gbllServerGhostY, gbllServerGhostZ 'this message must go here unchanged
                            'randomly place the Ghost of DEATH nearby the player
                            gbllServerGhostX = gbllServerGhostX - (lRandom(4) - 1)
                            gbllServerGhostX = gbllServerGhostX + (lRandom(4) - 1)
                            gbllServerGhostY = gbllServerGhostY - (lRandom(4) - 1)
                            gbllServerGhostY = gbllServerGhostY + (lRandom(4) - 1)
                            gbllServerGhostZ = gbllServerGhostZ - (lRandom(4) - 1)
                            gbllServerGhostZ = gbllServerGhostZ + (lRandom(4) - 1)
                        End If
                        rsPlayer.MoveNext
                    Loop
                    Set rsPlayer = Nothing
                End If
            End If
            
            If (gbllServerGhostPlayerID <> 0) Then
                If (lRandom(4) = 1) Then
                    Select Case lRandom(6)
                        Case 1
                            subSendMsgAreaAll "&BA strange &wfog &Bmoves though the area!", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                        Case 2
                            subSendMsgAreaAll "&BWait! That was not &wfog &Bit changed directions, or did it?!?", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                        Case 3
                            subSendMsgAreaAll "&BThe leaves are moving by themselves and there is no wind !", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                        Case 4
                            subSendMsgAreaAll "&BThe &Garea &gis &Bbeing haunted, there is &GG&goo &GE&gverywhere&B!", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                        Case 5
                            subSendMsgAreaAll "&WWhite ghostly mist forms around the area!", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                        Case Else
                            subSendMsgAreaAll "&aThis haunting is very scarey !!!", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                    End Select
                End If
    
                If (lRandom(99) = 1) Then
                    subSendMsg "&BYou are being haunted by the (mostly harmless) &WRealm Ghost&B.", gblzServerGhostPortID
                End If
                
                If (lRandom(99) = 1) Then
                    subSendMsg "&BYou are positive the &WRealm Ghost&B is nearby!", gblzServerGhostPortID
                End If
            
                If (lRandom(2) = 1) Then
                    Select Case lRandom(2)
                        Case 1
                            gbllServerGhostX = gbllServerGhostX - 1
                        Case Else
                            gbllServerGhostX = gbllServerGhostX + 1
                    End Select
                    Select Case lRandom(2)
                        Case 1
                            gbllServerGhostY = gbllServerGhostY - 1
                        Case Else
                            gbllServerGhostY = gbllServerGhostY + 1
                    End Select
                    Select Case lRandom(2)
                        Case 1
                            gbllServerGhostZ = gbllServerGhostZ - 1
                        Case Else
                            gbllServerGhostZ = gbllServerGhostZ + 1
                    End Select
                End If
            End If
        End If
        
        If (gbllServerGhostPlayerID <> 0) Then 'Game over?
            If (gbllServerGhostAX = gbllServerGhostX And gbllServerGhostAY = gbllServerGhostY And gbllServerGhostAZ = gbllServerGhostZ) Then
                subSendMsgAreaAll "&BThe scarey &WRealm Ghost&B screams in the area, then &wpoof&B disappears!", gbllServerGhostAX, gbllServerGhostAY, gbllServerGhostAZ
                If (gblbRealmGhostCemetaryAwake) Then 'its a more powerful one
                    MyDB.Execute "UPDATE tblPlayer SET StunDuration=8, PlayerFleeDuration=50, CHP=[CHP]/6, CSoul=[CSoul]/6 WHERE (X=" & gbllServerGhostAX & " AND Y=" & gbllServerGhostAY & " AND Z=" & gbllServerGhostAZ & " AND Len([PortID])>1);", dbFailOnError
                Else
                    MyDB.Execute "UPDATE tblPlayer SET StunDuration=4, PlayerFleeDuration=15, CHP=[CHP]/4 WHERE (X=" & gbllServerGhostAX & " AND Y=" & gbllServerGhostAY & " AND Z=" & gbllServerGhostAZ & " AND Len([PortID])>1);", dbFailOnError
                End If
                gbllServerGhostPlayerID = 0
                gblzServerGhostPortID = ""
                gblbRealmGhostCemetaryAwake = False
                gblzServerGhostPlayerName = ""
            End If
        End If
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subServerGhost," & vbCrLf & "ERROR #" & Err.Number & vbCrLf & Err.Description
End Sub
Private Sub subShowOnForm()
    Dim lCountSystemErrors As Long
    If (gbllSystemTick = 1) Then
        lCountSystemErrors = lReturnTotalSystemErrors()
        Select Case (lCountSystemErrors)
            Case 0
                lblSystemErrors.ForeColor = &H8000& 'green!
                Select Case gblbServerWillBeRightBack
                    Case True
                        lblSystemErrors.Caption = "Snoozing till 9:30am"
                    Case False
                        lblSystemErrors.Caption = "System Operational"
                End Select
    
                'txtLastBackUpFile.Text = "Last Back up: " & zFilenameBackupLocation()
            Case Else
                lblSystemErrors.ForeColor = &HC0&   'red!
                lblSystemErrors.Caption = lCountSystemErrors & " Errors! Restore the system!"
                'txtLastBackUpFile.Text = "Back up from: " & zFilenameBackupLocation()
        End Select
    End If
End Sub
Private Sub txtWearItemMAX_LostFocus()
On Error Resume Next
    gbllWearItemMAX = MyCLng(txtWearItemMAX)
    If gbllWearItemMAX < 5 Then
        gbllWearItemMAX = 5
        txtWearItemMAX = 5
    End If
    If gbllWearItemMAX <> 52 And gbllWearItemMAX > 25 Then
        gbllWearItemMAX = 25
        txtWearItemMAX = 25
    End If
    gbllWearItemMAXAdmin = gbllWearItemMAX
End Sub
