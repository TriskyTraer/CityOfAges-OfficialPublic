VERSION 5.00
Begin VB.Form frmStarfield 
   Appearance      =   0  'Flat
   BackColor       =   &H80000005&
   Caption         =   "Starfield Use mouse and keyboard at the same time !"
   ClientHeight    =   10785
   ClientLeft      =   120
   ClientTop       =   465
   ClientWidth     =   16590
   Icon            =   "frmStarfield.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   10785
   ScaleWidth      =   16590
   StartUpPosition =   3  'Windows Default
   Begin VB.Timer tmrAllowMouse 
      Interval        =   333
      Left            =   0
      Top             =   600
   End
   Begin VB.Timer tmrMain 
      Interval        =   100
      Left            =   0
      Top             =   120
   End
   Begin VB.PictureBox picView 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   10815
      Left            =   0
      ScaleHeight     =   10785
      ScaleWidth      =   16545
      TabIndex        =   0
      Top             =   0
      Width           =   16575
   End
End
Attribute VB_Name = "frmStarfield"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private gblbAllowMouse As Boolean
Private gblbLoadMouse As Boolean

'=========================================
' constants
'=========================================
Private Const NUM_STARS As Long = 10000
Private Const WORLD_SIZE As Single = 5000
Private Const FOV As Single = 400

'=========================================
' star structure
'=========================================
Private Type StarType
    X As Single
    Y As Single
    Z As Single
End Type

Private Stars() As StarType

'=========================================
' camera variables
'=========================================
Private CamX As Single
Private CamY As Single
Private CamZ As Single

Private CamYaw As Single
Private CamPitch As Single

'=========================================
' movement flags
'=========================================
Private KeyW As Boolean
Private KeyA As Boolean
Private KeyS As Boolean
Private KeyD As Boolean
Private KeyQ As Boolean
Private KeyE As Boolean

Private MoveSpeed As Single
Private MouseSensitivity As Single

Private LastMouseX As Single
Private LastMouseY As Single

Private sngHoldLastMouseX As Single
Private sngHoldLastMouseY As Single


'=========================================
' startup
'=========================================
Private Sub Form_Load()

    Dim i As Long

    Randomize

    ReDim Stars(1 To NUM_STARS)
    CamX = 0
    CamY = 0
    CamZ = 0

    CamYaw = 0
    CamPitch = 0

    MoveSpeed = 25
    MouseSensitivity = 0.004

    'For i = 1 To NUM_STARS
    '    Stars(i).X = (Rnd * WORLD_SIZE * 2) - WORLD_SIZE
    '    Stars(i).Y = (Rnd * WORLD_SIZE * 2) - WORLD_SIZE
    '    Stars(i).Z = (Rnd * WORLD_SIZE * 2) - WORLD_SIZE
    'Next i
    
    subLoadXYZFile

    picView.BackColor = vbBlack
    picView.AutoRedraw = True
    picView.ScaleMode = vbPixels

    Me.KeyPreview = True

End Sub

'=========================================
' keyboard down
'=========================================
Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)

    Select Case KeyCode
        Case vbKeyW: KeyW = True
        Case vbKeyA: KeyA = True
        Case vbKeyS: KeyS = True
        Case vbKeyD: KeyD = True
        Case vbKeyQ: KeyQ = True
        Case vbKeyE: KeyE = True
    End Select

End Sub

'=========================================
' keyboard up
'=========================================
Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)

    Select Case KeyCode
        Case vbKeyW: KeyW = False
        Case vbKeyA: KeyA = False
        Case vbKeyS: KeyS = False
        Case vbKeyD: KeyD = False
        Case vbKeyQ: KeyQ = False
        Case vbKeyE: KeyE = False
    End Select

End Sub
'=========================================
' mouse look and move
'=========================================
Private Sub picView_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    gblbAllowMouse = False
    gblbLoadMouse = False
    sngHoldLastMouseX = LastMouseX
    sngHoldLastMouseY = LastMouseY
End Sub
Private Sub picView_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    gblbAllowMouse = True
    gblbLoadMouse = True
End Sub
Private Sub picView_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Dim dx As Single
    Dim dy As Single

    If (gblbAllowMouse) Then
        If (gblbLoadMouse) Then
            LastMouseX = X
            LastMouseY = Y
            gblbLoadMouse = False
        End If
        dx = X - LastMouseX
        dy = Y - LastMouseY
    
        CamYaw = CamYaw + dx * MouseSensitivity
        CamPitch = CamPitch + dy * MouseSensitivity
    
        If CamPitch > 1.5 Then CamPitch = 1.5
        If CamPitch < -1.5 Then CamPitch = -1.5
    
        LastMouseX = X
        LastMouseY = Y
    End If
End Sub
'=========================================
' timer loop
'=========================================
Private Sub tmrMain_Timer()

    UpdateCamera
    RenderScene

End Sub

'=========================================
' camera movement
'=========================================
Private Sub UpdateCamera()

    Dim ForwardX As Single
    Dim ForwardZ As Single

    Dim RightX As Single
    Dim RightZ As Single

    ForwardX = Sin(CamYaw)
    ForwardZ = Cos(CamYaw)

    RightX = Cos(CamYaw)
    RightZ = -Sin(CamYaw)

    If KeyW Then
        CamX = CamX + ForwardX * MoveSpeed
        CamZ = CamZ + ForwardZ * MoveSpeed
    End If

    If KeyS Then
        CamX = CamX - ForwardX * MoveSpeed
        CamZ = CamZ - ForwardZ * MoveSpeed
    End If

    If KeyA Then
        CamX = CamX - RightX * MoveSpeed
        CamZ = CamZ - RightZ * MoveSpeed
    End If

    If KeyD Then
        CamX = CamX + RightX * MoveSpeed
        CamZ = CamZ + RightZ * MoveSpeed
    End If

    If KeyQ Then
        CamY = CamY - MoveSpeed
    End If

    If KeyE Then
        CamY = CamY + MoveSpeed
    End If

End Sub

'=========================================
' render stars
'=========================================
Private Sub RenderScene()

    Dim i As Long

    Dim dx As Single
    Dim dy As Single
    Dim dz As Single

    Dim rx As Single
    Dim ry As Single
    Dim rz As Single

    Dim sx As Single
    Dim sy As Single

    Dim sngScale As Single
    Dim radius As Single

    Dim cy As Single
    Dim syaw As Single
    Dim cp As Single
    Dim sp As Single

    picView.Cls

    cy = Cos(CamYaw)
    syaw = Sin(CamYaw)

    cp = Cos(CamPitch)
    sp = Sin(CamPitch)

    For i = 1 To NUM_STARS

        dx = Stars(i).X - CamX
        dy = Stars(i).Y - CamY
        dz = Stars(i).Z - CamZ

        ' rotate yaw
        rx = dx * cy - dz * syaw
        rz = dx * syaw + dz * cy

        ' rotate pitch
        ry = dy * cp - rz * sp
        rz = dy * sp + rz * cp

        If rz > 1 Then

            If rz <> 0 Then
                sngScale = FOV / rz
            Else
                sngScale = 0
            End If

            sx = picView.ScaleWidth / 2 + rx * sngScale
            sy = picView.ScaleHeight / 2 - ry * sngScale

            If sx >= 0 And sx < picView.ScaleWidth _
            And sy >= 0 And sy < picView.ScaleHeight Then

                ' bigger when closer
                radius = 20 / rz

                If radius < 1 Then radius = 1
                If radius > 8 Then radius = 8

                picView.Circle (sx, sy), radius, vbWhite

            End If

        End If

    Next i

End Sub



'=========================================
' safe exponent math
'=========================================
Private Function SafePower(ByVal BaseVal As Double, _
                           ByVal ExpVal As Double) As Double

    On Error GoTo PowerError

    If BaseVal = 0 And ExpVal < 0 Then
        SafePower = 0
        Exit Function
    End If

    If BaseVal < 0 Then
        If ExpVal <> Int(ExpVal) Then
            SafePower = 0
            Exit Function
        End If
    End If

    If ExpVal > 50 Then ExpVal = 50
    If ExpVal < -50 Then ExpVal = -50

    SafePower = BaseVal ^ ExpVal
    Exit Function

PowerError:
    SafePower = 0

End Function

Private Sub subLoadXYZFile()
    Dim zLine As String
    Dim zChar As String
    Dim zVal As String
    Dim iStep As Integer
    Dim i As Integer
    Dim ii As Integer
    Dim f As Integer
    i = 0
    f = FreeFile
    Open App.Path & "\coaxyz.txt" For Input As #f
    Do While (Not EOF(f) And i < 7000)
        i = i + 1
        Line Input #f, zLine
        zLine = zLine & " " 'to help the for-loop
        'Debug.Print zline   ' Or process it however you want
        zVal = ""
        iStep = 0
        For ii = 1 To Len(zLine)
            zChar = Mid(zLine, ii, 1)
            Select Case zChar
                Case "-", "+", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
                    zVal = zVal & zChar
                Case Else
                    If (IsNumeric(zVal)) Then
                        iStep = iStep + 1
                        Select Case iStep
                            Case 1
                                Stars(i).X = CLng(zVal)
                            Case 2
                                Stars(i).Y = -1 * CLng(zVal)
                            Case 3
                                Stars(i).Z = CLng(zVal)
                                iStep = 0
                        End Select
                    End If
                    zVal = ""
            End Select
        Next ii
    Loop
    Close #f
End Sub
