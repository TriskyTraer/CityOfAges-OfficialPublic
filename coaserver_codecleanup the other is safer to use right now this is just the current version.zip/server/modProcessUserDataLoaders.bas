Attribute VB_Name = "modProcessUserDataLoaders"
Option Explicit
Public Sub subCostDamageReport(zWord1 As String, zWord2 As String, zWord3 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerLevel As Long
    Dim lPortID As Long
    Dim zRace As String
    Dim zClass As String
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel, Race, Class FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        zRace = MyCStr(rsPlayer!Race)
        zClass = MyCStr(rsPlayer!Class)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        lPortID = MyCLng(zPortID)
        Select Case Mid(zWord1, 1, 4)
            Case "DAMA", "DMG", "DAMG", "DMAG", "DMGA"
                If (gblbClientMode(lPortID)) Then
                    Select Case Mid(zWord2, 1, 4)
                        Case "", "TREE"
                            subPlayerSpellHealDamageTree lPlayerLevel, zRace, zClass, "<::=-DAMAGE TREE-=::>", 0, zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSpellHealDamageTree lPlayerLevel, Mid(zWord3, 1, 3), Mid(zWord2, 1, 2), "<::=-DAMAGE TREE-=::>", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                Else
                    Select Case Mid(zWord2, 1, 4)
                        Case "", "TREE"
                            subPlayerSpellHealDamageTree lPlayerLevel, zRace, zClass, "DAMAGE TREE", 0, zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSpellHealDamageTree lPlayerLevel, Mid(zWord3, 1, 3), Mid(zWord2, 1, 2), "DAMAGE TREE", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                End If
            Case "COST" 'Learn Points get traded for a better skill in a weapon type or something unique.
                If (gblbClientMode(lPortID)) Then
                    Select Case Mid(zWord2, 1, 4)
                        Case "", "TREE" '
                            subPlayerSkillsCostTree lPlayerLevel, zRace, zClass, "<::=-COST TREE-=::>", 0, zPortID
                            subSendMsg "&wNOTE: LEARN SPELLNAME5   - to learn 5 percent at a time." & vbCrLf & "Use PRACTICE to see what you have already learnt." & vbCrLf & "Use LEARN TREE to see what other spells and skills you can learn." & vbCrLf & "See Also: SLIST", zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSkillsCostTree lPlayerLevel, Mid(zWord3, 1, 3), Mid(zWord2, 1, 2), "<::=-COST TREE-=::>", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                Else
                    Select Case Mid(zWord2, 1, 4)
                        Case "", "TREE" '
                            subPlayerSkillsCostTree lPlayerLevel, zRace, zClass, "COST TREE", 0, zPortID
                            subSendMsg "&wNOTE: LEARN SPELLNAME5   - to learn 5 percent at a time." & vbCrLf & "Use PRACTICE to see what you have already learnt." & vbCrLf & "Use LEARN TREE to see what other spells and skills you can learn." & vbCrLf & "See Also: SLIST", zPortID
                        Case "ASSA", "BARD", "CLER", "DRUI", "GLAD", "GYPS", "KNIG", "MAGE", "MONK", "PALA", "PALY", "RANG", "THIE", "WARR", "DRAC", "DWAR", "ELF", "GNOM", "HALF", "HUMA", "MINO", "OGRE", "ORC", "PIXI", "TROL", "UNDE", "VAMP", "WERE", "PLAN", "CYBO", "VEGI", "VEGA", "VEGE"
                            subPlayerSkillsCostTree lPlayerLevel, Mid(zWord3, 1, 3), Mid(zWord2, 1, 2), "COST TREE", 0, zPortID
                        Case Else
                            subSendMsg "&wCOST CLASS" & vbCrLf & "See Also: SLIST", zPortID
                    End Select
                End If
        End Select
    Else
        subSendMsg "&RPlayer file not found :: subCostDamageReport", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subCostDamageReport," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subGambleMergeCardsLoad(zWord2 As String, zWord3 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,PlayerName,X,Y,Z,Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        subGambleMergeCards lPlayerID, zWord2, zWord3, zPortID, zPlayerName, lX, lY, lZ, lStatus
    Else
        subSendMsg "&RPlayer file not found :: subGambleMergeCardsLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subGambleMergeCardsLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub

Public Sub subGuessTheWordGameLoad(zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    'Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lImmortalLevel As Long
    Dim lLearnPoints As Long
    Dim bFound As Boolean
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerName,LearnPoints,ImmortalLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        'lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lLearnPoints = MyCLng(rsPlayer!LearnPoints)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        subGuessTheWordGame zPortID, zWord2, zPlayerName, lImmortalLevel, lLearnPoints
        If (lImmortalLevel > 97) Then
            subSendMsg "&r(EYE) IL98+&W Current word answer is -" & gblzSystemGuessWord & "- the scrambled question is -" & gblzSystemGuessWordScrambled & "-", zPortID
            If (Len(gblzSystemGuessWord) = 0 And Len(MyCStr(zWord2)) > 4) Then
                gblzSystemGuessWord = MyCStr(UCase(zWord2))
                subSendMsg "&WYou set up Guess the Word game! The word is: " & gblzSystemGuessWord & vbCrLf & "You can cancel the quest with IMMO GUESS.", zPortID
                subSendMsg "&WThe Guess word has been used " & lGuessWordCountAdd(gblzSystemGuessWord) + 1 & ".", zPortID
                Select Case lRandom(5)
                    Case 1, 2, 3
                        gbliSystemGuessWordBonusGlory = lRandom(3)
                    Case Else
                        gbliSystemGuessWordBonusGlory = 0
                End Select
                gblzSystemGuessWordScrambled = zScramble(gblzSystemGuessWord, gbliSystemGuessWordBonusGlory)
                Select Case (gbliSystemGuessWordBonusGlory) 'select a message
                    Case 0
                        subSimpleQuestChannel "&yUse the GUESS command and unscramble the word(" & Len(gblzSystemGuessWord) & ") " & gblzSystemGuessWordScrambled & "!"
                    Case 1
                        subSimpleQuestChannel "&yUse the GUESS command and unscramble the word(" & Len(gblzSystemGuessWord) & ") " & gblzSystemGuessWordScrambled & "!" & vbCrLf & "&a*1* Bonus Glory!" & vbCrLf & "There is one extra letter that cannot be used."
                    Case Else
                        subSimpleQuestChannel "&yUse the GUESS command and unscramble the word(" & Len(gblzSystemGuessWord) & ") " & gblzSystemGuessWordScrambled & "!" & vbCrLf & "&a*" & gbliSystemGuessWordBonusGlory & "* Bonus Glory!" & vbCrLf & "There are " & gbliSystemGuessWordBonusGlory & " extra letters that cannot be used."
                End Select
            Else
                subSendMsg "&GImmortals can: GUESS REALWORD will set up the word scramble game." & vbCrLf & "The RealWord must be at least 5 characters long. IMMO GUESS - will cancel the game.", zPortID
            End If
        End If
    Else
        subSendMsg "&RPlayer file not found :: subGuessTheWordGameLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subGuessTheWordGameLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subImmortalWHODisplayed(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    'Dim lPlayerID As Long
    Dim lImmortalLevel As Long
    Dim lPortID As Long
    Dim bFound As Boolean
    
    lPortID = MyCLng(zPortID)
    
    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT ImmortalLevel FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        'lPlayerID = MyCLng(rsPlayer!PlayerID)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        If (lImmortalLevel > 0) Then
            gblbImmortalWHODisplayed(lPortID) = Not gblbImmortalWHODisplayed(lPortID)
            Select Case gblbImmortalWHODisplayed(lPortID)
                Case True
                    subSendMsg "&WYou will be displayed in the who list.", zPortID
                Case Else
                    subSendMsg "&wYou will NOT be displayed in the who list.", zPortID
            End Select
        Else
            subSendMsg "&gHuh?", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subImmortalWHODisplayed", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subImmortalWHODisplayed," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subSkillReloadRemoveWearLoad(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim zGender As String
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lInvisibilityDuration As Long
    Dim lStatus As Long
    Dim lReloadPenalty As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,InvisibilityDuration,X,Y,Z,PlayerName,Status,Gender,ReloadPenalty FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        zGender = MyCStr(rsPlayer!Gender)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lReloadPenalty = MyCLng(rsPlayer!ReloadPenalty)
    End If
    Set rsPlayer = Nothing

    If (bFound) Then
        subSkillReloadRemoveWear zPlayerName, lPlayerID, lReloadPenalty, zPortID, zGender, lX, lY, lZ, lStatus, lInvisibilityDuration
    Else
        subSendMsg "&RPlayer file not found :: subSkillReloadRemoveWearLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subSkillReloadRemoveWearLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBuryLoad(zWord2 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCMove As Long
    Dim lStatus As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,CMove, X, Y, Z, PlayerName, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lCMove = MyCLng(rsPlayer!CMove)
    End If
    Set rsPlayer = Nothing

    If (bFound) Then
        subBury lX, lY, lZ, zWord2, zPortID, lPlayerID, zPlayerName, lStatus, lCMove
    Else
        subSendMsg "&RPlayer file not found :: subBuryLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subBuryLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDigFindLoad(zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCMove As Long
    Dim lStatus As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,CMove, X, Y, Z, PlayerName, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lCMove = MyCLng(rsPlayer!CMove)
    End If
    Set rsPlayer = Nothing

    If (bFound) Then
        subDigFind lX, lY, lZ, zPortID, lPlayerID, zPlayerName, lStatus, lCMove
    Else
        subSendMsg "&RPlayer file not found :: subDigFindLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDigFindLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBankingLoad(zWord2 As String, zWord3 As String, zPortID As String)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lGold As Long
    Dim lStatus As Long
    Dim lPlayerLevel As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerLevel,PlayerID,Gold, X, Y, Z, PlayerName, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lGold = MyCLng(rsPlayer!Gold)
    End If
    Set rsPlayer = Nothing

    If (bFound) Then
        If (bWhenIsIt("", False) Or lPlayerLevel < 20) Then
            subBanking zPortID, zPlayerName, lPlayerID, zWord3, lGold, lX, lY, lZ, zWord2, lStatus
        Else
            subSendMsg "&BThe banks are closed at night.", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subBankingLoad", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subBankingLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subBanking(zPortID As String, zPlayerName As String, lPlayerID As Long, zGold As String, lPlayerTotalGold As Long, lX As Long, lY As Long, lZ As Long, zMode As String, lStatus As Long)
On Error GoTo Err_Check
    Dim rsBank As Recordset
    Dim rsPlayer As Recordset
    Dim lBankGold As Long
    Dim lGold As Long
    
    'If (Not bPartOfAuction(zPortID, lPlayerID)) Then
        If (lStatus <> 50) Then
            lGold = MyCLng(zGold)
            
            Set rsBank = MyDB.OpenRecordset("SELECT * FROM tblBank WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND CertifiedLocation<>0);", dbOpenSnapshot) 'Look for a bank in the area.
            If (Not rsBank.EOF) Then
                Set rsPlayer = MyDB.OpenRecordset("SELECT * FROM tblBank WHERE (X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & ") AND (PlayerID=" & lPlayerID & ");", dbOpenDynaset)
                If (Not rsPlayer.EOF) Then
                    lBankGold = MyCLng(rsPlayer!Gold)
                    Select Case UCase(Mid(zMode, 1, 4))
                        Case "BOOK", "UPDA", "LIST", "ACCO"
                            subSendMsg "&yThe teller says, 'Your book shows " & lBankGold & " gold at the bank.'", zPortID
                            subSendMsgAreaExcept2 gblzFBMAG & "a bank teller shows " & zPlayerName & " an account status.", lX, lY, lZ, zPortID, ""
                        Case "WITH"
                            If (zGold = "ALL") Then lGold = lBankGold
                            
                            If (lGold > 0) Then
                                If (lGold <= lBankGold) Then
                                    rsPlayer.Edit
                                    rsPlayer!Gold = rsPlayer!Gold - lGold
                                    rsPlayer.Update
                                    If (rsPlayer!Gold < 1) Then
                                        rsPlayer.Delete 'We remove the account
                                    End If
                                    MyDB.Execute "UPDATE tblPlayer SET Gold = [Gold] + " & lGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                    subSendMsg "&yThe teller says, 'There you are.'", zPortID
                                    subSendMsgAreaExcept2 gblzFBMAG & "a bank teller hands " & zPlayerName & " some gold.", lX, lY, lZ, zPortID, ""
                                Else
                                    subSendMsg "&GYou are asking for more than what is in your account.", zPortID
                                End If
                            Else
                                subSendMsg "&GYou cannot withdraw zero gold.", zPortID
                            End If
                        Case "DEPO"
                            If (zGold = "ALL") Then lGold = lPlayerTotalGold
                            
                            If (lGold > 0) Then
                                If (lGold <= lPlayerTotalGold) Then
                                    rsPlayer.Edit
                                    rsPlayer!Gold = rsPlayer!Gold + lGold
                                    rsPlayer.Update
                                    MyDB.Execute "UPDATE tblPlayer SET Gold = [Gold] - " & lGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                    subSendMsg "&yThe teller says, 'Thank you for your deposit.'", zPortID
                                    subSendMsgAreaExcept2 gblzFBMAG & "a bank teller takes gold from " & zPlayerName & ".", lX, lY, lZ, zPortID, ""
                                Else
                                    subSendMsg "&GYou are trying to deposit more than you have.", zPortID
                                End If
                            Else
                                subSendMsg "&GYou cannot deposit zero gold.", zPortID
                            End If
                        Case Else
                            subSendMsg "&GBANK ACCOUNT" & vbCrLf & "BANK [WITHDRAW/DEPOSIT] [ALL/GOLDAMOUNT]", zPortID
                    End Select
                Else
                    Select Case UCase(Mid(zMode, 1, 4))
                        Case "BOOK", "UPDA", "LIST"
                            subSendMsg "&yThe teller says, 'You do not have an account with us.'", zPortID
                            subSendMsgAreaExcept2 gblzFBMAG & "a bank teller looks bewhilered at " & zPlayerName & ".", lX, lY, lZ, zPortID, ""
                        Case "WITH"
                            subSendMsg "&GYou do not have a bank account here.", zPortID
                        Case "DEPO"
                            If (zGold = "ALL") Then lGold = lPlayerTotalGold
                            
                            If (lGold <= lPlayerTotalGold) Then
                                rsPlayer.AddNew
                                rsPlayer!x = lX
                                rsPlayer!y = lY
                                rsPlayer!z = lZ
                                rsPlayer!PlayerID = lPlayerID
                                rsPlayer!Gold = lGold
                                rsPlayer.Update
                                MyDB.Execute "UPDATE tblPlayer SET Gold = [Gold] - " & lGold & " WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
                                subSendMsg "&yThe teller says, 'Thank you for opening an account with us.'", zPortID
                                subSendMsgAreaExcept2 gblzFBMAG & "a bank teller hands " & zPlayerName & " an account note and takes some cash.", lX, lY, lZ, zPortID, ""
                            Else
                                subSendMsg "&GYou are trying to deposit more than what you have.", zPortID
                            End If
                        Case Else
                            subSendMsg "&GBANK WITHDRAW/DEPOSIT/LIST Gold.", zPortID
                    End Select
                End If
                Set rsPlayer = Nothing
            Else
                subSendMsg "&GYou do not see a bank here.", zPortID
            End If
            Set rsBank = Nothing
        Else
            subSendMsg "&GYou dream of gold and fame.", zPortID
        End If
    'Else
    '    subSendMsg "&RYou cannot bank your money when you are apart of an auction.", zPortID
    'End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subBankWithDraw," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Function bPlayerCarriesObjectName(zObjectName As String, lPlayerID As Long) As Boolean
On Error GoTo Err_Check
    Dim bReturn As Boolean
    Dim rsPlayerObject As Recordset
    Set rsPlayerObject = MyDB.OpenRecordset("SELECT ObjectID FROM tblObject WHERE (ObjectName=""" & zObjectName & """ AND PlayerID=" & lPlayerID & ");", dbOpenSnapshot)
    bReturn = (Not rsPlayerObject.EOF)
    Set rsPlayerObject = Nothing
    bPlayerCarriesObjectName = bReturn
    Exit Function
Err_Check:
    subWriteErrorFile "bPlayerCarriesObjectName," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Function
Public Sub subWAKELoad(zWord2 As String, zPortID As String)
On Error GoTo Err_Check 'ie. subWAKE zWord(2), lX, lY, lZ, lPlayerID, zPortID, zPlayerName, lStatus, lInvisibilityDuration, lDetectInvisibilityDuration
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lPlayerLevel As Long
    Dim lInvisibilityDuration As Long
    Dim lDetectInvisibilityDuration As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lCCHA As Long
    Dim lStatus As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,InvisibilityDuration, X, Y, Z, PlayerName, PlayerLevel, InvisibilityDuration, DetectInvisibilityDuration, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lPlayerLevel = MyCLng(rsPlayer!PlayerLevel)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
        lInvisibilityDuration = MyCLng(rsPlayer!InvisibilityDuration)
        lDetectInvisibilityDuration = MyCLng(rsPlayer!DetectInvisibilityDuration)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        subWAKE zWord2, lX, lY, lZ, lPlayerID, zPortID, zPlayerName, lStatus, lInvisibilityDuration, lDetectInvisibilityDuration
    Else
        subSendMsg "&RPlayer file not found :: subWAKELoad", zPortID
    End If

    Exit Sub
Err_Check:
    subWriteErrorFile "subWAKELoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subWAKE(zTargetPlayer As String, lX As Long, lY As Long, lZ As Long, lPlayerID As Long, zPortID As String, zPlayerName As String, lStatus As Long, lInvisibilityDuration As Long, lDetectInvisibilityDuration As Long)
On Error GoTo Err_Check
    Dim rsPlayer As Recordset
    Dim zSQL As String
    Dim bSelf As Boolean
    Dim bOkayToWakeTarget As Boolean
    
    If (Len(zTargetPlayer) > 0 And UCase(zTargetPlayer) <> "SELF") Then
        zSQL = "SELECT InvisibilityDuration, DetectInvisibilityDuration, PlayerName, PortID, Status, X, Y, Z, PortID, PlayerID FROM tblPlayer WHERE (PlayerName Like '*" & zKeepLettersOnly(zTargetPlayer) & "*' AND X=" & lX & " AND Y=" & lY & " AND Z=" & lZ & " AND Len([PortID])>1);"
        bSelf = False
    Else
        zSQL = "SELECT InvisibilityDuration, DetectInvisibilityDuration, X, Y, Z, PlayerName, PortID, Status, PlayerID FROM tblPlayer WHERE (PlayerID=" & lPlayerID & ");"
        bSelf = True
    End If
    
    Set rsPlayer = MyDB.OpenRecordset(zSQL, dbOpenDynaset)
    If (Not rsPlayer.EOF) Then
        If (MyCLng(rsPlayer!Status) = 50) Then
            If (bSelf) Then
                subSendMsg "&mYou awaken, and stand up.", zPortID
                'subSendMsgAreaExcept2 gblzFBGRE & MyCStr(rsPlayer!PlayerName) & " awakes and sits up.", MyCLng(rsPlayer!X), MyCLng(rsPlayer!Y), MyCLng(rsPlayer!Z), zPortID, MyCStr(rsPlayer!PortID)
                subSendMsgAreaAllDetectInvisibility gblzFNMAG, lPlayerID, _
                    "Someone wakes up from a deep slumber.", _
                    zPlayerName & " wakes up from a deep slumber.", _
                    "", _
                    "", _
                    lX, lY, lZ, (lInvisibilityDuration <> 0), zPortID
                rsPlayer.Edit 'this is for the target player and yourself
                rsPlayer!Status = 5
                rsPlayer.Update
            Else
                If (lStatus <> 50) Then 'cant be sleeping to wake someone up
                    If (MyCLng(rsPlayer!InvisibilityDuration) = 0 Or (lDetectInvisibilityDuration <> 0)) Then
                        bOkayToWakeTarget = True
                    Else
                        bOkayToWakeTarget = False
                    End If
                    
                    If (bOkayToWakeTarget) Then
                        subSendMsg "&mYou wake up " & MyCStr(rsPlayer!PlayerName) & ".", zPortID
                        
                        If (lInvisibilityDuration = 0) Then
                            subSendMsg "&m" & zPlayerName & " woke you up from your slumber.", MyCStr(rsPlayer!PortID)
                        Else
                            If (MyCLng(rsPlayer!DetectInvisibilityDuration) <> 0) Then
                                subSendMsg "&m" & zPlayerName & " woke you up from your slumber.", MyCStr(rsPlayer!PortID)
                            Else
                                subSendMsg "&mSomeone woke you up from your slumber.", MyCStr(rsPlayer!PortID)
                            End If
                        End If
                        
                        subSendMsgAreaAllDetectInvisibility gblzFNMAG, lPlayerID, _
                            "Someone wakes up " & MyCStr(rsPlayer!PlayerName) & ".", _
                            zPlayerName & " wakes up " & MyCStr(rsPlayer!PlayerName) & ".", _
                            "", _
                            "", _
                            lX, lY, lZ, (lInvisibilityDuration <> 0), zPortID
                        rsPlayer.Edit 'this is for the target player and yourself
                        rsPlayer!Status = 5
                        rsPlayer.Update
                    Else
                        subSendMsg "&gWake Whom?", zPortID
                    End If
                Else
                    subSendMsg "&MYou dream of waking up someone.", zPortID
                End If
            End If
        Else
            If (bSelf) Then
                subSendMsg "&GYou are not sleeping.", zPortID
            Else
                If (MyCLng(rsPlayer!InvisibilityDuration) = 0) Then
                    subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " is not asleep and does not need to be woken up.", zPortID
                Else
                    If (lDetectInvisibilityDuration <> 0) Then
                        subSendMsg "&G" & MyCStr(rsPlayer!PlayerName) & " is not asleep and does not need to be woken up.", zPortID
                    Else
                        subSendMsg "&gWake Whom?", zPortID
                    End If
                End If
            End If
        End If
    Else
        subSendMsg "&gWake Whom?", zPortID
    End If
    Set rsPlayer = Nothing
    'Else
    '    subSendMsg "&GYou dream about waking up for the next adventure.", zPortID
    'End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subWAKE," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subChartEmotePetLoad(zPromptOriginal As String, zWord2 As String, zWord3 As String, zWord4 As String, zPortID As String)
On Error GoTo Err_Check 'ie. subWAKE zWord(2), lX, lY, lZ, lPlayerID, zPortID, zPlayerName, lStatus, lInvisibilityDuration, lDetectInvisibilityDuration
    Dim rsPlayer As Recordset
    Dim zPlayerName As String
    Dim lPlayerID As Long
    Dim lX As Long
    Dim lY As Long
    Dim lZ As Long
    Dim lStatus As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,X, Y, Z, PlayerName, Status FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        lX = MyCLng(rsPlayer!x)
        lY = MyCLng(rsPlayer!y)
        lZ = MyCLng(rsPlayer!z)
        lStatus = MyCLng(rsPlayer!Status)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        If (lStatus <> 50) Then
            If (Not bChartEmotePet(zPlayerName, zWord2, zWord3, zWord4, lX, lY, lZ, zPortID, lPlayerID)) Then
                If (Len(zPromptOriginal) > 0) Then subSendMsg "&RYou are too scared to do much right now!", zPortID
            End If
        Else
            subSendMsg "&GYou are asleep you cannot move.", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subChartEmotePetLoad", zPortID
    End If

    Exit Sub
Err_Check:
    subWriteErrorFile "subChartEmotePetLoad," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
Public Sub subDeclineImmortalStatus(zPortID As String)
On Error GoTo Err_Check 'ie. subWAKE zWord(2), lX, lY, lZ, lPlayerID, zPortID, zPlayerName, lStatus, lInvisibilityDuration, lDetectInvisibilityDuration
    Dim rsPlayer As Recordset
    Dim lPlayerID As Long
    Dim zPlayerName As String
    Dim lImmortalLevel As Long
    Dim lImmortalSupervisor As Long
    Dim bFound As Boolean

    bFound = False
    Set rsPlayer = MyDB.OpenRecordset("SELECT PlayerID,PlayerName,ImmortalLevel,ImmortalSupervisor FROM tblPlayer WHERE (PortID='" & zPortID & "');", dbOpenSnapshot)
    If (Not rsPlayer.EOF) Then
        bFound = True
        lPlayerID = MyCLng(rsPlayer!PlayerID)
        zPlayerName = MyCStr(rsPlayer!PlayerName)
        lImmortalLevel = MyCLng(rsPlayer!ImmortalLevel)
        lImmortalSupervisor = MyCLng(rsPlayer!ImmortalSupervisor)
    End If
    Set rsPlayer = Nothing
    
    If (bFound) Then
        If (lImmortalLevel + lImmortalSupervisor > 0) Then
            MyDB.Execute "UPDATE tblPlayer SET ImmortalLevel=0, ImmortalSupervisor=0 WHERE (PlayerID=" & lPlayerID & ");", dbFailOnError
            subSendMsg "&gWelcome mortal!", zPortID
        Else
            subSendMsg "&gHuh, wha?! No! Yes? Try Again???", zPortID
        End If
    Else
        subSendMsg "&RPlayer file not found :: subDeclineImmortalStatus", zPortID
    End If
    Exit Sub
Err_Check:
    subWriteErrorFile "subDeclineImmortalStatus," & vbCrLf & "ERROR#" & Err.Number & vbCrLf & Err.Description
End Sub
