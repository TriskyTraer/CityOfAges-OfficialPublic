VERSION 5.00
Begin VB.Form frmMain 
   Appearance      =   0  'Flat
   BackColor       =   &H00400040&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "3D City of Ages - Map [use WSAD QE to fly]"
   ClientHeight    =   3015
   ClientLeft      =   45
   ClientTop       =   390
   ClientWidth     =   4560
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3015
   ScaleWidth      =   4560
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin VB.Timer tmrAnimate 
      Interval        =   30
      Left            =   120
      Top             =   120
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private iFlipMode As Integer
Private blnFlipUp As Boolean
Private blnFlipDn As Boolean
'=============================
' Types
'=============================
Private Type VECTOR3
    X As Single
    Y As Single
    Z As Single
End Type

Private Type POINTAPI
    X As Long
    Y As Long
End Type

'=============================
' Camera variables
'=============================
Private v3CamPos As VECTOR3
Private sngCamYaw As Single
Private sngCamPitch As Single
Private sngMoveSpeed As Single

Private blnMoveForward As Boolean
Private blnMoveBackward As Boolean
Private blnMoveLeft As Boolean
Private blnMoveRight As Boolean
Private blnMoveUp As Boolean
Private blnMoveDown As Boolean

'=============================
' Starfield
'=============================
Private arrv3Stars() As VECTOR3
Private Const lngStarCount As Long = 7000 '10000 seems to crash

'=============================
' Form Load
'=============================
Private Sub Form_Load()
    Dim i As Long
    Me.Caption = "3D City of Ages - Map [use keys +- WSAD QE to fly] (" & iFlipMode & ")"
    ' Camera initial position
    v3CamPos.X = 0
    v3CamPos.Y = 0
    v3CamPos.Z = 0
    sngCamYaw = 0
    sngCamPitch = 0
    sngMoveSpeed = 5

    ' Generate random starfield
    ReDim arrv3Stars(lngStarCount - 1)
    Dim f As Integer
    Dim ii As Integer
    Dim zline As String
    Dim zChar As String * 1
    Dim zVal As String
    Dim iStep As Integer
    
    i = 0
    f = FreeFile
    Open App.Path & "\coaxyz.txt" For Input As #f
    Do While (Not EOF(f) And i < 7000)
        i = i + 1
        Line Input #f, zline
        zline = zline & " " 'to help the for-loop
        'Debug.Print zline   ' Or process it however you want
        zVal = ""
        iStep = 0
        For ii = 1 To Len(zline)
            zChar = Mid(zline, ii, 1)
            Select Case zChar
                Case "-", "+", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
                    zVal = zVal & zChar
                Case Else
                    If (IsNumeric(zVal)) Then
                        iStep = iStep + 1
                        Select Case iFlipMode
                            Case 0
                                Select Case iStep
                                    Case 1
                                        arrv3Stars(i).X = CLng(zVal)
                                    Case 2
                                        arrv3Stars(i).Y = CLng(zVal)
                                    Case 3
                                        arrv3Stars(i).Z = CLng(zVal)
                                End Select
                            Case 1
                                Select Case iStep
                                    Case 1
                                        arrv3Stars(i).X = CLng(zVal)
                                    Case 3
                                        arrv3Stars(i).Y = CLng(zVal)
                                    Case 2
                                        arrv3Stars(i).Z = CLng(zVal)
                                End Select
                            Case 2
                                Select Case iStep
                                    Case 2
                                        arrv3Stars(i).X = CLng(zVal)
                                    Case 1
                                        arrv3Stars(i).Y = CLng(zVal)
                                    Case 3
                                        arrv3Stars(i).Z = CLng(zVal)
                                End Select
                            Case 3
                                Select Case iStep
                                    Case 2
                                        arrv3Stars(i).X = CLng(zVal)
                                    Case 3
                                        arrv3Stars(i).Y = CLng(zVal)
                                    Case 1
                                        arrv3Stars(i).Z = CLng(zVal)
                                End Select
                            Case 4
                                Select Case iStep
                                    Case 3
                                        arrv3Stars(i).X = CLng(zVal)
                                    Case 1
                                        arrv3Stars(i).Y = CLng(zVal)
                                    Case 2
                                        arrv3Stars(i).Z = CLng(zVal)
                                End Select
                            Case 5
                                Select Case iStep
                                    Case 3
                                        arrv3Stars(i).X = CLng(zVal)
                                    Case 2
                                        arrv3Stars(i).Y = CLng(zVal)
                                    Case 1
                                        arrv3Stars(i).Z = CLng(zVal)
                                End Select
                        End Select
                    End If
                    zVal = ""
            End Select
        Next ii
    Loop
    
    Close #f

    ' Form graphics
    Me.AutoRedraw = True
    Me.ScaleMode = vbPixels
    Me.BackColor = vbBlack
    Me.ForeColor = vbWhite

    ' Timer
    tmrAnimate.Interval = 30
    tmrAnimate.Enabled = True
End Sub



' Transform 3D point relative to camera
'=============================
Private Function v3TransformPoint(v3Point As VECTOR3) As VECTOR3
    Dim v3Result As VECTOR3
    Dim sngDX As Single, sngDY As Single, sngDZ As Single
    Dim sngCosYaw As Single, sngSinYaw As Single
    Dim sngCosPitch As Single, sngSinPitch As Single
    Dim sngXTemp As Single, sngYTemp As Single, sngZTemp As Single

    ' Translate relative to camera
    sngDX = v3Point.X - v3CamPos.X
    'sngDX = sngDX * -1
    sngDY = v3Point.Y - v3CamPos.Y
    sngDY = sngDY * -1
    sngDZ = v3Point.Z - v3CamPos.Z
    'sngDZ = sngDZ * -1

    ' Yaw rotation (around Z-axis)
    sngCosYaw = Cos(sngCamYaw * 3.14159 / 180)
    'sngCosYaw = sngCosYaw * -1
    sngSinYaw = Sin(sngCamYaw * 3.14159 / 180)
    'sngSinYaw = sngSinYaw * -1

    sngXTemp = sngDX * sngCosYaw - sngDY * sngSinYaw
    sngYTemp = sngDX * sngSinYaw + sngDY * sngCosYaw
    sngZTemp = sngDZ

    ' Pitch rotation (around X-axis)
    sngCosPitch = Cos(sngCamPitch * 3.14159 / 180)
    sngSinPitch = Sin(sngCamPitch * 3.14159 / 180)

    v3Result.X = sngXTemp * sngCosPitch + sngZTemp * sngSinPitch
    v3Result.Y = sngYTemp
    v3Result.Z = -sngXTemp * sngSinPitch + sngZTemp * sngCosPitch

    v3TransformPoint = v3Result
End Function

'=============================
' Project 3D point to 2D screen
'=============================
Private Function ptProjectPoint(v3Point As VECTOR3) As POINTAPI
    Dim ptResult As POINTAPI
    Dim sngScale As Single

    ' Prevent divide by zero
    If Abs(v3Point.Z) < 0.0001 Then v3Point.Z = 0.0001

    ' Simple perspective projection
    sngScale = 500 / v3Point.Z

    ptResult.X = CLng(Me.ScaleWidth \ 2 + v3Point.X * sngScale)
    ptResult.Y = CLng(Me.ScaleHeight \ 2 - v3Point.Y * sngScale)

    ptProjectPoint = ptResult
End Function



' Update camera position based on key input
'=============================
Private Sub UpdateCameraPosition()
    Dim sngYawRad As Single
    Dim v3Forward As VECTOR3
    Dim v3Right As VECTOR3

    ' Convert yaw to radians
    sngYawRad = sngCamYaw * 3.14159 / 180

    ' Forward vector in X-Y plane
    v3Forward.X = Sin(sngYawRad)
    v3Forward.Y = Cos(sngYawRad)
    v3Forward.Z = 0

    ' Right vector (perpendicular)
    v3Right.X = Cos(sngYawRad)
    v3Right.Y = -Sin(sngYawRad)
    v3Right.Z = 0

    If blnFlipDn Then
        iFlipMode = iFlipMode - 1
        blnFlipDn = False
        If iFlipMode < 0 Then iFlipMode = 0
        Me.Caption = "3D City of Ages - Map [use keys +- WSAD QE to fly] (" & iFlipMode & ")"
        Call Form_Load
    End If
    If blnFlipUp Then
        iFlipMode = iFlipMode + 1
        blnFlipUp = False
        If iFlipMode > 5 Then iFlipMode = 5
        Me.Caption = "3D City of Ages - Map [use keys +- WSAD QE to fly] (" & iFlipMode & ")"
        Call Form_Load
    End If

    ' Move forward/back
    If blnMoveForward Then
        v3CamPos.X = v3CamPos.X + v3Forward.X * sngMoveSpeed
        v3CamPos.Y = v3CamPos.Y + v3Forward.Y * sngMoveSpeed
    End If
    If blnMoveBackward Then
        v3CamPos.X = v3CamPos.X - v3Forward.X * sngMoveSpeed
        v3CamPos.Y = v3CamPos.Y - v3Forward.Y * sngMoveSpeed
    End If

    ' Strafe left/right
    If blnMoveLeft Then
        v3CamPos.X = v3CamPos.X - v3Right.X * sngMoveSpeed
        v3CamPos.Y = v3CamPos.Y - v3Right.Y * sngMoveSpeed
    End If
    If blnMoveRight Then
        v3CamPos.X = v3CamPos.X + v3Right.X * sngMoveSpeed
        v3CamPos.Y = v3CamPos.Y + v3Right.Y * sngMoveSpeed
    End If

    ' Move up/down
    If blnMoveUp Then v3CamPos.Z = v3CamPos.Z + sngMoveSpeed
    If blnMoveDown Then v3CamPos.Z = v3CamPos.Z - sngMoveSpeed
End Sub
'=============================
' Key down
'=============================
Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
        Case vbKeyW
            blnMoveForward = True
        Case vbKeyS
            blnMoveBackward = True
        Case vbKeyA
            blnMoveLeft = True
        Case vbKeyD
            blnMoveRight = True
        Case vbKeyQ
            blnMoveUp = True
        Case vbKeyE
            blnMoveDown = True
        Case 107
            blnFlipUp = True
        Case 109
            blnFlipDn = True
    End Select
End Sub

'=============================
' Key up
'=============================
Private Sub Form_KeyUp(KeyCode As Integer, Shift As Integer)
    Select Case KeyCode
        Case vbKeyW
            blnMoveForward = False
        Case vbKeyS
            blnMoveBackward = False
        Case vbKeyA
            blnMoveLeft = False
        Case vbKeyD
            blnMoveRight = False
        Case vbKeyQ
            blnMoveUp = False
        Case vbKeyE
            blnMoveDown = False
        Case 107
            blnFlipUp = False
        Case 109
            blnFlipDn = False
    End Select
End Sub
Private Sub tmrAnimate_Timer()
    Dim i As Long
    Dim v3Trans As VECTOR3
    Dim ptScreen As POINTAPI
    Dim sngRadius As Single

    ' Clear previous frame
    Me.Cls

    ' Update camera movement
    UpdateCameraPosition

    ' Draw stars
    For i = 0 To lngStarCount - 1
        v3Trans = v3TransformPoint(arrv3Stars(i))

        ' Only draw stars in front of camera
        If v3Trans.Z > 0 Then
            ptScreen = ptProjectPoint(v3Trans)

            ' Scale radius: closer = bigger
            sngRadius = 200 / v3Trans.Z   ' adjust 200 for intensity
            If sngRadius < 1 Then sngRadius = 1
            If sngRadius > 6 Then sngRadius = 6  ' cap max size

            ' Draw filled white circle
            Me.FillStyle = vbSolid
            Me.ForeColor = vbWhite
            
            If (v3Trans.Z > -99 And v3Trans.Z < 99) Then
                Me.Circle (ptScreen.X, ptScreen.Y), sngRadius, vbGreen
            Else
                Me.Circle (ptScreen.X, ptScreen.Y), sngRadius, vbWhite
            End If
        End If
    Next i
End Sub
